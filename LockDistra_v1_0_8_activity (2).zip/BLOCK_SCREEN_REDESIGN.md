# Block screen redesign

New look for the block screen (`BlockActivity.kt`) for every reason (app, Shorts, section, daily limit, website limit,
website, adult, keyword, bedtime, settings, protection). Drawn fully in code: no image files.

* `ui/components/BlockArt.kt` (new): illustration drawn from SVG path data, title bar, "Daily Limit / Used Today" card,
  countdown card, tip card, colours (light like the design, dark for the dark theme).
* `BlockActivity.kt`: new layout only. Real data: limit = the limit set, used = today's stored usage (app, Shorts/Reels
  and website limits). Title, text and tip change with the reason. Unchanged: all buttons (Continue, Go to Home, Change
  limit, Request to unlock, Open ReWire, Emergency access), the emergency panels, countdowns, auto-close rules.
* Removed: the old pulsing ring hero and the small status chip (the title says it now).

Not compiled or run (no Android SDK here). Run `./gradlew assembleDebug` and open a limit block screen on a phone.
