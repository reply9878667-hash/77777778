# Home first-open shimmer

Home no longer lifts its cards up from the bottom. When the app is opened, Home shows placeholder shapes with a light
band moving left to right (like a video loading skeleton): 2 sweeps, then the real cards fade in.

* `ui/components/Effects.kt`: `HomeShimmer` (SWEEP_MS = 650, SWEEPS = 2: change these to make it faster / longer) and
  `Modifier.shimmerReveal(corner)`.
* `DashboardScreen.kt`: Header, hero timer card, Daily Task Planner and Focus Profile card use it.
* `FocusApp.kt`: starts the shimmer when the splash is gone; the bottom bar now fades in (no slide from the bottom).
* `MainActivity.kt`: a fresh app open resets it (rotation does not). Switching tabs never replays it.
Not compiled or run here (no Android SDK).
