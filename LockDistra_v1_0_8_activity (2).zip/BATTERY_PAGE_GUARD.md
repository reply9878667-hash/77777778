# Battery page guard (1.0.2)

LockDistra's own "Battery usage details" page (Samsung: Battery > LockDistra) has "Stop running in background",
which switches the blocker off. It is now closed like the App info / uninstall page, and only for LockDistra:
the page must show "LockDistra" plus "Battery usage details", "Background power control" or "Stop running in background".
Other apps' battery pages are not touched. Same switches as the uninstall guard (device admin on; focus session
guard or Advanced protection). See `batteryPackages` and `dangerousActions` in service/AppBlockerService.kt.

# 1.0.3
Lecture player: the black circle behind the play / pause button is gone (cover shrinks to a small dot while the controls
are shown) and the black cover after loading now clears in 0.3 s instead of 0.9 s. See LecturePlayerHtml.kt (#cv, paintCover).
