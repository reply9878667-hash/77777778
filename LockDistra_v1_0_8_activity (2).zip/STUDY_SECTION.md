# Study section

Replaces the Settings tab in the bottom bar (Settings is still opened from the gear icon on Home).

* Data: official YouTube Data API v3 (no scraping, no new library).
* API key: paste it in Study > gear icon, or build it in (`youtubeApiKey` in firebase.properties, or env `FOCUSMODE_YT_API_KEY`).
* Free daily limit is 10,000 units. A search costs 100, everything else 1. Results are cached (home 6 h, searches 1 h).
* "Study only" = public + embeddable + not live + (Education category OR trusted channel) + no distraction word in
  the title / channel name. Rules: `data/StudyRules.kt`. Shorts = 3 minutes or less.
* Video page shows only the picture, title, channel and "Start Focus Mode". That opens the normal start wizard with the
  video as the lecture; after it, the locked lecture player plays it (only that video, in its own ratio).

## Key safety (built-in key)
* A key built into an APK can be read out of it, so lock it in Google Cloud: API restrictions = YouTube Data API v3 only,
  Application restrictions = Android apps (package `com.focusmode.app` + the SHA-1 of the key the APK is signed with).
* The app sends `X-Android-Package` and `X-Android-Cert` with every call (`StudyApi`), which is what an Android-restricted key checks.
  Debug and release builds are signed differently: add the SHA-1 of each one you use.
* The 10,000 units a day are shared by ALL phones using this key. A home refresh costs about 400 units (2 subjects x 2 searches x 100).

## Follow + new-video notifications
* **Follow** (video page) = adds the channel to the trusted channels (same list as Study settings). It is a ReWire follow, NOT a
  YouTube subscription: subscribing on YouTube needs the person's Google login (OAuth) and Google's app verification, and YouTube's
  own notifications can never be forwarded to another app.
* `StudyUpdatesWorker` (WorkManager, every 4 hours, needs internet) reads the newest 6 uploads of each followed channel (1 unit each,
  up to 8 channels) and posts a ReWire notification with the video picture (`Notifications.postNewStudyVideo`, channel "New study videos").
* A channel's first check is silent (it only remembers what already exists). New videos still pass `StudyRules.accept`.
* At most 4 notifications per check. Tapping one opens the Study tab on that video page. Switch: Study settings > Trusted channels.
* Cost: up to 8 units per check, 6 checks a day = 48 units a day per phone, taken from the same shared 10,000.
* New dependency: `androidx.work:work-runtime-ktx:2.9.1`. Not compiled here.

## v35 update: YouTube-style Study tab
- No "Study / Only videos made for learning" heading. Top bar = search icon (opens a YouTube-style search field), refresh, settings. Then chips (Videos, Shorts, subjects), then edge-to-edge video items with channel icon, title and channel.
- The API key is built in: the key field is gone from Study settings; the "New video notifications" switch is gone (notifications are always on in code, `StudyStore.alertsOn`).
- Tapping a video plays it at once in ReWire's player (`LectureActivity` preview mode). Under the video: title, channel, Follow and "Start Focus Mode". Start Focus Mode returns to the app and opens the start wizard with that video (`StudyStore.armFocusStart` / `takeFocusStart`).
- In the Focus-mode player the bar has "Change video": it opens the Study tab inside the app (session keeps running); tapping a video there swaps the lecture.
- Suggestions follow what is played: `StudyStore.noteWatched` counts channels; the top 3 fill the feed and the top 6 are trusted like followed channels.

## v36: search suggestions
- Opening search shows YouTube's search page: history (last 10 searches, each removable) when the box is empty; suggestions while typing (YouTube's free suggestion service, no key, no daily-limit cost). Suggestions with distraction words are dropped (`StudyRules.parseSuggestions`).
- After a search, the top bar shows the searched text; tap it to edit, X to clear.

## v37: bell, channel logos, channel page
- Bell icon in the Study top bar (a dot shows when something is unread). It lists the new videos of followed channels that the background check found (`StudyStore.inbox`, kept even if the phone's notification is off or was swiped away); tap one to play it; "Clear" empties it.
- Channel logos: real round pictures from the channels.list call (1 unit per 50 channels, remembered in `StudyStore.avatars`); the first letter shows until the picture arrives.
- Tap a channel's logo or name under a video: channel page with logo, name, handle, subscribers, video count, Follow / Following, and Videos / Shorts tabs (the channel's own uploads, 1 unit per page, Load more).

## v38: upload time
- Every video shows when it was uploaded ("2 days ago", "3 weeks ago" ...) next to the channel name: home, search, channel page, bell and the player's details. Shorts show it under the title. Uses the `publishedAt` that videos.list already returns (no extra YouTube calls). Old saved lists are dropped once so times show at once.

## Part 1: core bug fixes (video loading, images, channel page, errors) — see STUDY_FIXES_PART1.md
- Missing video information is filled (title, picture, description); a damaged saved entry no longer throws the whole saved list away.
- Pictures: broken / missing addresses show a placeholder (a logo shows its first letter), failed pictures are not retried for 5 minutes, the same picture is downloaded once, the disk cache is trimmed (80 MB -> 50 MB).
- Channel page: description, parallel loading, no blank profile for videos without a channel, first page kept 10 minutes, list scroll position kept when coming back.
- Errors name their source (YouTube API / Direct YouTube / Web search); a used-up API limit is never reported as "no internet" and an unreadable page is never reported as a used-up limit.
- No automatic source switching was added or changed (the fallback chain that already existed is untouched).
