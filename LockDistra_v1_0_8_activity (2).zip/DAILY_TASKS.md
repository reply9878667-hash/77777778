# Daily Task Planner (Home screen)

STATUS: written, NOT compiled, NOT run on a device (no Gradle / Android SDK / Kotlin compiler in the authoring environment).

## What it does
- Home > card "Daily Tasks" (above Focus Profile). "+ Add Task" opens a one-line text dialog. No limit on tasks.
- Long-press a task = select (short vibration). Tap another task = add/remove it. Several can be selected.
- Selection bar: "N selected", Today, Tomorrow, X (clear). Back also clears. Tags can be changed again the same way.
- Headings: Today Tasks, Tomorrow Tasks. New tasks wait under "Unassigned" until tagged.
- Checkbox on the right of every task; done = strike-through + muted text. Done mark is saved.
- New local day: unfinished Tomorrow tasks -> Today; Tomorrow is emptied; finished Tomorrow tasks are not moved to Today
  (they leave Tomorrow, keep their done mark, and show under Unassigned).
  Checked on app start, on resume, at midnight while open, and on date / time / time-zone change broadcasts.
  Clock or time zone moved BACK: nothing moves, the day marker just follows the clock.

## Files
new: `data/DailyTasks.kt` (rules), `data/TaskStore.kt` (saving, prefs file "daily_tasks"), `ui/screens/DailyTaskPlanner.kt`,
     `test/.../data/DailyTasksTest.kt`, this file
changed: `ui/screens/DashboardScreen.kt` (3 lines: the planner call). Nothing else.
Not touched: Focus Mode, Focus Profile, App Blocking, Pomodoro, FocusApp.kt, AppViewModel.kt, manifest (VIBRATE already declared).
