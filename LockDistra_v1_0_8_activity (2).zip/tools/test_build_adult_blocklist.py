import json, hashlib, os, subprocess, sys, tempfile, unittest
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_adult_blocklist as b


class ParseTests(unittest.TestCase):
    def test_formats(self):
        for raw in ["example.com", "0.0.0.0 example.com", "127.0.0.1\texample.com # c", "||example.com^",
                    "address=/example.com/0.0.0.0", "*.example.com", "WWW.Example.COM"]:
            self.assertEqual(b.parse_line(raw), "example.com", raw)

    def test_rejects(self):
        for raw in ["# c", "! c", "", "localhost", "127.0.0.1 localhost", "192.168.0.1", "not a domain",
                    "bad_domain.com", "example.com/path", "-bad.com", "<html>"]:
            self.assertIsNone(b.parse_line(raw), raw)


class BuildTests(unittest.TestCase):
    def run_tool(self, lines, extra=()):
        d = tempfile.mkdtemp()
        src = os.path.join(d, "src.txt")
        open(src, "w").write("\n".join(lines) + "\n")
        out = os.path.join(d, "out")
        r = subprocess.run([sys.executable, os.path.join(HERE, "build_adult_blocklist.py"), "--no-default",
                            "--file", src, "--name", "T", "--license", "L", "--out", out, *extra],
                           capture_output=True, text=True)
        return r, out

    def test_build_output_is_sorted_unique_hashed(self):
        lines = [f"site{i}.com" for i in range(300)] + ["x.site1.com", "SITE2.com", "reddit.com", "u.tumblr.com", "# c"]
        r, out = self.run_tool(lines)
        self.assertEqual(r.returncode, 0, r.stderr)
        body = open(os.path.join(out, "adult_domains.txt"), "rb").read()
        got = body.decode().split("\n")[:-1]
        self.assertEqual(got, sorted(set(got), key=lambda s: s.encode()))
        self.assertEqual(len(got), 300)                      # subdomain, protected and duplicate entries are gone
        self.assertNotIn("reddit.com", got)
        m = json.load(open(os.path.join(out, "manifest.json")))
        self.assertEqual(m["count"], 300)
        self.assertEqual(m["sha256"], hashlib.sha256(body).hexdigest())
        self.assertEqual(m["sources"][0]["name"], "T")

    def test_refuses_garbage_and_tiny(self):
        r, _ = self.run_tool(["<div>%d</div>" % i for i in range(200)] + [f"s{i}.com" for i in range(20)])
        self.assertNotEqual(r.returncode, 0)
        r, _ = self.run_tool([f"s{i}.com" for i in range(10)])
        self.assertNotEqual(r.returncode, 0)

    def test_max_cap(self):
        r, out = self.run_tool([f"site{i}.com" for i in range(300)], ["--max", "100"])
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertEqual(json.load(open(os.path.join(out, "manifest.json")))["count"], 100)

    def test_bundled_asset_is_consistent(self):
        d = os.path.join(HERE, "..", "app", "src", "main", "assets", "adult_blocklist")
        body = open(os.path.join(d, "adult_domains.txt"), "rb").read()
        m = json.load(open(os.path.join(d, "manifest.json")))
        lines = body.decode().split("\n")[:-1]
        self.assertEqual(len(lines), m["count"])
        self.assertEqual(hashlib.sha256(body).hexdigest(), m["sha256"])
        self.assertEqual(lines, sorted(set(lines), key=lambda s: s.encode()))
        for l in lines:
            self.assertEqual(b.parse_line(l), l)
            self.assertFalse(b.is_protected(l))


if __name__ == "__main__":
    unittest.main()
