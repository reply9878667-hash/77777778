#!/usr/bin/env python3
"""
Builds ReWire's adult-domain database from public blocklists.

Output (in --out, default app/src/main/assets/adult_blocklist/):
  adult_domains.txt  sorted (byte order), unique, validated domains, one per line
  manifest.json      version, count, sha256, per-source attribution (shown in the app)

Use it two ways:
  * once before a release, to refresh the list bundled in the APK
  * from CI (see tools/adult-blocklist.yml) to publish a manifest + list the app can download

Sources are public lists; check each licence before shipping. Nothing is invented: every
output domain appears in at least one downloaded source, and the script prints per-source counts.

  python3 tools/build_adult_blocklist.py                       # download the default sources
  python3 tools/build_adult_blocklist.py --max 200000          # cap the size (keeps the shortest names first)
  python3 tools/build_adult_blocklist.py --file path/to/list.txt --name "My list" --license "MIT" --homepage https://...
  python3 tools/build_adult_blocklist.py --list-url https://raw.githubusercontent.com/OWNER/REPO/main/adult_domains.txt
"""
import argparse, datetime, hashlib, json, os, re, sys, urllib.request

# Same never-block list and rules as AdultBlocklist.kt. Keep the two in step.
NEVER_BLOCK = {
    "google.com", "youtube.com", "youtu.be", "bing.com", "duckduckgo.com", "yahoo.com",
    "wikipedia.org", "wikimedia.org", "reddit.com", "x.com", "twitter.com", "facebook.com",
    "instagram.com", "tumblr.com", "blogspot.com", "wordpress.com", "medium.com", "github.com",
    "microsoft.com", "apple.com", "amazon.com", "cloudflare.com", "archive.org", "pinterest.com",
    "telegram.org", "t.me", "discord.com", "discord.gg", "snapchat.com", "tiktok.com",
    "whatsapp.com", "netflix.com", "twitch.tv", "imgur.com", "giphy.com", "gstatic.com",
    "googleapis.com", "googleusercontent.com", "anthropic.com", "claude.ai",
    "free.fr", "over-blog.com", "canalblog.com", "wixsite.com", "weebly.com", "pages.dev",
    "github.io", "netlify.app", "vercel.app", "herokuapp.com", "fc2.com", "livejournal.com",
}

# Default public sources (domain-per-line or hosts format). Verify licences before you ship.
DEFAULT_SOURCES = [
    {
        "name": "The Block List Project - Porn",
        "homepage": "https://github.com/blocklistproject/Lists",
        "license": "Unlicense / MIT (as stated by the project)",
        "url": "https://raw.githubusercontent.com/blocklistproject/Lists/master/alt-version/porn-nl.txt",
    },
]

LABEL = re.compile(r"^[a-z0-9-]{1,63}$")
IP4 = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


def valid_host(h: str) -> bool:
    if not h or len(h) > 253:
        return False
    labels = h.split(".")
    if len(labels) < 2:
        return False
    for l in labels:
        if not LABEL.match(l) or l[0] == "-" or l[-1] == "-":
            return False
    tld = labels[-1]
    return tld.startswith("xn--") or (len(tld) >= 2 and tld.isalpha())


def parse_line(raw: str):
    s = raw.strip()
    if not s or s[0] in "#![/":
        return None
    i = s.find(" #")
    if i >= 0:
        s = s[:i].strip()
    if s.startswith("||"):
        s = s[2:]
        m = re.search(r"[\^/$]", s)
        if m:
            s = s[: m.start()]
    elif s.startswith(("address=/", "server=/")):
        s = s.split("/", 2)[1]
    else:
        parts = s.split()
        if len(parts) >= 2 and (parts[0] in ("::", "::1") or IP4.match(parts[0])):
            s = parts[1]
        elif len(parts) == 1:
            s = parts[0]
        else:
            return None
    s = s.lower()
    if s.startswith("*."):
        s = s[2:]
    s = s.lstrip(".").rstrip(".")
    if any(c in s for c in "*|^/:@ "):
        return None
    if s.startswith("www."):
        s = s[4:]
    try:
        s = s.encode("idna").decode("ascii") if any(ord(c) > 127 for c in s) else s
    except Exception:
        return None
    return s if valid_host(s) else None


def candidates(h):
    out = [h]
    while True:
        d = h.find(".")
        if d < 0:
            break
        p = h[d + 1:]
        if "." not in p:
            break
        out.append(p)
        h = p
    return out


def is_protected(h):
    return any(c in NEVER_BLOCK for c in candidates(h))


def read_source(src, timeout=120):
    if "file" in src:
        with open(src["file"], "r", encoding="utf-8", errors="replace") as f:
            return f.read().splitlines()
    req = urllib.request.Request(src["url"], headers={"User-Agent": "ReWire-blocklist-builder/1"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace").splitlines()


def build(sources, max_entries=None):
    per_source = []
    all_domains = set()
    for src in sources:
        lines = read_source(src)
        data = ok = 0
        mine = set()
        for line in lines:
            t = line.strip()
            if not t or t[0] in "#![":
                continue
            data += 1
            d = parse_line(line)
            if d is None:
                continue
            ok += 1
            if is_protected(d):
                continue
            mine.add(d)
        if data == 0 or ok / data < 0.90:
            raise SystemExit(f"refusing source {src.get('name')}: only {ok}/{data} lines were valid domains")
        per_source.append((src, len(mine)))
        all_domains |= mine
    # Drop entries already covered by a listed parent (a parent blocks its subdomains).
    kept = [d for d in all_domains if not any(c in all_domains for c in candidates(d)[1:])]
    if max_entries and len(kept) > max_entries:
        # Fewest labels, then shortest, first: registrable-looking domains give the most coverage per byte.
        kept.sort(key=lambda d: (d.count("."), len(d), d))
        kept = kept[:max_entries]
    kept.sort(key=lambda d: d.encode("ascii"))
    return kept, per_source


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="app/src/main/assets/adult_blocklist")
    ap.add_argument("--max", type=int, default=None, help="cap the number of entries")
    ap.add_argument("--file", action="append", default=[], help="local source file (repeatable)")
    ap.add_argument("--name", action="append", default=[])
    ap.add_argument("--license", action="append", default=[])
    ap.add_argument("--homepage", action="append", default=[])
    ap.add_argument("--no-default", action="store_true", help="do not download the default sources")
    ap.add_argument("--list-url", default="", help="public https URL the finished adult_domains.txt will be served from (for in-app updates)")
    ap.add_argument("--version", type=int, default=None, help="list version (default: today as yyyymmdd)")
    a = ap.parse_args()

    sources = [] if a.no_default else list(DEFAULT_SOURCES)
    for i, f in enumerate(a.file):
        sources.append({
            "file": f,
            "name": a.name[i] if i < len(a.name) else os.path.basename(f),
            "license": a.license[i] if i < len(a.license) else "see source",
            "homepage": a.homepage[i] if i < len(a.homepage) else "",
        })
    if not sources:
        raise SystemExit("no sources")

    today = datetime.date.today()
    domains, per_source = build(sources, a.max)
    if len(domains) < 50:
        raise SystemExit(f"only {len(domains)} domains; refusing to write a list that small")

    os.makedirs(a.out, exist_ok=True)
    body = ("\n".join(domains) + "\n").encode("ascii")
    with open(os.path.join(a.out, "adult_domains.txt"), "wb") as f:
        f.write(body)
    manifest = {
        "format": 1,
        "version": a.version or int(today.strftime("%Y%m%d")),
        "built_at": today.isoformat(),
        "count": len(domains),
        "sha256": hashlib.sha256(body).hexdigest(),
        "list_url": a.list_url,
        "sources": [
            {"name": s["name"], "homepage": s.get("homepage", ""), "license": s.get("license", ""),
             "retrieved": today.isoformat(), "entries": n}
            for s, n in per_source
        ],
    }
    with open(os.path.join(a.out, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=2)
        f.write("\n")
    print(f"wrote {len(domains)} domains, {len(body)/1024:.0f} KiB, sha256 {manifest['sha256'][:12]}...")
    for s, n in per_source:
        print(f"  {s['name']}: {n} usable entries")


if __name__ == "__main__":
    main()
