# Task 4 – Final testing, bug fixing, optimization and release preparation (v2.3.0, versionCode 24)

## Read this first: what could and could not be checked
This review was done on the source only. The sandbox has **no Android SDK, no Gradle and no Kotlin compiler**, so the
app was **not compiled, not run, and the Kotlin unit tests were not executed**. Nothing below claims otherwise.

| Check | Result |
|---|---|
| Worker (Cloudflare) tests, `node --test test/worker.test.mjs` | **12 / 12 pass** (actually run) |
| Every `com.focusmode.app.*` import resolves to a declaration (117 Kotlin files) | **0 unresolved** (script) |
| Manifest components exist as classes; `@style/@xml/@mipmap/@drawable/@string/@color` and every `R.*` reference exist | **all found** |
| Brace / parenthesis balance of every file edited in this task | balanced |
| Gradle sync, compile, `testDebugUnitTest`, `assembleDebug`, `assembleRelease` | **NOT RUN – needs Android Studio / SDK** |
| Anything on a phone or emulator (screens, rotation, keyboard, animation, back button, services) | **NOT RUN – needs a device** |
| Live Firebase (sign-up, login, Google, reset mail, rules, push) | **NOT RUN – needs the live project** |
| Signed release build | **NOT DONE – no keystore was provided; nothing was invented** |

## Bugs found and fixed
| # | Problem | Fix | File |
|---|---|---|---|
| 1 | **Back on the Log in screen opened Sign up** instead of leaving the app, even when Log in was the screen the flow opened on (logged-out user, expired session). Contradicted the Task 3 rule "Back leaves the app"; in the Settings flow it also needed two presses to close. | Back now moves only towards the screen the flow opened on: Forgot -> Log in; Log in <-> Sign up only when the other one is the start; on the opening screen Back closes the flow (when the host allows it) or leaves the app. | `ui/auth/AuthFlow.kt` |
| 2 | Onboarding draft was written to disk **on every keystroke** (name field) – a whole preferences file rewrite each time. | Draft save is debounced (350 ms). A write that is not due yet is cancelled when the flow closes, so a stale draft can never reappear after "Continue". | `ui/onboarding/OnboardingFlow.kt` |
| 3 | Starting the foreground service could throw (Android refuses a foreground promotion) and **crash** `FocusController.start` / `FocusService.onStartCommand`. | Both are guarded. The session is already saved and blocking runs in the accessibility service, so nothing is lost; the alarm / next start retry. | `service/FocusController.kt`, `service/FocusService.kt` |
| 4 | Onboarding answers (they contain the person's **name** and goals) lived in the device-protected storage that is readable before the first unlock, unlike the login and the profile. | Moved to the normal private storage; existing data is moved over once (`moveSharedPreferencesFrom`). Only UI code uses this store, never a boot-time service. | `data/OnboardingStore.kt` |
| 5 | Release prep | `versionCode 23 -> 24`, `versionName 2.2.0 -> 2.3.0`. | `app/build.gradle.kts` |

## Files modified
`app/build.gradle.kts`, `app/src/main/java/com/focusmode/app/ui/auth/AuthFlow.kt`,
`.../ui/onboarding/OnboardingFlow.kt`, `.../data/OnboardingStore.kt`, `.../service/FocusController.kt`,
`.../service/FocusService.kt`. New: this file.

## Reviewed and found correct (no change)
* **Router** (`AppEntry` / `AppEntryRules`): new user, existing user, logged-out user, "I already have an account", second
  account on one phone, expired session. Home is not composed while logged out.
* **Auth**: validation, one-action-at-a-time guard, Firebase error mapping, Google linking vs. existing-account sign-in,
  password reset (unknown email not revealed), session restore / revalidate (offline never logs out), logout.
* **Profile / onboarding persistence**: offline-first with a dirty flag, server wins for onboarding (create-once),
  records only shown under their own uid, answers handed to exactly one account.
* **Database rules**: `users/$uid` readable and writable only by that uid; onboarding create-once; request / pairing
  rules tie every write to `auth.uid`; no wildcard read anywhere. Client photo limit (100 000) is below the rule (120 000).
* **Secrets**: no password, token or credential is stored or logged (no `Log.*` / `println` anywhere); `allowBackup=false`;
  cleartext traffic off; login and profile are in credential-encrypted storage.
* **Performance**: accessibility handler is already filtered by package and throttled (500 ms); no `runBlocking`, no
  `GlobalScope`, only 5 guarded `!!`.
* **Keyboard / scrolling**: account, profile and onboarding screens use `imePadding` / safe-drawing padding and scroll.

## Remaining items (need your environment)
1. **First compile.** Tasks 1-3 were also written without a compiler. Run `./gradlew testDebugUnitTest assembleDebug` and fix
   any compile error before anything else.
2. **Firebase**: Email/Password + Google + Anonymous sign-in on; publish `firebase/database.rules.json`; add the app's
   SHA-1 / SHA-256 for Google sign-in; `googleWebClientId` is empty in the supplied `firebase.properties`, so **Google
   sign-in says "isn't set up" until it is filled**; `workerUrl` is empty, so there is no FCM push (the trusted phone
   falls back to its background listener).
3. `firebase.properties` is included as supplied (needed for your build; git-ignored). It holds Firebase *web* identifiers,
   not passwords, but do not publish the zip publicly.
4. **Play Store policy** (cannot be solved in code): Accessibility API declaration, `FOREGROUND_SERVICE_SPECIAL_USE`
   declaration, `PACKAGE_USAGE_STATS`. Uninstall protection is not allowed on Play: build with `-PplayBuild=true`.
5. R8/minify is off (`isMinifyEnabled=false`) and release lint is off. Left unchanged on purpose: turning R8 on without a
   device test risks breaking Firebase / services. Try it later with the existing `proguard-rules.pro`.
6. Manual tests: run the 13-point list in `INTEGRATION_TASK3.md`, plus: (a) logged-out launch -> Log in -> press Back ->
   app leaves; (b) Settings -> Account -> Log in -> Back -> closes; (c) type a long name in question 1, swipe the app away
   after a second -> name is still there; (d) update over an old install -> onboarding state kept.

## Build and release
```
# debug (needs Android Studio / SDK 35, JDK 17)
./gradlew testDebugUnitTest assembleDebug

# release - needs YOUR key (never commit it):
keytool -genkeypair -v -keystore signing/focusmode-release.jks -alias focusmode -keyalg RSA -keysize 2048 -validity 10000
# keystore.properties (next to settings.gradle.kts):
#   storePassword=...   keyAlias=focusmode   keyPassword=...
./gradlew assembleRelease -PplayBuild=true      # APK
./gradlew bundleRelease   -PplayBuild=true      # AAB for Google Play
```
Without the key files the release APK is built **unsigned** and the build prints a warning; it cannot be installed.
Keep the same key for every later update.
