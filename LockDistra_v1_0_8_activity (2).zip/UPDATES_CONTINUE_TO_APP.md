# "Continue to <app>" on the block screen

When a Short, a blocked section (Reels, Search ...), a Shorts/Reels daily limit, a blocked website or an adult
site is found INSIDE an allowed app (YouTube, Chrome, Instagram ...), the block screen now shows
**Continue to <app>** as the main button. "Go to home screen" / "Back to focus" stays as the second button.

What it does: closes the block screen and stays in the app. For a short while the accessibility service closes
that same blocked content with Back (max 4 times, 650 ms apart, within 8 s), so the app is left on an allowed
screen. If Back cannot get away from it, the block screen comes back (blocked content is never let through).

Not offered for whole-app blocks (focus block of the app, app daily limit, Bedtime, Settings, protection).

Files: BlockActivity.kt (button, canContinue), service/AppBlockerService.kt (continueInApp, handledByContinue),
test BlockContinueTest.kt.
Note: for a website in a browser, Back returns to the previous page; if the blocked page was the first page of
the tab, Back can leave the browser. Please try on a real phone (Chrome / YouTube).
