# Onboarding – Part 2C: mascot moods and reactions

Same mascot as Part 1 (`FocusBuddy`), now expressive on all seven questions. Questions, options, answers and
navigation are unchanged. No new libraries, assets or colours (everything is drawn in the one Canvas).

## Files
| File | Change |
|---|---|
| `data/OnboardingReactions.kt` | NEW. `BuddyMood` enum + `OnboardingReactions.moodFor(question, answers)` and `signature(...)` (when to react). Plain Kotlin, JVM tested. |
| `ui/onboarding/BuddyLook.kt` | NEW. What each mood looks like, as numbers (`BuddyLook`), one line per mood. Tune a mood here. |
| `ui/onboarding/FocusBuddy.kt` | EDITED. Two new optional parameters `mood` and `reactionTick` (defaults = Part 1 mascot). New face/arm expressions, one-off reactions, random fidgets. |
| `ui/onboarding/QuestionsScreen.kt` | EDITED, small: computes the mood and a reaction tick, passes both to the two `FocusBuddy` calls. |
| `test/.../OnboardingReactionsTest.kt` | NEW. Mood per question, Q4 answer mapping, reaction triggers. |
| Welcome screen, flow, questions, theme | NOT changed. |

## Mood per question
| Q | Mood | What you see |
|---|---|---|
| 1 | Friendly -> Happy once a name is typed | warm smile + hello wave; then grin, squinting happy eyes, waving, sparkles, small hops |
| 2 | Interested | head tilted and leaning in, one brow up, wide eyes watching the options |
| 3 | Concerned | hand on chin, worried brows, small frown, sweat drop |
| 4 | Thoughtful, then by answer | before an answer: hand on chin, eyes up, thought bubble. Under 4 h: Pleased. 6 h or more: Worried. 4-6 h / Not sure: stays Thoughtful |
| 5 | Encouraging | big smile, free arm pumps, gentle hops |
| 6 | Excited | open grin, both arms up, hopping, sparkles |
| 7 | Curious | tilted head, wide eyes, one brow higher, a question mark |

## How it stays natural
- Moods glide (springs); the face moves first, the body about 0.1 s later.
- A mood starts with a burst of energy (wave / raised arm / sparkles) that calms down after about 2 s.
- Picking an option (or every 3rd letter of the name) triggers one reaction: a nod, a head tilt or a hop, chosen at random.
- On its own it also blinks (single / double), glances around, tilts its head the other way and flicks a brow at random times.
- Lightweight: one Canvas, one frame clock read only while drawing, no per-frame allocations, no new dependencies.
- Note: the random glances/tilts/brow flicks also run on the welcome screen (same mascot); everything else there is as in Part 1.

## For Part 2D (celebration)
- Add moods to `BuddyMood` (+ a line in `BuddyLook.kt`) or new poses; call `FocusBuddy(mood = ..., reactionTick = ...)`.
- Nothing here ends the flow; `OnboardingFlow` and the `onQuestionsFinished` hook are exactly as in Part 2A.

## Testing
1. Clear app data, launch, Let's Start.
2. Q1: mascot smiles and waves; type a name: it turns happy (grin, sparkles) and nods/tilts as you type; clear the name: back to friendly.
3. Q2: leans in, interested. Pick options: a small nod/tilt/hop each time.
4. Q3: hand on chin, worried brows, sweat drop; toggling options reacts.
5. Q4: thought bubble first; pick "Less than 2 hours" (pleased), "6-8 hours" (worried), "4-6 hours" (still thoughtful).
6. Q5 encouraging, Q6 excited (both arms up), Q7 curious (question mark).
7. Go Back/Next quickly: mood switches glide, no jumps. Rotate: it keeps working.
8. `./gradlew testDebugUnitTest`.
