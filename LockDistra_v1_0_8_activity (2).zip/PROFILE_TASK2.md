# Task 2 – User profile & onboarding data

Continues from `AUTH_TASK1.md`. Login/sign-up, the onboarding screens, Home and all blocking/unlock code are reused, not rebuilt.

> **Not compiled or run.** Written without an Android SDK / Gradle (same as Task 1). Open the project in Android Studio,
> sync, and expect to fix a small compile error or two. The pure logic has unit tests: `./gradlew testDebugUnitTest`.

## What was found in the project (and reused)
| Need | Existing piece reused |
|---|---|
| Auth (email sign-up/login, Google) | `data/auth/AuthRepository` (`session` = `AuthSession.SignedIn(user.uid, name, email, provider)`). Nothing duplicated. |
| Database | **Firebase Realtime Database** (already used by Online Approval, rules in `firebase/database.rules.json`) through `FirebaseGateway` (socket + HTTPS fallback, retries, error kinds). No new dependency. |
| Seven questions + answers | `data/OnboardingQuestions.kt` (`OnboardingAnswers`), saved on the phone by `OnboardingStore.saveAnswers` when the celebration screen's Continue is pressed. |
| Journey | Welcome → Q1..Q7 → Celebration → Account screen → Home (unchanged). |

## Architecture (new package `data/profile`, new package `ui/profile`)
```
data/profile/
  ProfileRepository.kt  ONLY entry point: state (StateFlow<ProfileState>), updateProfile(), refresh()
  ProfileRemote.kt      users/{uid} reads/writes through FirebaseGateway; checks the Firebase login IS that uid first
  ProfileStore.kt       phone copy, one record per uid (+ "not yet on server" flags)
  ProfileModels.kt      UserProfile, ProfileOnboarding, states, ProfileRules, ProfileMerge (pure, unit tested)
  ProfilePhotos.kt      gallery picture -> 256x256 JPEG -> Base64
ui/profile/
  ProfileScreen.kt      avatar, name, email, account info, the 7 answers, Edit profile, loading/offline/error banners
  EditProfileScreen.kt  name, photo or preset avatar, read-only email
  ProfileAvatar.kt      photo / preset avatar / initials
```

## Database structure (Realtime Database)
```
users/{uid}/profile      displayName, email, provider (EMAIL|GOOGLE), avatar? (preset id), createdAt, updatedAt
users/{uid}/onboarding   name, goal, distractions ("a,b,c"), phoneTime, sessionLength, dailyGoal,
                         dailyGoalMinutes (only when dailyGoal = "custom"), source (optional), completedAt
users/{uid}/photo        Base64 JPEG string (own node so a name edit doesn't re-upload it)
```
Answers are stored as **option ids** (e.g. `study_better`, `min_45`), not display text. A missing optional answer is simply absent.

## Security rules (`firebase/database.rules.json`, new `users` block)
* Read: only `auth.uid === $uid`. There is no read on `users` itself, so nobody can list other users.
* Write: only `auth.uid === $uid`, per child (`profile`, `onboarding`, `photo`); no write at `users/{uid}` level.
* `onboarding` is **create-once** (`!data.exists()`): it can never be overwritten or duplicated, even by the owner.
* `createdAt` is immutable; all fields are type/length/regex validated; unknown fields are rejected (`$other`).
* The app additionally checks, before every server call, that Firebase is signed in as the uid being written.

## How onboarding answers are tied to the logged-in user
1. Onboarding runs before an account exists; `OnboardingStore` keeps the answers on the phone (survives closing the app) and tags them *unclaimed*.
2. After sign-up / login, `ProfileRepository` sees a new uid. If the phone has no record for it, it creates one from the login (name, email, provider) and moves the unclaimed answers into **that uid's record**, saves it, and only then marks the answers *claimed by that uid*. They can never be given to a second account.
3. First sync: the server is read first. If the account already has answers there (login on another phone) the **server's win** and this phone's are dropped; otherwise they are uploaded once to `users/{uid}/onboarding`.
4. Skipping the account screen keeps the answers unclaimed; they move into the first account created later (Settings → Log in or create account).
5. If sign-up happens offline-after-the-fact or the upload fails, the record is flagged and re-sent automatically (app start, back online, profile screen opens, Retry).

Other consistency rules: one record per uid (idempotent PUTs, no appends); a fresh phone record has `updatedAt = 0` so it can never overwrite an existing server profile; for edits, newer `updatedAt` wins.

## Custom daily goal (small change inside the existing onboarding)
"Set my own goal" previously only recorded the choice. It now shows a "Minutes per day" field (10–960) under the options; Next stays disabled until the number is valid. Stored next to the choice and saved as `dailyGoalMinutes`. Nothing else in the questions changed.

## Files
**New (10):** `data/profile/` ProfileRepository, ProfileRemote, ProfileStore, ProfileModels, ProfilePhotos; `ui/profile/` ProfileScreen, EditProfileScreen, ProfileAvatar; test `data/profile/ProfileRulesTest.kt`; `PROFILE_TASK2.md`.

**Modified (12 files):**
| File | Change |
|---|---|
| `firebase/database.rules.json` | + `users` block |
| `data/online/FirebaseGateway.kt` | + generic `readNode` / `setNode` (same transport as the rest) |
| `data/OnboardingQuestions.kt` | + custom-minutes answer, `dailyGoalMinutes`, `isEmpty`, `canContinue` checks the number |
| `ui/onboarding/QuestionsScreen.kt` | + minutes field under Q6 when "Set my own goal" is chosen |
| `data/OnboardingStore.kt` | + `unclaimedAnswers()` / `markClaimed(uid)` |
| `data/auth/AuthRepository.kt`, `FirebaseAuthService.kt` | + `applyProfileName` / `updateDisplayName` (keeps Firebase name, Settings and trusted-phone name in step) |
| `ui/AppViewModel.kt` | + `Screen.Profile`, `val profile` (starts the profile system) |
| `ui/FocusApp.kt` | Home's profile button opens the profile screen when logged in (name dialog as before when not); Profile route |
| `ui/screens/SettingsScreen.kt`, `ui/online/OnlineScreens.kt` | "View profile" button in Settings → Account |
| `app/src/test/.../OnboardingQuestionsTest.kt` | + 2 tests |

Home screen layout, login/sign-up, the questions' text/order, blocking and unlock code are untouched.

## Required setup (nothing is done for you)
1. Tasks 1's setup must already work (Email/Password enabled, `firebase.properties` filled, Anonymous sign-in on).
2. **Publish the rules:** Firebase console → Realtime Database → Rules → paste the full contents of `firebase/database.rules.json` → Publish. Without this, profile saving shows "The server refused to save your profile…" and everything stays on the phone.
3. Realtime Database must exist and `databaseUrl` in `firebase.properties` must point to it (already required by Online Approval).
4. Nothing else: no new permission, no new Gradle dependency, no storage bucket. The gallery picker is Android's Photo Picker (no permission).

## How to test (fresh start: clear app data)
1. **Creation + answers saved:** finish onboarding (choose "Set my own goal", type 95; skip question 7) → sign up. Open Home → profile button (or Settings → Account → View profile). Name, email, "Signed in with", and all answers show; daily goal reads "1 h 35 min"; last row "Skipped". Firebase console → Realtime Database → `users/<uid>` has `profile`, `onboarding` (no `source`), no `photo`.
2. **Association:** console: the node key equals the uid on the Authentication → Users page for that email.
3. **Editing:** Edit profile → change name, pick an avatar → Save → "Profile saved.", console `profile.displayName/avatar/updatedAt` change, Settings → Account shows the new name. Choose a photo → Save → `photo` appears. Remove photo → Save → node disappears. Empty/1-letter name → message, nothing saved.
4. **Persistence:** swipe the app away, reopen: profile appears immediately (no spinner flash of empty data). Log out → log in again with the same account: same name/avatar/photo/answers come back from the server.
5. **Offline:** airplane mode → Edit name → Save → "Saved on this phone. It will sync when you're back online." Profile shows the "offline" banner and "Saved on this phone, not synced yet". Turn data on: syncs by itself (or tap Try again); banner disappears, console updated.
6. **Second phone / second account:** log in to the same account elsewhere: the server's answers and profile are shown (not that phone's own onboarding). Log in as a different account: sees only its own data; the first account's answers are never reused.
7. **Rules (console → Rules Playground):** simulate a *read* of `/users/<uidA>` authenticated as `<uidB>` → denied; a second *write* to `/users/<uidA>/onboarding` as `<uidA>` → denied; read as `<uidA>` → allowed.
8. **Skip path:** first launch → Skip for now → later Settings → Log in or create account → the saved answers appear in the new account's profile.
9. **Custom goal field:** Q6 → "Set my own goal": Next disabled until 10–960; typing letters is ignored; rotate: text stays.

## Notes / limits (honest)
* Email change, password change, account deletion and email verification are not part of this task (the email is read-only).
* The photo is a 256 px JPEG kept in the database (≈15–40 KB). If you later want large photos, move to Firebase Storage; only `ProfilePhotos` and `ProfileRemote.writePhoto/fetch` change.
* Logging out removes the phone's copy of that profile unless it still has unsent changes (those stay, tied to that uid, and are sent next time that account logs in).
* A trusted-phone pairing keeps the existing rule (log in/out refused while connected); profile code does not change identity.
