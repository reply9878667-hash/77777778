# Home feed upload time + LockDistra name check

- **Home feed time:** lists saved by older builds had no upload time (the saved copy is shown first, so it looked like the fix did
  nothing). Cache keys were bumped (`feed3:` -> `feed4:` for the Home pool, `n1:` -> `n2:` for page-data searches), so Home refills
  with videos that carry their upload time. Nothing else changed.
- **Name audit (whole app):** user-visible "Re Arena" used as the APP's name is now "LockDistra": Study header, notification
  sub-text (3 places), notification channel names "Messages from LockDistra" / "LockDistra unlock requests" (an existing channel is
  renamed too). `app_name`, accessibility / admin texts already said LockDistra.
- **Left on purpose:** "Powered by Re Arena · By Prince Yadav" and the splash "By Re Arena" (company credit); internal identifiers
  (`ReWire` popup bridge used by the admin panel, `rewire_*` saved-data names, Cloudflare `rewire-push`, `rewire-debug.jks`) because
  renaming them would break saved data, the admin popups or the worker.
