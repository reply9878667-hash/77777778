# Focus timer tied to the lecture + "Back to Focus"

A Focus session that has a lecture now counts time only while the lecture really plays on screen.
* Lecture paused, buffering (slow network), stuck, or the person left the player (Home, another app, screen off, app swiped away):
  the timer stands still. `LectureTimerGuard` (called about every second by the blocking service, and every 0.3 s by the open player)
  moves the session's end / start / next reminder / next check-in forward by the time that passed (`FocusStore.shiftSession`).
  Blocking itself keeps running the whole time.
* The player page tells the app once a second whether the video is really playing (state PLAYING; the normal page: not paused, not ended,
  enough data). No message for 5 s = not playing. Picture-in-picture counts as playing.
* The person was in the player and stayed away 4 s: one "Back to Focus" notification (own channel, heads-up). Tapping it opens the
  lecture at the saved time and it plays on. It is removed when the player is back.
* The status notification shows "Timer paused / Play your lecture to continue" instead of the countdown while the timer stands still.
* Not applied: Pomodoro sessions (own rounds), and a lecture that was watched to its end in a session without "turn off after the lecture"
  (the timer then runs normally). With "turn off after the lecture" the lecture end still ends Focus Mode (see LECTURE_SEEK_GUARD.md).
* The session key used by `ensureLectureOpen` ignores the stood-still time, so the lecture is not re-opened by itself when you leave.

Files: `data/LectureTimerRules.kt` (new, tested), `service/LectureTimerGuard.kt` (new), `data/FocusStore.kt`, `data/LectureLockStore.kt`,
`service/Notifications.kt`, `service/AppBlockerService.kt`, `LectureActivity.kt`, `ui/lecture/LecturePlayerHtml.kt`, `test/.../LectureTimerRulesTest.kt`.
Not compiled and not run on a device.
Check: pause the video -> timer stops, press play -> it runs; turn Wi-Fi off mid-lecture -> timer stops; press Home -> timer stops,
"Back to Focus" arrives after ~4 s, tap it -> lecture plays and the timer runs; status notification shows "Timer paused" meanwhile.
