# Focus Profile, Part 1 (UI and basic storage)

Basic structure only. No blocking settings, and the blocking system is untouched.

## Behaviour
- Home: a "Focus Profile" card under the Focus ring shows the profile in use ("Not set up yet" if none).
- Starting Focus Mode with no saved profile shows a small warning: **Set Up Focus Profile** or **Continue without** (the session is never blocked from starting).
- Max two profiles, Profile #1 and Profile #2. One screen creates, edits, deletes and selects them.
- Title is "Create Focus Profile" (empty slot) or "Edit Focus Profile" (saved slot).
- The screen opens with a centre-outward scale + fade animation and closes the reverse way (Back or the arrow).
- First saved profile is selected automatically; "Use this profile" switches; deleting the selected one moves selection to the other, or none.

## Files
- new `data/FocusProfileStore.kt` (model, pure `FocusProfileRules`, store in its own `focus_profiles` prefs file, same pattern as BedtimeStore)
- new `ui/screens/FocusProfileScreen.kt`
- new test `FocusProfileRulesTest.kt`
- changed: `AppViewModel.kt` (store + 3 functions), `DashboardScreen.kt` (card, 2 params), `FocusApp.kt` (overlay, warning dialog, `beginSession`)

Not compiled or run: this environment has no Android SDK. Build and run the unit tests in Android Studio first.
