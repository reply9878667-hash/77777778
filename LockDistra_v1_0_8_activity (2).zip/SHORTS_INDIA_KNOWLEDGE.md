# Shorts: India only + knowledge creators

* Shorts search no longer limited to the Education category; `StudyRules.acceptShort` accepts Education (27), Science & Technology (28),
  News & Politics (25) (explainer / GK / current-affairs creators). Long videos stay Education only. Adult + distraction words still block.
* Foreign Shorts: Shorts searches now look up the channel country first and drop other countries (before: kept, only moved last);
  a Short whose language is set to a non-Indian, non-English language is dropped. Videos now remember `audioLang`.
* Home refresh: +1 Shorts search (rotating GK / Current affairs / Science facts / History / Economy / Geography) = +100 YouTube units per refresh.
* Shorts tab chips: subject chips now search Shorts (before they jumped to Videos); knowledge chips added after them (slide sideways).
* Cache keys bumped (feed5 / q4) so old saved lists with foreign Shorts are rebuilt.
Not compiled. Tests: ShortsRulesTest.
