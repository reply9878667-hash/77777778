# Focus Profile, Part 2 (connect existing settings to profiles)

Each profile now keeps its own blocking and limit settings. Focus Mode activation and the blockers are NOT changed:
nothing reads a profile's settings yet.

## How it works
- In Create / Edit Focus Profile there is a "Blocking & limits" card (shows a summary such as "3 apps/games - 2 sites - 1 limit").
  Tapping it opens the **existing Blocking screen (`AppsScreen`)** on that profile's data. A new profile is saved first.
- One screen covers everything asked for: apps and games (app lists), YouTube Shorts, Reels / Status etc. (rows under their app),
  websites (Website Blocking card + each app's panel) and individual app limits (each app's panel -> existing limit editor).
- Saved per slot in the `focus_profiles` prefs file (keys end in `_1` / `_2`). Opening a profile loads what it saved.
- Deleting a profile deletes its settings. Renaming keeps them.
- Normal App Limits, global blocked apps, websites and content filters are never written by a profile.

## Left out of the profile view (phone-wide settings): Adult content, Bedtime, "Inside apps", educational channels, per-app Emergency access.

## Reuse
- `AppsScreen` / `AppRestrictionSheet`: two optional parameters (`profileName`, `showEmergency`); defaults keep today's behaviour.
- `FocusProfileBlockingScreen` is only an adapter: profile data in, profile storage out.
- Website rules logic moved from `WebsiteStore` into pure `WebsiteEdits` (same checks, same order); `WebsiteStore` calls it with its usual
  session-lock policy, profiles call it with no lock.

## Files
new: `ui/screens/FocusProfileBlockingScreen.kt`, test `FocusProfileSettingsTest.kt` (also covers `WebsiteEdits`)
changed: `data/FocusProfileStore.kt`, `data/WebsiteBlocking.kt`, `data/WebsiteStore.kt`, `ui/AppViewModel.kt`,
`ui/FocusApp.kt`, `ui/screens/FocusProfileScreen.kt`, `ui/screens/AppsScreen.kt`, `ui/screens/AppRestrictionSheet.kt`

Checked: the pure logic and its new tests (18) were compiled and run with a standalone Kotlin compiler.
Not compiled: the Compose / Android code (no Android SDK here). Build in Android Studio and run the unit tests first.
