// Shared types. The D1 / Worker runtime shapes are declared here (only the parts we use) so the project
// type-checks without extra packages; the real Cloudflare objects satisfy them structurally.

export interface D1PreparedStatementLike {
  bind(...values: unknown[]): D1PreparedStatementLike;
  first<T = unknown>(): Promise<T | null>;
  all<T = unknown>(): Promise<{ results: T[] }>;
  run(): Promise<{ meta: { changes?: number } }>;
}

export interface D1Like {
  prepare(query: string): D1PreparedStatementLike;
  batch(statements: D1PreparedStatementLike[]): Promise<Array<{ meta: { changes?: number } }>>;
}

export interface Env {
  /** D1 binding (wrangler.toml [[d1_databases]]). */
  DB: D1Like;
  /** Firebase project id. Not secret. */
  FIREBASE_PROJECT_ID: string;
  /** Realtime Database URL. Not secret. */
  FIREBASE_DATABASE_URL: string;
  /** Whole service-account JSON. SECRET: `wrangler secret put FCM_SERVICE_ACCOUNT_JSON`. */
  FCM_SERVICE_ACCOUNT_JSON: string;

  // Optional tuning (all have defaults, see config.ts).
  REQUEST_TTL_MS?: string;
  RATE_LIMIT_SEND_PER_MIN?: string;
  RATE_LIMIT_RECIPIENT_PER_MIN?: string;
  RATE_LIMIT_REGISTER_PER_MIN?: string;
  FCM_ATTEMPT_TIMEOUT_MS?: string;
  FCM_TOTAL_BUDGET_MS?: string;
  FCM_MAX_ATTEMPTS?: string;
  MAX_DEVICES_PER_USER?: string;
  RETENTION_DAYS?: string;
  VALIDATE_TOKEN_ON_REGISTER?: string;
}

/** Everything that touches the outside world, so tests can replace it. */
export interface Runtime {
  fetch: (input: string, init?: RequestInit) => Promise<Response>;
  now: () => number;
  sleep: (ms: number) => Promise<void>;
  random: () => number;
  uuid: () => string;
}

export interface ExecutionContextLike {
  waitUntil(promise: Promise<unknown>): void;
}

/** A failure of something we depend on (Google, Firebase, FCM). */
export class UpstreamError extends Error {
  /** transient = try again later; config = our credentials / setup are wrong. */
  kind: "transient" | "config";
  code: string;
  retryAfterMs?: number;
  constructor(kind: "transient" | "config", code: string, retryAfterMs?: number) {
    super(code);
    this.name = "UpstreamError";
    this.kind = kind;
    this.code = code;
    this.retryAfterMs = retryAfterMs;
  }
}
