// JSON responses and the one error type the routes throw.

export class ApiError extends Error {
  status: number;
  code: string;
  retryAfterS?: number;
  allow?: string;
  extra?: Record<string, unknown>;
  constructor(
    status: number,
    code: string,
    message: string,
    opts: { retryAfterS?: number; allow?: string; extra?: Record<string, unknown> } = {},
  ) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.retryAfterS = opts.retryAfterS;
    this.allow = opts.allow;
    this.extra = opts.extra;
  }
}

const BASE_HEADERS: Record<string, string> = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
  "x-content-type-options": "nosniff",
};

export function json(body: unknown, status: number, rid: string, extra: Record<string, string> = {}): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...BASE_HEADERS, "x-request-id": rid, ...extra },
  });
}

export function ok(body: Record<string, unknown>, rid: string, status = 200): Response {
  return json({ ok: true, ...body }, status, rid);
}

export function fail(e: ApiError, rid: string): Response {
  const headers: Record<string, string> = {};
  if (e.retryAfterS !== undefined) headers["retry-after"] = String(e.retryAfterS);
  if (e.allow) headers.allow = e.allow;
  if (e.status === 401) headers["www-authenticate"] = 'Bearer realm="rewire-push"';
  return json({ ok: false, error: { code: e.code, message: e.message, ...(e.extra ?? {}) }, request_id: rid }, e.status, rid, headers);
}
