// Structured logging that cannot leak secrets: only whitelisted scalar fields are written, long strings are
// cut, and anything that looks like a credential key is dropped. Never pass tokens or request bodies in.

const BLOCKED_KEYS = /token|secret|authorization|private|password|key|credential/i;

export interface Logger {
  info(msg: string, fields?: Record<string, unknown>): void;
  warn(msg: string, fields?: Record<string, unknown>): void;
  error(msg: string, fields?: Record<string, unknown>): void;
}

function clean(fields: Record<string, unknown> = {}): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(fields)) {
    if (BLOCKED_KEYS.test(k)) continue;
    if (typeof v === "string") out[k] = v.slice(0, 200);
    else if (typeof v === "number" || typeof v === "boolean" || v === null) out[k] = v;
  }
  return out;
}

export function createLogger(rid: string): Logger {
  const emit = (level: "info" | "warn" | "error", msg: string, fields?: Record<string, unknown>) => {
    const line = JSON.stringify({ level, msg, rid, ...clean(fields) });
    // Looked up at call time so tests can capture it.
    if (level === "error") console.error(line);
    else if (level === "warn") console.warn(line);
    else console.log(line);
  };
  return {
    info: (m, f) => emit("info", m, f),
    warn: (m, f) => emit("warn", m, f),
    error: (m, f) => emit("error", m, f),
  };
}
