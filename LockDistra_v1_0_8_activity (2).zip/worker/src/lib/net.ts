import type { Runtime } from "../types.ts";

/** fetch with a hard timeout. A timeout rejects with an AbortError, like any other network failure. */
export async function fetchWithTimeout(rt: Runtime, url: string, init: RequestInit, timeoutMs: number): Promise<Response> {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    return await rt.fetch(url, { ...init, signal: ctl.signal });
  } finally {
    clearTimeout(timer);
  }
}

/** "Retry-After: 3" -> 3000 ms (capped), anything else -> undefined. */
export function retryAfterMs(res: Response, capMs = 2_000): number | undefined {
  const raw = res.headers.get("retry-after");
  if (!raw) return undefined;
  const secs = Number(raw);
  if (!Number.isFinite(secs) || secs < 0) return undefined;
  return Math.min(capMs, Math.round(secs * 1000));
}
