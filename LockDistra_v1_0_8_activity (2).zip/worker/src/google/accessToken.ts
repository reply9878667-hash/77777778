// Google OAuth 2.0 access token for the Firebase service account (JWT-bearer flow).
// The service-account JSON only ever lives in the Worker secret FCM_SERVICE_ACCOUNT_JSON.
import type { Runtime } from "../types.ts";
import { UpstreamError } from "../types.ts";
import { bytesToB64url, pemToDer, utf8 } from "../lib/encoding.ts";
import { fetchWithTimeout } from "../lib/net.ts";

const SCOPES = [
  "https://www.googleapis.com/auth/firebase.database",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/firebase.messaging",
].join(" ");
const TOKEN_URL = "https://oauth2.googleapis.com/token";

export interface ServiceAccount {
  client_email: string;
  private_key: string;
}

export function parseServiceAccount(raw: string): ServiceAccount {
  try {
    const sa = JSON.parse(raw) as Partial<ServiceAccount>;
    if (typeof sa.client_email !== "string" || typeof sa.private_key !== "string" || !sa.private_key.includes("PRIVATE KEY")) {
      throw new Error("incomplete");
    }
    return { client_email: sa.client_email, private_key: sa.private_key };
  } catch {
    throw new UpstreamError("config", "service_account_invalid");
  }
}

export interface AccessTokens {
  /** A valid access token; reuses the cached one until two minutes before it expires. */
  get(sa: ServiceAccount): Promise<string>;
  /** Forget the cached token (call after a 401) so the next get() mints a new one. */
  invalidate(): void;
}

export function createAccessTokens(rt: Runtime): AccessTokens {
  let cached: { token: string; until: number } | null = null;
  let inflight: Promise<string> | null = null;
  let keyCache: { pem: string; key: CryptoKey } | null = null;

  async function signingKey(pem: string): Promise<CryptoKey> {
    if (keyCache && keyCache.pem === pem) return keyCache.key;
    try {
      const key = await crypto.subtle.importKey(
        "pkcs8",
        pemToDer(pem) as BufferSource,
        { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
        false,
        ["sign"],
      );
      keyCache = { pem, key };
      return key;
    } catch {
      throw new UpstreamError("config", "service_account_key_invalid");
    }
  }

  async function mint(sa: ServiceAccount): Promise<string> {
    const iat = Math.floor(rt.now() / 1000);
    const header = bytesToB64url(utf8(JSON.stringify({ alg: "RS256", typ: "JWT" })));
    const claim = bytesToB64url(
      utf8(JSON.stringify({ iss: sa.client_email, scope: SCOPES, aud: TOKEN_URL, iat, exp: iat + 3600 })),
    );
    const key = await signingKey(sa.private_key);
    const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, utf8(`${header}.${claim}`) as BufferSource);
    let res: Response;
    try {
      res = await fetchWithTimeout(
        rt,
        TOKEN_URL,
        {
          method: "POST",
          headers: { "content-type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({
            grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
            assertion: `${header}.${claim}.${bytesToB64url(sig)}`,
          }),
        },
        5_000,
      );
    } catch {
      throw new UpstreamError("transient", "oauth_unreachable");
    }
    if (res.status >= 500 || res.status === 429) throw new UpstreamError("transient", "oauth_http_" + res.status);
    if (!res.ok) throw new UpstreamError("config", "oauth_rejected"); // bad / revoked service account
    const body = (await res.json()) as { access_token?: string; expires_in?: number };
    if (!body.access_token) throw new UpstreamError("transient", "oauth_no_token");
    const ttl = Math.max(60, (body.expires_in ?? 3600) - 120);
    cached = { token: body.access_token, until: rt.now() + ttl * 1000 };
    return cached.token;
  }

  return {
    async get(sa) {
      if (cached && rt.now() < cached.until) return cached.token;
      if (!inflight) {
        inflight = mint(sa).finally(() => {
          inflight = null;
        });
      }
      return inflight;
    },
    invalidate() {
      cached = null;
    },
  };
}
