// Firebase Realtime Database over REST, as the service account (so database rules do not apply:
// every path is built only from values that were validated first).
import type { Env, Runtime } from "../types.ts";
import { UpstreamError } from "../types.ts";
import type { AccessTokens, ServiceAccount } from "./accessToken.ts";
import { fetchWithTimeout } from "../lib/net.ts";

export interface Rtdb {
  get<T = unknown>(path: string): Promise<T | null>;
  remove(path: string): Promise<void>;
}

export function createRtdb(rt: Runtime, env: Env, tokens: AccessTokens, sa: ServiceAccount): Rtdb {
  const base = env.FIREBASE_DATABASE_URL.replace(/\/$/, "");

  async function call(method: "GET" | "DELETE", path: string, retryOn401 = true): Promise<Response> {
    const token = await tokens.get(sa);
    let res: Response;
    try {
      res = await fetchWithTimeout(
        rt,
        `${base}/${path}.json?access_token=${encodeURIComponent(token)}`,
        { method },
        5_000,
      );
    } catch {
      throw new UpstreamError("transient", "rtdb_unreachable");
    }
    if (res.status === 401 && retryOn401) {
      tokens.invalidate();
      return call(method, path, false);
    }
    if (res.status === 401 || res.status === 403) throw new UpstreamError("config", "rtdb_denied");
    if (res.status === 429 || res.status >= 500) throw new UpstreamError("transient", "rtdb_http_" + res.status);
    if (!res.ok) throw new UpstreamError("transient", "rtdb_http_" + res.status);
    return res;
  }

  return {
    async get<T>(path: string): Promise<T | null> {
      const res = await call("GET", path);
      try {
        return (await res.json()) as T | null;
      } catch {
        throw new UpstreamError("transient", "rtdb_bad_json");
      }
    },
    async remove(path) {
      await call("DELETE", path);
    },
  };
}
