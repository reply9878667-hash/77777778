// Firebase Cloud Messaging HTTP v1: send one message to one device token, with a per-attempt timeout,
// retry with backoff for transient errors, one token refresh on 401, and exact classification of failures.
import type { Config } from "../config.ts";
import type { Runtime } from "../types.ts";
import { UpstreamError } from "../types.ts";
import type { AccessTokens, ServiceAccount } from "./accessToken.ts";
import { fetchWithTimeout, retryAfterMs } from "../lib/net.ts";

export type FcmKind =
  | "ok" // FCM accepted the message (this is NOT proof that the phone showed it)
  | "invalid_token" // UNREGISTERED / bad token: stop using it
  | "rejected" // FCM refused the message itself (our payload), the token may be fine
  | "transient" // FCM / network trouble, worth trying again later
  | "config"; // our credentials or FCM setup are wrong

export interface FcmResult {
  kind: FcmKind;
  code: string;
  attempts: number;
}

export interface FcmMessage {
  token: string;
  data: Record<string, string>;
  ttlSeconds: number;
}

export interface FcmClient {
  send(msg: FcmMessage, opts?: { validateOnly?: boolean; maxAttempts?: number }): Promise<FcmResult>;
}

interface FcmErrorBody {
  error?: { code?: number; message?: string; status?: string; details?: Array<{ errorCode?: string }> };
}

/** Maps one FCM HTTP answer to a kind. Exported for tests. */
export function classify(status: number, body: FcmErrorBody | null): { kind: FcmKind; code: string } {
  const err = body?.error;
  const detail = err?.details?.find((d) => typeof d.errorCode === "string")?.errorCode;
  const code = detail ?? err?.status ?? "HTTP_" + status;
  const message = err?.message ?? "";
  if (status === 404 || code === "UNREGISTERED") return { kind: "invalid_token", code: "UNREGISTERED" };
  if (code === "SENDER_ID_MISMATCH") return { kind: "invalid_token", code };
  if (status === 400) {
    // INVALID_ARGUMENT is also what a bad payload looks like: only drop the token if FCM says it is the token.
    if (/registration token/i.test(message)) return { kind: "invalid_token", code: "INVALID_TOKEN" };
    return { kind: "rejected", code };
  }
  if (status === 429 || code === "QUOTA_EXCEEDED") return { kind: "transient", code: "QUOTA_EXCEEDED" };
  if (status >= 500 || code === "UNAVAILABLE" || code === "INTERNAL") return { kind: "transient", code };
  if (status === 401 || status === 403) return { kind: "config", code };
  return { kind: "rejected", code };
}

export function createFcm(
  rt: Runtime,
  cfg: Config,
  projectId: string,
  tokens: AccessTokens,
  sa: ServiceAccount,
): FcmClient {
  const url = `https://fcm.googleapis.com/v1/projects/${encodeURIComponent(projectId)}/messages:send`;

  return {
    async send(msg, opts = {}) {
      const maxAttempts = opts.maxAttempts ?? cfg.fcmMaxAttempts;
      const started = rt.now();
      const deadline = started + cfg.fcmTotalBudgetMs;
      const body = JSON.stringify({
        validate_only: opts.validateOnly === true ? true : undefined,
        message: {
          token: msg.token,
          data: msg.data,
          // Data-only + HIGH priority: Android always calls onMessageReceived (foreground, background,
          // even when the app process was killed), so the app builds its own notification.
          android: { priority: "HIGH", ttl: `${Math.max(5, Math.floor(msg.ttlSeconds))}s` },
        },
      });

      let refreshed = false;
      let last: FcmResult = { kind: "transient", code: "NO_ATTEMPT", attempts: 0 };

      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        let waitHint: number | undefined;
        const remaining = deadline - rt.now();
        if (attempt > 1 && remaining < 500) break;

        try {
          const accessToken = await tokens.get(sa);
          const res = await fetchWithTimeout(
            rt,
            url,
            {
              method: "POST",
              headers: { authorization: `Bearer ${accessToken}`, "content-type": "application/json" },
              body,
            },
            Math.max(500, Math.min(cfg.fcmAttemptTimeoutMs, remaining)),
          );
          if (res.ok) return { kind: "ok", code: "OK", attempts: attempt };

          let parsed: FcmErrorBody | null = null;
          try {
            parsed = (await res.json()) as FcmErrorBody;
          } catch {
            parsed = null;
          }
          if (res.status === 401 && !refreshed) {
            // Expired / revoked access token: mint a new one and try again right away.
            refreshed = true;
            tokens.invalidate();
            last = { kind: "config", code: "UNAUTHENTICATED", attempts: attempt };
            continue;
          }
          const c = classify(res.status, parsed);
          last = { ...c, attempts: attempt };
          if (c.kind !== "transient") return last;
          waitHint = retryAfterMs(res);
        } catch (e) {
          if (e instanceof UpstreamError) {
            last = { kind: e.kind, code: e.code, attempts: attempt };
            if (e.kind === "config") return last;
          } else {
            last = { kind: "transient", code: "NETWORK_OR_TIMEOUT", attempts: attempt };
          }
        }

        if (attempt < maxAttempts) {
          const backoff = 250 * 2 ** (attempt - 1) * (0.5 + rt.random());
          const delay = Math.max(waitHint ?? 0, backoff);
          if (rt.now() + delay >= deadline) break;
          await rt.sleep(delay);
        }
      }
      return last;
    },
  };
}
