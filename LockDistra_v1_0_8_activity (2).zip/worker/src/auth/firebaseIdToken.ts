// Verifies a Firebase Auth ID token (the login every ReWire phone already has) following Firebase's
// "verify ID tokens" rules: RS256 signature against Google's published keys, audience, issuer, expiry.
import type { Runtime } from "../types.ts";
import { UpstreamError } from "../types.ts";
import { b64urlJson, b64urlToBytes, utf8 } from "../lib/encoding.ts";
import { fetchWithTimeout } from "../lib/net.ts";

const JWK_URL = "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com";

/** Firebase uids are 1..128 chars. We only accept the safe subset so a uid can never alter a database path. */
export const SAFE_ID = /^[A-Za-z0-9_-]{1,128}$/;

export interface Verifier {
  verify(token: string, projectId: string): Promise<{ uid: string; claims: Record<string, unknown> }>;
}

export class AuthError extends Error {
  constructor(reason: string) {
    super(reason);
    this.name = "AuthError";
  }
}

export function createVerifier(rt: Runtime): Verifier {
  let cache: { keys: JsonWebKey[]; until: number } | null = null;
  let inflight: Promise<JsonWebKey[]> | null = null;

  async function keys(forceFresh: boolean): Promise<JsonWebKey[]> {
    const now = rt.now();
    if (!forceFresh && cache && now < cache.until) return cache.keys;
    if (inflight) return inflight;
    inflight = (async () => {
      let res: Response;
      try {
        // Google's public keys change rarely: let Cloudflare's edge cache serve them (up to 1 h) so a fresh
        // Worker instance does not download them again.
        res = await fetchWithTimeout(rt, JWK_URL, { cf: { cacheTtl: 3600, cacheEverything: true } } as unknown as RequestInit, 5_000);
      } catch {
        throw new UpstreamError("transient", "jwk_unreachable");
      }
      if (!res.ok) throw new UpstreamError("transient", "jwk_http_" + res.status);
      const body = (await res.json()) as { keys?: JsonWebKey[] };
      if (!Array.isArray(body.keys) || body.keys.length === 0) throw new UpstreamError("transient", "jwk_empty");
      const maxAge = /max-age=(\d+)/.exec(res.headers.get("cache-control") ?? "");
      const ttl = maxAge ? Math.min(Number(maxAge[1]), 86_400) * 1000 : 3_600_000;
      cache = { keys: body.keys, until: rt.now() + ttl };
      return cache.keys;
    })().finally(() => {
      inflight = null;
    });
    return inflight;
  }

  return {
    async verify(token, projectId) {
      const parts = String(token || "").split(".");
      if (parts.length !== 3 || token.length > 4096) throw new AuthError("malformed");
      let header: Record<string, unknown>;
      let payload: Record<string, unknown>;
      try {
        header = b64urlJson(parts[0]);
        payload = b64urlJson(parts[1]);
      } catch {
        throw new AuthError("malformed");
      }
      if (header.alg !== "RS256" || typeof header.kid !== "string") throw new AuthError("bad_header");

      const now = Math.floor(rt.now() / 1000);
      if (payload.aud !== projectId) throw new AuthError("bad_audience");
      if (payload.iss !== `https://securetoken.google.com/${projectId}`) throw new AuthError("bad_issuer");
      const sub = payload.sub;
      if (typeof sub !== "string" || !SAFE_ID.test(sub)) throw new AuthError("bad_subject");
      if (typeof payload.exp !== "number" || !(payload.exp > now)) throw new AuthError("expired");
      if (typeof payload.iat !== "number" || payload.iat > now + 60) throw new AuthError("issued_in_future");
      if (typeof payload.auth_time === "number" && payload.auth_time > now + 60) throw new AuthError("bad_auth_time");

      let list = await keys(false);
      let jwk = list.find((k) => (k as { kid?: string }).kid === header.kid);
      if (!jwk) {
        list = await keys(true); // Google rotates keys
        jwk = list.find((k) => (k as { kid?: string }).kid === header.kid);
      }
      if (!jwk) throw new AuthError("unknown_key");

      let valid = false;
      try {
        const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
        valid = await crypto.subtle.verify(
          "RSASSA-PKCS1-v1_5",
          key,
          b64urlToBytes(parts[2]) as BufferSource,
          utf8(`${parts[0]}.${parts[1]}`) as BufferSource,
        );
      } catch {
        valid = false;
      }
      if (!valid) throw new AuthError("bad_signature");
      return { uid: sub, claims: payload };
    },
  };
}
