// ReWire push worker: routes unlock-approval notifications to the trusted phone through FCM HTTP v1.
// Responsibility: ONLY notification delivery. It decides nothing about unlocking, limits or blocking.
import { AuthError, createVerifier } from "./auth/firebaseIdToken.ts";
import { loadConfig, missingConfig } from "./config.ts";
import { purgeDevices } from "./db/devices.ts";
import { purgeNotifications } from "./db/notifications.ts";
import { purgeRateLimits } from "./db/rateLimit.ts";
import { createAccessTokens, parseServiceAccount } from "./google/accessToken.ts";
import { ApiError, fail, json, ok } from "./lib/http.ts";
import { createLogger } from "./lib/logger.ts";
import type { Ctx } from "./routes/context.ts";
import { handleRegister, handleUnregister } from "./routes/devices.ts";
import { handleSend } from "./routes/send.ts";
import type { Env, ExecutionContextLike, Runtime } from "./types.ts";
import { UpstreamError } from "./types.ts";

const MAX_BODY_BYTES = 4096;

type Handler = (c: Ctx, uid: string, body: unknown) => Promise<Response>;

const PROTECTED: Record<string, { method: string; handler: Handler }> = {
  "/api/v1/notifications/send": { method: "POST", handler: handleSend },
  "/notify": { method: "POST", handler: handleSend }, // path used by the app since v2.6
  "/api/v1/devices/register": { method: "POST", handler: handleRegister },
  "/api/v1/devices/unregister": { method: "POST", handler: handleUnregister },
};

export function defaultRuntime(): Runtime {
  return {
    // Arrow wrappers: calling fetch as a method of another object throws "Illegal invocation" in Workers.
    fetch: (input, init) => fetch(input, init),
    now: () => Date.now(),
    sleep: (ms) => new Promise((r) => setTimeout(r, ms)),
    random: () => Math.random(),
    uuid: () => crypto.randomUUID(),
  };
}

function toApiError(e: unknown, log: ReturnType<typeof createLogger>): ApiError {
  if (e instanceof ApiError) return e;
  if (e instanceof AuthError) return new ApiError(401, "unauthorized", "Missing or invalid login token.");
  if (e instanceof UpstreamError) {
    log.warn("upstream failure", { kind: e.kind, code: e.code });
    if (e.kind === "transient") return new ApiError(503, "upstream_unavailable", "A required service is temporarily unavailable. Retry.", { retryAfterS: 2 });
    return new ApiError(500, "server_misconfigured", "The server is not configured correctly.");
  }
  log.error("unexpected error", { name: e instanceof Error ? e.name : "unknown", message: e instanceof Error ? e.message : "" });
  return new ApiError(500, "internal_error", "Unexpected server error.");
}

export function createHandler(rt: Runtime = defaultRuntime()) {
  // Shared across requests inside one isolate: Google's signing keys and the service-account access token.
  const verifier = createVerifier(rt);
  const tokens = createAccessTokens(rt);

  async function fetchHandler(request: Request, env: Env): Promise<Response> {
    const rid = rt.uuid();
    const log = createLogger(rid);
    const { pathname } = new URL(request.url);

    try {
      if (pathname === "/health") {
        if (request.method !== "GET" && request.method !== "HEAD") {
          throw new ApiError(405, "method_not_allowed", "Use GET.", { allow: "GET" });
        }
        let dbOk = false;
        try {
          dbOk = (await env.DB.prepare("SELECT 1 AS one").first<{ one: number }>())?.one === 1;
        } catch {
          dbOk = false;
        }
        return dbOk ? ok({ status: "ok" }, rid) : json({ ok: false, status: "degraded" }, 503, rid);
      }

      const route = PROTECTED[pathname];
      if (!route) throw new ApiError(404, "not_found", "Unknown path.");
      if (request.method !== route.method) {
        throw new ApiError(405, "method_not_allowed", `Use ${route.method}.`, { allow: route.method });
      }

      const missing = missingConfig(env);
      if (missing) {
        log.error("worker not configured", { missing });
        throw new ApiError(500, "server_not_configured", "The server is not configured.");
      }

      // 1. Who is calling? (Firebase login token of the phone)
      const auth = request.headers.get("authorization") ?? "";
      const m = /^Bearer\s+(\S+)$/i.exec(auth);
      if (!m) throw new AuthError("no_token");
      const { uid } = await verifier.verify(m[1], env.FIREBASE_PROJECT_ID);

      // 2. Body: bounded size, JSON only.
      const declared = Number(request.headers.get("content-length") ?? "0");
      if (declared > MAX_BODY_BYTES) throw new ApiError(413, "payload_too_large", "Request body is too large.");
      const text = await request.text();
      if (text.length > MAX_BODY_BYTES) throw new ApiError(413, "payload_too_large", "Request body is too large.");
      let parsed: unknown;
      try {
        parsed = JSON.parse(text);
      } catch {
        throw new ApiError(400, "invalid_json", "Body must be valid JSON.");
      }

      const ctx: Ctx = { rt, env, cfg: loadConfig(env), log, rid, tokens, sa: parseServiceAccount(env.FCM_SERVICE_ACCOUNT_JSON) };
      return await route.handler(ctx, uid, parsed);
    } catch (e) {
      const err = toApiError(e, log);
      if (err.status >= 400 && err.status < 500 && err.status !== 404) log.info("request refused", { status: err.status, code: err.code });
      return fail(err, rid);
    }
  }

  /** Daily housekeeping (cron trigger): drops old delivery records, counters and dead device rows. */
  async function scheduledHandler(env: Env): Promise<void> {
    const log = createLogger("cron");
    const cfg = loadConfig(env);
    const now = rt.now();
    await purgeNotifications(env.DB, now, cfg.retentionDays);
    await purgeRateLimits(env.DB, now);
    await purgeDevices(env.DB, now);
    log.info("cleanup done");
  }

  return { fetch: fetchHandler, scheduled: scheduledHandler };
}

const handler = createHandler();

export default {
  fetch: (request: Request, env: Env, _ctx?: ExecutionContextLike) => handler.fetch(request, env),
  scheduled: (_event: unknown, env: Env, ctx?: ExecutionContextLike) => {
    const job = handler.scheduled(env);
    if (ctx) ctx.waitUntil(job);
    return job;
  },
};
