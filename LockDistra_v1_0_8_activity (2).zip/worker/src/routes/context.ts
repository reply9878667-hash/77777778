import type { Config } from "../config.ts";
import type { AccessTokens, ServiceAccount } from "../google/accessToken.ts";
import type { Logger } from "../lib/logger.ts";
import type { Env, Runtime } from "../types.ts";

/** What a route handler gets: everything already built and validated for this one request. */
export interface Ctx {
  rt: Runtime;
  env: Env;
  cfg: Config;
  log: Logger;
  rid: string;
  tokens: AccessTokens;
  sa: ServiceAccount;
}
