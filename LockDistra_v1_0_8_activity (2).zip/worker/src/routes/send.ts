// POST /api/v1/notifications/send  (alias: POST /notify, the path the app already uses)
//
// Who may notify whom is decided ONLY from the database, never from the caller:
//   sender    = the verified Firebase login (token "sub")
//   recipient = links/{sender}/approverUid  (the trusted phone this sender is paired with)
//   content   = unlockRequests/{sender}/{request_id}  (must exist, be "pending" and fresh)
//
// One more kind, request_type "checkin_missed" (Study Check-In): same sender / recipient rules, but there is no
// unlock request to read. The push carries a fixed "check-in missed" signal and nothing the caller wrote; the
// trusted phone builds the wording itself. (request_id still makes it send-once: a repeat is answered from the record.)
import { activeDevices, deactivateToken } from "../db/devices.ts";
import type { NotificationRow } from "../db/notifications.ts";
import { claimRequest, finishRequest, findRequest } from "../db/notifications.ts";
import { hit } from "../db/rateLimit.ts";
import { createFcm } from "../google/fcm.ts";
import { createRtdb } from "../google/rtdb.ts";
import { SAFE_ID } from "../auth/firebaseIdToken.ts";
import { ApiError, ok } from "../lib/http.ts";
import { parseSend } from "../validation.ts";
import type { Ctx } from "./context.ts";

const STALE_IN_PROGRESS_MS = 30_000;

/** A missed check-in alert is only useful for a short while. */
const CHECKIN_TTL_S = 300;
/** At most this many check-in alerts per sender in the window (an interval is never shorter than 2 minutes). */
const CHECKIN_MAX_PER_WINDOW = 6;
const CHECKIN_WINDOW_MS = 600_000;

interface LinkNode {
  approverUid?: unknown;
}
interface RequestNode {
  status?: unknown;
  createdAt?: unknown;
  kind?: unknown;
  appName?: unknown;
}

/**
 * The push carries data only, no secret. A "more time in one app" request also names the app so the
 * notification can say so; the trusted phone re-reads and verifies the request itself before showing Approve.
 * (type stays "unlock_request": ApproverMessagingService ignores any other value.)
 */
export function pushData(requestId: string, req: RequestNode | null): Record<string, string> {
  const data: Record<string, string> = { type: "unlock_request", requestId };
  if (req && req.kind === "app" && typeof req.appName === "string") {
    data.kind = "app";
    // eslint-disable-next-line no-control-regex
    data.appName = req.appName.replace(/[\u0000-\u001f\u007f|]/g, " ").trim().slice(0, 40);
  }
  return data;
}

/** Data-only push for a missed Study Check-In. Nothing from the caller is copied into it. */
export function checkinPushData(requestId: string): Record<string, string> {
  return { type: "checkin_missed", requestId };
}

interface Summary {
  status: string;
  targeted: number;
  submitted: number;
  invalidRemoved: number;
  failed: number;
}

function body(requestId: string, s: Summary, duplicate: boolean, extra: Record<string, unknown> = {}) {
  return {
    request_id: requestId,
    status: s.status, // accepted | submitted | no_device | failed
    duplicate,
    sent: s.status === "submitted", // true = FCM accepted the message (kept for the old app's response shape)
    delivery_confirmed: false, // FCM v1 never confirms that the phone showed the notification
    devices: { targeted: s.targeted, submitted: s.submitted, invalid_removed: s.invalidRemoved, failed: s.failed },
    ...extra,
  };
}

function fromRow(row: NotificationRow): Summary {
  return {
    status: row.status,
    targeted: row.devices_targeted,
    submitted: row.devices_submitted,
    invalidRemoved: 0,
    failed: Math.max(0, row.devices_targeted - row.devices_submitted),
  };
}

export async function handleSend(c: Ctx, uid: string, rawBody: unknown): Promise<Response> {
  const input = parseSend(rawBody);
  const db = c.env.DB;
  const now = c.rt.now();
  const requestId = input.requestId;

  if (input.senderUserId !== undefined && input.senderUserId !== uid) {
    throw new ApiError(403, "sender_mismatch", "sender_user_id does not match the signed-in user.");
  }

  const rl = await hit(db, `send:${uid}`, c.cfg.rateSendPerMin, 60_000, now);
  if (!rl.allowed) throw new ApiError(429, "rate_limited", "Too many requests. Try again shortly.", { retryAfterS: rl.retryAfterS });

  // Duplicate of something already pushed: answer with the earlier result, send nothing.
  const prior = await findRequest(db, uid, requestId);
  if (prior?.status === "submitted") return ok(body(requestId, fromRow(prior), true), c.rid);

  const rtdb = createRtdb(c.rt, c.env, c.tokens, c.sa);

  const link = await rtdb.get<LinkNode>(`links/${uid}`);
  const approverUid = typeof link?.approverUid === "string" && SAFE_ID.test(link.approverUid) ? link.approverUid : null;
  if (!approverUid) throw new ApiError(404, "no_trusted_phone", "This account has no trusted phone connected.");
  if (input.recipientUserId !== undefined && input.recipientUserId !== approverUid) {
    throw new ApiError(403, "recipient_not_authorized", "The sender is not allowed to notify that recipient.");
  }
  // Protects the trusted phone from being flooded, whoever is asking.
  const rr = await hit(db, `recv:${approverUid}`, c.cfg.rateRecipientPerMin, 60_000, now);
  if (!rr.allowed) throw new ApiError(429, "rate_limited", "Too many requests. Try again shortly.", { retryAfterS: rr.retryAfterS });

  const isCheckIn = input.type === "checkin_missed";
  let req: RequestNode | null = null;
  let ttlSeconds = CHECKIN_TTL_S;
  if (isCheckIn) {
    const ci = await hit(db, `checkin:${uid}`, CHECKIN_MAX_PER_WINDOW, CHECKIN_WINDOW_MS, now);
    if (!ci.allowed) throw new ApiError(429, "rate_limited", "Too many requests. Try again shortly.", { retryAfterS: ci.retryAfterS });
  } else {
    req = await rtdb.get<RequestNode>(`unlockRequests/${uid}/${requestId}`);
    if (!req || req.status !== "pending" || typeof req.createdAt !== "number") {
      throw new ApiError(409, "not_pending", "That request does not exist or is no longer pending.");
    }
    const age = now - req.createdAt;
    if (age > c.cfg.requestTtlMs || age < -10_000) throw new ApiError(409, "expired", "That request has expired.");
    ttlSeconds = Math.floor((c.cfg.requestTtlMs - Math.max(0, age)) / 1000);
  }
  const type = isCheckIn ? "checkin_missed" : req?.kind === "app" ? "app_time" : "unlock";

  const claim = await claimRequest(db, { sender: uid, recipient: approverUid, requestId, type, now, staleMs: STALE_IN_PROGRESS_MS });
  if (claim.kind === "duplicate") return ok(body(requestId, fromRow(claim.row), true), c.rid);
  if (claim.kind === "in_progress") {
    throw new ApiError(409, "in_progress", "This request is already being delivered.", { retryAfterS: 2 });
  }

  const fcm = createFcm(c.rt, c.cfg, c.env.FIREBASE_PROJECT_ID, c.tokens, c.sa);
  const summary: Summary = { status: "failed", targeted: 0, submitted: 0, invalidRemoved: 0, failed: 0 };
  let errorCode: string | null = null;
  let worst: "transient" | "config" | "rejected" | null = null;

  try {
    // Devices: D1 first (many per user). Phones that registered before the Worker existed live in the old
    // deviceTokens/{uid} node; they are used only while the user has no D1 device.
    type Target = { id: number | null; token: string };
    let targets: Target[] = (await activeDevices(db, approverUid)).map((d) => ({ id: d.id, token: d.fcm_token }));
    if (targets.length === 0) {
      const legacy = await rtdb.get<string>(`deviceTokens/${approverUid}`);
      if (typeof legacy === "string" && legacy.length >= 20) targets = [{ id: null, token: legacy }];
    }
    summary.targeted = targets.length;

    if (targets.length === 0) {
      summary.status = "no_device";
      errorCode = "no_registered_device";
    } else {
      const data = isCheckIn ? checkinPushData(requestId) : pushData(requestId, req);
      const results = await Promise.all(
        targets.map(async (t) => ({ t, r: await fcm.send({ token: t.token, data, ttlSeconds }) })),
      );
      for (const { t, r } of results) {
        if (r.kind === "ok") summary.submitted++;
        else if (r.kind === "invalid_token") {
          summary.invalidRemoved++;
          if (t.id !== null) await deactivateToken(db, t.id, t.token, r.code, c.rt.now());
          else await rtdb.remove(`deviceTokens/${approverUid}`).catch(() => undefined);
          c.log.info("fcm token deactivated", { reason: r.code });
        } else {
          summary.failed++;
          errorCode = r.code;
          const rank = { rejected: 1, transient: 2, config: 3 } as const;
          const kind = r.kind;
          if (worst === null || rank[kind] > rank[worst]) worst = kind;
          c.log.warn("fcm send failed", { kind: r.kind, code: r.code, attempts: r.attempts });
        }
      }
      if (summary.submitted > 0) summary.status = "submitted";
      else if (summary.failed > 0) summary.status = "failed";
      else {
        summary.status = "no_device";
        errorCode = "all_tokens_invalid";
      }
    }
  } catch (e) {
    await finishRequest(db, claim.id, { status: "failed", targeted: summary.targeted, submitted: summary.submitted, errorCode: "internal", now: c.rt.now() });
    throw e;
  }

  await finishRequest(db, claim.id, {
    status: summary.status as "submitted" | "no_device" | "failed",
    targeted: summary.targeted,
    submitted: summary.submitted,
    errorCode,
    now: c.rt.now(),
  });
  c.log.info("notification processed", { status: summary.status, targeted: summary.targeted, submitted: summary.submitted });

  if (summary.status === "submitted") return ok(body(requestId, summary, false), c.rid);
  if (summary.status === "no_device") {
    return ok(body(requestId, summary, false, { reason: errorCode }), c.rid, 202);
  }
  // Failed: nothing reached FCM. The same request_id may be sent again.
  if (worst === "transient") throw new ApiError(503, "fcm_unavailable", "The push service is temporarily unavailable. Retry.", { retryAfterS: 2 });
  if (worst === "config") throw new ApiError(502, "fcm_misconfigured", "The push service credentials are not accepted.");
  throw new ApiError(502, "fcm_rejected", "The push service rejected the message.");
}
