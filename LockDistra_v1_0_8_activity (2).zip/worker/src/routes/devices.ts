// POST /api/v1/devices/register and /api/v1/devices/unregister
// The owner is always the verified login (token "sub"). A user_id in the body is only compared, never used.
import { unregisterDevice, upsertDevice } from "../db/devices.ts";
import { hit } from "../db/rateLimit.ts";
import { createFcm } from "../google/fcm.ts";
import { createRtdb } from "../google/rtdb.ts";
import { ApiError, ok } from "../lib/http.ts";
import { parseRegister, parseUnregister } from "../validation.ts";
import type { Ctx } from "./context.ts";

async function limit(c: Ctx, uid: string): Promise<void> {
  const rl = await hit(c.env.DB, `dev:${uid}`, c.cfg.rateRegisterPerMin, 60_000, c.rt.now());
  if (!rl.allowed) throw new ApiError(429, "rate_limited", "Too many requests. Try again shortly.", { retryAfterS: rl.retryAfterS });
}

export async function handleRegister(c: Ctx, uid: string, rawBody: unknown): Promise<Response> {
  const input = parseRegister(rawBody);
  if (input.userId !== undefined && input.userId !== uid) {
    throw new ApiError(403, "user_mismatch", "You can only register devices for your own account.");
  }
  await limit(c, uid);

  if (c.cfg.validateTokenOnRegister) {
    // Dry run against FCM: proves the token is a real token of THIS Firebase project before we store it.
    const fcm = createFcm(c.rt, c.cfg, c.env.FIREBASE_PROJECT_ID, c.tokens, c.sa);
    const r = await fcm.send({ token: input.fcmToken, data: { type: "validate" }, ttlSeconds: 5 }, { validateOnly: true, maxAttempts: 2 });
    if (r.kind === "invalid_token") throw new ApiError(422, "invalid_fcm_token", "FCM does not accept this token.");
    if (r.kind !== "ok") c.log.warn("token validation skipped", { kind: r.kind, code: r.code }); // do not block login on FCM trouble
  }

  const res = await upsertDevice(c.env.DB, {
    userId: uid,
    deviceId: input.deviceId,
    token: input.fcmToken,
    platform: input.platform,
    now: c.rt.now(),
    maxDevices: c.cfg.maxDevicesPerUser,
  });
  c.log.info("device registered", { created: res.created, rotated: res.rotated });
  // The token is never echoed back.
  return ok({ device_id: input.deviceId, created: res.created, rotated: res.rotated }, c.rid);
}

export async function handleUnregister(c: Ctx, uid: string, rawBody: unknown): Promise<Response> {
  const input = parseUnregister(rawBody);
  if (input.userId !== undefined && input.userId !== uid) {
    throw new ApiError(403, "user_mismatch", "You can only remove your own devices.");
  }
  await limit(c, uid);

  const removed = await unregisterDevice(c.env.DB, uid, input.deviceId, c.rt.now());
  // Also clear the pre-Worker token node of this same user (never anyone else's).
  await createRtdb(c.rt, c.env, c.tokens, c.sa).remove(`deviceTokens/${uid}`).catch((e) => {
    c.log.warn("legacy token cleanup failed", { code: e instanceof Error ? e.message : "unknown" });
  });
  c.log.info("device unregistered", { removed });
  return ok({ device_id: input.deviceId, removed }, c.rid);
}
