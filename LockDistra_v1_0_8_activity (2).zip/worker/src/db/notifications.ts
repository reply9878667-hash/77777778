import type { D1Like } from "../types.ts";

export type NotificationStatus = "accepted" | "submitted" | "no_device" | "failed";

export interface NotificationRow {
  id: number;
  request_id: string;
  status: NotificationStatus;
  devices_targeted: number;
  devices_submitted: number;
  error_code: string | null;
  updated_at: number;
}

export type Claim =
  | { kind: "claimed"; id: number } // this call owns the delivery attempt
  | { kind: "duplicate"; row: NotificationRow } // already submitted: report the earlier result
  | { kind: "in_progress"; row: NotificationRow }; // another call is delivering right now

const COLS = "id, request_id, status, devices_targeted, devices_submitted, error_code, updated_at";

export async function findRequest(db: D1Like, sender: string, requestId: string): Promise<NotificationRow | null> {
  return db
    .prepare(`SELECT ${COLS} FROM notification_requests WHERE sender_user_id = ? AND request_id = ?`)
    .bind(sender, requestId)
    .first<NotificationRow>();
}

/**
 * Idempotency gate. Exactly one caller gets "claimed" for a (sender, request_id):
 *  - first call                                  -> claimed
 *  - earlier call reached FCM (submitted)        -> duplicate (nothing is sent again)
 *  - earlier call is still running (< staleMs)   -> in_progress
 *  - earlier call failed / had no device / died  -> claimed again (a retry is allowed), by compare-and-swap
 */
export async function claimRequest(
  db: D1Like,
  i: { sender: string; recipient: string; requestId: string; type: string; now: number; staleMs: number },
): Promise<Claim> {
  const ins = await db
    .prepare(
      `INSERT OR IGNORE INTO notification_requests
         (request_id, sender_user_id, recipient_user_id, request_type, status, attempts, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'accepted', 1, ?, ?)`,
    )
    .bind(i.requestId, i.sender, i.recipient, i.type, i.now, i.now)
    .run();

  const row = await findRequest(db, i.sender, i.requestId);
  if (!row) throw new Error("claim: row vanished");
  if ((ins.meta.changes ?? 0) > 0) return { kind: "claimed", id: row.id };

  if (row.status === "submitted") return { kind: "duplicate", row };
  const stale = row.status === "accepted" && i.now - row.updated_at >= i.staleMs;
  if (row.status === "failed" || row.status === "no_device" || stale) {
    const cas = await db
      .prepare(
        `UPDATE notification_requests
         SET status = 'accepted', attempts = attempts + 1, error_code = NULL, updated_at = ?
         WHERE id = ? AND status = ? AND updated_at = ?`,
      )
      .bind(i.now, row.id, row.status, row.updated_at)
      .run();
    if ((cas.meta.changes ?? 0) > 0) return { kind: "claimed", id: row.id };
    const again = await findRequest(db, i.sender, i.requestId);
    if (again?.status === "submitted") return { kind: "duplicate", row: again };
    return { kind: "in_progress", row: again ?? row };
  }
  return { kind: "in_progress", row };
}

export async function finishRequest(
  db: D1Like,
  id: number,
  r: { status: NotificationStatus; targeted: number; submitted: number; errorCode: string | null; now: number },
): Promise<void> {
  await db
    .prepare(
      `UPDATE notification_requests
       SET status = ?, devices_targeted = ?, devices_submitted = ?, error_code = ?, updated_at = ?,
           submitted_at = CASE WHEN ? = 'submitted' THEN ? ELSE submitted_at END
       WHERE id = ?`,
    )
    .bind(r.status, r.targeted, r.submitted, r.errorCode, r.now, r.status, r.now, id)
    .run();
}

export async function purgeNotifications(db: D1Like, now: number, retentionDays: number): Promise<void> {
  await db
    .prepare("DELETE FROM notification_requests WHERE created_at < ?")
    .bind(now - retentionDays * 24 * 3600_000)
    .run();
}
