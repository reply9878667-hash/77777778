import type { D1Like } from "../types.ts";

export interface DeviceRow {
  id: number;
  device_id: string;
  fcm_token: string;
}

export interface UpsertInput {
  userId: string;
  deviceId: string;
  token: string;
  platform: string;
  now: number;
  maxDevices: number;
}

/**
 * Registers or updates one device of one user.
 *  - same (user, device) with a new token  -> token rotation, the row is updated
 *  - the token already belongs to another row (phone moved to another account, or reinstall) -> that row is
 *    deactivated, so a token can never receive another user's notifications
 *  - more than maxDevices active devices -> the least recently updated ones are deactivated
 * All in one atomic batch.
 */
export async function upsertDevice(db: D1Like, i: UpsertInput): Promise<{ created: boolean; rotated: boolean }> {
  const existing = await db
    .prepare("SELECT fcm_token, is_active FROM devices WHERE user_id = ? AND device_id = ?")
    .bind(i.userId, i.deviceId)
    .first<{ fcm_token: string | null; is_active: number }>();

  await db.batch([
    db
      .prepare(
        `UPDATE devices SET is_active = 0, fcm_token = NULL, last_error = 'TOKEN_MOVED', updated_at = ?
         WHERE fcm_token = ? AND NOT (user_id = ? AND device_id = ?)`,
      )
      .bind(i.now, i.token, i.userId, i.deviceId),
    db
      .prepare(
        `INSERT INTO devices (user_id, device_id, fcm_token, platform, is_active, created_at, updated_at)
         VALUES (?, ?, ?, ?, 1, ?, ?)
         ON CONFLICT (user_id, device_id) DO UPDATE SET
           fcm_token = excluded.fcm_token, platform = excluded.platform, is_active = 1,
           last_error = NULL, updated_at = excluded.updated_at`,
      )
      .bind(i.userId, i.deviceId, i.token, i.platform, i.now, i.now),
    db
      .prepare(
        `UPDATE devices SET is_active = 0, fcm_token = NULL, last_error = 'DEVICE_LIMIT', updated_at = ?
         WHERE user_id = ? AND is_active = 1 AND id NOT IN (
           SELECT id FROM devices WHERE user_id = ? AND is_active = 1 ORDER BY updated_at DESC, id DESC LIMIT ?
         )`,
      )
      .bind(i.now, i.userId, i.userId, i.maxDevices),
  ]);

  return {
    created: existing === null,
    rotated: existing !== null && existing.fcm_token !== null && existing.fcm_token !== i.token,
  };
}

export async function activeDevices(db: D1Like, userId: string): Promise<DeviceRow[]> {
  const res = await db
    .prepare(
      `SELECT id, device_id, fcm_token FROM devices
       WHERE user_id = ? AND is_active = 1 AND fcm_token IS NOT NULL ORDER BY updated_at DESC, id DESC`,
    )
    .bind(userId)
    .all<DeviceRow>();
  return res.results;
}

/** Marks a token dead. Matches on the token too, so a device that just rotated to a new token is untouched. */
export async function deactivateToken(db: D1Like, id: number, token: string, reason: string, now: number): Promise<void> {
  await db
    .prepare(
      `UPDATE devices SET is_active = 0, fcm_token = NULL, last_error = ?, updated_at = ?
       WHERE id = ? AND fcm_token = ?`,
    )
    .bind(reason.slice(0, 40), now, id, token)
    .run();
}

/** Only the owner's own device can be removed: user_id comes from the verified login, never from the body. */
export async function unregisterDevice(db: D1Like, userId: string, deviceId: string, now: number): Promise<boolean> {
  const res = await db
    .prepare(
      `UPDATE devices SET is_active = 0, fcm_token = NULL, last_error = 'UNREGISTERED_BY_USER', updated_at = ?
       WHERE user_id = ? AND device_id = ? AND is_active = 1`,
    )
    .bind(now, userId, deviceId)
    .run();
  return (res.meta.changes ?? 0) > 0;
}

export async function purgeDevices(db: D1Like, now: number): Promise<void> {
  await db.prepare("DELETE FROM devices WHERE is_active = 0 AND updated_at < ?").bind(now - 30 * 24 * 3600_000).run();
}
