import type { D1Like } from "../types.ts";

/** Counts one hit in a fixed window. allowed=false once the window's limit is passed. */
export async function hit(
  db: D1Like,
  bucket: string,
  limit: number,
  windowMs: number,
  now: number,
): Promise<{ allowed: boolean; retryAfterS: number }> {
  const windowStart = Math.floor(now / windowMs) * windowMs;
  const row = await db
    .prepare(
      `INSERT INTO rate_limits (bucket, window_start, count) VALUES (?, ?, 1)
       ON CONFLICT (bucket, window_start) DO UPDATE SET count = count + 1
       RETURNING count`,
    )
    .bind(bucket, windowStart)
    .first<{ count: number }>();
  const count = row?.count ?? 1;
  return { allowed: count <= limit, retryAfterS: Math.max(1, Math.ceil((windowStart + windowMs - now) / 1000)) };
}

export async function purgeRateLimits(db: D1Like, now: number): Promise<void> {
  await db.prepare("DELETE FROM rate_limits WHERE window_start < ?").bind(now - 24 * 3600_000).run();
}
