import type { Env } from "./types.ts";

export interface Config {
  /** How long an unlock request stays valid. Must match ApprovalProtocol.REQUEST_TTL_MS in the app. */
  requestTtlMs: number;
  rateSendPerMin: number;
  rateRecipientPerMin: number;
  rateRegisterPerMin: number;
  fcmAttemptTimeoutMs: number;
  fcmTotalBudgetMs: number;
  fcmMaxAttempts: number;
  maxDevicesPerUser: number;
  retentionDays: number;
  validateTokenOnRegister: boolean;
}

function int(raw: string | undefined, def: number, min: number, max: number): number {
  if (raw === undefined || raw === "") return def;
  const n = Number(raw);
  if (!Number.isInteger(n)) return def;
  return Math.min(max, Math.max(min, n));
}

export function loadConfig(env: Env): Config {
  return {
    requestTtlMs: int(env.REQUEST_TTL_MS, 120_000, 10_000, 600_000),
    rateSendPerMin: int(env.RATE_LIMIT_SEND_PER_MIN, 10, 1, 600),
    rateRecipientPerMin: int(env.RATE_LIMIT_RECIPIENT_PER_MIN, 20, 1, 600),
    rateRegisterPerMin: int(env.RATE_LIMIT_REGISTER_PER_MIN, 10, 1, 600),
    // The Android app waits 10 s for this Worker, so the whole FCM effort stays under that.
    fcmAttemptTimeoutMs: int(env.FCM_ATTEMPT_TIMEOUT_MS, 4_000, 500, 15_000),
    fcmTotalBudgetMs: int(env.FCM_TOTAL_BUDGET_MS, 8_000, 1_000, 25_000),
    fcmMaxAttempts: int(env.FCM_MAX_ATTEMPTS, 3, 1, 5),
    maxDevicesPerUser: int(env.MAX_DEVICES_PER_USER, 5, 1, 20),
    retentionDays: int(env.RETENTION_DAYS, 7, 1, 90),
    validateTokenOnRegister: (env.VALIDATE_TOKEN_ON_REGISTER ?? "true").toLowerCase() !== "false",
  };
}

/** True when everything the Worker needs to do its job is present. */
export function missingConfig(env: Env): string | null {
  if (!env.DB) return "DB";
  if (!env.FIREBASE_PROJECT_ID) return "FIREBASE_PROJECT_ID";
  if (!env.FIREBASE_DATABASE_URL || !env.FIREBASE_DATABASE_URL.startsWith("https://")) return "FIREBASE_DATABASE_URL";
  if (!env.FCM_SERVICE_ACCOUNT_JSON) return "FCM_SERVICE_ACCOUNT_JSON";
  return null;
}
