// Input validation. Every field is checked for type, format and length before it is used anywhere.
import { ApiError } from "./lib/http.ts";
import { SAFE_ID } from "./auth/firebaseIdToken.ts";

export const REQUEST_ID = /^[-_A-Za-z0-9]{10,40}$/;
export const DEVICE_ID = /^[-_A-Za-z0-9]{8,64}$/;
/** FCM registration tokens: letters, digits and - _ : . only. Real ones are ~140-200 chars. */
export const FCM_TOKEN = /^[-_:.A-Za-z0-9]{20,4096}$/;
export const PLATFORMS = ["android", "ios", "web"];
export const REQUEST_TYPES = ["unlock", "app_time", "checkin_missed"];

const bad = (message: string) => new ApiError(400, "invalid_request", message);

type Body = Record<string, unknown>;

export function asObject(v: unknown): Body {
  if (typeof v !== "object" || v === null || Array.isArray(v)) throw bad("Body must be a JSON object.");
  return v as Body;
}

function optString(b: Body, key: string, max: number, min = 1): string | undefined {
  const v = b[key];
  if (v === undefined || v === null) return undefined;
  if (typeof v !== "string" || v.length < min || v.length > max) throw bad(`${key} must be a string of ${min}-${max} characters.`);
  return v;
}

export interface SendInput {
  requestId: string;
  senderUserId?: string;
  recipientUserId?: string;
  /** Only "checkin_missed" changes what the Worker does; anything else is the original unlock flow. */
  type?: string;
}

/**
 * Accepts the documented snake_case fields and the app's original {"requestId": "..."}.
 * request_type, application_name, message and created_at are shape-checked but never used: what the
 * trusted phone is told comes from the request stored in the database, not from the caller.
 */
export function parseSend(body: unknown): SendInput {
  const b = asObject(body);
  const rid = b.request_id ?? b.requestId;
  if (typeof rid !== "string" || !REQUEST_ID.test(rid)) throw bad("request_id must be 10-40 characters: letters, digits, - or _.");

  const sender = optString(b, "sender_user_id", 128);
  const recipient = optString(b, "recipient_user_id", 128);
  for (const [name, v] of [["sender_user_id", sender], ["recipient_user_id", recipient]] as const) {
    if (v !== undefined && !SAFE_ID.test(v)) throw bad(`${name} has invalid characters.`);
  }
  const type = optString(b, "request_type", 20);
  if (type !== undefined && !REQUEST_TYPES.includes(type)) throw bad("request_type must be 'unlock', 'app_time' or 'checkin_missed'.");
  optString(b, "application_name", 100);
  optString(b, "message", 500);
  const created = b.created_at;
  if (created !== undefined && created !== null && (typeof created !== "number" || !Number.isFinite(created) || created < 0)) {
    throw bad("created_at must be a number (epoch milliseconds).");
  }
  return { requestId: rid, senderUserId: sender, recipientUserId: recipient, type };
}

export interface RegisterInput {
  deviceId: string;
  fcmToken: string;
  platform: string;
  userId?: string;
}

export function parseRegister(body: unknown): RegisterInput {
  const b = asObject(body);
  const deviceId = b.device_id;
  if (typeof deviceId !== "string" || !DEVICE_ID.test(deviceId)) throw bad("device_id must be 8-64 characters: letters, digits, - or _.");
  const token = b.fcm_token;
  if (typeof token !== "string" || !FCM_TOKEN.test(token)) throw bad("fcm_token is missing or malformed.");
  const platform = b.platform === undefined || b.platform === null ? "android" : b.platform;
  if (typeof platform !== "string" || !PLATFORMS.includes(platform)) throw bad("platform must be android, ios or web.");
  const userId = optString(b, "user_id", 128);
  if (userId !== undefined && !SAFE_ID.test(userId)) throw bad("user_id has invalid characters.");
  return { deviceId, fcmToken: token, platform, userId };
}

export function parseUnregister(body: unknown): { deviceId: string; userId?: string } {
  const b = asObject(body);
  const deviceId = b.device_id;
  if (typeof deviceId !== "string" || !DEVICE_ID.test(deviceId)) throw bad("device_id must be 8-64 characters: letters, digits, - or _.");
  const userId = optString(b, "user_id", 128);
  if (userId !== undefined && !SAFE_ID.test(userId)) throw bad("user_id has invalid characters.");
  return { deviceId, userId };
}
