-- ReWire push worker: initial schema (Cloudflare D1 / SQLite).

-- One row per registered phone. A user may have several (one row per device_id).
CREATE TABLE devices (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     TEXT    NOT NULL,                       -- Firebase uid, always taken from the verified login token
  device_id   TEXT    NOT NULL,                       -- stable per-install id chosen by the app
  fcm_token   TEXT    UNIQUE,                         -- NULL once unregistered / dead; a token belongs to one row only
  platform    TEXT    NOT NULL DEFAULT 'android' CHECK (platform IN ('android', 'ios', 'web')),
  is_active   INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
  last_error  TEXT,                                   -- why a token was deactivated (e.g. UNREGISTERED)
  created_at  INTEGER NOT NULL,                       -- epoch ms
  updated_at  INTEGER NOT NULL,
  UNIQUE (user_id, device_id),
  CHECK (is_active = 0 OR fcm_token IS NOT NULL)
);
CREATE INDEX idx_devices_user_active ON devices (user_id, is_active, updated_at DESC);

-- One row per notification request: the idempotency record and the delivery log.
-- status: accepted (Worker took it) -> submitted (FCM accepted >= 1 message)
--                                   -> no_device (nobody to send to) | failed (FCM / upstream error)
-- FCM can not confirm that a phone showed the notification, so there is no "delivered" status.
CREATE TABLE notification_requests (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id         TEXT    NOT NULL,
  sender_user_id     TEXT    NOT NULL,
  recipient_user_id  TEXT    NOT NULL,
  request_type       TEXT    NOT NULL CHECK (request_type IN ('unlock', 'app_time')),
  status             TEXT    NOT NULL CHECK (status IN ('accepted', 'submitted', 'no_device', 'failed')),
  attempts           INTEGER NOT NULL DEFAULT 1,
  devices_targeted   INTEGER NOT NULL DEFAULT 0,
  devices_submitted  INTEGER NOT NULL DEFAULT 0,
  error_code         TEXT,
  created_at         INTEGER NOT NULL,
  updated_at         INTEGER NOT NULL,
  submitted_at       INTEGER,                         -- when FCM accepted the message
  -- request ids are only unique per sender (they live under unlockRequests/{uid}/), so the pair is the key
  UNIQUE (sender_user_id, request_id)
);
CREATE INDEX idx_notification_requests_created ON notification_requests (created_at);

-- Fixed-window request counters for abuse protection.
CREATE TABLE rate_limits (
  bucket        TEXT    NOT NULL,
  window_start  INTEGER NOT NULL,
  count         INTEGER NOT NULL,
  PRIMARY KEY (bucket, window_start)
) WITHOUT ROWID;
