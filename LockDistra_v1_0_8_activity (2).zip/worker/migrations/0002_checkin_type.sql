-- Study Check-In: allow request_type 'checkin_missed' in the delivery log.
-- SQLite cannot change a CHECK constraint in place, so the table is rebuilt (same columns, same data).
-- Apply once: npm run db:migrate:remote   (and :local for wrangler dev)

CREATE TABLE notification_requests_new (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id         TEXT    NOT NULL,
  sender_user_id     TEXT    NOT NULL,
  recipient_user_id  TEXT    NOT NULL,
  request_type       TEXT    NOT NULL CHECK (request_type IN ('unlock', 'app_time', 'checkin_missed')),
  status             TEXT    NOT NULL CHECK (status IN ('accepted', 'submitted', 'no_device', 'failed')),
  attempts           INTEGER NOT NULL DEFAULT 1,
  devices_targeted   INTEGER NOT NULL DEFAULT 0,
  devices_submitted  INTEGER NOT NULL DEFAULT 0,
  error_code         TEXT,
  created_at         INTEGER NOT NULL,
  updated_at         INTEGER NOT NULL,
  submitted_at       INTEGER,
  UNIQUE (sender_user_id, request_id)
);

INSERT INTO notification_requests_new
  (id, request_id, sender_user_id, recipient_user_id, request_type, status, attempts,
   devices_targeted, devices_submitted, error_code, created_at, updated_at, submitted_at)
SELECT id, request_id, sender_user_id, recipient_user_id, request_type, status, attempts,
       devices_targeted, devices_submitted, error_code, created_at, updated_at, submitted_at
FROM notification_requests;

DROP TABLE notification_requests;
ALTER TABLE notification_requests_new RENAME TO notification_requests;
CREATE INDEX idx_notification_requests_created ON notification_requests (created_at);
