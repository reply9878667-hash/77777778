# ReWire push Worker

Cloudflare Worker that replaces the always-on listener on the trusted phone with an event-driven push:

```
locked phone (A)                 Worker                         Firebase                trusted phone (B)
  create request in RTDB
  POST /api/v1/notifications/send ──► verify A's login
   (Authorization: Bearer <A's        read links/A, request       ◄── Realtime Database
    Firebase ID token>)               find B's devices (D1)
                                      FCM HTTP v1 send  ─────────────► FCM ───────────────► push
                                                                                              ApproverMessagingService
                                                                                              opens Unlock requests
```

It does one job: deliver the notification. It decides nothing about unlocking, limits or blocking; B's app still
reads the request from the database and verifies its MAC before showing Approve.

> **Why there is no separate "backend key".** ReWire has no application server: every phone signs in to Firebase
> and the database is the source of truth. So the Worker authenticates the *caller's Firebase login token* and takes
> sender, recipient and content from the database. The caller cannot choose who gets notified.

## Layout

```
src/index.ts              router, auth, body limits, error mapping, cron cleanup
src/auth/                 Firebase ID-token verification
src/google/               service-account OAuth (accessToken), Realtime Database REST (rtdb), FCM v1 (fcm)
src/db/                   D1 access: devices, notification_requests (idempotency), rate_limits
src/routes/               send.ts, devices.ts
src/validation.ts         every input is type/format/length checked
migrations/0001_init.sql  D1 schema
test/                     40 tests (real SQLite + fake Google/Firebase/FCM)
```

No runtime dependencies. Dev tools: `wrangler`, `typescript`. Node >= 22.18 for the tests.

## Deploy (once)

```bash
cd worker
npm install

# 1. database
npx wrangler d1 create rewire-push          # copy the printed database_id into wrangler.toml
npx wrangler d1 migrations apply rewire-push --remote

# 2. the ONLY secret: Firebase console > Project settings > Service accounts > Generate new private key
npx wrangler secret put FCM_SERVICE_ACCOUNT_JSON     # paste the whole JSON, then Enter

# 3. ship it
npx wrangler deploy
```

Put the printed `https://focusmode-approval.<you>.workers.dev` into `firebase.properties` as `workerUrl` and rebuild
the app. Never paste the service-account JSON in chat, in the app, or in git.

Firebase console checklist: *Cloud Messaging API (V1)* enabled; an **Android app** `com.focusmode.app` registered and its
`1:...:android:...` id used as `appId` (a web app id cannot get an FCM token); Anonymous (and Email/Password) sign-in on.
If you deployed the previous Worker, deploy this one **before** shipping the new app build.
`/notify` still works, so old app builds keep working.

### Configuration

| Name | Kind | Default | Meaning |
|---|---|---|---|
| `FIREBASE_PROJECT_ID` | var | in wrangler.toml | project id |
| `FIREBASE_DATABASE_URL` | var | in wrangler.toml | Realtime Database URL |
| `FCM_SERVICE_ACCOUNT_JSON` | **secret** | none | service-account JSON |
| `DB` | D1 binding | none | `rewire-push` |
| `REQUEST_TTL_MS` | var | 120000 | must equal the app's request lifetime |
| `RATE_LIMIT_SEND_PER_MIN` | var | 10 | per sender |
| `RATE_LIMIT_RECIPIENT_PER_MIN` | var | 20 | per trusted phone, all senders together |
| `RATE_LIMIT_REGISTER_PER_MIN` | var | 10 | device register / unregister per user |
| `FCM_ATTEMPT_TIMEOUT_MS` / `FCM_TOTAL_BUDGET_MS` / `FCM_MAX_ATTEMPTS` | var | 4000 / 8000 / 3 | the app waits 10 s, so keep the budget under that |
| `MAX_DEVICES_PER_USER` | var | 5 | older devices are deactivated beyond this |
| `VALIDATE_TOKEN_ON_REGISTER` | var | true | FCM dry-run of a token before storing it |
| `RETENTION_DAYS` | var | 7 | delivery records kept (cron cleans daily) |

Also add a Cloudflare **WAF rate-limiting rule** on the Worker's hostname (for example 60 requests / minute / IP).
The built-in per-user limits cannot see unauthenticated floods.

## Local development and testing

```bash
npm test            # 40 tests: auth, authorization, idempotency, retries, token lifecycle, logs hygiene
npm run typecheck

cp .dev.vars.example .dev.vars    # real service-account JSON on one line
npm run db:migrate:local
npx wrangler dev                  # http://localhost:8787
```

Manual run against `wrangler dev` (or the deployed Worker). Get a real Firebase ID token for a test user:

```bash
API_KEY=<apiKey from firebase.properties>
ID_TOKEN=$(curl -s -X POST "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$API_KEY" \
  -H 'content-type: application/json' -d '{"returnSecureToken":true}' | jq -r .idToken)
W=http://localhost:8787

curl -s $W/health
curl -s -X POST $W/api/v1/devices/register -H "authorization: Bearer $ID_TOKEN" -H 'content-type: application/json' \
  -d '{"device_id":"0123456789abcdef0123456789abcdef","fcm_token":"<real FCM token>","platform":"android"}'
```

Sending needs a real pair (a `links/{uid}` entry and a pending `unlockRequests/{uid}/{id}`), which the app creates;
the easiest end-to-end test is the app itself: connect two phones, tap **Request to Unlock** on A.

## API

All paths except `/health` need `Authorization: Bearer <Firebase ID token>` and a JSON body (max 4 KB).
Errors always look like `{"ok":false,"error":{"code":"...","message":"..."},"request_id":"..."}`.
Every response has `x-request-id` (also in the logs) and `cache-control: no-store`.

### `GET /health`
`200 {"ok":true,"status":"ok"}`; `503 {"ok":false,"status":"degraded"}` if D1 is unreachable. No secrets, no versions.

### `POST /api/v1/notifications/send`  (alias `POST /notify`)

```json
{ "request_id": "-Nabcdefghijklmno1234",
  "sender_user_id": "uidA", "recipient_user_id": "uidB",
  "request_type": "unlock", "application_name": "Instagram", "message": "optional", "created_at": 1762171200000 }
```
Only `request_id` is required (the old `{"requestId": "..."}` works too). `sender_user_id` / `recipient_user_id`, if
present, are *compared* with what the database says and refused on mismatch. `request_type`, `application_name`,
`message`, `created_at` are validated but **ignored**: the pushed content comes from the stored request.

Success, FCM accepted the message:
```json
{ "ok": true, "request_id": "-Nabc...", "status": "submitted", "duplicate": false, "sent": true,
  "delivery_confirmed": false, "devices": { "targeted": 1, "submitted": 1, "invalid_removed": 0, "failed": 0 } }
```

| HTTP | `error.code` / status | Meaning | Caller should |
|---|---|---|---|
| 200 | `status: submitted` | FCM accepted it. `duplicate: true` if this id was already pushed (nothing sent again) | done |
| 202 | `status: no_device`, `reason` | trusted phone has no valid push token (`no_registered_device`, `all_tokens_invalid`) | rely on in-app listener; may retry later |
| 400 | `invalid_request`, `invalid_json` | bad input | fix |
| 401 | `unauthorized` | missing / invalid / expired login token | refresh token |
| 403 | `sender_mismatch`, `recipient_not_authorized` | ids do not match the database link | do not retry |
| 404 | `no_trusted_phone` | no trusted phone connected | do not retry |
| 409 | `not_pending`, `expired` | request missing, answered or older than 120 s | do not retry |
| 409 | `in_progress` | same id is being delivered right now | wait 2 s |
| 413 | `payload_too_large` | | |
| 429 | `rate_limited` (+ `Retry-After`) | | wait |
| 500 | `server_not_configured`, `server_misconfigured`, `internal_error` | missing secret / bad service account / bug | operator |
| 502 | `fcm_rejected`, `fcm_misconfigured` | FCM refused the message / credentials | operator |
| 503 | `fcm_unavailable`, `upstream_unavailable` (+ `Retry-After`) | FCM, Google or the database is down | retry with the **same** request_id |

Status meanings: `accepted` (Worker took it, internal), `submitted` (FCM accepted it for at least one device),
`no_device`, `failed`. **FCM never confirms that a phone displayed the notification**, so `delivery_confirmed` is always
`false`; the real confirmation is the trusted phone opening the request and answering it.

### `POST /api/v1/devices/register`
```json
{ "device_id": "0123456789abcdef0123456789abcdef", "fcm_token": "dX9...", "platform": "android" }
```
`200 {"ok":true,"device_id":"...","created":true,"rotated":false}`. The owner is the login token's uid; a `user_id`
in the body is only compared (`403 user_mismatch`). Calling again with a new token for the same `device_id` rotates it.
The token is checked with an FCM dry run (`422 invalid_fcm_token` if FCM rejects it) and is never echoed back.
A token that appears under another account is taken away from the old one.

### `POST /api/v1/devices/unregister`
```json
{ "device_id": "0123456789abcdef0123456789abcdef" }
```
`200 {"ok":true,"device_id":"...","removed":true}`. Only the caller's own device can match; anything else gives
`removed:false`. There is no delete-by-token.

### Push message sent to FCM
```json
{ "message": { "token": "<device>", "data": { "type": "unlock_request", "requestId": "-Nabc...", "kind": "app", "appName": "Instagram" },
               "android": { "priority": "HIGH", "ttl": "118s" } } }
```
`kind` / `appName` appear only for "more time in one app" requests. No secrets, no login tokens, no message text.
`type` is `unlock_request` (not `approval_request`) because `ApproverMessagingService` ignores any other value.
It is a **data-only** message on purpose: Android then calls `onMessageReceived` in foreground, background and when the
process was killed, and the app builds its own notification (channel, "Re Arena" sub-text, the `isApprover` check, tap opens
the Unlock requests screen). A `notification` block would be shown by the system in the background, skipping all of that.

## Integration

**Android app (already patched in this project):**
1. Trusted phone B, after connecting and whenever FCM issues a new token (`onNewToken`):
   `POST /api/v1/devices/register` with B's own login. `OnlineManager.registerPushToken()` does this through
   `FirebaseGateway.registerToken(context, token, deviceId)`; if the Worker is unreachable it falls back to writing
   `deviceTokens/{uid}` as before, and the Worker still reads that.
2. Locked phone A, right after writing the request: `POST /notify` (or `/api/v1/notifications/send`) with
   `{"request_id": "..."}` and A's login (`FirebaseGateway.notifyApprover`). The push is a convenience: if it fails the
   request is still in the database. Retrying the same `request_id` is safe.
3. B disconnecting: `POST /api/v1/devices/unregister` (`FirebaseGateway.removeToken`).

**A real server of your own (optional):** it can call `send` only with a valid Firebase ID token of the *requesting*
user (for example one it obtained via the Firebase Admin SDK `createCustomToken` + sign-in). The Worker still
resolves the recipient from the database, so a server can never redirect a notification.

## Security and reliability checklist

- [x] Every sensitive route verifies a Firebase ID token (RS256, audience, issuer, expiry, key rotation); uid pattern restricted so it cannot alter a database path.
- [x] Recipient = `links/{sender}.approverUid`; content from `unlockRequests/{sender}/{id}` (pending, <= 120 s). Caller-supplied ids are only compared.
- [x] Idempotency: unique `(sender, request_id)`; atomic claim; concurrent duplicates send once; failed attempts may be retried; crashed claims are reclaimed after 30 s.
- [x] Replay: an ID token replayed within its hour can only repeat idempotent actions.
- [x] Rate limits per sender, per trusted phone and per user for device calls; `Retry-After` returned.
- [x] Input type/format/length validation, 4 KB body cap, unknown paths 404, wrong method 405.
- [x] Secrets only in Cloudflare Secrets; service-account JSON never logged or returned; logger drops credential-like fields (tested).
- [x] FCM: per-attempt timeout, total budget, backoff + `Retry-After`, 401 refresh, UNREGISTERED removal, bad payload does not kill a good token.
- [x] Honest status: `submitted` is not `delivered`; outages are 5xx, never a fake success.
- [x] Multi-device per user, token rotation, token moves between accounts, device cap, daily cleanup (cron).
- [x] Health check leaks nothing.
- [ ] You: enable the WAF rate-limit rule, keep Firebase RTDB rules published (`firebase/database.rules.json`), rotate the service-account key if it ever leaks.

Known limits: access-token and key caches are per Worker isolate (a cold isolate mints a new one; harmless).
Rate limits are fixed windows (a burst across a window edge can be up to 2x). A phone that was force-stopped by the
user, or whose maker kills background apps, may not receive pushes until the app is opened; that is Android, not the Worker.
