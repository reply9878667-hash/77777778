import test from "node:test";
import assert from "node:assert/strict";
import { classify } from "../src/google/fcm.ts";
import { pushData } from "../src/routes/send.ts";
import { addDevice, createWorld, rows } from "./harness.ts";

test("health: simple status, no internals; 503 when the database is unreachable", async () => {
  const w = await createWorld();
  const r = await w.call("/health", { method: "GET", token: null });
  assert.equal(r.status, 200);
  assert.deepEqual(r.json, { ok: true, status: "ok" });
  const text = JSON.stringify(r.json);
  assert.ok(!/token|secret|key|focus|firebase/i.test(text));
  assert.equal((await w.call("/health", { method: "POST", token: null })).status, 405);
  w.env.DB = { prepare: () => { throw new Error("down"); }, batch: async () => [] } as any;
  const down = await w.call("/health", { method: "GET", token: null });
  assert.equal(down.status, 503);
  assert.equal(down.json.status, "degraded");
});

test("responses carry no-store and a request id", async () => {
  const w = await createWorld();
  const r = await w.call("/health", { method: "GET", token: null });
  assert.equal(r.headers.get("cache-control"), "no-store");
  assert.ok(r.headers.get("x-request-id"));
  assert.equal(r.headers.get("x-content-type-options"), "nosniff");
});

test("FCM error classification", () => {
  const body = (status: string, message = "", errorCode?: string) => ({ error: { status, message, details: errorCode ? [{ errorCode }] : [] } });
  assert.equal(classify(404, body("NOT_FOUND", "", "UNREGISTERED")).kind, "invalid_token");
  assert.equal(classify(404, null).kind, "invalid_token");
  assert.equal(classify(403, body("PERMISSION_DENIED", "", "SENDER_ID_MISMATCH")).kind, "invalid_token");
  assert.equal(classify(400, body("INVALID_ARGUMENT", "The registration token is not a valid FCM registration token")).kind, "invalid_token");
  assert.equal(classify(400, body("INVALID_ARGUMENT", "Invalid JSON payload")).kind, "rejected");
  assert.equal(classify(429, body("RESOURCE_EXHAUSTED", "", "QUOTA_EXCEEDED")).kind, "transient");
  assert.equal(classify(500, body("INTERNAL")).kind, "transient");
  assert.equal(classify(503, body("UNAVAILABLE")).kind, "transient");
  assert.equal(classify(403, body("PERMISSION_DENIED")).kind, "config");
  assert.equal(classify(401, body("UNAUTHENTICATED")).kind, "config");
});

test("pushData: data only, strings only, minimal", () => {
  const id = "-Nabcdefghijklmno1234";
  assert.deepEqual(pushData(id, null), { type: "unlock_request", requestId: id });
  assert.deepEqual(pushData(id, { status: "pending" }), { type: "unlock_request", requestId: id });
  assert.deepEqual(pushData(id, { kind: "other", appName: "x" }), { type: "unlock_request", requestId: id });
  assert.deepEqual(Object.keys(pushData(id, { kind: "app", appName: 5 })), ["type", "requestId"]);
  for (const v of Object.values(pushData(id, { kind: "app", appName: "Insta" }))) assert.equal(typeof v, "string");
});

test("scheduled cleanup removes old records only", async () => {
  const w = await createWorld();
  const day = 86_400_000;
  const ins = "INSERT INTO notification_requests (request_id,sender_user_id,recipient_user_id,request_type,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?)";
  w.raw.prepare(ins).run("old-request-1", "a", "b", "unlock", "submitted", w.clock.t - 10 * day, w.clock.t - 10 * day);
  w.raw.prepare(ins).run("new-request-1", "a", "b", "unlock", "submitted", w.clock.t - 1 * day, w.clock.t - 1 * day);
  w.raw.prepare("INSERT INTO rate_limits VALUES ('x', ?, 3)").run(w.clock.t - 3 * day);
  w.raw.prepare("INSERT INTO rate_limits VALUES ('y', ?, 3)").run(w.clock.t);
  addDevice(w, "uidB", "dev-bbbbbbbb", "tok".padEnd(40, "q"));
  w.raw.prepare("INSERT INTO devices (user_id,device_id,fcm_token,is_active,created_at,updated_at) VALUES ('u','dev-dead0001',NULL,0,?,?)").run(w.clock.t - 40 * day, w.clock.t - 40 * day);
  await w.handler.scheduled(w.env);
  assert.deepEqual(rows(w, "SELECT request_id FROM notification_requests").map((r) => r.request_id), ["new-request-1"]);
  assert.deepEqual(rows(w, "SELECT bucket FROM rate_limits").map((r) => r.bucket), ["y"]);
  assert.deepEqual(rows(w, "SELECT device_id FROM devices").map((r) => r.device_id), ["dev-bbbbbbbb"]);
});
