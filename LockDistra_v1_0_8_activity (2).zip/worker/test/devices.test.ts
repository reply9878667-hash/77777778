import test from "node:test";
import assert from "node:assert/strict";
import { REQ, SEND, TOKEN_B, TOKEN_B2, addDevice, createWorld, rows } from "./harness.ts";

const REGISTER = "/api/v1/devices/register";
const UNREGISTER = "/api/v1/devices/unregister";
const DEV = "dev-bbbbbbbb";
const UNREGISTERED = { error: { code: 404, status: "NOT_FOUND", details: [{ errorCode: "UNREGISTERED" }] } };

const asB = (w: any) => w.tokenFor("uidB");

test("register: creates the device for the signed-in user only, validates the token with FCM, never echoes it", async () => {
  const w = await createWorld();
  const r = await w.call(REGISTER, { token: await asB(w), body: { device_id: DEV, fcm_token: TOKEN_B } });
  assert.equal(r.status, 200);
  assert.deepEqual(r.json, { ok: true, device_id: DEV, created: true, rotated: false });
  assert.ok(!JSON.stringify(r.json).includes(TOKEN_B));
  assert.equal(w.fcmCalls.length, 1);
  assert.equal(w.fcmCalls[0].validateOnly, true, "dry run, nothing is delivered");
  assert.deepEqual(rows(w, "SELECT user_id, device_id, fcm_token, platform, is_active FROM devices"), [
    { user_id: "uidB", device_id: DEV, fcm_token: TOKEN_B, platform: "android", is_active: 1 },
  ]);
});

test("register: same device again = token rotation (one row, new token, no duplicates)", async () => {
  const w = await createWorld();
  await w.call(REGISTER, { token: await asB(w), body: { device_id: DEV, fcm_token: TOKEN_B } });
  const r = await w.call(REGISTER, { token: await asB(w), body: { device_id: DEV, fcm_token: TOKEN_B2 } });
  assert.deepEqual([r.json.created, r.json.rotated], [false, true]);
  assert.deepEqual(rows(w, "SELECT fcm_token FROM devices"), [{ fcm_token: TOKEN_B2 }]);
  const same = await w.call(REGISTER, { token: await asB(w), body: { device_id: DEV, fcm_token: TOKEN_B2 } });
  assert.deepEqual([same.json.created, same.json.rotated], [false, false], "re-registering the same token is a no-op");
});

test("register: nobody can register a token for another account", async () => {
  const w = await createWorld();
  const r = await w.call(REGISTER, { token: await w.tokenFor("uidEvil"), body: { device_id: DEV, fcm_token: TOKEN_B, user_id: "uidB" } });
  assert.equal(r.status, 403);
  assert.equal(r.json.error.code, "user_mismatch");
  assert.equal(rows(w, "SELECT * FROM devices").length, 0);
  assert.equal((await w.call(REGISTER, { token: null, body: { device_id: DEV, fcm_token: TOKEN_B } })).status, 401);
});

test("register: a token that moves to another account is taken away from the old one", async () => {
  const w = await createWorld();
  w.rtdb["links/uidA"] = { approverUid: "uidB" };
  await w.call(REGISTER, { token: await asB(w), body: { device_id: DEV, fcm_token: TOKEN_B } });
  await w.call(REGISTER, { token: await w.tokenFor("uidC"), body: { device_id: "dev-cccccccc", fcm_token: TOKEN_B } });
  const d = rows(w, "SELECT user_id, is_active, fcm_token, last_error FROM devices ORDER BY user_id");
  assert.deepEqual(d[0], { user_id: "uidB", is_active: 0, fcm_token: null, last_error: "TOKEN_MOVED" });
  assert.deepEqual(d[1], { user_id: "uidC", is_active: 1, fcm_token: TOKEN_B, last_error: null });
  // uidA's request now has nobody to go to; uidC never receives it.
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 202);
  assert.equal(w.fcmCalls.filter((c) => !c.validateOnly).length, 0);
});

test("register: input validation and FCM dry-run rejection", async () => {
  const w = await createWorld();
  const t = await asB(w);
  for (const body of [
    {}, { device_id: DEV }, { fcm_token: TOKEN_B },
    { device_id: "short", fcm_token: TOKEN_B },
    { device_id: "dev id with spaces", fcm_token: TOKEN_B },
    { device_id: DEV, fcm_token: "tooshort" },
    { device_id: DEV, fcm_token: "x".repeat(20) + " <script>" },
    { device_id: DEV, fcm_token: TOKEN_B, platform: "toaster" },
  ]) {
    const r = await w.call(REGISTER, { token: t, body });
    assert.equal(r.status, 400, JSON.stringify(body).slice(0, 80));
  }
  assert.equal((await w.call(REGISTER, { token: t, body: { device_id: DEV, fcm_token: "x".repeat(5000) } })).status, 413, "oversized body");
  assert.equal(w.fcmCalls.length, 0);
  w.fcmScript.set(TOKEN_B, [{ status: 404, body: UNREGISTERED }]);
  const bad = await w.call(REGISTER, { token: t, body: { device_id: DEV, fcm_token: TOKEN_B } });
  assert.equal(bad.status, 422);
  assert.equal(bad.json.error.code, "invalid_fcm_token");
  assert.equal(rows(w, "SELECT * FROM devices").length, 0);
});

test("register: FCM trouble during the dry run does not block registration; validation can be switched off", async () => {
  let w = await createWorld();
  w.fcmScript.set(TOKEN_B, [{ status: 503, body: { error: { status: "UNAVAILABLE" } } }]);
  assert.equal((await w.call(REGISTER, { token: await asB(w), body: { device_id: DEV, fcm_token: TOKEN_B } })).status, 200);
  assert.equal(rows(w, "SELECT * FROM devices").length, 1);

  w = await createWorld({ VALIDATE_TOKEN_ON_REGISTER: "false" } as any);
  assert.equal((await w.call(REGISTER, { token: await asB(w), body: { device_id: DEV, fcm_token: TOKEN_B } })).status, 200);
  assert.equal(w.fcmCalls.length, 0);
});

test("register: at most MAX_DEVICES_PER_USER stay active (oldest are dropped)", async () => {
  const w = await createWorld({ MAX_DEVICES_PER_USER: "2" } as any);
  const t = await asB(w);
  for (const [i, tok] of ["tokAAAAAAAAAAAAAAAAAAAA1", "tokAAAAAAAAAAAAAAAAAAAA2", "tokAAAAAAAAAAAAAAAAAAAA3"].entries()) {
    w.clock.t += 1000;
    await w.call(REGISTER, { token: t, body: { device_id: `device-${i}-xxxx`, fcm_token: tok } });
  }
  const d = rows(w, "SELECT device_id, is_active, last_error FROM devices ORDER BY id");
  assert.deepEqual(d.map((x) => x.is_active), [0, 1, 1]);
  assert.equal(d[0].last_error, "DEVICE_LIMIT");
});

test("register: rate limited", async () => {
  const w = await createWorld({ RATE_LIMIT_REGISTER_PER_MIN: "2" } as any);
  const t = await asB(w);
  const body = { device_id: DEV, fcm_token: TOKEN_B };
  assert.equal((await w.call(REGISTER, { token: t, body })).status, 200);
  assert.equal((await w.call(REGISTER, { token: t, body })).status, 200);
  assert.equal((await w.call(REGISTER, { token: t, body })).status, 429);
});

test("several devices of one user all receive the notification", async () => {
  const w = await createWorld();
  const t = await asB(w);
  await w.call(REGISTER, { token: t, body: { device_id: DEV, fcm_token: TOKEN_B } });
  await w.call(REGISTER, { token: t, body: { device_id: "dev-bbbbbbb2", fcm_token: TOKEN_B2 } });
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 200);
  assert.deepEqual(r.json.devices, { targeted: 2, submitted: 2, invalid_removed: 0, failed: 0 });
  assert.deepEqual(w.fcmCalls.filter((c) => !c.validateOnly).map((c) => c.token).sort(), [TOKEN_B, TOKEN_B2].sort());
});

test("unregister: removes only the caller's own device; legacy token node of the caller is cleared", async () => {
  const w = await createWorld();
  addDevice(w, "uidB", DEV, TOKEN_B);
  w.rtdb["deviceTokens/uidB"] = TOKEN_B;
  w.rtdb["deviceTokens/uidC"] = "other".repeat(10);
  const r = await w.call(UNREGISTER, { token: await asB(w), body: { device_id: DEV } });
  assert.deepEqual(r.json, { ok: true, device_id: DEV, removed: true });
  assert.deepEqual(rows(w, "SELECT is_active, fcm_token, last_error FROM devices"), [{ is_active: 0, fcm_token: null, last_error: "UNREGISTERED_BY_USER" }]);
  assert.deepEqual(w.rtdbDeletes, ["deviceTokens/uidB"], "only the caller's own legacy node");
  assert.ok("deviceTokens/uidC" in w.rtdb);
  // After logout nothing is pushed.
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 202);
  assert.equal(w.fcmCalls.length, 0);
});

test("unregister: arbitrary deletion is impossible", async () => {
  const w = await createWorld();
  addDevice(w, "uidB", DEV, TOKEN_B);
  const evil = await w.tokenFor("uidEvil");
  const r = await w.call(UNREGISTER, { token: evil, body: { device_id: DEV } });
  assert.equal(r.status, 200);
  assert.equal(r.json.removed, false, "someone else's device id matches nothing");
  assert.equal(rows(w, "SELECT is_active FROM devices")[0].is_active, 1);
  const spoof = await w.call(UNREGISTER, { token: evil, body: { device_id: DEV, user_id: "uidB" } });
  assert.equal(spoof.status, 403);
  assert.equal(rows(w, "SELECT is_active FROM devices")[0].is_active, 1);
  assert.equal((await w.call(UNREGISTER, { token: null, body: { device_id: DEV } })).status, 401);
  assert.equal((await w.call(UNREGISTER, { token: evil, body: { fcm_token: TOKEN_B } })).status, 400, "deleting by raw token is not offered");
  const again = await w.call(UNREGISTER, { token: await asB(w), body: { device_id: "dev-unknown1" } });
  assert.equal(again.json.removed, false);
});

test("database constraints back the rules up", async () => {
  const w = await createWorld();
  addDevice(w, "uidB", DEV, TOKEN_B);
  assert.throws(() => addDevice(w, "uidB", DEV, TOKEN_B2), /UNIQUE/, "one row per (user, device)");
  assert.throws(() => addDevice(w, "uidC", "dev-cccccccc", TOKEN_B), /UNIQUE/, "a token belongs to one row");
  assert.throws(() => w.raw.prepare("UPDATE devices SET fcm_token = NULL WHERE is_active = 1").run(), /CHECK/, "active device needs a token");
  w.raw.prepare("INSERT INTO notification_requests (request_id,sender_user_id,recipient_user_id,request_type,status,created_at,updated_at) VALUES ('r1','a','b','unlock','accepted',1,1)").run();
  assert.throws(() => w.raw.prepare("INSERT INTO notification_requests (request_id,sender_user_id,recipient_user_id,request_type,status,created_at,updated_at) VALUES ('r1','a','b','unlock','accepted',1,1)").run(), /UNIQUE/);
});
