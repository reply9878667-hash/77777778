// Test harness: a real SQLite database behind the D1 interface (same SQL engine as D1), plus fake
// Google / Firebase / FCM servers. Nothing here touches the network.
import { DatabaseSync } from "node:sqlite";
import { readdirSync, readFileSync } from "node:fs";
import { webcrypto } from "node:crypto";
import { bytesToB64url } from "../src/lib/encoding.ts";
import { createHandler } from "../src/index.ts";
import type { D1Like, D1PreparedStatementLike, Env, Runtime } from "../src/types.ts";

export const PROJECT = "demo-proj";
export const DB_URL = "https://demo-proj-default-rtdb.firebaseio.com";
const enc = new TextEncoder();

// ---- D1 on top of node:sqlite --------------------------------------------------------------------------------
export function createD1(): { d1: D1Like; raw: DatabaseSync } {
  const raw = new DatabaseSync(":memory:");
  for (const f of readdirSync(new URL("../migrations/", import.meta.url)).sort()) {
    raw.exec(readFileSync(new URL(`../migrations/${f}`, import.meta.url), "utf8"));
  }
  const stmt = (sql: string, params: unknown[] = []): D1PreparedStatementLike => ({
    bind: (...v) => stmt(sql, v.map((x) => (x === undefined ? null : x))),
    first: async <T>() => (raw.prepare(sql).get(...(params as never[])) as T | undefined) ?? null,
    all: async <T>() => ({ results: raw.prepare(sql).all(...(params as never[])) as T[] }),
    run: async () => {
      const r = raw.prepare(sql).run(...(params as never[]));
      return { meta: { changes: Number(r.changes) } };
    },
  });
  const d1: D1Like = {
    prepare: (sql) => stmt(sql),
    batch: async (list) => {
      raw.exec("BEGIN");
      try {
        const out = [];
        for (const s of list) out.push(await s.run());
        raw.exec("COMMIT");
        return out;
      } catch (e) {
        raw.exec("ROLLBACK");
        throw e;
      }
    },
  };
  return { d1, raw };
}

// ---- keys: one plays "Google securetoken", one plays the service account ------------------------------------
const algo = { name: "RSASSA-PKCS1-v1_5", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" };
export const googleKeys = await webcrypto.subtle.generateKey(algo, true, ["sign", "verify"]);
export const otherKeys = await webcrypto.subtle.generateKey(algo, true, ["sign", "verify"]);
const saKeys = await webcrypto.subtle.generateKey(algo, true, ["sign", "verify"]);
const googleJwk = { ...(await webcrypto.subtle.exportKey("jwk", googleKeys.publicKey)), kid: "k1", alg: "RS256", use: "sig" };
const saPkcs8 = Buffer.from(await webcrypto.subtle.exportKey("pkcs8", saKeys.privateKey)).toString("base64");
export const SA_PRIVATE_B64 = saPkcs8;
export const SA_JSON = JSON.stringify({
  client_email: "svc@demo-proj.iam.gserviceaccount.com",
  private_key: `-----BEGIN PRIVATE KEY-----\n${saPkcs8.match(/.{1,64}/g)!.join("\n")}\n-----END PRIVATE KEY-----\n`,
});

export async function idToken(
  clock: { t: number },
  overrides: Record<string, unknown> = {},
  signWith: CryptoKey = googleKeys.privateKey,
  kid = "k1",
): Promise<string> {
  const now = Math.floor(clock.t / 1000);
  const payload = {
    aud: PROJECT, iss: `https://securetoken.google.com/${PROJECT}`, sub: "uidA",
    iat: now - 10, exp: now + 3000, auth_time: now - 10, ...overrides,
  };
  const h = bytesToB64url(enc.encode(JSON.stringify({ alg: "RS256", kid, typ: "JWT" })));
  const p = bytesToB64url(enc.encode(JSON.stringify(payload)));
  const sig = await webcrypto.subtle.sign("RSASSA-PKCS1-v1_5", signWith, enc.encode(`${h}.${p}`));
  return `${h}.${p}.${bytesToB64url(sig)}`;
}

// ---- the fake internet ---------------------------------------------------------------------------------------
export interface FcmCall { token: string; data: Record<string, string>; android: Record<string, unknown>; validateOnly: boolean; auth: string }
export interface World {
  clock: { t: number };
  rtdb: Record<string, unknown>;
  rtdbDeletes: string[];
  fcmCalls: FcmCall[];
  oauthCalls: number;
  jwkCalls: number;
  /** token -> queue of responses; the last one repeats. Default: 200. */
  fcmScript: Map<string, Array<{ status: number; body?: unknown; headers?: Record<string, string>; throws?: boolean }>>;
  /** when set, FCM answers 401 once for tokens issued before this counter value */
  rejectAccessTokensBefore: number;
  fcmDelayMs: number;
  handler: ReturnType<typeof createHandler>;
  env: Env;
  raw: DatabaseSync;
  sleeps: number[];
  call(path: string, o?: { token?: string | null; body?: unknown; method?: string; rawBody?: string; headers?: Record<string, string> }): Promise<{ status: number; json: any; headers: Headers }>;
  tokenFor(uid: string, overrides?: Record<string, unknown>): Promise<string>;
}

export const REQ = "-Nabcdefghijklmno1234";
export const TOKEN_B = "tokB".padEnd(60, "x");
export const TOKEN_B2 = "tokB2".padEnd(60, "y");

export async function createWorld(envOverrides: Partial<Env> = {}): Promise<World> {
  const clock = { t: Date.UTC(2026, 10, 3, 12, 0, 0) };
  const { d1, raw } = createD1();
  const w = {
    clock, rtdbDeletes: [], fcmCalls: [], oauthCalls: 0, jwkCalls: 0, fcmScript: new Map(),
    rejectAccessTokensBefore: 0, fcmDelayMs: 0, sleeps: [],
  } as unknown as World;
  w.rtdb = {
    "links/uidA": { approverUid: "uidB", approverName: "B" },
    [`unlockRequests/uidA/${REQ}`]: { status: "pending", createdAt: clock.t - 2000 },
  };
  w.raw = raw;
  w.env = {
    DB: d1, FIREBASE_PROJECT_ID: PROJECT, FIREBASE_DATABASE_URL: DB_URL, FCM_SERVICE_ACCOUNT_JSON: SA_JSON,
    ...envOverrides,
  };

  const fakeFetch = async (url: string, init: RequestInit = {}): Promise<Response> => {
    if (url.includes("securetoken@system.gserviceaccount.com")) {
      w.jwkCalls++;
      return new Response(JSON.stringify({ keys: [googleJwk] }), { headers: { "cache-control": "max-age=3600" } });
    }
    if (url === "https://oauth2.googleapis.com/token") {
      w.oauthCalls++;
      return new Response(JSON.stringify({ access_token: `ya29.${w.oauthCalls}`, expires_in: 3600 }));
    }
    if (url.startsWith(DB_URL)) {
      const u = new URL(url);
      const path = decodeURIComponent(u.pathname.slice(1).replace(/\.json$/, ""));
      const n = Number(/^ya29\.(\d+)$/.exec(u.searchParams.get("access_token") ?? "")?.[1] ?? 0);
      if (n < w.rejectAccessTokensBefore) return new Response("{}", { status: 401 });
      if (init.method === "DELETE") { w.rtdbDeletes.push(path); delete w.rtdb[path]; return new Response("null"); }
      return new Response(JSON.stringify(path in w.rtdb ? w.rtdb[path] : null));
    }
    if (url.startsWith("https://fcm.googleapis.com/v1/projects/")) {
      const auth = new Headers(init.headers).get("authorization") ?? "";
      const n = Number(/^Bearer ya29\.(\d+)$/.exec(auth)?.[1] ?? 0);
      if (n < w.rejectAccessTokensBefore) return new Response(JSON.stringify({ error: { code: 401, status: "UNAUTHENTICATED" } }), { status: 401 });
      const parsed = JSON.parse(String(init.body));
      w.fcmCalls.push({ token: parsed.message.token, data: parsed.message.data, android: parsed.message.android, validateOnly: parsed.validate_only === true, auth });
      if (w.fcmDelayMs) clock.t += w.fcmDelayMs;
      const q = w.fcmScript.get(parsed.message.token);
      const step = q ? (q.length > 1 ? q.shift()! : q[0]) : { status: 200 };
      if (step.throws) throw new Error("network down");
      return new Response(JSON.stringify(step.body ?? { name: "projects/x/messages/1" }), { status: step.status, headers: step.headers });
    }
    throw new Error("unexpected fetch " + url);
  };

  const rt: Runtime = {
    fetch: fakeFetch, now: () => clock.t, random: () => 0.5,
    sleep: async (ms) => { w.sleeps.push(ms); clock.t += ms; },
    uuid: () => "rid-" + Math.random().toString(36).slice(2, 10),
  };
  w.handler = createHandler(rt);

  w.tokenFor = (uid, overrides) => idToken(clock, { sub: uid, ...overrides });
  w.call = async (path, o = {}) => {
    const headers: Record<string, string> = { ...(o.headers ?? {}) };
    const token = o.token === undefined ? await w.tokenFor("uidA") : o.token;
    if (token) headers.authorization = `Bearer ${token}`;
    const method = o.method ?? "POST";
    const body = o.rawBody ?? (method === "POST" ? JSON.stringify(o.body ?? {}) : undefined);
    const res = await w.handler.fetch(new Request("https://w.example" + path, { method, headers, body }), w.env);
    const text = await res.text();
    let j: any = null;
    try { j = JSON.parse(text); } catch { j = text; }
    return { status: res.status, json: j, headers: res.headers };
  };
  return w;
}

export const SEND = "/api/v1/notifications/send";
export function addDevice(w: World, user: string, deviceId: string, token: string): void {
  w.raw.prepare("INSERT INTO devices (user_id, device_id, fcm_token, platform, is_active, created_at, updated_at) VALUES (?,?,?,?,1,?,?)")
    .run(user, deviceId, token, "android", w.clock.t, w.clock.t);
}
export function rows(w: World, sql: string, ...p: unknown[]): any[] {
  return (w.raw.prepare(sql).all(...(p as never[])) as any[]).map((r) => ({ ...r }));
}
