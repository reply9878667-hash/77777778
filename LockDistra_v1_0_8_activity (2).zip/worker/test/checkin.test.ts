// Study Check-In: a missed check-in is pushed to the trusted phone through the same authenticated route.
import test from "node:test";
import assert from "node:assert/strict";
import { SEND, TOKEN_B, addDevice, createWorld, rows } from "./harness.ts";

const CI = "ci_12_lx3k9a0z";
const body = (id = CI) => ({ request_id: id, request_type: "checkin_missed" });

async function world() {
  const w = await createWorld();
  addDevice(w, "uidB", "dev-bbbbbbbb", TOKEN_B);
  // The harness seeds a pending unlock request; a check-in must not need (or touch) one.
  for (const k of Object.keys(w.rtdb)) if (k.startsWith("unlockRequests/")) delete w.rtdb[k];
  return w;
}

test("missed check-in: one data-only push, only to the trusted phone, fixed content, no unlock request needed", async () => {
  const w = await world();
  const r = await w.call(SEND, { body: body() });
  assert.equal(r.status, 200);
  assert.equal(r.json.status, "submitted");
  assert.equal(w.fcmCalls.length, 1);
  assert.equal(w.fcmCalls[0].token, TOKEN_B);
  assert.deepEqual(w.fcmCalls[0].data, { type: "checkin_missed", requestId: CI });
  assert.equal(w.fcmCalls[0].android.priority, "HIGH");
  assert.equal(w.fcmCalls[0].android.ttl, "300s");
  const row = rows(w, "SELECT request_type, status, recipient_user_id r FROM notification_requests")[0];
  assert.equal(row.request_type, "checkin_missed");
  assert.equal(row.status, "submitted");
  assert.equal(row.r, "uidB");
});

test("caller-written text never reaches the push (message / application_name are ignored)", async () => {
  const w = await world();
  const r = await w.call(SEND, { body: { ...body(), message: "He is cheating!", application_name: "evil", kind: "app", appName: "x" } });
  assert.equal(r.status, 200);
  assert.deepEqual(Object.keys(w.fcmCalls[0].data).sort(), ["requestId", "type"]);
});

test("duplicate: the same check-in id is answered from the record and never pushed twice (also concurrently)", async () => {
  const w = await world();
  assert.equal((await w.call(SEND, { body: body() })).json.duplicate, false);
  const again = await w.call(SEND, { body: body() });
  assert.equal(again.status, 200);
  assert.equal(again.json.duplicate, true);
  assert.equal(w.fcmCalls.length, 1);

  const w2 = await world();
  await Promise.all([1, 2, 3].map(() => w2.call(SEND, { body: body("ci_13_lx3k9a0z") })));
  assert.equal(w2.fcmCalls.length, 1, "simultaneous retries produce a single push");
});

test("authorization: recipient comes from the database link; a spoofed recipient or sender is refused", async () => {
  const w = await world();
  assert.equal((await w.call(SEND, { body: { ...body(), recipient_user_id: "uidEvil" } })).status, 403);
  assert.equal((await w.call(SEND, { body: { ...body(), sender_user_id: "someoneElse" } })).status, 403);
  assert.equal(w.fcmCalls.length, 0);
});

test("authentication: no / bad login token is refused and nothing is sent", async () => {
  const w = await world();
  assert.equal((await w.call(SEND, { token: null, body: body() })).status, 401);
  assert.equal((await w.call(SEND, { token: "garbage", body: body() })).status, 401);
  assert.equal(w.fcmCalls.length, 0);
});

test("a user with no trusted phone cannot send a check-in alert to anyone", async () => {
  const w = await world();
  const r = await w.call(SEND, { token: await w.tokenFor("uidLoner"), body: body() });
  assert.equal(r.status, 404);
  assert.equal(r.json.error?.code ?? r.json.code, "no_trusted_phone");
  assert.equal(w.fcmCalls.length, 0);
});

test("rate limit: a flood of different check-in ids is cut off", async () => {
  const w = await world();
  const codes: number[] = [];
  for (let i = 0; i < 8; i++) codes.push((await w.call(SEND, { body: body(`ci_${100 + i}_lx3k9a0z`) })).status);
  assert.deepEqual(codes, [200, 200, 200, 200, 200, 200, 429, 429]);
  assert.equal(w.fcmCalls.length, 6);
});

test("no registered device: 202 and nothing sent; the same id can be retried once a phone registers", async () => {
  const w = await createWorld();
  const r = await w.call(SEND, { body: body() });
  assert.equal(r.status, 202);
  assert.equal(w.fcmCalls.length, 0);
  addDevice(w, "uidB", "dev-bbbbbbbb", TOKEN_B);
  assert.equal((await w.call(SEND, { body: body() })).json.status, "submitted");
  assert.equal(w.fcmCalls.length, 1);
});

test("unlock flow is unchanged: a normal request still needs its pending record and keeps type unlock_request", async () => {
  const w = await createWorld();
  addDevice(w, "uidB", "dev-bbbbbbbb", TOKEN_B);
  const stale = await w.call(SEND, { body: { request_id: "-Nnotexisting0000001" } });
  assert.equal(stale.status, 409);
  const ok = await w.call(SEND, { body: { request_id: "-Nabcdefghijklmno1234" } });
  assert.equal(ok.status, 200);
  assert.equal(w.fcmCalls[0].data.type, "unlock_request");
});

test("bad check-in ids and unknown types are rejected", async () => {
  const w = await world();
  assert.equal((await w.call(SEND, { body: { request_id: "short", request_type: "checkin_missed" } })).status, 400);
  assert.equal((await w.call(SEND, { body: { request_id: CI, request_type: "checkin_ok" } })).status, 400);
  assert.equal(w.fcmCalls.length, 0);
});

test("migration 0002 keeps old rows and only widens request_type", async () => {
  const w = await createWorld();
  const cols = rows(w, "PRAGMA table_info(notification_requests)").map((c) => c.name);
  assert.ok(["request_id", "sender_user_id", "recipient_user_id", "request_type", "status", "submitted_at"].every((n) => cols.includes(n)));
  assert.throws(() => w.raw.prepare("INSERT INTO notification_requests (request_id,sender_user_id,recipient_user_id,request_type,status,created_at,updated_at) VALUES ('x','a','b','bogus','accepted',1,1)").run(), /CHECK/);
  assert.ok(rows(w, "SELECT name FROM sqlite_master WHERE type='index' AND name='idx_notification_requests_created'").length === 1);
});
