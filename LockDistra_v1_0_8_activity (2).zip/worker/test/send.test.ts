import test from "node:test";
import assert from "node:assert/strict";
import { SEND, REQ, TOKEN_B, TOKEN_B2, SA_PRIVATE_B64, addDevice, createWorld, idToken, otherKeys, rows } from "./harness.ts";

const UNREGISTERED = { error: { code: 404, status: "NOT_FOUND", message: "Requested entity was not found.", details: [{ errorCode: "UNREGISTERED" }] } };
const UNAVAILABLE = { error: { code: 503, status: "UNAVAILABLE", message: "The service is currently unavailable." } };

async function world(env = {}) {
  const w = await createWorld(env);
  addDevice(w, "uidB", "dev-bbbbbbbb", TOKEN_B);
  return w;
}

test("valid request: FCM gets exactly one data-only message, for the trusted phone only", async () => {
  const w = await world();
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 200);
  assert.equal(r.json.ok, true);
  assert.equal(r.json.status, "submitted");
  assert.equal(r.json.sent, true);
  assert.equal(r.json.duplicate, false);
  assert.equal(r.json.delivery_confirmed, false, "FCM acceptance is not device delivery");
  assert.deepEqual(r.json.devices, { targeted: 1, submitted: 1, invalid_removed: 0, failed: 0 });
  assert.equal(w.fcmCalls.length, 1);
  assert.equal(w.fcmCalls[0].token, TOKEN_B);
  assert.equal(w.fcmCalls[0].validateOnly, false);
  assert.deepEqual(w.fcmCalls[0].data, { type: "unlock_request", requestId: REQ });
  assert.equal(w.fcmCalls[0].android.priority, "HIGH");
  assert.equal(w.fcmCalls[0].android.ttl, "118s", "push expires with the request");
  assert.ok(!JSON.stringify(r.json).includes(TOKEN_B), "FCM token never appears in a response");
  assert.equal(rows(w, "SELECT status, recipient_user_id, request_type FROM notification_requests")[0].status, "submitted");
  assert.equal(rows(w, "SELECT recipient_user_id r FROM notification_requests")[0].r, "uidB");
});

test("old app contract still works: POST /notify {requestId} with the pre-Worker RTDB token", async () => {
  const w = await createWorld();
  w.rtdb["deviceTokens/uidB"] = TOKEN_B;
  const r = await w.call("/notify", { body: { requestId: REQ } });
  assert.equal(r.status, 200);
  assert.equal(r.json.sent, true);
  assert.equal(w.fcmCalls[0].token, TOKEN_B);
});

test("authentication: missing / garbage / foreign-key / wrong project / expired tokens are refused", async () => {
  const w = await world();
  const t = w.clock;
  assert.equal((await w.call(SEND, { token: null, body: { request_id: REQ } })).status, 401);
  assert.equal((await w.call(SEND, { token: "a.b.c", body: { request_id: REQ } })).status, 401);
  assert.equal((await w.call(SEND, { token: await idToken(t, {}, otherKeys.privateKey), body: { request_id: REQ } })).status, 401, "signed by another key");
  assert.equal((await w.call(SEND, { token: await idToken(t, { aud: "other" }), body: { request_id: REQ } })).status, 401);
  assert.equal((await w.call(SEND, { token: await idToken(t, { iss: "https://evil" }), body: { request_id: REQ } })).status, 401);
  assert.equal((await w.call(SEND, { token: await idToken(t, { exp: Math.floor(t.t / 1000) - 5 }), body: { request_id: REQ } })).status, 401);
  assert.equal((await w.call(SEND, { token: await idToken(t, { sub: "a/../b" }), body: { request_id: REQ } })).status, 401, "unsafe uid");
  const r = await w.call(SEND, { token: null, body: { request_id: REQ } });
  assert.equal(r.json.error.code, "unauthorized");
  assert.ok(r.headers.get("www-authenticate"));
  assert.equal(w.fcmCalls.length, 0);
  assert.equal(rows(w, "SELECT * FROM notification_requests").length, 0);
});

test("authorization: the recipient comes from the database link, never from the caller", async () => {
  const w = await world();
  // Attacker uidX is paired with uidZ and knows uidA's request id.
  w.rtdb["links/uidX"] = { approverUid: "uidZ" };
  addDevice(w, "uidZ", "dev-zzzzzzzz", "tokZ".padEnd(60, "z"));
  const x = await w.call(SEND, { token: await w.tokenFor("uidX"), body: { request_id: REQ } });
  assert.equal(x.status, 409);
  assert.equal(x.json.error.code, "not_pending", "uidA's request does not exist under uidX");
  // No link at all.
  const n = await w.call(SEND, { token: await w.tokenFor("uidN"), body: { request_id: REQ } });
  assert.equal(n.status, 404);
  assert.equal(n.json.error.code, "no_trusted_phone");
  // Claiming to be someone else / aiming at someone else.
  const s = await w.call(SEND, { body: { request_id: REQ, sender_user_id: "uidX" } });
  assert.equal(s.status, 403);
  assert.equal(s.json.error.code, "sender_mismatch");
  const rcp = await w.call(SEND, { body: { request_id: REQ, recipient_user_id: "uidC" } });
  assert.equal(rcp.status, 403);
  assert.equal(rcp.json.error.code, "recipient_not_authorized");
  assert.equal(w.fcmCalls.length, 0, "nothing was pushed to anybody");
  // Correct explicit ids are accepted.
  const good = await w.call(SEND, { body: { request_id: REQ, sender_user_id: "uidA", recipient_user_id: "uidB" } });
  assert.equal(good.status, 200);
  assert.equal(w.fcmCalls.length, 1);
});

test("the request must exist, be pending and be fresh", async () => {
  let w = await world();
  (w.rtdb[`unlockRequests/uidA/${REQ}`] as any).status = "approved";
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).json.error.code, "not_pending");
  w = await world();
  (w.rtdb[`unlockRequests/uidA/${REQ}`] as any).createdAt = w.clock.t - 200_000;
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).json.error.code, "expired");
  w = await world();
  delete w.rtdb[`unlockRequests/uidA/${REQ}`];
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).json.error.code, "not_pending");
  assert.equal(w.fcmCalls.length, 0);
});

test("bad input, wrong method, unknown path, oversized body", async () => {
  const w = await world();
  for (const body of [{ request_id: "../links" }, {}, { request_id: 5 }, { request_id: REQ, request_type: "nuke" }, { request_id: REQ, message: "x".repeat(501) }, { request_id: REQ, created_at: "now" }]) {
    const r = await w.call(SEND, { body });
    assert.equal(r.status, 400, JSON.stringify(body));
    assert.equal(r.json.error.code, "invalid_request");
  }
  assert.equal((await w.call(SEND, { rawBody: "[1,2]" })).status, 400);
  assert.equal((await w.call(SEND, { rawBody: "{nope" })).json.error.code, "invalid_json");
  const get = await w.call(SEND, { method: "GET" });
  assert.equal(get.status, 405);
  assert.equal(get.headers.get("allow"), "POST");
  assert.equal((await w.call("/nope")).status, 404);
  assert.equal((await w.call(SEND, { rawBody: JSON.stringify({ request_id: REQ, message: "x".repeat(5000) }) })).status, 413);
  assert.equal(w.fcmCalls.length, 0);
});

test("idempotency: a repeated request_id is answered from the record and never pushed twice", async () => {
  const w = await world();
  const a = await w.call(SEND, { body: { request_id: REQ } });
  const b = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(a.json.duplicate, false);
  assert.equal(b.status, 200);
  assert.equal(b.json.duplicate, true);
  assert.equal(b.json.status, "submitted");
  assert.equal(w.fcmCalls.length, 1);
  assert.equal(rows(w, "SELECT * FROM notification_requests").length, 1);
});

test("idempotency under concurrency: simultaneous calls produce a single push", async () => {
  const w = await world();
  const all = await Promise.all([1, 2, 3, 4].map(() => w.call(SEND, { body: { request_id: REQ } })));
  assert.equal(w.fcmCalls.length, 1);
  for (const r of all) assert.ok([200, 409].includes(r.status), "got " + r.status);
  assert.equal(all.filter((r) => r.status === 200 && r.json.duplicate === false).length, 1, "exactly one winner");
});

test("a request id is scoped to its sender: another user cannot block or hijack it", async () => {
  const w = await world();
  w.rtdb["links/uidX"] = { approverUid: "uidZ" };
  w.rtdb[`unlockRequests/uidX/${REQ}`] = { status: "pending", createdAt: w.clock.t - 1000 };
  addDevice(w, "uidZ", "dev-zzzzzzzz", "tokZ".padEnd(60, "z"));
  assert.equal((await w.call(SEND, { token: await w.tokenFor("uidX"), body: { request_id: REQ } })).status, 200);
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).json.duplicate, false, "uidA still gets its own push");
  assert.deepEqual(w.fcmCalls.map((c) => c.token).sort(), [TOKEN_B, "tokZ".padEnd(60, "z")].sort());
});

test("FCM outage: retried with backoff, reported as 503 (not as sent), and the same request may be retried later", async () => {
  const w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 503, body: UNAVAILABLE }]);
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 503);
  assert.equal(r.json.error.code, "fcm_unavailable");
  assert.ok(r.headers.get("retry-after"));
  assert.equal(w.fcmCalls.length, 3, "three attempts");
  assert.equal(w.sleeps.length, 2, "backoff between attempts");
  assert.equal(rows(w, "SELECT status, error_code FROM notification_requests")[0].status, "failed");

  w.fcmScript.set(TOKEN_B, [{ status: 200 }]);
  const again = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(again.status, 200);
  assert.equal(again.json.duplicate, false, "a failed attempt does not block the retry");
  assert.equal(rows(w, "SELECT attempts, status FROM notification_requests")[0].attempts, 2);
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).json.duplicate, true);
});

test("transient errors recover inside one call; Retry-After is honoured; network errors are retried", async () => {
  let w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 503, body: UNAVAILABLE }, { status: 200 }]);
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 200);
  assert.equal(w.fcmCalls.length, 2);

  w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 429, headers: { "retry-after": "1" }, body: { error: { status: "QUOTA_EXCEEDED" } } }, { status: 200 }]);
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 200);
  assert.equal(w.sleeps[0], 1000);

  w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 0, throws: true }, { status: 200 }]);
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 200);

  w = await world({ FCM_MAX_ATTEMPTS: "1" } as any);
  w.fcmScript.set(TOKEN_B, [{ status: 503, body: UNAVAILABLE }]);
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 503);
  assert.equal(w.fcmCalls.length, 1);
});

test("several devices: all get the push; a dead token is deactivated and the others still deliver", async () => {
  const w = await world();
  addDevice(w, "uidB", "dev-bbbbbbb2", TOKEN_B2);
  w.fcmScript.set(TOKEN_B, [{ status: 404, body: UNREGISTERED }]);
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 200);
  assert.deepEqual(r.json.devices, { targeted: 2, submitted: 1, invalid_removed: 1, failed: 0 });
  const d = rows(w, "SELECT device_id, is_active, fcm_token, last_error FROM devices ORDER BY device_id");
  assert.deepEqual(d[0], { device_id: "dev-bbbbbbb2", is_active: 1, fcm_token: TOKEN_B2, last_error: null });
  assert.deepEqual(d[1], { device_id: "dev-bbbbbbbb", is_active: 0, fcm_token: null, last_error: "UNREGISTERED" });
});

test("every token dead: 202 no_device; after the phone registers again the same request is delivered", async () => {
  const w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 404, body: UNREGISTERED }]);
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 202);
  assert.equal(r.json.status, "no_device");
  assert.equal(r.json.sent, false);
  assert.equal(r.json.reason, "all_tokens_invalid");
  addDevice(w, "uidB", "dev-bbbbbbb3", TOKEN_B2);
  const again = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(again.status, 200);
  assert.equal(w.fcmCalls.at(-1)!.token, TOKEN_B2);
});

test("no registered device at all: 202, nothing sent", async () => {
  const w = await createWorld();
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 202);
  assert.equal(r.json.reason, "no_registered_device");
  assert.equal(w.fcmCalls.length, 0);
});

test("a rejected payload does not kill a good token; a bad-token 400 does", async () => {
  let w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 400, body: { error: { code: 400, status: "INVALID_ARGUMENT", message: "Invalid JSON payload received." } } }]);
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 502);
  assert.equal(r.json.error.code, "fcm_rejected");
  assert.equal(rows(w, "SELECT is_active FROM devices")[0].is_active, 1);
  assert.equal(w.fcmCalls.length, 1, "permanent errors are not retried");

  w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 400, body: { error: { code: 400, status: "INVALID_ARGUMENT", message: "The registration token is not a valid FCM registration token" } } }]);
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 202);
  assert.equal(rows(w, "SELECT is_active FROM devices")[0].is_active, 0);
});

test("expired OAuth access token is refreshed once; a second 401 means bad credentials", async () => {
  let w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 401, body: { error: { code: 401, status: "UNAUTHENTICATED" } } }, { status: 200 }]);
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 200);
  assert.equal(w.oauthCalls, 2);
  assert.equal(w.fcmCalls.length, 2);
  assert.notEqual(w.fcmCalls[0].auth, w.fcmCalls[1].auth, "second attempt used the new token");

  // The database refuses an old token too.
  w = await world();
  await w.call(SEND, { body: { request_id: REQ } }); // mints ya29.1
  w.rejectAccessTokensBefore = 2;
  w.rtdb[`unlockRequests/uidA/-Nsecondrequest12345`] = { status: "pending", createdAt: w.clock.t - 500 };
  const r2 = await w.call(SEND, { body: { request_id: "-Nsecondrequest12345" } });
  assert.equal(r2.status, 200);
  assert.equal(w.oauthCalls, 2);

  w = await world();
  w.fcmScript.set(TOKEN_B, [{ status: 401, body: { error: { status: "UNAUTHENTICATED" } } }]);
  const bad = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(bad.status, 502);
  assert.equal(bad.json.error.code, "fcm_misconfigured");
});

test("the access token is reused across requests and renewed after it expires", async () => {
  const w = await world();
  await w.call(SEND, { body: { request_id: REQ } });
  w.rtdb[`unlockRequests/uidA/-Nsecondrequest12345`] = { status: "pending", createdAt: w.clock.t - 500 };
  await w.call(SEND, { body: { request_id: "-Nsecondrequest12345" } });
  assert.equal(w.oauthCalls, 1);
  assert.equal(w.jwkCalls, 1, "Google signing keys are cached too");
  w.clock.t += 3600_000;
  w.rtdb[`unlockRequests/uidA/-Nthirdrequest123456`] = { status: "pending", createdAt: w.clock.t - 500 };
  assert.equal((await w.call(SEND, { body: { request_id: "-Nthirdrequest123456" } })).status, 200);
  assert.equal(w.oauthCalls, 2);
});

test("rate limits: per sender and per recipient, and the window resets", async () => {
  const w = await world();
  const codes: number[] = [];
  for (let i = 0; i < 11; i++) codes.push((await w.call(SEND, { body: { request_id: REQ } })).status);
  assert.deepEqual(codes, [200, ...Array(9).fill(200), 429]);
  const limited = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(limited.json.error.code, "rate_limited");
  assert.ok(Number(limited.headers.get("retry-after")) >= 1);
  assert.equal(w.fcmCalls.length, 1);
  w.clock.t += 61_000;
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 200);

  const w2 = await world({ RATE_LIMIT_RECIPIENT_PER_MIN: "1" } as any);
  w2.rtdb["links/uidC"] = { approverUid: "uidB" };
  w2.rtdb[`unlockRequests/uidC/${REQ}`] = { status: "pending", createdAt: w2.clock.t - 1000 };
  assert.equal((await w2.call(SEND, { body: { request_id: REQ } })).status, 200);
  assert.equal((await w2.call(SEND, { token: await w2.tokenFor("uidC"), body: { request_id: REQ } })).status, 429, "trusted phone cannot be flooded by many senders");
});

test("\"more time in one app\": the push names the app, cleaned and short; type is recorded", async () => {
  const w = await world();
  w.rtdb[`unlockRequests/uidA/${REQ}`] = { status: "pending", createdAt: w.clock.t - 1000, kind: "app", pkg: "com.x", appName: "In|sta\ngram" + "x".repeat(60), reason: 3 };
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 200);
  const d = w.fcmCalls[0].data;
  assert.deepEqual(Object.keys(d).sort(), ["appName", "kind", "requestId", "type"]);
  assert.equal(d.kind, "app");
  assert.ok(d.appName.startsWith("In sta gram"));
  assert.ok(d.appName.length <= 40);
  assert.equal(rows(w, "SELECT request_type FROM notification_requests")[0].request_type, "app_time");
});

test("configuration problems fail closed and send nothing", async () => {
  let w = await world({ FCM_SERVICE_ACCOUNT_JSON: "" } as any);
  let r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 500);
  assert.equal(r.json.error.code, "server_not_configured");
  w = await world({ FCM_SERVICE_ACCOUNT_JSON: "{not json" } as any);
  r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 500);
  assert.equal(r.json.error.code, "server_misconfigured");
  assert.equal(w.fcmCalls.length, 0);
});

test("database outage is a retryable 503, not a crash and not a false success", async () => {
  const w = await world();
  w.env.FIREBASE_DATABASE_URL = "https://unreachable.example";
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 503);
  assert.equal(r.json.error.code, "upstream_unavailable");
  assert.equal(w.fcmCalls.length, 0);
});

test("a crash after the claim is recorded as failed so the request can be retried", async () => {
  const w = await world();
  const realPrepare = w.env.DB.prepare.bind(w.env.DB);
  let boom = true;
  w.env.DB.prepare = (sql: string) => {
    if (boom && sql.startsWith("SELECT id, device_id, fcm_token FROM devices")) { boom = false; throw new Error("d1 exploded"); }
    return realPrepare(sql);
  };
  const r = await w.call(SEND, { body: { request_id: REQ } });
  assert.equal(r.status, 500);
  assert.equal(r.json.error.code, "internal_error");
  assert.equal(rows(w, "SELECT status FROM notification_requests")[0].status, "failed");
  assert.equal((await w.call(SEND, { body: { request_id: REQ } })).status, 200);
});

test("logs never contain tokens, keys or request secrets", async () => {
  const w = await world();
  const lines: string[] = [];
  const saved = [console.log, console.warn, console.error];
  console.log = console.warn = console.error = (...a: unknown[]) => { lines.push(a.join(" ")); };
  const idt = await w.tokenFor("uidA");
  try {
    w.fcmScript.set(TOKEN_B2, [{ status: 503, body: UNAVAILABLE }]);
    addDevice(w, "uidB", "dev-bbbbbbb2", TOKEN_B2);
    await w.call(SEND, { token: idt, body: { request_id: REQ } });
    await w.call(SEND, { token: "garbage.token.value", body: { request_id: REQ } });
  } finally {
    [console.log, console.warn, console.error] = saved;
  }
  const all = lines.join("\n");
  assert.ok(all.length > 0, "something was logged");
  for (const secret of [TOKEN_B, TOKEN_B2, idt, "ya29", "PRIVATE KEY", SA_PRIVATE_B64.slice(0, 40), "svc@demo-proj"]) {
    assert.ok(!all.includes(secret), "leaked: " + secret.slice(0, 12));
  }
});
