# Study Check-In + automatic trusted-phone alert (Task 2)

STATUS: written, NOT compiled, NOT run on a device (no Gradle / Android SDK / Kotlin compiler in the authoring environment).
The Cloudflare Worker part WAS run: `cd worker && npm test` -> 51/51 pass (40 existing + 11 new), `npx tsc --noEmit` clean.

## How it works (no new service, timer or listener)
- Setting: Settings > Focus > "Study Check-In" (Off [default] / Every 10 minutes / Every 15 minutes / Custom 2-180 min).
  Changeable only between sessions (same rule as the OFF method), so it cannot be switched off mid-session.
- `FocusEngine.process` (already ticked every second by `FocusService`, and by the existing doze-safe alarm and app resume)
  calls `StudyCheckInEngine.process`. At the interval it posts a heads-up notification (own channel, short chime):
  "Are You Still Studying?" / "Please confirm that you are actively studying." / button "I'm Studying".
  It shows on top of the current app, needs no app switch, and works in the background. It removes itself after 1 minute.
- "I'm Studying" -> `StudyCheckInReceiver` -> `FocusStore.confirmStudyCheckIn` (counts only for the waiting check-in).
- No answer within 1 minute -> missed. Focus session, Pomodoro timer and blocking are not touched.
- Missed + effective OFF method is Online Approval -> ONE authenticated POST to the existing Worker `/notify`
  (`request_type: "checkin_missed"`). The Worker takes the sender from the Firebase login, finds the recipient from
  `links/{sender}/approverUid`, and pushes a data-only message to that user's registered devices only.
  The trusted phone shows "Study Check-In Missed" / "The user has not responded to the study confirmation for one minute.
  Please check whether they are studying." (fixed wording in the app; nothing from the push is displayed).
- Normal Button / Password (or Online Approval that lost its setup and fell back to Normal): the miss is recorded, nothing is sent.

## Duplicate / false-alert protection
- Store steps (`beginStudyCheckIn`, `markStudyCheckInMissed`, `markStudyAlertHandled`) are synchronized and once-only.
- One send in flight at a time; retries spaced 20 s, max 4 tries, dropped 5 min after the miss.
- Same miss = same id `ci_<seq>_<time>`; the Worker answers a repeat from its D1 record (no second push).
- Notifications off / channel off: the prompt is skipped (not shown, so it is never called "missed").
- Phone asleep/off past the 1-minute deadline by more than 2 min: dropped quietly, trusted person not told.
- Session ending (timer end, Pomodoro round end, OFF) drops a waiting prompt; that is not a miss.

## Deploy order (important)
1. `cd worker && npm run db:migrate:remote` (new `migrations/0002_checkin_type.sql` widens the `request_type` CHECK; rebuilds the table, keeps rows).
2. `npm run deploy`.
3. Ship the app. Firebase RTDB rules are unchanged (no new database node).
Without step 1, only check-in alerts fail (HTTP 500); unlock requests keep working.

## Files
new: `data/StudyCheckIn.kt`, `service/StudyCheckInEngine.kt`, `StudyCheckInTest.kt`, `worker/migrations/0002_checkin_type.sql`,
     `worker/test/checkin.test.ts`, this file
changed (app): `data/FocusStore.kt`, `service/FocusController.kt`, `service/Notifications.kt`, `service/Receivers.kt`,
     `service/ApproverMessagingService.kt`, `data/online/FirebaseGateway.kt`, `data/online/OnlineManager.kt`,
     `ui/screens/FocusControlsCard.kt`, `ui/screens/SettingsScreen.kt`, `ui/AppViewModel.kt`, `ui/FocusApp.kt`, `AndroidManifest.xml`
changed (worker): `src/validation.ts`, `src/routes/send.ts`

## Known limits
- The prompt is a heads-up notification, not a custom window drawn over other apps (that would need the accessibility overlay or
  "display over other apps"). If the user turns heads-up off for the channel, it appears in the shade instead.
- The existing plant reminder ("Are you studying?", grows the plant) is untouched and separate; both can be on.
- The Worker cannot know the OFF method; "Online Approval only" is enforced in the app. A modified app could send the alert
  anyway, but only to its own trusted phone, rate-limited (6 per 10 min) and send-once per id.
- Exact timing needs "Alarms & reminders" on Android 12+. Without it Android may delay the wake-up in doze; a delay beyond 2 min means no alert.
- Check-ins run only while a session runs; nothing is asked during a Pomodoro Break.

## Manual device checks
1. Interval 10, then 15 (Custom 2 for a quick test): prompt appears at the interval, with sound, over another app; button dismisses it.
2. Tap "I'm Studying": prompt gone, no alert on the trusted phone, session timer unchanged.
3. Ignore it for 1 minute, OFF method = Online Approval: trusted phone gets "Study Check-In Missed" once; Focus stays ON.
4. Same with Normal Button, then Password: nothing arrives on the trusted phone.
5. Lock the screen / background ReWire / battery saver on: prompts and alerts still come.
6. Pomodoro 25/5 with interval 10: prompts only in Focus rounds; timer and Break unaffected; round 2 restarts the interval.
7. Notifications off: no prompt, no alert. Airplane mode during a miss: no crash, no duplicate when back online.
