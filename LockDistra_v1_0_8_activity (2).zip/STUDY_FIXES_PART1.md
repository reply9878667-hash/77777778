# Study Section – Part 1/4: core bug fixes

Scope: only identified problems were fixed. The Study Section was not rebuilt, and no automatic source switching was added or changed.
NOT compiled or run here (no Gradle / Kotlin / Android SDK in the build sandbox): run `./gradlew testDebugUnitTest` and a debug build before release.

## Root causes found and fixed

| # | Problem (root cause) | Fix | File |
|---|---|---|---|
| 1 | One damaged entry in a saved list made `fromJson` return nothing, so the whole list was thrown away and fetched again | each entry is read on its own; empty title / picture get defaults | StudyRules |
| 2 | A video answer with no picture or no title made a blank card | standard picture address (`i.ytimg.com/vi/<id>/hqdefault.jpg`), title "Untitled video" | StudyRules |
| 3 | Descriptions were never read | first 300 characters kept and shown under the video (tap to open) | StudyRules, LecturePreviewPanel |
| 4 | A picture that failed to load left an empty hole, was asked for again on every scroll, and a non-picture answer was saved to disk | placeholder icon (logo: first letter), 5 minute "do not retry", never save non-pictures, delete damaged files | StudyScreen |
| 5 | The same picture on several cards was downloaded several times; the picture folder grew without limit | one download per address; trimmed to 50 MB when above 80 MB (once per app start) | StudyScreen |
| 6 | Plain `http://` and `//host` picture addresses never load on Android | `StudyRules.imageUrl` makes them https, anything else counts as missing | StudyRules |
| 7 | Direct YouTube results had no channel logos while the API was resting | logos are read from the page data and kept | StudyNative, StudyRepository |
| 8 | Logos saved by another source never showed (the screen kept an old copy) | the screen reloads the saved logos before deciding what is missing | StudyScreen |
| 9 | Opening a channel for a video without a channel (web result) gave a blank / failing profile | no channel tap when the channel is unknown; guarded in the repository | StudyScreen, StudyRepository |
| 10 | Channel page: description missing, details and videos loaded one after the other, reopening asked YouTube again | description added, both load together, first page kept for 10 minutes | StudyApi, StudyRepository, StudyScreen |
| 11 | Going back from a channel / Shorts viewer / settings jumped the list to the top | scroll positions kept in `StudyScreen`; a new search or tab still starts at the top | StudyScreen |
| 12 | A channel that never uploaded (no uploads playlist, 404) showed an error | treated as an empty channel (`NOT_FOUND`) | StudyRules, StudyApi |
| 13 | The same videos / channels were paid for again by the feed, search, promo and web judging | shared 10 minute memory for video and channel details (also "YouTube returned nothing"); the logo loader and country lookup share one in-flight request | StudyApi, StudyRepository |
| 14 | A 200 answer that is not JSON (Wi-Fi login page) became "no videos" | `BAD_ANSWER` error | StudyApi |
| 15 | Direct YouTube's unreadable page was reported as `QUOTA`; refused keys were reported as "limit used up" | new kinds `BAD_ANSWER` / `NOT_FOUND`, `StudyException.source` (API / PAGE / WEB), the resting reason of a key is kept | StudyRules, StudyApi, StudyStore, StudyRepository |
| 16 | Web search: every failure said "check your internet"; a page with no readable cards said "no study videos" | named messages: no connection, YouTube refusing (403 / 429), page engine stopped, page could not be read | StudyWebSearch |
| 17 | Error cards all had the same heading | heading names the source and keeps limit / network / unreadable apart (`StudyRules.errorTitle`) | StudyScreen |

The fallback to the next source that already existed (limit used up -> page data -> web search) still runs exactly as before; an unreadable Direct YouTube page still moves on to the Web search (it is now `BAD_ANSWER` with source PAGE instead of a fake `QUOTA`).

## Modified files
data: StudyRules, StudyApi, StudyNative, StudyRepository, StudyStore · ui: StudyScreen, StudyWebSearch, LecturePreviewPanel · tests: StudyRulesTest, StudyNativeTest · docs: STUDY_SECTION.md, this file.

## Tests added
StudyRulesTest: missing information, one broken item, picture addresses, non-JSON answer, damaged saved list, channel description, not-found, error names / source. StudyNativeTest: channel pictures (classic and lockup layouts, and none).

## Not verified
- Compile and unit tests (see top).
- The page-data paths for channel pictures follow YouTube's current data names (`channelThumbnailWithLinkRenderer`, `avatarViewModel`) but were only tested against hand-written samples, not the live site.
- No device test of the screens (placeholder, scroll position, channel page).
