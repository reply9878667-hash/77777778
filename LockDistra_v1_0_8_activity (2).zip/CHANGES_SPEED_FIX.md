# Speed fix (user app, Study tab) - nothing removed, only improved/added

Why it was slow
1. Home feed: ~10 YouTube requests ran ONE AFTER ANOTHER (8 channels + 2 searches), then details, then channel country lookup.
2. Home feed had no "next page" at all: only one batch was loaded (after the study filter ~6-7 videos), so scrolling stopped.
3. Search: search -> details -> country lookup, all in a row. A repeated search also lost its "load more".
4. Every request used disconnect(), which throws the HTTPS connection away: a new TLS handshake for every suggestion, picture and API call.
5. Suggestions: 250 ms wait + a new connection per letter + no memory of earlier answers.
6. Pictures: no disk cache (downloaded again after every app start).
7. Player: WebView engine + youtube scripts started cold on the first tap.

What changed
- StudyRepository.feed(): all requests run at the same time (thread pool).
- StudyRepository.feedMore() + StudyScreen.loadMoreFeed(): endless Home scroll (older uploads of followed/most played channels, 1 unit per page; subject search only as fallback).
- StudyRepository.search(): no wait for country lookup (learned in background), skips empty pages (max 3), cached first page keeps its next-page token.
- StudyApi: streams closed instead of disconnect() (connection reuse); suggestions cached in memory, 2.5 s timeouts.
- StudyScreen: suggestions show from memory instantly, 60 ms wait, connection warmed when the search box opens.
- StudyScreen Thumb(): picture disk cache (cacheDir/study_thumbs), connection reuse.
- LecturePlayerHtml / ShortsViewer: preconnect hints; WebView engine warmed up quietly after Study opens.

Not compiled or run here (no Android SDK). Please build and test on a phone.

# Study benefits popup (first open only)
- New file ui/screens/StudyBenefitsDialog.kt: popup "Welcome to Study mode - Benefits for you" with symbols + points (No ads, no distractions, only learning videos, fast & endless, follow teachers, grow your plant).
- StudyStore.benefitsSeen: remembers it was shown. StudyScreen shows it once, the first time the Study section opens.
