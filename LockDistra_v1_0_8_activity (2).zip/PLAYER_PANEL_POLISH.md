# Player settings, Repeat button, description switch + links

- **Settings (gear) menu = quality only** (Auto + levels + "Playing now"). Background play and Repeat are no longer inside it.
  Background keeps its own top button; **Repeat now has its own top button** ("Repeat: On/Off", purple when on) in the player's top row.
- **Description:** the Hide/Show text is now a **switch** (on = open). Web addresses in the description are underlined and tappable
  (opened with the browser / matching app; "No app can open this link" if none). Text is still selectable.
- **Subscribe** under a Study video is now a small white pill, so it no longer looks like the purple **Start Focus Mode** button.
  (Channel page keeps its own wide button.)
