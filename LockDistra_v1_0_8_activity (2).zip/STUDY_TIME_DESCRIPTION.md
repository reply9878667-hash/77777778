# Study videos: upload time, length and an open description

**Problem.** Videos that came from YouTube's search page (no API key / daily limit used up) showed no "3 days ago", and the
player under a Study video showed no description at all (only the API ever gave one, and it was folded to 3 lines).

**Fix.**
- `StudyRules.parseAgoLabel` reads "3 days ago" / "Streamed 2 weeks ago" from the page text; `NativeResult.publishedAt` and
  `StudyRepository.nativeSearch` now keep it, so every card shows the upload time like the API videos do.
- `StudyNative.watchInfo` / `parseWatchInfo` read the FULL description and the real upload date from the video's watch page
  (`ytInitialPlayerResponse`). Free: costs none of the YouTube API limit. If it fails, `StudyApi.details` is the fallback.
- `LecturePreviewPanel` (the panel under a playing Study video) loads that info when the video opens and shows:
  channel, upload time, **Length mm:ss**, and a **Description** section that is OPEN by default (tap "Hide" to fold it).
  The text can be selected and copied (creators' notes).
- Tests: `StudyRulesTest` (ago label, ISO date), `StudyNativeTest` (publishedAt, watch page parsing).
