# Task 1 – Account creation & login

Continues from `ONBOARDING_PART2D.md`. Onboarding screens, the seven questions, Home and the unlock/blocking code are untouched.

> **Not compiled or run.** This was written without an Android SDK / Gradle (same as earlier parts). Open the project
> in Android Studio, sync, and expect to fix a small compile error or two. The pure logic (validation, error mapping)
> has unit tests: `./gradlew testDebugUnitTest`.

## What existed before this task
A small *optional* email login was already in the code (`LoginOverlay` / `AccountForm` in `OnlineScreens.kt`,
`OnlineManager.signUp/signIn/signOut`, `FirebaseGateway.createAccount/signInEmail`): name + email + password,
Skip button, no Google, no confirm-password, no forgot-password, weak validation, no loading/duplicate guard,
no session restore. It is **replaced** by this task (old UI and methods removed, not left as dead code).

## Journey
Splash -> Welcome -> Q1..Q7 -> Celebration -> **Account screen (new, first launch only)** -> Home.
`Skip for now` keeps the old behaviour (the app works fully offline without an account). To make accounts mandatory
later, set `AuthConfig.ALLOW_SKIP = false`. Settings > Account opens the same screens (starting on *Log in*).

## Architecture (all new code in two packages)
```
data/auth/                      (no UI)
  AuthRepository.kt             ONLY entry point: session + signUpWithEmail / signInWithEmail / signInWithGoogle /
                                sendPasswordReset / signOut. Never throws, one action at a time (BUSY guard).
  FirebaseAuthService.kt        only class that calls Firebase Auth (reuses FirebaseGateway's Firebase app)
  GoogleCredentialClient.kt     Android Credential Manager -> Google ID token
  AuthValidation.kt / AuthErrors.kt / AuthModels.kt / AuthConfig.kt / AuthStore.kt / AccountHost.kt
ui/auth/
  AuthFlow.kt                   Sign up, Log in, Forgot password, Success screens (one overlay composable)
  AuthViewModel.kt              form state, field errors, busy flag, reset cooldown
  AuthComponents.kt             fields, Google button, divider, message box, page scaffold
```
A later profile phase should read `AuthRepository.get(context).session` (`AuthSession.SignedIn(user)` with
uid, name, email, provider) and need not touch anything else.

## Files
**New (12):** `data/auth/` AccountHost, AuthConfig, AuthErrors, AuthModels, AuthRepository, AuthStore, AuthValidation,
FirebaseAuthService, GoogleCredentialClient; `ui/auth/` AuthComponents, AuthFlow, AuthViewModel; tests
`data/auth/AuthValidationTest.kt`, `AuthErrorsTest.kt`; this file.

**Modified (9):**
| File | Change |
|---|---|
| `app/build.gradle.kts` | + deps `credentials`, `credentials-play-services-auth`, `googleid`; + BuildConfig `GOOGLE_WEB_CLIENT_ID` |
| `firebase.properties.example`, `firebase.properties` | + `googleWebClientId=` (empty until you set it) |
| `ui/FocusApp.kt` | old `LoginOverlay` replaced by `AuthFlow`; first-run trigger; `onOpenAuth` for Settings |
| `ui/screens/SettingsScreen.kt` | + `onOpenAuth` parameter, passed to `AccountSection` |
| `ui/online/OnlineScreens.kt` | `AccountForm`/`LoginOverlay` removed; `AccountSection` rewritten (name, email, provider, Log out + confirm) |
| `data/online/OnlineManager.kt` | old `signUp/signIn/signOut` replaced by `accountHost` (the bridge); `skipLogin` kept |
| `data/online/FirebaseGateway.kt` | old email-account block removed (anonymous sign-in for Online Approval is unchanged) |
| `ui/components/Common.kt` | `PrimaryButton` + optional `loading` spinner (default off, nothing else changes) |
| `ui/AppViewModel.kt` | + `val auth` so the saved login is checked at every start |

## Security and session
* Passwords go straight to Firebase over TLS. Firebase keeps only a salted hash. The app never stores, logs or
  caches a password; the in-memory copy is cleared on success / screen change.
* The login persists across restarts (Firebase's own storage, refreshed tokens). `AuthStore` keeps only
  uid / name / email / provider so the UI is right at once and offline.
* At every start the saved login is checked with the server: a deleted or disabled account (or revoked token) logs out;
  being offline or slow never does. Logins made with the *old* Settings form are adopted automatically.
* "Wrong password" and "no such account" give the same message. Forgot password says "if an account exists..."
  either way, with a 30 s resend cooldown. Firebase rate-limits too (`Too many tries`).
* Password rule on sign-up: 8-64 characters, letters and numbers. Log in only needs a non-empty password (older accounts).
* All Firebase calls have a 20 s timeout; offline gives "No internet connection". Every button is disabled while an action
  runs, and the repository refuses a second action (BUSY) even if a screen forgot to.

## Rules you should know about
1. **Trusted-phone pairing (Online Approval) is bound to this phone's Firebase uid.** Sign-up and Google sign-in
   *link* to the phone's existing anonymous identity, so the uid (and the pairing) survive. Logging in to an account
   that already exists elsewhere, or logging out, changes the identity, so both are refused while a trusted phone is
   connected ("Disconnect the trusted phone first"). This was already the rule; it is kept on purpose.
2. Firebase **Anonymous** sign-in must stay enabled (Online Approval needs it).
3. Email verification, change password, delete account and profile editing are **not** part of Task 1.

## Required external setup (nothing below is done for you)
Without it the app builds and runs; email auth says "Accounts aren't set up in this build" and the Google button says
"Google sign-in isn't set up in this build". Nothing pretends to work.

### A. Email + password
1. Firebase console > Authentication > Sign-in method > enable **Email/Password** (leave "Email link" off).
2. Make sure `firebase.properties` (or the `FOCUSMODE_FB_*` variables) has apiKey, appId, projectId, databaseUrl.
   Your current `appId` is a *web* app id; email and Google login work with it, but register the Android app
   `com.focusmode.app` and use its `1:...:android:...` id (also needed for push, see `ONLINE_APPROVAL.md`).
3. If your API key has restrictions in Google Cloud > Credentials, allow the Android app (package + SHA-1) or login
   requests are rejected. A key restricted to "HTTP referrers" will not work from Android.
4. Optional: Authentication > Templates > Password reset: set the sender name and language. Reset mails often land in spam.

### B. Google sign-in
1. Firebase console > Authentication > Sign-in method > enable **Google**, choose a support email, save.
2. Project settings > Your apps > Android app `com.focusmode.app` > **Add fingerprint**: add the SHA-1 (and SHA-256) of
   every key you run with. Debug key: `./gradlew signingReport` (or
   `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android`).
   Also add your release key's SHA-1 and, if you publish on Google Play, the **Play App Signing** SHA-1
   (Play Console > Setup > App signing). Adding a fingerprint makes Firebase create the Android OAuth client in the
   same Google Cloud project; without it the Google sheet fails to open.
3. Copy the **Web client ID** (Authentication > Sign-in method > Google > *Web SDK configuration*; it ends in
   `.apps.googleusercontent.com`). It must be the **Web** client, not the Android one.
4. Put it in `firebase.properties` as `googleWebClientId=...` (or env `FOCUSMODE_GOOGLE_WEB_CLIENT_ID`), then rebuild.
5. The phone needs at least one Google account and Google Play services. Debug builds show Google's technical reason
   under the error text (almost always a wrong SHA-1 or the wrong client id).
6. The "G" on the button is a plain placeholder; swap in Google's official logo asset before a store release.

## How to test
Fresh start for each: clear app data (or reinstall).
1. **Email sign-up:** finish onboarding > account screen. Press *Create account* empty: each field shows its message.
   Type a bad email, a 5-letter password, mismatching confirm: matching messages. Fill correctly > spinner on the
   button, fields locked > "Account created / Welcome, <name>!" > Continue > Home. Console shows the new user.
2. **Duplicate guard:** tap *Create account* repeatedly: only one request, one account. Turn on airplane mode first:
   "No internet connection", form stays filled, nothing created.
3. **Existing email:** sign up again with the same email: "This email already has an account. Log in instead."
4. **Log out:** Settings > Account > Log out > confirm. Card changes to "Not logged in".
5. **Email login:** Settings > Log in or create account > correct credentials > "You're logged in". Wrong password:
   "Wrong email or password...". Many wrong tries: "Too many tries".
6. **Forgot password:** Log in screen > Forgot password? > email > "Send reset link": message appears, button counts down
   30 s. Open the mail, choose a new password, log in with it. An unknown email shows the same message (no mail is sent).
7. **Google:** *Continue with Google* on Sign up or Log in > pick account > success screen. Cancel the sheet: nothing
   happens, no error. Log out > Google again: the account chooser is shown again.
8. **Session:** log in, swipe the app away, reopen (also after a phone restart): still logged in, no screen. Delete the
   user in the Firebase console, reopen with internet: logged out within a few seconds.
9. **Skip:** first launch > *Skip for now*: Home, never asked again; Settings still offers login.
10. **Trusted phone rule:** connect a trusted phone, then try Log out: refused with the "Disconnect first" message.
11. Rotate the phone on each screen: typed text stays. Landscape / small phone: the form scrolls above the keyboard.

## Fixed debug key (v5)
Debug builds are signed with `signing/rewire-debug.jks` (public, passwords `android`, alias `androiddebugkey`), so the
SHA-1 never changes between builds or machines. Add THIS fingerprint once in Firebase (Project settings > Your apps >
com.focusmode.app > Add fingerprint):
- SHA-1:   E1:63:90:FC:05:82:4D:D3:04:C2:B5:B1:4E:28:35:FF:4E:AB:B4:F0
- SHA-256: FE:73:50:A9:36:8F:85:CF:0F:F9:34:F5:CA:11:1C:42:07:12:D9:F9:B9:E2:04:77:54:03:6A:2C:A1:44:BC:36
The first install with this key needs the old app uninstalled (different signature).

## v7 additions
- Adult Content Protection: "Your own links and words" (`data/AdultCustom.kt`, `AdultBlockStore.addCustom`). One box: a link / website becomes a blocked
  site, anything else a blocked word checked in the browser's address bar. Works even with the built-in list switch off.
- Website blocking: "Add website" also accepts a plain name ("youtube" -> youtube.com).
- Floating timer: position, size (pill / circle) and lock are remembered per app (`TimerOverlay`, key `pos_<package>`).
