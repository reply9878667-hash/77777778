# Fix: "Prevent changes" no longer locks Focus Mode settings

Focus Mode (separate profiles, session controls) is independent from the phone-wide settings that
"Prevent changes" protects. Now free under Prevent changes:

- Switches under the ReWire ring / Default controls (FocusPolicy.canSetControl)
- OFF method, Study Check-In, plant check-in timing, Restore after restart
- Auto Focus card + dialog
- Saved Focus Profiles (choose / edit / delete / blocked apps inside a profile)

Still locked by Prevent changes: phone-wide blocked apps, limits, emergency apps, content/website lists,
app lock, unlock method and other ReWire settings.

A running session's own rules ("Allow changing settings", "Allow app changes") still apply as before.

New helpers in FocusState: `canChangeFocusSettings`, `canEditFocusProfiles`.
Files: FocusStore.kt, Policy.kt, FocusProfileStore.kt, FocusControlsCard.kt, PlantScreen.kt,
SettingsScreen.kt, FocusApp.kt, ChangeLockTest.kt (updated + new tests).
