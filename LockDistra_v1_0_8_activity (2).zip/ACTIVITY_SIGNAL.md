# Activity signal (who still uses ReWire)

- When the app is opened and an account is signed in, `ActivityPing.flush` runs. At most once a day it:
  1. reads `users/<uid>/seenDay` (one number),
  2. writes ONE atomic update: `users/<uid>/seenDay = today`, `stats/seen/dNNNNN +1`, `stats/seen/d<old> -1`
     (first time only: `stats/measured +1`).
- Every person is in exactly one day bucket (the last day they opened the app), so the admin panel only reads
  `stats/seen` (last 31 days) and `stats/measured`: a few hundred bytes, however many users there are.
- No Worker change. The only server-side change is `firebase/database.rules.json` (publish it in the Firebase console).
