# FocusMode v4 – 5 updates

1. Full-screen background: `FocusBackground` (ui/components/Effects.kt) is drawn once behind the whole app
   (edge to edge, behind status + navigation bars). Per-screen opaque backgrounds were removed.
2. Home cleaned: Blocking tiles (Apps/Limits/Emergency/Inside), Seed card, Educational Shorts card and the
   Emergency card are gone. Home = header, setup notice, Focus timer, session controls.
3. Emergency lives in the per-app slide-up panel (`AppRestrictionSheet`), opened by tapping an app or switching it on.
   Usage-limit emergency stays in the limit editor opened from the same panel.
4. Apps: YouTube shows Complete blocking / Usage limit / Shorts blocking, always visible. Apps with Reels/Status/
   Spotlight get their own switch directly under the app. "Inside apps" and "Educational Shorts" moved into Apps.
5. Focus screen (`SessionScreen`): back button, timer, plant growing with the session clock, one motivational line.
   Back keeps the session running; Home shows a floating Focus icon (`FloatingFocusButton`) that reopens it.
