# Onboarding – Part 2A: seven questions (basic UI + navigation)

Welcome (Part 1) -> Question 1 ... Question 7 -> placeholder "finished" hook. Part 1 is untouched except one
additive parameter. Nothing is stored (no login, database, profile, cloud).

## Files
| File | Change |
|---|---|
| `data/OnboardingQuestions.kt` | NEW. The 7 questions (ids, labels, type, optional flag) and `OnboardingAnswers` (immutable; typed readers; saved-state encoding). Plain Kotlin, JVM tested. |
| `ui/onboarding/QuestionsScreen.kt` | NEW. Header (Back, "Question n of 7", 7-segment progress), the same `FocusBuddy`, question in `BuddySpeechBubble`, options, Next/Finish. Portrait + landscape. |
| `ui/onboarding/OnboardingFlow.kt` | EDITED. `OnboardingStep { Welcome, Questions }`, holds step / question index / answers (rotation-safe), step transition. |
| `ui/onboarding/WelcomeScreen.kt` | 2 lines: new parameter `skipIntro: Boolean = false` (default = Part 1 behaviour). Used when Back is pressed on question 1. |
| `test/.../OnboardingQuestionsTest.kt` | NEW. Question order/options, optional rule, Next gating, toggling, round trip. |
| `FocusApp.kt`, theme, other screens | NOT changed. |

## Behaviour
- Q1 name (text, required, max 30) - Q2 goal (single) - Q3 distractions (multi) - Q4 phone time - Q5 session - Q6 daily goal - Q7 source (optional).
- Next is disabled until a required question is answered; Q7 can be finished with no answer. Q7's button says "Finish".
- Back (button or system back): n -> n-1; Q1 -> Welcome. Answers are kept both ways.
- The mascot "types" each new question once; going back shows it instantly. Tap the bubble to skip typing.
- "Set my own goal" (Q6) only records the choice `custom`; asking for the number is for Part 2B.

## Hooks for Part 2B
- `OnboardingFlow(onFinished, onQuestionsFinished: (OnboardingAnswers) -> Unit = {})`. On Finish, Part 2A calls
  `onQuestionsFinished(answers)` then `onFinished()` (so the app continues as before: login question, then Home).
  Part 2B: add `OnboardingStep.Celebration`, move to it instead of calling `onFinished()` in the `onNext` of the last question, call `onFinished()` after it.
- Read answers with `answers.name`, `.goal`, `.distractions`, `.phoneTime`, `.sessionLength`, `.dailyGoal`, `.source` (option ids from `OnboardingQuestions`).
- `welcome_done` is still set only by `onFinished`, so quitting mid-questions shows the welcome again next launch.

## Testing
1. Clear app data (the welcome shows once) and launch. After the splash: welcome -> Let's Start.
2. Q1: Next is disabled until a name is typed; keyboard Done also moves on.
3. Go through Q2-Q7; check Q3 allows several picks and Q7 Finish works with nothing selected.
4. Press Back repeatedly (button and system back): earlier answers are still selected; Q1 -> Welcome (no replay) -> Let's Start again.
5. Rotate on any question: step, question and answers stay. Try a small phone and landscape.
6. Finish: the app continues to the usual login question / Home.
7. Unit tests: `./gradlew testDebugUnitTest`.
