# Adult Content Blocking (built-in blocklist)

One switch on **Blocked apps → Adult Content Blocking**. When it is on, ReWire's accessibility service reads the
address bar of the supported browsers (the same mechanism as Website blocking) and closes any adult site that is in the
list stored on the phone. No manual entries, no screen/AI monitoring, no internet needed. It works without a focus
session, like Bedtime Mode. Turning it OFF follows the usual lock rules (not allowed while a session runs or settings
are locked).

## What is in the box

| Piece | File |
|---|---|
| Matching, parsing, validation, binary-search index | `data/AdultBlocklist.kt` |
| Switch, local database install, update state, attribution | `data/AdultBlockStore.kt` |
| Optional safe download | `data/AdultListUpdater.kt` |
| Enforcement | `service/AppBlockerService.kt` (`enforceWebsite`) → block screen `REASON_ADULT` in `BlockActivity.kt` |
| UI | `ui/screens/AdultBlockingCard.kt` |
| Bundled database | `assets/adult_blocklist/adult_domains.txt` + `manifest.json` |
| List builder + tests + CI template | `tools/` |

## IMPORTANT: the bundled list in this zip is only a starter set (178 domains: 113 from the published list + 65 well-known sites added by hand)

The sandbox this was built in had no internet access for scripts. The seed holds 113 domains copied from the
published **Block List Project "porn" list** (list dated 2026-07-18, ~953,000 entries) and passed through the same
validator. It proves the engine end to end but is **far from full protection**. Before release run once, with internet:

    python3 tools/build_adult_blocklist.py --max 400000
    # writes app/src/main/assets/adult_blocklist/{adult_domains.txt,manifest.json}

`--max` keeps the shortest / fewest-label names first, which gives the most coverage per byte; omit it for everything
(about 20 MB). The script prints how many usable entries each source gave. Entries are never invented: each one is in a
downloaded source. Add more sources with `--file list.txt --name ... --license ... --homepage ...` and check each licence.

## Format and matching

* Database: one lowercase ASCII domain per line, strictly sorted in byte order, unique (`verifyFile` enforces this).
  It is copied to device-protected storage and searched with a binary search on disk (about 20 small reads per lookup,
  ~0.15 ms on 300,000 entries in testing), so memory use stays tiny even for a very large list.
* A listed entry blocks itself **and all its subdomains**, at a dot boundary only (`notbad.com` and
  `bad.com.evil.org` do not match `bad.com`).
* Entries covered by a listed parent are dropped at build time. Entries under a never-block host (Google, Reddit,
  Tumblr, GitHub, free-hosting domains, ...) are dropped at build time and never matched at run time, to avoid
  false positives. The list is kept identical in `AdultBlocklist.kt` and `tools/build_adult_blocklist.py`.

## Optional updates (off until you configure a URL)

Set `adultListUrl=` in `firebase.properties` (or env `FOCUSMODE_ADULT_LIST_URL`) to the raw URL of a `manifest.json`
produced by the tool. Easiest: copy `tools/adult-blocklist.yml` to `.github/workflows/`, run it, and use
`https://raw.githubusercontent.com/<you>/<repo>/main/adult-blocklist/manifest.json`.
With no URL the app simply uses the bundled list and the card hides the update controls.

The update is applied only if **all** of these hold, otherwise the working list is left untouched:
HTTPS and a trusted host (raw.githubusercontent.com, github.com and their asset hosts, or the host of your URL), every
redirect hop checked; manifest well-formed with a newer version; download size cap (80 MB); SHA-256 equals the manifest's;
file passes the sorted/unique/valid-domain check; entry count equals the manifest's; at least 50 entries; not less than
half the size of the current list. The new file is written to a staging file and moved over the live one atomically.
An automatic check runs at most weekly while protection is on (can be switched off on the card).

## Attribution

`manifest.json` records each source's name, homepage, licence, retrieval date and entry count. The card's
"List sources" shows them. The Block List Project states its list is open source (its repository README says
Unlicense, the list header says MIT, both permissive); keep this attribution when you ship.

## Limits (honest)

* Only the supported browsers' address bars are read (Chrome, Edge, Brave, Firefox, Samsung Internet, Opera, Vivaldi,
  DuckDuckGo). Sites inside other apps' built-in viewers, private tabs that hide the URL, or browsers not listed are not
  covered. New / unlisted adult sites are not caught: any list is incomplete.
* Needs the ReWire Accessibility service enabled. Following the phone's clock/permissions like the rest of the app.
* Not compiled or run here: there was no Kotlin/Android toolchain in the build sandbox. The Python tool tests
  (`python3 tools/test_build_adult_blocklist.py`) pass, and the binary-search algorithm was checked in Java on the real
  seed and on a 300,000-entry file with 0 failures. Please run `./gradlew testDebugUnitTest` (new
  `AdultBlocklistTest`, 12 cases) and try it on a phone.

## Device checklist

Switch on (card shows the count) → open Chrome → type a listed domain → block screen → "Go to home screen";
subdomain of a listed domain; a normal site still opens; airplane mode still blocks; reboot then blocks; switch off
during a session is refused; switch off between sessions removes the block screen; update with a bad URL leaves the
count unchanged; update with a valid manifest raises the count.

## Update (why "enable does nothing" happened, and what changed)
Cause: the bundled list had only 113 domains and none of the big sites; no update URL was set, so it never grew.
Done here (not compiled / not run on a device): +65 well-known domains in the seed (validated with the builder's own rules,
manifest count and sha256 updated); the card now says "starter list - limited protection" while the list has < 5,000 entries;
a bigger bundled list of the same version now replaces a smaller bundled one (never a downloaded one).
STILL NEEDED for full protection: run `python3 tools/build_adult_blocklist.py --max 400000` once with internet (see above).

## Update 2 - real blocking in every browser and app (DNS filter)
Cause of "switch ON but adult sites still open": the only enforcement was the accessibility service reading the address
bar of a few browsers, against a 178-domain list. Any other browser, a hidden / renamed address bar, an in-app browser or
any site not in the tiny list simply opened.
Fix:
* `service/AdultDnsVpnService.kt` - a local, DNS-only VPN (only one fake DNS address is routed into it; the rest of the
  traffic is untouched). Blocked names get 0.0.0.0 / ::, so the page cannot load in ANY browser or app. All other names go
  to a family-safe resolver (CleanBrowsing Adult filter, fallback Cloudflare Family) which blocks adult sites that are not
  in the local list and forces SafeSearch. DoH host names are refused and the best-known DoH IPs black-holed so browsers
  fall back to this filter.
* `data/AdultDns.kt` - DNS / IPv4-UDP packet code (pure Kotlin, unit tested in `AdultDnsTest`).
* `AdultBlocklist.looksAdult` - adult-looking names (porn, xxx, hentai, ...; ".xxx/.porn/.sex/.adult") are blocked even
  when not in the list; never-block hosts and a small not-adult list (essex, xxxlutz, porn-recovery sites) are exempt.
* The card asks for the one-time Android VPN permission when the switch is turned ON, shows "Active in every browser and
  app", and offers "Turn on full protection" if it is not running. Warns when Private DNS is set to a provider name.
* The filter restarts after reboot / app update (`BootReceiver`) and whenever the app opens.
* The address-bar check with the block screen stays as a second layer.
Limits: Android's own Private DNS set to a provider name, or a user-added VPN, can skip the filter (the card warns); the
filter needs internet to reach the family-safe resolver (the local list still works offline). Not compiled with the Android
toolchain here; DNS and name-detection code were compiled and tested with kotlinc. Please build and try on a phone.
