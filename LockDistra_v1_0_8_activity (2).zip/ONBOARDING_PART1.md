# Onboarding – Part 1: mascot + welcome screen

What a new user sees: after the splash, a mascot (a violet sprout buddy, the app's plant with a face) pops in,
waves, says the welcome message in a speech bubble, thinks for a moment, and waits for **Let's Start**.
Pressing the button ends Part 1 and the app continues exactly as before (the existing login question, then Home).

## Files (all new, except 3 small edits in FocusApp.kt)
| File | What it is |
|---|---|
| `ui/onboarding/FocusBuddy.kt` | The mascot. One Canvas, gradients + gloss + soft shadows (depth), no image files. `BuddyPose`: Idle, Greeting, GreetingTalking, Talking, Thinking. Blinks, breathes, looks around, sways. Poses glide into each other. |
| `ui/onboarding/BuddyComponents.kt` | `BuddySpeechBubble` (with pointer) and `TypedText` (typewriter, keeps the bubble size fixed). Reused by Part 2. |
| `ui/onboarding/WelcomeScreen.kt` | The welcome screen: portrait and landscape layouts, typed message, Let's Start button. Tap the bubble to skip typing. |
| `ui/onboarding/OnboardingFlow.kt` | Entry point of the flow. Part 2 adds its steps here. |
| `data/OnboardingStore.kt` | One saved flag (`welcome_done`), the first-launch rule, and the typewriter helper. |
| `test/.../OnboardingTest.kt` | JVM tests for the rule and the typewriter (emoji are never cut in half). |
| `ui/FocusApp.kt` | 3 small edits: show `OnboardingFlow` on first launch, and hold back the bottom bar / login question until it is done. |

## Why 2D and not 3D
A real 3D character needs a 3D engine (Filament / SceneView, ~10+ MB) plus modelled and rigged assets. The project has
neither, and forcing it would look worse and cost performance. So the mascot is a shaded 2D character with
3D-style depth (radial lighting, gloss highlight, contact shadows, breathing squash). It uses the app's own palette
(`FocusTheme` colours: violet + leaf green + blossom pink) and follows light/dark theme.

## Testing it
The welcome shows once. To see it again: clear the app's data, or uninstall and reinstall.
By default **everyone** sees it once, including people updating an old install (easy to test).
To show it only on fresh installs, set `OnboardingRules.SKIP_FOR_EXISTING_INSTALLS = true`.

## Ready for Part 2
- Add steps in `OnboardingFlow` and change `onContinue` in the welcome call from `onFinished` to "go to the first question".
- Per question: `FocusBuddy(pose = BuddyPose.Thinking / Talking / Idle ...)` + `BuddySpeechBubble { TypedText(...) }`.
- Call `onFinished` after the last question. Answers can be stored next to `welcome_done` in `OnboardingStore`.
