# v9 changes

* **Circular logos.** The ReWire logo on Home and every app icon (Blocked apps, Limits, Emergency, sheets) is a circle; the app's own icon fills it.
* **New splash.** Only the cartoon buddy waving ("Hey there!"), "Welcome to ReWire", and a small "By Re Arena" watermark at the bottom, then the app opens (about 2.8 s). The Android 12+ system splash shows no icon, so no other logo flashes first (`res/drawable/splash_empty.xml`).
* **Less cloud data.** The server now holds only `users/{uid}/profile` (name, email, sign-in type, avatar id, times) and `users/{uid}/onboarding` (name + finish time). The profile photo, the onboarding answers and every setting stay on the phone. A new photo no longer causes any network call. `firebase/database.rules.json` no longer accepts a photo or the answers, so nothing extra can be stored. **Publish the rules again** (Firebase console > Realtime Database > Rules).
* Fixes from the first compile: `FocusBuddy.kt` (Animatable -> State via `asState()`), `FocusApp.kt` (missing `dp` import, qualified `AnimatedVisibility`).

## Fix: Focus Mode no longer closes Settings (v2.1)
- Uninstall protection now uses ONE narrow rule during a focus session and between sessions: only
  ReWire's own app-info / uninstall / force-stop / device-admin / "turn off ReWire" screens and the
  installer's uninstall dialog are closed. All other Settings screens work normally.
- Hindi labels (अनइंस्टॉल, फ़ोर्स स्टॉप, ...) added to the dangerous-action list.
- Change: AppBlockerService.isProtectedScreen + dangerousActions.

## Start popup + Lecture Lock for any platform (v3)
- The start popup now ALWAYS ends with "How to turn it OFF" (Normal / Password / Online), also when a Focus
  Profile exists (before, that step was skipped for people with a profile). Nothing starts before it.
- Lecture Lock accepts a link from ANY platform (YouTube, Facebook, Instagram, Vimeo, any website, Google Drive,
  direct video files). When Focus Mode starts, the lecture opens by itself in ReWire's own player
  (LectureActivity). The player can show only that video: other pages / videos are cancelled and the lecture is
  loaded again; YouTube plays through its embedded player (no related videos).
- While the session runs, the lecture platform's own app (YouTube, Facebook, Instagram, Vimeo, X, Twitch,
  Dailymotion) and its site in the supported browsers are closed, so no other video of that platform can play.
  Emergency access / extra time for that app lifts this, like every other rule.
- Removed: LectureGuard (YouTube-app screen reading). New: LectureLink (parser, platforms), LectureActivity.

## Fix: Auto Focus now starts with the app closed (v5)
- Cause: only the app's screen (a Compose loop) checked the Auto Focus schedule, so with ReWire closed / killed it never
  started. 
- Now `service/AutoFocusEngine.kt` does the work and is woken by (1) an AlarmManager alarm for the start time (survives
  the app being closed), (2) the Accessibility service poll loop (~every 15 s), (3) boot, app update, time / time-zone
  change and app process start. `process()` starts each window only once.
- Exact alarm is used when "Alarms & reminders" is allowed for ReWire; otherwise an inexact while-idle alarm, with the
  Accessibility service as the backup while the phone is awake.

## Google sign-in: clear error reasons (v6)
- Debug builds now say WHY "Continue with Google" fails: empty googleWebClientId / missing Firebase values, Google's own
  error type, and THIS build's SHA-1 (data/auth/AppSignature.kt) to add under Firebase > Project settings > Android app >
  Add fingerprint. Release builds keep the plain messages.
