# Share to ReWire (Lecture Lock)

ReWire now appears in the Android Share list (plain text / links). Share a video from YouTube, Instagram, Facebook ... to ReWire:

1. ReWire opens on the start wizard's **link page**, with the link already filled in (Next button).
2. The remaining wizard steps follow (what is blocked, info, what stays possible, ..., Turn OFF method last).
3. After the last step Focus Mode starts and the lecture opens by itself in ReWire's player (Lecture Lock rules as before).

Rules
- Nothing starts from the Share itself: every wizard step must still be passed.
- If a Focus / Pomodoro session is already running, a message is shown and nothing changes.
- If accessibility is not on yet, the permission screen comes first, then the wizard.
- With app lock on, the wizard opens after unlocking.
- Shared text without a usable video link shows "No video link found in what was shared."

Changed files
- `app/src/main/AndroidManifest.xml` (SEND / text/plain filter on MainActivity)
- `MainActivity.kt` (reads the shared text), `ui/AppViewModel.kt` (`sharedLink`)
- `ui/FocusApp.kt` (opens the wizard with the link), `ui/screens/StartWizard.kt` (`initialLink`, link page first)

Not compiled or run here (no Android SDK): build it with your GitHub Actions workflow.
