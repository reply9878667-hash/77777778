# Online Approval unlock

Settings > **Unlock method**: Password (as before) / Online / Both.

## How it works
1. Phone A (gets locked) > Settings > **Generate my private connecting key** shows a one-time code with **Copy key** and **Share** buttons. Phone B > Settings > **Paste connector code** (paste button reads the clipboard, a whole chat message works too).
   A asks "connect this phone?" and then shows a one-time **recovery code**.
2. Choose *Online* or *Both*. On A's lock screen tap **Request to Unlock**. B gets a push and an *Unlock requests* screen with
   Approve / Reject. Approve opens A at once. Reject or 2 minutes of silence keeps A locked and shows the status.

## Request to unlock one app (v2.6)
Works once a trusted phone is connected (any unlock method). When an app is closed because of a **focus block**,
its **daily limit**, or its **Shorts / Reels limit**, its block screen ("Time's up for today." / "Stay with it.") has a
**Request to unlock** button.
1. Tap it. The trusted phone gets a push: *"Your other phone wants more time in Instagram"*. (You can leave the block
   screen; the answer still arrives.)
2. On the trusted phone the *Unlock requests* screen shows the app, why it is closed, quick picks (5 min, 15 min,
   30 min, 1 h) and a box to **type the minutes** (1 to 240). **Approve** opens that app for exactly that long;
   **Reject** keeps it closed. No answer in 2 minutes = closed.
3. The app opens by itself on the locked phone (and a notification says for how long). When the time is over the app
   is closed again by itself, with the same block screen.

What the extra time lifts: that one app's focus block, its daily limit, and its Shorts / Reels limit. It does not lift
anything for other apps, the Android Settings block, uninstall protection, or ReWire's own sections rules.
Emergency access and its counters are untouched. Usage keeps being counted during the extra time.

Security: the request carries the app, its name and the reason inside the signed text; the answer carries the minutes
inside its proof. The locked phone checks the proof before opening anything, so the database alone (or a changed app name)
can't grant time, and a normal unlock answer can't be turned into app time (or the other way round). Within one boot the
window runs on the phone's monotonic clock, so changing the date does not stretch it.

**After updating from v2.5 you must redeploy two server pieces** (the app alone is not enough):
`firebase/database.rules.json` > Firebase console > Realtime Database > Rules > Publish, and in `worker/`: `wrangler deploy`
(the Worker now puts the app name in the push).

## Setup (once)
1. Firebase console > Authentication > Sign-in method > enable **Anonymous**.
2. Realtime Database > Rules > paste `firebase/database.rules.json` > Publish.
3. Build values come from `firebase.properties` (git-ignored) or env vars / GitHub secrets
   `FOCUSMODE_FB_API_KEY, _APP_ID, _DATABASE_URL, _PROJECT_ID, _SENDER_ID, FOCUSMODE_APPROVAL_WORKER_URL`.
4. Push (optional but recommended): Firebase console > Project settings > Cloud Messaging: make sure *Firebase Cloud Messaging API (V1)*
   is enabled. Register an **Android app** `com.focusmode.app` and use its appId (`1:...:android:...`) in `firebase.properties`.
   Then in `worker/`: `npm i -g wrangler`, `wrangler secret put FCM_SERVICE_ACCOUNT_JSON` (paste the service-account JSON from
   Project settings > Service accounts > Generate new private key), `wrangler deploy`, and put the Worker URL in `workerUrl`.
   Modern FCM uses a service account, not an "API key"; never paste it in chat or commit it.
   Without the Worker everything still works, but B only sees requests while ReWire is open on it.

## Security model
- Anonymous Firebase login per phone + RTDB rules (`firebase/database.rules.json`): only the linked trusted phone can answer,
  only before 120 s, only once (pending > approved/rejected > consumed), server clock (`now`) decides time.
- End-to-end proof: pair key (derived from the typed code, stored in Android Keystore) signs requests and answers; A verifies
  the proof, the answering uid, device id and nonce locally before unlocking. Used request ids are remembered (single use).
- Fails closed: Online/Both keep the lock up even if pairing data is unreadable; recovery code is the way in.
- Leaving Online mode or disconnecting asks for the recovery code (or PIN/password).

## Tests
- `cd worker && npm test` (push worker, 10 tests, run).
- `cd worker && npm test` now has 12 tests (push for app requests included).
- `./gradlew test` includes `OnlineUnlockTest` (mode rules + protocol) and `AppUnlockTest` (app requests, minutes, grant clock). Not run here (no Android SDK).

## Notification fixes (v2.6.1)
- The trusted phone now asks for notification permission by itself (Android 13+) when its *Unlock requests* screen opens
  or right after connecting, and shows an **Allow notifications** card while it is off (also when the "Unlock requests"
  channel was switched off in system settings).
- If the trusted phone can't register for push (web app id instead of an Android one, no Play services, no internet), the
  *Unlock requests* screen says why instead of failing silently.
- The locked phone retries the push once on a network error or a 5xx from the Worker.
- The build warns when `appId` is not an Android app id (`1:...:android:...`) or `workerUrl` is empty.

## Trigger-based, nothing runs in the background (v10.8)
No always-on service, no timer, no permanent listener. Things happen only on a trigger:

1. Locked phone: the person taps *Request to unlock* -> the request is written to the database -> ONE call to the Worker
   (`POST /notify`, `{"requestId": ...}`) -> the Worker pushes to the trusted phone. Then the locked phone listens to that one
   request for at most 2 minutes.
2. Trusted phone: the push shows the notification and opens a live listener for one request lifetime (about 2 min), then it
   lets go. Opening the Unlock requests screen listens only while that screen is open.
3. The push token is sent to the Worker once (again only when Firebase issues a new one, after pairing, or after 7 days).
4. Nothing connects at app start. If the live connection is blocked, a fallback checks the single request every 3 s, 6 s, 12 s
   ... (max 20 s) and only while that connection is down.
Without a `workerUrl` there is no push: the trusted phone sees requests only while the Unlock requests screen is open.

## Less data, nothing left behind (v2.6.3)
- The trusted phone's listener only asks for requests with status `pending` (rules: `.indexOn` now has `status`), so
  answered or old requests are never downloaded. While idle, only the small connection keep-alive uses data.
- The phone that asked deletes its request from the database right after the answer (approved, rejected, expired,
  cancelled or invalid). The rules already let only the owner delete. Leftovers older than 3 minutes (phone off,
  app killed) are swept at the next request. Pairing invites and claims were already deleted after pairing.
- **Re-publish `firebase/database.rules.json`** (the `status` index is new); otherwise the trusted phone's listener errors.

## Optional login and Re Arena notifications (v2.7)
- First launch shows a **Welcome / login** screen (Create account, Sign in, **Skip for now**). It is asked once; Settings > **Account**
  has the same form later. Email + password via Firebase Authentication. Console: Authentication > Sign-in method > **Email/Password** > Enable
  (the first switch; Email link is not needed). Anonymous must stay enabled too.
- **Create account** upgrades the phone's existing anonymous login, so its identity (uid) does not change and an already connected trusted
  phone keeps working. **Sign in** (existing account, e.g. after a reinstall) is refused while a trusted phone is connected; disconnect first.
- The name typed at sign-up becomes the phone's name: the trusted phone shows "Prince Yadav wants to unlock ReWire" on the request card and in
  the notification, instead of a phone model. Skipped login = the phone model, as before. Only the name and email are kept locally; the password is not.
- The request notification on the trusted phone carries "Re Arena" as its sub-text and the channel is named "Re Arena unlock requests".
  Android always prints the app's own label (strings.xml `app_name`) at the top of a notification, and a normal app can't override it. To show
  "Re Arena" there too, change `app_name` in `res/values/strings.xml` (that also renames the launcher icon).

## Connecting two phones (v2.7.1)
1. Phone A (the one that gets locked): Settings > Trusted phone > **Generate my private connecting key**. Tap **Copy key** or **Share** and send it to phone B.
   Keep that dialog open: the key works once, for 10 minutes, and A must be online.
2. Phone B: Settings > **Paste connector code** > Paste > Connect.
3. Phone A asks "Connect this phone?" > Yes. From then on only B receives and answers A's unlock requests.
A new key can be made any time ("New connecting key"); a used or expired key is useless.
