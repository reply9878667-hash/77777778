# Player: black dot after skipping fixed + "Add bookmark" at the bottom

Black dot: the player page had no `endmsg` / `endsub` elements, so `resetEnd()` threw an error every time the video went to
"playing". That stopped `showCtl()` / `setIcon()` right after it, so after a skip the controls did not appear and a big EMPTY black
cover badge (meant to hide YouTube's own spinner) stayed in the middle. Fixed: the elements exist now, the helpers are null-safe,
and the cover is never an empty big dot any more (spinner badge 64 px, short leftover badge 30 px).

Bookmarks (own player, portrait, strip at the bottom of the screen):
* "Add bookmark": pauses at the current second, a small bottom form (not full screen) takes a topic / heading; Save (or keyboard Done)
  stores it and the video plays on. Empty text is saved as "Bookmark at 12:34". Same second = replaces.
* "Bookmarks (n)": list of this video's bookmarks sorted by time; tap = jump there and play; bin icon = delete.
Files: `data/LectureBookmarks.kt` (new), `ui/lecture/BookmarkUi.kt` (new), `LectureActivity.kt`, `ui/lecture/LecturePlayerHtml.kt`,
`test/.../LectureBookmarksTest.kt` (new). Not compiled and not run on a device.

## Bookmarks on the server (v1.0.8)
* Saved per account at `users/{uid}/bookmarks/{youtubeVideoId}` (`data` = JSON text, `updatedAt`, `v`). Needs a login; without one they stay on
  the phone and the list says "Log in to keep your bookmarks on the server."
* The phone always saves first (works offline). Then `LectureBookmarkRemote.sync` downloads the server copy, joins both
  (`BookmarkRules.merge`: per bookmark the newer change wins; a delete is kept as a mark for 30 days so it reaches other phones) and
  uploads the result. It runs when the player opens and after every add / delete. Failed (offline) = tried again at the next sync.
* **Publish `firebase/database.rules.json` in the Firebase console (Realtime Database > Rules)**, otherwise the server refuses the write
  and the list says "No connection..." although the internet works.
* Only the account owner can read / write; only real 11-character YouTube ids; max 60 000 characters per video.
Files: `data/LectureBookmarks.kt` (store + remote), wiring in `LectureActivity.kt`, `ui/lecture/BookmarkUi.kt`,
`firebase/database.rules.json`, `test/.../LectureBookmarksTest.kt`. Not compiled and not run on a device.
