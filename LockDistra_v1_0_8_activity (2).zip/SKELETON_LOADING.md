# Task 1A: YouTube-style skeleton loading + search spinner (Study tab)

* `ui/components/Skeleton.kt` (new): `rememberShimmerShift`, `Modifier.shimmerFill` (grey placeholder + light band sliding
  left to right, one band across the whole screen so all shapes shine in step), `VideoSkeletonList`, `ShortSkeletonGrid`,
  `ShimmerFill`, `SkeletonLine`, `SearchLoading` (circular spinner + "Searching"). Speed: `SHIMMER_SWEEP_MS`.
* `StudyScreen.kt`:
  * Home feed: skeleton (video: 16:9 picture + channel logo + 2 title lines; Shorts: tall cards) while the feed loads and
    nothing is cached. First frame is already the skeleton (no flash of "Nothing here yet"). Skeleton, spinner and content
    cross-fade into each other.
  * Thumbnails / channel logos: shimmer until the picture is downloaded, then fade in (pictures already in memory show at once).
  * Search: old results are cleared, a centred circular spinner shows, and it disappears when results (or an error) arrive.
    A failed search shows "Search failed" + the reason + "Try again" (retries the SAME search). Older answers that arrive
    late are ignored (no wrong results after a quick second search). "Load more" and refresh keep the small bottom spinner.
  * Channel page: skeleton for the first load of its videos / Shorts and for the numbers line.
* Backend (`StudyApi`, `StudyRepository`, rules, cache) is untouched.
Not compiled or run here (no Android SDK).
