# Lecture player: Background play (floating window) + Repeat

Where: the gear button of the lecture player (the same menu as Quality). New "Options" rows, both OFF by default and remembered per video:
* **Background play (floating window)**: when ON and Home / recents is pressed, the video moves to a small Picture-in-Picture window and keeps
  playing (picture and sound). Tap the window to come back, X to close it (the sound stops). It is NOT audio-only and does not play with
  the screen off or with the window closed: YouTube's API policy requires the video to stay visible, and a key that breaks it can be shut down.
* **Repeat**: when the video ends it starts again, until the switch is turned OFF. While Repeat is ON the lecture never "ends", so
  "turn Focus Mode off when the lecture ends" does not follow the video any more; Focus Mode then ends by its own timer.

Only for the own (embedded) player. The fallback "normal YouTube page" has no menu and no floating window.
Files: `LectureActivity.kt`, `ui/lecture/LecturePlayerHtml.kt`, `data/LectureLockStore.kt`, `AndroidManifest.xml` (`supportsPictureInPicture`).
Not compiled and not run on a device. Check: switch ON, press Home -> floating window keeps playing; tap it -> back to the lecture;
switch OFF -> Home leaves the app as before; Repeat ON -> video restarts at the end; Focus Mode / blocking still work around the window.

## v39: "Background" button
- A separate **Background** button in the player's top bar (next to Rotate / Close) and a **Background** pill in the player's own controls (next to the gear). Tap = background play ON (shown as "Background: On", highlighted); tap again = OFF. It is the same per-video switch as the gear menu's option, so all three stay in step.
- While ON, pressing Home keeps the video playing in the small floating window (as described above; still not audio-only, by YouTube's API policy). A short message explains this when it is switched ON.
- Only for the own (embedded) player; hidden when the player has switched to the normal YouTube page.
