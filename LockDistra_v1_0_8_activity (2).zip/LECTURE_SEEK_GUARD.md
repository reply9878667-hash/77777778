# Lecture: jumping to the end no longer turns Focus Mode off

Problem: with "turn Focus Mode off when the lecture ends", someone could drag the seek bar to the end and the lecture counted as
finished (two ways: the video's "ended" event, and the safety timer, which followed the video position and became ~2 minutes).

Fix: only seconds that really played are counted. The player itself is unchanged (seek bar, +10 s, double tap, speed all work).
* `data/LectureWatch.kt`: one flag per second of video. A progress report counts only when the position moved forward by what the
  clock and the chosen speed allow (real seconds x speed x 1.3 + 1 s). Jumps are not counted; 2x speed is.
* Focus Mode ends after the lecture only when at least 90 % was watched (intro / a short skip is fine).
* If the end is reached with less than that: Focus Mode stays on, the player shows "Part of this lecture was skipped" with a
  "Watch the skipped part" button that jumps to the first skipped second (normal page mode jumps there by itself).
* The safety timer now follows the part still left to WATCH, not the position, so skipping ahead does not shorten the session.
* Watched parts are saved per video (`LectureLockStore.watched / saveWatched / clearWatched`), so an interrupted lecture keeps its
  credit, and are cleared when the lecture counts as finished. A Study preview is not tracked.

Files: `LectureActivity.kt`, `ui/lecture/LecturePlayerHtml.kt`, `data/LectureLockStore.kt`, `data/LectureWatch.kt` (new),
`test/.../LectureWatchTest.kt` (new). Not compiled and not run on a device.
Check: watch normally (also at 2x) -> Focus Mode ends at the end; drag to the end -> "skipped" message, Focus Mode stays on,
button continues at the gap; skip ~1 minute of a 20-minute lecture -> still ends normally.
