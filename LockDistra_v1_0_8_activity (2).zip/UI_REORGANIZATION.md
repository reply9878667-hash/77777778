# UI reorganization (v10_6)

UI structure only. No storage, blocking, service or permission code was changed.

## Old -> new

| Tab | Before | After |
|---|---|---|
| Apps | "Blocked apps": Bedtime and Adult cards (always open) above the app lists; Website blocking only inside each app's panel | **Blocking**: one "Blocking" section with a card each for Website Blocking, Adult Content Protection and Bedtime Mode (folded, header tap opens), then "App blocking" (Android Settings, YouTube, Inside apps, Popular, All apps) |
| Limits | Floating-timer settings (3 cards) first, then Shorts/Reels/Status, then App limits | App limits first, Shorts/Reels/Status next, Floating timer last as one folded card under "Display" |
| Settings | 10 sections (Appearance, App lock, Account, Unlock method, Prevent changes, Uninstall protection, Focus controls, Permissions, After a restart, About) | 6 sections: Appearance, Account, **Security** (App lock, Unlock method, Prevent changes, Uninstall protection), **Focus** (Default controls, After a restart), Permissions, About |
| Home | unchanged (ring, Pomodoro, live Focus controls) | unchanged |

## Files changed
- `ui/screens/AppsScreen.kt` (Blocking section, title, card order)
- `ui/screens/WebsiteBlockingCard.kt` (new: summary card, opens the existing per-app website panel)
- `ui/screens/BedtimeCard.kt`, `ui/screens/AdultBlockingCard.kt` (foldable header, card renamed to "Adult Content Protection")
- `ui/screens/LimitsScreen.kt` (order, folded floating timer)
- `ui/screens/SettingsScreen.kt` (section grouping, `SettingsSubLabel`)
- `ui/components/BottomBar.kt` (tab label "Apps" -> "Blocking")
- Text-only: `ContentScreens.kt`, `PomodoroCard.kt`, `FocusApp.kt`, `BlockActivity.kt`

## Notes
- `Screen.Apps` keeps its name (only the label changed), so navigation and saved state are unaffected.
- No Keyword Blocking feature exists in the project, so no card was invented for it.
- Not compiled or run: this environment has no Android SDK or network. Build in Android Studio first.

## Logo (v10_7)
New ReWire logo (shield + brain + phone) is used for:
- launcher icon: legacy `ic_launcher.png` (all densities) and adaptive `ic_launcher_foreground` / `ic_launcher_background` / `ic_launcher_monochrome` (themed icon)
- in-app logo `drawable-nodpi/ic_rewire_logo.png`: Home header, splash screen, both "ReWire is locked" screens
- Not changed on purpose: notification small icon (`ic_stat_leaf`, the leaf), the floating focus button leaf, the onboarding buddy. App name stays "ReWire".
