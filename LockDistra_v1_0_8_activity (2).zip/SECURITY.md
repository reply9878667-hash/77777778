# ReWire – security review (v2.3)

This is an honest account of why scanners and Google Play Protect may react to ReWire, what was
changed, and what can only be fixed outside the code. Nothing here hides the app from any scanner.

## Why a scanner can flag this app (real causes)

| # | Cause | Real risk or heuristic? | Status in v2.3 |
|---|---|---|---|
| 1 | **Accessibility service** that reads window content (`canRetrieveWindowContent`, view ids) and can press Back / tap a tab. Spyware and some malware use the same API. | Heuristic, but a real capability. It is needed for Shorts / Reels / Status blocking. | Kept. Declared honestly as `isAccessibilityTool="false"`; description tells the user exactly what is read. Games are never read. The INTERNET permission (added in v2.5 for the optional Online approval) is never used by this service. |
| 2 | **Uninstall protection** (device admin + covering the Settings / installer screens). "Prevents its own removal" is a classic malware behaviour, and Google Play forbids it outside parental-control / enterprise apps. | This is the most likely source of genuine detections. | Kept (it is an existing feature and was required to stay). It is opt-in, never covers Play Protect warning screens (`ALLOW_PLAY_PROTECT_SCREENS`), and is compiled out of the Play build (`-PplayBuild=true`). |
| 3 | **Sideloaded, self-signed APK from an unknown developer.** Play Protect warns about apps it has never seen, and Android 13+ blocks accessibility for sideloaded apps until "Allow restricted settings" is chosen. | Reputation / install-source, not a defect. | See "Installing" below. |
| 4 | **Signing key** committed with its password hard-coded in `build.gradle.kts`, and a release build that fell back to the public debug key when the key was missing. | Real weakness. | Fixed: passwords moved to `keystore.properties` / env vars (git-ignored); release is never signed with the debug key; v1+v2+v3 signature schemes on. |
| 5 | Sensitive permissions: `PACKAGE_USAGE_STATS`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`, `RECEIVE_BOOT_COMPLETED`, foreground service. | Each is used by a real feature; none is declared without use. | Reviewed, none removed (every one backs a feature). The battery request is only shown after an explanation; the Play build uses the plain battery list. |

## What the code review found

Checked for and **not found** (as of v2.4; `INTERNET` was added in v2.5 for Online approval, see the end of this file): `QUERY_ALL_PACKAGES`, `SYSTEM_ALERT_WINDOW`, install / delete
packages, dynamic code loading (`DexClassLoader`), reflection / hidden APIs, `Runtime.exec`,
WebViews, wipe / reset-password device-admin policies, hidden launcher icon, cleartext traffic.
`allowBackup` is off. The only device-admin policy is `force-lock`. Internal receivers are not
exported; the boot receiver treats the vendor "quick boot" actions (which any app could send) as
untrusted – they can restore a session but never end one.

## Installing

- Android 13+: after the first install, if Accessibility is greyed out, open **Settings > Apps >
  ReWire > ⋮ > Allow restricted settings**, then enable the accessibility service.
- Play Protect: tap **More details > Install anyway** once, or use **Play Protect > Scan app**.
  Warnings for unknown-developer apps go away through Play distribution (below), not through code.
- Updating over an existing install works only when the same release key signs it
  (`signing/focusmode-release.jks`). Keep that file private and backed up.

## What cannot be fixed by code

1. **Verified reputation.** Publish the Play build (`./gradlew bundleRelease -PplayBuild=true`) through
   Google Play. Accessibility apps must complete Play's Accessibility API declaration (core
   functionality = digital wellbeing / focus). The Play build omits uninstall protection.
2. **False positives from third-party engines.** Submit the signed APK to each vendor's false-positive
   form (and Google's Play Protect appeal) with the explanation above. Do not obfuscate or repack
   to dodge detection; that makes real detections more likely.
3. **Replace the signing key before a public release.** The key in this repo was generated for
   testing and its password was published in earlier source zips. For Play, use a new upload key
   (or Play App Signing) whose password is never committed.

## Build with the secrets outside the source

    # keystore.properties (git-ignored)
    storePassword=...
    keyAlias=focusmode
    keyPassword=...
    ./gradlew assembleRelease


## Online approval (optional, v2.5)

- Adds the INTERNET permission. The app contacts Firebase only after a trusted phone is connected.
- No push / server secret is in the app. The push service account lives only in a Cloudflare Worker secret.
- Pairing shares a 100-bit secret between the two phones (typed by hand, never uploaded). Every request and every
  approval carries an HMAC made with it, so the database alone can't approve an unlock.
- Requests live 120 s, an approval must be used within 30 s, and each request id works once.
- Offline recovery code (hash only) is the way in if the trusted phone is lost. Details: ONLINE_APPROVAL.md.
- v2.6 "Request to unlock" for one app: the app, its name, the reason and the granted minutes are inside the signed
  request / proof (separate HMAC tags from the lock-screen unlock). A grant lasts 1 to 240 minutes, covers one app, and is
  stored on the phone only after the proof checked out.
