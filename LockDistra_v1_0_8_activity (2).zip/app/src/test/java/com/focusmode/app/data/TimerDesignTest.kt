package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TimerDesignTest {

    @Test
    fun everyDesignHasAUniqueIdAndUnknownIdsFallBack() {
        assertEquals(TimerStyle.values().size, TimerStyle.values().map { it.id }.toSet().size)
        TimerStyle.values().forEach { assertEquals(it, TimerStyle.fromId(it.id)) }
        assertEquals(TimerStyle.CLASSIC, TimerStyle.fromId(null))
        assertEquals(TimerStyle.CLASSIC, TimerStyle.fromId("nonsense"))
        assertEquals(TimerStyle.DEFAULT_ID, TimerStyle.CLASSIC.id)
    }

    @Test
    fun designsShowWhatTheirNamesSay() {
        assertEquals("YouTube · 5 min left", TimerStyle.CLASSIC.text("YouTube", "5 min left"))
        assertEquals("5 min left", TimerStyle.LOGO_TIME.text("YouTube", "5 min left"))
        assertEquals("5 min left", TimerStyle.TIME_ONLY.text("YouTube", "5 min left"))
        assertEquals("5 min left", TimerStyle.CLASSIC.text("", "5 min left"))
        assertTrue(TimerStyle.CLASSIC.showsIcon && TimerStyle.LOGO_TIME.showsIcon && TimerStyle.STACKED.showsIcon)
        assertFalse(TimerStyle.TIME_ONLY.showsIcon)
        assertFalse(TimerStyle.TEXT_ONLY.showsIcon)
        assertFalse(TimerStyle.TEXT_ONLY.hasBox)
        assertTrue(TimerStyle.STACKED.stacked)
    }

    @Test
    fun fiveQuickTapsUnlockAndFewerDoNot() {
        val lock = TimerLock(locked = true)
        var t = 1_000L
        repeat(4) { assertFalse(lock.onTap(t)); t += 300 }
        assertTrue(lock.locked)
        assertEquals(1, lock.tapsLeft)
        assertTrue(lock.onTap(t))
        assertFalse(lock.locked)
        assertEquals(0, lock.tapsLeft)
    }

    @Test
    fun aPauseOrADragBreaksTheRunOfTaps() {
        val lock = TimerLock(locked = true)
        var t = 0L
        repeat(4) { lock.onTap(t); t += 500 }
        t += TimerLock.TAP_GAP_MS + 1          // too slow: the run starts over
        assertFalse(lock.onTap(t))
        assertEquals(TimerLock.TAPS_TO_UNLOCK - 1, lock.tapsLeft)

        val other = TimerLock(locked = true)
        repeat(4) { other.onTap(it * 200L) }
        other.onDragAttempt()                    // a drag also resets the count
        assertFalse(other.onTap(1_000L))
        assertTrue(other.locked)
    }

    @Test
    fun lockingAgainNeedsAnotherFiveTaps() {
        val lock = TimerLock(locked = true)
        repeat(5) { lock.onTap(it * 100L) }
        assertFalse(lock.locked)
        lock.lockNow()
        assertTrue(lock.locked)
        repeat(4) { assertFalse(lock.onTap(10_000L + it * 100L)) }
        assertTrue(lock.onTap(10_500L))
    }

    @Test
    fun tapsOnAnUnlockedTimerAreIgnoredByTheLock() {
        val lock = TimerLock(locked = false)
        repeat(10) { assertFalse(lock.onTap(it * 100L)) }
        assertFalse(lock.locked)
    }
}
