package com.focusmode.app.data

import com.focusmode.app.BlockActivity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** "Continue to <app>" is offered only when ONE part of an app is blocked, never for the whole app. */
class BlockContinueTest {

    @Test fun partsOfAnAppCanContinue() {
        assertTrue(BlockActivity.canContinue(BlockActivity.REASON_SHORTS))
        assertTrue(BlockActivity.canContinue(BlockActivity.REASON_FEATURE))
        assertTrue(BlockActivity.canContinue(BlockActivity.REASON_CATEGORY))
        assertTrue(BlockActivity.canContinue(BlockActivity.REASON_WEBSITE))
        assertTrue(BlockActivity.canContinue(BlockActivity.REASON_ADULT))
    }

    @Test fun wholeAppBlocksCannotContinue() {
        assertFalse(BlockActivity.canContinue(BlockActivity.REASON_APP))
        assertFalse(BlockActivity.canContinue(BlockActivity.REASON_LIMIT))
        assertFalse(BlockActivity.canContinue(BlockActivity.REASON_BEDTIME))
        assertFalse(BlockActivity.canContinue(BlockActivity.REASON_SETTINGS))
        assertFalse(BlockActivity.canContinue(BlockActivity.REASON_PROTECTION))
    }
}
