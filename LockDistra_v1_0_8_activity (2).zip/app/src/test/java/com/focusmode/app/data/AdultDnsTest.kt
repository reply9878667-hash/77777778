package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdultDnsTest {

    private fun query(name: String, type: Int): ByteArray {
        val o = java.io.ByteArrayOutputStream()
        o.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0))
        for (l in name.split('.')) { o.write(l.length); o.write(l.toByteArray()) }
        o.write(0); o.write(type shr 8); o.write(type and 255); o.write(0); o.write(1)
        return o.toByteArray()
    }

    @Test fun adultNamesAreCaughtWithoutTheList() {
        for (h in listOf("pornhub.com", "some-sex-videos.net", "free.sex", "newsite-xxx.org", "hotporn123.xyz", "a.b.xvideos77.com", "sex.com"))
            assertTrue(h, AdultBlocklist.looksAdult(h))
    }

    @Test fun everydaySitesAreNotCaught() {
        for (h in listOf("essex.ac.uk", "sussex.ac.uk", "middlesex.edu", "google.com", "xxx.tumblr.com", "xxxlutz.at",
            "yourbrainonporn.com", "wikipedia.org", "unicorn.com", "popcorn.io", "sextant.com", "bbc.co.uk"))
            assertFalse(h, AdultBlocklist.looksAdult(h))
    }

    @Test fun parsesAndSinkholes() {
        val qa = query("PornHub.com", AdultDns.TYPE_A)
        val q = AdultDns.parseQuestion(qa)!!
        assertEquals("pornhub.com", q.name)
        val r = AdultDns.sinkholeResponse(qa, q)
        assertEquals(0x12.toByte(), r[0]); assertEquals(0x34.toByte(), r[1])
        assertEquals(1, r[7].toInt())
        assertEquals(qa.size + 16, r.size)
        assertNull(AdultDns.parseQuestion(r)) // a response is not a query
        val aaaa = query("x.com", AdultDns.TYPE_AAAA)
        assertEquals(aaaa.size + 28, AdultDns.sinkholeResponse(aaaa, AdultDns.parseQuestion(aaaa)!!).size)
    }

    @Test fun nxdomainAndDohNames() {
        val qa = query("dns.google", AdultDns.TYPE_A)
        val q = AdultDns.parseQuestion(qa)!!
        assertTrue(AdultDns.isDohName(q.name))
        assertEquals(3, AdultDns.errorResponse(qa, q, AdultDns.RCODE_NXDOMAIN)[3].toInt() and 0xF)
        assertFalse(AdultDns.isDohName("google.com"))
    }

    @Test fun replyPacketHasValidChecksumAndSwappedEnds() {
        val pay = query("a.com", AdultDns.TYPE_A)
        val pkt = ByteArray(28 + pay.size)
        pkt[0] = 0x45; pkt[2] = (pkt.size shr 8).toByte(); pkt[3] = pkt.size.toByte(); pkt[8] = 64; pkt[9] = 17
        byteArrayOf(10, 111, 222.toByte(), 1).copyInto(pkt, 12); byteArrayOf(10, 111, 222.toByte(), 2).copyInto(pkt, 16)
        pkt[20] = 0x30; pkt[21] = 0x39; pkt[23] = 53
        val ul = 8 + pay.size; pkt[24] = (ul shr 8).toByte(); pkt[25] = ul.toByte()
        pay.copyInto(pkt, 28)
        val p = AdultDns.parsePacket(pkt, pkt.size) as AdultDns.Parsed.Udp
        assertEquals(53, p.packet.dstPort)
        val rep = AdultDns.buildReply(p.packet, pay)
        assertEquals(0, AdultDns.ipChecksum(rep, 20))
        assertEquals(2.toByte(), rep[15]); assertEquals(1.toByte(), rep[19])
        assertTrue(AdultDns.parsePacket(ByteArray(10), 10) is AdultDns.Parsed.Other)
    }
}
