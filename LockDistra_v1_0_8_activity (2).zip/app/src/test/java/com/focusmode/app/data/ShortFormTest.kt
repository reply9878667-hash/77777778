package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ShortFormTest {

    @Test
    fun onlyInstalledAppsOfferContent() {
        val none = ShortFormCatalog.installed(emptySet())
        assertTrue(none.isEmpty())

        val some = ShortFormCatalog.installed(setOf("com.whatsapp", "com.google.android.youtube", "com.unknown"))
        assertEquals(setOf("wa_status", "yt_shorts"), some.map { it.id }.toSet())
        // WhatsApp must not offer Reels, Instagram must not offer Status.
        assertTrue(ShortFormCatalog.forPackage("com.whatsapp").none { it.title == "Reels" })
        assertTrue(ShortFormCatalog.forPackage("com.instagram.android").none { it.title == "Status" })
    }

    @Test
    fun catalogIsConsistent() {
        assertEquals(ShortFormCatalog.all.size, ShortFormCatalog.all.map { it.id }.toSet().size)
        ShortFormCatalog.all.forEach { form ->
            assertTrue(form.pkg in FeatureCatalog.appPackages)
            if (form.id == ShortFormCatalog.YT_SHORTS) {
                assertEquals(null, form.featureId)
            } else {
                assertNotNull(FeatureCatalog.byId(form.featureId!!))
            }
            assertNotNull(ShortFormCatalog.exitDef(form))
        }
    }

    @Test
    fun whatsAppStatusViewerIsRecognisedByWindowClass() {
        val def = FeatureCatalog.byId(FeatureCatalog.WA_STATUS)!!
        assertTrue(FeatureMatcher.matches(def.selector, emptyList(), "com.whatsapp.status.playback.StatusPlaybackActivity"))
        assertFalse(FeatureMatcher.matches(def.selector, emptyList(), "com.whatsapp.HomeActivity"))
        // The Updates tab being selected also counts.
        assertTrue(FeatureMatcher.matches(def.selector, listOf(NodeSnap(desc = "Updates", selected = true)), "com.whatsapp.HomeActivity"))
        assertFalse(FeatureMatcher.matches(def.selector, listOf(NodeSnap(desc = "Chats", selected = true)), "com.whatsapp.HomeActivity"))
    }

    @Test
    fun popupIntervalsMatchTheChosenMinutes() {
        for (every in listOf(1, 2, 5)) {
            var since = 0L
            var popups = 0
            // 10 minutes of active use, counted second by second.
            repeat(600) {
                since += 1_000L
                if (PopupSchedule.isDue(since, every)) {
                    since = 0L
                    popups++
                }
            }
            assertEquals(600 / (every * 60), popups)
        }
        assertFalse(PopupSchedule.isDue(10 * 60_000L, 0)) // Always mode never schedules popups
        assertFalse(PopupSchedule.isDue(59_999L, 1))
        assertTrue(PopupSchedule.isDue(60_000L, 1))
    }

    @Test
    fun scheduleSurvivesSwitchingApps() {
        // Per-app counters, as the service keeps them: 40 s in A, 30 s in B, 30 s back in A.
        val since = HashMap<String, Long>()
        fun use(app: String, seconds: Int): Boolean {
            var fired = false
            repeat(seconds) {
                val v = (since[app] ?: 0L) + 1_000L
                if (PopupSchedule.isDue(v, 1)) { since[app] = 0L; fired = true } else since[app] = v
            }
            return fired
        }
        assertFalse(use("A", 40))
        assertFalse(use("B", 30))
        assertTrue(use("A", 30)) // 70 s of A in total: due after the 60th second
    }
}

class ShortsLimitFixTest {

    @Test
    fun shortsPlayerRecognisedEvenWhenIdsChange() {
        val player = listOf(
            NodeSnap(id = "com.google.android.youtube:id/reel_player_page_container"),
        )
        assertTrue(ShortsDetector.isShortsScreen(player))
        // A renamed player id that still uses the reel_ prefix is still found.
        assertTrue(ShortsDetector.isShortsScreen(listOf(NodeSnap(id = "com.google.android.youtube:id/reel_dyn_like_button"))))
        // The selected Shorts tab counts.
        assertTrue(ShortsDetector.isShortsScreen(listOf(NodeSnap(desc = "Shorts", selected = true))))
    }

    @Test
    fun normalYouTubePagesAreNotShorts() {
        // The bottom Shorts tab is visible but not selected on every page.
        assertFalse(ShortsDetector.isShortsScreen(listOf(NodeSnap(desc = "Shorts", selected = false), NodeSnap(desc = "Like this video"))))
        // The Shorts shelf inside Home must not count as the Shorts player.
        assertFalse(ShortsDetector.isShortsScreen(listOf(NodeSnap(id = "com.google.android.youtube:id/reel_shelf_item"))))
        assertFalse(ShortsDetector.isShortsScreen(listOf(NodeSnap(id = "com.google.android.youtube:id/reel_player_page_container", visible = false))))
    }

    @Test
    fun categoryTimerShowsTheSmallerRemainingTime() {
        assertEquals(0L, CategoryTimer.remaining(60_000L, 90_000L, 0L))
        assertEquals(20_000L, CategoryTimer.remaining(60_000L, 30_000L, 10_000L))
        assertTrue(CategoryTimer.pick(null, 5_000L))      // Shorts limit only
        assertTrue(CategoryTimer.pick(600_000L, 5_000L))  // Shorts runs out first
        assertFalse(CategoryTimer.pick(1_000L, 5_000L))   // the app limit runs out first
        assertFalse(CategoryTimer.pick(1_000L, null))     // not in Shorts at all
    }
}
