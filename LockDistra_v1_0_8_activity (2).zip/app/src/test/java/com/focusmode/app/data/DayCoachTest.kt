package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test
import java.time.ZoneId

class DayCoachTest {

    private val utc = ZoneId.of("UTC")
    private val today = 20261107
    private val min = 60_000L

    private fun at(day: Int, minute: Int) = DayCoachRules.atMs(day, minute, utc)

    private fun settings(enabled: Boolean = true, dayStart: Int = 3 * 60, sleep: Int = 23 * 60) =
        CoachSettings(enabled, dayStart, sleep)

    private fun ev(key: String, s: CoachSettings = settings()) =
        DayCoachRules.events(s, today, utc).first { it.key == key }

    @Test fun off_hasNoEvents() {
        assertTrue(DayCoachRules.events(settings(enabled = false), today, utc).isEmpty())
    }

    @Test fun morning_goodMorningThenFirstTaskFiveMinutesLater() {
        val ds = ev("ds:$today")
        val ft = ev("ft:$today")
        assertEquals(CoachEventType.DAY_START, ds.type)
        assertEquals(at(today, 3 * 60), ds.at)
        assertEquals(CoachEventType.FIRST_TASK, ft.type)
        assertEquals(ds.at + 5 * min, ft.at)
    }

    @Test fun night_reminderFifteenMinutesBeforeSleep_goodNightAtSleep() {
        val pr = ev("pr:$today")
        val gn = ev("gn:$today")
        assertEquals(CoachEventType.PLAN_REMINDER, pr.type)
        assertEquals(at(today, 23 * 60) - 15 * min, pr.at)
        assertEquals(CoachEventType.GOOD_NIGHT, gn.type)
        assertEquals(at(today, 23 * 60), gn.at)
    }

    @Test fun onlyTheFourThingsExist_noNagsNoBlocks() {
        val types = DayCoachRules.events(settings(), today, utc).map { it.type }.toSet()
        assertEquals(
            setOf(CoachEventType.DAY_START, CoachEventType.FIRST_TASK, CoachEventType.PLAN_REMINDER, CoachEventType.GOOD_NIGHT),
            types
        )
        // yesterday, today and tomorrow: 4 events each
        assertEquals(12, DayCoachRules.events(settings(), today, utc).size)
    }

    @Test fun due_onlyInsideItsWindow_andOnlyOnce() {
        val events = DayCoachRules.events(settings(), today, utc)
        val ds = at(today, 3 * 60)
        assertTrue(DayCoachRules.due(events, emptySet(), ds - min).none { it.key == "ds:$today" })
        assertTrue(DayCoachRules.due(events, emptySet(), ds + 1).any { it.key == "ds:$today" })
        assertTrue(DayCoachRules.due(events, setOf("ds:$today"), ds + 1).none { it.key == "ds:$today" })
        // the good-morning message is skipped once the phone wakes up much later
        assertTrue(DayCoachRules.due(events, emptySet(), ds + 30 * min).none { it.key == "ds:$today" })
        // the reminder is not sent after the sleep time
        val sleep = at(today, 23 * 60)
        assertTrue(DayCoachRules.due(events, emptySet(), sleep + 1).none { it.key == "pr:$today" })
        assertTrue(DayCoachRules.due(events, emptySet(), sleep + 1).any { it.key == "gn:$today" })
    }

    @Test fun nextAt_isTheNextUnhandledEvent() {
        val events = DayCoachRules.events(settings(), today, utc)
        val now = at(today, 12 * 60)
        assertEquals(at(today, 23 * 60) - 15 * min, DayCoachRules.nextAt(events, emptySet(), now))
        assertEquals(at(today, 23 * 60), DayCoachRules.nextAt(events, setOf("pr:$today"), now))
    }

    @Test fun sleepAfterMidnight_isStillInOrder() {
        val s = settings(sleep = 30) // 12:30 AM
        val pr = ev("pr:$today", s)
        val gn = ev("gn:$today", s)
        assertEquals(at(today, 15), pr.at)
        assertEquals(at(today, 30), gn.at)
    }

    @Test fun pruneHandled_forgetsOldDays() {
        val kept = DayCoachRules.pruneHandled(setOf("ds:20261101", "ds:20261106", "gn:20261107"), today)
        assertEquals(setOf("ds:20261106", "gn:20261107"), kept)
    }

    // ---- The tasks the messages talk about ---------------------------------------------------------------------

    private fun board(vararg t: DailyTask) = TaskBoard(t.toList(), 20261107)

    @Test fun firstTask_isTheFirstUnfinishedTodayTaskInListOrder() {
        val b = board(
            DailyTask(1, "Tomorrow thing", TaskTag.TOMORROW),
            DailyTask(2, "Done already", TaskTag.TODAY, done = true),
            DailyTask(3, "Complete Math", TaskTag.TODAY),
            DailyTask(4, "Science notes", TaskTag.TODAY),
        )
        assertEquals("Complete Math", DayCoachRules.firstTask(b)?.text)
    }

    @Test fun firstTask_nullWhenNothingIsLeftToday() {
        assertNull(DayCoachRules.firstTask(board()))
        assertNull(DayCoachRules.firstTask(board(DailyTask(1, "x", TaskTag.TODAY, done = true), DailyTask(2, "y", TaskTag.NONE))))
    }

    @Test fun tomorrowCount_countsUnfinishedTomorrowTasks() {
        val b = board(DailyTask(1, "a", TaskTag.TOMORROW), DailyTask(2, "b", TaskTag.TOMORROW, done = true), DailyTask(3, "c", TaskTag.TODAY))
        assertEquals(1, DayCoachRules.tomorrowCount(b))
    }

    // ---- Words -------------------------------------------------------------------------------------------------

    @Test fun messages_sayTheRightThing() {
        assertTrue(CoachMessages.goodMorning().title.contains("Good morning"))
        assertTrue(CoachMessages.goodMorning().text.contains("5 minute"))
        val m = CoachMessages.firstTask(DailyTask(1, "Complete Math", TaskTag.TODAY))
        assertTrue(m.title.contains("Pehla task"))
        assertTrue(m.text.contains("Complete Math"))
        assertTrue(CoachMessages.firstTask(null).title.contains("khali"))
        assertTrue(CoachMessages.planReminder(0).title.contains("set karo"))
        assertTrue(CoachMessages.planReminder(2).text.contains("2 task"))
        assertTrue(CoachMessages.planReminder(0).text.contains("15 minute"))
        val gn = CoachMessages.goodNight(3 * 60)
        assertTrue(gn.title.contains("Good night"))
        assertTrue(gn.text.contains("3:00 AM"))
    }

    @Test fun defaults() {
        val s = CoachSettings()
        assertFalse(s.enabled)
        assertEquals(6 * 60, s.dayStartMin)
        assertEquals(23 * 60, s.sleepMin)
    }
}
