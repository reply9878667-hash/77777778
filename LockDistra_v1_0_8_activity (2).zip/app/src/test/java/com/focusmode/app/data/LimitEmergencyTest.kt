package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LimitEmergencyTest {

    private val t0 = 1_000_000L

    @Test
    fun defaultsAreTwoAttemptsOfTwoMinutes() {
        val e = LimitEmergency()
        assertTrue(e.enabled)
        assertEquals(2, e.attempts)
        assertEquals(2, e.minutes)
        assertEquals(2, e.remaining)
    }

    @Test
    fun settingsAreCappedAtFiveAndFive() {
        assertEquals(5, LimitEmergencyRules.clampAttempts(99))
        assertEquals(1, LimitEmergencyRules.clampAttempts(0))
        assertEquals(5, LimitEmergencyRules.clampMinutes(30))
        assertEquals(1, LimitEmergencyRules.clampMinutes(-3))
    }

    @Test
    fun startingUsesOneAttemptAndOpensTheWindow() {
        val e = LimitEmergency(enabled = true, attempts = 2, minutes = 3)
        val s = LimitEmergencyRules.start(e, t0)!!
        assertEquals(1, s.used)
        assertEquals(1, s.remaining)
        assertEquals(3 * 60_000L, s.leftMs(t0))
        assertTrue(s.isActive(t0 + 179_000L))
        assertFalse(s.isActive(t0 + 180_000L))
    }

    @Test
    fun cannotStartTwiceAtOnceOrPastTheLimitOrWhenOff() {
        val e = LimitEmergency(enabled = true, attempts = 2, minutes = 2)
        val first = LimitEmergencyRules.start(e, t0)!!
        assertNull(LimitEmergencyRules.start(first, t0 + 1_000L))          // window still running
        val second = LimitEmergencyRules.start(first, t0 + 121_000L)       // after it ended
        assertNotNull(second)
        assertNull(LimitEmergencyRules.start(second!!, t0 + 300_000L))     // both attempts used
        assertNull(LimitEmergencyRules.start(e.copy(enabled = false), t0)) // switched off
    }

    @Test
    fun attemptsAreNeverGivenBackWhenTheWindowEndsEarly() {
        val e = LimitEmergency(enabled = true, attempts = 1, minutes = 5)
        val s = LimitEmergencyRules.start(e, t0)!!
        val endedEarly = s.copy(activeUntil = 0L)
        assertEquals(0, endedEarly.remaining)
        assertNull(LimitEmergencyRules.start(endedEarly, t0 + 10_000L))
    }
}
