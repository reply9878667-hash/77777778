package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WebsiteLimitsTest {

    private fun limits(vararg pairs: Pair<String, Int>) =
        pairs.map { WebsiteLimit(it.first, it.second) }

    // ---- Add ---------------------------------------------------------------------------------

    @Test fun addsDomainWithHoursAndMinutes() {
        val c = WebsiteLimitRules.add(emptyList(), "youtube.com", 1 * 60 + 30)
        assertEquals(WebsiteLimitRules.Result.OK, c.result)
        assertEquals(listOf(WebsiteLimit("youtube.com", 90, enabled = true)), c.limits)
        assertEquals(90 * 60_000L, c.limits.single().limitMs)
    }

    @Test fun acceptsLinkOrNameInsteadOfDomain() {
        assertEquals("instagram.com", WebsiteLimitRules.add(emptyList(), "https://www.instagram.com/reels/abc?x=1", 15).limits.single().domain)
        assertEquals("facebook.com", WebsiteLimitRules.add(emptyList(), "facebook", 20).limits.single().domain)
        assertEquals("youtube.com", WebsiteLimitRules.add(emptyList(), "YouTube.com", 30).limits.single().domain)
    }

    @Test fun rejectsTextThatIsNotAWebsite() {
        for (bad in listOf("", "   ", "not a site", "192.168.0.1", "how to youtube.com")) {
            val c = WebsiteLimitRules.add(emptyList(), bad, 30)
            assertEquals(bad, WebsiteLimitRules.Result.INVALID, c.result)
            assertTrue(c.limits.isEmpty())
        }
    }

    @Test fun rejectsZeroAndTooLongTimes() {
        assertEquals(WebsiteLimitRules.Result.BAD_TIME, WebsiteLimitRules.add(emptyList(), "youtube.com", 0).result)
        assertEquals(WebsiteLimitRules.Result.BAD_TIME, WebsiteLimitRules.add(emptyList(), "youtube.com", -5).result)
        assertEquals(WebsiteLimitRules.Result.BAD_TIME, WebsiteLimitRules.add(emptyList(), "youtube.com", 24 * 60).result)
        assertEquals(WebsiteLimitRules.Result.OK, WebsiteLimitRules.add(emptyList(), "youtube.com", 23 * 60 + 59).result)
    }

    @Test fun severalWebsitesEachHaveTheirOwnLimit() {
        var list = emptyList<WebsiteLimit>()
        list = WebsiteLimitRules.add(list, "youtube.com", 30).limits
        list = WebsiteLimitRules.add(list, "instagram.com", 15).limits
        list = WebsiteLimitRules.add(list, "facebook.com", 20).limits
        assertEquals(listOf("youtube.com" to 30, "instagram.com" to 15, "facebook.com" to 20), list.map { it.domain to it.limitMin })
    }

    // ---- Duplicates and overlaps ---------------------------------------------------------------

    @Test fun duplicateWebsiteIsRejectedHoweverItIsTyped() {
        val list = limits("youtube.com" to 30)
        for (again in listOf("youtube.com", "www.YouTube.com", "https://youtube.com/watch?v=1", "youtube", "  youtube.com  ")) {
            val c = WebsiteLimitRules.add(list, again, 10)
            assertEquals(again, WebsiteLimitRules.Result.ALREADY_THERE, c.result)
            assertEquals(list, c.limits)
        }
    }

    @Test fun otherAddressOfTheSameSiteIsADuplicate() {
        assertEquals(WebsiteLimitRules.Result.ALREADY_THERE, WebsiteLimitRules.add(limits("youtube.com" to 30), "youtu.be", 10).result)
        assertEquals(WebsiteLimitRules.Result.ALREADY_THERE, WebsiteLimitRules.add(limits("x.com" to 30), "twitter.com", 10).result)
        assertEquals(WebsiteLimitRules.Result.ALREADY_THERE, WebsiteLimitRules.add(limits("twitter.com" to 30), "x.com", 10).result)
    }

    @Test fun aSubdomainOrParentOfALimitedSiteOverlaps() {
        assertEquals(WebsiteLimitRules.Result.OVERLAPS, WebsiteLimitRules.add(limits("google.com" to 30), "mail.google.com", 10).result)
        assertEquals(WebsiteLimitRules.Result.OVERLAPS, WebsiteLimitRules.add(limits("mail.google.com" to 30), "google.com", 10).result)
    }

    @Test fun similarLookingSitesAreNotTheSameSite() {
        val list = limits("youtube.com" to 30)
        assertEquals(WebsiteLimitRules.Result.OK, WebsiteLimitRules.add(list, "notyoutube.com", 10).result)
        assertEquals(WebsiteLimitRules.Result.OK, WebsiteLimitRules.add(list, "youtube.com.evil.net", 10).result)
    }

    @Test fun listHasAMaximum() {
        var list = emptyList<WebsiteLimit>()
        for (i in 1..WebsiteLimitRules.MAX_LIMITS) {
            val c = WebsiteLimitRules.add(list, "site$i.com", 10)
            assertEquals(WebsiteLimitRules.Result.OK, c.result)
            list = c.limits
        }
        assertEquals(WebsiteLimitRules.Result.FULL, WebsiteLimitRules.add(list, "one-more.com", 10).result)
    }

    // ---- Edit, delete, ON / OFF ----------------------------------------------------------------

    @Test fun editChangesTimeAndKeepsTheSwitch() {
        val list = listOf(WebsiteLimit("youtube.com", 30, enabled = false), WebsiteLimit("instagram.com", 15))
        val c = WebsiteLimitRules.edit(list, "youtube.com", "youtube.com", 45)
        assertEquals(WebsiteLimitRules.Result.OK, c.result)
        assertEquals(WebsiteLimit("youtube.com", 45, enabled = false), c.limits[0])
        assertEquals(list[1], c.limits[1])
    }

    @Test fun editCanChangeTheSite() {
        val c = WebsiteLimitRules.edit(limits("youtube.com" to 30), "youtube.com", "reddit.com", 20)
        assertEquals(WebsiteLimitRules.Result.OK, c.result)
        assertEquals(listOf(WebsiteLimit("reddit.com", 20)), c.limits)
    }

    @Test fun editCannotCreateADuplicateOrUseABadValue() {
        val list = limits("youtube.com" to 30, "instagram.com" to 15)
        assertEquals(WebsiteLimitRules.Result.ALREADY_THERE, WebsiteLimitRules.edit(list, "youtube.com", "instagram.com", 30).result)
        assertEquals(WebsiteLimitRules.Result.INVALID, WebsiteLimitRules.edit(list, "youtube.com", "not a site", 30).result)
        assertEquals(WebsiteLimitRules.Result.BAD_TIME, WebsiteLimitRules.edit(list, "youtube.com", "youtube.com", 0).result)
        assertEquals(WebsiteLimitRules.Result.INVALID, WebsiteLimitRules.edit(list, "unknown.com", "unknown.com", 30).result)
        assertEquals(list, WebsiteLimitRules.edit(list, "youtube.com", "instagram.com", 30).limits)
    }

    @Test fun removeAndSwitchOnlyTouchTheNamedSite() {
        val list = limits("youtube.com" to 30, "instagram.com" to 15)
        assertEquals(listOf("instagram.com"), WebsiteLimitRules.remove(list, "youtube.com").map { it.domain })
        val off = WebsiteLimitRules.setEnabled(list, "instagram.com", false)
        assertTrue(off[0].enabled)
        assertFalse(off[1].enabled)
        assertTrue(WebsiteLimitRules.setEnabled(off, "instagram.com", true)[1].enabled)
    }

    // ---- Which limit a page belongs to -----------------------------------------------------------

    @Test fun subpagesAndSubdomainsCountTowardTheMainDomain() {
        val list = limits("youtube.com" to 30, "instagram.com" to 15)
        // Subpages share the host, so they are the same host after normalization.
        assertEquals("youtube.com", WebsiteRules.normalize("https://www.youtube.com/watch?v=x")?.let { WebsiteLimitRules.find(list, it)?.domain })
        assertEquals("youtube.com", WebsiteRules.normalize("youtube.com/shorts/abc")?.let { WebsiteLimitRules.find(list, it)?.domain })
        assertEquals("youtube.com", WebsiteLimitRules.find(list, "m.youtube.com")?.domain)
        assertEquals("youtube.com", WebsiteLimitRules.find(list, "music.youtube.com")?.domain)
        assertEquals("instagram.com", WebsiteLimitRules.find(list, "instagram.com")?.domain)
    }

    @Test fun otherAddressesOfALimitedSiteCount() {
        val list = limits("youtube.com" to 30)
        assertEquals("youtube.com", WebsiteLimitRules.find(list, "youtu.be")?.domain)
        assertEquals("x.com", WebsiteLimitRules.find(limits("x.com" to 30), "twitter.com")?.domain)
    }

    @Test fun otherSitesDoNotMatch() {
        val list = limits("youtube.com" to 30)
        assertNull(WebsiteLimitRules.find(list, "notyoutube.com"))
        assertNull(WebsiteLimitRules.find(list, "youtube.com.evil.net"))
        assertNull(WebsiteLimitRules.find(list, "google.com"))
        assertNull(WebsiteLimitRules.find(emptyList(), "youtube.com"))
    }

    // ---- State ---------------------------------------------------------------------------------

    @Test fun limitIsReachedOnlyWhenOnAndTimeIsUsedUp() {
        val state = WebsiteLimitState(
            limits = listOf(
                WebsiteLimit("youtube.com", 30),
                WebsiteLimit("instagram.com", 15),
                WebsiteLimit("reddit.com", 10, enabled = false),
            ),
            usedMs = mapOf(
                "youtube.com" to 30 * 60_000L,
                "instagram.com" to 14 * 60_000L + 59_000L,
                "reddit.com" to 99 * 60_000L,
            ),
        )
        assertTrue(state.isReached("youtube.com"))
        assertFalse(state.isReached("instagram.com"))
        assertFalse("a limit that is OFF never blocks", state.isReached("reddit.com"))
        assertFalse(state.isReached("unknown.com"))
        assertTrue(state.hasActive)
        assertFalse(WebsiteLimitState(limits = listOf(WebsiteLimit("a.com", 5, enabled = false))).hasActive)
        assertNotNull(state.limitFor("youtube.com"))
        assertEquals(0L, state.usedFor("unknown.com"))
    }

    // ---- What counts as time -------------------------------------------------------------------

    @Test fun timeCountsOnlyWhileTheBrowserIsInFrontScreenOnAndTheSiteWasSeen() {
        assertTrue(WebsiteLimitRules.countsNow(browserInFront = true, screenOn = true, msSinceRead = 0L))
        assertTrue(WebsiteLimitRules.countsNow(true, true, 60_000L))
        assertTrue(WebsiteLimitRules.countsNow(true, true, WebsiteLimitRules.MAX_UNREAD_MS))
        assertFalse(WebsiteLimitRules.countsNow(true, true, WebsiteLimitRules.MAX_UNREAD_MS + 1))
        assertFalse(WebsiteLimitRules.countsNow(browserInFront = false, screenOn = true, msSinceRead = 0L))
        assertFalse(WebsiteLimitRules.countsNow(browserInFront = true, screenOn = false, msSinceRead = 0L))
        assertFalse("a read from the future is not trusted", WebsiteLimitRules.countsNow(true, true, -1L))
    }

    @Test fun oneTickNeverAddsALongGap() {
        assertEquals(1_000L, WebsiteLimitRules.tickDelta(1_000L))
        assertEquals(WebsiteLimitRules.MAX_TICK_MS, WebsiteLimitRules.tickDelta(120_000L))
        assertEquals(0L, WebsiteLimitRules.tickDelta(-50L))
    }
}
