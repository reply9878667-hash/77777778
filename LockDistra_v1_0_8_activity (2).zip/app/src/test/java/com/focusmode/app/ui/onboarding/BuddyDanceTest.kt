package com.focusmode.app.ui.onboarding

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BuddyDanceTest {

    private fun frame(move: Int, t: Float) = DanceFrame().also { DanceMoves.fill(move, t, it) }

    @Test
    fun everyMoveStaysFiniteAndInsideTheDrawingSpace() {
        var t = 0f
        while (t < 40f) {
            for (m in 0 until DanceMoves.COUNT) {
                val f = frame(m, t)
                val all = listOf(f.hop, f.shiftX, f.lean, f.headTilt, f.lx, f.ly, f.rx, f.ry, f.lbx, f.lby, f.rbx, f.rby, f.swing, f.mouth)
                all.forEach { assertTrue("move $m t=$t", it.isFinite()) }
                assertTrue("hop $m", f.hop in 0f..40f)
                assertTrue("sway $m", f.shiftX in -20f..20f && f.lean in -10f..10f)
                assertTrue("hands x $m", f.lx in 20f..340f && f.rx in 20f..340f)
                assertTrue("hands y $m", f.ly in 90f..360f && f.ry in 90f..360f)
                assertTrue("mouth $m", f.mouth in 0f..1f)
            }
            t += 0.05f
        }
    }

    @Test
    fun movesLookDifferentFromEachOther() {
        val t = 1.1f
        val poses = (0 until DanceMoves.COUNT).map { m -> frame(m, t).let { listOf(it.lx, it.ly, it.rx, it.ry) } }
        assertEquals(DanceMoves.COUNT, poses.toSet().size)
    }

    @Test
    fun aMoveKeepsMovingOverTime() {
        for (m in 0 until DanceMoves.COUNT) {
            val seen = (0..40).map { frame(m, it * 0.07f).let { f -> f.ly + f.ry + f.hop } }.toSet()
            assertTrue("move $m is not static", seen.size > 10)
        }
    }

    @Test
    fun moveNumbersWrapAround() {
        val a = frame(2, 3.3f)
        val b = frame(2 + DanceMoves.COUNT, 3.3f)
        val c = frame(2 - DanceMoves.COUNT, 3.3f)
        assertEquals(a.ly, b.ly, 0f)
        assertEquals(a.rx, c.rx, 0f)
    }

    @Test
    fun blendingGoesSmoothlyFromOneMoveToTheNext() {
        val a = frame(0, 2f)
        val b = frame(3, 2f)
        val mix = DanceFrame()
        mix.blend(a, b, 0f)
        assertEquals(a.ly, mix.ly, 0.0001f)
        mix.blend(a, b, 1f)
        assertEquals(b.rx, mix.rx, 0.0001f)
        mix.blend(a, b, 0.5f)
        assertEquals((a.lx + b.lx) / 2f, mix.lx, 0.0001f)
        assertNotEquals(a.ry, b.ry)
    }
}
