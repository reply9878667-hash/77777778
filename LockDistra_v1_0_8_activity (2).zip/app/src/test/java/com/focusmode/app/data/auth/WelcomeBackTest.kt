package com.focusmode.app.data.auth

import org.junit.Assert.assertTrue
import org.junit.Test

class WelcomeBackTest {
    @Test
    fun messageGreetsByNameWithEmoji() {
        val (title, text) = WelcomeNotifier.backMessage("Asha", hour = 8)
        assertTrue(title.startsWith("Welcome back, Asha!"))
        assertTrue(text.contains("Good morning"))
        assertTrue(text.contains("\uD83C\uDF31"))
    }

    @Test
    fun greetingChangesWithTheTimeOfDay() {
        assertTrue(WelcomeNotifier.backMessage("A", hour = 14).second.contains("Good afternoon"))
        assertTrue(WelcomeNotifier.backMessage("A", hour = 19).second.contains("Good evening"))
        assertTrue(WelcomeNotifier.backMessage("A", hour = 2).second.contains("night owl"))
    }
}
