package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class DailyTasksTest {

    private fun board(vararg texts: String): TaskBoard =
        texts.fold(TaskBoard(lastDay = 20261104)) { b, t -> DailyTaskRules.add(b, t) }

    private fun TaskBoard.task(id: Long) = tasks.first { it.id == id }

    // ---- 1. Task creation -----------------------------------------------------------------------------------

    @Test fun addsATaskWithCleanedText() {
        val b = DailyTaskRules.add(TaskBoard(), "  Read   Physics\nChapter 1  ")
        assertEquals(1, b.tasks.size)
        assertEquals("Read Physics Chapter 1", b.tasks[0].text)
        assertEquals(TaskTag.NONE, b.tasks[0].tag)
        assertEquals(false, b.tasks[0].done)
    }

    @Test fun blankTextAddsNothing() {
        assertEquals(0, DailyTaskRules.add(TaskBoard(), "   \n\t ").tasks.size)
        assertNull(DailyTaskRules.cleanText(""))
    }

    @Test fun longTextIsCapped() {
        val b = DailyTaskRules.add(TaskBoard(), "x".repeat(500))
        assertEquals(DailyTaskRules.MAX_TEXT, b.tasks[0].text.length)
    }

    // ---- 2. Unlimited entries -------------------------------------------------------------------------------

    @Test fun thousandTasksAllKeptWithUniqueIds() {
        var b = TaskBoard()
        repeat(1000) { b = DailyTaskRules.add(b, "Task $it") }
        assertEquals(1000, b.tasks.size)
        assertEquals(1000, b.tasks.map { it.id }.toSet().size)
        assertEquals("Task 999", b.tasks.last().text)
    }

    // ---- 3. Selection result: assign Today / Tomorrow, several at once, change later -------------------------

    @Test fun assignsSeveralTasksAtOnce() {
        val b = DailyTaskRules.assign(board("a", "b", "c"), setOf(1L, 3L), TaskTag.TODAY)
        assertEquals(TaskTag.TODAY, b.task(1).tag)
        assertEquals(TaskTag.NONE, b.task(2).tag)
        assertEquals(TaskTag.TODAY, b.task(3).tag)
        assertEquals(listOf("a", "c"), DailyTaskRules.inTag(b, TaskTag.TODAY).map { it.text })
    }

    @Test fun tagCanBeChangedLater() {
        var b = DailyTaskRules.assign(board("a"), setOf(1L), TaskTag.TODAY)
        b = DailyTaskRules.assign(b, setOf(1L), TaskTag.TOMORROW)
        assertEquals(TaskTag.TOMORROW, b.task(1).tag)
        b = DailyTaskRules.assign(b, setOf(1L), TaskTag.TODAY)
        assertEquals(TaskTag.TODAY, b.task(1).tag)
    }

    @Test fun assignKeepsDoneStatusAndText() {
        var b = DailyTaskRules.setDone(board("a"), 1, true)
        b = DailyTaskRules.assign(b, setOf(1L), TaskTag.TOMORROW)
        assertEquals(true, b.task(1).done)
        assertEquals("a", b.task(1).text)
    }

    // ---- 5. Completion ----------------------------------------------------------------------------------------

    @Test fun checkboxTogglesOnlyThatTask() {
        var b = DailyTaskRules.setDone(board("a", "b"), 2, true)
        assertEquals(false, b.task(1).done)
        assertEquals(true, b.task(2).done)
        b = DailyTaskRules.setDone(b, 2, false)
        assertEquals(false, b.task(2).done)
    }

    // ---- 4. Automatic date change -----------------------------------------------------------------------------

    private fun planned(): TaskBoard {
        var b = board("today open", "today done", "tomorrow open", "tomorrow done", "unassigned")
        b = DailyTaskRules.assign(b, setOf(1L, 2L), TaskTag.TODAY)
        b = DailyTaskRules.assign(b, setOf(3L, 4L), TaskTag.TOMORROW)
        return DailyTaskRules.setDone(DailyTaskRules.setDone(b, 2, true), 4, true)
    }

    @Test fun sameDayChangesNothing() {
        val b = planned()
        assertEquals(b, DailyTaskRules.rollover(b, 20261104))
    }

    @Test fun newDayMovesUnfinishedTomorrowIntoToday() {
        val r = DailyTaskRules.rollover(planned(), 20261105)
        assertEquals(TaskTag.TODAY, r.task(3).tag)
        assertEquals(false, r.task(3).done)
        assertEquals(20261105, r.lastDay)
    }

    @Test fun newDayClearsTomorrowAndDoesNotMoveCompletedTasksIntoToday() {
        val r = DailyTaskRules.rollover(planned(), 20261105)
        assertTrue(DailyTaskRules.inTag(r, TaskTag.TOMORROW).isEmpty())
        assertEquals(TaskTag.NONE, r.task(4).tag)   // finished Tomorrow task: not in Today
        assertEquals(true, r.task(4).done)          // and its done mark is kept
        assertEquals(listOf("today open", "today done", "tomorrow open"), DailyTaskRules.inTag(r, TaskTag.TODAY).map { it.text })
    }

    @Test fun otherTasksAreUntouchedByRollover() {
        val before = planned()
        val r = DailyTaskRules.rollover(before, 20261105)
        assertEquals(before.task(1), r.task(1))
        assertEquals(before.task(2), r.task(2))
        assertEquals(before.task(5), r.task(5))
    }

    @Test fun skippingSeveralDaysStillMovesOnce() {
        val r = DailyTaskRules.rollover(planned(), 20261201)
        assertEquals(TaskTag.TODAY, r.task(3).tag)
        assertTrue(DailyTaskRules.inTag(r, TaskTag.TOMORROW).isEmpty())
    }

    @Test fun rolloverIsIdempotent() {
        val once = DailyTaskRules.rollover(planned(), 20261105)
        assertEquals(once, DailyTaskRules.rollover(once, 20261105))
    }

    @Test fun clockMovedBackMovesNothingAndFollowsTheClock() {
        val b = planned()
        val r = DailyTaskRules.rollover(b, 20261103)
        assertEquals(b.tasks, r.tasks)
        assertEquals(20261103, r.lastDay)
        // ...and the next real midnight still works.
        val next = DailyTaskRules.rollover(r, 20261104)
        assertEquals(TaskTag.TODAY, next.task(3).tag)
    }

    @Test fun firstEverRunOnlySetsTheDay() {
        val r = DailyTaskRules.rollover(TaskBoard(), 20261104)
        assertEquals(20261104, r.lastDay)
        assertTrue(r.tasks.isEmpty())
    }

    @Test fun taskMovedToTomorrowAfterRolloverStaysUntilNextDay() {
        var b = DailyTaskRules.rollover(planned(), 20261105)
        b = DailyTaskRules.assign(b, setOf(5L), TaskTag.TOMORROW)
        assertEquals(TaskTag.TOMORROW, DailyTaskRules.rollover(b, 20261105).task(5).tag)
        assertEquals(TaskTag.TODAY, DailyTaskRules.rollover(b, 20261106).task(5).tag)
    }

    // ---- Day key (local calendar day) -------------------------------------------------------------------------

    @Test fun dayKeyFollowsTheLocalCalendarDay() {
        val zone = ZoneId.of("Asia/Kolkata")
        val late = ZonedDateTime.of(2026, 11, 4, 23, 59, 59, 0, zone).toInstant().toEpochMilli()
        val after = ZonedDateTime.of(2026, 11, 5, 0, 0, 0, 0, zone).toInstant().toEpochMilli()
        assertEquals(20261104, DailyTaskRules.dayKey(late, zone))
        assertEquals(20261105, DailyTaskRules.dayKey(after, zone))
    }

    @Test fun dayKeyOrdersAcrossMonthAndYearEnds() {
        val zone = ZoneId.of("UTC")
        val dec31 = ZonedDateTime.of(2026, 12, 31, 12, 0, 0, 0, zone).toInstant().toEpochMilli()
        val jan1 = ZonedDateTime.of(2027, 1, 1, 12, 0, 0, 0, zone).toInstant().toEpochMilli()
        assertTrue(DailyTaskRules.dayKey(jan1, zone) > DailyTaskRules.dayKey(dec31, zone))
    }

    // ---- Persistence format (survives an app restart) ---------------------------------------------------------

    @Test fun encodeDecodeRoundTripKeepsEverything() {
        val b = planned()
        assertEquals(b.tasks, DailyTaskRules.decode(DailyTaskRules.encode(b.tasks)))
    }

    @Test fun savedTextWithBackslashesAndTabsSurvives() {
        val tasks = listOf(DailyTask(7, "C:\\notes\\new", TaskTag.TODAY, true))
        assertEquals(tasks, DailyTaskRules.decode(DailyTaskRules.encode(tasks)))
    }

    @Test fun damagedLinesAreSkippedNotFatal() {
        val data = "garbage\n1\t1\t0\tgood\nx\t1\t0\tbad id\n2\t2\t1\n3\t0\t0\tfine"
        assertEquals(listOf("good", "fine"), DailyTaskRules.decode(data).map { it.text })
    }

    @Test fun emptyOrMissingDataGivesNoTasks() {
        assertTrue(DailyTaskRules.decode(null).isEmpty())
        assertTrue(DailyTaskRules.decode("").isEmpty())
    }

    @Test fun restartThenNewDaySettlesCorrectly() {
        // Saved yesterday, reopened today: decode, then rollover, exactly what TaskStore does on start.
        val saved = DailyTaskRules.encode(planned().tasks)
        val reopened = TaskBoard(DailyTaskRules.decode(saved), lastDay = 20261104)
        val r = DailyTaskRules.rollover(reopened, 20261105)
        assertEquals(TaskTag.TODAY, r.task(3).tag)
        assertTrue(DailyTaskRules.inTag(r, TaskTag.TOMORROW).isEmpty())
    }
}
