package com.focusmode.app.data.auth

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class AuthValidationTest {

    @Test
    fun namesAreCleanedAndChecked() {
        assertEquals("Mary Ann", AuthValidation.cleanName("  Mary   Ann "))
        assertEquals("Ab", AuthValidation.cleanName("A|b")) // '|' is the trusted-phone protocol separator
        assertEquals(30, AuthValidation.cleanName("x".repeat(50)).length)
        assertNull(AuthValidation.nameError("Rahul"))
        assertNull(AuthValidation.nameError("राहुल"))
        assertNotNull(AuthValidation.nameError(""))
        assertNotNull(AuthValidation.nameError("   "))
        assertNotNull(AuthValidation.nameError("A"))
        assertNotNull(AuthValidation.nameError("12"))
    }

    @Test
    fun emailsAreCheckedAndLowerCased() {
        assertEquals("a@b.com", AuthValidation.cleanEmail("  A@B.com "))
        assertNull(AuthValidation.emailError("rahul@example.com"))
        assertNull(AuthValidation.emailError(" Rahul.Y+focus@mail.example.co.in "))
        assertNotNull(AuthValidation.emailError(""))
        assertNotNull(AuthValidation.emailError("rahul"))
        assertNotNull(AuthValidation.emailError("rahul@"))
        assertNotNull(AuthValidation.emailError("rahul@example"))
        assertNotNull(AuthValidation.emailError("@example.com"))
        assertNotNull(AuthValidation.emailError("ra hul@example.com"))
        assertNotNull(AuthValidation.emailError("rahul@exa mple.com"))
        assertNotNull(AuthValidation.emailError("rahul@example..com"))
    }

    @Test
    fun newPasswordNeedsLengthLettersAndNumbers() {
        assertNull(AuthValidation.newPasswordError("focus2026"))
        assertNotNull(AuthValidation.newPasswordError(""))
        assertNotNull(AuthValidation.newPasswordError("abc123"))      // too short
        assertNotNull(AuthValidation.newPasswordError("abcdefghij"))  // no number
        assertNotNull(AuthValidation.newPasswordError("1234567890"))  // no letter
        assertNotNull(AuthValidation.newPasswordError("a1".repeat(40))) // too long
    }

    @Test
    fun passwordsAreNeverTrimmed() {
        // A trailing space is part of the password, so it counts for length and must match exactly.
        assertNull(AuthValidation.newPasswordError("abcdef1 "))
        assertNotNull(AuthValidation.confirmError("abcdef1 ", "abcdef1"))
    }

    @Test
    fun confirmMustMatch() {
        assertNull(AuthValidation.confirmError("focus2026", "focus2026"))
        assertNotNull(AuthValidation.confirmError("focus2026", ""))
        assertNotNull(AuthValidation.confirmError("focus2026", "Focus2026"))
    }

    @Test
    fun loginOnlyNeedsSomethingTyped() {
        assertNull(AuthValidation.loginPasswordError("abc")) // old accounts may have short passwords
        assertNotNull(AuthValidation.loginPasswordError(""))
    }
}
