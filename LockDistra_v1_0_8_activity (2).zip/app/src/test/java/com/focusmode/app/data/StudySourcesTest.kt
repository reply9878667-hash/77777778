package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.IOException
import java.net.SocketTimeoutException

/**
 * Study Part 2/4: source detection. Plain JVM (no Android): the classifier and the tracker hold all the rules; the Android
 * facts (PackageManager, ConnectivityManager, WebView) only feed them and are covered by the by-hand checks in STUDY_SOURCE_DETECTION.md.
 */
class StudySourcesTest {
    private val NOW = 1_794_000_000_000L // a fixed moment, so no test depends on the real clock
    private lateinit var t: SourceTracker

    @Before fun setUp() { t = SourceTracker() }

    private fun api(code: Int, body: String = ""): SourceFailure? = SourceClassifier.fromApi(StudyRules.parseError(code, body), NOW)

    // ---- 1. YouTube API ----------------------------------------------------------------------------------------

    @Test fun api_dailyLimit_isQuotaExhausted_withResetTime() {
        val f = api(403, """{"error":{"errors":[{"reason":"quotaExceeded"}]}}""")!!
        assertEquals(SourceStatus.QUOTA_EXHAUSTED, f.status)
        assertEquals(SourceReason.DAILY_LIMIT, f.reason)
        assertTrue(f.retryAtMs - NOW in 1..86_400_000L)
    }

    @Test fun api_perMinuteLimit_isTemporary_notExhausted() {
        val f = api(429)!!
        assertEquals(SourceStatus.TEMPORARILY_FAILED, f.status)
        assertEquals(SourceReason.RATE_LIMIT, f.reason)
        assertEquals(NOW + 60_000L, f.retryAtMs)
    }

    @Test fun api_invalidKey_isAuthError() {
        val f = api(400, """{"error":{"errors":[{"reason":"keyInvalid"}]}}""")!!
        assertEquals(SourceStatus.AUTH_ERROR, f.status)
        assertEquals(SourceReason.INVALID_KEY, f.reason)
    }

    @Test fun api_refusedKey_isAuthError() {
        val f = api(403, """{"error":{"errors":[{"reason":"forbidden"}]}}""")!!
        assertEquals(SourceStatus.AUTH_ERROR, f.status)
        assertEquals(SourceReason.KEY_REFUSED, f.reason)
    }

    @Test fun api_serviceUnavailable_and_serverError_areTemporary_andDistinct() {
        val unavailable = api(503)!!
        val server = api(500)!!
        assertEquals(SourceStatus.TEMPORARILY_FAILED, unavailable.status)
        assertEquals(SourceReason.SERVICE_UNAVAILABLE, unavailable.reason)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, server.status)
        assertEquals(SourceReason.SERVER_ERROR, server.reason)
    }

    @Test fun api_5xx_keepsKindOther_soTheOldFallbackRuleIsUnchanged() {
        assertEquals(StudyErrorKind.OTHER, StudyRules.parseError(503, "").kind)
        assertEquals(StudyErrorKind.OTHER, StudyRules.parseError(500, "").kind)
    }

    @Test fun api_timeout_isTemporary_otherNetworkFailure_isNetworkError() {
        val timeout = StudyException(StudyErrorKind.NETWORK, "x", reason = SourceReason.TIMEOUT)
        val offline = StudyException(StudyErrorKind.NETWORK, "x", reason = SourceReason.UNREACHABLE)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.fromApi(timeout, NOW)!!.status)
        assertEquals(SourceReason.TIMEOUT, SourceClassifier.fromApi(timeout, NOW)!!.reason)
        assertEquals(SourceStatus.NETWORK_ERROR, SourceClassifier.fromApi(offline, NOW)!!.status)
    }

    @Test fun api_missingItem_saysNothingAboutTheApi() {
        assertNull(api(404))
    }

    @Test fun api_noKey_isUnavailable_unreadableAnswer_isTemporary() {
        assertEquals(SourceStatus.UNAVAILABLE, SourceClassifier.fromApi(StudyException(StudyErrorKind.NO_KEY, "x"), NOW)!!.status)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.fromApi(StudyException(StudyErrorKind.BAD_ANSWER, "x"), NOW)!!.status)
    }

    @Test fun api_success_isAvailable() {
        t.success(StudyMode.API, NOW)
        assertEquals(SourceStatus.AVAILABLE, t.state(StudyMode.API).status)
    }

    @Test fun api_restingKeys_followTheRestLength() {
        val day = listOf(NOW + 3 * 3_600_000L)
        val minute = listOf(NOW + 60_000L)
        assertEquals(SourceStatus.QUOTA_EXHAUSTED, SourceClassifier.fromResting(listOf(StudyErrorKind.QUOTA), day, NOW)!!.status)
        // a one-minute rest is the per-minute limit: it must NOT look like "used up for today"
        assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.fromResting(listOf(StudyErrorKind.QUOTA), minute, NOW)!!.status)
        assertEquals(SourceStatus.AUTH_ERROR, SourceClassifier.fromResting(listOf(StudyErrorKind.BAD_KEY), minute, NOW)!!.status)
        // one key can still be asked: nothing is wrong with the API
        assertNull(SourceClassifier.fromResting(listOf(StudyErrorKind.QUOTA, StudyErrorKind.QUOTA), listOf(NOW + 3_600_000L, NOW - 1), NOW))
        assertNull(SourceClassifier.fromResting(emptyList(), emptyList(), NOW))
    }

    @Test fun api_localFacts() {
        assertEquals(SourceStatus.UNAVAILABLE, SourceClassifier.apiLocal(true, 0, false)!!.status)
        assertEquals(SourceStatus.DISABLED, SourceClassifier.apiLocal(false, 2, false)!!.status)
        assertNull(SourceClassifier.apiLocal(true, 1, false))
        assertNull(SourceClassifier.apiLocal(true, 1, null))
    }

    // ---- 2. Direct YouTube -------------------------------------------------------------------------------------

    @Test fun direct_appNotInstalled_isUnavailable() {
        val f = SourceClassifier.directLocal(true, appInstalled = false, appEnabled = null, permissionsOk = true, offline = false, requiresApp = true)!!
        assertEquals(SourceStatus.UNAVAILABLE, f.status)
        assertEquals(SourceReason.APP_NOT_INSTALLED, f.reason)
    }

    @Test fun direct_appDisabled_isDisabled() {
        val f = SourceClassifier.directLocal(true, true, appEnabled = false, permissionsOk = true, offline = false, requiresApp = true)!!
        assertEquals(SourceStatus.DISABLED, f.status)
        assertEquals(SourceReason.APP_DISABLED, f.reason)
    }

    @Test fun direct_installedAndEnabled_isNeverShownDisabled() {
        assertNull(SourceClassifier.directLocal(true, true, true, true, false, requiresApp = true))
    }

    @Test fun direct_unknownFacts_neverCountAgainstIt() {
        assertNull(SourceClassifier.directLocal(true, null, null, null, null, requiresApp = true))
        // installed but "enabled" could not be read (disabled-until-used): not "disabled"
        assertNull(SourceClassifier.directLocal(true, true, null, true, false, requiresApp = true))
    }

    @Test fun direct_missingPermission_isUnavailable() {
        val f = SourceClassifier.directLocal(true, true, true, permissionsOk = false, offline = false, requiresApp = true)!!
        assertEquals(SourceReason.PERMISSION_MISSING, f.reason)
    }

    @Test fun direct_appCheckCanBeSwitchedOff() {
        assertNull(SourceClassifier.directLocal(true, false, null, true, false, requiresApp = false))
    }

    @Test fun direct_pageFailures_areTemporary_orNetwork() {
        assertEquals(SourceReason.PAGE_UNREADABLE, SourceClassifier.fromPage(NoDataException()).reason)
        assertEquals(SourceReason.BLOCKED_BY_YOUTUBE, SourceClassifier.fromPage(HttpStatusException(429)).reason)
        assertEquals(SourceReason.BLOCKED_BY_YOUTUBE, SourceClassifier.fromPage(HttpStatusException(403)).reason)
        assertEquals(SourceReason.SERVER_ERROR, SourceClassifier.fromPage(HttpStatusException(503)).reason)
        assertEquals(SourceReason.TIMEOUT, SourceClassifier.fromPage(SocketTimeoutException()).reason)
        assertEquals(SourceStatus.NETWORK_ERROR, SourceClassifier.fromPage(IOException("x")).status)
        listOf(NoDataException(), HttpStatusException(429), SocketTimeoutException(), HttpStatusException(500)).forEach {
            assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.fromPage(it).status)
        }
    }

    @Test fun apiFailure_doesNotTouchDirectYouTube() {
        t.failure(StudyMode.API, api(403, """{"error":{"errors":[{"reason":"quotaExceeded"}]}}""")!!, NOW)
        // the local read for Direct YouTube says "nothing wrong": it must not turn into DISABLED / UNAVAILABLE
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, true, true, false, requiresApp = true), NOW)
        assertEquals(SourceStatus.QUOTA_EXHAUSTED, t.state(StudyMode.API).status)
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.PAGE).status)
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.WEB).status)
    }

    // ---- 3. Web ------------------------------------------------------------------------------------------------

    @Test fun web_localFacts() {
        assertEquals(SourceStatus.DISABLED, SourceClassifier.webLocal(false, true, false)!!.status)
        assertEquals(SourceReason.WEBVIEW_MISSING, SourceClassifier.webLocal(true, false, false)!!.reason)
        assertNull(SourceClassifier.webLocal(true, true, false))
        assertNull(SourceClassifier.webLocal(true, null, null))
    }

    @Test fun web_noInternet_isNetworkError_neverDisabled() {
        val f = SourceClassifier.webLocal(true, true, offline = true)!!
        assertEquals(SourceStatus.NETWORK_ERROR, f.status)
        assertEquals(SourceReason.NO_INTERNET, f.reason)
    }

    @Test fun web_requestFailures() {
        assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.fromWebError(timeout = true, network = false).status)
        assertEquals(SourceStatus.NETWORK_ERROR, SourceClassifier.fromWebError(timeout = false, network = true).status)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.httpFailure(503).status)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.webRendererStopped().status)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, SourceClassifier.webInitFailed().status)
    }

    // ---- 4 / 5. Independent, honest statuses ------------------------------------------------------------------

    @Test fun networkFailure_marksNetworkError_onEverySource_butNeverDisabled() {
        val off = true
        t.applyLocal(StudyMode.API, SourceClassifier.apiLocal(true, 1, off), NOW)
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, true, true, off, requiresApp = true), NOW)
        t.applyLocal(StudyMode.WEB, SourceClassifier.webLocal(true, true, off), NOW)
        StudyMode.values().forEach { assertEquals(SourceStatus.NETWORK_ERROR, t.state(it).status) }
        // back online: the local finding clears by itself and each source may be re-checked once
        t.applyLocal(StudyMode.WEB, SourceClassifier.webLocal(true, true, false), NOW + 1000)
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.WEB).status)
        assertTrue(t.due(StudyMode.WEB, NOW + 2000))
    }

    @Test fun noInternet_neverHidesAVerifiedQuotaOrKeyProblem() {
        t.failure(StudyMode.API, api(403, """{"error":{"errors":[{"reason":"quotaExceeded"}]}}""")!!, NOW)
        t.applyLocal(StudyMode.API, SourceClassifier.apiLocal(true, 1, true), NOW + 1000)
        assertEquals(SourceStatus.QUOTA_EXHAUSTED, t.state(StudyMode.API).status)
    }

    @Test fun aSuccess_doesNotErase_aSwitchOff_orAMissingApp() {
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, false, true, false, requiresApp = true), NOW)
        t.success(StudyMode.PAGE, NOW + 1000)
        assertEquals(SourceStatus.DISABLED, t.state(StudyMode.PAGE).status)
        t.applyLocal(StudyMode.WEB, SourceClassifier.webLocal(false, true, false), NOW)
        t.success(StudyMode.WEB, NOW + 1000)
        assertEquals(SourceStatus.DISABLED, t.state(StudyMode.WEB).status)
    }

    @Test fun aSwitchedOffSource_ignoresFailures_andIsNeverReChecked() {
        t.applyLocal(StudyMode.API, SourceClassifier.apiLocal(false, 1, false), NOW)
        t.failure(StudyMode.API, SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT), NOW + 1)
        assertEquals(SourceStatus.DISABLED, t.state(StudyMode.API).status)
        assertFalse(t.due(StudyMode.API, NOW + 10_000_000L))
    }

    @Test fun localFinding_clears_whenTheFactIsGone_butRealEvidenceDoesNot() {
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, false, true, false, requiresApp = true), NOW)
        assertEquals(SourceStatus.DISABLED, t.state(StudyMode.PAGE).status)
        assertFalse(t.due(StudyMode.PAGE, NOW + 100_000_000L)) // a local block is re-read, not re-asked on the network
        t.applyLocal(StudyMode.PAGE, null, NOW + 5000) // the person enabled YouTube again
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.PAGE).status)
        assertTrue(t.due(StudyMode.PAGE, NOW + 20_000))

        t.failure(StudyMode.API, SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT), NOW)
        t.applyLocal(StudyMode.API, null, NOW + 1000)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, t.state(StudyMode.API).status)
    }

    // ---- 6. Cool-down / light monitoring ----------------------------------------------------------------------

    @Test fun cooldown_growsThenCaps() {
        assertEquals(30_000L, SourceTracker.cooldown(SourceStatus.TEMPORARILY_FAILED, 1))
        assertEquals(60_000L, SourceTracker.cooldown(SourceStatus.TEMPORARILY_FAILED, 2))
        assertEquals(120_000L, SourceTracker.cooldown(SourceStatus.NETWORK_ERROR, 3))
        assertEquals(600_000L, SourceTracker.cooldown(SourceStatus.TEMPORARILY_FAILED, 10))
    }

    @Test fun repeatedFailures_waitLonger_andNeverBecomePermanent() {
        val f = SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT)
        var now = NOW
        repeat(25) { t.failure(StudyMode.WEB, f, now); now += 1000 }
        val s = t.state(StudyMode.WEB)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, s.status)
        assertEquals(now - 1000 + 600_000L, s.retryAt)
    }

    @Test fun due_onlyAfterCooldown_andNotTwiceInARow() {
        t.failure(StudyMode.WEB, SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT), NOW)
        assertFalse(t.due(StudyMode.WEB, NOW + 29_999))
        assertTrue(t.due(StudyMode.WEB, NOW + 30_000))
        t.markChecked(StudyMode.WEB, NOW + 30_000)
        assertFalse(t.due(StudyMode.WEB, NOW + 30_001))
    }

    @Test fun due_neverForAWorkingSource_orOneNeverUsed() {
        assertFalse(t.due(StudyMode.API, NOW)) // never used: its first real use verifies it for free
        t.success(StudyMode.API, NOW)
        assertFalse(t.due(StudyMode.API, NOW + 100_000_000L))
    }

    @Test fun quota_isReChecked_onlyAfterTheReset() {
        val f = api(403, """{"error":{"errors":[{"reason":"quotaExceeded"}]}}""")!!
        t.failure(StudyMode.API, f, NOW)
        assertFalse(t.due(StudyMode.API, NOW + 3_600_000L))
        assertTrue(t.due(StudyMode.API, f.retryAtMs))
    }

    @Test fun observingTheSameRestAgain_isNotANewFailure() {
        val f = SourceFailure(SourceStatus.QUOTA_EXHAUSTED, SourceReason.DAILY_LIMIT, NOW + 3_600_000L)
        t.observe(StudyMode.API, f, NOW)
        t.observe(StudyMode.API, f, NOW + 1000)
        t.observe(StudyMode.API, f, NOW + 2000)
        assertEquals(1, t.state(StudyMode.API).failures)
    }

    // ---- 7. Recovery -------------------------------------------------------------------------------------------

    @Test fun recovery_afterFailure_backToAvailable() {
        t.failure(StudyMode.WEB, SourceClassifier.fromWebError(timeout = false, network = true), NOW)
        assertEquals(SourceStatus.NETWORK_ERROR, t.state(StudyMode.WEB).status)
        t.success(StudyMode.WEB, NOW + 40_000)
        val s = t.state(StudyMode.WEB)
        assertEquals(SourceStatus.AVAILABLE, s.status)
        assertEquals(0, s.failures)
        assertFalse(t.due(StudyMode.WEB, NOW + 10_000_000L))
    }

    @Test fun recovery_ofADailyLimit_afterTheReset() {
        val f = api(403, """{"error":{"errors":[{"reason":"quotaExceeded"}]}}""")!!
        t.failure(StudyMode.API, f, NOW)
        t.success(StudyMode.API, f.retryAtMs + 5000)
        assertEquals(SourceStatus.AVAILABLE, t.state(StudyMode.API).status)
    }

    @Test fun webViewInitFailure_isClearedByASuccessfulStart() {
        t.failure(StudyMode.WEB, SourceClassifier.webInitFailed(), NOW)
        t.clearReason(StudyMode.WEB, SourceReason.WEBVIEW_INIT_FAILED, NOW + 1000)
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.WEB).status)
        // a different finding is not cleared by it
        t.failure(StudyMode.WEB, SourceClassifier.webRendererStopped(), NOW + 2000)
        t.clearReason(StudyMode.WEB, SourceReason.WEBVIEW_INIT_FAILED, NOW + 3000)
        assertEquals(SourceStatus.TEMPORARILY_FAILED, t.state(StudyMode.WEB).status)
    }

    @Test fun parseError_namesTheCause() {
        assertEquals(SourceReason.DAILY_LIMIT, StudyRules.parseError(403, """{"error":{"errors":[{"reason":"dailyLimitExceeded"}]}}""").reason)
        assertEquals(SourceReason.RATE_LIMIT, StudyRules.parseError(429, "").reason)
        assertEquals(SourceReason.INVALID_KEY, StudyRules.parseError(400, """{"error":{"message":"API key not valid"}}""").reason)
        assertEquals(SourceReason.UNKNOWN_ERROR, StudyRules.parseError(418, "").reason)
    }
}
