package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotSame
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Part 3/4: automatic source switching. Fake clock, fake phone facts, its own tracker: no Android, no network, no waiting.
 * Every test names the scenario it covers (failure of one, two or three sources, cool-downs, loop prevention).
 */
class StudySwitchTest {

    private class FakeFacts : SourceFacts {
        val on = mutableMapOf(StudyMode.API to true, StudyMode.PAGE to true, StudyMode.WEB to true)
        var keys = 1
        var rest: ApiRest? = null
        override fun enabled(mode: StudyMode) = on.getValue(mode)
        override fun apiKeyCount() = keys
        override fun apiRest(now: Long): ApiRest? = rest?.takeIf { it.until > now }
    }

    private var now = 1_000_000L
    private lateinit var tracker: SourceTracker
    private lateinit var sw: SourceSwitcher
    private lateinit var facts: FakeFacts
    private val calls = ArrayList<StudyMode>()

    @Before fun setUp() {
        now = 1_000_000L
        tracker = SourceTracker()
        sw = SourceSwitcher(tracker) { now }
        facts = FakeFacts()
        calls.clear()
    }

    // ---- helpers -------------------------------------------------------------------------------------------------

    private fun quota(daily: Boolean = true) = StudyException(
        StudyErrorKind.QUOTA, "limit", dailyLimit = daily, reason = if (daily) SourceReason.DAILY_LIMIT else SourceReason.RATE_LIMIT,
    )
    private fun badKey() = StudyException(StudyErrorKind.BAD_KEY, "key", reason = SourceReason.KEY_REFUSED)
    private fun network(src: StudyMode = StudyMode.API) = StudyException(StudyErrorKind.NETWORK, "net", source = src, reason = SourceReason.UNREACHABLE)
    private fun unreadable() = StudyException(StudyErrorKind.BAD_ANSWER, "page", source = StudyMode.PAGE)

    /** What StudyApi does for a daily limit: every key rests until the reset, then the error is thrown. */
    private fun apiQuotaOut(): () -> String = {
        calls += StudyMode.API
        facts.rest = ApiRest(now + 20L * 3_600_000L, SourceReason.DAILY_LIMIT)
        throw quota()
    }

    private fun ok(mode: StudyMode, value: String = mode.name): () -> String = { calls += mode; value }
    private fun fail(mode: StudyMode, e: Exception): () -> String = { calls += mode; throw e }

    private fun run(
        api: (() -> String)? = null,
        page: (() -> String)? = null,
        op: StudyOp = StudyOp.SEARCH,
        key: String = "maths",
        manual: Boolean = false,
    ): String {
        val m = LinkedHashMap<StudyMode, () -> String>()
        api?.let { m[StudyMode.API] = it }
        page?.let { m[StudyMode.PAGE] = it }
        return sw.run(op, key, facts, manual, m)
    }

    private inline fun <reified E : StudyException> expect(block: () -> Unit): E {
        try { block() } catch (e: StudyException) {
            if (e is E) return e
            throw AssertionError("Expected " + E::class.java.simpleName + " but got " + e.javaClass.simpleName + ": " + e.message)
        }
        throw AssertionError("Expected " + E::class.java.simpleName + " but nothing was thrown")
    }

    // ---- 1. default priority and no needless switching --------------------------------------------------------------

    @Test fun healthyApiServesAndNothingElseIsAsked() {
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.API), calls)
        assertEquals(StudyMode.API, StudyMonitor.mode.value)
    }

    @Test fun priorityIsApiThenDirectThenWebHandoff() {
        assertEquals(listOf(StudyMode.API, StudyMode.PAGE, StudyMode.WEB), SourceSwitcher.PRIORITY)
        val h = expect<WebHandoff> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertEquals(listOf(StudyMode.API, StudyMode.PAGE), calls) // in priority order, Web is last
        assertEquals(2, h.attempts.size)
    }

    // ---- 2. the examples of the task: quota, direct unavailable, auth error, web server down --------------------------

    @Test fun apiQuotaExhaustedFallsBackToDirectYouTube() {
        assertEquals("PAGE", run(api = apiQuotaOut(), page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.API, StudyMode.PAGE), calls)
        assertEquals(StudyMode.PAGE, StudyMonitor.mode.value)
        // The limit is remembered: the next request goes straight to Direct YouTube, the API is not asked again.
        calls.clear(); now += 1_000
        assertEquals("PAGE", run(api = apiQuotaOut(), page = ok(StudyMode.PAGE), key = "science"))
        assertEquals(listOf(StudyMode.PAGE), calls)
    }

    @Test fun directYouTubeUnavailableFallsBackToWeb() {
        // The YouTube app is missing: Direct YouTube is blocked by a local fact, so only API is asked, then Web.
        tracker.applyLocal(StudyMode.PAGE, SourceFailure(SourceStatus.UNAVAILABLE, SourceReason.APP_NOT_INSTALLED), now)
        expect<WebHandoff> { run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE)) }
        assertEquals(listOf(StudyMode.API), calls) // Direct YouTube never asked
    }

    @Test fun directYouTubeNetworkFailureStillReachesWeb() {
        // Before Part 3 this error went to the screen as an error card and Web was never tried.
        facts.rest = ApiRest(now + 3_600_000L, SourceReason.DAILY_LIMIT)
        expect<WebHandoff> { run(api = ok(StudyMode.API), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertEquals(listOf(StudyMode.PAGE), calls)
    }

    @Test fun apiAuthenticationErrorUsesTheConfiguredAlternative() {
        val api: () -> String = { calls += StudyMode.API; throw badKey() }
        assertEquals("PAGE", run(api = api, page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.API, StudyMode.PAGE), calls)
        assertEquals(SourceStatus.AUTH_ERROR, tracker.state(StudyMode.API).status)
    }

    @Test fun noApiKeyUsesDirectYouTubeWithoutAskingTheApi() {
        facts.keys = 0
        assertEquals("PAGE", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.PAGE), calls)
    }

    @Test fun webServerDownTriesTheOtherSources() {
        // Web is the last source, but when it is the one that is down (cooling) the others still serve.
        tracker.failure(StudyMode.WEB, SourceClassifier.httpFailure(503), now)
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
        facts.rest = ApiRest(now + 3_600_000L, SourceReason.DAILY_LIMIT)
        calls.clear()
        assertEquals("PAGE", run(page = ok(StudyMode.PAGE), key = "other"))
    }

    // ---- 3. one failure never makes the others "unavailable" -------------------------------------------------------

    @Test fun oneSourceFailingDoesNotTouchTheOthers() {
        run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE))
        assertEquals(SourceStatus.NETWORK_ERROR, tracker.state(StudyMode.API).status)
        assertEquals(SourceStatus.UNKNOWN, tracker.state(StudyMode.WEB).status)
        assertEquals(SourceStatus.UNKNOWN, tracker.state(StudyMode.PAGE).status) // PAGE's own success is recorded by its own layer
        assertTrue(sw.isUsable(StudyMode.WEB, facts))
    }

    @Test fun aSourceThatCannotServeThisRequestIsNotBlamed() {
        val page: () -> String = { calls += StudyMode.PAGE; throw NotServed("no name", StudyMode.PAGE) }
        expect<WebHandoff> { run(api = fail(StudyMode.API, network()), page = page) }
        assertEquals(SourceStatus.UNKNOWN, tracker.state(StudyMode.PAGE).status)
        assertTrue(sw.isUsable(StudyMode.PAGE, facts))
    }

    @Test fun notFoundIsPassedOnAndSwitchesNothing() {
        val missing = StudyException(StudyErrorKind.NOT_FOUND, "nothing")
        val e = expect<StudyException> { run(api = fail(StudyMode.API, missing), page = ok(StudyMode.PAGE)) }
        assertEquals(StudyErrorKind.NOT_FOUND, e.kind)
        assertEquals(listOf(StudyMode.API), calls)
        assertEquals(SourceStatus.UNKNOWN, tracker.state(StudyMode.API).status)
    }

    @Test fun anyUnexpectedExceptionAlsoTriggersTheFallback() {
        assertEquals("PAGE", run(api = fail(StudyMode.API, IOException("boom")), page = ok(StudyMode.PAGE)))
        assertEquals(SourceStatus.NETWORK_ERROR, tracker.state(StudyMode.API).status)
    }

    // ---- 4. all sources fail: one meaningful error, no handoff to a dead Web --------------------------------------

    @Test fun allThreeFailedGivesOneMeaningfulError() {
        tracker.failure(StudyMode.WEB, SourceClassifier.fromWebError(timeout = false, network = true), now)
        val e = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertEquals(StudyErrorKind.NETWORK, e.kind)
        assertEquals("No internet connection", e.title)
        assertEquals("No internet connection", StudyRules.errorTitle(e, true))
        assertTrue(e.message.orEmpty().contains("internet"))
        assertEquals(3, e.attempts.size)
    }

    @Test fun webSwitchedOffEndsInErrorNotHandoff() {
        facts.on[StudyMode.WEB] = false
        val e = expect<SourcesExhausted> { run(api = fail(StudyMode.API, unreadable()), page = fail(StudyMode.PAGE, unreadable())) }
        assertTrue(e.attempts.last().skipped)
        assertEquals("Could not load videos", e.title)
    }

    @Test fun dailyLimitPlusDeadOthersExplainsTheLimit() {
        facts.on[StudyMode.WEB] = false
        val e = expect<SourcesExhausted> { run(api = apiQuotaOut(), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertTrue(e.message.orEmpty().contains("daily limit"))
    }

    @Test fun networkFailuresPlusSwitchedOffWebStillSayNoInternet() {
        facts.on[StudyMode.WEB] = false
        val e = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertEquals(StudyErrorKind.NETWORK, e.kind)
        assertEquals("No internet connection", e.title)
    }

    @Test fun everySourceSwitchedOffSaysSo() {
        StudyMode.values().forEach { facts.on[it] = false }
        val e = expect<SourcesExhausted> { run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)) }
        assertEquals("No video source available", e.title)
        assertTrue(calls.isEmpty())
    }

    @Test fun webFailingAfterApiAndDirectGivesTheCombinedMessage() {
        tracker.failure(StudyMode.API, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE), now)
        tracker.failure(StudyMode.PAGE, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE), now)
        tracker.failure(StudyMode.WEB, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE), now)
        val all = SwitchMessages.allThreeFailed(tracker.states.value)
        assertEquals("No internet connection", all?.title)
        // Web alone failing while the API still works keeps the web-specific text.
        tracker.reset()
        tracker.success(StudyMode.API, now)
        tracker.failure(StudyMode.WEB, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE), now)
        assertNull(SwitchMessages.allThreeFailed(tracker.states.value))
    }

    // ---- 5. cool-down, retry limits, loop prevention ------------------------------------------------------------

    @Test fun failedSourceIsNotAskedAgainInsideItsCooldownAndIsAskedAfterIt() {
        run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE))
        calls.clear(); now += 5_000
        run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE), key = "science")
        assertEquals(listOf(StudyMode.PAGE), calls) // API skipped at once: no waiting for it to fail again
        calls.clear(); now += 60_000 // past the 30 s cool-down
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "history"))
        assertEquals(listOf(StudyMode.API), calls) // back on the highest priority
    }

    @Test fun cooldownGrowsWithRepeatedFailures() {
        var t = now
        val waits = ArrayList<Long>()
        repeat(4) { i ->
            now = t
            run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE), key = "k$i")
            val st = tracker.state(StudyMode.API)
            waits += st.retryAt - now
            t = st.retryAt + 1
        }
        assertEquals(listOf(30_000L, 60_000L, 120_000L, 240_000L), waits)
    }

    @Test fun eachSourceIsAskedAtMostOncePerRequest() {
        val api = AtomicInteger(); val page = AtomicInteger()
        expect<WebHandoff> {
            run(api = { api.incrementAndGet(); throw network() }, page = { page.incrementAndGet(); throw network(StudyMode.PAGE) })
        }
        assertEquals(1, api.get()); assertEquals(1, page.get())
    }

    @Test fun aRequestThatJustFailedIsNotStartedAgainStraightAway() {
        facts.on[StudyMode.WEB] = false
        val first = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        calls.clear(); now += 1_000
        val again = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertSame(first, again) // answered from memory
        assertTrue(calls.isEmpty())
        now += 5_000 // past the short memory: a fresh decision is made (sources are still cooling, so nothing is asked either)
        val later = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertNotSame(first, later)
    }

    @Test fun threeFailuresInARowMakeTheAutomaticRequestRest() {
        facts.on[StudyMode.WEB] = false
        var last: StudyException? = null
        repeat(3) { i ->
            last = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
            // Past both cool-downs, so the next request really asks the sources again.
            if (i < 2) now = maxOf(tracker.state(StudyMode.API).retryAt, tracker.state(StudyMode.PAGE).retryAt) + 1
        }
        // 10 s after the 3rd failure the same automatic request is answered from memory (the long rest), nothing is asked.
        now += 10_000
        calls.clear()
        val fourth = expect<SourcesExhausted> { run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)) }
        assertSame(last, fourth)
        assertTrue(calls.isEmpty())
        // An explicit "Try again" is allowed after the short memory: the failures are 10 s old, so the sources are asked.
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), manual = true))
    }

    @Test fun manualRetryNeverSkipsACooldownOfAFreshFailure() {
        run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE))
        calls.clear(); now += 4_000
        run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "again", manual = true)
        assertEquals(listOf(StudyMode.PAGE), calls) // the failure is only 4 s old: not asked again
        calls.clear(); now += 8_000 // the failure is now 12 s old
        run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "third", manual = true)
        assertEquals(listOf(StudyMode.API), calls)
    }

    @Test fun aSuccessEndsTheCooldown() {
        run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE))
        now += 31_000
        run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "x")
        tracker.success(StudyMode.API, now) // StudyApi records its own success
        calls.clear(); now += 1_000
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "y"))
    }

    // ---- 6. duplicate requests --------------------------------------------------------------------------------------

    @Test fun theSameRequestAskedTwiceAtOnceRunsOnce() {
        val started = CountDownLatch(1)
        val release = CountDownLatch(1)
        val runs = AtomicInteger()
        val slow: () -> String = { runs.incrementAndGet(); started.countDown(); release.await(5, TimeUnit.SECONDS); "answer" }
        val results = arrayOfNulls<String>(2)
        val t1 = Thread { results[0] = run(api = slow, page = ok(StudyMode.PAGE), key = "same") }
        t1.start()
        assertTrue(started.await(5, TimeUnit.SECONDS))
        val t2 = Thread { results[1] = run(api = slow, page = ok(StudyMode.PAGE), key = "same") }
        t2.start()
        Thread.sleep(200) // the second caller is waiting on the first one
        release.countDown()
        t1.join(5000); t2.join(5000)
        assertEquals(1, runs.get())
        assertEquals(listOf("answer", "answer"), results.toList())
    }

    @Test fun differentRequestsDoNotBlockEachOther() {
        assertEquals("API", run(api = ok(StudyMode.API), key = "a"))
        assertEquals("API", run(api = ok(StudyMode.API), key = "b"))
        assertEquals(2, calls.size)
    }

    // ---- 7. live facts beat stale states -------------------------------------------------------------------------------

    @Test fun staleOfflineStateNeverBlocksASource() {
        tracker.applyLocal(StudyMode.PAGE, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.NO_INTERNET), now)
        tracker.applyLocal(StudyMode.API, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.NO_INTERNET), now)
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
    }

    @Test fun aSourceSwitchedBackOnWorksAtOnce() {
        tracker.applyLocal(StudyMode.PAGE, SourceFailure(SourceStatus.DISABLED, SourceReason.SWITCHED_OFF), now)
        facts.on[StudyMode.PAGE] = true // the live flag says on; the tracker is only re-read when Study opens
        facts.rest = ApiRest(now + 3_600_000L, SourceReason.DAILY_LIMIT)
        assertEquals("PAGE", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
    }

    @Test fun aSwitchedOffSourceIsNeverAsked() {
        facts.on[StudyMode.API] = false
        assertEquals("PAGE", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.PAGE), calls)
    }

    @Test fun disabledYouTubeAppBlocksDirectButNotTheOthers() {
        tracker.applyLocal(StudyMode.PAGE, SourceFailure(SourceStatus.DISABLED, SourceReason.APP_DISABLED), now)
        assertTrue(sw.check(StudyMode.PAGE, facts) is Pick.Blocked)
        assertEquals(Pick.Use, sw.check(StudyMode.API, facts))
        assertEquals(Pick.Use, sw.check(StudyMode.WEB, facts))
    }

    @Test fun apiRestingKeysCoolTheApiWithTheRightReason() {
        facts.rest = ApiRest(now + 3_600_000L, SourceReason.DAILY_LIMIT)
        val p = sw.check(StudyMode.API, facts) as Pick.Cooling
        assertEquals(SourceReason.DAILY_LIMIT, p.reason)
        assertEquals("PAGE", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
    }

    @Test fun rateLimitIsOnlyAShortPause() {
        val api: () -> String = { calls += StudyMode.API; throw quota(daily = false) }
        run(api = api, page = ok(StudyMode.PAGE))
        assertEquals(SourceStatus.TEMPORARILY_FAILED, tracker.state(StudyMode.API).status)
        calls.clear(); now += 61_000
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "later"))
    }

    // ---- 8. fast switching indicator ----------------------------------------------------------------------------------

    @Test fun switchingFlagShowsOnlyWhileAFallbackRuns() {
        assertFalse(sw.switching.value)
        var seen = false
        val page: () -> String = { seen = sw.switching.value; "PAGE" }
        run(api = fail(StudyMode.API, network()), page = page)
        assertTrue(seen)
        assertFalse(sw.switching.value)
        // A request served by the first source never shows it (the API's short cool-down from above is over by then).
        now += 60_000
        var seenFirst = true
        run(api = { seenFirst = sw.switching.value; "API" }, key = "plain")
        assertFalse(seenFirst)
    }

    @Test fun switchingFlagIsClearedEvenWhenEverythingFails() {
        facts.on[StudyMode.WEB] = false
        expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertFalse(sw.switching.value)
    }

    // ---- 9. content consistency -----------------------------------------------------------------------------------------

    private fun video(id: String, title: String = "T", channel: String = "", desc: String = "", at: Long = 0L, secs: Int = 600) =
        StudyVideo(id, title, channel, if (channel.isEmpty()) "" else "Name", "https://i.ytimg.com/vi/$id/hqdefault.jpg", secs, "", true, at, desc)

    @Test fun sameVideoFromTwoSourcesIsOneEntryWithTheRicherDetails() {
        val fromPage = video("abc", "Title", "UC1", "", 0L)
        val fromApi = video("abc", "Title", "UC1", "Full description", 1234L)
        val merged = StudyMerge.merge(listOf(fromPage), listOf(fromApi, video("def")))
        assertEquals(listOf("abc", "def"), merged.map { it.id })
        assertEquals("Full description", merged[0].description)
        assertEquals(1234L, merged[0].publishedAt)
        assertEquals("Title", merged[0].title)
        assertEquals("UC1", merged[0].channelId)
        assertEquals("https://i.ytimg.com/vi/abc/hqdefault.jpg", merged[0].thumbUrl)
    }

    @Test fun mergeNeverReplacesOneVideoWithAnother() {
        try {
            StudyMerge.richer(video("aaa"), video("bbb"))
            fail("two different videos must never be merged")
        } catch (e: IllegalArgumentException) {
            // expected
        }
        val merged = StudyMerge.merge(listOf(video("a1", "One")), listOf(video("a2", "Two")))
        assertEquals(listOf("One", "Two"), merged.map { it.title })
    }

    @Test fun mergeKeepsTheFirstPositionAndNeverDuplicates() {
        val a = listOf(video("1"), video("2"), video("3"))
        val b = listOf(video("3"), video("2"), video("4"))
        assertEquals(listOf("1", "2", "3", "4"), StudyMerge.merge(a, b).map { it.id })
    }

    @Test fun channelInformationSurvivesAMergeWithAnAnonymousWebResult() {
        val api = video("w1", "Lesson", "UC9")
        val web = video("w1", "Lesson", "")
        val merged = StudyMerge.merge(listOf(web), listOf(api)).single()
        assertEquals("UC9", merged.channelId) // channel profile navigation keeps working
        assertEquals("Name", merged.channelTitle)
    }
}
