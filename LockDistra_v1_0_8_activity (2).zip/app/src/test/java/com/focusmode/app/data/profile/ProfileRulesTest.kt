package com.focusmode.app.data.profile

import com.focusmode.app.data.OnboardingAnswers
import com.focusmode.app.data.OnboardingQuestions
import com.focusmode.app.data.profile.ProfileMerge.Winner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileRulesTest {

    @Test
    fun nameRulesAreTheAccountRules() {
        assertNotNull(ProfileRules.nameError(""))
        assertNotNull(ProfileRules.nameError("A"))
        assertNotNull(ProfileRules.nameError("12"))
        assertNull(ProfileRules.nameError("Sam"))
        assertEquals("Sam Lee", ProfileRules.cleanName("  Sam   Lee "))
        assertEquals(30, ProfileRules.cleanName("x".repeat(80)).length)
    }

    @Test
    fun avatarIds() {
        assertTrue(ProfileRules.isValidAvatar(""))
        ProfileRules.AVATAR_IDS.forEach { assertTrue(it, ProfileRules.isValidAvatar(it)) }
        assertFalse(ProfileRules.isValidAvatar("not_an_avatar"))
    }

    @Test
    fun initials() {
        assertEquals("AY", ProfileRules.initials("Ayşe Yılmaz"))
        assertEquals("S", ProfileRules.initials("sam"))
        assertEquals("SL", ProfileRules.initials("  sam   lee  ken "))
        assertEquals("?", ProfileRules.initials("  "))
    }

    @Test
    fun idListsRoundTrip() {
        val ids = listOf("social_media", "gaming")
        assertEquals(ids, ProfileRules.decodeIds(ProfileRules.encodeIds(ids)))
        assertEquals(emptyList<String>(), ProfileRules.decodeIds(null))
        assertEquals(emptyList<String>(), ProfileRules.decodeIds(""))
    }

    @Test
    fun labelsAndDurations() {
        assertEquals("Study better", ProfileRules.optionLabel(OnboardingQuestions.GOAL, "study_better"))
        assertNull(ProfileRules.optionLabel(OnboardingQuestions.GOAL, "unknown_id"))
        assertNull(ProfileRules.optionLabel(OnboardingQuestions.SOURCE, null))
        assertEquals("45 minutes", ProfileRules.durationText(45))
        assertEquals("1 hour", ProfileRules.durationText(60))
        assertEquals("2 hours", ProfileRules.durationText(120))
        assertEquals("1 h 30 min", ProfileRules.durationText(90))
        assertEquals("1 hour", ProfileRules.dailyGoalText("h_1", null))
        assertEquals("1 h 30 min", ProfileRules.dailyGoalText("custom", 90))
        assertNull(ProfileRules.dailyGoalText(null, null))
    }

    @Test
    fun mergeDecision() {
        assertEquals(Winner.LOCAL, ProfileMerge.winner(localDirty = true, localUpdatedAt = 0, remoteUpdatedAt = null))
        assertEquals(Winner.LOCAL, ProfileMerge.winner(localDirty = false, localUpdatedAt = 5, remoteUpdatedAt = null))
        // fresh record (updatedAt 0) must never overwrite an existing server profile
        assertEquals(Winner.REMOTE, ProfileMerge.winner(localDirty = true, localUpdatedAt = 0, remoteUpdatedAt = 100))
        assertEquals(Winner.REMOTE, ProfileMerge.winner(localDirty = false, localUpdatedAt = 500, remoteUpdatedAt = 100))
        assertEquals(Winner.LOCAL, ProfileMerge.winner(localDirty = true, localUpdatedAt = 200, remoteUpdatedAt = 100))
        assertEquals(Winner.REMOTE, ProfileMerge.winner(localDirty = true, localUpdatedAt = 50, remoteUpdatedAt = 100))
    }

    @Test
    fun allSevenAnswersAreCarriedOver() {
        val a = OnboardingAnswers()
            .withText("name", "Sam")
            .withSingle("goal", "study_better")
            .withToggled("distractions", "gaming")
            .withToggled("distractions", "social_media")
            .withSingle("phone_time", "4_6h")
            .withSingle("session_length", "min_45")
            .withSingle("daily_goal", "custom")
            .withCustomGoalText("95")
            .withSingle("source", "youtube")
        val o = ProfileOnboarding.from(a, now = 1234L)!!
        assertEquals("Sam", o.name)
        assertEquals("study_better", o.goal)
        assertEquals(listOf("gaming", "social_media"), o.distractions)
        assertEquals("4_6h", o.phoneTime)
        assertEquals("min_45", o.sessionLength)
        assertEquals("custom", o.dailyGoal)
        assertEquals(95, o.dailyGoalMinutes)
        assertEquals("youtube", o.source)
        assertEquals(1234L, o.completedAt)
    }

    @Test
    fun optionalAnswerStaysEmptyAndNothingAnsweredMeansNoRecord() {
        val a = OnboardingAnswers().withText("name", "Sam").withSingle("daily_goal", "h_2")
        val o = ProfileOnboarding.from(a, 1L)!!
        assertNull(o.source)
        assertNull(o.dailyGoalMinutes)
        assertNull(ProfileOnboarding.from(OnboardingAnswers(), 1L))
    }
}
