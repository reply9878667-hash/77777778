package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingTest {

    @Test
    fun freshInstallShowsTheWelcome() {
        assertFalse(OnboardingRules.welcomeDone(stored = null, isUpdatedInstall = false))
        assertFalse(OnboardingRules.welcomeDone(stored = null, isUpdatedInstall = false, skipForExistingInstalls = true))
    }

    @Test
    fun everyoneSeesItOnceByDefaultEvenAfterAnUpdate() {
        // Default rule: an update of an old install also gets the introduction once.
        assertFalse(OnboardingRules.SKIP_FOR_EXISTING_INSTALLS)
        assertFalse(OnboardingRules.welcomeDone(stored = null, isUpdatedInstall = true, skipForExistingInstalls = false))
    }

    @Test
    fun existingInstallsCanBeSkippedWhenTheRuleIsOn() {
        assertTrue(OnboardingRules.welcomeDone(stored = null, isUpdatedInstall = true, skipForExistingInstalls = true))
    }

    @Test
    fun aSavedAnswerAlwaysWins() {
        assertTrue(OnboardingRules.welcomeDone(stored = true, isUpdatedInstall = false, skipForExistingInstalls = false))
        assertFalse(OnboardingRules.welcomeDone(stored = false, isUpdatedInstall = true, skipForExistingInstalls = true))
    }

    @Test
    fun typewriterCountsAndCutsByCodePoint() {
        val text = "Hey! \uD83D\uDC4B Hi" // the waving hand is two UTF-16 chars but one letter to type
        assertEquals(9, Typewriter.length(text))
        assertEquals("", Typewriter.prefix(text, 0))
        assertEquals("", Typewriter.prefix(text, -3))
        assertEquals("Hey! ", Typewriter.prefix(text, 5))
        assertEquals("Hey! \uD83D\uDC4B", Typewriter.prefix(text, 6)) // never half an emoji
        assertEquals(text, Typewriter.prefix(text, 9))
        assertEquals(text, Typewriter.prefix(text, 999))
    }

    @Test
    fun typewriterWorksOnPlainAndEmptyText() {
        assertEquals(0, Typewriter.length(""))
        assertEquals("", Typewriter.prefix("", 5))
        assertEquals("Chal", Typewriter.prefix("Chalo", 4))
    }
}
