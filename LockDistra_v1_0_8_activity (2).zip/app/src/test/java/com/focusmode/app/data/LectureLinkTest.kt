package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class LectureLinkTest {

    private val yt = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"

    // ---- YouTube ----
    @Test fun youtubeWatchLink() {
        val t = LectureLink.parse(yt)!!
        assertEquals(LecturePlatform.YOUTUBE, t.platform)
        assertEquals("dQw4w9WgXcQ", t.youtubeId)
        assertEquals(yt, t.url)
    }
    @Test fun youtubeShortLinkWithoutScheme_andShareText() {
        assertEquals("dQw4w9WgXcQ", LectureLink.parse("youtu.be/dQw4w9WgXcQ?si=abc")!!.youtubeId)
        assertEquals("dQw4w9WgXcQ", LectureLink.parse("Maths lecture https://youtu.be/dQw4w9WgXcQ")!!.youtubeId)
        assertEquals("dQw4w9WgXcQ", LectureLink.parse("https://m.youtube.com/shorts/dQw4w9WgXcQ")!!.youtubeId)
    }
    @Test fun youtubeWithoutOneVideoIsRejected() {
        assertNull(LectureLink.parse("https://www.youtube.com/"))
        assertNull(LectureLink.parse("https://www.youtube.com/@somechannel"))
        assertNull(LectureLink.parse("https://www.youtube.com/watch?v=short"))
    }

    // ---- other platforms and websites ----
    @Test fun facebookInstagramVimeo() {
        assertEquals(LecturePlatform.FACEBOOK, LectureLink.parse("https://fb.watch/abc123/")!!.platform)
        assertEquals(LecturePlatform.FACEBOOK, LectureLink.parse("https://www.facebook.com/watch/?v=123456")!!.platform)
        assertEquals(LecturePlatform.INSTAGRAM, LectureLink.parse("https://www.instagram.com/reel/Cabc123/")!!.platform)
        assertEquals(LecturePlatform.VIMEO, LectureLink.parse("vimeo.com/123456")!!.platform)
    }
    @Test fun anyWebsiteIsAccepted_andMadeHttps() {
        val t = LectureLink.parse("http://lectures.example.org/class/5")!!
        assertEquals(LecturePlatform.WEB, t.platform)
        assertEquals("lectures.example.org", t.host)
        assertEquals("https://lectures.example.org/class/5", t.url)
        assertEquals(setOf("lectures.example.org"), t.blockedHosts)
    }
    @Test fun driveViewLinkBecomesPreview() {
        val t = LectureLink.parse("https://drive.google.com/file/d/AbC_123/view?usp=sharing")!!
        assertEquals("https://drive.google.com/file/d/AbC_123/preview", t.url)
        assertTrue(t.blockedHosts.isEmpty())
    }

    // ---- not links ----
    @Test fun nonLinksAreRejected() {
        assertNull(LectureLink.parse(""))
        assertNull(LectureLink.parse("   "))
        assertNull(LectureLink.parse("hello world"))
        assertNull(LectureLink.parse("javascript:alert(1)"))
        assertNull(LectureLink.parse("file:///sdcard/a.mp4"))
        assertNull(LectureLink.parse("dQw4w9WgXcQ"))
    }

    // ---- which app / site is closed ----
    @Test fun platformAppsAndHosts() {
        val t = LectureLink.parse(yt)!!
        assertTrue(t.blocksApp("com.google.android.youtube"))
        assertFalse(t.blocksApp("com.facebook.katana"))
        assertTrue(LectureLink.hostMatchesAny("m.youtube.com", t.blockedHosts))
        assertTrue(LectureLink.hostMatchesAny("youtu.be", t.blockedHosts))
        assertFalse(LectureLink.hostMatchesAny("notyoutube.com", t.blockedHosts))
    }

    // ---- the player page stays on the lecture ----
    @Test fun youtubeSameVideoOnly() {
        val t = LectureLink.parse(yt)!!
        assertTrue(LectureLink.isSameLecture(t, "https://m.youtube.com/watch?v=dQw4w9WgXcQ&t=5"))
        assertFalse(LectureLink.isSameLecture(t, "https://m.youtube.com/watch?v=aaaaaaaaaaa"))
        assertFalse(LectureLink.isSameLecture(t, "https://m.youtube.com/"))
    }
    @Test fun websiteSamePageOnly() {
        val t = LectureLink.parse("https://www.facebook.com/watch/?v=123456")!!
        assertTrue(LectureLink.isSameLecture(t, "https://m.facebook.com/watch/?v=123456"))
        assertFalse(LectureLink.isSameLecture(t, "https://m.facebook.com/watch/?v=999"))
        assertFalse(LectureLink.isSameLecture(t, "https://m.facebook.com/"))
    }
    @Test fun settledPageAfterRedirectCounts() {
        val t = LectureLink.parse("https://fb.watch/abc123/")!!
        assertFalse(LectureLink.isSameLecture(t, "https://m.facebook.com/watch/?v=777"))
        assertTrue(LectureLink.isSameLecture(t, "https://m.facebook.com/watch/?v=777", settled = "https://m.facebook.com/watch/?v=777"))
    }
    @Test fun loginPagesStayReachable() {
        assertTrue(LectureLink.isLoginPage("https://m.facebook.com/login/?next=x"))
        assertTrue(LectureLink.isLoginPage("https://accounts.google.com/signin"))
        assertFalse(LectureLink.isLoginPage("https://m.facebook.com/watch/?v=1"))
    }
}
