package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WebsiteBlockingTest {

    private fun rule(d: String, sub: Boolean = true, on: Boolean = true) = WebsiteRule(d, on, sub)

    private val idle = FocusState(focusActive = false)
    private fun running(allowApps: Boolean) = FocusState(
        focusActive = true, sessionStart = 1L, sessionEnd = 10_000_000L, allowAppChanges = allowApps,
    )

    // ---- Normalization ---------------------------------------------------------------------

    @Test fun plainDomainIsKept() = assertEquals("youtube.com", WebsiteRules.normalize("youtube.com"))

    @Test fun schemeWwwPathQueryPortAreStripped() {
        assertEquals("youtube.com", WebsiteRules.normalize("https://www.YouTube.com/watch?v=abc#t=1"))
        assertEquals("youtube.com", WebsiteRules.normalize("http://youtube.com:8080/"))
        assertEquals("m.youtube.com", WebsiteRules.normalize("m.youtube.com/feed"))
        assertEquals("example.com", WebsiteRules.normalize("  user:pw@Example.com./x "))
        assertEquals("example.com", WebsiteRules.normalize("//example.com"))
    }

    @Test fun invalidInputIsRejected() {
        for (bad in listOf("", "   ", "youtube", "localhost", "how to youtube.com", "192.168.0.1",
            "a.b", "-bad.com", "bad-.com", "exa mple.com", "http://", "example.com:", "example.com:abc",
            "[::1]", "under_score.com", "x..com")) {
            assertNull("should reject '$bad'", WebsiteRules.normalize(bad))
        }
    }

    @Test fun internationalNamesBecomePunycode() {
        assertEquals("xn--bcher-kva.de", WebsiteRules.normalize("bücher.de"))
    }

    // ---- Matching --------------------------------------------------------------------------

    @Test fun exactAndSubdomainMatching() {
        val r = rule("youtube.com")
        assertTrue(WebsiteRules.matches("youtube.com", r))
        assertTrue(WebsiteRules.matches("m.youtube.com", r))
        assertTrue(WebsiteRules.matches("a.b.youtube.com", r))
        val exact = rule("youtube.com", sub = false)
        assertTrue(WebsiteRules.matches("youtube.com", exact))
        assertFalse(WebsiteRules.matches("m.youtube.com", exact))
    }

    @Test fun noPartialDomainMatching() {
        val r = rule("youtube.com")
        assertFalse(WebsiteRules.matches("notyoutube.com", r))
        assertFalse(WebsiteRules.matches("youtube.com.evil.net", r))
        assertFalse(WebsiteRules.matches("youtube.co", r))
        assertFalse(WebsiteRules.matches("fakeyoutube.com", r))
        assertFalse(WebsiteRules.matches("com", r))
    }

    @Test fun disabledRuleNeverMatches() =
        assertFalse(WebsiteRules.matches("youtube.com", rule("youtube.com", on = false)))

    @Test fun addressBarTextMatchesLikeATypedUrl() {
        val r = rule("youtube.com")
        // What Chrome shows unfocused / focused:
        assertTrue(WebsiteRules.normalize("m.youtube.com")?.let { WebsiteRules.matches(it, r) } == true)
        assertTrue(WebsiteRules.normalize("https://www.youtube.com/watch?v=1")?.let { WebsiteRules.matches(it, r) } == true)
        // Search text is not a host, so it never blocks:
        assertNull(WebsiteRules.normalize("youtube tutorial"))
        assertNull(WebsiteRules.normalize("Search or type web address"))
    }

    // ---- State -----------------------------------------------------------------------------

    @Test fun firstMatchOnlyUsesSwitchedOnAppsAndEnabledRules() {
        val s = WebsiteState(
            enabledApps = setOf("yt"),
            rules = mapOf(
                "yt" to listOf(rule("youtube.com"), rule("youtu.be", on = false)),
                "ig" to listOf(rule("instagram.com")), // app switch is off
            ),
        )
        assertEquals("yt", s.firstMatch("m.youtube.com")?.first)
        assertNull(s.firstMatch("youtu.be"))
        assertNull(s.firstMatch("instagram.com"))
        assertEquals(listOf("yt"), s.activeOwners())
        assertTrue(s.isRuleActive("yt", "youtube.com"))
        assertFalse(s.isRuleActive("yt", "youtu.be"))
        assertFalse(WebsiteState().hasActiveRules)
    }

    // ---- Browsers and catalog --------------------------------------------------------------

    @Test fun browserIdsArePackageQualified() {
        assertTrue(WebsiteBrowsers.isSupported("com.android.chrome"))
        assertEquals(listOf("com.android.chrome:id/url_bar"), WebsiteBrowsers.urlBarIds("com.android.chrome"))
        assertFalse(WebsiteBrowsers.isSupported("com.whatsapp"))
        assertTrue(WebsiteBrowsers.urlBarIds("com.whatsapp").isEmpty())
    }

    @Test fun catalogSuggestsDomainsAndIsValid() {
        assertTrue(WebsiteCatalog.supports("com.instagram.android"))
        assertFalse(WebsiteCatalog.supports("com.android.calculator2"))
        for (pkg in listOf("com.google.android.youtube", "com.instagram.android", "com.facebook.katana",
            "com.twitter.android", "com.discord", "org.telegram.messenger")) {
            WebsiteCatalog.suggested(pkg).forEach { assertEquals(it, WebsiteRules.normalize(it)) }
        }
    }

    // ---- Enforcement and session locks -----------------------------------------------------

    @Test fun enforcementNeedsSessionOrLimitAndNoExtraTime() {
        assertFalse(WebsitePolicy.shouldEnforce(sessionBlocks = false, limitBlocks = false, extraTime = false))
        assertTrue(WebsitePolicy.shouldEnforce(true, false, false))
        assertTrue(WebsitePolicy.shouldEnforce(false, true, false))
        assertFalse(WebsitePolicy.shouldEnforce(true, true, true))
    }

    @Test fun runningSessionAllowsOnlyTighteningAndOnlyIfAppChangesAllowed() {
        assertTrue(WebsitePolicy.canTighten(idle))
        assertTrue(WebsitePolicy.canLoosen(idle))
        assertTrue(WebsitePolicy.canTighten(running(allowApps = true)))
        assertFalse(WebsitePolicy.canLoosen(running(allowApps = true)))
        assertFalse(WebsitePolicy.canTighten(running(allowApps = false)))
        assertFalse(WebsitePolicy.canLoosen(running(allowApps = false)))
    }

    // ---- Blocked websites (standalone list) and adding several at once -----------------------

    @Test fun splitInputSeparatesByCommaSpaceAndNewline() {
        assertEquals(listOf("a.com", "b.com", "c.com", "d.com"), WebsiteRules.splitInput("a.com, b.com\nc.com;  d.com"))
        assertTrue(WebsiteRules.splitInput("  ,, \n ").isEmpty())
    }

    @Test fun standaloneListIsOnAsSoonAsItHoldsASite() {
        val g = WebsiteCatalog.GENERAL
        val s = WebsiteEdits.addSite(WebsiteState(), g, "https://www.Example.com/page", true, canTighten = true).state
        assertTrue(s.isOn(g))
        assertEquals(listOf("example.com"), s.rulesFor(g).map { it.domain })
        assertTrue(s.hasActiveRules)
        assertTrue(s.isRuleActive(g, "example.com"))
        // Sub pages and http / https forms of the same site are covered.
        for (typed in listOf("http://example.com/a/b?x=1", "https://m.example.com/", "example.com")) {
            assertNotNull(s.firstMatch(WebsiteRules.normalize(typed)!!, listOf(g)))
        }
        assertNull(s.firstMatch("notexample.com", listOf(g)))
    }

    @Test fun standaloneListDoesNotTouchAppLists() {
        val g = WebsiteCatalog.GENERAL
        val s0 = WebsiteEdits.setAppEnabled(WebsiteState(), "com.instagram.android", true, true, true)!!
        val s = WebsiteEdits.addSite(s0, g, "reddit.com", true, true).state
        assertEquals(listOf("instagram.com"), s.rulesFor("com.instagram.android").map { it.domain })
        assertEquals(listOf("reddit.com"), s.rulesFor(g).map { it.domain })
    }

    @Test fun duplicatesAreRefusedInTheStandaloneList() {
        val g = WebsiteCatalog.GENERAL
        val s = WebsiteEdits.addSite(WebsiteState(), g, "youtube.com", true, true).state
        for (again in listOf("youtube.com", "https://www.youtube.com/watch?v=1", "YOUTUBE.COM")) {
            assertEquals(WebsiteRules.Result.ALREADY_THERE, WebsiteEdits.addSite(s, g, again, true, true).result)
        }
    }

    @Test fun addSeveralAtOnceKeepsGoodOnesAndReportsTheRest() {
        val g = WebsiteCatalog.GENERAL
        val start = WebsiteEdits.addSite(WebsiteState(), g, "facebook.com", true, true).state
        val bulk = WebsiteEdits.addSites(start, g, "youtube.com, instagram.com\nfacebook.com, bad!one, youtube.com", true, true)
        assertEquals(listOf("youtube.com", "instagram.com"), bulk.added)
        assertEquals(listOf("facebook.com", "youtube.com"), bulk.duplicates)
        assertTrue(bulk.invalid.isNotEmpty())
        assertFalse(bulk.allDone)
        assertEquals(listOf("facebook.com", "youtube.com", "instagram.com"), bulk.state.rulesFor(g).map { it.domain })
    }

    @Test fun addSeveralIsLockedWhileSessionForbidsTightening() {
        val g = WebsiteCatalog.GENERAL
        val bulk = WebsiteEdits.addSites(WebsiteState(), g, "a.com, b.com", true, canTighten = false)
        assertTrue(bulk.locked)
        assertTrue(bulk.added.isEmpty())
        assertTrue(bulk.state.rulesFor(g).isEmpty())
    }

    @Test fun emptyInputIsNotAllDone() {
        val bulk = WebsiteEdits.addSites(WebsiteState(), WebsiteCatalog.GENERAL, "   ", true, true)
        assertFalse(bulk.allDone)
    }

    @Test fun standaloneSiteCanBeEditedSwitchedOffAndRemoved() {
        val g = WebsiteCatalog.GENERAL
        var s = WebsiteEdits.addSite(WebsiteState(), g, "old.com", true, true).state
        s = WebsiteEdits.editSite(s, g, "old.com", "new.com", false, true).state
        assertEquals("new.com", s.rulesFor(g).single().domain)
        assertFalse(s.rulesFor(g).single().subdomains)
        s = WebsiteEdits.setSiteEnabled(s, g, "new.com", false, true, true)!!
        assertFalse(s.hasActiveRules)
        assertNull(s.firstMatch("new.com", listOf(g)))
        s = WebsiteEdits.removeSite(s, g, "new.com", true)!!
        assertTrue(s.rulesFor(g).isEmpty())
    }
}
