package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingReactionsTest {

    private val empty = OnboardingAnswers()
    private fun mood(id: String, a: OnboardingAnswers = empty) = OnboardingReactions.moodFor(id, a)

    @Test
    fun everyQuestionHasItsOwnMoodFromTheSpec() {
        assertEquals(BuddyMood.Friendly, mood("name"))
        assertEquals(BuddyMood.Interested, mood("goal"))
        assertEquals(BuddyMood.Concerned, mood("distractions"))
        assertEquals(BuddyMood.Thoughtful, mood("phone_time"))
        assertEquals(BuddyMood.Encouraging, mood("session_length"))
        assertEquals(BuddyMood.Excited, mood("daily_goal"))
        assertEquals(BuddyMood.Curious, mood("source"))
        OnboardingQuestions.all.forEach { assertNotEquals(it.id, BuddyMood.Neutral, mood(it.id)) }
    }

    @Test
    fun enteringANameMakesTheMascotHappy() {
        assertEquals(BuddyMood.Friendly, mood("name", empty.withText("name", "   ")))
        assertEquals(BuddyMood.Happy, mood("name", empty.withText("name", "Sam")))
    }

    @Test
    fun phoneTimeAnswerChangesTheReaction() {
        fun m(opt: String) = mood("phone_time", empty.withSingle("phone_time", opt))
        assertEquals(BuddyMood.Pleased, m("lt_2h"))
        assertEquals(BuddyMood.Pleased, m("2_4h"))
        assertEquals(BuddyMood.Thoughtful, m("4_6h"))
        assertEquals(BuddyMood.Worried, m("6_8h"))
        assertEquals(BuddyMood.Worried, m("gt_8h"))
        assertEquals(BuddyMood.Thoughtful, m("not_sure"))
    }

    @Test
    fun answersToOtherQuestionsDoNotChangeTheirMood() {
        val a = empty.withSingle("goal", "study_better").withToggled("distractions", "gaming")
            .withSingle("session_length", "min_90").withSingle("daily_goal", "h_5_plus").withSingle("source", "youtube")
        assertEquals(BuddyMood.Interested, mood("goal", a))
        assertEquals(BuddyMood.Concerned, mood("distractions", a))
        assertEquals(BuddyMood.Encouraging, mood("session_length", a))
        assertEquals(BuddyMood.Excited, mood("daily_goal", a))
        assertEquals(BuddyMood.Curious, mood("source", a))
    }

    @Test
    fun unknownQuestionStaysNeutral() {
        assertEquals(BuddyMood.Neutral, mood("something_else"))
    }

    @Test
    fun choiceReactionFiresOnEveryChangeButNotWithoutOne() {
        val sig = { a: OnboardingAnswers -> OnboardingReactions.signature("distractions", a) }
        val none = sig(empty)
        val one = sig(empty.withToggled("distractions", "gaming"))
        val two = sig(empty.withToggled("distractions", "gaming").withToggled("distractions", "social_media"))
        assertEquals(none, sig(empty))
        assertNotEquals(none, one)
        assertNotEquals(one, two)
        assertEquals(none, sig(empty.withToggled("distractions", "gaming").withToggled("distractions", "gaming")))
        val g1 = OnboardingReactions.signature("goal", empty.withSingle("goal", "study_better"))
        val g2 = OnboardingReactions.signature("goal", empty.withSingle("goal", "focus_on_work"))
        assertNotEquals(g1, g2)
    }

    @Test
    fun typingANameReactsEveryThirdLetterNotEveryKey() {
        fun sig(name: String) = OnboardingReactions.signature("name", empty.withText("name", name))
        assertEquals(0, sig(""))
        assertEquals(0, sig("   "))
        assertNotEquals(sig(""), sig("S"))          // first letter reacts
        assertEquals(sig("S"), sig("Sa"))           // no reaction on every key
        assertNotEquals(sig("Sa"), sig("Sam"))      // third letter reacts
        assertEquals(sig("Sam"), sig("Sam "))       // trailing space is ignored
        assertTrue(sig("Samantha") > sig("Sam"))
    }
}
