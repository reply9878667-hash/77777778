package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class FocusProfileSettingsTest {

    private val yt = "com.google.android.youtube"
    private val ig = "com.instagram.android"

    @Test fun startsEmpty() {
        val s = FocusProfileSettings()
        assertTrue(s.isEmpty)
        assertEquals("Nothing selected yet", s.summary())
    }

    @Test fun appsAndGamesAreBlockedPerProfile() {
        val a = FocusProfileSettings().withBlocked(ig, true).withBlocked("com.some.game", true)
        assertEquals(setOf(ig, "com.some.game"), a.blocked)
        assertEquals(setOf("com.some.game"), a.withBlocked(ig, false).blocked)
        // The other profile's value is a different object and is not affected.
        assertTrue(FocusProfileSettings().blocked.isEmpty())
    }

    @Test fun shortsAndSectionFeatures() {
        val a = FocusProfileSettings().withShorts(true).withFeature(FeatureCatalog.IG_REELS, true)
        assertTrue(a.blockShorts)
        assertEquals(setOf(FeatureCatalog.IG_REELS), a.features)
        assertSame(a, a.withFeature("not_a_real_feature", true)) // unknown ids are ignored
        assertTrue(a.withFeature(FeatureCatalog.IG_REELS, false).features.isEmpty())
    }

    @Test fun limitsReplaceByPackageAndRemoveTheirEmergency() {
        val a = FocusProfileSettings()
            .withLimit(AppLimit(ig, 30, 5)).withLimit(AppLimit(ig, 45, 5)).withLimit(AppLimit(yt, 20, 0))
            .withLimitEmergency(ig, EmergencyDraft(true, 99, 99))
        assertEquals(listOf(45, 20), a.limits.map { it.limitMin })
        assertEquals(EmergencyDraft(true, LimitEmergencyRules.MAX_ATTEMPTS, LimitEmergencyRules.MAX_MINUTES), a.limitEmergency[ig])
        val b = a.withoutLimit(ig)
        assertEquals(listOf(yt), b.limits.map { it.pkg })
        assertFalse(b.limitEmergency.containsKey(ig))
    }

    @Test fun summaryCountsEverything() {
        val web = WebsiteEdits.setAppEnabled(WebsiteState(), ig, true, canTighten = true, canLoosen = true)!!
        val s = FocusProfileSettings()
            .withBlocked(ig, true).withBlocked(yt, true)
            .withShorts(true)
            .withWebsites(web)
            .withLimit(AppLimit(ig, 30, 5))
        assertEquals("2 apps/games • 1 Shorts/Reels • 1 site • 1 limit", s.summary())
        assertFalse(s.isEmpty)
    }

    @Test fun codecRoundTripsWebsiteRules() {
        val rules = mapOf(
            ig to listOf(WebsiteRule("instagram.com", true, true), WebsiteRule("example.org", false, false)),
            yt to listOf(WebsiteRule("youtu.be", true, false)),
        )
        assertEquals(rules, FocusProfileCodec.decodeRules(FocusProfileCodec.encodeRules(rules)))
        assertTrue(FocusProfileCodec.decodeRules(null).isEmpty())
        assertTrue(FocusProfileCodec.decodeRules("garbage").isEmpty())
    }

    @Test fun codecRoundTripsLimitsAndEmergency() {
        val limits = listOf(AppLimit(ig, 30, 5), AppLimit(yt, 60, 0)).sortedBy { it.pkg }
        assertEquals(limits, FocusProfileCodec.decodeLimits(FocusProfileCodec.encodeLimits(limits)))
        val emg = mapOf(ig to EmergencyDraft(true, 2, 3), yt to EmergencyDraft(false, 1, 1))
        assertEquals(emg, FocusProfileCodec.decodeEmergency(FocusProfileCodec.encodeEmergency(emg)))
        assertTrue(FocusProfileCodec.decodeLimits(setOf("bad", "pkg|0|1", "pkg|x|1")).isEmpty())
        assertTrue(FocusProfileCodec.decodeEmergency(setOf("bad", "pkg|1|x|1")).isEmpty())
    }
}

class WebsiteEditsTest {
    private val ig = "com.instagram.android"
    private val empty = WebsiteState()

    @Test fun switchingOnSeedsTheUsualSitesOnce() {
        val on = WebsiteEdits.setAppEnabled(empty, ig, true, true, true)!!
        assertTrue(on.isOn(ig))
        assertEquals(listOf("instagram.com"), on.rulesFor(ig).map { it.domain })
        // Off and on again keeps what is there instead of seeding twice.
        val back = WebsiteEdits.setAppEnabled(WebsiteEdits.setAppEnabled(on, ig, false, true, true)!!, ig, true, true, true)!!
        assertEquals(1, back.rulesFor(ig).size)
    }

    @Test fun lockedChangesAreRefused() {
        assertNull(WebsiteEdits.setAppEnabled(empty, ig, true, canTighten = false, canLoosen = true))
        assertEquals(WebsiteRules.Result.LOCKED, WebsiteEdits.addSite(empty, ig, "a.com", true, canTighten = false).result)
        assertNull(WebsiteEdits.removeSite(empty, ig, "a.com", canLoosen = false))
    }

    @Test fun addEditRemoveAndDuplicates() {
        val added = WebsiteEdits.addSite(empty, ig, "https://www.Example.com/x", true, true)
        assertEquals(WebsiteRules.Result.OK, added.result)
        assertEquals("example.com", added.state.rulesFor(ig).single().domain)
        assertEquals(WebsiteRules.Result.ALREADY_THERE, WebsiteEdits.addSite(added.state, ig, "example.com", true, true).result)
        assertEquals(WebsiteRules.Result.INVALID, WebsiteEdits.addSite(empty, ig, "not a site", true, true).result)
        val edited = WebsiteEdits.editSite(added.state, ig, "example.com", "other.org", false, true)
        assertEquals(WebsiteRules.Result.OK, edited.result)
        assertEquals(WebsiteRule("other.org", true, false), edited.state.rulesFor(ig).single())
        assertTrue(WebsiteEdits.removeSite(edited.state, ig, "other.org", true)!!.rulesFor(ig).isEmpty())
    }

    @Test fun siteSwitch() {
        val s = WebsiteEdits.addSite(empty, ig, "example.com", true, true).state
        val off = WebsiteEdits.setSiteEnabled(s, ig, "example.com", false, true, true)!!
        assertFalse(off.rulesFor(ig).single().enabled)
        assertNull(WebsiteEdits.setSiteEnabled(s, ig, "missing.com", false, true, true))
        assertSame(s, WebsiteEdits.setSiteEnabled(s, ig, "example.com", true, true, true))
    }

    @Test fun siteLimitPerApp() {
        var s = empty
        repeat(WebsiteRules.MAX_PER_APP) { s = WebsiteEdits.addSite(s, ig, "site$it.com", true, true).state }
        assertEquals(WebsiteRules.Result.FULL, WebsiteEdits.addSite(s, ig, "one-more.com", true, true).result)
    }
}
