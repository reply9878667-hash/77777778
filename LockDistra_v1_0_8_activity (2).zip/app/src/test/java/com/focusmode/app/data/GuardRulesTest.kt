package com.focusmode.app.data

import org.junit.Test
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue

class GuardRulesTest {
    @Test fun oemBatteryPackagesAreGuarded() {
        assertTrue(GuardRules.looksLikeOemGuardPackage("com.vivo.abe"))
        assertTrue(GuardRules.looksLikeOemGuardPackage("com.iqoo.powersaving"))
        assertTrue(GuardRules.looksLikeOemGuardPackage("com.miui.securitycenter"))
    }

    @Test fun launchersKeyboardsBrowsersAreNot() {
        assertFalse(GuardRules.looksLikeOemGuardPackage("com.bbk.launcher2"))
        assertFalse(GuardRules.looksLikeOemGuardPackage("com.vivo.browser"))
        assertFalse(GuardRules.looksLikeOemGuardPackage("com.android.systemui"))
    }

    @Test fun headerZone() {
        assertTrue(GuardRules.isInHeaderZone(235, 1600))
        assertFalse(GuardRules.isInHeaderZone(900, 1600))
        assertFalse(GuardRules.isInHeaderZone(-1, 1600))
    }

    @Test fun blindGuardClasses() {
        assertTrue(GuardRules.isDangerousWhileBlind("com.google.android.packageinstaller", "com.android.packageinstaller.UninstallerActivity"))
        assertTrue(GuardRules.isDangerousWhileBlind("com.android.settings", "com.android.settings.DeviceAdminAdd"))
        assertTrue(GuardRules.isDangerousWhileBlind("com.android.settings", "com.android.settings.applications.InstalledAppDetails"))
        assertFalse(GuardRules.isDangerousWhileBlind("com.android.settings", "com.android.settings.SubSettings"))
        assertFalse(GuardRules.isDangerousWhileBlind("com.android.settings", "com.android.settings.accessibility.AccessibilitySettings"))
    }
}
