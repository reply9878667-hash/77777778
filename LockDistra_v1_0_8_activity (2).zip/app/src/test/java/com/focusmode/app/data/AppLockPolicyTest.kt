package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AppLockPolicyTest {

    // ---- New PIN / password rules ---------------------------------------------------------------

    @Test fun pinLengthIsChecked() {
        assertNotNull(LockRules.validate(LockType.PIN, "135"))
        assertNull(LockRules.validate(LockType.PIN, "1357"))
        assertNull(LockRules.validate(LockType.PIN, "13572468"))
        assertNotNull(LockRules.validate(LockType.PIN, "135724681"))
    }

    @Test fun pinMustBeDigits() {
        assertNotNull(LockRules.validate(LockType.PIN, "12a45"))
        assertNotNull(LockRules.validate(LockType.PIN, "13 57"))
    }

    @Test fun easyPinsAreRefused() {
        assertTrue(LockRules.isTooSimple("1111"))
        assertTrue(LockRules.isTooSimple("0000"))
        assertTrue(LockRules.isTooSimple("1234"))
        assertTrue(LockRules.isTooSimple("987654"))
        assertFalse(LockRules.isTooSimple("1357"))
        assertFalse(LockRules.isTooSimple("2580"))
        assertNotNull(LockRules.validate(LockType.PIN, "123456"))
    }

    @Test fun passwordRules() {
        assertNotNull(LockRules.validate(LockType.PASSWORD, "abc"))
        assertNotNull(LockRules.validate(LockType.PASSWORD, "      "))
        assertNotNull(LockRules.validate(LockType.PASSWORD, "aaaaaa"))
        assertNotNull(LockRules.validate(LockType.PASSWORD, "ab".repeat(20)))
        assertNull(LockRules.validate(LockType.PASSWORD, "river-Stone7"))
    }

    // ---- Pauses after wrong tries -----------------------------------------------------------------

    @Test fun firstFiveWrongTriesAreFree() {
        for (n in 1 until LockRules.FREE_TRIES) assertEquals(0L, LockRules.lockoutMs(n))
        assertEquals(30_000L, LockRules.lockoutMs(LockRules.FREE_TRIES))
    }

    @Test fun pausesGrowAndStopAtOneHour() {
        val steps = (5..12).map { LockRules.lockoutMs(it) }
        assertEquals(steps.sorted(), steps)
        assertEquals(LockRules.MAX_LOCKOUT_MS, LockRules.lockoutMs(50))
        assertEquals(LockRules.MAX_LOCKOUT_MS, steps.max())
    }

    @Test fun triesLeftNeverGoesNegative() {
        assertEquals(5, LockRules.triesLeftBeforePause(0))
        assertEquals(1, LockRules.triesLeftBeforePause(4))
        assertEquals(0, LockRules.triesLeftBeforePause(9))
    }

    @Test fun waitIsShownAsMinutesAndSeconds() {
        assertEquals("30s", LockRules.formatWait(30_000))
        assertEquals("1:00", LockRules.formatWait(60_000))
        assertEquals("4:59", LockRules.formatWait(298_001))
        assertEquals("0s", LockRules.formatWait(0))
    }

    // ---- When the lock screen comes back ------------------------------------------------------------

    @Test fun lockedAtOnceWhenGraceIsZero() {
        assertTrue(LockRules.shouldRelock(true, true, awayMs = 0, graceSeconds = 0, viaOwnLaunch = false))
        assertTrue(LockRules.shouldRelock(true, true, awayMs = 5_000, graceSeconds = 0, viaOwnLaunch = false))
    }

    @Test fun graceKeepsAppOpenForAShortTrip() {
        assertFalse(LockRules.shouldRelock(true, true, awayMs = 29_000, graceSeconds = 30, viaOwnLaunch = false))
        assertTrue(LockRules.shouldRelock(true, true, awayMs = 30_000, graceSeconds = 30, viaOwnLaunch = false))
    }

    @Test fun permissionTripsGetMoreRoomButNotForever() {
        // A visit to Accessibility settings that the app started itself.
        assertFalse(LockRules.shouldRelock(true, true, awayMs = 60_000, graceSeconds = 0, viaOwnLaunch = true))
        assertTrue(LockRules.shouldRelock(true, true, awayMs = LockRules.INTERNAL_LAUNCH_GRACE_MS, graceSeconds = 0, viaOwnLaunch = true))
        // A longer chosen grace still wins over the permission allowance.
        assertFalse(LockRules.shouldRelock(true, true, awayMs = 299_000L, graceSeconds = 300, viaOwnLaunch = false))
        assertTrue(LockRules.shouldRelock(true, true, awayMs = 301_000L, graceSeconds = 300, viaOwnLaunch = true))
    }

    @Test fun nothingToRelockWhenOffOrAlreadyLocked() {
        assertFalse(LockRules.shouldRelock(false, true, 999_999, 0, false))
        assertFalse(LockRules.shouldRelock(true, false, 999_999, 0, false))
    }

    // ---- Hashing ----------------------------------------------------------------------------------

    private val fastRounds = 1_000

    @Test fun sameSecretAndSaltGiveTheSameHash() {
        val salt = Credentials.newSalt()
        assertTrue(Credentials.equal(Credentials.hash("2580", salt, fastRounds), Credentials.hash("2580", salt, fastRounds)))
    }

    @Test fun differentSecretOrSaltGiveADifferentHash() {
        val salt = Credentials.newSalt()
        val a = Credentials.hash("2580", salt, fastRounds)
        assertFalse(Credentials.equal(a, Credentials.hash("2581", salt, fastRounds)))
        assertFalse(Credentials.equal(a, Credentials.hash("2580", Credentials.newSalt(), fastRounds)))
    }

    @Test fun hashIs256BitAndNotThePin() {
        val h = Credentials.hash("2580", Credentials.newSalt(), fastRounds)
        assertEquals(32, h.size)
        assertNotEquals("2580", String(h))
    }

    @Test fun saltsDiffer() {
        assertFalse(Credentials.newSalt().contentEquals(Credentials.newSalt()))
    }

    @Test fun base64RoundTrips() {
        val bytes = Credentials.newSalt()
        assertTrue(Credentials.unb64(Credentials.b64(bytes)).contentEquals(bytes))
    }

    // ---- Recovery code ------------------------------------------------------------------------------

    @Test fun recoveryCodeLooksRight() {
        val code = Credentials.newRecoveryCode()
        assertEquals(19, code.length) // 16 characters + 3 dashes
        assertTrue(Regex("[A-HJ-NP-Z2-9]{4}(-[A-HJ-NP-Z2-9]{4}){3}").matches(code))
        assertTrue(Credentials.isRecoveryShapeValid(code))
    }

    @Test fun recoveryCodesDoNotRepeat() {
        val codes = (1..200).map { Credentials.newRecoveryCode() }.toSet()
        assertEquals(200, codes.size)
    }

    @Test fun recoveryCodeIsForgivingAboutTyping() {
        val code = Credentials.newRecoveryCode()
        val typed = code.lowercase().replace("-", " ")
        assertEquals(Credentials.normalizeRecovery(code), Credentials.normalizeRecovery(typed))
        assertEquals(Credentials.RECOVERY_LENGTH, Credentials.normalizeRecovery(typed).length)
    }

    @Test fun shortOrJunkRecoveryInputIsRejected() {
        assertFalse(Credentials.isRecoveryShapeValid(""))
        assertFalse(Credentials.isRecoveryShapeValid("ABCD-EFGH"))
        assertFalse(Credentials.isRecoveryShapeValid("1111-1111-1111-1111")) // 0/1/O/I are not in the alphabet
    }
}
