package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class LectureLayoutTest {

    private val minPanel = 180 * 3 // 180 dp at density 3

    @Test fun widescreenVideoOnATallPhone_showsThePanel() {
        val p = LectureLayout.plan(available = 2000, width = 1080, ratio = 16f / 9f, minPanel = minPanel)
        assertEquals(607, p.videoHeight)
        assertTrue(p.showPanel)
    }

    @Test fun fourByThreeVideo_isTallerButStillLeavesRoom() {
        val p = LectureLayout.plan(2000, 1080, 4f / 3f, minPanel)
        assertEquals(810, p.videoHeight)
        assertTrue(p.showPanel)
    }

    @Test fun verticalVideo_leavesNoRoom_panelIsHidden_videoGetsTheWholeHeight() {
        val p = LectureLayout.plan(2000, 1080, 9f / 16f, minPanel)
        assertFalse(p.showPanel)
        assertEquals(2000, p.videoHeight)
    }

    @Test fun exactlyEnoughRoom_showsPanel_oneLessPixel_hidesIt() {
        val video = (1080 / (16f / 9f)).toInt()
        assertTrue(LectureLayout.plan(video + minPanel, 1080, 16f / 9f, minPanel).showPanel)
        assertFalse(LectureLayout.plan(video + minPanel - 1, 1080, 16f / 9f, minPanel).showPanel)
    }

    @Test fun notMeasuredYet_keepsPanelUntilRealSizeIsKnown() {
        assertTrue(LectureLayout.plan(0, 1080, 16f / 9f, minPanel).showPanel)
    }

    @Test fun badRatioFallsBackTo16by9() {
        assertEquals(LectureLayout.DEFAULT_RATIO, LectureLayout.clampRatio(0f), 0.0001f)
        assertEquals(LectureLayout.DEFAULT_RATIO, LectureLayout.clampRatio(Float.NaN), 0.0001f)
    }

    @Test fun oEmbedAnswer_givesTheShape() {
        assertEquals(16f / 9f, VideoRatio.parseOEmbed("""{"width":200,"height":113}""")!!, 0.01f)
        assertEquals(4f / 3f, VideoRatio.parseOEmbed("""{"width":200,"height":150}""")!!, 0.01f)
        assertEquals(113f / 200f, VideoRatio.parseOEmbed("""{"width":113,"height":200}""")!!, 0.01f)
        assertNull(VideoRatio.parseOEmbed("""{"title":"x"}"""))
        assertNull(VideoRatio.parseOEmbed("not json"))
    }

    @Test fun shortsAndReelsLinks_areVertical() {
        assertEquals(9f / 16f, VideoRatio.fromLink("https://www.youtube.com/shorts/abcdefghijk")!!, 0.001f)
        assertEquals(9f / 16f, VideoRatio.fromLink("https://www.instagram.com/reel/xyz/")!!, 0.001f)
        assertEquals(9f / 16f, VideoRatio.fromLink("https://www.facebook.com/reel/123")!!, 0.001f)
        assertNull(VideoRatio.fromLink("https://www.youtube.com/watch?v=abcdefghijk"))
        assertNull(VideoRatio.fromLink("https://vimeo.com/123"))
    }
}
