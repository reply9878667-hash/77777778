package com.focusmode.app.data.auth

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthErrorsTest {

    @Test
    fun firebaseCodesMapToKinds() {
        assertEquals(AuthErrorKind.EMAIL_IN_USE, AuthErrors.kindOfFirebaseCode("ERROR_EMAIL_ALREADY_IN_USE"))
        assertEquals(AuthErrorKind.WEAK_PASSWORD, AuthErrors.kindOfFirebaseCode("ERROR_WEAK_PASSWORD"))
        assertEquals(AuthErrorKind.INVALID_EMAIL, AuthErrors.kindOfFirebaseCode("ERROR_INVALID_EMAIL"))
        assertEquals(AuthErrorKind.USER_DISABLED, AuthErrors.kindOfFirebaseCode("ERROR_USER_DISABLED"))
        assertEquals(AuthErrorKind.TOO_MANY_REQUESTS, AuthErrors.kindOfFirebaseCode("ERROR_TOO_MANY_REQUESTS"))
        assertEquals(AuthErrorKind.OFFLINE, AuthErrors.kindOfFirebaseCode("ERROR_NETWORK_REQUEST_FAILED"))
        assertEquals(AuthErrorKind.PROVIDER_DISABLED, AuthErrors.kindOfFirebaseCode("ERROR_OPERATION_NOT_ALLOWED"))
        assertEquals(AuthErrorKind.UNKNOWN, AuthErrors.kindOfFirebaseCode("SOMETHING_NEW"))
        assertEquals(AuthErrorKind.UNKNOWN, AuthErrors.kindOfFirebaseCode(null))
    }

    @Test
    fun wrongPasswordAndUnknownUserLookTheSame() {
        // The login form must not reveal whether an email has an account.
        val a = AuthErrors.kindOfFirebaseCode("ERROR_WRONG_PASSWORD")
        val b = AuthErrors.kindOfFirebaseCode("ERROR_USER_NOT_FOUND")
        val c = AuthErrors.kindOfFirebaseCode("ERROR_INVALID_LOGIN_CREDENTIALS")
        assertEquals(AuthErrorKind.WRONG_CREDENTIALS, a)
        assertEquals(a, b)
        assertEquals(a, c)
    }

    @Test
    fun everyKindHasAMessage() {
        AuthErrorKind.values().forEach { assertTrue(AuthErrors.message(it).isNotBlank()) }
    }

    @Test
    fun onlyDefiniteCodesEndASavedLogin() {
        assertTrue(AuthErrors.isDeadSessionCode("ERROR_USER_DISABLED"))
        assertTrue(AuthErrors.isDeadSessionCode("ERROR_USER_NOT_FOUND"))
        assertTrue(AuthErrors.isDeadSessionCode("ERROR_USER_TOKEN_EXPIRED"))
        assertFalse(AuthErrors.isDeadSessionCode("ERROR_NETWORK_REQUEST_FAILED"))
        assertFalse(AuthErrors.isDeadSessionCode(null))
    }
}
