package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * Part 4/4: source recovery, health monitoring, false-warning prevention and the integration scenarios.
 * Fake clock, fake phone facts, its own tracker: no Android, no network, no waiting.
 */
class StudyRecoveryTest {

    private class FakeFacts : SourceFacts {
        val on = mutableMapOf(StudyMode.API to true, StudyMode.PAGE to true, StudyMode.WEB to true)
        var keys = 1
        var rest: ApiRest? = null
        override fun enabled(mode: StudyMode) = on.getValue(mode)
        override fun apiKeyCount() = keys
        override fun apiRest(now: Long): ApiRest? = rest?.takeIf { it.until > now }
    }

    private var now = 1_000_000L
    private lateinit var t: SourceTracker
    private lateinit var sw: SourceSwitcher
    private lateinit var facts: FakeFacts
    private val calls = ArrayList<StudyMode>()

    @Before fun setUp() {
        now = 1_000_000L
        t = SourceTracker()
        sw = SourceSwitcher(t) { now }
        facts = FakeFacts()
        calls.clear()
    }

    // ---- helpers -------------------------------------------------------------------------------------------------

    private val netFail = SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE)
    private fun network(src: StudyMode = StudyMode.API) = StudyException(StudyErrorKind.NETWORK, "net", source = src, reason = SourceReason.UNREACHABLE)
    private fun ok(mode: StudyMode): () -> String = { calls += mode; mode.name }
    private fun fail(mode: StudyMode, e: Exception): () -> String = { calls += mode; throw e }

    private fun run(api: (() -> String)? = null, page: (() -> String)? = null, key: String = "maths", manual: Boolean = false): String {
        val m = LinkedHashMap<StudyMode, () -> String>()
        api?.let { m[StudyMode.API] = it }
        page?.let { m[StudyMode.PAGE] = it }
        return sw.run(StudyOp.SEARCH, key, facts, manual, m)
    }

    private inline fun <reified E : StudyException> expect(block: () -> Unit): E {
        try { block() } catch (e: StudyException) {
            if (e is E) return e
            throw AssertionError("Expected " + E::class.java.simpleName + " but got " + e.javaClass.simpleName + ": " + e.message)
        }
        throw AssertionError("Expected " + E::class.java.simpleName + " but nothing was thrown")
    }

    // ---- 1. Health monitoring ------------------------------------------------------------------------------------

    @Test fun health_tracksFailureThenRecovery() {
        t.failure(StudyMode.API, netFail, now)
        var h = t.health(StudyMode.API, now)
        assertFalse(h.available)
        assertEquals(RecoveryStatus.WAITING, h.recovery)
        assertEquals(30_000L, h.retryInMs)
        assertEquals(1, h.consecutiveFailures)
        assertEquals(SourceReason.UNREACHABLE, h.lastFailureReason)
        assertEquals(now, h.lastFailureAt)

        now += 31_000
        assertEquals(RecoveryStatus.RETRY_DUE, t.health(StudyMode.API, now).recovery)

        t.success(StudyMode.API, now, responseMs = 200)
        h = t.health(StudyMode.API, now)
        assertTrue(h.available)
        assertEquals(RecoveryStatus.RECOVERED, h.recovery)
        assertEquals(0, h.consecutiveFailures)
        assertEquals(200L, h.responseMs)
        assertEquals(now, h.lastSuccessAt)
        // What went wrong before is still known after the recovery.
        assertEquals(SourceReason.UNREACHABLE, h.lastFailureReason)

        assertEquals(RecoveryStatus.HEALTHY, t.health(StudyMode.API, now + SourceTracker.RECOVERED_SHOWN_MS + 1).recovery)
    }

    @Test fun health_responseTimeIsSmoothed() {
        t.success(StudyMode.PAGE, now, responseMs = 200)
        t.success(StudyMode.PAGE, now + 1, responseMs = 400)
        assertEquals(250L, t.health(StudyMode.PAGE, now + 2).responseMs)
        t.success(StudyMode.PAGE, now + 3) // not measured: the number stays
        assertEquals(250L, t.health(StudyMode.PAGE, now + 4).responseMs)
    }

    @Test fun health_neverUsedSourceIsNotAFailure() {
        val h = t.health(StudyMode.WEB, now)
        assertEquals(SourceStatus.UNKNOWN, h.status)
        assertEquals(RecoveryStatus.HEALTHY, h.recovery)
        assertEquals(0, h.consecutiveFailures)
        assertEquals(3, t.healthAll(now).size)
    }

    @Test fun health_phoneBlockedSourceHasNothingToRetry() {
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, false, true, false), now)
        val h = t.health(StudyMode.PAGE, now)
        assertEquals(SourceStatus.DISABLED, h.status)
        assertEquals(RecoveryStatus.BLOCKED_BY_PHONE, h.recovery)
        assertEquals(0L, h.retryInMs)
    }

    @Test fun health_quotaWaitsForTheReset() {
        val reset = SourceClassifier.nextQuotaReset(now)
        t.failure(StudyMode.API, SourceFailure(SourceStatus.QUOTA_EXHAUSTED, SourceReason.DAILY_LIMIT, reset), now)
        val h = t.health(StudyMode.API, now)
        assertEquals(RecoveryStatus.WAITING, h.recovery)
        assertEquals(reset - now, h.retryInMs)
        assertEquals(RecoveryStatus.RETRY_DUE, t.health(StudyMode.API, reset).recovery)
    }

    // ---- 2. Recovery detection ---------------------------------------------------------------------------------

    @Test fun recoveredSourceIsAvailableAgain_forEachOfTheThreeSources() {
        for (m in StudyMode.values()) {
            t.failure(m, netFail, now)
            assertFalse(t.state(m).available)
            now += 31_000
            t.success(m, now)
            assertTrue(m.name, t.state(m).available)
            assertEquals(m.name, SourceReason.NONE, t.state(m).reason)
            assertFalse(m.name, t.due(m, now + 1_000_000L))
        }
    }

    @Test fun networkRestored_endsOnlyTheNetworkCooldowns() {
        t.failure(StudyMode.WEB, netFail, now)
        t.failure(StudyMode.PAGE, SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT), now)
        t.failure(StudyMode.PAGE, SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT), now + 1)
        val reset = SourceClassifier.nextQuotaReset(now)
        t.failure(StudyMode.API, SourceFailure(SourceStatus.QUOTA_EXHAUSTED, SourceReason.DAILY_LIMIT, reset), now)

        t.networkRestored(now + 2_000)

        assertEquals(0L, t.state(StudyMode.WEB).retryAt)
        assertEquals(0, t.state(StudyMode.WEB).failures)
        assertEquals(0L, t.state(StudyMode.PAGE).retryAt)
        // A used-up daily limit is a fact about YouTube's quota, not about the phone's network: it stays.
        assertEquals(SourceStatus.QUOTA_EXHAUSTED, t.state(StudyMode.API).status)
        assertEquals(reset, t.state(StudyMode.API).retryAt)
        assertTrue(t.due(StudyMode.WEB, now + 12_000))
        assertFalse(t.due(StudyMode.API, now + 12_000))
    }

    @Test fun networkRestored_doesNotTouchPhoneBlockedOrServerErrorSources() {
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, false, true, false), now)
        t.failure(StudyMode.WEB, SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.SERVER_ERROR), now)
        val webRetry = t.state(StudyMode.WEB).retryAt
        t.networkRestored(now + 1_000)
        assertEquals(SourceStatus.DISABLED, t.state(StudyMode.PAGE).status)
        assertEquals(SourceReason.APP_DISABLED, t.state(StudyMode.PAGE).reason)
        assertEquals(webRetry, t.state(StudyMode.WEB).retryAt)
    }

    @Test fun noInternetFact_isClearedWhenThePhoneIsOnlineAgain() {
        t.applyLocal(StudyMode.API, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.NO_INTERNET), now)
        assertEquals(Long.MAX_VALUE, t.state(StudyMode.API).retryAt)
        val before = t.recoveryEpoch
        t.applyLocal(StudyMode.API, null, now + 5_000)
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.API).status)
        assertTrue(t.recoveryEpoch > before)
    }

    @Test fun aQuotaStateIsNotHiddenByNoInternet() {
        t.failure(StudyMode.API, SourceFailure(SourceStatus.QUOTA_EXHAUSTED, SourceReason.DAILY_LIMIT, now + 3_600_000L), now)
        t.applyLocal(StudyMode.API, SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.NO_INTERNET), now + 1)
        assertEquals(SourceStatus.QUOTA_EXHAUSTED, t.state(StudyMode.API).status)
    }

    // ---- 3. Loop prevention: a source that flips between working and failing ----------------------------------

    @Test fun failingAgainRightAfterARecovery_doesNotStartOverAtThirtySeconds() {
        t.failure(StudyMode.API, netFail, now)
        t.failure(StudyMode.API, netFail, now + 30_000)
        t.failure(StudyMode.API, netFail, now + 90_000)
        assertEquals(3, t.state(StudyMode.API).failures)
        val back = now + 100_000
        t.success(StudyMode.API, back)
        val again = back + 20_000 // inside the flap window
        t.failure(StudyMode.API, netFail, again)
        assertEquals(4, t.state(StudyMode.API).failures)
        assertEquals(240_000L, t.state(StudyMode.API).retryAt - again)
    }

    @Test fun failingLongAfterARecovery_startsFresh() {
        t.failure(StudyMode.API, netFail, now)
        t.failure(StudyMode.API, netFail, now + 30_000)
        t.success(StudyMode.API, now + 100_000)
        val later = now + 100_000 + SourceTracker.FLAP_WINDOW_MS + 1
        t.failure(StudyMode.API, netFail, later)
        assertEquals(1, t.state(StudyMode.API).failures)
        assertEquals(30_000L, t.state(StudyMode.API).retryAt - later)
    }

    @Test fun repeatedFailuresAndRecoveries_neverLeaveAStuckState() {
        var at = now
        repeat(5) {
            t.failure(StudyMode.WEB, netFail, at)
            assertEquals(SourceStatus.NETWORK_ERROR, t.state(StudyMode.WEB).status)
            at += 5 * 60_000L // far outside the flap window
            t.success(StudyMode.WEB, at)
            assertTrue(t.state(StudyMode.WEB).available)
            assertEquals(0, t.state(StudyMode.WEB).failures)
            assertEquals(0L, t.state(StudyMode.WEB).retryAt)
            at += 5 * 60_000L
        }
    }

    // ---- 4. Intelligent selection: a recovered preferred source is preferred again --------------------------------

    @Test fun recoveredApiIsPreferredAgainForTheNextRequest() {
        assertEquals("PAGE", run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE), key = "a"))
        now += 5_000
        // Still cooling: the next request does not wait for it.
        calls.clear()
        assertEquals("PAGE", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "b"))
        assertEquals(listOf(StudyMode.PAGE), calls)
        // A re-check found the API working again (recorded by StudyApi itself): the very next request goes back to it.
        t.success(StudyMode.API, now)
        calls.clear()
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "c"))
        assertEquals(listOf(StudyMode.API), calls)
    }

    @Test fun aRecoveryDoesNotChangeTheSourceOfAnAlreadyFinishedRequest() {
        val first = run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE), key = "a")
        t.success(StudyMode.API, now + 1_000) // recovery: only the status changes, nothing is re-run
        assertEquals("PAGE", first)
        assertEquals(listOf(StudyMode.API, StudyMode.PAGE), calls)
    }

    // ---- 5. Scenarios --------------------------------------------------------------------------------------------

    @Test fun scenario1_allThreeWorking_apiServes() {
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.API), calls)
    }

    @Test fun scenario2_quotaExhausted_directServesThenApiRecoversAfterTheReset() {
        facts.rest = ApiRest(now + 20L * 3_600_000L, SourceReason.DAILY_LIMIT)
        assertEquals("PAGE", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "a"))
        assertEquals(listOf(StudyMode.PAGE), calls)
        now += 21L * 3_600_000L // the limit reset: the key stops resting
        calls.clear()
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "b"))
    }

    @Test fun scenario3_directUnavailable_webTakesOver() {
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, false, null, true, false), now)
        expect<WebHandoff> { run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE)) }
        assertEquals(listOf(StudyMode.API), calls)
    }

    @Test fun scenario4_webUnavailable_othersStillServe() {
        t.failure(StudyMode.WEB, SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.SERVER_ERROR), now)
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
        assertEquals("PAGE", run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE), key = "b"))
    }

    @Test fun scenario5and6_youtubeAppDisabledThenEnabled() {
        // disabled: only Direct YouTube is blocked, and it is blocked with the TRUE reason
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, false, true, false), now)
        assertEquals(Pick.Blocked(SourceReason.APP_DISABLED), sw.check(StudyMode.PAGE, facts, now))
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "a"))
        assertFalse(StudyMode.PAGE in calls)

        // enabled again: the next read of the phone clears it, Direct YouTube serves when the API cannot
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, true, true, false), now + 1_000)
        assertEquals(Pick.Use, sw.check(StudyMode.PAGE, facts, now + 1_000))
        now += 10_000
        calls.clear()
        assertEquals("PAGE", run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE), key = "b"))
    }

    @Test fun scenario7_internetDisconnected_oneHonestMessage() {
        t.failure(StudyMode.WEB, netFail, now)
        val e = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        assertEquals("No internet connection", e.title)
        assertEquals(StudyErrorKind.NETWORK, e.kind)
        assertNoFalseWarning(e)
    }

    @Test fun scenario8_internetReturns_theSameRequestWorksAtOnce() {
        t.failure(StudyMode.WEB, netFail, now)
        val first = expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        // Right away the same request is answered from the short memory, without asking anybody again.
        calls.clear()
        val memo = expect<SourcesExhausted> { run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)) }
        assertSame(first, memo)
        assertTrue(calls.isEmpty())
        // The connection comes back: the memory of the failure is stale and the cool-downs are over.
        t.networkRestored(now)
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.API), calls)
    }

    @Test fun scenario8b_aRecoveryOfAnySourceClearsTheStaleFailureMemory() {
        facts.on[StudyMode.WEB] = false
        expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE))) }
        t.success(StudyMode.PAGE, now + 1_000) // a re-check found Direct YouTube working
        now += 1_000
        calls.clear()
        assertEquals("PAGE", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)))
    }

    @Test fun scenario9_previouslyFailedApiWorksAgain() {
        run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE), key = "a")
        now += 31_000 // the cool-down is over: the API is asked again by itself
        calls.clear()
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "b"))
        t.success(StudyMode.API, now)
        assertTrue(t.state(StudyMode.API).available)
    }

    @Test fun scenario10_severalSourcesFailTogether_theErrorNamesTheVerifiedReasons() {
        facts.on[StudyMode.WEB] = false
        t.applyLocal(StudyMode.PAGE, SourceClassifier.directLocal(true, true, false, true, false), now)
        facts.rest = ApiRest(now + 20L * 3_600_000L, SourceReason.DAILY_LIMIT)
        val e = expect<SourcesExhausted> { run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE)) }
        assertTrue(calls.isEmpty())
        assertTrue(e.message.orEmpty().contains("daily limit"))
        assertNoFalseWarning(e)
    }

    @Test fun scenario11_failureWhileSwitching_nextSourceTakesOverInTheSameCall() {
        assertEquals("PAGE", run(api = fail(StudyMode.API, network()), page = ok(StudyMode.PAGE)))
        assertEquals(listOf(StudyMode.API, StudyMode.PAGE), calls)
        assertEquals(SourceStatus.NETWORK_ERROR, t.state(StudyMode.API).status)
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.WEB).status) // the untouched source is not blamed
    }

    @Test fun scenario12_repeatedFailuresDoNotLoopAndRecoveryEndsThem() {
        facts.on[StudyMode.WEB] = false
        repeat(3) { i ->
            expect<SourcesExhausted> { run(api = fail(StudyMode.API, network()), page = fail(StudyMode.PAGE, network(StudyMode.PAGE)), key = "same") }
            now += 4_000 // past the 3 s memory, before the 30 s cool-downs end
            assertTrue("round $i: neither source asked again while cooling", calls.size <= 2)
        }
        assertEquals(2, calls.size) // each source was asked exactly once in all those rounds
        t.networkRestored(now)
        calls.clear()
        assertEquals("API", run(api = ok(StudyMode.API), page = ok(StudyMode.PAGE), key = "same"))
    }

    @Test fun scenario13_channelProfileAndThumbnailSurviveASourceChange() {
        val fromApi = StudyVideo("abc12345678", "Maths", "UC1", "Maths Channel", "https://i.ytimg.com/vi/abc12345678/hqdefault.jpg", 600, "27", true, 1_000L, "desc")
        val fromDirect = StudyVideo("abc12345678", "Maths", "", "", StudyRules.fallbackThumb("abc12345678"), 600, "", true)
        val both = StudyMerge.merge(listOf(fromDirect), listOf(fromApi))
        assertEquals(1, both.size)
        assertEquals("abc12345678", both[0].id)
        assertEquals("UC1", both[0].channelId)
        assertEquals("Maths Channel", both[0].channelTitle)
        assertTrue(both[0].thumbUrl.contains("abc12345678"))
        // the other order keeps the API's richer copy as it was
        val other = StudyMerge.merge(listOf(fromApi), listOf(fromDirect))
        assertEquals("UC1", other[0].channelId)
        assertEquals("https://i.ytimg.com/vi/abc12345678/hqdefault.jpg", other[0].thumbUrl)
    }

    // ---- 6. False-warning prevention -------------------------------------------------------------------------------

    private val forbidden = listOf("please enable", "is disabled", "is unavailable", "youtube is disabled", "web is unavailable", "enable youtube", "enable web")

    private fun assertNoFalseWarning(e: SourcesExhausted) {
        val text = (e.title + " " + e.message.orEmpty()).lowercase()
        forbidden.forEach { assertFalse("\"$it\" in: $text", text.contains(it)) }
    }

    @Test fun noReasonEverProducesAGenericDisabledWarning() {
        for (r in SourceReason.values()) {
            val attempts = StudyMode.values().map { SourceAttempt(it, false, r) }
            assertNoFalseWarning(SwitchMessages.exhausted(attempts))
            // and a single source with that reason never gets a generic phrase
            StudyMode.values().forEach { m ->
                val p = SwitchMessages.reasonPhrase(m, r)?.lowercase().orEmpty()
                forbidden.forEach { assertFalse("$r: $p", p.contains(it)) }
            }
        }
    }

    @Test fun anUnknownCauseIsNeverNamed() {
        assertNull(SwitchMessages.reasonPhrase(StudyMode.API, SourceReason.UNKNOWN_ERROR))
        assertNull(SwitchMessages.reasonPhrase(StudyMode.WEB, SourceReason.NONE))
        val e = SwitchMessages.exhausted(
            listOf(SourceAttempt(StudyMode.API, false, SourceReason.UNKNOWN_ERROR), SourceAttempt(StudyMode.PAGE, false, SourceReason.UNKNOWN_ERROR)),
        )
        assertEquals("Could not load videos", e.title)
        assertEquals("", SwitchMessages.detail(e.attempts))
    }

    @Test fun eachFailureHasItsOwnWording() {
        fun msg(vararg a: SourceAttempt) = SwitchMessages.exhausted(a.toList()).message.orEmpty()
        val quota = msg(SourceAttempt(StudyMode.API, true, SourceReason.DAILY_LIMIT), SourceAttempt(StudyMode.PAGE, false, SourceReason.PAGE_UNREADABLE))
        assertTrue(quota.contains("daily limit"))

        val key = msg(SourceAttempt(StudyMode.API, true, SourceReason.INVALID_KEY), SourceAttempt(StudyMode.PAGE, false, SourceReason.PAGE_UNREADABLE))
        assertTrue(key.contains("API key"))
        assertFalse(key.contains("daily limit"))

        val server = msg(SourceAttempt(StudyMode.API, false, SourceReason.SERVER_ERROR), SourceAttempt(StudyMode.PAGE, false, SourceReason.SERVER_ERROR))
        assertTrue(server.contains("temporary problem"))

        val app = msg(SourceAttempt(StudyMode.API, true, SourceReason.NO_KEY), SourceAttempt(StudyMode.PAGE, true, SourceReason.APP_DISABLED), SourceAttempt(StudyMode.WEB, true, SourceReason.WEBVIEW_MISSING))
        assertTrue(app.contains("YouTube app is turned off"))
        assertTrue(app.contains("no web view"))

        val webInit = msg(SourceAttempt(StudyMode.API, false, SourceReason.TIMEOUT), SourceAttempt(StudyMode.PAGE, false, SourceReason.PAGE_UNREADABLE), SourceAttempt(StudyMode.WEB, false, SourceReason.WEBVIEW_INIT_FAILED))
        assertTrue(webInit.contains("web view could not start"))
    }

    @Test fun anApiKeyProblemIsNotReportedAsAMissingApp() {
        val e = SwitchMessages.exhausted(
            listOf(SourceAttempt(StudyMode.API, false, SourceReason.KEY_REFUSED), SourceAttempt(StudyMode.PAGE, false, SourceReason.PAGE_UNREADABLE)),
        )
        val text = e.message.orEmpty().lowercase()
        assertFalse(text.contains("youtube app"))
        assertTrue(text.contains("key"))
    }

    @Test fun phoneOnlineAgainDoesNotShowAnOldDisabledWarning() {
        // A source blocked by the phone's own fact shows its reason only while that fact holds.
        t.applyLocal(StudyMode.WEB, SourceClassifier.webLocal(true, true, true), now)
        assertEquals(SourceReason.NO_INTERNET, t.state(StudyMode.WEB).reason)
        t.applyLocal(StudyMode.WEB, SourceClassifier.webLocal(true, true, false), now + 1_000)
        assertEquals(SourceStatus.UNKNOWN, t.state(StudyMode.WEB).status)
        assertEquals(SourceReason.NONE, t.state(StudyMode.WEB).reason)
        assertEquals(Pick.Use, sw.check(StudyMode.WEB, facts, now + 1_000))
    }
}
