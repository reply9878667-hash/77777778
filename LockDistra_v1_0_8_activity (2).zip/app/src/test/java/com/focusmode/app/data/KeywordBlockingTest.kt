package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class KeywordBlockingTest {

    private fun state(vararg words: String, partial: Boolean = false, on: Boolean = true) =
        KeywordState(enabled = on, rules = words.map { KeywordRule(it, true, partial) })

    private fun hit(s: KeywordState, text: String) = KeywordRules.firstHit(s, text)?.word

    // ---- Matching ----------------------------------------------------------------------------

    @Test fun matchingIsCaseInsensitive() {
        val s = state("instagram")
        assertEquals("instagram", hit(s, "https://www.INSTAGRAM.com/reel/abc"))
        assertEquals("instagram", hit(s, "Instagram Login"))
    }

    @Test fun keywordIsFoundInUrlsSearchesAndTitles() {
        val s = state("gambling")
        assertNotNull(hit(s, "https://example.com/best-gambling-sites"))
        assertNotNull(hit(s, "google.com/search?q=online+gambling"))
        assertNotNull(hit(s, "google.com/search?q=online%20Gambling%20tips"))
        assertNotNull(hit(s, "Top Gambling Apps - News"))
    }

    @Test fun wholeWordsOnlyByDefaultSoThereIsNoFalseBlocking() {
        val s = state("sex", "ad", "mature")
        assertNull(hit(s, "https://www.essex.gov.uk/county"))
        assertNull(hit(s, "Sussex County Cricket"))
        assertNull(hit(s, "download.example.com/app"))
        assertNull(hit(s, "immature fruit"))
        assertEquals("sex", hit(s, "sex education class"))
    }

    @Test fun partialMatchingIsOptIn() {
        assertNull(hit(state("porn"), "https://pornhub.com"))
        assertEquals("porn", hit(state("porn", partial = true), "https://pornhub.com"))
    }

    @Test fun partialIsIgnoredForVeryShortKeywords() {
        val c = KeywordEdits.add(emptyList(), "ab", partial = true, canTighten = true)
        assertEquals(KeywordRules.Result.OK, c.result)
        assertFalse(c.rules.single().partial)
    }

    @Test fun phrasesNeedTheirWordsNextToEachOther() {
        val s = state("adult content")
        assertNotNull(hit(s, "https://x.com/adult-content"))
        assertNotNull(hit(s, "search?q=Adult%20Content"))
        assertNull(hit(s, "adult and content"))
        assertNull(hit(s, "content for adult"))
    }

    @Test fun domainLabelsAreWords() {
        val s = state("facebook")
        assertNotNull(hit(s, "m.facebook.com/home"))
        assertNotNull(hit(s, "https://my-facebook-fans.net"))
        assertNull(hit(s, "facebookfans.net"))
    }

    @Test fun otherLanguagesStayInOnePiece() {
        assertEquals(listOf("जुआ", "खेल"), KeywordRules.words("जुआ खेल"))
        assertNotNull(hit(state("जुआ"), "Online जुआ sites"))
    }

    @Test fun offKeywordsAndOffSwitchNeverMatch() {
        val rules = listOf(KeywordRule("gambling", enabled = false), KeywordRule("casino"))
        assertNull(hit(KeywordState(enabled = true, rules = rules), "gambling"))
        assertEquals("casino", hit(KeywordState(enabled = true, rules = rules), "casino"))
        assertNull(hit(KeywordState(enabled = false, rules = rules), "casino"))
        assertFalse(KeywordState(enabled = true, rules = listOf(KeywordRule("a1", enabled = false))).isActive)
    }

    @Test fun blankTextAndBrokenEscapesAreSafe() {
        val s = state("casino")
        assertNull(hit(s, ""))
        assertNull(hit(s, "   "))
        assertNotNull(hit(s, "50%zz casino"))
    }

    // ---- Cleaning and adding -----------------------------------------------------------------

    @Test fun cleanTidiesAndRejects() {
        assertEquals("adult content", KeywordRules.clean("  Adult   CONTENT "))
        assertNull(KeywordRules.clean("a"))
        assertNull(KeywordRules.clean("   "))
        assertNull(KeywordRules.clean("!!!"))
        assertNull(KeywordRules.clean("x".repeat(KeywordRules.MAX_LENGTH + 1)))
    }

    @Test fun duplicatesAreRefusedIgnoringCaseAndPunctuation() {
        val one = KeywordEdits.add(emptyList(), "Instagram", false, true).rules
        for (again in listOf("instagram", "INSTAGRAM", "instagram!", " Instagram ")) {
            assertEquals(KeywordRules.Result.ALREADY_THERE, KeywordEdits.add(one, again, false, true).result)
        }
    }

    @Test fun addSeveralKeepsGoodOnesAndReportsTheRest() {
        val bulk = KeywordEdits.addMany(emptyList(), "Instagram, facebook\nGambling, adult content, instagram, x", false, true)
        assertEquals(listOf("Instagram", "facebook", "Gambling", "adult content"), bulk.added)
        assertEquals(listOf("instagram"), bulk.duplicates)
        assertEquals(listOf("x"), bulk.invalid)
        assertFalse(bulk.allDone)
        assertEquals(listOf("instagram", "facebook", "gambling", "adult content"), bulk.rules.map { it.word })
    }

    @Test fun addingIsLockedWhenTighteningIsNotAllowed() {
        val bulk = KeywordEdits.addMany(emptyList(), "a1, b2", false, canTighten = false)
        assertTrue(bulk.locked)
        assertTrue(bulk.rules.isEmpty())
        assertEquals(KeywordRules.Result.LOCKED, KeywordEdits.add(emptyList(), "casino", false, false).result)
    }

    @Test fun listHasAMaximum() {
        var l = emptyList<KeywordRule>()
        for (i in 0 until KeywordRules.MAX) l = KeywordEdits.add(l, "word$i", false, true).rules
        assertEquals(KeywordRules.MAX, l.size)
        assertEquals(KeywordRules.Result.FULL, KeywordEdits.add(l, "another", false, true).result)
    }

    // ---- Edit, switch, remove ----------------------------------------------------------------

    @Test fun editKeepsOnOffStateAndRefusesDuplicates() {
        var l = KeywordEdits.add(emptyList(), "casino", false, true).rules
        l = KeywordEdits.add(l, "poker", false, true).rules
        l = KeywordEdits.setEnabled(l, "poker", false, true, true)!!
        val c = KeywordEdits.edit(l, "poker", "Poker Room", true, true)
        assertEquals(KeywordRules.Result.OK, c.result)
        val edited = c.rules.last()
        assertEquals("poker room", edited.word)
        assertFalse(edited.enabled)
        assertTrue(edited.partial)
        assertEquals(KeywordRules.Result.ALREADY_THERE, KeywordEdits.edit(l, "poker", "CASINO", false, true).result)
        assertEquals(KeywordRules.Result.INVALID, KeywordEdits.edit(l, "poker", "!", false, true).result)
        assertEquals(KeywordRules.Result.LOCKED, KeywordEdits.edit(l, "poker", "bingo", false, canLoosen = false).result)
        // Saving the same word again (only the option changed) is not a duplicate of itself.
        assertEquals(KeywordRules.Result.OK, KeywordEdits.edit(l, "casino", "casino", true, true).result)
    }

    @Test fun removeAndSwitchFollowTheSessionLocks() {
        val l = KeywordEdits.add(emptyList(), "casino", false, true).rules
        assertNull(KeywordEdits.remove(l, "casino", canLoosen = false))
        assertTrue(KeywordEdits.remove(l, "casino", canLoosen = true)!!.isEmpty())
        assertNull(KeywordEdits.setEnabled(l, "casino", false, canTighten = true, canLoosen = false))
        assertNull(KeywordEdits.setEnabled(l, "unknown", false, true, true))
        val off = KeywordEdits.setEnabled(l, "casino", false, true, true)!!
        assertNull(KeywordEdits.setEnabled(off, "casino", true, canTighten = false, canLoosen = true))
        assertTrue(KeywordEdits.setEnabled(off, "casino", true, true, false)!!.single().enabled)
    }

    // ---- Saving ------------------------------------------------------------------------------

    @Test fun savedListRoundTrips() {
        val l = listOf(KeywordRule("casino", true, false), KeywordRule("adult content", false, true), KeywordRule("जुआ"))
        assertEquals(l, KeywordRules.decode(KeywordRules.encode(l)))
        assertTrue(KeywordRules.decode(null).isEmpty())
        assertTrue(KeywordRules.decode("").isEmpty())
    }
}
