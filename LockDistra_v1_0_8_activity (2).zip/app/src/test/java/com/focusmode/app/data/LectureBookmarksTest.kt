package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class LectureBookmarksTest {

    private val now = 1_000_000_000_000L

    @Test fun time_isFormatted() {
        assertEquals("0:05", BookmarkRules.time(5))
        assertEquals("12:34", BookmarkRules.time(754))
        assertEquals("1:02:03", BookmarkRules.time(3723))
        assertEquals("0:00", BookmarkRules.time(-4))
    }

    @Test fun emptyTitle_becomesTheTime() {
        assertEquals("Bookmark at 1:05", BookmarkRules.cleanTitle("   ", 65))
        assertEquals("Biodiversity hotspots", BookmarkRules.cleanTitle("  Biodiversity   hotspots ", 65))
        assertEquals(BookmarkRules.MAX_TITLE, BookmarkRules.cleanTitle("x".repeat(500), 1).length)
    }

    @Test fun list_isSortedByTime_andSameSecondReplaces() {
        var l = emptyList<Bookmark>()
        l = BookmarkRules.add(l, 300, "B", 1)
        l = BookmarkRules.add(l, 60, "A", 2)
        l = BookmarkRules.add(l, 300, "B2", 3)
        val v = BookmarkRules.visible(l)
        assertEquals(listOf(60, 300), v.map { it.seconds })
        assertEquals("B2", v[1].title)
    }

    @Test fun remove_hidesIt_butKeepsAMarkForTheSync() {
        var l = BookmarkRules.add(emptyList(), 10, "a", 1)
        l = BookmarkRules.add(l, 20, "b", 2)
        l = BookmarkRules.remove(l, 1, now)
        assertEquals(listOf(2L), BookmarkRules.visible(l).map { it.id })
        assertTrue(l.any { it.id == 1L && it.deleted })
    }

    @Test fun json_roundTrips_andBadJsonIsEmpty() {
        val l = BookmarkRules.add(BookmarkRules.add(emptyList(), 90, "Intro \"quote\"", 5), 10, "Start", 6)
        assertEquals(l.toSet(), BookmarkRules.fromJson(BookmarkRules.toJson(l)).toSet())
        assertTrue(BookmarkRules.fromJson("not json").isEmpty())
        assertTrue(BookmarkRules.fromJson(null).isEmpty())
    }

    @Test fun oldJsonWithoutTheNewFields_stillLoads() {
        val l = BookmarkRules.fromJson("""[{"id":7,"s":42,"t":"Old"}]""")
        assertEquals(Bookmark(7, 42, "Old", at = 7, deleted = false), l.single())
    }

    @Test fun liveListIsCapped() {
        var l = emptyList<Bookmark>()
        for (i in 0 until BookmarkRules.MAX_PER_VIDEO + 10) l = BookmarkRules.add(l, i, "t", i.toLong() + 1)
        assertEquals(BookmarkRules.MAX_PER_VIDEO, BookmarkRules.visible(l).size)
    }

    // ---- sync ----

    @Test fun merge_bringsTogetherBookmarksMadeOnTwoPhones() {
        val phone = BookmarkRules.add(emptyList(), 60, "A", 100)
        val server = BookmarkRules.add(emptyList(), 300, "B", 200)
        val m = BookmarkRules.merge(phone, server, now)
        assertEquals(listOf(60, 300), BookmarkRules.visible(m).map { it.seconds })
    }

    @Test fun merge_aDeleteOnOnePhoneReachesTheOther() {
        val both = BookmarkRules.add(emptyList(), 60, "A", 100)
        val deletedOnPhone = BookmarkRules.remove(both, 100, 500)
        val m = BookmarkRules.merge(deletedOnPhone, both, now)
        assertTrue(BookmarkRules.visible(m).isEmpty())
        // ... and the other way round: the server holds the delete, the phone still has it
        val m2 = BookmarkRules.merge(both, deletedOnPhone, now)
        assertTrue(BookmarkRules.visible(m2).isEmpty())
    }

    @Test fun merge_theNewerEditWins() {
        val old = listOf(Bookmark(1, 60, "old", at = 100))
        val edited = listOf(Bookmark(1, 60, "new", at = 900))
        assertEquals("new", BookmarkRules.visible(BookmarkRules.merge(old, edited, now)).single().title)
        assertEquals("new", BookmarkRules.visible(BookmarkRules.merge(edited, old, now)).single().title)
    }

    @Test fun merge_twoPhonesAtTheSameSecond_keepOne() {
        val a = listOf(Bookmark(1, 60, "from A", at = 100))
        val b = listOf(Bookmark(2, 60, "from B", at = 200))
        val v = BookmarkRules.visible(BookmarkRules.merge(a, b, now))
        assertEquals(1, v.size)
        assertEquals("from B", v.single().title)
    }

    @Test fun merge_forgetsOldDeleteMarks() {
        val old = listOf(Bookmark(1, 60, "x", at = now - BookmarkRules.TOMBSTONE_MS - 1, deleted = true))
        assertTrue(BookmarkRules.merge(old, emptyList(), now).isEmpty())
        val fresh = listOf(Bookmark(1, 60, "x", at = now - 1000, deleted = true))
        assertEquals(1, BookmarkRules.merge(fresh, emptyList(), now).size)
    }

    @Test fun onlyRealYoutubeIdsGoToTheServer() {
        assertTrue(BookmarkRules.syncable("dQw4w9WgXcQ"))
        assertFalse(BookmarkRules.syncable("https://example.com/video"))
        assertFalse(BookmarkRules.syncable("../users"))
    }
}
