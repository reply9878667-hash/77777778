package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdultCustomTest {

    @Test fun linkBecomesSite() {
        val e = AdultCustom.parse("https://xvideos.com/abc")!!
        assertEquals(CustomKind.DOMAIN, e.kind)
        assertEquals("xvideos.com", e.value)
    }

    @Test fun plainWordAndPhraseBecomeWords() {
        assertEquals(CustomEntry(CustomKind.KEYWORD, "pornhub"), AdultCustom.parse("pornhub"))
        assertEquals("sex video", AdultCustom.parse("Sex   Video")!!.value)
    }

    @Test fun tooShortOrBlankIsRejected() {
        assertNull(AdultCustom.parse("ab"))
        assertNull(AdultCustom.parse("   "))
    }

    @Test fun searchLinkOfBigSiteIsNotBlockedByAccident() {
        val raw = "https://google.com/search?q=x"
        assertTrue(AdultCustom.isAccidentalBigSite(raw, AdultCustom.parse(raw)!!))
        assertFalse(AdultCustom.isAccidentalBigSite("google.com", AdultCustom.parse("google.com")!!))
    }

    @Test fun wordsAreFoundInAddressBarText() {
        assertEquals("pornhub", AdultCustom.keywordHit("https://www.PornHub.com/view", listOf("pornhub")))
        assertEquals("sex video", AdultCustom.keywordHit("google.com/search?q=sex+video", listOf("sex video")))
        assertEquals("sex video", AdultCustom.keywordHit("google.com/search?q=sex%20video", listOf("sex video")))
        assertNull(AdultCustom.keywordHit("wikipedia.org", listOf("pornhub")))
    }

    @Test fun sitesMatchSubdomainsAtDotBoundaryOnly() {
        assertTrue(AdultCustom.domainHit("m.xvideos.com", listOf("xvideos.com")))
        assertFalse(AdultCustom.domainHit("notxvideos.com", listOf("xvideos.com")))
    }

    @Test fun savedListRoundTrips() {
        val l = listOf(CustomEntry(CustomKind.DOMAIN, "a.com"), CustomEntry(CustomKind.KEYWORD, "foo bar"))
        assertEquals(l, AdultCustom.decode(AdultCustom.encode(l)))
    }

    @Test fun websiteNamesBecomeSites() {
        assertEquals("youtube.com", WebsiteRules.fromTyped("youtube"))
        assertEquals("telegram.org", WebsiteRules.fromTyped("telegram"))
        assertEquals("example.com", WebsiteRules.fromTyped("https://www.Example.com/x"))
        assertNull(WebsiteRules.fromTyped("not a site"))
    }
}
