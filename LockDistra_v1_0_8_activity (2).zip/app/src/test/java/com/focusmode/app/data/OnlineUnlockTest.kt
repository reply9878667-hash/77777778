package com.focusmode.app.data

import com.focusmode.app.data.online.*
import org.junit.Assert.*
import org.junit.Test

class OnlineUnlockTest {

    private val code = "ABCDE-FGHJK-LMNPQ-RSTUV"
    private val key = ApprovalProtocol.pairKey(code)
    private fun expected(key: ByteArray = this.key) =
        ExpectedRequest("ownerA", "req1", "n0nce", "dev1", "approverB", key)

    private fun snap(
        status: String, created: Long = 1_000, decidedAt: Long? = null, by: String? = null,
        decision: Decision? = null, proofKey: ByteArray = key,
    ) = RequestSnapshot(
        status, created, decidedAt, by,
        decision?.let { ApprovalProtocol.decisionProof(proofKey, "ownerA", "req1", "n0nce", "dev1", it) },
        "n0nce", "dev1",
    )

    // ---- the three modes ----
    @Test fun passwordMode_isTheOldBehaviour() {
        assertTrue(UnlockGateRules.gateActive(UnlockMode.PASSWORD, true))
        assertFalse(UnlockGateRules.gateActive(UnlockMode.PASSWORD, false))
        val m = UnlockGateRules.methods(UnlockMode.PASSWORD, true)
        assertTrue(m.password); assertFalse(m.online)
    }
    @Test fun onlineMode_failsClosed_evenWithoutPassword() {
        assertTrue(UnlockGateRules.gateActive(UnlockMode.ONLINE, false))
        val m = UnlockGateRules.methods(UnlockMode.ONLINE, true)
        assertFalse(m.password); assertTrue(m.online)
    }
    @Test fun bothMode_offersEither() {
        val m = UnlockGateRules.methods(UnlockMode.BOTH, true)
        assertTrue(m.both)
        assertFalse(UnlockGateRules.methods(UnlockMode.BOTH, false).password)
    }
    @Test fun selectingModes_needsWhatItUses() {
        assertNull(UnlockGateRules.canSelect(UnlockMode.PASSWORD, false, false, false))
        assertNotNull(UnlockGateRules.canSelect(UnlockMode.ONLINE, false, false, false))
        assertNotNull(UnlockGateRules.canSelect(UnlockMode.ONLINE, false, true, false))
        assertNull(UnlockGateRules.canSelect(UnlockMode.ONLINE, false, true, true))
        assertNotNull(UnlockGateRules.canSelect(UnlockMode.BOTH, false, true, true))
        assertNull(UnlockGateRules.canSelect(UnlockMode.BOTH, true, true, true))
    }
    @Test fun modeFollowsPasswordLockAndUnlink() {
        assertEquals(UnlockMode.ONLINE, UnlockGateRules.modeAfterPasswordLockOff(UnlockMode.BOTH))
        assertEquals(UnlockMode.PASSWORD, UnlockGateRules.modeAfterPasswordLockOff(UnlockMode.PASSWORD))
        assertEquals(UnlockMode.PASSWORD, UnlockGateRules.modeAfterUnlink(UnlockMode.BOTH))
        assertEquals(UnlockMode.PASSWORD, UnlockMode.fromId("garbage"))
    }

    // ---- pairing ----
    @Test fun pairCode_shapeAndDerivation() {
        val c = ApprovalProtocol.newPairCode()
        assertTrue(ApprovalProtocol.isPairCodeShapeValid(c))
        assertEquals(ApprovalProtocol.inviteId(c), ApprovalProtocol.inviteId(c.lowercase().replace("-", " ")))
        assertNotEquals(ApprovalProtocol.inviteId(c), ApprovalProtocol.inviteId(ApprovalProtocol.newPairCode()))
        assertFalse(ApprovalProtocol.hex(ApprovalProtocol.pairKey(c)).contains(ApprovalProtocol.inviteId(c)))
        assertFalse(ApprovalProtocol.isPairCodeShapeValid("ABC"))
    }

    // ---- request lifecycle ----
    @Test fun pending_thenExpires() {
        assertEquals(RequestOutcome.Pending, ApprovalProtocol.evaluate(snap("pending"), expected(), 1_500, false))
        assertEquals(RequestOutcome.Expired,
            ApprovalProtocol.evaluate(snap("pending"), expected(), 1_000 + ApprovalProtocol.REQUEST_TTL_MS + 1, false))
    }
    @Test fun approvedByTrustedPhone_unlocks() {
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED)
        assertEquals(RequestOutcome.Approved, ApprovalProtocol.evaluate(s, expected(), 6_000, false))
    }
    @Test fun rejected_staysLocked() {
        val s = snap("rejected", decidedAt = 5_000, by = "approverB", decision = Decision.REJECTED)
        assertEquals(RequestOutcome.Rejected, ApprovalProtocol.evaluate(s, expected(), 6_000, false))
    }
    @Test fun approvalFromAnotherDevice_isRefused() {
        val s = snap("approved", decidedAt = 5_000, by = "attacker", decision = Decision.APPROVED)
        assertTrue(ApprovalProtocol.evaluate(s, expected(), 6_000, false) is RequestOutcome.Invalid)
    }
    @Test fun forgedProof_isRefused() {
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED,
            proofKey = ApprovalProtocol.pairKey("ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ"))
        assertTrue(ApprovalProtocol.evaluate(s, expected(), 6_000, false) is RequestOutcome.Invalid)
    }
    @Test fun rejectionProof_cannotBeReusedAsApproval() {
        val rej = snap("rejected", decidedAt = 5_000, by = "approverB", decision = Decision.REJECTED)
        val asApproved = rej.copy(status = "approved")
        assertTrue(ApprovalProtocol.evaluate(asApproved, expected(), 6_000, false) is RequestOutcome.Invalid)
    }
    @Test fun proofForAnotherRequest_isRefused() {
        val other = ApprovalProtocol.decisionProof(key, "ownerA", "req-OTHER", "n0nce", "dev1", Decision.APPROVED)
        val s = snap("approved", decidedAt = 5_000, by = "approverB").copy(proof = other)
        assertTrue(ApprovalProtocol.evaluate(s, expected(), 6_000, false) is RequestOutcome.Invalid)
    }
    @Test fun lateApproval_isExpired() {
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED)
        assertEquals(RequestOutcome.Expired,
            ApprovalProtocol.evaluate(s, expected(), 5_000 + ApprovalProtocol.CONSUME_WINDOW_MS + 1, false))
        val afterTtl = snap("approved", decidedAt = 1_000 + ApprovalProtocol.REQUEST_TTL_MS + 10, by = "approverB", decision = Decision.APPROVED)
        assertEquals(RequestOutcome.Expired, ApprovalProtocol.evaluate(afterTtl, expected(), 125_000, false))
    }
    @Test fun usedOrClosedRequest_neverUnlocksAgain() {
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED)
        assertTrue(ApprovalProtocol.evaluate(s, expected(), 6_000, alreadyUsed = true) is RequestOutcome.Invalid)
        assertTrue(ApprovalProtocol.evaluate(s.copy(status = "consumed"), expected(), 6_000, false) is RequestOutcome.Invalid)
    }
    @Test fun changedNonceOrDevice_isRefused() {
        assertTrue(ApprovalProtocol.evaluate(snap("pending").copy(nonce = "x"), expected(), 1_500, false) is RequestOutcome.Invalid)
        assertTrue(ApprovalProtocol.evaluate(snap("pending").copy(deviceId = "x"), expected(), 1_500, false) is RequestOutcome.Invalid)
    }

    // ---- trusted phone side ----
    @Test fun approver_onlyAnswersVerifiedFreshRequests() {
        val mac = ApprovalProtocol.requestMac(key, "ownerA", "req1", "n0nce", "dev1")
        val s = snap("pending")
        assertTrue(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", mac, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", "bad", key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", null, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req2", mac, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", mac, key, 1_000 + ApprovalProtocol.REQUEST_TTL_MS + 1))
        assertFalse(ApprovalProtocol.approverMayAnswer(s.copy(status = "approved"), "ownerA", "req1", mac, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s.copy(nonce = "a|b"), "ownerA", "req1", mac, key, 2_000))
    }
}
