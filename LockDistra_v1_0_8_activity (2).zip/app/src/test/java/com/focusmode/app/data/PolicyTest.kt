package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PolicyTest {

    private val now = 1_000_000L

    private fun running(
        sessionEnd: Long = now + 60 * 60_000L,
        allowTurnOff: Boolean = true,
        allowSettings: Boolean = true,
        allowEmergency: Boolean = true,
        allowApps: Boolean = true,
        allowBypass: Boolean = false,
    ) = FocusState(
        focusActive = true,
        sessionStart = now - 1_000L,
        sessionEnd = sessionEnd,
        allowTurnOff = allowTurnOff,
        allowSettingsChange = allowSettings,
        allowEmergency = allowEmergency,
        allowAppChanges = allowApps,
        allowOtherBypass = allowBypass,
    )

    // ---- Focus controls ---------------------------------------------------------------------

    @Test
    fun controlsAreFreeBetweenSessions() {
        val idle = FocusState(focusActive = false, allowTurnOff = false)
        FocusControl.values().forEach { control ->
            assertTrue(FocusPolicy.canSetControl(idle, control, true))
            assertTrue(FocusPolicy.canSetControl(idle, control, false))
        }
    }

    @Test
    fun duringASessionAControlCanBeTightenedButNotLoosened() {
        val s = running()
        assertTrue(FocusPolicy.canSetControl(s, FocusControl.EMERGENCY, false))
        val tightened = s.copy(allowEmergency = false)
        assertFalse(FocusPolicy.canSetControl(tightened, FocusControl.EMERGENCY, true))
        // Asking for the value it already has is harmless.
        assertTrue(FocusPolicy.canSetControl(tightened, FocusControl.EMERGENCY, false))
    }

    @Test
    fun theBypassSwitchStartsGuardedAndCannotBeOpenedMidSession() {
        val s = running(allowBypass = false)
        assertTrue(s.sessionGuardOn)
        assertFalse(FocusPolicy.canSetControl(s, FocusControl.OTHER_BYPASS, true))
    }

    @Test
    fun noControlChangesOnceSettingsAreLocked() {
        val s = running(allowSettings = false)
        FocusControl.values().forEach { control ->
            val value = FocusPolicy.isAllowed(s, control)
            assertFalse(FocusPolicy.canSetControl(s, control, !value))
        }
    }

    @Test
    fun aSessionWithNoEndTimeCanNeverBeLockedAgainstTurningOff() {
        val open = running(sessionEnd = 0L)
        assertFalse(FocusPolicy.canSetControl(open, FocusControl.TURN_OFF, false))
        val timed = running()
        assertTrue(FocusPolicy.canSetControl(timed, FocusControl.TURN_OFF, false))
    }

    @Test
    fun policyHelpersFollowTheControls() {
        assertTrue(running().canTurnOff)
        assertFalse(running(allowTurnOff = false).canTurnOff)
        assertFalse(running(allowSettings = false).canChangeSettings)
        assertFalse(running(allowEmergency = false).canUseEmergency)
        assertFalse(running(allowApps = false).canEditApps)
        // Between sessions nothing is locked, whatever the saved defaults say.
        val idle = FocusState(focusActive = false, allowTurnOff = false, allowAppChanges = false)
        assertTrue(idle.canTurnOff)
        assertTrue(idle.canEditApps)
        assertFalse(idle.canUseEmergency)
        assertFalse(idle.sessionGuardOn)
    }

    // ---- Emergency window -------------------------------------------------------------------

    @Test
    fun anEmergencyWindowOnlyOpensItsOwnApp() {
        val s = running().copy(emergencyUntil = now + 120_000L, emergencyPkg = "com.example.chat")
        assertTrue(s.emergencyCovers("com.example.chat", now))
        assertFalse(s.emergencyCovers("com.example.video", now))
        // After it ends nothing is covered.
        assertFalse(s.emergencyCovers("com.example.chat", now + 120_001L))
    }

    @Test
    fun aLegacyWindowWithoutAPackageStillOpensEverything() {
        val s = running().copy(emergencyUntil = now + 60_000L, emergencyPkg = "")
        assertTrue(s.emergencyCovers("any.package", now))
    }

    @Test
    fun emergencyCannotStartWhenOffOrAlreadyRunning() {
        assertTrue(EmergencyPolicy.sessionAllows(running(), now))
        assertFalse(EmergencyPolicy.sessionAllows(running(allowEmergency = false), now))
        val open = running().copy(emergencyUntil = now + 30_000L, emergencyPkg = "a")
        assertFalse(EmergencyPolicy.sessionAllows(open, now))
        assertFalse(EmergencyPolicy.sessionAllows(FocusState(focusActive = false), now))
    }

    // ---- Emergency attempts -----------------------------------------------------------------

    @Test
    fun anAppWithLimitThreeOpensExactlyThreeTimes() {
        var app: EmergencyApp? = EmergencyApp("com.example.chat", enabled = true, limit = 3, used = 0)
        var opened = 0
        repeat(5) {
            val next = EmergencyPolicy.consume(app)
            if (next != null) {
                opened++
                app = next
            }
        }
        assertEquals(3, opened)
        assertEquals(0, app!!.remaining)
        assertFalse(app!!.available)
        assertNull(EmergencyPolicy.consume(app))
    }

    @Test
    fun remainingAttemptsCountDown() {
        val app = EmergencyApp("p", enabled = true, limit = 3, used = 1)
        assertEquals(2, app.remaining)
        assertEquals(0, app.copy(used = 7).remaining) // never negative
    }

    @Test
    fun aSwitchedOffOrUnknownAppCannotBeOpened() {
        assertNull(EmergencyPolicy.consume(null))
        val off = EmergencyApp("p", enabled = false, limit = 3, used = 0)
        assertEquals(0, off.remaining)
        assertNull(EmergencyPolicy.consume(off))
    }

    // ---- Emergency settings -----------------------------------------------------------------

    @Test
    fun emergencyAppsAreFreelyEditableBetweenSessions() {
        val idle = FocusState(focusActive = false)
        assertTrue(EmergencyPolicy.canSetEnabled(idle, true))
        assertTrue(EmergencyPolicy.canSetLimit(idle, currentLimit = 3, newLimit = 9))
    }

    @Test
    fun duringASessionEmergencyAppsCanOnlyBeTightened() {
        val s = running()
        assertFalse(EmergencyPolicy.canSetEnabled(s, true))   // no new apps
        assertTrue(EmergencyPolicy.canSetEnabled(s, false))   // switching one off is fine
        assertFalse(EmergencyPolicy.canSetLimit(s, 3, 4))     // no higher limit
        assertTrue(EmergencyPolicy.canSetLimit(s, 3, 2))      // lower is fine
        assertTrue(EmergencyPolicy.canSetLimit(s, 3, 3))
    }

    @Test
    fun lockedAppChangesFreezeEmergencySettingsCompletely() {
        val noApps = running(allowApps = false)
        assertFalse(EmergencyPolicy.canSetEnabled(noApps, false))
        assertFalse(EmergencyPolicy.canSetLimit(noApps, 3, 1))
        val noSettings = running(allowSettings = false)
        assertFalse(EmergencyPolicy.canSetEnabled(noSettings, false))
        assertFalse(EmergencyPolicy.canSetLimit(noSettings, 3, 1))
    }
}
