package com.focusmode.app.data

import com.focusmode.app.data.online.*
import org.junit.Assert.*
import org.junit.Test

/** "Request to unlock" on an app's block screen: the protocol, the minutes rules and the grant clock. */
class AppUnlockTest {

    private val code = "ABCDE-FGHJK-LMNPQ-RSTUV"
    private val key = ApprovalProtocol.pairKey(code)
    private val pkg = "com.instagram.android"
    private val name = "Instagram"
    private val reason = AppUnlockRules.REASON_LIMIT

    private fun expected(key: ByteArray = this.key) =
        ExpectedRequest("ownerA", "req1", "n0nce", "dev1", "approverB", key, pkg, reason)

    /** An app request as read from the database. [minutes] is what the proof was made for. */
    private fun snap(
        status: String, created: Long = 1_000, decidedAt: Long? = null, by: String? = null,
        decision: Decision? = null, minutes: Int = 0, proofKey: ByteArray = key,
    ) = RequestSnapshot(
        status, created, decidedAt, by,
        decision?.let {
            ApprovalProtocol.appDecisionProof(proofKey, "ownerA", "req1", "n0nce", "dev1", pkg, reason, it, minutes)
        },
        "n0nce", "dev1", ApprovalProtocol.KIND_APP, pkg, name, reason, minutes.toLong(),
    )

    // ---- answers ----
    @Test fun approvedWithMinutes_grantsThoseMinutes() {
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 15)
        assertEquals(RequestOutcome.GrantedFor(15), ApprovalProtocol.evaluate(s, expected(), 6_000, false))
    }

    @Test fun rejected_staysClosed() {
        val s = snap("rejected", decidedAt = 5_000, by = "approverB", decision = Decision.REJECTED, minutes = 0)
        assertEquals(RequestOutcome.Rejected, ApprovalProtocol.evaluate(s, expected(), 6_000, false))
    }

    @Test fun minutesChangedAfterTheAnswer_areRefused() {
        val real = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 5)
        val stretched = real.copy(minutes = 240)
        assertTrue(ApprovalProtocol.evaluate(stretched, expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    @Test fun timeOutsideTheAllowedRange_isRefused() {
        val zero = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 0)
        assertTrue(ApprovalProtocol.evaluate(zero, expected(), 6_000, false) is RequestOutcome.Invalid)
        val tooLong = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED,
            minutes = ApprovalProtocol.MAX_GRANT_MIN + 1)
        assertTrue(ApprovalProtocol.evaluate(tooLong, expected(), 6_000, false) is RequestOutcome.Invalid)
        val noTime = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 10)
            .copy(minutes = null)
        assertTrue(ApprovalProtocol.evaluate(noTime, expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    @Test fun answerFromAnotherPhoneOrKey_isRefused() {
        val other = snap("approved", decidedAt = 5_000, by = "attacker", decision = Decision.APPROVED, minutes = 15)
        assertTrue(ApprovalProtocol.evaluate(other, expected(), 6_000, false) is RequestOutcome.Invalid)
        val forged = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 15,
            proofKey = ApprovalProtocol.pairKey("ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ"))
        assertTrue(ApprovalProtocol.evaluate(forged, expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    @Test fun rejectionCannotBeTurnedIntoApproval() {
        val rej = snap("rejected", decidedAt = 5_000, by = "approverB", decision = Decision.REJECTED, minutes = 0)
        val asApproved = rej.copy(status = "approved", minutes = 30)
        assertTrue(ApprovalProtocol.evaluate(asApproved, expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    @Test fun otherAppOrReason_isRefused() {
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 15)
        assertTrue(ApprovalProtocol.evaluate(s.copy(pkg = "com.google.android.youtube"), expected(), 6_000, false) is RequestOutcome.Invalid)
        assertTrue(ApprovalProtocol.evaluate(s.copy(reason = AppUnlockRules.REASON_APP), expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    @Test fun lateOrUsedAnswer_neverGrants() {
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 15)
        assertEquals(RequestOutcome.Expired,
            ApprovalProtocol.evaluate(s, expected(), 5_000 + ApprovalProtocol.CONSUME_WINDOW_MS + 1, false))
        assertTrue(ApprovalProtocol.evaluate(s, expected(), 6_000, alreadyUsed = true) is RequestOutcome.Invalid)
        assertTrue(ApprovalProtocol.evaluate(s.copy(status = "consumed"), expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    // ---- an app request and a lock-screen request never stand in for each other ----
    @Test fun plainApprovalCannotGrantAnApp() {
        val plainProof = ApprovalProtocol.decisionProof(key, "ownerA", "req1", "n0nce", "dev1", Decision.APPROVED)
        val s = snap("approved", decidedAt = 5_000, by = "approverB", minutes = 15).copy(proof = plainProof)
        assertTrue(ApprovalProtocol.evaluate(s, expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    @Test fun appApprovalCannotOpenTheFocusModeLock() {
        // The lock screen's own request has no app in it.
        val lockExpected = ExpectedRequest("ownerA", "req1", "n0nce", "dev1", "approverB", key)
        val s = snap("approved", decidedAt = 5_000, by = "approverB", decision = Decision.APPROVED, minutes = 15)
        assertTrue(ApprovalProtocol.evaluate(s, lockExpected, 6_000, false) is RequestOutcome.Invalid)
    }

    @Test fun plainAnswerToAnAppRequest_isRefused() {
        val plain = RequestSnapshot(
            "approved", 1_000, 5_000, "approverB",
            ApprovalProtocol.decisionProof(key, "ownerA", "req1", "n0nce", "dev1", Decision.APPROVED),
            "n0nce", "dev1",
        )
        assertTrue(ApprovalProtocol.evaluate(plain, expected(), 6_000, false) is RequestOutcome.Invalid)
    }

    // ---- trusted phone side ----
    @Test fun approver_onlyShowsVerifiedAppRequests() {
        val mac = ApprovalProtocol.appRequestMac(key, "ownerA", "req1", "n0nce", "dev1", pkg, name, reason)
        val s = snap("pending")
        assertTrue(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", mac, key, 2_000))
        // another app name or app or reason: not what the locked phone signed
        assertFalse(ApprovalProtocol.approverMayAnswer(s.copy(appName = "Calculator"), "ownerA", "req1", mac, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s.copy(pkg = "com.android.calculator2"), "ownerA", "req1", mac, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s.copy(reason = AppUnlockRules.REASON_APP), "ownerA", "req1", mac, key, 2_000))
        // a plain request's MAC does not make an app request
        val plainMac = ApprovalProtocol.requestMac(key, "ownerA", "req1", "n0nce", "dev1")
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", plainMac, key, 2_000))
        // and an app MAC does not make a plain request
        assertFalse(ApprovalProtocol.approverMayAnswer(s.copy(kind = null), "ownerA", "req1", mac, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s.copy(kind = "other"), "ownerA", "req1", mac, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", null, key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", mac, key, 1_000 + ApprovalProtocol.REQUEST_TTL_MS + 1))
    }

    @Test fun approver_refusesOddValues() {
        val s = snap("pending").copy(pkg = "a|b", appName = "x")
        assertFalse(ApprovalProtocol.approverMayAnswer(s, "ownerA", "req1", "00", key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(snap("pending").copy(pkg = null), "ownerA", "req1", "00", key, 2_000))
        assertFalse(ApprovalProtocol.approverMayAnswer(snap("pending").copy(reason = null), "ownerA", "req1", "00", key, 2_000))
    }

    @Test fun packageNames() {
        assertTrue(ApprovalProtocol.isValidPackageName("com.instagram.android"))
        assertTrue(ApprovalProtocol.isValidPackageName("com.my_app.v2"))
        assertFalse(ApprovalProtocol.isValidPackageName("instagram"))
        assertFalse(ApprovalProtocol.isValidPackageName("com.a|b"))
        assertFalse(ApprovalProtocol.isValidPackageName("com..x"))
        assertFalse(ApprovalProtocol.isValidPackageName(""))
        assertFalse(ApprovalProtocol.isValidPackageName("com." + "a".repeat(250)))
    }

    // ---- minutes and wording ----
    @Test fun typedMinutes() {
        assertEquals(15, AppUnlockRules.parseMinutes("15"))
        assertEquals(30, AppUnlockRules.parseMinutes(" 30 "))
        assertEquals(1, AppUnlockRules.parseMinutes("1"))
        assertEquals(240, AppUnlockRules.parseMinutes("240"))
        assertNull(AppUnlockRules.parseMinutes("0"))
        assertNull(AppUnlockRules.parseMinutes("241"))
        assertNull(AppUnlockRules.parseMinutes("-5"))
        assertNull(AppUnlockRules.parseMinutes("1.5"))
        assertNull(AppUnlockRules.parseMinutes("abc"))
        assertNull(AppUnlockRules.parseMinutes(""))
    }

    @Test fun describeMinutes() {
        assertEquals("15 min", AppUnlockRules.describe(15))
        assertEquals("1 h", AppUnlockRules.describe(60))
        assertEquals("1 h 30 min", AppUnlockRules.describe(90))
    }

    @Test fun onlyTimeUpAndBlockScreensOfferARequest() {
        assertTrue(AppUnlockRules.canRequest(AppUnlockRules.REASON_APP))
        assertTrue(AppUnlockRules.canRequest(AppUnlockRules.REASON_LIMIT))
        assertTrue(AppUnlockRules.canRequest(AppUnlockRules.REASON_CATEGORY))
        // Shorts (1), protection (2), Android Settings (4), in-app section (5)
        for (r in listOf(1, 2, 4, 5, 99)) assertFalse(AppUnlockRules.canRequest(r))
    }

    @Test fun appNameIsCleaned() {
        assertEquals("Instagram", AppUnlockRules.cleanName("Insta|gram", "x"))
        assertEquals("fallback", AppUnlockRules.cleanName("   ", "fallback"))
        assertEquals("ab", AppUnlockRules.cleanName("a\u0000b", "x"))
        assertEquals(AppUnlockRules.MAX_NAME, AppUnlockRules.cleanName("a".repeat(100), "x").length)
    }

    // ---- the granted window ----
    @Test fun grantFollowsTheMonotonicClock() {
        val g = AppGrantRules.newGrant(pkg, 10, wallNow = 1_000_000, elapsedNow = 50_000, bootNow = 7)
        assertEquals(600_000L, g.durationMs)
        assertEquals(500_000L, AppGrantRules.remainingMs(g, 1_100_000, 150_000, 7))
        // phone date moved back (or forward): same boot, so it changes nothing
        assertEquals(500_000L, AppGrantRules.remainingMs(g, 0, 150_000, 7))
        assertEquals(500_000L, AppGrantRules.remainingMs(g, 9_000_000, 150_000, 7))
        assertTrue(AppGrantRules.isActive(g, 1_100_000, 150_000, 7))
        assertFalse(AppGrantRules.isActive(g, 1_700_000, 650_000, 7))
    }

    @Test fun grantAfterRestart_usesWallClock_andNeverMoreThanGranted() {
        val g = AppGrantRules.newGrant(pkg, 10, wallNow = 1_000_000, elapsedNow = 50_000, bootNow = 7)
        assertEquals(300_000L, AppGrantRules.remainingMs(g, 1_300_000, 5_000, 8))
        assertEquals(0L, AppGrantRules.remainingMs(g, 1_700_000, 5_000, 8))
        // clock set far back: capped at the length that was granted
        assertEquals(600_000L, AppGrantRules.remainingMs(g, 0, 5_000, 8))
    }

    @Test fun grantLengthIsKeptInRange() {
        assertEquals(60_000L, AppGrantRules.newGrant(pkg, 0, 0, 0, 0).durationMs)
        assertEquals(240 * 60_000L, AppGrantRules.newGrant(pkg, 9_999, 0, 0, 0).durationMs)
    }

    @Test fun grantSurvivesSaving() {
        val g = AppGrantRules.newGrant(pkg, 25, 123_456_789L, 4_242L, 3)
        assertEquals(g, AppGrantRules.decode(AppGrantRules.encode(g)))
        assertNull(AppGrantRules.decode("garbage"))
        assertNull(AppGrantRules.decode("a|b|c|d|e"))
        assertNull(AppGrantRules.decode("|1|2|3|4"))
    }
}
