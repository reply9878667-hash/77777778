package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class FocusOffMethodTest {

    private fun err(
        m: FocusOffMethod,
        password: Boolean = false,
        phone: Boolean = false,
        recovery: Boolean = false,
        configured: Boolean = true,
    ) = FocusOffRules.setupError(m, password, phone, recovery, configured)

    // ---- the three methods ----
    @Test fun exactlyThreeMethods_normalIsDefault() {
        assertEquals(listOf("Normal Button", "Password", "Online Approval"), FocusOffMethod.entries.map { it.label })
        assertEquals(FocusOffMethod.NORMAL, FocusOffMethod.fromId(null))
        assertEquals(FocusOffMethod.NORMAL, FocusOffMethod.fromId("nonsense"))
        FocusOffMethod.entries.forEach { assertEquals(it, FocusOffMethod.fromId(it.id)) }
    }
    @Test fun focusStateDefault_isNormalButton() {
        assertEquals(FocusOffMethod.NORMAL, FocusState().offMethod)
    }

    // ---- setup checks ----
    @Test fun normal_isAlwaysReady() {
        assertNull(err(FocusOffMethod.NORMAL))
    }
    @Test fun password_needsAppLock() {
        assertNotNull(err(FocusOffMethod.PASSWORD, password = false))
        assertTrue(err(FocusOffMethod.PASSWORD, password = false)!!.contains("App lock"))
        assertNull(err(FocusOffMethod.PASSWORD, password = true))
    }
    @Test fun online_needsPhoneAndRecoveryAndBuildSupport() {
        assertNotNull(err(FocusOffMethod.ONLINE, phone = false, recovery = false))
        assertTrue(err(FocusOffMethod.ONLINE, phone = false)!!.contains("trusted phone"))
        assertNull(err(FocusOffMethod.ONLINE, phone = true, recovery = false))
        assertNotNull(err(FocusOffMethod.ONLINE, phone = true, recovery = true, configured = false))
        assertNull(err(FocusOffMethod.ONLINE, phone = true, recovery = true))
    }
    @Test fun passwordSetup_doesNotMakeOnlineReady_andViceVersa() {
        assertNotNull(err(FocusOffMethod.ONLINE, password = true))
        assertNotNull(err(FocusOffMethod.PASSWORD, phone = true, recovery = true))
    }

    // ---- effective method ----
    @Test fun effective_keepsReadyMethod_fallsBackToButtonWhenSetupLost() {
        assertEquals(FocusOffMethod.PASSWORD, FocusOffRules.effective(FocusOffMethod.PASSWORD, null))
        assertEquals(FocusOffMethod.ONLINE, FocusOffRules.effective(FocusOffMethod.ONLINE, null))
        assertEquals(FocusOffMethod.NORMAL, FocusOffRules.effective(FocusOffMethod.PASSWORD, "no password"))
        assertEquals(FocusOffMethod.NORMAL, FocusOffRules.effective(FocusOffMethod.ONLINE, "no phone"))
    }

    // ---- when the method may be changed ----
    @Test fun method_changesOnlyBetweenSessions_andWhenSettingsAreOpen() {
        assertTrue(FocusOffRules.canChange(focusActive = false, canChangeSettings = true))
        assertFalse(FocusOffRules.canChange(focusActive = true, canChangeSettings = true))
        assertFalse(FocusOffRules.canChange(focusActive = false, canChangeSettings = false))
    }
    @Test fun unlinkBlocked_onlyForOnlineWhileSessionRuns() {
        assertNotNull(FocusOffRules.unlinkBlockedReason(true, FocusOffMethod.ONLINE))
        assertNull(FocusOffRules.unlinkBlockedReason(false, FocusOffMethod.ONLINE))
        assertNull(FocusOffRules.unlinkBlockedReason(true, FocusOffMethod.PASSWORD))
        assertNull(FocusOffRules.unlinkBlockedReason(true, FocusOffMethod.NORMAL))
    }

    // ---- Pomodoro ----
    @Test fun pomodoro_gatedOnlyWhileAFocusRoundRuns() {
        assertTrue(FocusOffRules.gatesPomodoroAction(focusActive = true, pomodoroActive = true))
        assertFalse(FocusOffRules.gatesPomodoroAction(focusActive = false, pomodoroActive = true)) // break / paused
        assertFalse(FocusOffRules.gatesPomodoroAction(focusActive = true, pomodoroActive = false)) // plain session
    }

    // ---- preview ----
    private val names = mapOf(
        "a.chat" to "Chat", "a.video" to "Video", "a.news" to "News", "a.mail" to "Mail", "a.maps" to "Maps",
        "g.race" to "Racing", "g.puzzle" to "Puzzle", "g.war" to "War", "g.farm" to "Farm",
    )
    private fun preview(blocked: Collection<String>, sites: List<String> = emptyList()) =
        StartPreviewRules.build(blocked, { it.startsWith("g.") }, { names[it] }, sites)

    @Test fun preview_showsAtMostFourApps_andPlusMore() {
        val p = preview(listOf("a.chat", "a.video", "a.news", "a.mail", "a.maps"))
        assertEquals(4, p.apps.size)
        assertEquals(5, p.appTotal)
        assertEquals("+ 1 more", StartPreviewRules.more(p.appTotal, p.apps.size))
        assertEquals(p.apps.map { it.label.lowercase() }.sorted(), p.apps.map { it.label.lowercase() })
    }
    @Test fun preview_splitsGamesFromApps() {
        val p = preview(listOf("a.chat", "g.race", "g.puzzle", "g.war", "g.farm"))
        assertEquals(listOf("Chat"), p.apps.map { it.label })
        assertEquals(StartPreviewRules.MAX_GAMES, p.games.size)
        assertEquals(4, p.gameTotal)
        assertEquals("+ 1 more", StartPreviewRules.more(p.gameTotal, p.games.size))
        assertNull(StartPreviewRules.more(p.appTotal, p.apps.size))
    }
    @Test fun preview_skipsUninstalledPackages() {
        val p = preview(listOf("a.chat", "gone.app"))
        assertEquals(1, p.appTotal)
    }
    @Test fun preview_sitesAreCountedAndTrimmed() {
        val p = preview(emptyList(), listOf("a.com", " b.com ", "a.com", "c.com", "d.com", ""))
        assertEquals(4, p.siteTotal)
        assertEquals(StartPreviewRules.MAX_SITES, p.sites.size)
        assertEquals("+ 1 more", StartPreviewRules.more(p.siteTotal, p.sites.size))
    }
    @Test fun preview_emptyWhenNothingSelected() {
        assertTrue(preview(emptyList()).isEmpty)
        assertFalse(preview(listOf("a.chat")).isEmpty)
        assertFalse(preview(emptyList(), listOf("x.com")).isEmpty)
    }
    @Test fun siteDomains_onlyEnabledRulesOfEnabledApps() {
        val state = WebsiteState(
            enabledApps = setOf("p1"),
            rules = mapOf(
                "p1" to listOf(WebsiteRule("on.com", enabled = true, subdomains = true), WebsiteRule("off.com", enabled = false, subdomains = true)),
                "p2" to listOf(WebsiteRule("other.com", enabled = true, subdomains = true)),
            ),
        )
        assertEquals(listOf("on.com"), StartPreviewRules.siteDomains(state))
    }
}
