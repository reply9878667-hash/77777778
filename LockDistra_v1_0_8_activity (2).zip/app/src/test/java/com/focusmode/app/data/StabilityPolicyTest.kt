package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Tests for the v1.5 rules: clock changes, restart signals and forged plant taps. */
class StabilityPolicyTest {

    private val minute = 60_000L
    private val anchor = ClockAnchor(wall = 1_000_000_000L, elapsed = 50_000L, boot = 7)

    // ---- ClockGuard ----

    @Test fun noAnchorMeansNoJump() {
        assertEquals(0L, ClockGuard.jump(null, 5L, 5L, 7))
    }

    @Test fun normalTimePassingIsNotAJump() {
        val j = ClockGuard.jump(anchor, anchor.wall + 10 * minute, anchor.elapsed + 10 * minute, 7)
        assertEquals(0L, j)
    }

    @Test fun smallDriftIsIgnored() {
        val j = ClockGuard.jump(anchor, anchor.wall + 10 * minute + 20_000L, anchor.elapsed + 10 * minute, 7)
        assertEquals(0L, j)
    }

    @Test fun forwardChangeIsFound() {
        val j = ClockGuard.jump(anchor, anchor.wall + 3_600_000L + 5 * minute, anchor.elapsed + 5 * minute, 7)
        assertEquals(3_600_000L, j)
    }

    @Test fun backwardChangeIsFound() {
        val j = ClockGuard.jump(anchor, anchor.wall - 2 * 3_600_000L + minute, anchor.elapsed + minute, 7)
        assertEquals(-2 * 3_600_000L, j)
    }

    @Test fun restartCannotBeCompared() {
        assertEquals(0L, ClockGuard.jump(anchor, anchor.wall + 99 * minute, anchor.elapsed + minute, 8))
        // Same boot number is not reported by the phone, but the monotonic clock went backwards.
        assertEquals(0L, ClockGuard.jump(anchor, anchor.wall + 99 * minute, 1_000L, 7))
    }

    @Test fun shiftKeepsTimeLeft() {
        val end = anchor.wall + 30 * minute
        val jump = 3_600_000L
        val moved = ClockGuard.shifted(end, jump)
        // Remaining time measured on the new (jumped) clock is unchanged.
        assertEquals(end - anchor.wall, moved - (anchor.wall + jump))
        assertEquals(0L, ClockGuard.shifted(0L, jump)) // unset times stay unset
    }

    @Test fun anchorRefreshRules() {
        assertTrue(ClockGuard.shouldRefresh(null, 1L, 7))
        assertFalse(ClockGuard.shouldRefresh(anchor, anchor.elapsed + 10_000L, 7))
        assertTrue(ClockGuard.shouldRefresh(anchor, anchor.elapsed + ClockGuard.REFRESH_MS, 7))
        assertTrue(ClockGuard.shouldRefresh(anchor, anchor.elapsed + 10_000L, 8))
        assertTrue(ClockGuard.shouldRefresh(anchor, 10L, 7))
    }

    // ---- RestartPolicy ----

    private fun session(restore: Boolean, allowOff: Boolean, active: Boolean = true) =
        FocusState(focusActive = active, restoreAfterRestart = restore, allowTurnOff = allowOff)

    @Test fun idleStaysIdle() {
        assertEquals(RestartAction.NOTHING, RestartPolicy.decide(session(true, true, active = false), true))
    }

    @Test fun realBootWithRestoreOffEndsOnlyAnOpenSession() {
        assertEquals(RestartAction.END, RestartPolicy.decide(session(restore = false, allowOff = true), true))
        // A locked session ("Allow turning OFF" off) survives a restart even with restore off.
        assertEquals(RestartAction.RESUME, RestartPolicy.decide(session(restore = false, allowOff = false), true))
        assertEquals(RestartAction.RESUME, RestartPolicy.decide(session(restore = true, allowOff = true), true))
    }

    @Test fun forgedBootSignalNeverEndsASession() {
        assertEquals(RestartAction.RESUME, RestartPolicy.decide(session(restore = false, allowOff = true), false))
    }

    // ---- GrowPolicy ----

    @Test fun onlyThePostedReminderGrowsThePlantOnce() {
        assertTrue(GrowPolicy.accepts(token = 500L, posted = 500L, applied = 400L))
        assertFalse(GrowPolicy.accepts(500L, 500L, 500L))      // already used
        assertFalse(GrowPolicy.accepts(999_999L, 500L, 400L))  // forged number
        assertFalse(GrowPolicy.accepts(0L, 0L, 0L))            // nothing posted
        assertFalse(GrowPolicy.accepts(-5L, -5L, -9L))
    }

    // ---- check-in (plant reminder) ----

    @Test fun checkInIsPendingOnlyWhileASessionRunsAndTokenIsNew() {
        val base = FocusState(focusActive = true, checkInToken = 500L, lastGrowthToken = 400L)
        assertTrue(base.checkInPending)
        assertFalse(base.copy(lastGrowthToken = 500L).checkInPending) // already answered
        assertFalse(base.copy(focusActive = false).checkInPending)    // no session
        assertFalse(base.copy(checkInToken = 0L).checkInPending)      // nothing posted
    }
}
