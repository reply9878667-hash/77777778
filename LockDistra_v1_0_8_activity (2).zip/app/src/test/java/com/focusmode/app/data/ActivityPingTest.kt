package com.focusmode.app.data

import com.focusmode.app.data.auth.ActivityPing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ActivityPingTest {

    @Test
    fun theDayChangesAtMidnightUtc() {
        assertEquals(0L, ActivityPing.dayOf(0L))
        assertEquals(0L, ActivityPing.dayOf(ActivityPing.DAY_MS - 1))
        assertEquals(1L, ActivityPing.dayOf(ActivityPing.DAY_MS))
        assertEquals(20_401L, ActivityPing.dayOf(20_401L * ActivityPing.DAY_MS + 5))
    }

    @Test
    fun dayKeysSortByDateAndFitTheRules() {
        assertEquals("d20401", ActivityPing.dayKey(20_401L))
        assertTrue(ActivityPing.dayKey(20_401L) < ActivityPing.dayKey(20_402L))
        assertTrue(Regex("^d[0-9]{5}$").matches(ActivityPing.dayKey(20_401L)))
    }
}
