package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class AdultBlocklistTest {

    private fun indexOf(vararg domains: String): Pair<SortedDomainIndex, File> {
        val built = AdultBlocklist.build(domains.asSequence())
        val f = File.createTempFile("adult", ".txt").also { it.deleteOnExit() }
        f.writeBytes(AdultBlocklist.encode(built.domains))
        return SortedDomainIndex(f) to f
    }

    @Test fun parsesCommonFormats() {
        assertEquals("example.com", AdultBlocklist.parseLine("example.com"))
        assertEquals("example.com", AdultBlocklist.parseLine("0.0.0.0 example.com"))
        assertEquals("example.com", AdultBlocklist.parseLine("127.0.0.1\texample.com # note"))
        assertEquals("example.com", AdultBlocklist.parseLine("||example.com^"))
        assertEquals("example.com", AdultBlocklist.parseLine("address=/example.com/0.0.0.0"))
        assertEquals("example.com", AdultBlocklist.parseLine("*.example.com"))
        assertEquals("example.com", AdultBlocklist.parseLine("WWW.Example.COM"))
    }

    @Test fun rejectsJunk() {
        assertNull(AdultBlocklist.parseLine("# comment"))
        assertNull(AdultBlocklist.parseLine("! comment"))
        assertNull(AdultBlocklist.parseLine(""))
        assertNull(AdultBlocklist.parseLine("localhost"))
        assertNull(AdultBlocklist.parseLine("127.0.0.1 localhost"))
        assertNull(AdultBlocklist.parseLine("192.168.0.1"))
        assertNull(AdultBlocklist.parseLine("not a domain"))
        assertNull(AdultBlocklist.parseLine("bad_domain.com"))
        assertNull(AdultBlocklist.parseLine("example.com/path"))
        assertNull(AdultBlocklist.parseLine("-bad.com"))
    }

    @Test fun buildSortsDedupesAndDropsCoveredSubdomains() {
        val b = AdultBlocklist.build(sequenceOf("b.com", "a.com", "A.com", "x.a.com", "0.0.0.0 c.net", "# c", "bad line here"))
        assertEquals(listOf("a.com", "b.com", "c.net"), b.domains)
    }

    @Test fun neverBlockEntriesAreDropped() {
        val b = AdultBlocklist.build(sequenceOf("reddit.com", "user.tumblr.com", "x.com", "site.com"))
        assertEquals(listOf("site.com"), b.domains)
    }

    @Test fun matchesExactAndSubdomainsAtDotBoundaryOnly() {
        val (idx, _) = indexOf("badsite.com", "other.net")
        assertTrue(AdultBlocklist.matches("badsite.com", idx))
        assertTrue(AdultBlocklist.matches("www.badsite.com", idx))
        assertTrue(AdultBlocklist.matches("m.cdn.badsite.com", idx))
        assertTrue(AdultBlocklist.matches("https://m.badsite.com/watch?v=1", idx))
        assertFalse(AdultBlocklist.matches("notbadsite.com", idx))
        assertFalse(AdultBlocklist.matches("badsite.com.evil.org", idx))
        assertFalse(AdultBlocklist.matches("badsite.net", idx))
        assertFalse(AdultBlocklist.matches("search words", idx))
    }

    @Test fun protectedHostsAreNeverMatched() {
        val (idx, _) = indexOf("site.com")
        // Even if a list file somehow held it, a never-block host stays open.
        val f = File.createTempFile("p", ".txt").also { it.deleteOnExit() }
        f.writeText("reddit.com\nsite.com\n")
        assertFalse(AdultBlocklist.matches("old.reddit.com", SortedDomainIndex(f)))
        assertTrue(AdultBlocklist.matches("site.com", idx))
    }

    @Test fun binarySearchFindsEveryEntryAndNothingElse() {
        val domains = (0 until 2000).map { "site${it * 7}.com" }
        val built = AdultBlocklist.build(domains.asSequence())
        val f = File.createTempFile("big", ".txt").also { it.deleteOnExit() }
        f.writeBytes(AdultBlocklist.encode(built.domains))
        val idx = SortedDomainIndex(f)
        for (d in domains) assertTrue(d, idx.contains(d))
        for (i in 0 until 500) assertFalse(idx.contains("site${i * 7 + 1}.com"))
        assertFalse(idx.contains(""))
        assertFalse(idx.contains("zzz.com"))
        assertEquals(domains.size, AdultBlocklist.verifyFile(f))
    }

    @Test fun emptyOrMissingFileMatchesNothing() {
        val idx = SortedDomainIndex(File("/nonexistent/adult.txt"))
        assertFalse(idx.contains("anything.com"))
    }

    @Test fun verifyFileRejectsUnsortedDuplicateAndBadLines() {
        fun check(text: String): Boolean {
            val f = File.createTempFile("v", ".txt").also { it.deleteOnExit() }
            f.writeText(text)
            return try { AdultBlocklist.verifyFile(f); true } catch (_: Exception) { false }
        }
        assertTrue(check("a.com\nb.com\n"))
        assertFalse(check("b.com\na.com\n"))
        assertFalse(check("a.com\na.com\n"))
        assertFalse(check("a.com\n\nb.com\n"))
        assertFalse(check("a.com\nnot a domain\n"))
        assertFalse(check("A.com\n"))
    }

    @Test fun updateIsRefusedWhenInvalidTinyOrShrunk() {
        val good = AdultBlocklist.build((1..400).asSequence().map { "site$it.com" })
        assertEquals(AdultBlocklist.Refusal.NONE, AdultBlocklist.judge(good, currentCount = 300))
        assertEquals(AdultBlocklist.Refusal.NONE, AdultBlocklist.judge(good, currentCount = 0))

        val tiny = AdultBlocklist.build((1..10).asSequence().map { "site$it.com" })
        assertEquals(AdultBlocklist.Refusal.TOO_SMALL, AdultBlocklist.judge(tiny, currentCount = 0))

        val shrunk = AdultBlocklist.build((1..100).asSequence().map { "site$it.com" })
        assertEquals(AdultBlocklist.Refusal.SHRANK_TOO_MUCH, AdultBlocklist.judge(shrunk, currentCount = 1000))

        // An HTML error page or garbage: lots of lines, almost none valid.
        val html = AdultBlocklist.build(
            (1..200).asSequence().map { if (it <= 60) "site$it.com" else "<div class=\"x\">line $it</div>" }
        )
        assertEquals(AdultBlocklist.Refusal.TOO_MANY_BAD_LINES, AdultBlocklist.judge(html, currentCount = 0))
    }

    @Test fun candidatesStopBeforeBareTld() {
        assertEquals(listOf("a.b.example.com", "b.example.com", "example.com"), AdultBlocklist.candidates("a.b.example.com"))
        assertEquals(listOf("example.com"), AdultBlocklist.candidates("example.com"))
    }

    @Test fun sha256IsStable() {
        assertEquals(
            "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad",
            AdultBlocklist.sha256("abc".toByteArray())
        )
    }
}
