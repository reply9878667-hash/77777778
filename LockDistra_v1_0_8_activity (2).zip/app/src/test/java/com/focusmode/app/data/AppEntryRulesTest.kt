package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppEntryRulesTest {

    private fun route(
        signedIn: Boolean = false,
        onboardingDone: Boolean = false,
        authRequired: Boolean = true,
        ownOnboardingRequired: Boolean = false,
        holdAuth: Boolean = false,
        wantsLogin: Boolean = false,
    ) = AppEntryRules.route(signedIn, onboardingDone, authRequired, ownOnboardingRequired, holdAuth, wantsLogin)

    @Test fun newUserStartsWithOnboarding() = assertEquals(EntryRoute.Onboarding, route())

    @Test fun afterOnboardingALoggedOutUserSeesTheAccountScreen() =
        assertEquals(EntryRoute.Auth, route(onboardingDone = true))

    @Test fun savedLoginGoesStraightToHome() =
        assertEquals(EntryRoute.Home, route(signedIn = true, onboardingDone = true))

    @Test fun savedLoginNeverShowsOnboardingAgain() =
        assertEquals(EntryRoute.Home, route(signedIn = true, onboardingDone = false))

    @Test fun logoutClosesHome() {
        assertEquals(EntryRoute.Home, route(signedIn = true, onboardingDone = true))
        assertEquals(EntryRoute.Auth, route(signedIn = false, onboardingDone = true))
    }

    @Test fun logoutDoesNotSendAnExistingUserBackToOnboarding() =
        assertNotEquals(EntryRoute.Onboarding, route(signedIn = false, onboardingDone = true))

    @Test fun successScreenStaysUntilContinue() {
        assertEquals(EntryRoute.Auth, route(signedIn = true, onboardingDone = true, holdAuth = true))
        assertEquals(EntryRoute.Home, route(signedIn = true, onboardingDone = true, holdAuth = false))
    }

    @Test fun haveAccountSkipsTheQuestions() {
        assertEquals(EntryRoute.Auth, route(wantsLogin = true))
        // ... but only when accounts exist in this build
        assertEquals(EntryRoute.Onboarding, route(wantsLogin = true, authRequired = false))
    }

    @Test fun newAccountOnASharedPhoneAnswersItsOwnQuestions() {
        assertEquals(EntryRoute.Onboarding, route(signedIn = true, onboardingDone = true, ownOnboardingRequired = true))
        // after the success screen, not before
        assertEquals(EntryRoute.Auth, route(signedIn = true, onboardingDone = true, ownOnboardingRequired = true, holdAuth = true))
    }

    @Test fun withoutFirebaseTheAppStaysOpen() {
        assertEquals(EntryRoute.Home, route(onboardingDone = true, authRequired = false))
        assertEquals(EntryRoute.Onboarding, route(onboardingDone = false, authRequired = false))
    }

    @Test fun accountScreenStartsOnSignUpOnlyForFreshOnboarding() {
        assertFalse(AppEntryRules.startOnLogin(hasUnclaimedAnswers = true, wantsLogin = false, hasNotice = false))
        assertTrue(AppEntryRules.startOnLogin(hasUnclaimedAnswers = false, wantsLogin = false, hasNotice = false))
        assertTrue(AppEntryRules.startOnLogin(hasUnclaimedAnswers = true, wantsLogin = true, hasNotice = false))
        assertTrue(AppEntryRules.startOnLogin(hasUnclaimedAnswers = true, wantsLogin = false, hasNotice = true))
    }

    @Test fun onlyANewAccountWithoutWaitingAnswersNeedsOnboarding() {
        assertTrue(AppEntryRules.newAccountNeedsOnboarding(isNewAccount = true, answersForThisAccount = false))
        assertFalse(AppEntryRules.newAccountNeedsOnboarding(isNewAccount = true, answersForThisAccount = true))
        assertFalse(AppEntryRules.newAccountNeedsOnboarding(isNewAccount = false, answersForThisAccount = false))
    }

    private fun assertNotEquals(unexpected: Any, actual: Any) = assertTrue(unexpected != actual)
}
