package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class LectureWatchTest {

    private val dur = 600.0 // a 10 minute lecture

    /** Plays [from] .. [to] at [speed] with a report every 3 real seconds. Returns the clock afterwards. */
    private fun play(w: LectureWatch, from: Double, to: Double, speed: Double = 1.0, startMs: Long = 0L): Long {
        var pos = from
        var now = startMs
        w.report(pos, dur, speed, now)
        while (pos < to) {
            now += 3000
            pos = minOf(to, pos + 3 * speed)
            w.report(pos, dur, speed, now)
        }
        return now
    }

    @Test fun watchingTheWholeLecture_counts() {
        val w = LectureWatch()
        play(w, 0.0, 600.0)
        assertTrue(w.enough(dur))
        assertTrue(w.coverage(dur) > 0.97)
    }

    @Test fun draggingTheSeekBarToTheEnd_doesNotCount() {
        val w = LectureWatch()
        val t = play(w, 0.0, 20.0)
        w.report(598.0, dur, 1.0, t + 1000) // the jump
        w.report(600.0, dur, 1.0, t + 4000)
        assertFalse(w.enough(dur))
        assertTrue(w.coverage(dur) < 0.1)
        assertTrue(w.firstGap(dur) in 17..22)
    }

    @Test fun skippingWithThePlusTenButtonAgainAndAgain_doesNotCount() {
        val w = LectureWatch()
        var pos = 0.0
        var now = 0L
        w.report(pos, dur, 1.0, now)
        while (pos < 590) { now += 3000; pos += 3 + 10; w.report(pos, dur, 1.0, now) } // +10 s every 3 s
        assertFalse(w.enough(dur))
        assertTrue(w.coverage(dur) < 0.25)
    }

    @Test fun twiceTheSpeed_stillCountsFully() {
        val w = LectureWatch()
        play(w, 0.0, 600.0, speed = 2.0)
        assertTrue(w.enough(dur))
    }

    @Test fun skippingASmallPart_isAllowed_aBigOneIsNot() {
        val small = LectureWatch()
        var t = play(small, 0.0, 200.0)
        small.report(240.0, dur, 1.0, t + 3000) // 40 s skipped (~7 %)
        play(small, 240.0, 600.0, startMs = t + 3000)
        assertTrue(small.enough(dur))

        val big = LectureWatch()
        t = play(big, 0.0, 200.0)
        big.report(400.0, dur, 1.0, t + 3000) // 200 s skipped (~33 %)
        play(big, 400.0, 600.0, startMs = t + 3000)
        assertFalse(big.enough(dur))
    }

    @Test fun rewindingAndWatchingAgain_neverCountsAPartTwice() {
        val w = LectureWatch()
        var t = play(w, 0.0, 100.0)
        w.report(50.0, dur, 1.0, t + 1000)
        play(w, 50.0, 100.0, startMs = t + 1000)
        assertTrue(w.watchedSeconds(dur) <= 105.0)
    }

    @Test fun pausedVideo_countsNothingNew() {
        val w = LectureWatch()
        w.report(100.0, dur, 1.0, 0)
        assertFalse(w.report(100.0, dur, 1.0, 3000))
        assertFalse(w.report(100.0, dur, 1.0, 600_000))
        assertEquals(0.0, w.watchedSeconds(dur), 0.0)
    }

    @Test fun firstGap_pointsAtTheSkippedPart() {
        val w = LectureWatch()
        val t = play(w, 0.0, 100.0)
        w.report(300.0, dur, 1.0, t + 3000)
        assertTrue(w.firstGap(dur) in 95..101)
    }

    @Test fun savedAndRestored_keepsTheWatchedParts() {
        val w = LectureWatch()
        play(w, 0.0, 300.0)
        val back = LectureWatch(LectureWatch.fromHex(w.toHex()))
        assertEquals(w.watchedSeconds(dur), back.watchedSeconds(dur), 0.0)
        assertEquals(0.0, LectureWatch(LectureWatch.fromHex(null)).watchedSeconds(dur), 0.0)
        assertEquals(0.0, LectureWatch(LectureWatch.fromHex("zz")).watchedSeconds(dur), 0.0)
    }

    @Test fun badNumbers_areIgnored() {
        val w = LectureWatch()
        assertFalse(w.report(Double.NaN, dur, 1.0, 0))
        assertFalse(w.report(10.0, 0.0, 1.0, 0))
        assertFalse(w.report(10.0, Double.NaN, 1.0, 0))
    }

    // ---- skipped parts on the seek bar ----

    @Test fun skippedRanges_showTheJumpedOverPart() {
        val w = LectureWatch()
        val t = play(w, 0.0, 100.0)
        w.report(400.0, dur, 1.0, t + 3000)          // jump from 100 to 400 (not counted)
        play(w, 400.0, 420.0, startMs = t + 6000)    // watches on from there
        val r = w.skippedRanges(dur)
        assertEquals(1, r.size)
        assertTrue(r[0].first in 98..104)
        assertTrue(r[0].second in 396..401)
    }

    @Test fun skippedRanges_neverListTheUnplayedRest() {
        val w = LectureWatch()
        play(w, 0.0, 120.0)
        assertTrue(w.skippedRanges(dur).isEmpty())   // nothing skipped: the rest is just not reached yet
    }

    @Test fun skippedRanges_goAwayWhenWatchedLater() {
        val w = LectureWatch()
        val t = play(w, 0.0, 100.0)
        w.report(400.0, dur, 1.0, t + 3000)
        val t2 = play(w, 400.0, 420.0, startMs = t + 6000)
        assertEquals(1, w.skippedRanges(dur).size)
        play(w, 98.0, 402.0, startMs = t2 + 3000)    // goes back and watches the gap
        assertTrue(w.skippedRanges(dur).isEmpty())
    }

    @Test fun skippedRanges_ignoreTinyGaps_andSurviveRestore() {
        val w = LectureWatch()
        play(w, 2.0, 200.0)                          // starts 2 s late: not worth a red mark
        assertTrue(w.skippedRanges(dur).isEmpty())
        val restored = LectureWatch(LectureWatch.fromHex(w.toHex()))
        restored.report(300.0, dur, 1.0, 0L)         // a jump after resuming
        assertTrue(restored.skippedRanges(dur).isNotEmpty())
    }

    @Test fun skippedJson_usesDotsAndFractions() {
        val w = LectureWatch()
        val t = play(w, 0.0, 60.0)
        w.report(300.0, dur, 1.0, t + 3000)
        val json = w.skippedJson(dur)
        assertTrue(Regex("^\\[\\[0\\.\\d{4},0\\.\\d{4}\\]\\]$").matches(json))
        assertEquals("[]", LectureWatch().skippedJson(dur))
    }
}
