package com.focusmode.app.data

import com.focusmode.app.data.StudyCheckInRules.Step
import org.junit.Assert.*
import org.junit.Test

/** Pure rules of the Study Check-In (no Android). The scheduling glue is checked by hand on a device, see STUDY_CHECKIN.md. */
class StudyCheckInTest {

    private val min = 60_000L
    private val t0 = 1_000_000_000L

    // ---- setting ----
    @Test fun default_isOff_andPresetsAre10And15() {
        assertEquals(StudyCheckInRules.OFF, FocusState().studyMin)
        assertEquals(listOf(10, 15), StudyCheckInRules.PRESETS)
    }
    @Test fun clamp_offStaysOff_customIsBounded() {
        assertEquals(0, StudyCheckInRules.clamp(0))
        assertEquals(0, StudyCheckInRules.clamp(-5))
        assertEquals(StudyCheckInRules.MIN_CUSTOM, StudyCheckInRules.clamp(1))
        assertEquals(10, StudyCheckInRules.clamp(10))
        assertEquals(37, StudyCheckInRules.clamp(37))
        assertEquals(StudyCheckInRules.MAX_CUSTOM, StudyCheckInRules.clamp(10_000))
    }
    @Test fun customVsPreset() {
        assertFalse(StudyCheckInRules.isCustom(0))
        assertFalse(StudyCheckInRules.isCustom(10))
        assertFalse(StudyCheckInRules.isCustom(15))
        assertTrue(StudyCheckInRules.isCustom(20))
    }
    @Test fun canChange_onlyBetweenSessions_andWhenSettingsUnlocked() {
        assertTrue(StudyCheckInRules.canChange(focusActive = false, canChangeSettings = true))
        assertFalse(StudyCheckInRules.canChange(focusActive = true, canChangeSettings = true))
        assertFalse(StudyCheckInRules.canChange(focusActive = false, canChangeSettings = false))
    }

    // ---- when something is due ----
    @Test fun nothingDue_whenOff_orNoSession() {
        assertEquals(Step.NONE, StudyCheckInRules.decide(true, 0, t0, 0L, t0 + 99 * min))
        assertEquals(Step.NONE, StudyCheckInRules.decide(false, 10, t0, 0L, t0 + 99 * min))
        assertEquals(Step.NONE, StudyCheckInRules.decide(false, 10, t0, t0 + min, t0 + 99 * min))
    }
    @Test fun prompt_dueExactlyAtInterval_10and15() {
        for (m in listOf(10, 15)) {
            val next = t0 + m * min
            assertEquals(Step.NONE, StudyCheckInRules.decide(true, m, next, 0L, next - 1))
            assertEquals(Step.PROMPT, StudyCheckInRules.decide(true, m, next, 0L, next))
        }
    }
    @Test fun nextPrompt_isOneIntervalAfterThisPrompt() {
        assertEquals(t0 + 10 * min, StudyCheckInRules.nextAfterPrompt(t0, 10))
        assertEquals(t0 + 15 * min, StudyCheckInRules.nextAfterPrompt(t0, 15))
        assertEquals(t0 + 23 * min, StudyCheckInRules.nextAfterPrompt(t0, 23))
    }
    @Test fun responseWindow_isOneMinute() {
        assertEquals(60_000L, StudyCheckInRules.RESPONSE_WINDOW_MS)
    }
    @Test fun waiting_untilDeadline_thenMissed() {
        val deadline = t0 + min
        assertEquals(Step.NONE, StudyCheckInRules.decide(true, 10, t0 + 10 * min, deadline, t0 + 1))
        assertEquals(Step.NONE, StudyCheckInRules.decide(true, 10, t0 + 10 * min, deadline, deadline - 1))
        assertEquals(Step.MISSED, StudyCheckInRules.decide(true, 10, t0 + 10 * min, deadline, deadline))
        assertEquals(Step.MISSED, StudyCheckInRules.decide(true, 10, t0 + 10 * min, deadline, deadline + StudyCheckInRules.MISSED_GRACE_MS))
    }
    @Test fun noticedTooLate_isExpiredNotMissed() {
        val deadline = t0 + min
        assertEquals(
            Step.EXPIRED,
            StudyCheckInRules.decide(true, 10, t0 + 10 * min, deadline, deadline + StudyCheckInRules.MISSED_GRACE_MS + 1),
        )
    }
    @Test fun noSecondPrompt_whileOneIsWaiting() {
        // Even if the next time has already come, a waiting prompt is handled first.
        assertEquals(Step.NONE, StudyCheckInRules.decide(true, 2, t0, t0 + 30_000L, t0 + 10_000L))
    }

    // ---- confirmation ----
    @Test fun confirm_onlyForTheWaitingCheckIn() {
        assertTrue(StudyCheckInRules.acceptsConfirm(tapSeq = 5, currentSeq = 5, deadline = t0, focusActive = true))
        assertFalse(StudyCheckInRules.acceptsConfirm(4, 5, t0, true))   // old notification
        assertFalse(StudyCheckInRules.acceptsConfirm(6, 5, t0, true))   // forged number
        assertFalse(StudyCheckInRules.acceptsConfirm(0, 0, t0, true))   // no number
        assertFalse(StudyCheckInRules.acceptsConfirm(5, 5, 0L, true))   // nothing waiting (already answered / missed)
        assertFalse(StudyCheckInRules.acceptsConfirm(5, 5, t0, false))  // session is over
    }

    // ---- the trusted-phone alert ----
    private fun due(
        method: FocusOffMethod,
        miss: Long = 3, sent: Long = 2, missedAt: Long = t0, now: Long = t0 + 1_000L, tries: Int = 0, last: Long = 0L,
    ) = StudyCheckInRules.alertDue(miss, sent, missedAt, now, method, tries, last)

    @Test fun alert_onlyForOnlineApproval() {
        assertTrue(due(FocusOffMethod.ONLINE))
        assertFalse(due(FocusOffMethod.NORMAL))
        assertFalse(due(FocusOffMethod.PASSWORD))
        assertTrue(StudyCheckInRules.alertAllowed(FocusOffMethod.ONLINE))
        assertFalse(StudyCheckInRules.alertAllowed(FocusOffMethod.NORMAL))
        assertFalse(StudyCheckInRules.alertAllowed(FocusOffMethod.PASSWORD))
    }
    @Test fun alert_neverTwiceForTheSameMiss() {
        assertFalse(due(FocusOffMethod.ONLINE, miss = 3, sent = 3))
        assertFalse(due(FocusOffMethod.ONLINE, miss = 2, sent = 3))
        assertFalse(due(FocusOffMethod.ONLINE, miss = 0, sent = 0))
    }
    @Test fun alert_retriesAreSpacedAndLimited_andGiveUpWhenStale() {
        val gap = StudyCheckInRules.ALERT_RETRY_GAP_MS
        assertFalse(due(FocusOffMethod.ONLINE, tries = 1, last = t0 + 1_000L, now = t0 + 1_000L + gap - 1))
        assertTrue(due(FocusOffMethod.ONLINE, tries = 1, last = t0 + 1_000L, now = t0 + 1_000L + gap))
        assertFalse(due(FocusOffMethod.ONLINE, tries = StudyCheckInRules.ALERT_MAX_TRIES, last = t0, now = t0 + 10 * gap))
        assertFalse(due(FocusOffMethod.ONLINE, now = t0 + StudyCheckInRules.ALERT_MAX_AGE_MS + 1))
    }
    @Test fun alertId_isStablePerMiss_uniqueAcrossMisses_andFitsTheWorkersRule() {
        val a = StudyCheckInRules.alertId(7, t0)
        assertEquals(a, StudyCheckInRules.alertId(7, t0))
        assertNotEquals(a, StudyCheckInRules.alertId(8, t0 + 10 * min))
        assertNotEquals(a, StudyCheckInRules.alertId(7, t0 + 1))
        val workerRule = Regex("^[-_A-Za-z0-9]{10,40}$")
        assertTrue(a, workerRule.matches(a))
        assertTrue(workerRule.matches(StudyCheckInRules.alertId(1, 0L)))
        assertTrue(workerRule.matches(StudyCheckInRules.alertId(Int.MAX_VALUE.toLong(), 9_999_999_999_999L)))
    }

    // ---- text ----
    @Test fun wording_matchesTheSpec() {
        assertEquals("Are You Still Studying?", StudyCheckInRules.PROMPT_TITLE)
        assertEquals("Please confirm that you are actively studying.", StudyCheckInRules.PROMPT_TEXT)
        assertEquals("I'm Studying", StudyCheckInRules.PROMPT_BUTTON)
        assertEquals("Study Check-In Missed", StudyCheckInRules.ALERT_TITLE)
        assertEquals(
            "The user has not responded to the study confirmation for one minute. Please check whether they are studying.",
            StudyCheckInRules.ALERT_TEXT,
        )
    }
}
