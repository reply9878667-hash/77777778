package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Test

class StudyUpdatesTest {
    private fun v(id: String) = StudyVideo(id, "t$id", "UC1", "Ch", "", 300, "27", true)

    @Test fun unseenKeepsOrderAndSkipsSeen() {
        assertEquals(listOf("c", "a"), StudyUpdates.unseen(listOf("c", "b", "a"), setOf("b")))
    }

    @Test fun nothingNewGivesNothing() {
        assertEquals(emptyList<String>(), StudyUpdates.unseen(listOf("a", "b"), setOf("a", "b", "z")))
    }

    @Test fun trimKeepsNewestAndRemovesDuplicates() {
        val many = (1..500).map { "id$it" } + "id1"
        val out = StudyUpdates.trimSeen(many, 400)
        assertEquals(400, out.size)
        assertEquals("id1", out.last())
        assertEquals(out.distinct(), out)
    }

    @Test fun notifyOrderIsCappedAndNewestLast() {
        val fresh = listOf("5", "4", "3", "2", "1").map { v(it) }
        assertEquals(listOf("2", "3", "4", "5"), StudyUpdates.notifyOrder(fresh).map { it.id })
    }

    @Test fun pendingRoundTripKeepsTheVideo() {
        val one = v("abc")
        assertEquals(one, StudyRules.fromJson(StudyRules.toJson(listOf(one))).first())
    }
}

class ChannelAlertsTest {
    private fun v(title: String) = StudyVideo("x", title, "UC1", "Ch", "", 300, "27", true)
    private val subjects = listOf("Maths", "Physics")

    @Test fun allAnnouncesEverything() {
        assertEquals(true, StudyUpdates.wants(ChannelAlerts.ALL, v("Random upload"), subjects))
    }

    @Test fun noneAnnouncesNothing() {
        assertEquals(false, StudyUpdates.wants(ChannelAlerts.NONE, v("Maths chapter 1"), subjects))
    }

    @Test fun personalizedNeedsASubjectWord() {
        assertEquals(true, StudyUpdates.wants(ChannelAlerts.PERSONALIZED, v("Class 10 MATHS - Trigonometry"), subjects))
        assertEquals(false, StudyUpdates.wants(ChannelAlerts.PERSONALIZED, v("Channel update and Q&A"), subjects))
    }

    @Test fun unknownKeyIsAll() {
        assertEquals(ChannelAlerts.ALL, ChannelAlerts.fromKey(null))
        assertEquals(ChannelAlerts.ALL, ChannelAlerts.fromKey("zzz"))
        assertEquals(ChannelAlerts.NONE, ChannelAlerts.fromKey("none"))
    }
}

class FirstLookTest {
    private fun v(published: Long) = StudyVideo("x", "t", "UC1", "Ch", "", 300, "27", true, publishedAt = published)

    @Test fun cutoffIsTheFollowTimeWhenKnown() {
        assertEquals(5_000L, StudyUpdates.firstLookCutoff(5_000L, 999_999_999L))
    }

    @Test fun unknownFollowTimeMeansTheLastDay() {
        val now = 10L * 24 * 3600 * 1000
        assertEquals(now - StudyUpdates.UNKNOWN_FOLLOW_WINDOW_MS, StudyUpdates.firstLookCutoff(0L, now))
    }

    @Test fun uploadAfterTheFollowCountsAsNew() {
        org.junit.Assert.assertTrue(StudyUpdates.isNewSince(v(6_000L), 5_000L))
        org.junit.Assert.assertTrue(StudyUpdates.isNewSince(v(5_000L), 5_000L))
    }

    @Test fun olderOrUndatedUploadsStayQuiet() {
        org.junit.Assert.assertFalse(StudyUpdates.isNewSince(v(4_999L), 5_000L))
        org.junit.Assert.assertFalse(StudyUpdates.isNewSince(v(0L), 5_000L))
    }
}

class ShortsRulesTest {
    private fun s(cat: String, lang: String = "", title: String = "Explained in 60 seconds", ch: String = "UC9") =
        StudyVideo("v", title, ch, "Creator", "", 45, cat, true, audioLang = lang)

    @Test fun explainerCategoriesAreAcceptedInShorts() {
        for (c in listOf("27", "28", "25")) org.junit.Assert.assertTrue(c, StudyRules.acceptShort(s(c), emptySet()))
    }

    @Test fun otherCategoriesStayOut() {
        org.junit.Assert.assertFalse(StudyRules.acceptShort(s("24"), emptySet()))
        org.junit.Assert.assertFalse(StudyRules.acceptShort(s("22"), emptySet()))
    }

    @Test fun longVideosStayEducationOnly() {
        org.junit.Assert.assertFalse(StudyRules.accept(s("28"), emptySet()))
        org.junit.Assert.assertTrue(StudyRules.accept(s("27"), emptySet()))
    }

    @Test fun foreignLanguageShortsAreLeftOut() {
        org.junit.Assert.assertFalse(StudyRules.acceptShort(s("27", "es"), emptySet()))
        org.junit.Assert.assertFalse(StudyRules.acceptShort(s("27", "pt-BR"), emptySet()))
        org.junit.Assert.assertTrue(StudyRules.acceptShort(s("27", "hi"), emptySet()))
        org.junit.Assert.assertTrue(StudyRules.acceptShort(s("27", "en-US"), emptySet()))
        org.junit.Assert.assertTrue(StudyRules.acceptShort(s("27", ""), emptySet()))
    }

    @Test fun savedVideoKeepsItsLanguage() {
        val v = s("27", "ta")
        org.junit.Assert.assertEquals("ta", StudyRules.fromJson(StudyRules.toJson(listOf(v))).first().audioLang)
    }
}
