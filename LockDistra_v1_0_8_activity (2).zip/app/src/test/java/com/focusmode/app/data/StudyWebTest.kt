package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class StudyWebTest {

    private fun card(id: String = "abcdefghijk", title: String = "Quadratic equations class 10", text: String = "Maths Guru • 1M views", dur: String = "12:34") =
        WebCard(id, title, text, dur)

    private fun video(id: String = "abcdefghijk", category: String = "27", seconds: Int = 600, channelId: String = "UC1") =
        StudyVideo(id, "Quadratic equations", channelId, "Maths Guru", "", seconds, category, true)

    // ---- addresses ----

    @Test fun searchUrl_encodesTheQuery_andAsksForVideosOnly() {
        val u = StudyWeb.searchUrl("ohm's law")
        assertTrue(u.startsWith("https://m.youtube.com/results?search_query=ohm%27s+law"))
        assertTrue(u.contains("&sp=EgIQAQ%253D%253D"))
        assertTrue(StudyWeb.isAllowedPage(u))
    }

    @Test fun videoIdFromUrl_readsWatchLinksOnly() {
        assertEquals("abcdefghijk", StudyWeb.videoIdFromUrl("/watch?v=abcdefghijk"))
        assertEquals("abcdefghijk", StudyWeb.videoIdFromUrl("https://m.youtube.com/watch?v=abcdefghijk&t=5"))
        assertEquals("", StudyWeb.videoIdFromUrl("/shorts/abcdefghijk"))
        assertEquals("", StudyWeb.videoIdFromUrl("/watch?v=short"))
        assertEquals("", StudyWeb.videoIdFromUrl("/results?search_query=v=abcdefghijk"))
        assertEquals("", StudyWeb.videoIdFromUrl(null))
    }

    @Test fun onlyTheSearchPage_andItsConsentScreen_areAllowed() {
        assertTrue(StudyWeb.isAllowedPage("https://m.youtube.com/results?search_query=maths"))
        assertTrue(StudyWeb.isAllowedPage("https://www.youtube.com/results?search_query=maths"))
        assertTrue(StudyWeb.isAllowedPage("https://consent.youtube.com/m?continue=https%3A%2F%2Fm.youtube.com%2F"))
        assertFalse(StudyWeb.isAllowedPage("https://m.youtube.com/"))
        assertFalse(StudyWeb.isAllowedPage("https://m.youtube.com/watch?v=abcdefghijk"))
        assertFalse(StudyWeb.isAllowedPage("https://m.youtube.com/shorts/abcdefghijk"))
        assertFalse(StudyWeb.isAllowedPage("https://m.youtube.com/@somechannel"))
        assertFalse(StudyWeb.isAllowedPage("https://evil.example.com/results"))
        assertFalse(StudyWeb.isAllowedPage("https://youtube.com.evil.example.com/results"))
        assertFalse(StudyWeb.isAllowedPage("http://m.youtube.com/results?search_query=maths"))
        assertFalse(StudyWeb.isAllowedPage(null))
    }

    // ---- what the page sends ----

    @Test fun durationLabel_isRead() {
        assertEquals(754, StudyWeb.parseDurationLabel("12:34"))
        assertEquals(3723, StudyWeb.parseDurationLabel("1:02:03"))
        assertEquals(45, StudyWeb.parseDurationLabel("0:45"))
        assertEquals(0, StudyWeb.parseDurationLabel("LIVE"))
        assertEquals(0, StudyWeb.parseDurationLabel(""))
        assertEquals(0, StudyWeb.parseDurationLabel(null))
    }

    @Test fun parseCards_dropsBadIds_andRepeats() {
        val json = """[{"id":"abcdefghijk","title":"A","text":"t","dur":"1:00"},
            {"id":"abcdefghijk","title":"again"},
            {"id":"short","title":"bad"},
            {"id":"zzzzzzzzzzz","title":"B"}]"""
        val cards = StudyWeb.parseCards(json)
        assertEquals(listOf("abcdefghijk", "zzzzzzzzzzz"), cards.map { it.id })
        assertEquals(60, cards.first().seconds)
        assertTrue(StudyWeb.parseCards("not json").isEmpty())
        assertTrue(StudyWeb.parseCards(null).isEmpty())
    }

    @Test fun verdictJson_keepsOnlyValidIds() {
        val json = StudyWeb.verdictJson(WebVerdict(listOf("abcdefghijk", "'; alert(1)"), listOf("zzzzzzzzzzz")))
        assertTrue(json.contains("abcdefghijk"))
        assertTrue(json.contains("zzzzzzzzzzz"))
        assertFalse(json.contains("alert"))
    }

    // ---- study signals ----

    @Test fun studySignal_english_andHindi() {
        assertTrue(StudyWeb.hasStudySignal("Ohm's law class 10"))
        assertTrue(StudyWeb.hasStudySignal("कक्षा 10 गणित अध्याय 1"))
        assertFalse(StudyWeb.hasStudySignal("Top 10 cars of the year"))
    }

    @Test fun studyQuery_isASubject_orHasAStudyWord() {
        assertTrue(StudyWeb.isStudyQuery("maths", listOf("Maths", "Science")))
        assertTrue(StudyWeb.isStudyQuery("ohm's law class 10", emptyList()))
        assertFalse(StudyWeb.isStudyQuery("minecraft", listOf("Maths")))
        assertFalse(StudyWeb.isStudyQuery("  ", listOf("Maths")))
    }

    // ---- the loose rules (limit used up) ----

    @Test fun loose_acceptsStudyLooking_rejectsDistractions() {
        assertTrue(StudyWeb.looseAccept(card(), false, emptyList()))
        assertFalse(StudyWeb.looseAccept(card(title = "Funny physics prank"), false, emptyList()))
        assertFalse(StudyWeb.looseAccept(card(title = "Top 10 cars of the year", text = "Auto Fan • 2M views"), false, emptyList()))
    }

    @Test fun loose_aStudySearch_lets_unlabelledTitlesThrough_butNotDistractions() {
        val plain = card(title = "Newton and the apple", text = "Some Channel • 10K views")
        assertFalse(StudyWeb.looseAccept(plain, false, emptyList()))
        assertTrue(StudyWeb.looseAccept(plain, true, emptyList()))
        assertFalse(StudyWeb.looseAccept(card(title = "Newton gameplay", text = "Gamer • 10K views"), true, emptyList()))
    }

    @Test fun loose_neverShowsShorts_orAdultWords() {
        assertFalse(StudyWeb.looseAccept(card(dur = "0:45"), true, emptyList()))
        assertFalse(StudyWeb.looseAccept(card(title = "xxx class", text = "x"), true, listOf("x channel")))
    }

    @Test fun loose_trustedChannelName_beatsDistractionWords() {
        val c = card(title = "Physics prank experiment", text = "Physics Wallah • 5M views")
        assertFalse(StudyWeb.looseAccept(c, false, emptyList()))
        assertTrue(StudyWeb.looseAccept(c, false, listOf("Physics Wallah")))
    }

    // ---- judge ----

    @Test fun judge_withApi_usesTheNormalRules() {
        val cards = listOf(card("aaaaaaaaaaa"), card("bbbbbbbbbbb"), card("ccccccccccc"), card("ddddddddddd"))
        val details = mapOf(
            "aaaaaaaaaaa" to video("aaaaaaaaaaa", category = "27"),
            "bbbbbbbbbbb" to video("bbbbbbbbbbb", category = "24"),        // not Education
            "ccccccccccc" to video("ccccccccccc", category = "27", seconds = 45), // a Short
        )                                                                     // ddddddddddd: the API does not know it
        val v = StudyWeb.judge(cards, details, true, emptySet(), emptySet(), emptyList(), false)
        assertEquals(listOf("aaaaaaaaaaa"), v.allowed)
        assertEquals(listOf("bbbbbbbbbbb", "ccccccccccc", "ddddddddddd"), v.denied)
    }

    @Test fun judge_withApi_trustedChannelSkipsTheCategory() {
        val cards = listOf(card("aaaaaaaaaaa"))
        val details = mapOf("aaaaaaaaaaa" to video("aaaaaaaaaaa", category = "24", channelId = "UC9"))
        val v = StudyWeb.judge(cards, details, true, setOf("UC9"), emptySet(), emptyList(), false)
        assertEquals(listOf("aaaaaaaaaaa"), v.allowed)
    }

    @Test fun judge_withoutApi_usesTheLooseRules() {
        val cards = listOf(card("aaaaaaaaaaa"), card("bbbbbbbbbbb", title = "Funny prank video"))
        val v = StudyWeb.judge(cards, emptyMap(), false, emptySet(), emptySet(), emptyList(), false)
        assertEquals(listOf("aaaaaaaaaaa"), v.allowed)
        assertEquals(listOf("bbbbbbbbbbb"), v.denied)
    }

    // ---- playing a video the API never described ----

    @Test fun minimalVideo_hasWhatThePageShowed() {
        val v = StudyWeb.minimalVideo("abcdefghijk", "Quadratic equations", "12:34")
        assertEquals("abcdefghijk", v.id)
        assertEquals(754, v.seconds)
        assertTrue(v.embeddable)
        assertEquals("", v.channelId)
        assertEquals("Study video", StudyWeb.minimalVideo("abcdefghijk", " ", "").title)
    }
}
