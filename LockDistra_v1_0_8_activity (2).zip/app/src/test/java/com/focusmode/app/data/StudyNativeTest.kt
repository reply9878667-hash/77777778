package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class StudyNativeTest {

    private fun page(data: String) =
        "<html><script>var ytInitialData = $data;</script><script>var other = {\"a\":1};</script></html>"

    private val classic = """
        {"contents":{"twoColumnSearchResultsRenderer":{"primaryContents":{"sectionListRenderer":{"contents":[{"itemSectionRenderer":{"contents":[
          {"videoRenderer":{"videoId":"abcdefghijk","title":{"runs":[{"text":"Metals and Non-metals | Class 10 {Science}"}]},
            "lengthText":{"simpleText":"32:10"},
            "ownerText":{"runs":[{"text":"Study Guru","navigationEndpoint":{"browseEndpoint":{"browseId":"UC1234567890123456789012"}}}]},
            "viewCountText":{"simpleText":"1.2M views"},"publishedTimeText":{"simpleText":"2 years ago"}}},
          {"videoRenderer":{"videoId":"live1234567","title":{"runs":[{"text":"Live class"}]},
            "ownerText":{"runs":[{"text":"Someone"}]}}},
          {"reelShelfRenderer":{"items":[{"reelItemRenderer":{"videoId":"shortsvid01"}}]}},
          {"videoRenderer":{"videoId":"abcdefghijk","title":{"runs":[{"text":"duplicate"}]},"lengthText":{"simpleText":"1:00"}}}
        ]}}]}}}}}
    """.trimIndent()

    private val lockup = """
        {"contents":[{"lockupViewModel":{"contentType":"LOCKUP_CONTENT_TYPE_VIDEO","contentId":"lockupvid01",
          "contentImage":{"thumbnailViewModel":{"overlays":[{"thumbnailBottomOverlayViewModel":{"badges":[{"thumbnailBadgeViewModel":{"text":"1:02:03"}}]}}]}},
          "metadata":{"lockupMetadataViewModel":{"title":{"content":"Chemical reactions class 10"},
            "metadata":{"contentMetadataViewModel":{"metadataRows":[{"metadataParts":[{"text":{"content":"Chem Channel"}}]},
              {"metadataParts":[{"text":{"content":"10K views"}},{"text":{"content":"1 year ago"}}]}]}}}}}},
          {"lockupViewModel":{"contentType":"LOCKUP_CONTENT_TYPE_PLAYLIST","contentId":"playlist001"}}]}
    """.trimIndent()

    @Test fun extractInitialData_ignoresBracesInsideStrings() {
        val data = StudyNative.extractInitialData(page(classic))
        assertNotNull(data)
        assertTrue(data!!.has("contents"))
    }

    @Test fun extractInitialData_nullWhenMissing() {
        assertNull(StudyNative.extractInitialData("<html>nothing</html>"))
    }

    @Test fun parseHtml_readsClassicRenderers() {
        val list = StudyNative.parseHtml(page(classic))
        assertEquals(listOf("abcdefghijk", "live1234567"), list.map { it.id })
        val first = list[0]
        assertEquals("Metals and Non-metals | Class 10 {Science}", first.title)
        assertEquals("32:10", first.durationLabel)
        assertEquals("Study Guru", first.channelTitle)
        assertEquals("UC1234567890123456789012", first.channelId)
        assertTrue(first.extra.contains("1.2M views"))
        assertEquals("", list[1].durationLabel) // a live stream has no length
    }

    @Test fun parseHtml_readsLockupViewModels() {
        val list = StudyNative.parseHtml(page(lockup))
        assertEquals(1, list.size)
        assertEquals("lockupvid01", list[0].id)
        assertEquals("Chemical reactions class 10", list[0].title)
        assertEquals("1:02:03", list[0].durationLabel)
        assertEquals("Chem Channel", list[0].channelTitle)
    }

    @Test(expected = NoDataException::class)
    fun parseHtml_unknownPage_throws() {
        StudyNative.parseHtml("<html>please sign in</html>")
    }

    @Test fun card_feedsTheNormalWebFilter() {
        val r = StudyNative.parseHtml(page(classic))[0]
        val v = StudyWeb.judge(listOf(r.card), emptyMap(), false, emptySet(), emptySet(), emptyList(), true, "metal and nonmetals")
        assertEquals(listOf("abcdefghijk"), v.allowed)
    }

    @Test fun searchUrl_isVideosOnly_andBiased() {
        val u = StudyNative.searchUrl("newton")
        assertTrue(u.startsWith("https://www.youtube.com/results?search_query=newton+lecture+explained"))
        assertTrue(u.contains("&sp=EgIQAQ%253D%253D"))
    }

    // ---- API error reading ----

    @Test fun quotaIsDaily_butBusyIsShort() {
        val daily = StudyRules.parseError(403, """{"error":{"errors":[{"reason":"quotaExceeded"}]}}""")
        assertEquals(StudyErrorKind.QUOTA, daily.kind); assertTrue(daily.dailyLimit)
        val busy = StudyRules.parseError(403, """{"error":{"errors":[{"reason":"rateLimitExceeded"}]}}""")
        assertEquals(StudyErrorKind.QUOTA, busy.kind); assertFalse(busy.dailyLimit)
        val tooMany = StudyRules.parseError(429, "")
        assertEquals(StudyErrorKind.QUOTA, tooMany.kind); assertFalse(tooMany.dailyLimit)
    }

    @Test fun newStyleKeyErrors_areKeyProblems() {
        val blocked = StudyRules.parseError(403, """{"error":{"code":403,"status":"PERMISSION_DENIED","details":[{"reason":"API_KEY_ANDROID_APP_BLOCKED"}]}}""")
        assertEquals(StudyErrorKind.BAD_KEY, blocked.kind)
        assertEquals(StudyErrorKind.BAD_KEY, StudyRules.parseError(400, """{"error":{"details":[{"reason":"API_KEY_INVALID"}]}}""").kind)
        assertEquals(StudyErrorKind.OTHER, StudyRules.parseError(503, "").kind)
    }

    // ---- source indicator ----

    @Test fun monitor_followsTheSourceThatDelivered() {
        StudyMonitor.report(StudyMode.API)
        StudyMonitor.sync(apiAvailable = false)
        assertEquals(StudyMode.PAGE, StudyMonitor.mode.value)   // API resting -> page data
        StudyMonitor.report(StudyMode.WEB)
        StudyMonitor.sync(apiAvailable = false)
        assertEquals(StudyMode.WEB, StudyMonitor.mode.value)    // a WebView state is not overwritten by a guess
        StudyMonitor.sync(apiAvailable = true)
        assertEquals(StudyMode.API, StudyMonitor.mode.value)    // API ready again -> normal colour
    }

    // ---- channel pictures read from the page data ---------------------------------------------------------------------

    @Test fun parseHtml_readsChannelPicture_classic() {
        val data = """
            {"contents":[{"videoRenderer":{"videoId":"abcdefghijk","title":{"runs":[{"text":"Lesson"}]},"lengthText":{"simpleText":"10:00"},
              "ownerText":{"runs":[{"text":"Study Guru","navigationEndpoint":{"browseEndpoint":{"browseId":"UC1234567890123456789012"}}}]},
              "channelThumbnailSupportedRenderers":{"channelThumbnailWithLinkRenderer":{"thumbnail":{"thumbnails":[{"url":"//yt3.ggpht.com/a=s68","width":68}]}}}}}]}
        """.trimIndent()
        val r = StudyNative.parseHtml(page(data)).single()
        assertEquals("https://yt3.ggpht.com/a=s68", r.avatarUrl)
    }

    @Test fun parseHtml_readsChannelPicture_lockup() {
        val data = """
            {"contents":[{"lockupViewModel":{"contentType":"LOCKUP_CONTENT_TYPE_VIDEO","contentId":"lockupvid01",
              "contentImage":{"thumbnailViewModel":{"overlays":[{"thumbnailBottomOverlayViewModel":{"badges":[{"thumbnailBadgeViewModel":{"text":"5:00"}}]}}]}},
              "metadata":{"lockupMetadataViewModel":{"title":{"content":"Chemical reactions"},
                "image":{"decoratedAvatarViewModel":{"avatar":{"avatarViewModel":{"image":{"sources":[{"url":"https://yt3.ggpht.com/b=s68"}]}}}}},
                "metadata":{"contentMetadataViewModel":{"metadataRows":[{"metadataParts":[{"text":{"content":"Chem Channel"}}]}]}}}}}}]}
        """.trimIndent()
        val r = StudyNative.parseHtml(page(data)).single()
        assertEquals("https://yt3.ggpht.com/b=s68", r.avatarUrl)
    }

    @Test fun parseHtml_noChannelPicture_isEmptyNotAnError() {
        val r = StudyNative.parseHtml(page(classic)).first()
        assertEquals("", r.avatarUrl)
    }

    @Test fun result_publishedAt_comesFromTheAgoLabel() {
        val r = StudyNative.parseHtml(page(classic)).first()
        assertTrue(r.publishedAt > 0L)
        val none = StudyNative.parseHtml(page(classic)).first { it.id == "live1234567" }
        assertEquals(0L, none.publishedAt)
    }

    @Test fun parseWatchInfo_readsFullDescriptionAndUploadTime() {
        val html = "<html><script>var ytInitialPlayerResponse = " +
            "{\"videoDetails\":{\"shortDescription\":\"Notes {chapter 1}\\n0:00 Intro\\n5:10 Laws\"}," +
            "\"microformat\":{\"playerMicroformatRenderer\":{\"publishDate\":\"2024-05-01T10:20:30-07:00\"}}};</script></html>"
        val info = StudyNative.parseWatchInfo(html)!!
        assertTrue(info.description.contains("5:10 Laws"))
        assertTrue(info.description.startsWith("Notes {chapter 1}"))
        assertTrue(info.publishedAt > 0L)
    }

    @Test fun parseWatchInfo_nothingReadable_isNull() {
        assertNull(StudyNative.parseWatchInfo("<html>consent page</html>"))
    }
}
