package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingQuestionsTest {

    private val qs = OnboardingQuestions.all
    private fun q(id: String) = qs.first { it.id == id }

    @Test
    fun thereAreSevenQuestionsInTheAgreedOrder() {
        assertEquals(7, OnboardingQuestions.count)
        assertEquals(
            listOf("name", "goal", "distractions", "phone_time", "session_length", "daily_goal", "source"),
            qs.map { it.id }
        )
        assertEquals(qs.size, qs.map { it.id }.toSet().size)
    }

    @Test
    fun optionCountsAndTypesMatchTheSpec() {
        assertEquals(QuestionType.Text, q("name").type)
        assertEquals(emptyList<OnboardingOption>(), q("name").options)
        listOf("goal", "distractions", "phone_time", "session_length", "daily_goal", "source")
            .forEach { assertEquals(it, 6, q(it).options.size) }
        // Only question 3 allows several answers.
        assertEquals(listOf("distractions"), qs.filter { it.type == QuestionType.MultiChoice }.map { it.id })
        // Option ids are unique inside a question.
        qs.forEach { assertEquals(it.id, it.options.size, it.options.map { o -> o.id }.toSet().size) }
    }

    @Test
    fun onlyTheLastQuestionIsOptional() {
        assertEquals(listOf("source"), qs.filter { it.optional }.map { it.id })
    }

    @Test
    fun nextIsBlockedUntilARequiredQuestionIsAnswered() {
        val empty = OnboardingAnswers()
        qs.filter { !it.optional }.forEach { assertFalse(it.id, empty.canContinue(it)) }
        assertTrue(empty.canContinue(q("source"))) // question 7 can be skipped
    }

    @Test
    fun aBlankNameDoesNotCount() {
        val name = q("name")
        assertFalse(OnboardingAnswers().withText("name", "   ").canContinue(name))
        assertTrue(OnboardingAnswers().withText("name", " Sam ").canContinue(name))
        assertEquals("Sam", OnboardingAnswers().withText("name", " Sam ").name)
    }

    @Test
    fun nameIsCappedAndCleaned() {
        val long = "a".repeat(100)
        assertEquals(OnboardingQuestions.NAME_MAX_LENGTH, OnboardingAnswers().withText("name", long).text("name").length)
        assertEquals("AB", OnboardingAnswers().withText("name", "A\u0001B\n").text("name"))
    }

    @Test
    fun singleChoiceReplacesTheOldAnswer() {
        val a = OnboardingAnswers().withSingle("goal", "study_better").withSingle("goal", "focus_on_work")
        assertEquals(listOf("focus_on_work"), a.selected("goal"))
        assertEquals("focus_on_work", a.goal)
        assertTrue(a.canContinue(q("goal")))
    }

    @Test
    fun multiChoiceTogglesAndMayBecomeEmptyAgain() {
        var a = OnboardingAnswers().withToggled("distractions", "gaming").withToggled("distractions", "social_media")
        assertEquals(listOf("gaming", "social_media"), a.distractions)
        a = a.withToggled("distractions", "gaming")
        assertEquals(listOf("social_media"), a.distractions)
        a = a.withToggled("distractions", "social_media")
        assertTrue(a.distractions.isEmpty())
        assertFalse(a.canContinue(q("distractions")))
    }

    @Test
    fun skippedOptionalQuestionReadsAsNull() {
        assertNull(OnboardingAnswers().source)
        assertEquals("youtube", OnboardingAnswers().withSingle("source", "youtube").source)
    }

    @Test
    fun answersSurviveTheSavedStateRoundTrip() {
        val a = OnboardingAnswers()
            .withText("name", "Ayşe \uD83D\uDC4B")
            .withSingle("goal", "all_of_these")
            .withToggled("distractions", "gaming")
            .withToggled("distractions", "messaging_apps")
            .withSingle("phone_time", "2_4h")
            .withSingle("session_length", "min_25")
            .withSingle("daily_goal", "custom")
        assertEquals(a, OnboardingAnswers.decode(a.encode()))
        assertEquals(OnboardingAnswers(), OnboardingAnswers.decode(emptyList()))
        assertEquals(OnboardingAnswers(), OnboardingAnswers.decode(listOf("", "goal", "goal\u0001")))
    }
    @Test
    fun customDailyGoalNeedsAValidNumberOfMinutes() {
        val goal = q("daily_goal")
        val custom = OnboardingAnswers().withSingle("daily_goal", "custom")
        assertFalse(custom.canContinue(goal))                                   // no number yet
        assertFalse(custom.withCustomGoalText("5").canContinue(goal))           // below the minimum
        assertFalse(custom.withCustomGoalText("5000").canContinue(goal))        // above the maximum
        assertTrue(custom.withCustomGoalText("90").canContinue(goal))
        assertEquals(90, custom.withCustomGoalText("90").dailyGoalMinutes)
        assertEquals("12", custom.withCustomGoalText("1a2").customGoalText)     // digits only
        // another choice ignores a typed number
        val other = custom.withCustomGoalText("90").withSingle("daily_goal", "h_2")
        assertTrue(other.canContinue(goal))
        assertEquals(null, other.dailyGoalMinutes)
    }

    @Test
    fun customMinutesSurviveTheSavedStateRoundTrip() {
        val a = OnboardingAnswers().withSingle("daily_goal", "custom").withCustomGoalText("75")
        assertEquals(a, OnboardingAnswers.decode(a.encode()))
        assertEquals(75, OnboardingAnswers.decode(a.encode()).dailyGoalMinutes)
        assertTrue(OnboardingAnswers().isEmpty)
        assertFalse(a.isEmpty)
    }
}
