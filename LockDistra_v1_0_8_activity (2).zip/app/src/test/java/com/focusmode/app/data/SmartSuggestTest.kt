package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartSuggestTest {
    private val now = 1_000_000_000_000L
    private fun state(opens: Int) = SuggestState(opens = opens)

    @Test fun nothingBeforeTheSecondOpening() {
        assertNull(SmartSuggest.pick(state(1), emptySet(), now))
        assertNotNull(SmartSuggest.pick(state(2), emptySet(), now))
    }

    @Test fun featuresInUseAreNotSuggested() {
        val all = SmartSuggest.features.map { it.id }.toSet()
        assertNull(SmartSuggest.pick(state(5), all, now))
        val f = SmartSuggest.pick(state(5), all - SmartSuggest.BEDTIME, now)
        assertEquals(SmartSuggest.BEDTIME, f?.id)
    }

    @Test fun usedEverIsNeverSuggested() {
        var s = SmartSuggest.withUsed(state(5), SmartSuggest.LECTURE)
        assertTrue(SmartSuggest.pick(s, emptySet(), now)?.id != SmartSuggest.LECTURE)
    }

    @Test fun oneAtATimeWithCooldown() {
        val s = SmartSuggest.withShown(state(3), SmartSuggest.LECTURE, now)
        assertNull(SmartSuggest.pick(s, emptySet(), now + 1000))
        assertNotNull(SmartSuggest.pick(s, emptySet(), now + SmartSuggest.COOLDOWN_MS))
    }

    @Test fun notRepeatedAtOnceAndAtMostTwice() {
        val first = SmartSuggest.features.first().id
        val others = SmartSuggest.features.drop(1).map { it.id }.toSet()
        var s = SmartSuggest.withShown(state(2), first, now)
        val later = now + SmartSuggest.COOLDOWN_MS
        // One opening later: not again.
        assertNull(SmartSuggest.pick(s.copy(opens = 3), others, later))
        // Enough openings later: once more.
        assertEquals(first, SmartSuggest.pick(s.copy(opens = 2 + SmartSuggest.OPENS_BETWEEN), others, later)?.id)
        // After the second time: never again.
        s = SmartSuggest.withShown(s.copy(opens = 5), first, now)
        assertNull(SmartSuggest.pick(s.copy(opens = 50), others, later + SmartSuggest.COOLDOWN_MS))
    }

    @Test fun dismissedForGoodAndSwitchedOff() {
        val first = SmartSuggest.features.first().id
        val others = SmartSuggest.features.drop(1).map { it.id }.toSet()
        val s = SmartSuggest.withDismissed(state(10), first)
        assertNull(SmartSuggest.pick(s, others, now))
        assertNull(SmartSuggest.pick(state(10).copy(enabled = false), emptySet(), now))
    }

    @Test fun everySuggestionHasAllParts() {
        for (f in SmartSuggest.features) {
            assertTrue(f.id, f.title.isNotBlank() && f.what.isNotBlank() && f.benefits.size >= 2 && f.actionLabel.isNotBlank())
        }
    }
}
