package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FocusProfileRuntimeTest {

    private fun profile(slot: Int, settings: FocusProfileSettings) = FocusProfile(slot, "P$slot", 1L, 1L, settings)

    private val work = profile(
        1,
        FocusProfileSettings(
            blocked = setOf("com.game", "com.social"),
            blockShorts = true,
            features = setOf(FeatureCatalog.IG_REELS, "no_such_feature"),
            websites = WebsiteState(
                enabledApps = setOf(FeatureCatalog.YOUTUBE),
                rules = mapOf(FeatureCatalog.YOUTUBE to listOf(WebsiteRule("youtube.com", enabled = true, subdomains = true))),
            ),
            limits = listOf(AppLimit("com.social", 20, 5)),
        ),
    )
    private val study = profile(2, FocusProfileSettings(blocked = setOf("com.video")))
    private val both = FocusProfilesState(listOf(work, study), selectedSlot = 1)

    private val globalFocus = FocusState(focusActive = true, blocked = setOf("com.global"), blockShorts = false)
    private val idle = FocusState(focusActive = false, blocked = setOf("com.global"))

    @Test fun focusOnUsesOnlyTheSelectedProfile() {
        val p = FocusProfileRuntime.active(globalFocus, both)
        assertEquals(1, p?.slot)
        assertEquals(setOf("com.game", "com.social"), FocusProfileRuntime.blocked(globalFocus, p))
        assertTrue(FocusProfileRuntime.blockShorts(globalFocus, p))
    }

    @Test fun otherProfileIsNeverCombined() {
        val p = FocusProfileRuntime.active(globalFocus, both)
        assertFalse("com.video" in FocusProfileRuntime.blocked(globalFocus, p))
        assertFalse("com.global" in FocusProfileRuntime.blocked(globalFocus, p))
    }

    @Test fun switchingTheSelectionSwitchesTheSettings() {
        val p = FocusProfileRuntime.active(globalFocus, both.copy(selectedSlot = 2))
        assertEquals(setOf("com.video"), FocusProfileRuntime.blocked(globalFocus, p))
        assertFalse(FocusProfileRuntime.blockShorts(globalFocus, p))
    }

    @Test fun noSessionOrBreakMeansNoProfile() {
        // A Pomodoro Break is "no session": nothing of the profile applies, so restrictions are suspended.
        assertNull(FocusProfileRuntime.active(idle, both))
        assertEquals(setOf("com.global"), FocusProfileRuntime.blocked(idle, null))
        // And the same profile is back as soon as the next Focus round starts a session.
        assertEquals(1, FocusProfileRuntime.active(globalFocus, both)?.slot)
    }

    @Test fun missingOrDeletedSelectionFallsBackToTheNormalFocusSettings() {
        for (state in listOf(FocusProfilesState(), FocusProfilesState(listOf(work), selectedSlot = 0), FocusProfilesState(listOf(work), selectedSlot = 2))) {
            val p = FocusProfileRuntime.active(globalFocus, state)
            assertNull(p)
            assertEquals(setOf("com.global"), FocusProfileRuntime.blocked(globalFocus, p))
            assertFalse(FocusProfileRuntime.blockShorts(globalFocus, p))
        }
    }

    @Test fun profileSectionsReplaceTheGlobalOnes() {
        val global = ContentState(enabledFeatures = setOf(FeatureCatalog.YT_HOME), autoDetect = true)
        val c = FocusProfileRuntime.content(global, work)
        assertEquals(setOf(FeatureCatalog.IG_REELS), c.enabledFeatures)   // unknown ids dropped, global one not combined
        assertTrue(c.autoDetect)                                          // Shorts exceptions are not blocks: kept
        assertEquals(global, FocusProfileRuntime.content(global, null))
    }

    @Test fun limitIsTheStricterOfNormalAndProfile() {
        val normal = AppLimit("com.social", 60, 10)
        assertEquals(20, FocusProfileRuntime.limitFor(normal, work, "com.social")?.limitMin)
        assertEquals(15, FocusProfileRuntime.limitFor(normal.copy(limitMin = 15), work, "com.social")?.limitMin)
        assertEquals(normal, FocusProfileRuntime.limitFor(normal, work, "com.other"))
        assertEquals(normal, FocusProfileRuntime.limitFor(normal, null, "com.social"))
        assertNull(FocusProfileRuntime.limitFor(null, null, "com.social"))
        assertEquals(AppLimit("com.social", 20, 5), FocusProfileRuntime.limitFor(null, work, "com.social"))
    }

    @Test fun profileLimitsAreCountedOnlyWithTheProfile() {
        assertEquals(setOf("com.a", "com.social"), FocusProfileRuntime.limitedPackages(listOf("com.a"), work))
        assertEquals(setOf("com.a"), FocusProfileRuntime.limitedPackages(listOf("com.a"), null))
        assertTrue(FocusProfileRuntime.hasProfileLimits(work))
        assertFalse(FocusProfileRuntime.hasProfileLimits(study))
        assertFalse(FocusProfileRuntime.hasProfileLimits(null))
    }

    private val globalSites = WebsiteState(
        enabledApps = setOf(FeatureCatalog.INSTAGRAM),
        rules = mapOf(FeatureCatalog.INSTAGRAM to listOf(WebsiteRule("instagram.com", enabled = true, subdomains = true))),
    )

    @Test fun withoutProfileTheGlobalWebsiteRulesBehaveAsBefore() {
        val rules = FocusProfileRuntime.websiteRules(globalSites, null, true, { false }, { false }, { false })
        assertEquals(1, rules.size)
        assertEquals("instagram.com", FocusProfileRuntime.firstMatch(rules, "instagram.com")?.second?.domain)
        // No session and no used-up limit: nothing is enforced.
        assertTrue(FocusProfileRuntime.websiteRules(globalSites, null, false, { false }, { false }, { false }).isEmpty())
    }

    @Test fun withProfileOnlyItsSitesBlockDuringTheSession() {
        val rules = FocusProfileRuntime.websiteRules(globalSites, work, true, { false }, { false }, { false })
        assertEquals("youtube.com", FocusProfileRuntime.firstMatch(rules, "m.youtube.com")?.second?.domain)
        assertNull(FocusProfileRuntime.firstMatch(rules, "instagram.com"))   // global site rule needs its own limit now
    }

    @Test fun globalSiteRuleStillFollowsItsUsedUpLimitDuringAProfileSession() {
        val rules = FocusProfileRuntime.websiteRules(globalSites, work, true, { false }, { it == FeatureCatalog.INSTAGRAM }, { false })
        assertEquals(FeatureCatalog.INSTAGRAM, FocusProfileRuntime.firstMatch(rules, "instagram.com")?.first)
    }

    @Test fun emergencyOrExtraTimeOpensASite() {
        assertTrue(FocusProfileRuntime.websiteRules(globalSites, work, true, { true }, { false }, { false }).isEmpty())
        assertTrue(FocusProfileRuntime.websiteRules(globalSites, work, true, { false }, { false }, { true }).isEmpty())
    }
}
