package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class StudyBlocklistTest {

    private fun blocked(q: String) = StudyBlocklist.blockedSearch(q) != null

    @Test fun comedy_andEntertainment_areBlocked() {
        listOf("comedy", "funny videos", "Carry Minati roast", "bhuvan bam", "pubg gameplay", "new songs", "full movie", "bigg boss",
            "ipl highlights", "meme", "prank video", "cartoon", "vlog", "bhojpuri gana", "कॉमेडी", "गाना", "सट्टा matka")
            .forEach { assertTrue("should block: $it", blocked(it)) }
    }

    @Test fun adult_isBlocked_evenWithSpellingTricks() {
        listOf("porn", "p0rn", "pornnnn", "s e x", "sexy video", "xxx", "nsfw", "hot video", "सेक्स", "chudai", "naked girl")
            .forEach { assertTrue("should block: $it", blocked(it)) }
    }

    @Test fun adult_hitsAreReportedAsAdult() {
        assertEquals(StudyBlocklist.Kind.ADULT, StudyBlocklist.blockedSearch("xxx videos")?.kind)
        assertEquals(StudyBlocklist.Kind.DISTRACTION, StudyBlocklist.blockedSearch("funny memes")?.kind)
    }

    @Test fun studySearches_areNotBlocked() {
        listOf("ohm's law class 10", "quadratic equations", "photosynthesis", "ncert maths chapter 3", "sigma notation", "mod function",
            "triple integral", "essex county history", "class 12 physics", "organic chemistry", "इतिहास कक्षा 9")
            .forEach { assertFalse("should NOT block: $it", blocked(it)) }
    }

    @Test fun studyPhrases_thatLookRisky_areAllowed() {
        listOf("sex education class 12", "human reproduction", "game theory", "classical dance forms of india", "physics of cricket",
            "naked eye astronomy", "adult education", "how to crack neet", "ethical hacking course", "music theory")
            .forEach { assertFalse("should NOT block: $it", blocked(it)) }
    }

    @Test fun wholeWordsOnly_soStudyWordsAreSafe() {
        assertFalse(blocked("classic"))      // "ass"
        assertFalse(blocked("pass percentage"))
        assertFalse(blocked("triple"))       // "ipl"
        assertFalse(blocked("assam geography"))
        assertFalse(blocked("scunthorpe"))
    }

    @Test fun emptyAndBlank_areNotBlocked() {
        assertFalse(blocked(""))
        assertFalse(blocked("   "))
    }

    @Test fun rulesUseTheSameLists() {
        assertFalse(StudyRules.suggestionAllowed("funny videos"))
        assertFalse(StudyRules.suggestionAllowed("bollywood songs"))
        assertTrue(StudyRules.suggestionAllowed("ohm's law class 10"))
        assertTrue(StudyRules.hasNeverWord("xxx class"))
        assertTrue(StudyRules.hasDistractionWord("Best comedy scenes"))
    }

    @Test fun noticeText_isThere() {
        assertTrue(StudyBlocklist.NOTICE_TITLE.contains("educational"))
        assertTrue(StudyBlocklist.NOTICE_BODY.isNotBlank())
    }

    @Test fun webSearch_addsLessonWords_onlyWhenTheQueryHasNone() {
        assertEquals("newton lecture explained", StudyWeb.biasedQuery("newton"))
        assertEquals("ohm's law class 10", StudyWeb.biasedQuery("ohm's law class 10"))
        assertEquals("maths", StudyWeb.biasedQuery("maths"))
        assertEquals("", StudyWeb.biasedQuery("  "))
    }

    @Test fun webSearch_studyQuery_needsTheTitleToMatchTheSearch() {
        val c = WebCard("abcdefghijk", "Teacher vs student", "Random Channel • 3M views", "10:00")
        assertFalse(StudyWeb.looseAccept(c, true, emptyList(), "maths"))
        val ok = WebCard("abcdefghijk", "Newton and the apple", "Some Channel • 10K views", "10:00")
        assertTrue(StudyWeb.looseAccept(ok, true, emptyList(), "newton laws"))
    }

    @Test fun lessonTitles_withRiskyLookingWords_areNotHeldBack() {
        listOf("Sexual reproduction in flowering plants | Class 12 Biology", "Chemical reactions and equations | Class 10",
            "Dating of fossils | Biology", "Game development with Unity", "Highlights of the chapter: Light", "Playlist: Complete Class 10 Science",
            "Naked eye observations of the Moon", "Birthday paradox | Probability", "Redox reactions explained")
            .forEach {
                assertFalse("title must pass: $it", StudyRules.hasNeverWord(it))
                assertFalse("title must pass: $it", StudyRules.hasDistractionWord(it))
            }
        assertFalse(blocked("chemical reactions and equations"))
        assertFalse(blocked("redox reactions"))
    }

    @Test fun adultWord_nextToAStudyPhrase_isStillCaught() {
        assertTrue(blocked("porn sex education"))
        assertTrue(StudyRules.hasNeverWord("xxx sexual reproduction"))
    }
}
