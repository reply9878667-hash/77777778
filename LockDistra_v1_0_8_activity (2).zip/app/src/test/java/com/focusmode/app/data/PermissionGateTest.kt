package com.focusmode.app.data

import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.service.RequiredPermission
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PermissionGateTest {

    private fun route(
        signedIn: Boolean = true,
        onboardingDone: Boolean = true,
        authRequired: Boolean = true,
        ownOnboardingRequired: Boolean = false,
        holdAuth: Boolean = false,
        wantsLogin: Boolean = false,
        permissionsGranted: Boolean,
    ) = AppEntryRules.route(
        signedIn, onboardingDone, authRequired, ownOnboardingRequired, holdAuth, wantsLogin, permissionsGranted,
    )

    private val allOn = PermissionStatus(
        accessibility = true, usageAccess = true, notifications = true, batteryUnrestricted = true, exactAlarms = true,
    )

    // ---- Routing ----------------------------------------------------------------------------------------------

    @Test fun homeOpensOnlyWhenEveryPermissionIsAllowed() {
        assertEquals(EntryRoute.Permissions, route(permissionsGranted = false))
        assertEquals(EntryRoute.Home, route(permissionsGranted = true))
    }

    @Test fun permissionsComeAfterTheAccountWelcomeScreen() {
        // The "Welcome" confirmation after sign-up / login stays first; Permissions follows its Continue button.
        assertEquals(EntryRoute.Auth, route(holdAuth = true, permissionsGranted = false))
        assertEquals(EntryRoute.Permissions, route(holdAuth = false, permissionsGranted = false))
    }

    @Test fun aNewAccountsOwnQuestionsComeBeforePermissions() {
        assertEquals(EntryRoute.Onboarding, route(ownOnboardingRequired = true, permissionsGranted = false))
    }

    @Test fun loggedOutPersonSeesTheAccountScreenNotPermissions() {
        assertEquals(EntryRoute.Auth, route(signedIn = false, permissionsGranted = false))
        assertEquals(EntryRoute.Onboarding, route(signedIn = false, onboardingDone = false, permissionsGranted = false))
    }

    @Test fun withoutAccountsInThisBuildPermissionsStillGuardHome() {
        assertEquals(EntryRoute.Permissions, route(signedIn = false, authRequired = false, permissionsGranted = false))
        assertEquals(EntryRoute.Home, route(signedIn = false, authRequired = false, permissionsGranted = true))
        assertEquals(EntryRoute.Onboarding, route(signedIn = false, onboardingDone = false, authRequired = false, permissionsGranted = false))
    }

    @Test fun aPermissionSwitchedOffLaterClosesHomeAndAllowingItReopensIt() {
        assertEquals(EntryRoute.Home, route(permissionsGranted = allOn.allRequiredGranted))
        val revoked = allOn.copy(accessibility = false)
        assertEquals(EntryRoute.Permissions, route(permissionsGranted = revoked.allRequiredGranted))
        assertEquals(EntryRoute.Home, route(permissionsGranted = revoked.copy(accessibility = true).allRequiredGranted))
    }

    @Test fun defaultKeepsTheOldBehaviour() {
        assertEquals(EntryRoute.Home, AppEntryRules.route(true, true, true, false, false, false))
    }

    // ---- Required permission list -----------------------------------------------------------------------------

    @Test fun allAllowedMeansNothingMissing() {
        assertTrue(allOn.missingRequired().isEmpty())
        assertTrue(allOn.allRequiredGranted)
    }

    @Test fun nothingAllowedListsEveryRequiredPermission() {
        val none = PermissionStatus(exactAlarms = false)
        assertEquals(
            listOf(
                RequiredPermission.ACCESSIBILITY, RequiredPermission.USAGE_ACCESS, RequiredPermission.NOTIFICATIONS,
                RequiredPermission.BATTERY, RequiredPermission.EXACT_ALARMS,
            ),
            none.missingRequired(),
        )
        assertFalse(none.allRequiredGranted)
    }

    @Test fun eachPermissionAloneBlocksHome() {
        assertEquals(listOf(RequiredPermission.ACCESSIBILITY), allOn.copy(accessibility = false).missingRequired())
        assertEquals(listOf(RequiredPermission.USAGE_ACCESS), allOn.copy(usageAccess = false).missingRequired())
        assertEquals(listOf(RequiredPermission.NOTIFICATIONS), allOn.copy(notifications = false).missingRequired())
        assertEquals(listOf(RequiredPermission.BATTERY), allOn.copy(batteryUnrestricted = false).missingRequired())
        assertEquals(listOf(RequiredPermission.EXACT_ALARMS), allOn.copy(exactAlarms = false).missingRequired())
    }

    @Test fun deviceAdminIsOptionalAndNeverBlocksHome() {
        assertTrue(allOn.copy(deviceAdmin = false).allRequiredGranted)
    }

    @Test fun phonesBeforeAndroid12AreNeverAskedForExactAlarms() {
        // Permissions.read reports true there; the default of the field is true as well.
        assertTrue(PermissionStatus(true, true, true, false, true).allRequiredGranted)
    }

    // ---- Skip for now -----------------------------------------------------------------------------------------

    @Test fun permissionStepIsDoneWhenAllAllowedOrSkipped() {
        assertFalse(AppEntryRules.permissionStepDone(allRequiredGranted = false, skipped = false))
        assertTrue(AppEntryRules.permissionStepDone(allRequiredGranted = true, skipped = false))
        assertTrue(AppEntryRules.permissionStepDone(allRequiredGranted = false, skipped = true))
        assertTrue(AppEntryRules.permissionStepDone(allRequiredGranted = true, skipped = true))
    }

    @Test fun skippingOpensHomeEvenWithPermissionsMissing() {
        val missing = PermissionStatus(exactAlarms = false)
        assertEquals(EntryRoute.Permissions, route(permissionsGranted = AppEntryRules.permissionStepDone(missing.allRequiredGranted, skipped = false)))
        assertEquals(EntryRoute.Home, route(permissionsGranted = AppEntryRules.permissionStepDone(missing.allRequiredGranted, skipped = true)))
    }

    @Test fun skipDoesNotJumpTheAccountOrQuestionScreens() {
        val done = AppEntryRules.permissionStepDone(allRequiredGranted = false, skipped = true)
        assertEquals(EntryRoute.Auth, route(holdAuth = true, permissionsGranted = done))
        assertEquals(EntryRoute.Onboarding, route(ownOnboardingRequired = true, permissionsGranted = done))
    }
}
