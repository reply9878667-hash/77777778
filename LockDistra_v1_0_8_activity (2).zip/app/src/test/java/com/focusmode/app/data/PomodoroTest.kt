package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PomodoroTest {

    private fun breakState(endWall: Long, endElapsed: Long, boot: Int) = PomodoroState(
        phase = PomodoroPhase.BREAK, breakEndWall = endWall, breakEndElapsed = endElapsed, breakBoot = boot,
    )

    @Test fun defaultsAre25And5() {
        val s = PomodoroState()
        assertEquals(25, s.focusMin)
        assertEquals(5, s.breakMin)
        assertEquals(PomodoroPhase.IDLE, s.phase)
        assertFalse(s.active)
        assertFalse(s.running)
    }

    @Test fun activeAndRunningFollowPhaseAndPause() {
        val focus = PomodoroState(phase = PomodoroPhase.FOCUS, round = 1)
        assertTrue(focus.active && focus.running)
        val paused = focus.copy(paused = true)
        assertTrue(paused.active)
        assertFalse(paused.running)
    }

    @Test fun durationsAreClamped() {
        assertEquals(1, PomodoroRules.clampFocus(0))
        assertEquals(180, PomodoroRules.clampFocus(999))
        assertEquals(1, PomodoroRules.clampBreak(-5))
        assertEquals(60, PomodoroRules.clampBreak(500))
        assertEquals(25, PomodoroRules.clampFocus(25))
    }

    @Test fun durationsCanOnlyBeEditedWhileNoCycleExists() {
        assertTrue(PomodoroRules.canEditDurations(PomodoroState()))
        assertFalse(PomodoroRules.canEditDurations(PomodoroState(phase = PomodoroPhase.FOCUS)))
        assertFalse(PomodoroRules.canEditDurations(PomodoroState(phase = PomodoroPhase.BREAK, paused = true)))
    }

    @Test fun breakCountsDownOnBothClocks() {
        // Break of 5 min started at wall 1_000_000 / elapsed 50_000, same boot.
        val s = breakState(endWall = 1_300_000L, endElapsed = 350_000L, boot = 7)
        assertEquals(300_000L, PomodoroRules.breakLeftMs(s, 1_000_000L, 50_000L, 7))
        assertEquals(120_000L, PomodoroRules.breakLeftMs(s, 1_180_000L, 230_000L, 7))
        assertEquals(0L, PomodoroRules.breakLeftMs(s, 1_300_000L, 350_000L, 7))
        assertEquals(0L, PomodoroRules.breakLeftMs(s, 1_900_000L, 950_000L, 7))
    }

    @Test fun movingTheDateBackCannotStretchABreak() {
        val s = breakState(endWall = 1_300_000L, endElapsed = 350_000L, boot = 7)
        // Real time passed: 4 minutes. The user moved the date back one hour.
        val left = PomodoroRules.breakLeftMs(s, 1_000_000L + 240_000L - 3_600_000L, 290_000L, 7)
        assertEquals(60_000L, left)
    }

    @Test fun movingTheDateForwardEndsTheBreakEarlyAndNeverNegative() {
        val s = breakState(endWall = 1_300_000L, endElapsed = 350_000L, boot = 7)
        assertEquals(0L, PomodoroRules.breakLeftMs(s, 1_000_000L + 3_600_000L, 60_000L, 7))
    }

    @Test fun afterARestartOnlyTheWallClockIsUsed() {
        val s = breakState(endWall = 1_300_000L, endElapsed = 350_000L, boot = 7)
        // New boot (8): the monotonic clock restarted, so its value must be ignored.
        assertEquals(200_000L, PomodoroRules.breakLeftMs(s, 1_100_000L, 5_000L, 8))
        // Boot number unknown on this phone: wall clock only as well.
        val unknown = breakState(endWall = 1_300_000L, endElapsed = 350_000L, boot = -1)
        assertEquals(200_000L, PomodoroRules.breakLeftMs(unknown, 1_100_000L, 5_000L, -1))
    }

    @Test fun messagesUseTheChosenMinutes() {
        assertEquals(
            "Your 25-minute focus session is complete! Enjoy your 5-minute break. " +
                "All Focus restrictions are temporarily unlocked.",
            PomodoroRules.breakStartedText(25, 5)
        )
        assertEquals(
            "Your 5-minute break is over! Focus restrictions are now active again.",
            PomodoroRules.breakOverText(5)
        )
        assertTrue(PomodoroRules.breakStartedText(50, 10).contains("50-minute focus"))
        assertTrue(PomodoroRules.breakStartedText(50, 10).contains("10-minute break"))
    }

    @Test fun focusStartKeepsRememberedLengthAndResumesWithElapsedTime() {
        // FocusState math the resume path relies on: start = now - elapsed, end = now + left.
        val now = 10_000_000L
        val total = 25 * 60_000L
        val left = 9 * 60_000L
        val start = now - (total - left)
        val end = now + left
        assertEquals(total, end - start)
        assertEquals(left, end - now)
    }
}
