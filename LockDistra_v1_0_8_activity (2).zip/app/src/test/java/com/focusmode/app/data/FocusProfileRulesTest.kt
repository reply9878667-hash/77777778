package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FocusProfileRulesTest {

    private fun p(slot: Int, name: String = "P$slot") = FocusProfile(slot, name, 1L, 1L)

    @Test fun twoProfilesAtMost() {
        assertEquals(2, FocusProfileRules.MAX_PROFILES)
        assertEquals(listOf(1, 2), FocusProfileRules.SLOTS)
        assertTrue(FocusProfileRules.validSlot(1))
        assertTrue(FocusProfileRules.validSlot(2))
        assertFalse(FocusProfileRules.validSlot(0))
        assertFalse(FocusProfileRules.validSlot(3))
    }

    @Test fun defaultNames() {
        assertEquals("Profile #1", FocusProfileRules.defaultName(1))
        assertEquals("Profile #2", FocusProfileRules.defaultName(2))
    }

    @Test fun namesAreCleaned() {
        assertEquals("Deep work", FocusProfileRules.cleanName("   Deep    work  "))
        assertEquals(FocusProfileRules.MAX_NAME, FocusProfileRules.cleanName("x".repeat(80)).length)
    }

    @Test fun emptyNameIsAnError() {
        assertNotNull(FocusProfileRules.nameError(""))
        assertNotNull(FocusProfileRules.nameError("   "))
        assertNull(FocusProfileRules.nameError("Study"))
    }

    @Test fun stateLookups() {
        val s = FocusProfilesState(listOf(p(2)), selectedSlot = 2)
        assertTrue(s.hasAny)
        assertEquals("P2", s.selected?.name)
        assertNull(s.get(1))
        assertFalse(FocusProfilesState().hasAny)
        assertNull(FocusProfilesState().selected)
    }

    @Test fun deletingTheSelectedProfileMovesToTheOtherOrNone() {
        val both = FocusProfilesState(listOf(p(1), p(2)), selectedSlot = 1)
        assertEquals(2, FocusProfileRules.selectionAfterDelete(both, 1))
        assertEquals(1, FocusProfileRules.selectionAfterDelete(both, 2)) // other one deleted: selection stays
        val only = FocusProfilesState(listOf(p(1)), selectedSlot = 1)
        assertEquals(0, FocusProfileRules.selectionAfterDelete(only, 1))
    }
}
