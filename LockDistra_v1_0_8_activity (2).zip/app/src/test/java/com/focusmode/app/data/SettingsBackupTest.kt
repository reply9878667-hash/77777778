package com.focusmode.app.data

import java.util.Random
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SettingsBackupTest {

    private fun s(v: String) = JSONObject().put("t", "s").put("v", v)
    private fun b(v: Boolean) = JSONObject().put("t", "b").put("v", v)
    private fun i(v: Int) = JSONObject().put("t", "i").put("v", v)
    private fun ss(vararg v: String) = JSONObject().put("t", "ss").put("v", JSONArray(v.toList()))

    private fun backup(vararg files: Pair<String, JSONObject>, version: Int = 1): String {
        val f = JSONObject()
        for ((name, content) in files) f.put(name, content)
        return JSONObject().put("v", version).put("files", f).toString()
    }

    // ---- what is part of a backup ----

    @Test fun focusModeControlsAndAutoFocusAreCovered() {
        for (k in listOf("ctl_allow_turn_off", "ctl_allow_settings", "ctl_allow_emergency", "ctl_allow_app_changes", "ctl_allow_other_bypass")) {
            assertTrue(k, SettingsBackupRules.covers("focus_mode", k))
        }
        for (k in listOf("enabled", "start_min", "end_min", "days")) assertTrue(k, SettingsBackupRules.covers("auto_focus", k))
        assertTrue(SettingsBackupRules.covers("smart_suggest", "enabled"))
    }

    @Test fun mainSettingsAreCovered() {
        assertTrue(SettingsBackupRules.covers("focus_mode", "blocked_packages"))
        assertTrue(SettingsBackupRules.covers("usage_limits", "limits"))
        assertTrue(SettingsBackupRules.covers("usage_limits", "cat_limits"))
        assertTrue(SettingsBackupRules.covers("keyword_blocking", "rules"))
        assertTrue(SettingsBackupRules.covers("website_blocking", "rules"))
        assertTrue(SettingsBackupRules.covers("website_limits", "limits"))
        assertTrue(SettingsBackupRules.covers("bedtime", "start_min"))
        // Every Focus Profile slot, whatever its number.
        for (k in listOf("name_0", "blocked_3", "shorts_1", "features_2", "web_apps_0", "web_rules_4", "limits_2", "limit_emg_2", "selected")) {
            assertTrue(k, SettingsBackupRules.covers("focus_profiles", k))
        }
    }

    @Test fun secretsAndRunningStateAreNotCovered() {
        for (k in listOf("prevent_changes", "focus_off_method", "advanced_protection", "active", "emergency_until", "lecture_timed", "plant_growth")) {
            assertFalse(k, SettingsBackupRules.covers("focus_mode", k))
        }
        assertFalse(SettingsBackupRules.covers("usage_limits", "used_com.example"))
        assertFalse(SettingsBackupRules.covers("auto_focus", "last_handled_start"))
        for (file in listOf("app_lock", "app_lock_settings", "auth_session", "online_unlock", "daily_tasks", "lecture_lock", "intent_guard")) {
            assertFalse(file, SettingsBackupRules.covers(file, "enabled"))
        }
    }

    @Test fun onlyTheNameIsPersonal() {
        assertTrue(SettingsBackupRules.isPersonal("focus_mode", "user_name"))
        assertFalse(SettingsBackupRules.isPersonal("focus_mode", "blocked_packages"))
        assertFalse(SettingsBackupRules.isPersonal("auto_focus", "enabled"))
    }

    // ---- reading a backup text ----

    @Test fun knownFilesAndKeysAreRead() {
        val text = backup(
            "focus_mode" to JSONObject().put("blocked_packages", ss("a.b", "c.d")).put("ctl_allow_turn_off", b(false)),
            "auto_focus" to JSONObject().put("enabled", b(true)).put("start_min", i(1320)),
        )
        val parsed = SettingsBackupRules.parse(text)!!
        assertEquals(setOf("a.b", "c.d"), parsed["focus_mode"]!!["blocked_packages"])
        assertEquals(false, parsed["focus_mode"]!!["ctl_allow_turn_off"])
        assertEquals(1320, parsed["auto_focus"]!!["start_min"])
    }

    @Test fun unknownFilesAndKeysAreIgnored() {
        val text = backup(
            "app_lock" to JSONObject().put("hash", s("secret")),
            "focus_mode" to JSONObject().put("prevent_changes", b(true)).put("block_shorts", b(true)),
        )
        val parsed = SettingsBackupRules.parse(text)!!
        assertNull(parsed["app_lock"])
        assertEquals(setOf("block_shorts"), parsed["focus_mode"]!!.keys)
    }

    @Test fun aValueOfTheWrongTypeRefusesTheWholeBackup() {
        // "enabled" is a boolean in the app; a string there would crash the store that reads it.
        assertNull(SettingsBackupRules.parse(backup("auto_focus" to JSONObject().put("enabled", s("yes")))))
        assertNull(SettingsBackupRules.parse(backup("focus_profiles" to JSONObject().put("blocked_1", s("x")))))
        assertNull(SettingsBackupRules.parse(backup("bedtime" to JSONObject().put("start_min", b(true)))))
    }

    @Test fun notABackupIsRefused() {
        assertNull(SettingsBackupRules.parse("not json"))
        assertNull(SettingsBackupRules.parse("{}"))
        assertNull(SettingsBackupRules.parse(backup("focus_mode" to JSONObject(), version = 99)))
        assertNull(SettingsBackupRules.parse(backup("focus_mode" to JSONObject().put("block_shorts", JSONObject().put("t", "zz").put("v", 1)))))
    }

    @Test fun anEmptyFileIsKeptSoARestoreClearsWhatWasRemoved() {
        val parsed = SettingsBackupRules.parse(backup("website_blocking" to JSONObject()))!!
        assertNotNull(parsed["website_blocking"])
        assertTrue(parsed["website_blocking"]!!.isEmpty())
    }

    @Test fun aSharedCopyNeverTakesTheFriendsName() {
        val text = backup("focus_mode" to JSONObject().put("user_name", s("Riya")).put("block_shorts", b(true)))
        assertEquals("Riya", SettingsBackupRules.parse(text)!!["focus_mode"]!!["user_name"])
        val shared = SettingsBackupRules.parse(text, shared = true)!!
        assertEquals(setOf("block_shorts"), shared["focus_mode"]!!.keys)
    }

    // ---- share code ----

    @Test fun generatedCodesUseOnlyTheSafeAlphabet() {
        val random = Random(42)
        repeat(200) {
            val code = ShareCode.generate(random)
            assertEquals(ShareCode.LENGTH, code.length)
            assertTrue(code, code.all { it in ShareCode.ALPHABET })
            assertEquals(code, ShareCode.normalize(code))
        }
        for (ch in "ILO01") assertFalse(ch.toString(), ch in ShareCode.ALPHABET)
    }

    @Test fun codeIsShownInTwoGroups() {
        assertEquals("K7P2-9QXM", ShareCode.display("K7P29QXM"))
    }

    @Test fun typedCodeIsCleanedUp() {
        assertEquals("K7P29QXM", ShareCode.normalize("K7P2-9QXM"))
        assertEquals("K7P29QXM", ShareCode.normalize("  k7p2 9qxm \n"))
        assertEquals("K7P29QXM", ShareCode.normalize("k7p2_9qxm"))
    }

    @Test fun codeIsFoundInsideAPastedMessage() {
        val message = "My LockDistra settings code: K7P2-9QXM\nIn LockDistra open Settings > Backup > Paste your friend's code, enter it and press Apply."
        assertEquals("K7P29QXM", ShareCode.normalize(message))
    }

    @Test fun wrongCodesAreRefused() {
        assertNull(ShareCode.normalize(""))
        assertNull(ShareCode.normalize("K7P2-9QX"))
        assertNull(ShareCode.normalize("K7P2-9QXMA"))
        assertNull(ShareCode.normalize("K7P2-9QX0"))
        assertNull(ShareCode.normalize("hello friend"))
    }
}
