package com.focusmode.app.data

import com.focusmode.app.data.online.UnlockGateRules
import com.focusmode.app.data.online.UnlockMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** "Lock after N seconds" for every unlock method, and "Prevent changes". */
class ChangeLockTest {

    private val locked = FocusState(preventChanges = true, changesLocked = true)
    private val windowOpen = FocusState(preventChanges = true, changesLocked = false)
    private val plain = FocusState()

    // ---- Lock again after leaving the app (any unlock method) -----------------------------------

    @Test fun autoLockChoicesStartAtOnceAndGrow() {
        val c = LockRules.AUTO_LOCK_CHOICES
        assertEquals(0, c.first())
        assertEquals(c.sorted(), c)
        assertTrue(listOf(5, 10, 30, 60, 300).all { it in c })
    }

    @Test fun shortGracesRelockOnTime() {
        assertFalse(LockRules.shouldRelock(true, true, awayMs = 9_999, graceSeconds = 10, viaOwnLaunch = false))
        assertTrue(LockRules.shouldRelock(true, true, awayMs = 10_000, graceSeconds = 10, viaOwnLaunch = false))
        assertTrue(LockRules.shouldRelock(true, true, awayMs = 5_000, graceSeconds = 5, viaOwnLaunch = false))
    }

    @Test fun onlineApprovalAloneRelocksLikeThePassword() {
        // Online-only has no PIN, yet the gate is up, so the grace time decides just the same.
        val gate = UnlockGateRules.gateActive(UnlockMode.ONLINE, passwordLockSet = false)
        assertTrue(gate)
        assertTrue(LockRules.shouldRelock(gate, true, awayMs = 0, graceSeconds = 0, viaOwnLaunch = false))
        assertFalse(LockRules.shouldRelock(gate, true, awayMs = 20_000, graceSeconds = 30, viaOwnLaunch = false))
        assertTrue(LockRules.shouldRelock(gate, true, awayMs = 30_000, graceSeconds = 30, viaOwnLaunch = false))
    }

    // ---- The editing window ----------------------------------------------------------------------

    @Test fun windowIsOpenForFiveMinutesOnly() {
        val t0 = 100_000L
        assertTrue(ChangeWindowRules.isOpen(t0, t0))
        assertTrue(ChangeWindowRules.isOpen(t0, t0 + ChangeWindowRules.WINDOW_MS - 1))
        assertFalse(ChangeWindowRules.isOpen(t0, t0 + ChangeWindowRules.WINDOW_MS))
    }

    @Test fun graceWindowIsTenSecondsThenLocks() {
        val t0 = 100_000L
        assertEquals(10_000L, ChangeWindowRules.GRACE_MS)
        assertTrue(ChangeWindowRules.isGraceOpen(t0, t0))
        assertTrue(ChangeWindowRules.isGraceOpen(t0, t0 + 9_999))
        assertFalse(ChangeWindowRules.isGraceOpen(t0, t0 + 10_000))
        assertEquals(4_000L, ChangeWindowRules.graceRemainingMs(t0, t0 + 6_000))
        assertEquals(0L, ChangeWindowRules.graceRemainingMs(t0, t0 + 10_000))
    }

    @Test fun graceNeverStartedOrClockBackwardsIsClosed() {
        assertFalse(ChangeWindowRules.isGraceOpen(0L, 5_000L))
        assertFalse(ChangeWindowRules.isGraceOpen(50_000L, 10_000L))
    }

    @Test fun neverOpenedMeansClosed() {
        assertFalse(ChangeWindowRules.isOpen(0L, 5_000L))
        assertEquals(0L, ChangeWindowRules.remainingMs(0L, 5_000L))
    }

    @Test fun clockGoingBackwardsDoesNotKeepTheWindowOpen() {
        assertFalse(ChangeWindowRules.isOpen(openedAt = 50_000L, now = 10_000L))
    }

    @Test fun remainingCountsDown() {
        assertEquals(ChangeWindowRules.WINDOW_MS - 60_000L, ChangeWindowRules.remainingMs(1_000L, 61_000L))
    }

    @Test fun lockedOnlyWhenOnAndWindowClosed() {
        assertTrue(ChangeWindowRules.isLocked(true, 0L, 9_999L))
        assertFalse(ChangeWindowRules.isLocked(true, 9_000L, 9_999L))
        assertFalse(ChangeWindowRules.isLocked(false, 0L, 9_999L))
    }

    @Test fun cannotTurnOnWithoutAWayToUnlock() {
        assertNotNull(ChangeWindowRules.canTurnOn(passwordLockSet = false, phoneConnected = false))
        assertNull(ChangeWindowRules.canTurnOn(passwordLockSet = true, phoneConnected = false))
        assertNull(ChangeWindowRules.canTurnOn(passwordLockSet = false, phoneConnected = true))
    }

    // ---- What "locked" blocks ----------------------------------------------------------------------

    @Test fun lockedBlocksAppsAndSettingsEvenOutsideASession() {
        assertFalse(locked.focusActive)
        assertFalse(locked.canEditApps)
        assertFalse(locked.canChangeSettings)
    }

    @Test fun openWindowAndOffBehaveLikeBefore() {
        assertTrue(windowOpen.canEditApps); assertTrue(windowOpen.canChangeSettings)
        assertTrue(plain.canEditApps); assertTrue(plain.canChangeSettings)
    }

    @Test fun sessionRulesStillApplyInsideAnOpenWindow() {
        val s = windowOpen.copy(focusActive = true, allowAppChanges = false, allowSettingsChange = false)
        assertFalse(s.canEditApps)
        assertFalse(s.canChangeSettings)
    }

    @Test fun contentSettingsAreFrozenBothWays() {
        assertTrue(ContentPolicy.frozen(locked))
        assertFalse(ContentPolicy.frozen(windowOpen))
        assertFalse(ContentPolicy.canSetFeature(locked, current = false, on = true))
        assertFalse(ContentPolicy.canSetFeature(locked, current = true, on = false))
        assertFalse(ContentPolicy.canSetAutoDetect(locked, current = false, on = true))
        assertFalse(ContentPolicy.canAddChannel(locked))
        assertFalse(ContentPolicy.canRemoveChannel(locked))
        assertFalse(ContentPolicy.canAddCustom(locked))
        assertFalse(ContentPolicy.canRemoveCustom(locked))
        assertTrue(ContentPolicy.canSetFeature(locked, current = true, on = true)) // no change is fine
        assertTrue(ContentPolicy.canAddChannel(windowOpen))
        assertTrue(ContentPolicy.canSetFeature(plain, current = false, on = true))
    }

    @Test fun emergencyAppsAreFrozen() {
        assertTrue(EmergencyPolicy.editsLocked(locked))
        assertFalse(EmergencyPolicy.editsLocked(windowOpen))
        assertFalse(EmergencyPolicy.canSetEnabled(locked, true))
        assertFalse(EmergencyPolicy.canSetEnabled(locked, false))
        assertFalse(EmergencyPolicy.canSetLimit(locked, currentLimit = 3, newLimit = 2))
        assertTrue(EmergencyPolicy.canSetEnabled(windowOpen, true))
        assertTrue(EmergencyPolicy.canSetLimit(windowOpen, 3, 5))
    }

    @Test fun focusModeControlsAreNotLockedByPreventChanges() {
        // Focus Mode is separate from the phone-wide settings: its switches stay free under "Prevent changes".
        assertTrue(FocusPolicy.canSetControl(locked, FocusControl.OTHER_BYPASS, allowed = true))
        assertTrue(FocusPolicy.canSetControl(locked, FocusControl.TURN_OFF, allowed = false))
        assertTrue(FocusPolicy.canSetControl(locked, FocusControl.TURN_OFF, allowed = true))
        assertTrue(FocusPolicy.canSetControl(plain, FocusControl.OTHER_BYPASS, allowed = true))
    }

    @Test fun focusModeSettingsAndProfilesIgnorePreventChanges() {
        assertTrue(locked.canChangeFocusSettings)
        assertTrue(locked.canEditFocusProfiles)
        // ...while the phone-wide settings and blocking lists stay locked.
        assertFalse(locked.canChangeSettings)
        assertFalse(locked.canEditApps)
    }

    @Test fun sessionRulesStillLockFocusSettingsAndProfiles() {
        val s = locked.copy(focusActive = true, allowSettingsChange = false, allowAppChanges = false)
        assertFalse(s.canChangeFocusSettings)
        assertFalse(s.canEditFocusProfiles)
        // Inside a session a control can still only be tightened.
        val running = locked.copy(focusActive = true, sessionEnd = 1L)
        assertFalse(FocusPolicy.canSetControl(running, FocusControl.OTHER_BYPASS, allowed = true))
        assertTrue(FocusPolicy.canSetControl(running, FocusControl.TURN_OFF, allowed = false))
    }
}
