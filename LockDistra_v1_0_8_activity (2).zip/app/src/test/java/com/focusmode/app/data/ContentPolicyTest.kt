package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ContentPolicyTest {

    private fun running(allowApps: Boolean = true) = FocusState(
        focusActive = true,
        sessionStart = 1L,
        sessionEnd = 10_000_000L,
        allowAppChanges = allowApps,
    )

    private val idle = FocusState(focusActive = false)

    /** A Shorts player the way the accessibility tree might expose it. */
    private fun shorts(vararg texts: String, handle: String? = null) = buildList {
        add(NodeSnap(id = "com.google.android.youtube:id/reel_player_page_container"))
        if (handle != null) add(NodeSnap(id = "com.google.android.youtube:id/reel_channel_bar", text = handle))
        texts.forEach { add(NodeSnap(text = it)) }
    }

    private fun ch(raw: String) = EducationMatcher.parseChannelInput(raw)!!

    // ---- Channel input ----------------------------------------------------------------------

    @Test
    fun channelInputAcceptsNamesHandlesAndLinks() {
        assertEquals("khan academy", ch("Khan Academy").key)
        assertEquals("khanacademy", ch("@KhanAcademy").key)
        assertEquals("veritasium", ch("https://www.youtube.com/@Veritasium").key)
        assertEquals("@Veritasium", ch("https://www.youtube.com/@Veritasium").display)
    }

    @Test
    fun channelInputRefusesWhatCannotBeMatchedOnScreen() {
        assertNull(EducationMatcher.parseChannelInput(""))
        assertNull(EducationMatcher.parseChannelInput("ab"))
        assertNull(EducationMatcher.parseChannelInput("https://www.youtube.com/channel/UCabc123"))
        assertNull(EducationMatcher.parseChannelInput("name<script>"))
        assertNull(EducationMatcher.parseChannelInput("x".repeat(41)))
    }

    // ---- Whitelist matching -----------------------------------------------------------------

    @Test
    fun listedHandleIsAllowed() {
        val v = EducationMatcher.judge(shorts(handle = "@KhanAcademy"), listOf(ch("khanacademy")), false, false)
        assertEquals(ShortsVerdict.Allow("channel"), v)
    }

    @Test
    fun handleMatchesWhenTheUserTypedTheDisplayName() {
        val v = EducationMatcher.judge(shorts(handle = "@KhanAcademy"), listOf(ch("Khan Academy")), false, false)
        assertEquals(ShortsVerdict.Allow("channel"), v)
    }

    @Test
    fun channelNameOnItsOwnNodeMatches() {
        val v = EducationMatcher.judge(shorts("Khan Academy", "Subscribe"), listOf(ch("Khan Academy")), false, false)
        assertEquals(ShortsVerdict.Allow("channel"), v)
    }

    @Test
    fun aCaptionThatOnlyMentionsAChannelDoesNotCount() {
        val v = EducationMatcher.judge(
            shorts("this prank is better than Khan Academy lol", handle = "@prankster"),
            listOf(ch("Khan Academy")), false, false
        )
        assertEquals(ShortsVerdict.Block("@prankster"), v)
    }

    @Test
    fun hiddenNodesAreIgnored() {
        val nodes = listOf(NodeSnap(id = "x:id/reel_channel_bar", text = "@KhanAcademy", visible = false))
        assertNull(EducationMatcher.matchChannel(nodes, listOf(ch("khanacademy"))))
    }

    @Test
    fun otherChannelIsBlockedAtOnceWhenItsHandleIsKnown() {
        val v = EducationMatcher.judge(shorts(handle = "@somebody"), listOf(ch("khanacademy")), false, false)
        assertEquals(ShortsVerdict.Block("@somebody"), v)
    }

    @Test
    fun withNoChannelOnScreenItWaitsThenBlocks() {
        val nodes = shorts("Subscribe")
        val list = listOf(ch("khanacademy"))
        assertEquals(ShortsVerdict.Wait, EducationMatcher.judge(nodes, list, false, false))
        assertEquals(ShortsVerdict.Block(null), EducationMatcher.judge(nodes, list, false, true))
    }

    @Test
    fun withoutAnyListEveryShortIsBlockedImmediately() {
        assertEquals(ShortsVerdict.Block(null), EducationMatcher.judge(shorts(handle = "@KhanAcademy"), emptyList(), false, false))
    }

    // ---- Automatic detection ----------------------------------------------------------------

    @Test
    fun autoDetectAllowsClearlyEducationalShorts() {
        val nodes = shorts("Newton's laws explained #physics #jee #study", handle = "@someteacher")
        assertEquals(ShortsVerdict.Allow("auto"), EducationMatcher.judge(nodes, emptyList(), true, false))
    }

    @Test
    fun autoDetectBlocksEntertainmentAndWaitsForCaptions() {
        val fun_ = shorts("Epic prank challenge #funny #viral", handle = "@clown")
        assertEquals(ShortsVerdict.Wait, EducationMatcher.judge(fun_, emptyList(), true, false))
        assertEquals(ShortsVerdict.Block("@clown"), EducationMatcher.judge(fun_, emptyList(), true, true))
    }

    @Test
    fun learnMoreOnAnAdIsNotEducation() {
        val ad = shorts("Sponsored", "Learn more", "Shop now")
        assertFalse(EducationMatcher.looksEducational(ad))
    }

    @Test
    fun negativeWordsOutweighOneEducationalWord() {
        assertFalse(EducationMatcher.looksEducational(shorts("science prank #funny")))
    }

    @Test
    fun listedChannelBeatsAutoDetectOff() {
        val v = EducationMatcher.judge(shorts("lol", handle = "@KhanAcademy"), listOf(ch("khanacademy")), true, false)
        assertEquals(ShortsVerdict.Allow("channel"), v)
    }

    // ---- Section matching -------------------------------------------------------------------

    @Test
    fun labelsMatchAtWordBoundaries() {
        assertTrue(FeatureMatcher.labelMatches("Reels", "Reels"))
        assertTrue(FeatureMatcher.labelMatches("Reels", "reels, tab 2 of 5"))
        assertFalse(FeatureMatcher.labelMatches("Reels", "Reelsy"))
        assertFalse(FeatureMatcher.labelMatches("Reels", "Home"))
        assertFalse(FeatureMatcher.labelMatches("", "Home"))
    }

    @Test
    fun selectedTabIsDetectedButAnUnselectedOneIsNot() {
        val def = FeatureCatalog.byId(FeatureCatalog.IG_REELS)!!
        val tabs = listOf(
            NodeSnap(id = "com.instagram.android:id/feed_tab", desc = "Home", selected = false),
            NodeSnap(id = "com.instagram.android:id/clips_tab", desc = "Reels", selected = false),
        )
        assertFalse(FeatureMatcher.matches(def.selector, tabs))
        val onReels = listOf(tabs[0], tabs[1].copy(selected = true))
        assertTrue(FeatureMatcher.matches(def.selector, onReels))
    }

    @Test
    fun youtubeHomeTabOnlyCountsWhenSelected() {
        val def = FeatureCatalog.byId(FeatureCatalog.YT_HOME)!!
        assertFalse(FeatureMatcher.matches(def.selector, listOf(NodeSnap(desc = "Home", selected = false))))
        assertTrue(FeatureMatcher.matches(def.selector, listOf(NodeSnap(desc = "Home", selected = true))))
    }

    @Test
    fun searchBoxByIdOrByHint() {
        val def = FeatureCatalog.byId(FeatureCatalog.YT_SEARCH)!!
        assertTrue(FeatureMatcher.matches(def.selector, listOf(NodeSnap(id = "com.google.android.youtube:id/search_edit_text"))))
        assertTrue(
            FeatureMatcher.matches(
                def.selector,
                listOf(NodeSnap(cls = "android.widget.EditText", text = "Search YouTube"))
            )
        )
        // The magnifier icon on the Home feed must not trigger it.
        assertFalse(FeatureMatcher.matches(def.selector, listOf(NodeSnap(cls = "android.widget.ImageView", desc = "Search"))))
    }

    @Test
    fun invisibleNodesNeverMatch() {
        val def = FeatureCatalog.byId(FeatureCatalog.YT_HOME)!!
        assertFalse(FeatureMatcher.matches(def.selector, listOf(NodeSnap(desc = "Home", selected = true, visible = false))))
    }

    @Test
    fun customSectionsUseSelectedLabels() {
        val custom = CustomSection("com.some.app", "Trending")
        val state = ContentState(customSections = listOf(custom))
        val defs = state.activeDefs("com.some.app")
        assertEquals(1, defs.size)
        assertTrue(FeatureMatcher.matches(defs[0].selector, listOf(NodeSnap(text = "Trending", selected = true))))
        assertFalse(FeatureMatcher.matches(defs[0].selector, listOf(NodeSnap(text = "Trending", selected = false))))
    }

    @Test
    fun onlyEnabledPresetsAreActive() {
        val state = ContentState(enabledFeatures = setOf(FeatureCatalog.IG_REELS))
        assertEquals(listOf(FeatureCatalog.IG_REELS), state.activeDefs(FeatureCatalog.INSTAGRAM).map { it.id })
        assertTrue(state.watches(FeatureCatalog.INSTAGRAM))
        assertFalse(state.watches(FeatureCatalog.YOUTUBE))
        assertEquals(1, state.activeFeatureCount)
    }

    @Test
    fun everyCatalogEntryIsReachableAndUnique() {
        assertEquals(FeatureCatalog.all.size, FeatureCatalog.all.map { it.id }.toSet().size)
        FeatureCatalog.all.forEach {
            assertNotNull(FeatureCatalog.byId(it.id))
            assertTrue(it.pkg in FeatureCatalog.appPackages)
        }
    }

    // ---- Editing rules ----------------------------------------------------------------------

    @Test
    fun everythingIsFreeBetweenSessions() {
        assertTrue(ContentPolicy.canSetFeature(idle, true, false))
        assertTrue(ContentPolicy.canSetAutoDetect(idle, false, true))
        assertTrue(ContentPolicy.canAddChannel(idle))
        assertTrue(ContentPolicy.canRemoveCustom(idle))
    }

    @Test
    fun duringASessionRestrictionsOnlyGetTighter() {
        val s = running()
        assertTrue(ContentPolicy.canSetFeature(s, false, true))
        assertFalse(ContentPolicy.canSetFeature(s, true, false))
        assertTrue(ContentPolicy.canSetAutoDetect(s, true, false))
        assertFalse(ContentPolicy.canSetAutoDetect(s, false, true))
        assertFalse(ContentPolicy.canAddChannel(s))
        assertTrue(ContentPolicy.canRemoveChannel(s))
        assertTrue(ContentPolicy.canAddCustom(s))
        assertFalse(ContentPolicy.canRemoveCustom(s))
    }

    @Test
    fun appRestrictionLockFreezesEverythingDuringASession() {
        val s = running(allowApps = false)
        assertTrue(ContentPolicy.frozen(s))
        assertFalse(ContentPolicy.canSetFeature(s, false, true))
        assertFalse(ContentPolicy.canSetAutoDetect(s, true, false))
        assertFalse(ContentPolicy.canRemoveChannel(s))
        assertFalse(ContentPolicy.canAddCustom(s))
        // Unchanged values are always fine.
        assertTrue(ContentPolicy.canSetFeature(s, true, true))
    }

    // ---- Storage codec ----------------------------------------------------------------------

    @Test
    fun listCodecKeepsOrderAndPairs() {
        val items = listOf("@a_b", "khan academy", "x")
        assertEquals(items, ListCodec.decode(ListCodec.encode(items)))
        assertEquals(emptyList<String>(), ListCodec.decode(""))
        assertEquals(emptyList<String>(), ListCodec.decode(null))
        assertEquals("pkg" to "Trending, now", ListCodec.unpair(ListCodec.pair("pkg", "Trending, now")))
        assertNull(ListCodec.unpair("nopair"))
    }
}
