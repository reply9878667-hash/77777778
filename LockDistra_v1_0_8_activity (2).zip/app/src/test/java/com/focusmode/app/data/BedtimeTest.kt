package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BedtimeTest {

    private fun t(h: Int, m: Int = 0) = h * 60 + m
    private val ig = "com.instagram.android"
    private val night = BedtimeState(enabled = true, startMin = t(22), endMin = t(7), apps = setOf(ig))

    @Test fun defaultsAreOffWithNoApps() {
        val s = BedtimeState()
        assertFalse(s.enabled)
        assertTrue(s.apps.isEmpty())
        assertFalse(s.armed)
        assertEquals(t(22), s.startMin)
        assertEquals(t(7), s.endMin)
    }

    @Test fun sameDayWindow() {
        assertTrue(BedtimeRules.inWindow(t(13), t(15), t(13)))
        assertTrue(BedtimeRules.inWindow(t(13), t(15), t(14, 59)))
        assertFalse(BedtimeRules.inWindow(t(13), t(15), t(15)))   // end is not included
        assertFalse(BedtimeRules.inWindow(t(13), t(15), t(12, 59)))
    }

    @Test fun overnightWindowCrossesMidnight() {
        assertTrue(BedtimeRules.inWindow(t(22), t(7), t(22)))
        assertTrue(BedtimeRules.inWindow(t(22), t(7), t(23, 59)))
        assertTrue(BedtimeRules.inWindow(t(22), t(7), 0))
        assertTrue(BedtimeRules.inWindow(t(22), t(7), t(6, 59)))
        assertFalse(BedtimeRules.inWindow(t(22), t(7), t(7)))
        assertFalse(BedtimeRules.inWindow(t(22), t(7), t(12)))
        assertFalse(BedtimeRules.inWindow(t(22), t(7), t(21, 59)))
    }

    @Test fun equalStartAndEndIsNotAWindow() {
        assertFalse(BedtimeRules.validWindow(t(8), t(8)))
        assertFalse(BedtimeRules.inWindow(t(8), t(8), t(8)))
        assertFalse(BedtimeState(true, t(8), t(8), setOf(ig)).armed)
    }

    @Test fun blocksOnlySelectedAppsInsideWindow() {
        assertTrue(BedtimeRules.blocks(night, ig, t(23)))
        assertFalse(BedtimeRules.blocks(night, "com.whatsapp", t(23)))      // not selected
        assertFalse(BedtimeRules.blocks(night, ig, t(12)))                  // outside window
    }

    @Test fun offOrNoAppsBlocksNothing() {
        assertFalse(BedtimeRules.blocks(night.copy(enabled = false), ig, t(23)))
        assertFalse(BedtimeRules.blocks(night.copy(apps = emptySet()), ig, t(23)))
        assertFalse(BedtimeRules.active(night.copy(apps = emptySet()), t(23)))
    }

    @Test fun addingAndRemovingApps() {
        val two = night.copy(apps = night.apps + "com.whatsapp")
        assertTrue(BedtimeRules.blocks(two, "com.whatsapp", t(23)))
        val back = two.copy(apps = two.apps - "com.whatsapp")
        assertFalse(BedtimeRules.blocks(back, "com.whatsapp", t(23)))
        assertTrue(BedtimeRules.blocks(back, ig, t(23)))
    }

    @Test fun minutesUntilWrapsAndNeverZero() {
        assertEquals(60, BedtimeRules.minutesUntil(t(21), t(22)))
        assertEquals(9 * 60, BedtimeRules.minutesUntil(t(22), t(7)))
        assertEquals(BedtimeRules.DAY_MIN, BedtimeRules.minutesUntil(t(7), t(7)))
    }

    @Test fun nextBoundaryIsStartWhenClosedAndEndWhenOpen() {
        // 21:00 -> start at 22:00 = 1 hour.
        assertEquals(60 * 60_000L, BedtimeRules.msToNextBoundary(night, t(21), 0))
        // 23:30 -> end at 07:00 = 7.5 hours.
        assertEquals((7 * 60 + 30) * 60_000L, BedtimeRules.msToNextBoundary(night, t(23, 30), 0))
        // 03:00 (after midnight) -> end at 07:00 = 4 hours.
        assertEquals(4 * 60 * 60_000L, BedtimeRules.msToNextBoundary(night, t(3), 0))
        // 07:00 exactly (just ended) -> next start is 15 hours away.
        assertEquals(15 * 60 * 60_000L, BedtimeRules.msToNextBoundary(night, t(7), 0))
    }

    @Test fun nextBoundaryAccountsForSecondsIntoTheMinute() {
        assertEquals(60 * 60_000L - 30_000L, BedtimeRules.msToNextBoundary(night, t(21), 30_000L))
    }

    @Test fun dailyRepetition() {
        // The rule only looks at the time of day, so every day behaves the same.
        repeat(3) { assertTrue(BedtimeRules.blocks(night, ig, t(23))) }
        repeat(3) { assertFalse(BedtimeRules.blocks(night, ig, t(8))) }
    }

    @Test fun formatsClockText() {
        assertEquals("10:00 PM", BedtimeRules.format(t(22)))
        assertEquals("7:00 AM", BedtimeRules.format(t(7)))
        assertEquals("12:00 AM", BedtimeRules.format(0))
        assertEquals("12:30 PM", BedtimeRules.format(t(12, 30)))
    }

    @Test fun notificationTextMatchesTheSpec() {
        assertEquals("Bedtime Mode is ON. Selected applications are now blocked.", BedtimeRules.startedText())
        assertEquals("Bedtime Mode is OFF. Your selected applications are unlocked.", BedtimeRules.endedText())
    }
}
