package com.focusmode.app.data

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Test

class StudyNativeChannelsTest {
    private val id = "UC" + "a".repeat(22)

    @Test fun readsClassicChannelRenderer() {
        val json = JSONObject(
            """{"contents":[{"channelRenderer":{"channelId":"$id","title":{"simpleText":"Physics Wallah"},
            "thumbnail":{"thumbnails":[{"url":"//yt3.ggpht.com/pic=s88"}]},
            "subscriberCountText":{"simpleText":"@PhysicsWallah"},"videoCountText":{"simpleText":"11M subscribers"}}}]}"""
        )
        val out = StudyNative.parseChannels(json)
        assertEquals(1, out.size)
        assertEquals("Physics Wallah", out[0].name)
        assertEquals("@PhysicsWallah", out[0].handle)
        assertEquals("11M subscribers", out[0].subsLabel)
        assertEquals("https://yt3.ggpht.com/pic=s88", out[0].avatarUrl)
    }

    @Test fun ignoresDuplicatesAndBadIds() {
        val json = JSONObject(
            """{"a":[{"channelRenderer":{"channelId":"$id","title":{"simpleText":"X"}}},
            {"channelRenderer":{"channelId":"$id","title":{"simpleText":"X again"}}},
            {"channelRenderer":{"channelId":"bad","title":{"simpleText":"Y"}}}]}"""
        )
        assertEquals(1, StudyNative.parseChannels(json).size)
    }
}
