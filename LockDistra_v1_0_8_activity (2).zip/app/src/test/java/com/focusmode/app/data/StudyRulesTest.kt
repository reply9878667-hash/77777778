package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class StudyRulesTest {

    private fun video(
        title: String = "Quadratic equations class 10",
        channel: String = "Maths Guru",
        channelId: String = "UC1",
        category: String = "27",
        seconds: Int = 600,
        embeddable: Boolean = true,
    ) = StudyVideo("abcdefghijk", title, channelId, channel, "", seconds, category, embeddable)

    @Test fun educationVideo_isAccepted() {
        assertTrue(StudyRules.accept(video(), emptySet()))
    }

    @Test fun otherCategory_isRejected_unlessChannelIsTrusted() {
        val v = video(category = "24")
        assertFalse(StudyRules.accept(v, emptySet()))
        assertTrue(StudyRules.accept(v, setOf("UC1")))
    }

    @Test fun distractionWords_areRejected() {
        assertFalse(StudyRules.accept(video(title = "Funny physics prank"), emptySet()))
        assertFalse(StudyRules.accept(video(channel = "Gaming Hub"), emptySet()))
        // whole words only: "gta" must not hit "Magtap"
        assertTrue(StudyRules.accept(video(title = "Magtap lesson"), emptySet()))
    }

    @Test fun trustedChannel_skipsDistractionList_butNotTheNeverList() {
        assertTrue(StudyRules.accept(video(title = "Movie review of the Mughal era", category = "24"), setOf("UC1")))
        assertFalse(StudyRules.accept(video(title = "nsfw clip", category = "24"), setOf("UC1")))
    }

    @Test fun notEmbeddableOrLive_isRejected() {
        assertFalse(StudyRules.accept(video(embeddable = false), emptySet()))
        assertFalse(StudyRules.accept(video(seconds = 0), emptySet()))
    }

    @Test fun durations() {
        assertEquals(3723, StudyRules.parseDuration("PT1H2M3S"))
        assertEquals(45, StudyRules.parseDuration("PT45S"))
        assertEquals(600, StudyRules.parseDuration("PT10M"))
        assertEquals(0, StudyRules.parseDuration("P0D"))
        assertEquals(0, StudyRules.parseDuration(null))
        assertEquals("1:02:03", StudyRules.formatLength(3723))
        assertEquals("0:45", StudyRules.formatLength(45))
    }

    @Test fun shortsAreThreeMinutesOrLess() {
        assertTrue(video(seconds = 59).isShort)
        assertTrue(video(seconds = 180).isShort)
        assertFalse(video(seconds = 181).isShort)
    }

    @Test fun parsesVideosAnswer() {
        val json = """{"items":[
          {"id":"aaaaaaaaaaa","snippet":{"title":"T1","channelId":"C1","channelTitle":"Ch","categoryId":"27","liveBroadcastContent":"none",
           "thumbnails":{"medium":{"url":"https://i.ytimg.com/vi/a/mqdefault.jpg"}}},
           "contentDetails":{"duration":"PT5M"},"status":{"privacyStatus":"public","embeddable":true}},
          {"id":"bbbbbbbbbbb","snippet":{"title":"Live","channelId":"C1","channelTitle":"Ch","categoryId":"27","liveBroadcastContent":"live"},
           "contentDetails":{"duration":"P0D"},"status":{"privacyStatus":"public","embeddable":true}},
          {"id":"ccccccccccc","snippet":{"title":"Hidden","channelId":"C1","channelTitle":"Ch","categoryId":"27"},
           "contentDetails":{"duration":"PT5M"},"status":{"privacyStatus":"private"}}]}"""
        val list = StudyRules.parseVideos(json)
        assertEquals(1, list.size)
        assertEquals("T1", list[0].title)
        assertEquals(300, list[0].seconds)
        assertEquals("https://i.ytimg.com/vi/a/mqdefault.jpg", list[0].thumbUrl)
        assertEquals(emptyList<StudyVideo>(), StudyRules.parseVideos("not json"))
    }

    @Test fun picksTheSharpestPicture() {
        val json = """{"items":[{"id":"aaaaaaaaaaa","snippet":{"title":"T","channelId":"C","channelTitle":"Ch","categoryId":"27","liveBroadcastContent":"none",
           "thumbnails":{"medium":{"url":"https://i.ytimg.com/vi/a/mqdefault.jpg"},"high":{"url":"https://i.ytimg.com/vi/a/hqdefault.jpg"},"maxres":{"url":"https://i.ytimg.com/vi/a/maxresdefault.jpg"}}},
           "contentDetails":{"duration":"PT5M"},"status":{"privacyStatus":"public","embeddable":true}}]}"""
        assertEquals("https://i.ytimg.com/vi/a/maxresdefault.jpg", StudyRules.parseVideos(json)[0].thumbUrl)
    }

    @Test fun channelCountry_isParsedUpperCase() {
        val json = """{"items":[{"id":"UC1","snippet":{"title":"A","country":"in"}},{"id":"UC2","snippet":{"title":"B"}}]}"""
        val list = StudyRules.parseChannelInfos(json)
        assertEquals("IN", list[0].country)
        assertEquals("", list[1].country)
    }

    @Test fun indiaFirst_putsOtherCountriesLastOrDropsThem() {
        val a = video(channelId = "IND")
        val b = video(channelId = "USA")
        val c = video(channelId = "NONE")
        val d = video(channelId = "TRUSTED_US")
        val countries = mapOf("IND" to "IN", "USA" to "US", "NONE" to "", "TRUSTED_US" to "US")
        val trusted = setOf("TRUSTED_US")
        // last, not removed (a search): India, unknown country and trusted channels keep their order; the US channel goes last
        assertEquals(listOf(a, c, d, b), StudyRules.indiaFirst(listOf(b, a, c, d), countries, trusted, dropForeign = false))
        // removed (the home feed)
        assertEquals(listOf(a, c, d), StudyRules.indiaFirst(listOf(b, a, c, d), countries, trusted, dropForeign = true))
        // never an empty feed: when only foreign videos exist they are kept
        assertEquals(listOf(b), StudyRules.indiaFirst(listOf(b), countries, emptySet(), dropForeign = true))
    }

    @Test fun diversify_neverTwoOfTheSameChannelInARow_andCapsAChannel() {
        // channel A has 6 videos, B..G one each (7 channels, so the cap of 3 applies)
        val a = (1..6).map { StudyVideo("a$it", "A$it", "A", "A", "", 600, "27", true) }
        val others = listOf("B", "C", "D", "E", "F", "G").map { StudyVideo("x$it", "t", it, it, "", 600, "27", true) }
        val out = StudyRules.diversify(a + others)
        assertEquals(3, out.count { it.channelId == "A" })
        assertEquals(9, out.size)
        // the first 7 are 7 different channels
        assertEquals(7, out.take(7).map { it.channelId }.toSet().size)
        // A's videos keep their own order
        assertEquals(listOf("a1", "a2", "a3"), out.filter { it.channelId == "A" }.map { it.id })
    }

    @Test fun diversify_fewChannels_noCap_butStillMixed() {
        val a = (1..4).map { StudyVideo("a$it", "A$it", "A", "A", "", 600, "27", true) }
        val b = (1..4).map { StudyVideo("b$it", "B$it", "B", "B", "", 600, "27", true) }
        val out = StudyRules.diversify(a + b)
        assertEquals(8, out.size)
        assertEquals(listOf("A", "B", "A", "B", "A", "B", "A", "B"), out.map { it.channelId })
    }

    @Test fun watchedChannel_skipsCategoryCheck_butNotTheDistractionCheck() {
        val v = video(category = "22")
        assertFalse(StudyRules.accept(v, emptySet(), emptySet()))
        assertTrue(StudyRules.accept(v, emptySet(), setOf("UC1")))
        assertFalse(StudyRules.accept(video(category = "22", title = "Funny physics prank"), emptySet(), setOf("UC1")))
    }

    @Test fun parsesSearchAndPlaylistIds() {
        assertEquals(listOf("a", "b"), StudyRules.parseSearchIds("""{"items":[{"id":{"videoId":"a"}},{"id":{"videoId":"b"}},{"id":{"kind":"channel"}}],"nextPageToken":"N"}"""))
        assertEquals("N", StudyRules.parseNextPage("""{"nextPageToken":"N"}"""))
        assertNull(StudyRules.parseNextPage("""{"items":[]}"""))
        assertEquals(listOf("x"), StudyRules.parsePlaylistIds("""{"items":[{"contentDetails":{"videoId":"x"}}]}"""))
    }

    @Test fun errorsAreExplained() {
        assertEquals(StudyErrorKind.QUOTA, StudyRules.parseError(403, """{"error":{"errors":[{"reason":"quotaExceeded"}]}}""").kind)
        assertEquals(StudyErrorKind.BAD_KEY, StudyRules.parseError(400, """{"error":{"errors":[{"reason":"keyInvalid"}]}}""").kind)
        assertEquals(StudyErrorKind.BAD_KEY, StudyRules.parseError(403, """{"error":{"errors":[{"reason":"accessNotConfigured"}]}}""").kind)
        assertEquals(StudyErrorKind.OTHER, StudyRules.parseError(500, "oops").kind)
    }

    @Test fun channelLinks() {
        val id = "UC" + "a".repeat(22)
        assertEquals(ChannelRef.Handle("physicswallah"), StudyRules.parseChannelRef("@physicswallah"))
        assertEquals(ChannelRef.Handle("physicswallah"), StudyRules.parseChannelRef("https://www.youtube.com/@physicswallah"))
        assertEquals(ChannelRef.Handle("physicswallah"), StudyRules.parseChannelRef("https://m.youtube.com/@physicswallah/videos"))
        assertEquals(ChannelRef.Id(id), StudyRules.parseChannelRef("https://youtube.com/channel/$id"))
        assertEquals(ChannelRef.Id(id), StudyRules.parseChannelRef(id))
        assertNull(StudyRules.parseChannelRef("https://example.com/@x"))
        assertNull(StudyRules.parseChannelRef(""))
        assertEquals("UU" + "a".repeat(22), StudyRules.uploadsPlaylist(id))
    }

    @Test fun cacheRoundTrip() {
        val list = listOf(video(), video(title = "Another", seconds = 50))
        assertEquals(list, StudyRules.fromJson(StudyRules.toJson(list)))
        assertEquals(emptyList<StudyVideo>(), StudyRules.fromJson("garbage"))
    }

    @Test fun subjectRotation() {
        val s = listOf("a", "b", "c", "d")
        assertEquals(listOf("a", "b"), StudyRules.pickSubjects(s, 2, 0))
        assertEquals(listOf("d", "a"), StudyRules.pickSubjects(s, 2, 3))
        assertEquals(s, StudyRules.pickSubjects(s, 5, 7))
    }

    @Test fun suggestions_areParsed_andDistractionOnesDropped() {
        val json = """["physics",["physics class 11","physics funny memes","physics wallah","physics class 11","  ","physics formulas"]]"""
        assertEquals(listOf("physics class 11", "physics wallah", "physics formulas"), StudyRules.parseSuggestions(json))
    }

    @Test fun suggestions_unreadableAnswer_isEmpty() {
        assertTrue(StudyRules.parseSuggestions("not json").isEmpty())
        assertTrue(StudyRules.parseSuggestions("[]").isEmpty())
    }

    @Test fun channelInfos_areParsed() {
        val json = """{"items":[{"id":"UC1","snippet":{"title":"Maths Guru","customUrl":"@mathsguru","thumbnails":{"default":{"url":"https://x/d.jpg"},"medium":{"url":"https://x/m.jpg"}}},"statistics":{"subscriberCount":"1250000","videoCount":"340"}},{"id":"UC2","snippet":{"title":"Hidden"},"statistics":{"hiddenSubscriberCount":true,"subscriberCount":"5"}}]}"""
        val list = StudyRules.parseChannelInfos(json)
        assertEquals(2, list.size)
        assertEquals("Maths Guru", list[0].name)
        assertEquals("@mathsguru", list[0].handle)
        assertEquals("https://x/m.jpg", list[0].avatarUrl)
        assertEquals(1_250_000L, list[0].subscribers)
        assertEquals(340L, list[0].videoCount)
        assertNull(list[1].subscribers)
        assertEquals("", list[1].avatarUrl)
    }

    @Test fun formatCount_isShort() {
        assertEquals("999", StudyRules.formatCount(999))
        assertEquals("1.2K", StudyRules.formatCount(1_250))
        assertEquals("12K", StudyRules.formatCount(12_000))
        assertEquals("1.2M", StudyRules.formatCount(1_250_000))
        assertEquals("2M", StudyRules.formatCount(2_000_000))
    }

    @Test fun parseTime_readsYoutubeTimes() {
        assertEquals(1_714_558_830_000L, StudyRules.parseTime("2024-05-01T10:20:30Z"))
        assertEquals(1_714_558_830_000L, StudyRules.parseTime("2024-05-01T10:20:30.123Z"))
        assertEquals(0L, StudyRules.parseTime("nonsense"))
        assertEquals(0L, StudyRules.parseTime(null))
    }

    @Test fun timeAgo_readsLikeYoutube() {
        val now = 10_000_000_000_000L
        val min = 60_000L
        assertEquals("", StudyRules.timeAgo(0L, now))
        assertEquals("just now", StudyRules.timeAgo(now - 20_000L, now))
        assertEquals("1 minute ago", StudyRules.timeAgo(now - min, now))
        assertEquals("5 hours ago", StudyRules.timeAgo(now - 5 * 60 * min, now))
        assertEquals("1 day ago", StudyRules.timeAgo(now - 24 * 60 * min, now))
        assertEquals("2 weeks ago", StudyRules.timeAgo(now - 15L * 24 * 60 * min, now))
        assertEquals("3 months ago", StudyRules.timeAgo(now - 100L * 24 * 60 * min, now))
        assertEquals("2 years ago", StudyRules.timeAgo(now - 800L * 24 * 60 * min, now))
    }

    @Test fun videoJson_keepsUploadTime() {
        val v = StudyVideo("abcdefghijk", "T", "UC1", "C", "", 600, "27", true, 123_456L)
        assertEquals(123_456L, StudyRules.fromJson(StudyRules.toJson(listOf(v))).first().publishedAt)
    }

    // ---- Study bug fixes (Part 1): missing information, broken cards, error sources ----------------------------------

    @Test fun parseVideos_fillsMissingInformation() {
        val long = "x".repeat(400)
        val json = """{"items":[{"id":"aaaaaaaaaaa","snippet":{"title":"   ","channelId":"C1","channelTitle":" Ch ","categoryId":"27","description":"$long"},
           "contentDetails":{"duration":"PT5M"},"status":{"privacyStatus":"public","embeddable":true}}]}"""
        val v = StudyRules.parseVideos(json).single()
        assertEquals("Untitled video", v.title)
        assertEquals("Ch", v.channelTitle)
        assertEquals("https://i.ytimg.com/vi/aaaaaaaaaaa/hqdefault.jpg", v.thumbUrl) // no picture in the answer: the standard address
        assertEquals(StudyRules.DESCRIPTION_MAX, v.description.length)
    }

    @Test fun parseVideos_oneBrokenItemDoesNotDropTheOthers() {
        val json = """{"items":[5,{"id":""},{"id":"bbbbbbbbbbb"},
           {"id":"aaaaaaaaaaa","snippet":{"title":"T","channelId":"C","channelTitle":"Ch","categoryId":"27"},"contentDetails":{"duration":"PT5M"}}]}"""
        assertEquals(listOf("aaaaaaaaaaa"), StudyRules.parseVideos(json).map { it.id })
    }

    @Test fun imageUrl_onlyGivesAddressesThePhoneCanLoad() {
        assertEquals("https://a/b.jpg", StudyRules.imageUrl(" https://a/b.jpg "))
        assertEquals("https://a/b.jpg", StudyRules.imageUrl("//a/b.jpg"))
        assertEquals("https://a/b.jpg", StudyRules.imageUrl("http://a/b.jpg"))
        assertEquals("", StudyRules.imageUrl("data:image/png;base64,AAAA"))
        assertEquals("", StudyRules.imageUrl(null))
        assertEquals("", StudyRules.imageUrl(""))
    }

    @Test fun answerThatIsNotJson_isRecognised() {
        assertTrue(StudyRules.isAnswerObject("""  {"items":[]}"""))
        assertFalse(StudyRules.isAnswerObject("<html>Log in to the Wi-Fi</html>"))
        assertFalse(StudyRules.isAnswerObject(""))
    }

    @Test fun savedList_survivesOneDamagedEntry_andKeepsDescription() {
        val good = StudyVideo("abcdefghijk", "T", "UC1", "C", "https://x/t.jpg", 600, "27", true, 5L, "About this")
        val json = StudyRules.toJson(listOf(good)).removeSuffix("]") + ""","oops",{"t":"no id"},{"id":""}]"""
        val back = StudyRules.fromJson(json)
        assertEquals(1, back.size)
        assertEquals("About this", back[0].description)
        assertEquals("abcdefghijk", back[0].id)
        // An entry with no picture or title still makes a usable card.
        val bare = StudyRules.fromJson("""[{"id":"zzzzzzzzzzz"}]""").single()
        assertEquals("Untitled video", bare.title)
        assertEquals("https://i.ytimg.com/vi/zzzzzzzzzzz/hqdefault.jpg", bare.thumbUrl)
        assertEquals(emptyList<StudyVideo>(), StudyRules.fromJson("not json"))
    }

    @Test fun channelInfos_readDescription_andUpgradePictureAddress() {
        val json = """{"items":[{"id":"UC1","snippet":{"title":"Maths Guru","description":" Daily lessons. ","thumbnails":{"medium":{"url":"http://x/m.jpg"}}}}]}"""
        val c = StudyRules.parseChannelInfos(json).single()
        assertEquals("Daily lessons.", c.description)
        assertEquals("https://x/m.jpg", c.avatarUrl)
    }

    @Test fun missingPlaylistOrChannel_isNotFound_notAFailureOfTheKey() {
        assertEquals(StudyErrorKind.NOT_FOUND, StudyRules.parseError(404, """{"error":{"errors":[{"reason":"playlistNotFound"}]}}""").kind)
        assertEquals(StudyErrorKind.NOT_FOUND, StudyRules.parseError(404, "gone").kind)
    }

    @Test fun errorsNameTheirSource_andLimitIsNeverANetworkProblem() {
        val quota = StudyException(StudyErrorKind.QUOTA, "m")
        val busy = StudyException(StudyErrorKind.QUOTA, "m", dailyLimit = false)
        val apiNet = StudyException(StudyErrorKind.NETWORK, "m")
        val pageNet = StudyException(StudyErrorKind.NETWORK, "m", source = StudyMode.PAGE)
        val pageBad = StudyException(StudyErrorKind.BAD_ANSWER, "m", source = StudyMode.PAGE)
        assertEquals("YouTube API limit reached", StudyRules.errorTitle(quota, false))
        assertEquals("YouTube API is busy", StudyRules.errorTitle(busy, false))
        assertEquals("Could not reach the YouTube API", StudyRules.errorTitle(apiNet, false))
        assertEquals("Could not reach YouTube", StudyRules.errorTitle(pageNet, true))
        assertEquals("YouTube's page could not be read", StudyRules.errorTitle(pageBad, true))
        assertEquals("Search failed", StudyRules.errorTitle(StudyException(StudyErrorKind.OTHER, "m"), true))
        assertEquals("Could not load videos", StudyRules.errorTitle(StudyException(StudyErrorKind.OTHER, "m"), false))
        // Only an unreadable Direct YouTube page counts as "page unreadable" (the Web search backup, as before).
        assertTrue(pageBad.isPageUnreadable)
        assertFalse(quota.isPageUnreadable)
        assertFalse(pageNet.isPageUnreadable)
        assertFalse(StudyException(StudyErrorKind.BAD_ANSWER, "m").isPageUnreadable)
    }

    @Test fun parseAgoLabel_readsTheTimeFromThePageText() {
        val now = 1_000_000_000_000L
        val day = 24 * 60 * 60 * 1000L
        assertEquals(now - 3 * day, StudyRules.parseAgoLabel("1.2M views 3 days ago", now))
        assertEquals(now - 14 * day, StudyRules.parseAgoLabel("Streamed 2 weeks ago", now))
        assertEquals(now - 365 * day, StudyRules.parseAgoLabel("1 year ago", now))
        assertEquals(now - 5 * 60_000L, StudyRules.parseAgoLabel("5 minutes ago", now))
        assertEquals(0L, StudyRules.parseAgoLabel("1.2M views", now))
        assertEquals(0L, StudyRules.parseAgoLabel("", now))
        assertEquals(0L, StudyRules.parseAgoLabel(null, now))
    }

    @Test fun parseIsoDate_readsOffsetAndPlainDates() {
        assertEquals(StudyRules.parseTime("2024-05-01T17:20:30Z"), StudyRules.parseIsoDate("2024-05-01T10:20:30-07:00"))
        assertTrue(StudyRules.parseIsoDate("2024-05-01") > 0L)
        assertEquals(0L, StudyRules.parseIsoDate("not a date"))
        assertEquals(0L, StudyRules.parseIsoDate(null))
    }
}
