package com.focusmode.app.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class OnboardingCelebrationTest {

    @Test
    fun headlineUsesTheRealName() {
        assertEquals("Awesome, Rahul! \uD83C\uDF89", OnboardingCelebration.headline("Rahul"))
        assertEquals("Awesome, Ayşe! \uD83C\uDF89", OnboardingCelebration.headline("Ayşe"))
    }

    @Test
    fun nameIsTrimmedAndSpacesCollapsed() {
        assertEquals("Awesome, Mary Ann! \uD83C\uDF89", OnboardingCelebration.headline("  Mary   Ann  "))
        assertEquals("Mary Ann", OnboardingCelebration.displayName("\tMary \n Ann "))
    }

    @Test
    fun blankNameStillMakesANiceHeadline() {
        assertEquals("Awesome! \uD83C\uDF89", OnboardingCelebration.headline(""))
        assertEquals("Awesome! \uD83C\uDF89", OnboardingCelebration.headline("   "))
    }

    @Test
    fun headlineFollowsTheNameTypedInQuestionOne() {
        val answers = OnboardingAnswers().withText("name", "  Rahul ")
        assertEquals("Awesome, Rahul! \uD83C\uDF89", OnboardingCelebration.headline(answers.name))
    }

    @Test
    fun theWholeHeadlineCanBeTypedWithoutCuttingTheEmoji() {
        val h = OnboardingCelebration.headline("Rahul")
        assertEquals(Typewriter.length(h) - 1, Typewriter.length(Typewriter.prefix(h, Typewriter.length(h) - 1)))
        assertEquals(h, Typewriter.prefix(h, Typewriter.length(h)))
        assertTrue(Typewriter.prefix(h, Typewriter.length(h) - 1).endsWith("! "))
    }

    @Test
    fun bodyIsTheAgreedMessage() {
        assertEquals(
            "Thanks for telling me about yourself. Your focus journey is about to begin!",
            OnboardingCelebration.BODY
        )
    }

    @Test
    fun celebratingIsNotUsedByAnyQuestion() {
        val a = OnboardingAnswers()
        OnboardingQuestions.all.forEach {
            assertNotEquals(it.id, BuddyMood.Celebrating, OnboardingReactions.moodFor(it.id, a))
        }
    }

    @Test
    fun allSevenAnswersSurviveTheHandOffRoundTrip() {
        val a = OnboardingAnswers()
            .withText("name", "Rahul").withSingle("goal", "study_better")
            .withToggled("distractions", "gaming").withToggled("distractions", "social_media")
            .withSingle("phone_time", "4_6h").withSingle("session_length", "min_45")
            .withSingle("daily_goal", "h_3").withSingle("source", "youtube")
        // What the store writes and reads back (a set of lines).
        val restored = OnboardingAnswers.decode(a.encode().toSet().toList())
        assertEquals(a, restored)
        assertEquals("Rahul", restored.name)
        assertEquals(listOf("gaming", "social_media"), restored.distractions)
        assertEquals("youtube", restored.source)
    }
}
