package com.focusmode.app.data

import org.junit.Assert.*
import org.junit.Test

class LectureTimerRulesTest {

    @Test fun freezes_onlyWhenSessionHasALectureThatIsNotPlaying() {
        assertTrue(LectureTimerRules.shouldFreeze(focusActive = true, hasLecture = true, pomodoroActive = false, lectureDone = false, playing = false))
        assertFalse(LectureTimerRules.shouldFreeze(true, true, false, false, playing = true))
        assertFalse(LectureTimerRules.shouldFreeze(true, hasLecture = false, pomodoroActive = false, lectureDone = false, playing = false))
        assertFalse(LectureTimerRules.shouldFreeze(focusActive = false, hasLecture = true, pomodoroActive = false, lectureDone = false, playing = false))
    }

    @Test fun pomodoroAndFinishedLecture_neverFreeze() {
        assertFalse(LectureTimerRules.shouldFreeze(true, true, pomodoroActive = true, lectureDone = false, playing = false))
        assertFalse(LectureTimerRules.shouldFreeze(true, true, false, lectureDone = true, playing = false))
    }

    @Test fun step_isTheTimeSinceTheLastCheck_butCapped() {
        assertEquals(0L, LectureTimerRules.stepMs(0L, 5_000L))
        assertEquals(1_200L, LectureTimerRules.stepMs(10_000L, 11_200L))
        assertEquals(LectureTimerRules.MAX_STEP_MS, LectureTimerRules.stepMs(10_000L, 10_000L + 10 * 60_000L))
        assertEquals(0L, LectureTimerRules.stepMs(10_000L, 9_000L))
    }

    @Test fun notice_needsTheStayAway_andIsOnlySentOnce() {
        val n = LectureTimerRules.AWAY_NOTICE_MS
        assertFalse(LectureTimerRules.shouldNotify(true, true, false, n - 1, false))
        assertTrue(LectureTimerRules.shouldNotify(true, true, false, n, false))
        assertFalse(LectureTimerRules.shouldNotify(true, true, false, n, alreadyNotified = true))
        assertFalse(LectureTimerRules.shouldNotify(true, seenInPlayer = false, playerVisible = false, awayMs = n, alreadyNotified = false))
        assertFalse(LectureTimerRules.shouldNotify(true, true, playerVisible = true, awayMs = n, alreadyNotified = false))
        assertFalse(LectureTimerRules.shouldNotify(frozen = false, seenInPlayer = true, playerVisible = false, awayMs = n, alreadyNotified = false))
    }
}
