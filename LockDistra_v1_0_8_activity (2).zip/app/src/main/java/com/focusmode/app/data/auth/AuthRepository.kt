package com.focusmode.app.data.auth

import android.app.Activity
import android.content.Context
import com.focusmode.app.data.online.OnlineManager
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * The single entry point of the account system. Screens (and any later feature, e.g. the profile) use this and
 * nothing else from the package:
 *
 *  - [session]: who is logged in (a StateFlow, restored at start, survives restarts)
 *  - signUpWithEmail / signInWithEmail / signInWithGoogle / sendPasswordReset / signOut
 *
 * Every action returns an [AuthResult]; none throws. Only one action runs at a time (a second tap while one is
 * running gets BUSY), which is what stops double submissions even if a screen forgets to disable its button.
 * Passwords are handed straight to Firebase over TLS; Firebase stores only a salted hash on its servers, and this
 * app never saves a password anywhere.
 */
class AuthRepository private constructor(
    context: Context,
    private val host: AccountHost,
) {
    private val appContext = context.applicationContext
    private val store = AuthStore.get(appContext)
    private val service = FirebaseAuthService(appContext)
    private val google = GoogleCredentialClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val running = AtomicBoolean(false)

    val session: StateFlow<AuthSession> = store.session

    /**
     * A message for the login screen that explains why the person is there (the saved login expired). Set when the
     * server says the login is dead, cleared by [takeNotice], by a successful login and by a deliberate log out.
     */
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice.asStateFlow()

    /** Returns the pending notice once and clears it. */
    fun takeNotice(): String? = _notice.value.also { _notice.value = null }

    @Volatile private var lastCheckAt = 0L

    val emailAvailable: Boolean get() = AuthConfig.firebaseReady
    val googleAvailable: Boolean get() = AuthConfig.googleReady

    init {
        lastCheckAt = System.currentTimeMillis()
        scope.launch { restoreSession() }
    }

    // ---- Actions ---------------------------------------------------------------------------------

    suspend fun signUpWithEmail(name: String, email: String, password: String): AuthResult = exclusive {
        val n = AuthValidation.cleanName(name)
        val e = AuthValidation.cleanEmail(email)
        val problem = AuthValidation.nameError(n) ?: AuthValidation.emailError(e) ?: AuthValidation.newPasswordError(password)
        if (problem != null) return@exclusive failure(AuthErrorKind.INVALID_INPUT, problem)
        precheck()?.let { return@exclusive it }
        val user = service.signUpWithEmail(n, e, password)
        complete(user, isNew = true)
    }

    suspend fun signInWithEmail(email: String, password: String): AuthResult = exclusive {
        val e = AuthValidation.cleanEmail(email)
        val problem = AuthValidation.emailError(e) ?: AuthValidation.loginPasswordError(password)
        if (problem != null) return@exclusive failure(AuthErrorKind.INVALID_INPUT, problem)
        precheck()?.let { return@exclusive it }
        // Logging in to an existing account can change this phone's Firebase identity.
        host.identityChangeBlockedReason()?.let { return@exclusive failure(AuthErrorKind.IDENTITY_LOCKED, it) }
        val user = service.signInWithEmail(e, password)
        complete(user, isNew = false)
    }

    /** Needs the foreground [activity]: Android shows the Google account sheet on top of it. */
    suspend fun signInWithGoogle(activity: Activity): AuthResult = exclusive {
        if (!AuthConfig.firebaseReady) return@exclusive failure(AuthErrorKind.NOT_CONFIGURED)
        if (!AuthConfig.googleReady) {
            return@exclusive failure(AuthErrorKind.GOOGLE_NOT_CONFIGURED, AuthConfig.googleSetupProblem ?: AuthErrors.message(AuthErrorKind.GOOGLE_NOT_CONFIGURED))
        }
        if (session.value is AuthSession.SignedIn) return@exclusive failure(AuthErrorKind.ALREADY_SIGNED_IN)
        val identity = google.getIdentity(activity, AuthConfig.webClientId)
        AuthDebug.note("4 signing in to Firebase")
        val outcome = try {
            service.signInWithGoogle(identity.idToken, identity.displayName, host.identityChangeBlockedReason())
        } catch (e: Exception) {
            AuthDebug.note("Firebase failed: ${e.javaClass.simpleName}: ${e.message} / ${e.cause?.javaClass?.simpleName}: ${e.cause?.message}")
            throw e
        }
        AuthDebug.note("5 Firebase ok (new account: ${outcome.isNewAccount})")
        complete(outcome.user, outcome.isNewAccount)
    }

    suspend fun sendPasswordReset(email: String): AuthResult = exclusive {
        val e = AuthValidation.cleanEmail(email)
        AuthValidation.emailError(e)?.let { return@exclusive failure(AuthErrorKind.INVALID_EMAIL, it) }
        if (!AuthConfig.firebaseReady) return@exclusive failure(AuthErrorKind.NOT_CONFIGURED)
        service.sendPasswordReset(e)
        AuthResult.Done
    }

    /** Works offline. Refused only while the connection to a trusted phone is not yet saved on the server, or a Focus session needs it (see [AccountHost]). */
    suspend fun signOut(): AuthResult = exclusive {
        host.logoutBlockedReason()?.let { return@exclusive failure(AuthErrorKind.IDENTITY_LOCKED, it) }
        forgetLogin()
        AuthResult.Done
    }

    /**
     * The profile screen changed the person's name: keep the account in step (Firebase display name, the saved
     * login shown in Settings, and the name on trusted-phone requests). Best effort and never throws: the
     * profile itself is the record of the name, this only keeps the other places consistent.
     */
    suspend fun applyProfileName(name: String) {
        val n = AuthValidation.cleanName(name)
        val current = (store.session.value as? AuthSession.SignedIn)?.user ?: return
        if (n.isEmpty() || n == current.name) return
        try {
            if (service.isReady()) service.updateDisplayName(n)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Offline: the local copy below still changes; Firebase's copy follows with the next edit.
        }
        // The session may have ended while the network call ran.
        if ((store.session.value as? AuthSession.SignedIn)?.user?.uid == current.uid) {
            store.save(current.copy(name = n))
            host.onAccountSignedIn(n, current.email)
        }
    }

    // ---- Session ---------------------------------------------------------------------------------

    /**
     * Asks the server again whether the saved login still stands (the app came back to the foreground). Cheap and
     * safe to call often: at most once a minute, never while a login / sign-up is running, and offline or slow
     * never logs anyone out. A dead login ends the session and [notice] explains it on the login screen.
     */
    fun revalidate() {
        if (session.value !is AuthSession.SignedIn || running.get()) return
        val now = System.currentTimeMillis()
        if (now - lastCheckAt < REVALIDATE_MIN_GAP_MS) return
        lastCheckAt = now
        scope.launch { restoreSession() }
    }

    /**
     * Run once at start. Firebase is the truth when it is available:
     *  - a saved Firebase account the local copy doesn't know (for example a login made with the old
     *    Settings form before this system existed) is adopted;
     *  - a local login that Firebase no longer has is cleared;
     *  - the server is asked whether the login still stands; only a definite "no" logs out. Offline or slow
     *    never logs anyone out.
     */
    private suspend fun restoreSession() {
        try {
            if (!service.isReady()) return
            val saved = service.savedAccountUser()
            val local = (store.session.value as? AuthSession.SignedIn)?.user
            if (saved == null) {
                if (local != null) forgetLogin(signOutFirebase = false, expired = true)
                return
            }
            if (local != saved) {
                store.save(saved)
                host.onAccountSignedIn(saved.name, saved.email)
            }
            if (service.checkSession() == SessionCheck.INVALID) forgetLogin(expired = true)
            else {
                NewUserReport.flush(appContext) // a sign-up report that could not be sent earlier
                ActivityPing.flush(appContext, saved.uid) // "still uses ReWire", once a day
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Slow or offline start: keep whatever is saved.
        }
    }

    // ---- Helpers ---------------------------------------------------------------------------------

    private fun precheck(): AuthResult? = when {
        !AuthConfig.firebaseReady -> failure(AuthErrorKind.NOT_CONFIGURED)
        session.value is AuthSession.SignedIn -> failure(AuthErrorKind.ALREADY_SIGNED_IN)
        else -> null
    }

    private fun complete(user: AuthUser, isNew: Boolean): AuthResult {
        _notice.value = null
        store.save(user)
        host.onAccountSignedIn(user.name, user.email)
        // A brand-new account gets a friendly welcome message on the phone; signing in to an existing one gets "Welcome back".
        runCatching {
            if (isNew) WelcomeNotifier.show(appContext, user.name) else WelcomeNotifier.showWelcomeBack(appContext, user.name)
        }
        runCatching { scope.launch { ActivityPing.flush(appContext, user.uid) } }
        if (isNew) {
            // Event: a new person registered. The Worker tells the admin; retried at the next start if offline.
            runCatching {
                NewUserReport.markPending(appContext, user.uid)
                scope.launch { NewUserReport.flush(appContext) }
            }
        }
        return AuthResult.Success(user, isNew)
    }

    private suspend fun forgetLogin(signOutFirebase: Boolean = true, expired: Boolean = false) {
        if (signOutFirebase) service.signOut()
        google.clear(appContext)
        // Set before the session flips to SignedOut, so the login screen already has its message.
        _notice.value = if (expired) AuthErrors.SESSION_EXPIRED else null
        store.clear()
        host.onAccountSignedOut()
    }

    private fun failure(kind: AuthErrorKind, message: String = AuthErrors.message(kind)) =
        AuthResult.Failure(kind, message)

    /** One action at a time; every exception becomes a [AuthResult] here. */
    private suspend fun exclusive(block: suspend () -> AuthResult): AuthResult {
        if (!running.compareAndSet(false, true)) return failure(AuthErrorKind.BUSY)
        return try {
            block()
        } catch (_: AuthCancelledException) {
            AuthDebug.note("cancelled by the person")
            AuthResult.Cancelled
        } catch (e: AuthException) {
            AuthResult.Failure(e.kind, e.message ?: AuthErrors.message(e.kind))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AuthDebug.note("unexpected: ${e.javaClass.simpleName}: ${e.message}")
            failure(AuthErrorKind.UNKNOWN)
        } finally {
            running.set(false)
        }
    }

    companion object {
        private const val REVALIDATE_MIN_GAP_MS = 60_000L

        @Volatile private var instance: AuthRepository? = null

        fun get(context: Context): AuthRepository =
            instance ?: synchronized(this) {
                instance ?: AuthRepository(context.applicationContext, OnlineManager.get(context).accountHost)
                    .also { instance = it }
            }
    }
}
