package com.focusmode.app.data.online

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.provider.Settings
import com.focusmode.app.data.Storage

/**
 * The apps that the trusted phone gave extra time in. Only [OnlineManager] writes here, and only
 * after the answer's proof checked out. AppBlockerService reads it: while a grant is running, that
 * one app is not closed for its focus block or its daily limits. When the time is over the app is
 * closed again by itself.
 *
 * Kept in device-protected storage, like the limits and the session, so it survives a restart.
 */
class AppGrantStore private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences = Storage.prefs(appContext, "app_unlock_grants")

    @Volatile private var cache: Map<String, AppGrant> = read()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> cache = read() }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    private fun read(): Map<String, AppGrant> {
        val out = HashMap<String, AppGrant>()
        for (raw in prefs.getStringSet(K_GRANTS, emptySet()) ?: emptySet()) {
            val g = AppGrantRules.decode(raw) ?: continue
            out[g.pkg] = g
        }
        return out
    }

    private fun bootCount(): Int = try {
        Settings.Global.getInt(appContext.contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) {
        -1
    }

    /** Starts (or replaces) the window for [pkg]: [minutes] from now. */
    @Synchronized
    fun grant(pkg: String, minutes: Int) {
        val wall = System.currentTimeMillis()
        val elapsed = SystemClock.elapsedRealtime()
        val boot = bootCount()
        val kept = read().values.filter { it.pkg != pkg && AppGrantRules.isActive(it, wall, elapsed, boot) }
        val next = kept + AppGrantRules.newGrant(pkg, minutes, wall, elapsed, boot)
        prefs.edit().putStringSet(K_GRANTS, next.map { AppGrantRules.encode(it) }.toSet()).commit()
        cache = next.associateBy { it.pkg }
    }

    fun isActive(pkg: String): Boolean = remainingMs(pkg) > 0L

    fun remainingMs(pkg: String): Long {
        val g = cache[pkg] ?: return 0L
        return AppGrantRules.remainingMs(g, System.currentTimeMillis(), SystemClock.elapsedRealtime(), bootCount())
    }

    companion object {
        private const val K_GRANTS = "grants"

        @Volatile private var instance: AppGrantStore? = null

        fun get(context: Context): AppGrantStore =
            instance ?: synchronized(this) {
                instance ?: AppGrantStore(context.applicationContext).also { instance = it }
            }
    }
}
