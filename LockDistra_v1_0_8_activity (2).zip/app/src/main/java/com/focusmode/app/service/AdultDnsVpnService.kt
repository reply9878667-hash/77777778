package com.focusmode.app.service

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.focusmode.app.MainActivity
import com.focusmode.app.R
import com.focusmode.app.data.AdultBlockStore
import com.focusmode.app.data.AdultDns
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Adult Content DNS filter. This is what makes Adult Content Blocking work in EVERY browser and app, not only in
 * the address bar of a few browsers.
 *
 * How it works: the service opens a local VPN interface that carries ONLY DNS traffic (one fake DNS address is
 * routed into it; all other traffic keeps using the normal network, so there is no speed loss and nothing leaves
 * the phone through a third party). Every name an app asks for ("pornhub.com", "www.some-site.xyz") is looked at:
 *   1. a listed adult site, an adult-looking name, or one of the person's own links / words -> answered with
 *      0.0.0.0 / ::, so the page cannot load at all;
 *   2. anything else is forwarded to a family-safe resolver (CleanBrowsing "Adult filter", then Cloudflare
 *      "Family"), which blocks adult sites that are not in the local list and turns on SafeSearch for Google,
 *      Bing, YouTube and DuckDuckGo.
 * Names of encrypted-DNS (DoH) servers are refused and the best-known DoH addresses are black-holed, so browsers
 * fall back to this filter instead of skipping it.
 *
 * Android shows its own "VPN" key icon while this runs. The person must allow it once (system dialog).
 */
class AdultDnsVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var reader: Thread? = null
    private var pool: ExecutorService? = null
    @Volatile private var active = false
    private val writeLock = Any()
    private lateinit var store: AdultBlockStore

    override fun onCreate() {
        super.onCreate()
        store = AdultBlockStore.get(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Started with startForegroundService(): must go to the foreground at once, even if we then stop.
        runCatching { goForeground() }
        if (!store.isActive()) {
            stopAll()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!active) establish()
        return START_STICKY
    }

    private fun goForeground() {
        Notifications.ensureChannels(this)
        val open = PendingIntent.getActivity(
            this, 303, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // Privacy: Android forces a notification while this service runs, so it says nothing about adult content,
        // is hidden on the lock screen, sits in the quietest group and shows no time.
        val n: Notification = NotificationCompat.Builder(this, Notifications.CH_QUIET)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("Background service")
            .setContentText("Running")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setContentIntent(open)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    private fun establish() {
        val b = Builder()
            .setSession("LockDistra adult content filter")
            .addAddress(TUN_ADDRESS, 32)
            .addDnsServer(DNS_ADDRESS)
            .addRoute(DNS_ADDRESS, 32)
            .setMtu(1500)
            .setBlocking(true)
        // Well-known encrypted-DNS addresses are pulled into the tunnel and dropped (see pump()), so a browser's
        // "secure DNS" cannot skip the filter. Plain DNS asked of these addresses is still answered.
        for (ip in CATCH_ADDRESSES) runCatching { b.addRoute(ip, 32) }
        // LockDistra's own traffic (sign-in, approvals, list updates) does not need to go through the filter.
        runCatching { b.addDisallowedApplication(packageName) }
        if (Build.VERSION.SDK_INT >= 29) runCatching { b.setMetered(false) }

        val pfd = try { b.establish() } catch (_: Exception) { null }
        if (pfd == null) {
            // The person has not allowed the VPN (or another VPN took over).
            stopAll()
            stopSelf()
            return
        }
        tun = pfd
        active = true
        pool = Executors.newFixedThreadPool(WORKERS)
        reader = Thread({ pump(pfd) }, "adult-dns").also { it.isDaemon = true; it.start() }
        _running.value = true
    }

    private fun pump(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (active) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                val parsed = AdultDns.parsePacket(buf, n)
                // Only DNS questions are served. Everything else that reaches the tunnel (TCP / QUIC to a blocked
                // encrypted-DNS address) is dropped on purpose.
                if (parsed is AdultDns.Parsed.Udp && parsed.packet.dstPort == 53) {
                    val packet = parsed.packet
                    try {
                        pool?.execute { answer(packet, output) }
                    } catch (_: Exception) {
                        // pool shut down while stopping
                    }
                }
            }
        } catch (_: IOException) {
            // the tunnel was closed
        } finally {
            if (active) {
                // Lost the tunnel without being asked to stop (another VPN took over, or the system closed it).
                active = false
                _running.value = false
            }
        }
    }

    private fun answer(packet: AdultDns.UdpPacket, output: FileOutputStream) {
        val reply = try { resolve(packet.payload) } catch (_: Exception) { null } ?: return
        val out = AdultDns.buildReply(packet, reply)
        synchronized(writeLock) {
            try { output.write(out) } catch (_: IOException) { }
        }
    }

    private fun resolve(query: ByteArray): ByteArray? {
        val q = AdultDns.parseQuestion(query) ?: return null
        if (AdultDns.isDohName(q.name)) return AdultDns.errorResponse(query, q, AdultDns.RCODE_NXDOMAIN)
        if (store.isActive() && store.dnsBlocks(q.name)) return AdultDns.sinkholeResponse(query, q)
        val resp = forward(query) ?: return AdultDns.errorResponse(query, q, AdultDns.RCODE_SERVFAIL)
        return if (resp.size > MAX_REPLY) AdultDns.truncated(resp) else resp
    }

    /** Asks the family-safe resolvers in turn. The sockets are exempt from the tunnel, so this cannot loop back. */
    private fun forward(query: ByteArray): ByteArray? {
        for (server in UPSTREAMS) {
            val socket = DatagramSocket()
            try {
                if (!protect(socket)) continue
                socket.soTimeout = 2500
                socket.connect(InetAddress.getByName(server), 53)
                socket.send(DatagramPacket(query, query.size))
                val rb = ByteArray(4096)
                val rp = DatagramPacket(rb, rb.size)
                socket.receive(rp)
                val r = rb.copyOf(rp.length)
                // Must be the answer to this very question.
                if (r.size >= 12 && r[0] == query[0] && r[1] == query[1]) return r
            } catch (_: IOException) {
                // try the next resolver
            } finally {
                socket.close()
            }
        }
        return null
    }

    private fun stopAll() {
        active = false
        _running.value = false
        runCatching { pool?.shutdownNow() }
        pool = null
        runCatching { tun?.close() }
        tun = null
        runCatching { reader?.interrupt() }
        reader = null
    }

    /** The person (or another VPN app) switched this VPN off in Android's settings. */
    override fun onRevoke() {
        stopAll()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 1030
        private const val WORKERS = 6
        private const val MAX_REPLY = 1400

        /** Private addresses that exist only inside the tunnel. */
        private const val TUN_ADDRESS = "10.111.222.1"
        private const val DNS_ADDRESS = "10.111.222.2"

        /** Family-safe resolvers: CleanBrowsing "Adult filter" (adult sites + SafeSearch), then Cloudflare "Family". */
        private val UPSTREAMS = listOf("185.228.168.10", "185.228.169.11", "1.1.1.3", "1.0.0.3")

        /** Public encrypted-DNS addresses that are pulled into the tunnel so they cannot be used to skip the filter. */
        private val CATCH_ADDRESSES = listOf(
            "8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1", "9.9.9.9", "149.112.112.112",
            "208.67.222.222", "208.67.220.220", "94.140.14.14", "94.140.15.15",
        )

        private val _running = MutableStateFlow(false)
        /** True while the filter is really running (the person sees this on the card). */
        val running: StateFlow<Boolean> = _running.asStateFlow()

        /** The system dialog to show once so the person can allow the VPN; null when it is already allowed. */
        fun permissionIntent(context: Context): Intent? =
            try { VpnService.prepare(context) } catch (_: Exception) { null }

        fun start(context: Context) {
            runCatching {
                ContextCompat.startForegroundService(context, Intent(context, AdultDnsVpnService::class.java))
            }
        }

        fun stop(context: Context) {
            runCatching { context.stopService(Intent(context, AdultDnsVpnService::class.java)) }
            _running.value = false
        }

        /**
         * Brings the filter in line with the switch: running while Adult Content Blocking is on (and the VPN is
         * allowed), stopped otherwise. Safe to call often: from the card, app start and after a restart.
         */
        fun sync(context: Context) {
            val app = context.applicationContext
            val store = AdultBlockStore.get(app)
            if (store.isActive()) {
                if (permissionIntent(app) == null) start(app)
            } else {
                stop(app)
            }
        }

        /**
         * True when the phone's "Private DNS" is set to a named provider. Android then sends DNS straight to that
         * provider and no app can filter it; the person has to set it to Off or Automatic.
         */
        fun privateDnsBypassesFilter(context: Context): Boolean = try {
            Settings.Global.getString(context.contentResolver, "private_dns_mode") == "hostname"
        } catch (_: Exception) {
            false
        }
    }
}
