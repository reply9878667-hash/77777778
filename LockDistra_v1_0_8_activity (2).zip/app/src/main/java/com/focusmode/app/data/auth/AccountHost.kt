package com.focusmode.app.data.auth

/**
 * What the account system needs from the rest of the app. Online Approval implements it
 * (`OnlineManager.accountHost`), so the auth package never depends on the unlock code.
 */
interface AccountHost {
    /**
     * A reason (shown to the person) when logging in to a different account or logging out must wait,
     * or null when it is fine. A phone paired with a trusted phone keeps its Firebase identity, because the
     * pairing is bound to it; changing identity would silently break the connection.
     */
    fun identityChangeBlockedReason(): String?

    /**
     * A reason when logging OUT must wait, or null. Defaults to the identity rule; Online Approval overrides it because
     * a connection that is saved on the server comes back at the next login, so logout is allowed again.
     */
    fun logoutBlockedReason(): String? = identityChangeBlockedReason()

    /** The person is now logged in. Lets Online Approval show their name on unlock requests. */
    fun onAccountSignedIn(name: String, email: String)

    /** The person logged out (or the saved login was no longer valid). */
    fun onAccountSignedOut()
}
