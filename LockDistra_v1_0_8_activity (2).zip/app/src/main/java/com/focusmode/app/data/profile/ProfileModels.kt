package com.focusmode.app.data.profile

import com.focusmode.app.data.OnboardingAnswers
import com.focusmode.app.data.OnboardingQuestions
import com.focusmode.app.data.auth.AuthProvider
import com.focusmode.app.data.auth.AuthValidation

/**
 * The seven onboarding answers as they are stored for an account. Every answer except [completedAt] may be
 * missing (the last question is optional, and an answer is never invented). Choice answers are option ids
 * (see OnboardingQuestions), so a label can be reworded without touching saved data.
 */
data class ProfileOnboarding(
    val name: String,
    val goal: String?,
    val distractions: List<String>,
    val phoneTime: String?,
    val sessionLength: String?,
    val dailyGoal: String?,
    /** Only when [dailyGoal] is "custom". */
    val dailyGoalMinutes: Int?,
    val source: String?,
    val completedAt: Long,
) {
    companion object {
        /** null when nothing was answered at all. */
        fun from(a: OnboardingAnswers, now: Long): ProfileOnboarding? {
            if (a.isEmpty) return null
            return ProfileOnboarding(
                name = a.name.take(OnboardingQuestions.NAME_MAX_LENGTH),
                goal = a.goal,
                distractions = a.distractions,
                phoneTime = a.phoneTime,
                sessionLength = a.sessionLength,
                dailyGoal = a.dailyGoal,
                dailyGoalMinutes = a.dailyGoalMinutes,
                source = a.source,
                completedAt = now,
            )
        }
    }
}

/** What is known about the signed-in person. [uid] is the Firebase uid: the key of everything stored. */
data class UserProfile(
    val uid: String,
    val displayName: String,
    /** The registered email (read only here: changing it needs re-verification, which is a different feature). */
    val email: String,
    val provider: AuthProvider,
    /** "" = initials; otherwise one of [ProfileRules.AVATAR_IDS]. A [photoB64] wins over it. */
    val avatarId: String,
    /** Small JPEG (see ProfilePhotos), Base64. null = no photo. */
    val photoB64: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val onboarding: ProfileOnboarding?,
)

/** A profile plus what still has to reach the server. Kept on the phone, one record per account. */
data class LocalRecord(
    val profile: UserProfile,
    /** The profile fields (name, avatar) changed here, or were never compared with the server. */
    val dirtyProfile: Boolean,
    /** The onboarding answers were never confirmed on / uploaded to the server. */
    val dirtyOnboarding: Boolean,
    /** The photo was changed or removed here. */
    val dirtyPhoto: Boolean,
) {
    val pending: Boolean get() = dirtyProfile || dirtyOnboarding || dirtyPhoto
}

enum class SyncStatus {
    /** Phone and server agree. */
    SYNCED,
    /** Talking to the server right now. */
    SYNCING,
    /** No internet / server too slow. Everything is safe on the phone and goes up automatically later. */
    OFFLINE,
    /** The server refused or failed. Retry is offered. */
    ERROR,
}

sealed interface ProfileState {
    /** Nobody is logged in. */
    data object SignedOut : ProfileState

    /** Logged in, the profile is being prepared (only for a moment at start). */
    data object Loading : ProfileState

    data class Ready(
        val profile: UserProfile,
        val sync: SyncStatus,
        /** Human text for [SyncStatus.OFFLINE] / [SyncStatus.ERROR]. */
        val message: String? = null,
        /** Something changed here that the server doesn't have yet. */
        val pending: Boolean = false,
    ) : ProfileState
}

/** The photo part of an edit. */
sealed interface PhotoChange {
    data object Keep : PhotoChange
    data object Remove : PhotoChange
    data class Set(val base64: String) : PhotoChange
}

sealed interface ProfileResult {
    /** Stored on the phone. [onServer] = the server has it too; false = it will follow when online. */
    data class Saved(val onServer: Boolean) : ProfileResult
    data class Invalid(val message: String) : ProfileResult
    data object NotSignedIn : ProfileResult
}

/** Plain rules (no Android classes), unit tested in ProfileRulesTest. */
object ProfileRules {

    /** Preset avatars. Ids are stored; the look (icon, colours) lives in the UI. */
    val AVATAR_IDS: List<String> = listOf("leaf", "moon", "bolt", "star", "flame", "wave", "peak", "heart")

    /** The server rule for the photo node allows 120000 characters; stay well below it. */
    const val MAX_PHOTO_CHARS = 100_000

    fun cleanName(raw: String): String = AuthValidation.cleanName(raw)

    fun nameError(raw: String): String? = AuthValidation.nameError(raw)

    fun isValidAvatar(id: String): Boolean = id.isEmpty() || id in AVATAR_IDS

    /** "Ayşe Yılmaz" -> "AY"; "sam" -> "S"; empty -> "?". */
    fun initials(name: String): String {
        val words = name.trim().split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return "?"
        val letters = words.take(2).mapNotNull { w -> w.firstOrNull { it.isLetterOrDigit() } }
        return if (letters.isEmpty()) "?" else letters.joinToString("").uppercase()
    }

    fun encodeIds(ids: List<String>): String = ids.joinToString(",")

    fun decodeIds(raw: String?): List<String> =
        raw.orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }

    /** The label of an option id, or null for an id this version doesn't know. */
    fun optionLabel(questionId: String, optionId: String?): String? {
        if (optionId == null) return null
        return OnboardingQuestions.all.firstOrNull { it.id == questionId }
            ?.options?.firstOrNull { it.id == optionId }?.label
    }

    fun durationText(minutes: Int): String = when {
        minutes < 60 -> "$minutes minutes"
        minutes % 60 == 0 -> if (minutes == 60) "1 hour" else "${minutes / 60} hours"
        else -> "${minutes / 60} h ${minutes % 60} min"
    }

    /** "1 hour", "5+ hours", or the typed minutes for a custom goal. */
    fun dailyGoalText(goalId: String?, customMinutes: Int?): String? = when {
        goalId == null -> null
        goalId == OnboardingQuestions.DAILY_GOAL_CUSTOM_OPTION ->
            customMinutes?.let { durationText(it) } ?: optionLabel(OnboardingQuestions.DAILY_GOAL, goalId)
        else -> optionLabel(OnboardingQuestions.DAILY_GOAL, goalId)
    }
}

/** Which copy wins when the phone and the server both have a profile. */
object ProfileMerge {
    enum class Winner { LOCAL, REMOTE }

    /**
     * @param localDirty the phone has changes the server has not seen (or a fresh, never compared record)
     * @param localUpdatedAt when the phone's copy was last changed (0 = never edited, only created from the login)
     * @param remoteUpdatedAt the server copy's time, or null when the server has no profile yet
     *
     * Nothing on the server -> upload the phone's copy. Nothing changed here -> take the server's.
     * Changed here -> the newer one wins, so an old offline edit can't wipe a newer edit from another phone.
     */
    fun winner(localDirty: Boolean, localUpdatedAt: Long, remoteUpdatedAt: Long?): Winner = when {
        remoteUpdatedAt == null -> Winner.LOCAL
        !localDirty -> Winner.REMOTE
        localUpdatedAt >= remoteUpdatedAt -> Winner.LOCAL
        else -> Winner.REMOTE
    }
}
