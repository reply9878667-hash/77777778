package com.focusmode.app.data.profile

import android.content.Context
import com.focusmode.app.data.OnboardingStore
import com.focusmode.app.data.auth.AuthRepository
import com.focusmode.app.data.auth.AuthSession
import com.focusmode.app.data.auth.AuthUser
import com.focusmode.app.data.online.FirebaseGateway
import com.focusmode.app.data.online.OnlineConfig
import com.focusmode.app.data.online.OnlineException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * The single entry point of the profile system. The UI reads [state] and calls [updateProfile] / [refresh];
 * nothing else of data/profile is needed.
 *
 * Who the profile belongs to: it follows [AuthRepository.session]. Whenever the logged-in uid changes, the profile of
 * THAT uid is loaded (phone copy first, then the server). A record is stored and shown only under its own uid, and
 * every server call re-checks that Firebase is signed in as that uid.
 *
 * Onboarding answers: they are saved on the phone before any account exists (OnboardingStore). The first time an
 * account has no phone copy, the unclaimed answers are moved into its record and marked claimed, so they belong to
 * exactly one account. On the first sync the server is asked first: if the account already has answers there (login
 * on a second phone) the server's answers win, otherwise the phone's answers are uploaded once.
 *
 * Only the name, email, sign-in type and avatar (plus "onboarding finished") go to the server. The photo and the
 * onboarding answers stay on the phone.
 *
 * Offline-first: every edit is stored on the phone at once and flagged; syncing runs right after, again when the
 * connection comes back, at every start and whenever the profile screen opens. One sync at a time (mutex).
 */
class ProfileRepository private constructor(
    context: Context,
    private val auth: AuthRepository,
) {
    private val appContext = context.applicationContext
    private val store = ProfileStore.get(appContext)
    private val onboardingStore = OnboardingStore.get(appContext)
    private val remote = ProfileRemote(appContext)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mutex = Mutex()

    @Volatile private var currentUid: String? = null

    private val _state = MutableStateFlow<ProfileState>(
        if (auth.session.value is AuthSession.SignedIn) ProfileState.Loading else ProfileState.SignedOut
    )
    val state: StateFlow<ProfileState> = _state.asStateFlow()

    init {
        scope.launch {
            auth.session
                .map { (it as? AuthSession.SignedIn)?.user }
                .distinctUntilChanged { a, b -> a?.uid == b?.uid }
                .collect { user -> onUser(user) }
        }
        // Back online: send whatever is still waiting.
        scope.launch {
            FirebaseGateway.connected.filter { it }.collect {
                val ready = _state.value as? ProfileState.Ready
                if (ready != null && ready.pending && ready.sync != SyncStatus.SYNCING) syncNow(ready.profile.uid)
            }
        }
    }

    // ---- Public API ------------------------------------------------------------------------------

    /** Compares the phone's copy with the server again (profile screen opens, Retry button). */
    fun refresh() {
        val uid = currentUid ?: return
        scope.launch { syncNow(uid) }
    }

    /**
     * Saves an edit: stored on the phone first, then sent to the server. The result says whether the server has it
     * already; if not, it follows by itself when the connection is back.
     */
    suspend fun updateProfile(rawName: String, avatarId: String, photo: PhotoChange): ProfileResult {
        val uid = currentUid ?: return ProfileResult.NotSignedIn
        val name = ProfileRules.cleanName(rawName)
        ProfileRules.nameError(name)?.let { return ProfileResult.Invalid(it) }
        if (!ProfileRules.isValidAvatar(avatarId)) return ProfileResult.Invalid("Pick one of the avatars.")
        if (photo is PhotoChange.Set && (photo.base64.isEmpty() || photo.base64.length > ProfileRules.MAX_PHOTO_CHARS)) {
            return ProfileResult.Invalid("That picture is too large. Choose another one.")
        }

        var nameChanged = false
        var needsSync = false
        mutex.withLock {
            if (currentUid != uid) return ProfileResult.NotSignedIn
            val rec = store.load(uid) ?: return ProfileResult.NotSignedIn
            val p = rec.profile
            val newPhoto = when (photo) {
                PhotoChange.Keep -> p.photoB64
                PhotoChange.Remove -> null
                is PhotoChange.Set -> photo.base64
            }
            val photoChanged = newPhoto != p.photoB64
            val profileChanged = p.displayName != name || p.avatarId != avatarId
            if (!photoChanged && !profileChanged) return ProfileResult.Saved(onServer = !rec.pending)
            nameChanged = p.displayName != name
            needsSync = profileChanged
            val updated = rec.copy(
                profile = p.copy(
                    displayName = name,
                    avatarId = avatarId,
                    photoB64 = newPhoto,
                    updatedAt = if (profileChanged) FirebaseGateway.serverNow() else p.updatedAt,
                ),
                // The photo is kept on the phone only: it is never uploaded, so it never makes the profile "pending".
                dirtyProfile = rec.dirtyProfile || profileChanged,
            )
            store.save(updated)
            val before = (_state.value as? ProfileState.Ready)?.sync ?: SyncStatus.SYNCED
            publish(updated, if (profileChanged) SyncStatus.SYNCING else before)
        }
        if (nameChanged) auth.applyProfileName(name)
        // A new photo alone needs no network at all.
        if (needsSync) syncNow(uid)
        val now = _state.value as? ProfileState.Ready
        return ProfileResult.Saved(onServer = now != null && !now.pending && now.sync == SyncStatus.SYNCED)
    }

    /**
     * Task 3: a brand-new account on a phone whose onboarding answers belonged to nobody (or to somebody else) has
     * just done its own onboarding. [OnboardingStore.saveAnswers] kept the answers unclaimed; this moves them into
     * the logged-in account's record, once, and syncs. An account that already has answers is never touched.
     */
    suspend fun claimPendingOnboarding() {
        val uid = currentUid ?: return
        mutex.withLock {
            if (currentUid != uid) return
            val rec = store.load(uid) ?: return
            if (rec.profile.onboarding != null) {
                // This account already has answers (create-once): the ones just given are consumed, not kept for
                // some later account.
                if (onboardingStore.unclaimedAnswers() != null) onboardingStore.markClaimed(uid)
            } else {
                claimIfPending(rec)?.let { publish(it, SyncStatus.SYNCING) }
            }
        }
        syncNow(uid)
    }

    /** Answers waiting on the phone go into [rec] (create-once: a record that has answers keeps them). */
    private fun claimIfPending(rec: LocalRecord): LocalRecord? {
        if (rec.profile.onboarding != null) return null
        val answers = onboardingStore.unclaimedAnswers() ?: return null
        val onboarding = ProfileOnboarding.from(answers, FirebaseGateway.serverNow()) ?: return null
        val updated = rec.copy(profile = rec.profile.copy(onboarding = onboarding), dirtyOnboarding = true)
        store.save(updated)
        // Only after the answers are safe in this account's own record are they marked as taken.
        onboardingStore.markClaimed(rec.profile.uid)
        return updated
    }

    // ---- Who is logged in ------------------------------------------------------------------------

    private suspend fun onUser(user: AuthUser?) {
        if (user == null) {
            val previous = currentUid
            currentUid = null
            _state.value = ProfileState.SignedOut
            // The server keeps the profile; the phone's copy goes unless it still holds unsent changes.
            if (previous != null) mutex.withLock { store.deleteIfSynced(previous) }
            return
        }
        currentUid = user.uid
        // A restart between "answers saved" and "answers moved into the account" is finished here.
        val rec = mutex.withLock { ensureLocal(user).let { claimIfPending(it) ?: it } }
        publish(rec, SyncStatus.SYNCING)
        syncNow(user.uid)
    }

    /** The phone's record for [user], created (from the login and any unclaimed onboarding answers) if missing. */
    private fun ensureLocal(user: AuthUser): LocalRecord {
        store.load(user.uid)?.let { return it }
        val now = FirebaseGateway.serverNow()
        val answers = onboardingStore.unclaimedAnswers()
        val onboarding = answers?.let { ProfileOnboarding.from(it, now) }
        val rec = LocalRecord(
            profile = UserProfile(
                uid = user.uid,
                // A login without a name (some Google accounts) still gets a readable one.
                displayName = user.name.ifBlank { user.email.substringBefore('@') }.ifBlank { "Me" },
                email = user.email,
                provider = user.provider,
                avatarId = "",
                photoB64 = null,
                createdAt = now,
                // 0 = "never edited": a profile that already exists on the server wins over this fresh copy.
                updatedAt = 0L,
                onboarding = onboarding,
            ),
            dirtyProfile = true,
            dirtyOnboarding = onboarding != null,
            dirtyPhoto = false,
        )
        store.save(rec)
        // Only after the answers are safe in the account's own record are they marked as taken.
        if (answers != null) onboardingStore.markClaimed(user.uid)
        return rec
    }

    // ---- Sync ------------------------------------------------------------------------------------

    private suspend fun syncNow(uid: String) {
        if (!OnlineConfig.configured) {
            mutex.withLock {
                val rec = store.load(uid) ?: return
                publish(rec, SyncStatus.OFFLINE, "Online storage isn't set up in this build. Your profile is saved on this phone.")
            }
            return
        }
        mutex.withLock {
            if (currentUid != uid) return
            val rec = store.load(uid) ?: return
            publish(rec, SyncStatus.SYNCING)
            try {
                val server = remote.fetch(uid)
                var p = rec.profile
                val now = FirebaseGateway.serverNow()

                // 1. Onboarding: only "name + finished at" is on the server (written once). The phone keeps the full
                //    answers; a phone that has none (login on a new phone) takes the short record.
                if (server.onboarding != null) {
                    if (p.onboarding == null) p = p.copy(onboarding = server.onboarding)
                } else if (p.onboarding != null) {
                    remote.writeOnboarding(uid, p.onboarding!!)
                }

                // 2. Name / avatar.
                val rp = server.profile
                val nameBefore = p.displayName
                if (rp == null || ProfileMerge.winner(rec.dirtyProfile, p.updatedAt, rp.updatedAt) == ProfileMerge.Winner.LOCAL) {
                    p = p.copy(
                        updatedAt = if (p.updatedAt == 0L) now else p.updatedAt,
                        createdAt = rp?.createdAt?.takeIf { it > 0L } ?: p.createdAt,
                    )
                    remote.writeProfile(uid, p)
                } else {
                    p = p.copy(
                        displayName = rp.displayName.ifBlank { p.displayName },
                        avatarId = if (ProfileRules.isValidAvatar(rp.avatar)) rp.avatar else "",
                        createdAt = rp.createdAt.takeIf { it > 0L } ?: p.createdAt,
                        updatedAt = rp.updatedAt,
                    )
                }

                // 3. The photo is not synced: it stays exactly as it is on this phone.

                val done = LocalRecord(p, dirtyProfile = false, dirtyOnboarding = false, dirtyPhoto = false)
                store.save(done)
                publish(done, SyncStatus.SYNCED)
                if (p.displayName != nameBefore) auth.applyProfileName(p.displayName)
            } catch (e: CancellationException) {
                throw e
            } catch (e: OnlineException) {
                val latest = store.load(uid) ?: rec
                when (e.kind) {
                    OnlineException.Kind.OFFLINE, OnlineException.Kind.TIMEOUT ->
                        publish(latest, SyncStatus.OFFLINE, "You're offline. Your changes are saved on this phone and will sync when you're back online.")
                    OnlineException.Kind.PERMISSION ->
                        publish(latest, SyncStatus.ERROR, "The server refused to save your profile. Make sure the database rules from the setup guide are published.")
                    else ->
                        publish(latest, SyncStatus.ERROR, "Couldn't reach your profile storage. Try again in a moment.")
                }
            } catch (_: Exception) {
                val latest = store.load(uid) ?: rec
                publish(latest, SyncStatus.ERROR, "Something went wrong while syncing. Try again in a moment.")
            }
        }
    }

    private fun publish(rec: LocalRecord, sync: SyncStatus, message: String? = null) {
        // Never show a record that isn't the logged-in account's.
        if (currentUid != rec.profile.uid) return
        _state.value = ProfileState.Ready(rec.profile, sync, message, pending = rec.pending)
    }

    companion object {
        @Volatile private var instance: ProfileRepository? = null

        fun get(context: Context): ProfileRepository =
            instance ?: synchronized(this) {
                instance ?: ProfileRepository(context.applicationContext, AuthRepository.get(context.applicationContext))
                    .also { instance = it }
            }
    }
}
