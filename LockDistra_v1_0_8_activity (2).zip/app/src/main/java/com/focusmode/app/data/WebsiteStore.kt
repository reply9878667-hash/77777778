package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Saved website-blocking settings: which apps have the option switched on and which sites each
 * one blocks. Kept in device-protected storage like the other stores, so the rules are back
 * right after a restart. Every change is checked against [WebsitePolicy] using the live focus
 * state, so a running session's locks apply no matter which screen calls.
 */
class WebsiteStore private constructor(private val context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "website_blocking")

    private val _state = MutableStateFlow(read())
    val state: StateFlow<WebsiteState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _state.value = read()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun current(): WebsiteState = read()

    private fun focus(): FocusState = FocusStore.get(context).current()

    private fun read(): WebsiteState {
        val apps = HashSet(prefs.getStringSet(K_APPS, emptySet()) ?: emptySet())
        val rules = LinkedHashMap<String, MutableList<WebsiteRule>>()
        for (entry in ListCodec.decode(prefs.getString(K_RULES, null))) {
            val (pkg, body) = ListCodec.unpair(entry) ?: continue
            val bar = body.lastIndexOf('|')
            if (bar <= 0 || body.length - bar - 1 != 2) continue
            val domain = body.substring(0, bar)
            val flags = body.substring(bar + 1)
            rules.getOrPut(pkg) { ArrayList() }
                .add(WebsiteRule(domain, enabled = flags[0] == '1', subdomains = flags[1] == '1'))
        }
        return WebsiteState(apps, rules)
    }

    private fun save(apps: Set<String>, rules: Map<String, List<WebsiteRule>>) {
        val encoded = rules.flatMap { (pkg, list) ->
            list.map {
                ListCodec.pair(pkg, "${it.domain}|${if (it.enabled) 1 else 0}${if (it.subdomains) 1 else 0}")
            }
        }
        // commit() so a rule is on disk before the service can be asked about it; the lists are tiny.
        prefs.edit()
            .putStringSet(K_APPS, HashSet(apps))
            .putString(K_RULES, ListCodec.encode(encoded))
            .commit()
    }

    /**
     * Switches website blocking for [pkg] on or off. The first time it goes on for a known app its
     * usual domains are filled in, so the switch does something straight away.
     */
    @Synchronized
    fun setAppEnabled(pkg: String, on: Boolean): Boolean {
        val s = read()
        val f = focus()
        val next = WebsiteEdits.setAppEnabled(s, pkg, on, WebsitePolicy.canTighten(f), WebsitePolicy.canLoosen(f))
            ?: return false
        if (next !== s) save(next.enabledApps, next.rules)
        return true
    }

    @Synchronized
    fun addSite(pkg: String, raw: String, subdomains: Boolean): WebsiteRules.Result {
        val s = read()
        val change = WebsiteEdits.addSite(s, pkg, raw, subdomains, WebsitePolicy.canTighten(focus()))
        if (change.result == WebsiteRules.Result.OK) save(change.state.enabledApps, change.state.rules)
        return change.result
    }

    /** Adds every site typed or pasted in [raw] (comma, space or line separated) in one go. */
    @Synchronized
    fun addSites(pkg: String, raw: String, subdomains: Boolean): WebsiteEdits.Bulk {
        val s = read()
        val bulk = WebsiteEdits.addSites(s, pkg, raw, subdomains, WebsitePolicy.canTighten(focus()))
        if (bulk.added.isNotEmpty()) save(bulk.state.enabledApps, bulk.state.rules)
        return bulk
    }

    /** Replaces [oldDomain] with whatever was typed. Editing loosens a rule, so it follows the delete lock. */
    @Synchronized
    fun editSite(pkg: String, oldDomain: String, raw: String, subdomains: Boolean): WebsiteRules.Result {
        val s = read()
        val change = WebsiteEdits.editSite(s, pkg, oldDomain, raw, subdomains, WebsitePolicy.canLoosen(focus()))
        if (change.result == WebsiteRules.Result.OK) save(change.state.enabledApps, change.state.rules)
        return change.result
    }

    @Synchronized
    fun removeSite(pkg: String, domain: String): Boolean {
        val s = read()
        val next = WebsiteEdits.removeSite(s, pkg, domain, WebsitePolicy.canLoosen(focus())) ?: return false
        save(next.enabledApps, next.rules)
        return true
    }

    @Synchronized
    fun setSiteEnabled(pkg: String, domain: String, on: Boolean): Boolean {
        val s = read()
        val f = focus()
        val next = WebsiteEdits.setSiteEnabled(s, pkg, domain, on, WebsitePolicy.canTighten(f), WebsitePolicy.canLoosen(f))
            ?: return false
        if (next !== s) save(next.enabledApps, next.rules)
        return true
    }

    companion object {
        private const val K_APPS = "apps_on"
        private const val K_RULES = "rules"

        @Volatile
        private var instance: WebsiteStore? = null

        fun get(context: Context): WebsiteStore =
            instance ?: synchronized(this) {
                instance ?: WebsiteStore(context.applicationContext).also { instance = it }
            }
    }
}
