package com.focusmode.app.ui.tips

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Counts how much the app has been used and which hints were already seen. Stored on this phone only. */
class FeatureTipsStore private constructor(context: Context) {
    private val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<TipsState> = _state.asStateFlow()

    fun recordOpen() = update { it.copy(opens = it.opens + 1) }

    fun recordSessionStart() = update { it.copy(sessions = it.sessions + 1) }

    fun markShown(now: Long = System.currentTimeMillis()) = update { it.copy(lastShownAt = now) }

    fun markSeen(id: String) = update { it.copy(seen = it.seen + id) }

    fun setEnabled(on: Boolean) = update { it.copy(enabled = on) }

    /** "Show tips again": every hint can appear again (usage counts are kept). */
    fun reset() = update { it.copy(enabled = true, seen = emptySet(), lastShownAt = 0L) }

    private fun update(change: (TipsState) -> TipsState) {
        val next = change(_state.value)
        _state.value = next
        prefs.edit()
            .putBoolean(KEY_ENABLED, next.enabled)
            .putInt(KEY_OPENS, next.opens)
            .putInt(KEY_SESSIONS, next.sessions)
            .putStringSet(KEY_SEEN, next.seen)
            .putLong(KEY_LAST, next.lastShownAt)
            .apply()
    }

    private fun read() = TipsState(
        enabled = prefs.getBoolean(KEY_ENABLED, true),
        opens = prefs.getInt(KEY_OPENS, 0),
        sessions = prefs.getInt(KEY_SESSIONS, 0),
        seen = prefs.getStringSet(KEY_SEEN, emptySet())?.toSet() ?: emptySet(),
        lastShownAt = prefs.getLong(KEY_LAST, 0L),
    )

    companion object {
        private const val FILE = "feature_tips"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_OPENS = "opens"
        private const val KEY_SESSIONS = "sessions"
        private const val KEY_SEEN = "seen"
        private const val KEY_LAST = "last_shown"

        @Volatile private var instance: FeatureTipsStore? = null

        fun get(context: Context): FeatureTipsStore =
            instance ?: synchronized(this) {
                instance ?: FeatureTipsStore(context.applicationContext).also { instance = it }
            }
    }
}
