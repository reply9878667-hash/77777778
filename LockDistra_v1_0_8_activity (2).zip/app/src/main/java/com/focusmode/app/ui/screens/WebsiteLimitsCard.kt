package com.focusmode.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.WebsiteBrowsers
import com.focusmode.app.data.WebsiteLimit
import com.focusmode.app.data.WebsiteLimitRules
import com.focusmode.app.data.WebsiteLimitState
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.formatMinutes
import com.focusmode.app.ui.theme.FocusTheme

/**
 * What the Website Usage Limits card can do. The ViewModel applies the session locks ([locked] only greys the controls
 * out); [onAdd] / [onEdit] answer with a [WebsiteLimitRules.Result] so the editor can say what is wrong.
 */
internal class WebsiteLimitActions(
    val locked: Boolean,
    val onAdd: (raw: String, minutes: Int) -> WebsiteLimitRules.Result,
    val onEdit: (old: String, raw: String, minutes: Int) -> WebsiteLimitRules.Result,
    val onRemove: (domain: String) -> Unit,
    val onEnabled: (domain: String, on: Boolean) -> Unit,
    /** Asked when the list is opened, so a new day shows zero used instead of yesterday's number. */
    val onRefresh: () -> Unit,
)

/**
 * Website Usage Limits: a daily time limit per website, in the Blocking section right under Website Blocking. The
 * two are separate cards with separate controls: Website Blocking closes sites during focus sessions, this limits the
 * time spent on a site each day. Each row shows the site, today's used time against its limit, a progress bar, and its
 * own edit / delete / ON-OFF controls.
 *
 * Honest scope: time is counted in [WebsiteBrowsers.supportedNames] (the address bar tells which site is open), while
 * the browser is in front and the screen is on. Other browsers, in-app web views and sites in background tabs are not
 * counted.
 */
@Composable
internal fun WebsiteLimitsCard(
    state: WebsiteLimitState,
    actions: WebsiteLimitActions,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    var open by remember { mutableStateOf(false) }
    // null = closed, "" = adding, anything else = editing that domain
    var editorFor by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(open) { if (open) actions.onRefresh() }

    val activeCount = state.limits.count { it.enabled }

    FocusCard(
        modifier = modifier,
        onClick = { open = !open },
        padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        highlight = state.hasActive
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Website Usage Limits", style = MaterialTheme.typography.titleMedium)
                    Text(
                        when {
                            state.hasActive -> "ON • $activeCount website limit${if (activeCount == 1) "" else "s"}"
                            state.limits.isNotEmpty() -> "OFF • ${state.limits.size} saved"
                            else -> "Set a daily time limit for any website"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.hasActive) c.accent else c.muted
                    )
                }
                Icon(
                    if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    if (open) "Hide website limits" else "Show website limits",
                    tint = c.muted
                )
            }

            if (open) {
                Spacer(Modifier.height(12.dp))
                if (state.limits.isEmpty()) {
                    Text(
                        "No website limits yet. Add YouTube, Instagram or any site and choose how long you can use it each day.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    state.limits.forEach { limit ->
                        WebsiteLimitRow(
                            limit = limit,
                            usedMs = state.usedFor(limit.domain),
                            locked = actions.locked,
                            onEdit = { editorFor = limit.domain },
                            onRemove = { actions.onRemove(limit.domain) },
                            onEnabled = { actions.onEnabled(limit.domain, it) },
                        )
                    }
                }
                TextButton(
                    onClick = { editorFor = "" },
                    enabled = !actions.locked && state.limits.size < WebsiteLimitRules.MAX_LIMITS
                ) {
                    Text(
                        "Add website limit",
                        color = if (!actions.locked) c.accent else c.muted
                    )
                }
                Text(
                    if (actions.locked) "Limits are locked right now. They can be changed again when the session ends."
                    else "Counted in ${WebsiteBrowsers.supportedNames} while the site is open on screen. " +
                        "Every page and subdomain of a site counts toward its limit, and the time starts again at midnight. " +
                        "Other browsers, in-app web views and background tabs are not counted.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
                )
            }
        }
    }

    editorFor?.let { editing ->
        val current = state.limitFor(editing)
        WebsiteLimitEditorSheet(
            editing = editing.ifEmpty { null },
            initialMinutes = current?.limitMin ?: WebsiteLimitRules.DEFAULT_MINUTES,
            onSave = { raw, minutes ->
                if (editing.isEmpty()) actions.onAdd(raw, minutes) else actions.onEdit(editing, raw, minutes)
            },
            onRemove = { actions.onRemove(editing); editorFor = null },
            onDismiss = { editorFor = null },
        )
    }
}

@Composable
private fun WebsiteLimitRow(
    limit: WebsiteLimit,
    usedMs: Long,
    locked: Boolean,
    onEdit: () -> Unit,
    onRemove: () -> Unit,
    onEnabled: (Boolean) -> Unit,
) {
    val c = FocusTheme.colors
    val reached = limit.enabled && usedMs >= limit.limitMs
    val nearEnd = limit.enabled && !reached && limit.limitMs - usedMs <= 5 * 60_000L
    val fraction by animateFloatAsState(
        (usedMs.toFloat() / limit.limitMs.toFloat()).coerceIn(0f, 1f), tween(500), label = "siteLimitProgress"
    )
    val barColor = if (reached || nearEnd) c.warning else c.accent
    val usedMin = (usedMs / 60_000L).toInt()
    val tint = if (locked) c.muted.copy(alpha = 0.4f) else c.muted

    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Language, null, tint = if (limit.enabled) c.accent else c.muted, modifier = Modifier.size(22.dp))
            Spacer(Modifier.size(10.dp))
            Column(Modifier.weight(1f)) {
                Text(limit.domain, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                Text(
                    when {
                        !limit.enabled -> "Off • ${formatMinutes(limit.limitMin)} a day"
                        reached -> "Limit reached • ${formatMinutes(limit.limitMin)} a day"
                        else -> "${formatMinutes(usedMin)} of ${formatMinutes(limit.limitMin)} used"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (reached || nearEnd) c.warning else c.muted
                )
            }
            IconButton(onClick = onEdit, enabled = !locked) {
                Icon(Icons.Rounded.Edit, "Edit ${limit.domain}", tint = tint, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onRemove, enabled = !locked) {
                Icon(Icons.Rounded.Delete, "Delete ${limit.domain}", tint = tint, modifier = Modifier.size(18.dp))
            }
            FocusSwitch(checked = limit.enabled, enabled = !locked, onCheckedChange = onEnabled)
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(c.ringTrack)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(if (limit.enabled) fraction else 0f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(3.dp))
                    .background(barColor)
            )
        }
    }
}

/** Add or edit one website limit: the site (typed or picked), then hours and minutes. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun WebsiteLimitEditorSheet(
    editing: String?,
    initialMinutes: Int,
    onSave: (raw: String, minutes: Int) -> WebsiteLimitRules.Result,
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var text by remember { mutableStateOf(editing.orEmpty()) }
    var hours by remember { mutableIntStateOf(initialMinutes / 60) }
    var minutes by remember { mutableIntStateOf(initialMinutes % 60) }
    var error by remember { mutableStateOf<String?>(null) }
    val total = hours * 60 + minutes
    val sliderColors = SliderDefaults.colors(
        thumbColor = c.accent,
        activeTrackColor = c.accent,
        inactiveTrackColor = c.ringTrack,
        activeTickColor = c.accent,
        inactiveTickColor = c.ringTrack,
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (editing == null) "Add website limit" else "Edit website limit",
                style = MaterialTheme.typography.titleLarge
            )
            Text("Daily limit", style = MaterialTheme.typography.bodySmall, color = c.muted)
            Spacer(Modifier.height(14.dp))

            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(300); error = null },
                singleLine = true,
                label = { Text("Website link or name") },
                placeholder = { Text("youtube.com") },
                isError = error != null,
                modifier = Modifier.fillMaxWidth()
            )
            if (error != null) {
                Text(
                    error!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
            }
            if (editing == null) {
                Spacer(Modifier.height(10.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    WebsiteLimitRules.suggestions.forEach { (name, domain) ->
                        SoftChip(text = name, selected = text.trim().equals(domain, ignoreCase = true), onClick = { text = domain; error = null })
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                if (total == 0) "Set a time" else formatMinutes(total),
                style = MaterialTheme.typography.displayMedium,
                color = c.accent
            )
            Spacer(Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(15, 20, 30, 60, 120).forEach { preset ->
                    SoftChip(
                        text = formatMinutes(preset),
                        selected = total == preset,
                        onClick = { hours = preset / 60; minutes = preset % 60; error = null }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Hours", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Stepper(
                    value = hours,
                    onMinus = { if (hours > 0) hours--; error = null },
                    onPlus = { if (hours < 23) hours++; error = null }
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Minutes", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text("$minutes", style = MaterialTheme.typography.titleMedium, color = c.accent)
            }
            Slider(
                value = minutes.toFloat(),
                onValueChange = { minutes = it.toInt(); error = null },
                valueRange = 0f..59f,
                steps = 58,
                colors = sliderColors
            )
            Text(
                "Every page and subdomain of the site counts toward this limit. When it is used up, the site is closed until tomorrow.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )

            Spacer(Modifier.height(20.dp))
            PrimaryButton(
                text = if (editing == null) "Set limit" else "Save changes",
                enabled = total > 0 && text.isNotBlank(),
                onClick = {
                    when (onSave(text, total)) {
                        WebsiteLimitRules.Result.OK -> onDismiss()
                        WebsiteLimitRules.Result.INVALID -> error = "Enter a website link or name, like youtube.com or instagram"
                        WebsiteLimitRules.Result.ALREADY_THERE -> error = "This website already has a limit. Edit that one instead."
                        WebsiteLimitRules.Result.OVERLAPS -> error = "This site overlaps one that already has a limit (a page or subdomain of it)."
                        WebsiteLimitRules.Result.BAD_TIME -> error = "Choose a time of at least 1 minute."
                        WebsiteLimitRules.Result.FULL -> error = "Too many website limits. Delete one first."
                        WebsiteLimitRules.Result.LOCKED -> error = "Changes are locked right now."
                        WebsiteLimitRules.Result.NO_ACCESS -> error = "Allow LockDistra's Accessibility service first, then save again."
                    }
                }
            )
            if (editing != null) {
                TextButton(onClick = onRemove) { Text("Remove limit", color = c.warning) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
