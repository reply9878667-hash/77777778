package com.focusmode.app.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.focusmode.app.data.SourceClassifier
import com.focusmode.app.data.StudyMode
import com.focusmode.app.data.StudyRepository
import com.focusmode.app.data.StudySources
import com.focusmode.app.data.SwitchMessages
import com.focusmode.app.data.StudyVideo
import com.focusmode.app.data.StudyWeb
import com.focusmode.app.ui.components.VideoSkeletonList
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The page script of the web search. It runs inside YouTube's own mobile search page and turns it into LockDistra's Study list:
 *  - every result card is hidden until the app has judged it ([StudyRepository.judgeWeb]); only approved cards show;
 *  - Shorts, ads, channels, playlists, the top bar, the bottom bar and the "more" menus are hidden;
 *  - a tap on a video never opens YouTube's watch page: it is handed to the app, which plays it in LockDistra's own player;
 *    any other link is refused, so the person cannot leave the search;
 *  - when too few cards are approved to fill the screen it scrolls once more so YouTube loads further results.
 * It finds cards by their video link and the smallest block around it (not by YouTube's tag names), so a layout change on
 * YouTube's side does not break it. Set `window.__rwDark` to true before it runs for the dark look.
 *
 * NOTE: this is a Kotlin raw string, so the script must never contain a dollar sign or three double quotes.
 */
internal object StudyWebScript {
    const val JS = """
(function(){
if(window.__rw){return}
window.__rw=1;
var decided={},asked={},scanT=null,kicks=0;
var HIDE=['ytm-mobile-topbar-renderer','.mobile-topbar-header','ytm-pivot-bar-renderer','ytm-chip-cloud-renderer','ytm-reel-shelf-renderer',
'ytm-shorts-lockup-view-model','ytm-shorts-lockup-view-model-v2','ytm-reel-item-renderer','ytm-rich-shelf-renderer','ytm-horizontal-card-list-renderer',
'ytm-promoted-sparkles-web-renderer','ytm-promoted-video-renderer','ytm-search-pyv-renderer','ytm-ad-slot-renderer','ytm-statement-banner-renderer',
'ytm-mealbar-promo-renderer','ytm-compact-channel-renderer','ytm-channel-renderer','ytm-compact-playlist-renderer','ytm-compact-radio-renderer',
'ytm-playlist-renderer','ytm-menu','.media-item-menu','.rw-no'].join(',');
function css(){
 var c=[HIDE+'{display:none!important}',
 '.rw-pend{visibility:hidden!important;height:0!important;min-height:0!important;margin:0!important;padding:0!important;overflow:hidden!important}',
 'ytm-app,body{padding-top:0!important}',
 '*{-webkit-tap-highlight-color:transparent;-webkit-touch-callout:none}'];
 if(window.__rwDark){
  c.push('html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}');
  c.push('img,video,picture,canvas{filter:invert(1) hue-rotate(180deg)!important}');
 }
 var s=document.createElement('style');s.id='rw-css';s.textContent=c.join('\n');
 (document.head||document.documentElement).appendChild(s);
}
function idOf(h){var m=/[?&]v=([A-Za-z0-9_-]{11})(?:[&#]|${'$'})/.exec(h||'');return(m&&h.indexOf('/watch')>=0)?m[1]:''}
var CARD='ytm-video-with-context-renderer,ytm-compact-video-renderer,ytm-rich-item-renderer,ytm-search-video-renderer,ytm-video-card-renderer';
function cardOf(a,id){
 var c=a.closest?a.closest(CARD):null;if(c)return c;
 var el=a,up=a.parentElement,i,j,ls,h,o,stop,tn;
 for(i=0;i<8&&up&&up!==document.body;i++){
  tn=(up.tagName||'').toUpperCase();
  if(tn.indexOf('SECTION')>=0||tn.indexOf('LIST')>=0||tn.indexOf('GRID')>=0||tn==='MAIN'||tn==='YTM-APP')break;
  ls=up.querySelectorAll('a[href*="/watch"],a[href*="/shorts/"]');stop=false;
  for(j=0;j<ls.length;j++){h=ls[j].getAttribute('href')||'';o=idOf(h);if(h.indexOf('/shorts/')>=0||(o&&o!==id)){stop=true;break}}
  if(stop)break;
  el=up;up=up.parentElement;
 }
 return el;
}
function info(card){
 var t=card.innerText||'',ln=t.split('\n').map(function(s){return s.trim()}).filter(function(s){return s}),dur='',title='',i;
 for(i=0;i<ln.length;i++){if(/^(\d{1,2}:)?\d{1,2}:\d{2}${'$'}/.test(ln[i])){dur=ln[i];break}}
 var h=card.querySelector('h3,h4,.media-item-headline,.compact-media-item-headline,[role=heading]');
 if(h)title=(h.innerText||'').trim();
 if(!title){for(i=0;i<ln.length;i++){if(ln[i]!==dur&&ln[i].length>8){title=ln[i];break}}}
 return{title:title.slice(0,200),text:t.slice(0,400),dur:dur};
}
function q(s){return document.querySelectorAll(s).length}
function stats(){try{RW.onStats(q('.rw-pend'),q('.rw-ok'),q('.rw-no'))}catch(e){}}
function mark(card,id,st){card.setAttribute('data-rw-id',id);card.classList.remove('rw-pend','rw-ok','rw-no');card.classList.add(st)}
function scan(){
 if(!document.getElementById('rw-css'))css();
 var as=document.querySelectorAll('a[href*="/watch"],a[href*="/shorts/"]'),i,a,h,id,card,batch=[],inf;
 for(i=0;i<as.length;i++){
  a=as[i];h=a.getAttribute('href')||'';
  if(h.indexOf('/shorts/')>=0){
   card=a.closest?(a.closest(CARD+',ytm-reel-item-renderer,ytm-shorts-lockup-view-model')||a):a;
   if(!card.getAttribute('data-rw-s')){card.setAttribute('data-rw-s','1');card.classList.add('rw-no')}
   continue;
  }
  id=idOf(h);if(!id)continue;
  card=cardOf(a,id);
  if(card.getAttribute('data-rw-id')===id)continue;
  if(decided[id]===1){mark(card,id,'rw-ok');continue}
  if(decided[id]===0){mark(card,id,'rw-no');continue}
  mark(card,id,'rw-pend');
  if(!asked[id]){asked[id]=1;inf=info(card);batch.push({id:id,title:inf.title,text:inf.text,dur:inf.dur})}
 }
 if(batch.length){try{RW.onCards(JSON.stringify(batch))}catch(e){}}else{stats()}
}
function fill(){
 if(q('.rw-pend')>0||kicks>=12)return;
 var d=document.documentElement;
 if(d.scrollHeight-window.innerHeight<window.innerHeight*0.9){kicks++;window.scrollTo(0,d.scrollHeight)}
}
window.__rwDecide=function(ok,no){
 var i,j,els;
 for(i=0;i<ok.length;i++){decided[ok[i]]=1;els=document.querySelectorAll('[data-rw-id="'+ok[i]+'"]');for(j=0;j<els.length;j++){els[j].classList.remove('rw-pend');els[j].classList.add('rw-ok')}}
 for(i=0;i<no.length;i++){decided[no[i]]=0;els=document.querySelectorAll('[data-rw-id="'+no[i]+'"]');for(j=0;j<els.length;j++){els[j].classList.remove('rw-pend');els[j].classList.add('rw-no')}}
 stats();fill();
};
function openVideo(id,el){
 var c=el.closest?(el.closest('[data-rw-id]')||el):el,inf=info(c);
 try{RW.onOpen(id,inf.title,inf.dur)}catch(e){}
}
document.addEventListener('click',function(e){
 var t=e.target,a=t&&t.closest?t.closest('a'):null,h,id,card;
 if(a){
  h=a.getAttribute('href')||'';id=idOf(h);
  if(id){e.preventDefault();e.stopImmediatePropagation();openVideo(id,a);return}
  if(h.indexOf('/results')===0){return}
  e.preventDefault();e.stopImmediatePropagation();return;
 }
 card=t&&t.closest?t.closest('[data-rw-id]'):null;
 if(card&&card.classList.contains('rw-ok')){e.preventDefault();e.stopImmediatePropagation();openVideo(card.getAttribute('data-rw-id'),card)}
},true);
function later(){if(scanT)return;scanT=setTimeout(function(){scanT=null;try{scan()}catch(e){}},120)}
function start(){
 if(!document.body){setTimeout(start,50);return}
 css();
 new MutationObserver(later).observe(document.body,{childList:true,subtree:true});
 scan();
 setInterval(function(){try{scan()}catch(e){}},1500);
}
start();
})();
"""
}

private const val WEB_FAIL_TITLE = "Could not load the search"
private const val WEB_FAIL_BODY = "Check your internet and try again."

/** What the page tells the app. Every method runs on a WebView thread; inputs are checked before use. */
private class WebBridge(
    private val onCards: (String) -> Unit,
    private val onOpen: (String, String, String) -> Unit,
    private val onStats: (Int, Int, Int) -> Unit,
) {
    @JavascriptInterface fun onCards(json: String) = onCards.invoke(json.take(60_000))
    @JavascriptInterface fun onOpen(id: String, title: String, dur: String) = onOpen.invoke(id, title.take(200), dur.take(12))
    @JavascriptInterface fun onStats(pending: Int, ok: Int, no: Int) = onStats.invoke(pending, ok, no)
}

/**
 * Study search read from YouTube's own search page, shown as LockDistra's own list (see [StudyWebScript]). It needs no API
 * quota. Videos still pass the Study rules before they appear and play in LockDistra's player ([onPlay]).
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun StudyWebSearch(
    query: String,
    queryIsStudy: Boolean,
    repo: StudyRepository,
    onPlay: (StudyVideo) -> Unit,
    modifier: Modifier = Modifier,
    /** Part 4/4: raised by the screen when the connection came back; a failed web search then loads again by itself. */
    retryTick: Int = 0,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val main = remember { Handler(Looper.getMainLooper()) }
    val studyQuery by rememberUpdatedState(queryIsStudy)
    val currentQuery by rememberUpdatedState(query)
    val play by rememberUpdatedState(onPlay)

    var progress by remember { mutableIntStateOf(0) }
    var pendingN by remember { mutableIntStateOf(0) }
    var okN by remember { mutableIntStateOf(0) }
    var noN by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    // What went wrong in the Web search, named for this source (a lost connection, YouTube refusing the page, a dead page engine).
    var failTitle by remember { mutableStateOf(WEB_FAIL_TITLE) }
    var failBody by remember { mutableStateOf(WEB_FAIL_BODY) }
    var settled by remember { mutableStateOf(false) }
    val holder = remember { arrayOfNulls<WebView>(1) }
    val dark = c.isDark

    val web = remember {
        val bridge = WebBridge(
            onCards = { json ->
                val cards = StudyWeb.parseCards(json)
                if (cards.isNotEmpty()) scope.launch {
                    val verdict = withContext(Dispatchers.IO) { runCatching { repo.judgeWeb(cards, studyQuery, currentQuery) }.getOrNull() }
                    if (verdict != null) {
                        val script = "(function(o){window.__rwDecide&&window.__rwDecide(o.ok,o.no)})(" + StudyWeb.verdictJson(verdict) + ")"
                        holder[0]?.evaluateJavascript(script, null)
                    }
                }
            },
            onOpen = { id, title, dur ->
                if (StudyWeb.isVideoId(id)) main.post { play(repo.webVideo(id, title, dur)) }
            },
            onStats = { p, ok, no ->
                // Cards were read from the page: the Web source really worked (a consent or empty page has no cards).
                if (p + ok + no > 0) StudySources.tracker.success(StudyMode.WEB)
                main.post { pendingN = p; okN = ok; noN = no }
            },
        )
        WebView(context).apply {
            setBackgroundColor(c.background.toArgb())
            isLongClickable = false
            setOnLongClickListener { true }
            overScrollMode = android.view.View.OVER_SCROLL_NEVER
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            settings.mediaPlaybackRequiresUserGesture = true
            CookieManager.getInstance().setAcceptCookie(true)
            addJavascriptInterface(bridge, "RW")
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) { progress = newProgress }
            }
            webViewClient = object : WebViewClient() {
                private fun inject(view: WebView) {
                    view.evaluateJavascript("window.__rwDark=" + dark + ";" + StudyWebScript.JS, null)
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) { failed = false; failTitle = WEB_FAIL_TITLE; failBody = WEB_FAIL_BODY; inject(view) }
                override fun onPageFinished(view: WebView, url: String?) { inject(view) }

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (!request.isForMainFrame) return false
                    val url = request.url.toString()
                    val id = StudyWeb.videoIdFromUrl(url)
                    if (id.isNotEmpty()) {
                        main.post { play(repo.webVideo(id, "", "")) }
                        return true
                    }
                    // true = refused: only the search page itself (and its cookie notice) may load.
                    return !StudyWeb.isAllowedPage(url)
                }

                // YouTube's page changes address without loading (a single-page app): anything but the search goes back to it.
                override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                    if (url == null || url.startsWith("about:") || StudyWeb.isAllowedPage(url)) return
                    view.stopLoading()
                    view.loadUrl(StudyWeb.searchUrl(currentQuery))
                }

                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (!request.isForMainFrame) return
                    failed = true
                    // The Web source's own failure: a lost connection is NETWORK_ERROR, never "web disabled".
                    StudySources.tracker.failure(
                        StudyMode.WEB,
                        SourceClassifier.fromWebError(
                            timeout = error.errorCode == WebViewClient.ERROR_TIMEOUT,
                            network = error.errorCode == WebViewClient.ERROR_HOST_LOOKUP || error.errorCode == WebViewClient.ERROR_CONNECT || error.errorCode == WebViewClient.ERROR_IO,
                        ),
                    )
                    when (error.errorCode) {
                        WebViewClient.ERROR_HOST_LOOKUP, WebViewClient.ERROR_CONNECT, WebViewClient.ERROR_TIMEOUT, WebViewClient.ERROR_IO -> {
                            failTitle = "Could not reach YouTube"
                            failBody = "Check your internet and try again."
                        }
                        else -> {
                            failTitle = WEB_FAIL_TITLE
                            failBody = "YouTube's search page did not open. Try again."
                        }
                    }
                }

                // The page came, but YouTube refused it (a busy / blocked answer): that is not a lost connection.
                override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                    if (!request.isForMainFrame || errorResponse.statusCode < 400) return
                    failed = true
                    StudySources.tracker.failure(StudyMode.WEB, SourceClassifier.httpFailure(errorResponse.statusCode))
                    if (errorResponse.statusCode == 429 || errorResponse.statusCode == 403) {
                        failTitle = "YouTube web search is busy"
                        failBody = "YouTube is refusing web searches for a moment. Try again in a minute."
                    } else {
                        failTitle = WEB_FAIL_TITLE
                        failBody = "YouTube answered with an error (code ${errorResponse.statusCode}). Try again."
                    }
                }

                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    failed = true
                    StudySources.tracker.failure(StudyMode.WEB, SourceClassifier.webRendererStopped())
                    failTitle = "The web page engine stopped"
                    failBody = "Close the search and open it again."
                    return true
                }
            }
        }
    }
    holder[0] = web

    // A new search (or the first one) loads its own page; the page script runs again for it.
    LaunchedEffect(query) {
        pendingN = 0; okN = 0; noN = 0; failed = false; settled = false; progress = 0
        web.loadUrl(StudyWeb.searchUrl(query))
    }
    // The connection came back while the "could not reach" card was showing: load the same search again, once, without a tap.
    LaunchedEffect(retryTick) {
        if (retryTick > 0 && failed) {
            failed = false; settled = false
            web.loadUrl(StudyWeb.searchUrl(query))
        }
    }
    // "Nothing found" only after the page has stopped changing for a moment.
    LaunchedEffect(query, progress, pendingN, okN, noN, failed) {
        settled = false
        if (progress >= 100 || failed) {
            delay(3000)
            settled = true
        }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, web) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) web.onPause() else if (event == Lifecycle.Event.ON_RESUME) web.onResume()
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            holder[0] = null
            web.stopLoading()
            web.removeJavascriptInterface("RW")
            web.destroy()
        }
    }

    val showSkeleton = okN == 0 && !failed && !settled
    // Cards were found but none passed the study rules = "no study videos". No card found at all = the page was not readable
    // (YouTube changed its page, or a notice came instead): a different problem, said differently.
    val showEmpty = okN == 0 && !failed && settled && pendingN == 0 && noN > 0
    val unreadable = okN == 0 && !failed && settled && pendingN == 0 && noN == 0

    Column(modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(factory = { web }, modifier = Modifier.fillMaxSize())
            if (showSkeleton) {
                Box(Modifier.fillMaxSize().background(c.background)) { VideoSkeletonList() }
            }
            if (progress in 1..99 && okN == 0) {
                LinearProgressIndicator(progress = { progress / 100f }, color = c.accent, modifier = Modifier.fillMaxWidth())
            }
            if (failed) {
                // All three sources failed (API and Direct YouTube were already down): one clear message instead of a web-only one.
                val all = remember(failed, failTitle) { SwitchMessages.allThreeFailed(StudySources.tracker.states.value) }
                Box(Modifier.fillMaxSize().background(c.background).padding(12.dp), contentAlignment = Alignment.TopCenter) {
                    MessageCard(all?.title ?: failTitle, all?.message ?: failBody, "Try again") {
                        failed = false; settled = false; web.loadUrl(StudyWeb.searchUrl(query))
                    }
                }
            } else if (unreadable) {
                Box(Modifier.fillMaxSize().background(c.background).padding(12.dp), contentAlignment = Alignment.TopCenter) {
                    MessageCard(
                        "The web page could not be read",
                        "YouTube's page held no videos the app could read. Try again, or search for another word.", "Try again"
                    ) {
                        settled = false; web.loadUrl(StudyWeb.searchUrl(query))
                    }
                }
            } else if (showEmpty) {
                Box(Modifier.fillMaxSize().background(c.background).padding(12.dp), contentAlignment = Alignment.TopCenter) {
                    MessageCard(
                        "No study videos found",
                        "Only learning videos are shown, so a search for entertainment finds nothing. Try a subject or a chapter name."
                    )
                }
            }
        }
    }
}
