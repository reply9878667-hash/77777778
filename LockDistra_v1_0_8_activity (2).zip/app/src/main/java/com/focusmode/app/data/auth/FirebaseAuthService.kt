package com.focusmode.app.data.auth

import android.content.Context
import com.focusmode.app.data.online.FirebaseGateway
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.resume

/** Internal failure carrying a kind; the repository turns it into [AuthResult.Failure]. */
class AuthException(
    val kind: AuthErrorKind,
    message: String = AuthErrors.message(kind),
    cause: Throwable? = null,
) : Exception(message, cause)

/** The person closed the Google sheet. Not a CancellationException on purpose (that would cancel coroutines). */
class AuthCancelledException : Exception()

enum class SessionCheck { VALID, INVALID, UNKNOWN }

data class GoogleSignInOutcome(val user: AuthUser, val isNewAccount: Boolean)

/**
 * The only class of the account system that talks to Firebase Authentication. It reuses the Firebase app that
 * [FirebaseGateway] starts from BuildConfig, so there is one Firebase app and one login in the whole process.
 *
 * Identity rule (important for Online Approval): a phone already has an ANONYMOUS Firebase user once it has used
 * online features, and a trusted-phone pairing is bound to that uid. So when an anonymous user exists, sign-up
 * and Google sign-in LINK the new credential to it (the uid does not change). Only logging in to an account that
 * already exists elsewhere changes the uid, and the repository refuses that while a trusted phone is connected.
 */
class FirebaseAuthService(context: Context) {

    private val appContext = context.applicationContext

    private fun auth(): FirebaseAuth {
        val app = FirebaseGateway.app(appContext) ?: throw AuthException(AuthErrorKind.NOT_CONFIGURED)
        return FirebaseAuth.getInstance(app)
    }

    /** True when Firebase is started (configured and the phone is unlocked). */
    fun isReady(): Boolean = FirebaseGateway.app(appContext) != null

    // ---- Email + password ------------------------------------------------------------------------

    suspend fun signUpWithEmail(name: String, email: String, password: String): AuthUser = call {
        val auth = auth()
        val current = auth.currentUser
        if (current != null && !current.isAnonymous) throw AuthException(AuthErrorKind.ALREADY_SIGNED_IN)
        val credential = EmailAuthProvider.getCredential(email, password)
        val user = if (current != null) {
            timed { current.linkWithCredential(credential).await() }.user
        } else {
            timed { auth.createUserWithEmailAndPassword(email, password).await() }.user
        } ?: throw AuthException(AuthErrorKind.UNKNOWN)
        // The name is a nicety: failing to store it must not undo a created account.
        runCatching {
            timed { user.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name).build()).await() }
        }
        toAuthUser(user, nameOverride = name)
    }

    suspend fun signInWithEmail(email: String, password: String): AuthUser = call {
        val auth = auth()
        val current = auth.currentUser
        if (current != null && !current.isAnonymous) throw AuthException(AuthErrorKind.ALREADY_SIGNED_IN)
        val user = timed { auth.signInWithEmailAndPassword(email, password).await() }.user
            ?: throw AuthException(AuthErrorKind.UNKNOWN)
        toAuthUser(user)
    }

    /** Sends the reset mail. An unknown email is reported as success too, so the form can't be used to probe accounts. */
    suspend fun sendPasswordReset(email: String) {
        call {
            try {
                timed { auth().sendPasswordResetEmail(email).await() }
            } catch (_: FirebaseAuthInvalidUserException) {
                // Deliberately silent.
            }
        }
    }

    // ---- Google ----------------------------------------------------------------------------------

    /**
     * @param idToken the Google ID token from Credential Manager
     * @param googleName display name Google gave us (used when Firebase has none yet)
     * @param identityLockedReason non-null when a trusted phone is connected: an EXISTING Google account may
     *   not be signed in to then (it would change the uid), only a brand-new one may be linked.
     */
    suspend fun signInWithGoogle(
        idToken: String,
        googleName: String?,
        identityLockedReason: String?,
    ): GoogleSignInOutcome = call {
        val auth = auth()
        val current = auth.currentUser
        if (current != null && !current.isAnonymous) throw AuthException(AuthErrorKind.ALREADY_SIGNED_IN)
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        var isNew = false
        val result = try {
            if (current != null) {
                // Keep the uid: this Google account becomes this phone's account.
                timed { current.linkWithCredential(credential).await() }.also { isNew = true }
            } else {
                timed { auth.signInWithCredential(credential).await() }
                    .also { isNew = it.additionalUserInfo?.isNewUser == true }
            }
        } catch (e: FirebaseAuthUserCollisionException) {
            if (e.errorCode != "ERROR_CREDENTIAL_ALREADY_IN_USE") throw e
            // This Google account already exists: sign in to it (the uid changes).
            if (identityLockedReason != null) throw AuthException(AuthErrorKind.IDENTITY_LOCKED, identityLockedReason)
            timed { auth.signInWithCredential(e.updatedCredential ?: credential).await() }
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            // A bad / expired Google token is a Google problem, not a "wrong password". A web client id from another
            // Firebase project is the usual reason, so debug builds show what Firebase said.
            val text = AuthErrors.message(AuthErrorKind.GOOGLE_FAILED) +
                if (com.focusmode.app.BuildConfig.DEBUG) " (Firebase: ${e.message.orEmpty()}. Check googleWebClientId belongs to this Firebase project.)" else ""
            throw AuthException(AuthErrorKind.GOOGLE_FAILED, text, e)
        }
        val user = result.user ?: throw AuthException(AuthErrorKind.UNKNOWN)
        GoogleSignInOutcome(toAuthUser(user, fallbackName = googleName), isNew)
    }

    /** Stores the display name on the Firebase account (so every sign-in method shows the same name). */
    suspend fun updateDisplayName(name: String) {
        call {
            val user = auth().currentUser ?: throw AuthException(AuthErrorKind.UNKNOWN)
            timed { user.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(name).build()).await() }
        }
    }

    // ---- Session ---------------------------------------------------------------------------------

    /** Logs out of Firebase. Never throws: logging out must always work. */
    fun signOut() {
        runCatching { auth().signOut() }
    }

    /**
     * The real account user (null for "nobody" and for the anonymous identity), after Firebase has finished
     * loading what it saved. Throws [AuthException] (TIMEOUT) when that takes too long, so the caller can leave
     * a saved login alone instead of wrongly clearing it.
     */
    suspend fun savedAccountUser(): AuthUser? = call {
        val auth = auth()
        val user = timed(5_000L) {
            suspendCancellableCoroutine<FirebaseUser?> { cont ->
                lateinit var listener: FirebaseAuth.AuthStateListener
                listener = FirebaseAuth.AuthStateListener { fa ->
                    fa.removeAuthStateListener(listener)
                    if (cont.isActive) cont.resume(fa.currentUser)
                }
                auth.addAuthStateListener(listener)
                cont.invokeOnCancellation { auth.removeAuthStateListener(listener) }
            }
        }
        if (user == null || user.isAnonymous) null else toAuthUser(user)
    }

    /** Asks the server whether the saved login still stands (account deleted / disabled / signed out everywhere). */
    suspend fun checkSession(): SessionCheck {
        val user = runCatching { auth().currentUser }.getOrNull() ?: return SessionCheck.UNKNOWN
        return try {
            timed { user.reload().await() }
            SessionCheck.VALID
        } catch (e: FirebaseAuthException) {
            if (AuthErrors.isDeadSessionCode(e.errorCode)) SessionCheck.INVALID else SessionCheck.UNKNOWN
        } catch (_: TimeoutCancellationException) {
            SessionCheck.UNKNOWN
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            SessionCheck.UNKNOWN // offline, timeout: keep the login, try again next start
        }
    }

    // ---- Helpers ---------------------------------------------------------------------------------

    private suspend fun <T> timed(ms: Long = AuthConfig.OP_TIMEOUT_MS, block: suspend () -> T): T =
        withTimeout(ms) { block() }

    private fun toAuthUser(user: FirebaseUser, nameOverride: String? = null, fallbackName: String? = null): AuthUser {
        val email = (user.email ?: user.providerData.firstNotNullOfOrNull { it.email }).orEmpty()
        val google = user.providerData.any { it.providerId == GoogleAuthProvider.PROVIDER_ID }
        val name = listOf(nameOverride, user.displayName, fallbackName, email.substringBefore('@'))
            .map { AuthValidation.cleanName(it.orEmpty()) }
            .firstOrNull { it.isNotEmpty() } ?: "Me"
        return AuthUser(
            uid = user.uid,
            name = name,
            email = email,
            provider = if (google) AuthProvider.GOOGLE else AuthProvider.EMAIL,
            emailVerified = user.isEmailVerified,
        )
    }

    /** Turns every Firebase / timeout / network failure into one [AuthException]. */
    private suspend fun <T> call(block: suspend () -> T): T = try {
        block()
    } catch (e: AuthException) {
        throw e
    } catch (e: TimeoutCancellationException) {
        throw AuthException(AuthErrorKind.TIMEOUT, cause = e)
    } catch (e: CancellationException) {
        throw e
    } catch (e: FirebaseNetworkException) {
        throw AuthException(AuthErrorKind.OFFLINE, cause = e)
    } catch (e: FirebaseTooManyRequestsException) {
        throw AuthException(AuthErrorKind.TOO_MANY_REQUESTS, cause = e)
    } catch (e: FirebaseAuthException) {
        throw AuthException(AuthErrors.kindOfFirebaseCode(e.errorCode), cause = e)
    } catch (e: FirebaseException) {
        throw AuthException(AuthErrorKind.UNKNOWN, cause = e)
    } catch (e: Exception) {
        throw AuthException(AuthErrorKind.UNKNOWN, cause = e)
    }
}
