package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Saved Keyword Blocking settings: the master switch, the page-title option and the keyword list. Kept in
 * device-protected storage like the other stores, so everything is back right after a restart. Changes follow the same
 * lock rules as the other restrictions ([ContentPolicy.canSetFeature]): while a session runs or settings are locked,
 * things can be tightened (add, switch on) but not loosened (edit, delete, switch off).
 */
class KeywordStore private constructor(private val context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "keyword_blocking")

    private val _state = MutableStateFlow(read())
    val state: StateFlow<KeywordState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> _state.value = read() }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun current(): KeywordState = read()

    private fun focus(): FocusState = FocusStore.get(context).current()

    fun canTighten() = ContentPolicy.canSetFeature(focus(), false, true)
    fun canLoosen() = ContentPolicy.canSetFeature(focus(), true, false)

    private fun read() = KeywordState(
        enabled = prefs.getBoolean(K_ON, false),
        checkPages = prefs.getBoolean(K_PAGES, true),
        rules = KeywordRules.decode(prefs.getString(K_RULES, null)),
    )

    private fun saveRules(rules: List<KeywordRule>, alsoOn: Boolean = false) {
        // commit() so a keyword is on disk before the service can be asked about it; the list is tiny.
        val e = prefs.edit().putString(K_RULES, KeywordRules.encode(rules))
        if (alsoOn) e.putBoolean(K_ON, true)
        e.commit()
    }

    /** Master switch. False when a session / lock does not allow that change right now. */
    @Synchronized
    fun setEnabled(on: Boolean): Boolean {
        val cur = prefs.getBoolean(K_ON, false)
        if (cur == on) return true
        if (!ContentPolicy.canSetFeature(focus(), cur, on)) return false
        prefs.edit().putBoolean(K_ON, on).commit()
        return true
    }

    /** Looking at page titles and headings too: ON tightens, OFF loosens. */
    @Synchronized
    fun setCheckPages(on: Boolean): Boolean {
        val cur = prefs.getBoolean(K_PAGES, true)
        if (cur == on) return true
        if (!ContentPolicy.canSetFeature(focus(), cur, on)) return false
        prefs.edit().putBoolean(K_PAGES, on).commit()
        return true
    }

    /** Adds every keyword in [raw] (comma / new line separated). The first one added also switches blocking on. */
    @Synchronized
    fun addMany(raw: String, partial: Boolean): KeywordEdits.Bulk {
        val s = read()
        val bulk = KeywordEdits.addMany(s.rules, raw, partial, canTighten())
        if (bulk.added.isNotEmpty()) saveRules(bulk.rules, alsoOn = true)
        return bulk
    }

    @Synchronized
    fun edit(oldWord: String, raw: String, partial: Boolean): KeywordRules.Result {
        val change = KeywordEdits.edit(read().rules, oldWord, raw, partial, canLoosen())
        if (change.result == KeywordRules.Result.OK) saveRules(change.rules)
        return change.result
    }

    @Synchronized
    fun remove(word: String): Boolean {
        val next = KeywordEdits.remove(read().rules, word, canLoosen()) ?: return false
        saveRules(next)
        return true
    }

    @Synchronized
    fun setRuleEnabled(word: String, on: Boolean): Boolean {
        val s = read()
        val next = KeywordEdits.setEnabled(s.rules, word, on, canTighten(), canLoosen()) ?: return false
        if (next !== s.rules) saveRules(next)
        return true
    }

    companion object {
        private const val K_ON = "enabled"
        private const val K_PAGES = "check_pages"
        private const val K_RULES = "rules"

        @Volatile
        private var instance: KeywordStore? = null

        fun get(context: Context): KeywordStore =
            instance ?: synchronized(this) {
                instance ?: KeywordStore(context.applicationContext).also { instance = it }
            }
    }
}
