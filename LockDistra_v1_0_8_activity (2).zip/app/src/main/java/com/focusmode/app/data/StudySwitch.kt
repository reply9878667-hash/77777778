package com.focusmode.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.concurrent.ExecutionException
import java.util.concurrent.FutureTask

/*
 * Study section, Part 3/4: Automatic Source Switching & Intelligent Fallback.
 *
 * ONE place decides which source serves a request and what happens when it fails. Before, every repository method had its
 * own copy of "if the API failed try the page data, then ask the screen to open the web search", and the copies disagreed
 * (a network error on Direct YouTube never reached Web, a source in its cool-down was asked again for every request, a failed
 * "load more" replaced the whole list by an error card).
 *
 * Sources and default priority:  API (YouTube Data API)  >  PAGE (Direct YouTube)  >  WEB (WebView search).
 *
 * WEB cannot run inside the repository (it is a WebView on screen). When API and PAGE cannot serve a request that WEB can serve,
 * the chain ends with a [WebHandoff]; the screen then opens the web search. That is the only "switch" the screen performs.
 *
 * Pure Kotlin (no Android classes): unit tested on the JVM with a fake clock and fake facts.
 */

/** What kind of request is being served, and which sources can serve it (in priority order). */
enum class StudyOp(val sources: List<StudyMode>) {
    /** Home: first screenful. WEB = a search of the first subject, opened by the screen. */
    FEED(listOf(StudyMode.API, StudyMode.PAGE, StudyMode.WEB)),

    /** Home: endless scroll. Never ends in an error screen (the list that is on screen stays). */
    FEED_MORE(listOf(StudyMode.API, StudyMode.PAGE)),

    /** First page of a normal (non-Short) search. */
    SEARCH(listOf(StudyMode.API, StudyMode.PAGE, StudyMode.WEB)),

    /** A next page (page token) or a Shorts search: only the API understands tokens / Shorts. */
    SEARCH_MORE(listOf(StudyMode.API)),

    /** A channel's own details: API only (the screen falls back to what the phone saved). */
    CHANNEL_INFO(listOf(StudyMode.API)),

    /** A channel's first page of videos. Direct YouTube can find the channel's videos by its name. */
    CHANNEL_PAGE(listOf(StudyMode.API, StudyMode.PAGE)),

    /** A channel's next page (token): API only. */
    CHANNEL_MORE(listOf(StudyMode.API)),
}

/** One source that did not serve a request: asked and failed, or skipped (and why). */
class SourceAttempt(
    val source: StudyMode,
    /** true = not asked at all (cooling down, switched off, missing app ...). */
    val skipped: Boolean,
    val reason: SourceReason,
    val message: String = "",
)

/** The API's keys all rest: until when and why. */
data class ApiRest(val until: Long, val reason: SourceReason)

/** Live facts the switcher reads from the phone's settings (not from the possibly stale tracker). */
interface SourceFacts {
    fun enabled(mode: StudyMode): Boolean
    fun apiKeyCount(): Int

    /** Non-null only when EVERY key rests (a key that can still be asked means the API is usable). */
    fun apiRest(now: Long): ApiRest?
}

/** Can a source be used for the next request? */
sealed interface Pick {
    object Use : Pick

    /** Failed lately; try again at [until] (an explicit "Try again" may go earlier, see [SourceSwitcher.run]). */
    data class Cooling(val until: Long, val reason: SourceReason) : Pick

    /** Cannot work here at all (switched off, no key, YouTube app missing ...). */
    data class Blocked(val reason: SourceReason) : Pick
}

/** The last source ran out: the screen should open the web search now. Carries what the earlier sources said. */
class WebHandoff(val attempts: List<SourceAttempt>) :
    StudyException(StudyErrorKind.OTHER, "Switching to the web search.", source = StudyMode.WEB)

/** Every source that can serve this request failed or is not usable: [title] / message are written for the person. */
class SourcesExhausted(
    kind: StudyErrorKind,
    message: String,
    val title: String,
    val attempts: List<SourceAttempt>,
    source: StudyMode = StudyMode.API,
) : StudyException(kind, message, source = source)

/**
 * A source worked, but it cannot serve THIS request (for example Direct YouTube has no way to list a channel whose name is
 * not known). It is not a failure of the source: nothing is recorded against it, the next source is tried.
 */
class NotServed(message: String, source: StudyMode) : StudyException(StudyErrorKind.OTHER, message, source = source)

object SwitchMessages {
    private val NETWORK = setOf(SourceReason.NO_INTERNET, SourceReason.UNREACHABLE, SourceReason.TIMEOUT)

    /**
     * Part 4/4: ONE short, honest phrase for a verified reason, or null when the reason says nothing worth telling (then it is left
     * out). Only reasons that were really verified come here (a real answer, or a fact read from the phone): an unknown is never a phrase.
     */
    fun reasonPhrase(source: StudyMode, reason: SourceReason): String? = when (reason) {
        SourceReason.DAILY_LIMIT -> "YouTube's free daily limit is used up"
        SourceReason.RATE_LIMIT -> "YouTube is asking for a short pause"
        SourceReason.INVALID_KEY -> "the YouTube API key is not valid"
        SourceReason.KEY_REFUSED -> "YouTube refused the API key"
        SourceReason.NO_KEY -> "no YouTube API key is set"
        SourceReason.SERVER_ERROR, SourceReason.SERVICE_UNAVAILABLE ->
            if (source == StudyMode.WEB) "the web server had a temporary error" else "YouTube's server had a temporary error"
        SourceReason.BLOCKED_BY_YOUTUBE -> "YouTube is refusing requests for a moment"
        SourceReason.PAGE_UNREADABLE, SourceReason.UNREADABLE_ANSWER -> "YouTube's answer could not be read"
        SourceReason.APP_DISABLED -> "the YouTube app is turned off on this phone"
        SourceReason.APP_NOT_INSTALLED -> "the YouTube app is not installed"
        SourceReason.PERMISSION_MISSING -> "an app permission is missing"
        SourceReason.WEBVIEW_MISSING -> "this phone has no web view"
        SourceReason.WEBVIEW_INIT_FAILED -> "the web view could not start"
        SourceReason.RENDERER_STOPPED -> "the web view stopped"
        SourceReason.SWITCHED_OFF -> "it is switched off"
        SourceReason.NO_INTERNET, SourceReason.UNREACHABLE, SourceReason.TIMEOUT -> "it could not be reached"
        SourceReason.UNKNOWN_ERROR, SourceReason.NONE -> null
    }

    private fun sourceName(m: StudyMode) = when (m) {
        StudyMode.API -> "YouTube API"
        StudyMode.PAGE -> "Direct YouTube"
        StudyMode.WEB -> "Web"
    }

    /**
     * What each source said, one phrase each ("YouTube API: YouTube's free daily limit is used up. Direct YouTube: the YouTube app is
     * turned off on this phone."). Sources with nothing verified to say are left out; the same source is named once.
     */
    fun detail(attempts: List<SourceAttempt>, except: StudyMode? = null): String =
        attempts.filter { it.reason != SourceReason.NONE && it.source != except }
            .distinctBy { it.source }
            .mapNotNull { a -> reasonPhrase(a.source, a.reason)?.let { sourceName(a.source) + ": " + it + "." } }
            .joinToString(" ")

    /** The one error shown when no source could serve the request (the person never sees the earlier single failures). */
    fun exhausted(attempts: List<SourceAttempt>): SourcesExhausted {
        val reasons = attempts.map { it.reason }.filter { it != SourceReason.NONE }
        // A source that is merely switched off / missing says nothing about WHY the others failed: it is left out of that judgement.
        val real = attempts.filter { !(it.skipped && it.reason.local && it.reason !in NETWORK) }.map { it.reason }.filter { it != SourceReason.NONE }
        val summary = detail(attempts)
        fun withDetail(base: String) = if (summary.isEmpty()) base else "$base $summary"
        return when {
            real.isNotEmpty() && real.all { it in NETWORK } -> SourcesExhausted(
                StudyErrorKind.NETWORK, "Study videos need an internet connection. Check your connection and try again.",
                "No internet connection", attempts, StudyMode.PAGE,
            )
            real.isEmpty() && reasons.isNotEmpty() && reasons.all { it.local && it !in NETWORK } -> SourcesExhausted(
                StudyErrorKind.OTHER, withDetail("Every video source is switched off or not available on this phone."),
                "No video source available", attempts,
            )
            SourceReason.DAILY_LIMIT in reasons -> SourcesExhausted(
                StudyErrorKind.OTHER,
                // "could not be reached" would be wrong when another source is merely switched off or its app is turned off: the others say why.
                "YouTube's free daily limit is used up and the other sources cannot serve this right now. " +
                    detail(attempts, except = StudyMode.API).let { if (it.isEmpty()) "" else "$it " } + "Try again in a little while.",
                "Could not load videos", attempts,
            )
            // A key that is wrong is a different problem from a busy server and says so (never "YouTube is disabled").
            SourceReason.INVALID_KEY in reasons || SourceReason.KEY_REFUSED in reasons -> SourcesExhausted(
                StudyErrorKind.OTHER, withDetail("The YouTube API key does not work and the other sources cannot serve this right now.") + " Try again in a little while.",
                "Could not load videos", attempts,
            )
            // A temporary error of a server: it passes by itself.
            reasons.any { it == SourceReason.SERVER_ERROR || it == SourceReason.SERVICE_UNAVAILABLE || it == SourceReason.BLOCKED_BY_YOUTUBE } -> SourcesExhausted(
                StudyErrorKind.OTHER, "YouTube's servers are having a temporary problem. Try again in a minute.",
                "Could not load videos", attempts,
            )
            else -> SourcesExhausted(
                StudyErrorKind.OTHER, withDetail("Every source is busy or not answering right now. Try again in a minute."),
                "Could not load videos", attempts,
            )
        }
    }

    /**
     * The Web search itself failed. When API and Direct YouTube are not working either, that is the "all three failed" case and
     * gets the one clear message; otherwise the Web-specific text stays. Null = keep the Web-specific text.
     */
    fun allThreeFailed(states: Map<StudyMode, SourceState>): SourcesExhausted? {
        val web = states[StudyMode.WEB] ?: return null
        if (web.available) return null
        val others = listOf(StudyMode.API, StudyMode.PAGE).map { states[it] ?: SourceState() }
        if (others.any { it.status == SourceStatus.AVAILABLE || it.status == SourceStatus.UNKNOWN }) return null
        val attempts = listOf(StudyMode.API, StudyMode.PAGE, StudyMode.WEB).map { SourceAttempt(it, false, (states[it] ?: SourceState()).reason) }
        return exhausted(attempts)
    }
}

/** Same video, richer details win; never a different video (ids must match). Used when two sources delivered the same lesson. */
object StudyMerge {
    fun richer(a: StudyVideo, b: StudyVideo): StudyVideo {
        require(a.id == b.id) { "Only the same video can be merged" }
        return a.copy(
            title = a.title.ifBlank { b.title },
            channelId = a.channelId.ifEmpty { b.channelId },
            channelTitle = a.channelTitle.ifEmpty { b.channelTitle },
            thumbUrl = a.thumbUrl.ifEmpty { b.thumbUrl },
            seconds = if (a.seconds > 0) a.seconds else b.seconds,
            categoryId = a.categoryId.ifEmpty { b.categoryId },
            publishedAt = if (a.publishedAt > 0L) a.publishedAt else b.publishedAt,
            description = a.description.ifEmpty { b.description },
        )
    }

    /** Lists in order, each video once (first position wins), gaps in its details filled from later copies. */
    fun merge(vararg lists: List<StudyVideo>): List<StudyVideo> {
        val out = LinkedHashMap<String, StudyVideo>()
        for (list in lists) for (v in list) {
            val cur = out[v.id]
            out[v.id] = if (cur == null) v else richer(cur, v)
        }
        return out.values.toList()
    }
}

/**
 * Runs a request through the sources in priority order and decides what happens on failure.
 *
 *  - Priority comes first, but only a source that is really usable is asked ([check]): not switched off, not blocked by a local
 *    fact, not in its cool-down. A source that failed lately is skipped at once (no waiting for it to fail again).
 *  - A failure of one source is recorded for THAT source only; the others are judged on their own state.
 *  - The next source is asked the moment a failure is seen. Each source is asked at most once per request.
 *  - The same request asked twice at the same time is run once; both callers get the one answer.
 *  - A request that just failed is not started again straight away ([MEMO_MS]); after [MAX_FAILED_CHAINS] failures in a row it
 *    rests [MEMO_LONG_MS] (an explicit "Try again" may start sooner, but never inside [MEMO_MS]).
 *
 * Blocking: call from a background thread.
 */
class SourceSwitcher(
    private val tracker: SourceTracker = StudySources.tracker,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    private val lock = Any()
    private val inflight = HashMap<String, FutureTask<Any?>>()
    private val memo = object : LinkedHashMap<String, Memo>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Memo>?): Boolean = size > MEMO_MAX
    }
    private var switchingCount = 0
    private val flow = MutableStateFlow(false)

    /** True while a request is on its second (or later) source, so the screen can show a quiet loading line. */
    val switching: StateFlow<Boolean> = flow

    private class Memo(val at: Long, val error: StudyException, val count: Int, val epoch: Long)

    // ---- is a source usable now? -------------------------------------------------------------------------------

    /**
     * Live phone facts first (a key that rests, a switch, no key at all), then what the tracker learned from real answers. The
     * tracker's local states (NO_INTERNET, SWITCHED_OFF) are only re-read when the Study screen opens, so they never block here:
     * a phone that is back online or a switch turned on again works at once.
     */
    fun check(mode: StudyMode, facts: SourceFacts, now: Long = clock()): Pick {
        if (!facts.enabled(mode)) return Pick.Blocked(SourceReason.SWITCHED_OFF)
        val s = tracker.state(mode)
        if (mode == StudyMode.API) {
            if (facts.apiKeyCount() == 0) return Pick.Blocked(SourceReason.NO_KEY)
            facts.apiRest(now)?.let { return Pick.Cooling(it.until, it.reason) }
            // The keys are the truth for limit / key problems (they rest on the phone); the tracker adds timeouts, 5xx, network, and
            // covers a limit / key refusal that no key rest recorded. A refused key is asked again after 5 minutes, as [StudyApi] does.
            val until = when (s.status) {
                SourceStatus.TEMPORARILY_FAILED, SourceStatus.QUOTA_EXHAUSTED -> s.retryAt
                SourceStatus.NETWORK_ERROR -> if (s.reason == SourceReason.NO_INTERNET) 0L else s.retryAt
                SourceStatus.AUTH_ERROR -> s.verifiedAt + AUTH_REST_MS
                else -> 0L
            }
            return if (now < until) Pick.Cooling(until, s.reason) else Pick.Use
        }
        return when (s.status) {
            SourceStatus.AVAILABLE, SourceStatus.UNKNOWN -> Pick.Use
            SourceStatus.DISABLED -> if (s.reason == SourceReason.SWITCHED_OFF) Pick.Use else Pick.Blocked(s.reason)
            SourceStatus.UNAVAILABLE -> if (s.reason.local) Pick.Blocked(s.reason) else cooling(s, now)
            SourceStatus.NETWORK_ERROR -> if (s.reason == SourceReason.NO_INTERNET) Pick.Use else cooling(s, now)
            SourceStatus.TEMPORARILY_FAILED, SourceStatus.AUTH_ERROR, SourceStatus.QUOTA_EXHAUSTED -> cooling(s, now)
        }
    }

    private fun cooling(s: SourceState, now: Long): Pick = if (now < s.retryAt) Pick.Cooling(s.retryAt, s.reason) else Pick.Use

    /** For optional extra requests (channel pictures, details for the web list): never worth asking a source that is down. */
    fun isUsable(mode: StudyMode, facts: SourceFacts): Boolean = check(mode, facts) == Pick.Use

    // ---- the chain -----------------------------------------------------------------------------------------------

    /**
     * Serves one request. [attempts] has the code of each source that can run inside the repository (WEB has none: it ends the
     * chain with a [WebHandoff]). [key] names the request (same text = same request). [manual] = the person tapped "Try again" /
     * pulled to refresh: a source that failed at least [MANUAL_MIN_AGE_MS] ago is asked again even inside its cool-down.
     *
     * Returns the first success. Throws [WebHandoff] when the web search is next, [SourcesExhausted] when nothing is left, or
     * the original error when it says nothing about a source's health (a missing item).
     */
    @Suppress("UNCHECKED_CAST")
    fun <T> run(op: StudyOp, key: String, facts: SourceFacts, manual: Boolean = false, attempts: Map<StudyMode, () -> T>): T {
        val full = op.name + "|" + key
        val now = clock()
        synchronized(lock) {
            memo[full]?.let { m ->
                val window = if (m.count >= MAX_FAILED_CHAINS && !manual) MEMO_LONG_MS else MEMO_MS
                // Part 4/4: when something came back since the failure (a source recovered, the phone is online again) the old
                // "this request just failed" memory is stale: the request may run again at once and use the recovered source.
                if (now - m.at < window && m.epoch == tracker.recoveryEpoch) throw m.error
            }
        }
        var mine = false
        val task = synchronized(lock) {
            inflight[full] ?: FutureTask<Any?> { execute(op, facts, manual, attempts) }.also { inflight[full] = it; mine = true }
        }
        if (mine) {
            try { task.run() } finally { synchronized(lock) { inflight.remove(full) } }
        }
        val result = try {
            task.get()
        } catch (e: ExecutionException) {
            val cause = e.cause ?: e
            if (mine && cause is StudyException && (cause is WebHandoff || cause is SourcesExhausted)) remember(full, cause)
            throw cause
        }
        if (mine) synchronized(lock) { memo.remove(full) }
        return result as T
    }

    private fun remember(full: String, e: StudyException) = synchronized(lock) {
        val at = clock()
        val prev = memo[full]
        memo[full] = Memo(at, e, if (prev != null && at - prev.at < MEMO_RESET_MS) prev.count + 1 else 1, tracker.recoveryEpoch)
    }

    private fun <T> execute(op: StudyOp, facts: SourceFacts, manual: Boolean, attempts: Map<StudyMode, () -> T>): T {
        val failed = ArrayList<SourceAttempt>()
        var switchShown = false
        try {
            for (mode in PRIORITY) {
                if (mode !in op.sources) continue
                val now = clock()
                val pick = check(mode, facts, now)
                val usable = when (pick) {
                    Pick.Use -> true
                    is Pick.Cooling -> manual && now - tracker.state(mode).verifiedAt >= MANUAL_MIN_AGE_MS
                    is Pick.Blocked -> false
                }
                if (!usable) {
                    failed += SourceAttempt(mode, true, when (pick) { is Pick.Cooling -> pick.reason; is Pick.Blocked -> pick.reason; else -> SourceReason.NONE })
                    continue
                }
                if (mode == StudyMode.WEB) throw WebHandoff(failed)
                val run = attempts[mode] ?: continue
                // The second source is being asked: a quiet loading line shows (the list on screen stays).
                if (failed.isNotEmpty() && !switchShown) { switchShown = true; beginSwitch() }
                val before = tracker.state(mode).verifiedAt
                try {
                    val value = run()
                    StudyMonitor.report(mode)
                    return value
                } catch (e: InterruptedException) {
                    throw e
                } catch (e: Exception) {
                    if (e is StudyException && e.kind == StudyErrorKind.NOT_FOUND) throw e // says nothing about the source
                    if (e is WebHandoff || e is SourcesExhausted) throw e
                    if (e !is NotServed) noteFailure(mode, e, before)
                    failed += SourceAttempt(mode, false, reasonOf(mode, e), e.message.orEmpty())
                }
            }
            throw SwitchMessages.exhausted(failed)
        } finally {
            if (switchShown) endSwitch()
        }
    }

    /**
     * The lower layers record what they saw ([StudyApi], [StudyRepository.nativeSearch]). This is only the safety net: if a
     * source failed and nothing was recorded for it, it is recorded now, so it cools down and is not asked again at once.
     */
    private fun noteFailure(mode: StudyMode, e: Exception, before: Long) {
        if (tracker.state(mode).verifiedAt != before) return
        tracker.failure(mode, classify(mode, e), clock())
    }

    private fun classify(mode: StudyMode, e: Exception): SourceFailure {
        if (e is StudyException) {
            if (mode == StudyMode.API) SourceClassifier.fromApi(e, clock())?.let { return it }
            return when (e.kind) {
                StudyErrorKind.NETWORK ->
                    if (e.reason == SourceReason.TIMEOUT) SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT)
                    else SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE)
                StudyErrorKind.BAD_ANSWER -> SourceFailure(
                    SourceStatus.TEMPORARILY_FAILED,
                    if (mode == StudyMode.PAGE) SourceReason.PAGE_UNREADABLE else SourceReason.UNREADABLE_ANSWER,
                )
                else -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, if (e.reason == SourceReason.NONE) SourceReason.UNKNOWN_ERROR else e.reason)
            }
        }
        return SourceClassifier.fromPage(e)
    }

    private fun reasonOf(mode: StudyMode, e: Exception): SourceReason =
        if (e is NotServed) SourceReason.NONE else tracker.state(mode).reason.takeIf { it != SourceReason.NONE } ?: classify(mode, e).reason

    private fun beginSwitch() = synchronized(lock) { switchingCount++; flow.value = true }
    private fun endSwitch() = synchronized(lock) { switchingCount = (switchingCount - 1).coerceAtLeast(0); flow.value = switchingCount > 0 }

    /** Tests only. */
    fun reset() = synchronized(lock) { memo.clear(); inflight.clear(); switchingCount = 0; flow.value = false }

    companion object {
        /** Default priority. */
        val PRIORITY = listOf(StudyMode.API, StudyMode.PAGE, StudyMode.WEB)

        /** A request that just failed is not started again inside this time. */
        const val MEMO_MS = 3_000L

        /** After [MAX_FAILED_CHAINS] failures in a row, the same automatic request rests this long. */
        const val MEMO_LONG_MS = 60_000L
        const val MAX_FAILED_CHAINS = 3

        /** An explicit retry may skip a cool-down only when the source's last failure is at least this old. */
        const val MANUAL_MIN_AGE_MS = 10_000L

        private const val AUTH_REST_MS = 5L * 60_000L
        private const val MEMO_RESET_MS = 5L * 60_000L
        private const val MEMO_MAX = 64
    }
}

/** The one switcher of the app (like [StudySources] / [StudyMonitor]): its in-flight and cool-down memory is shared by every screen. */
object StudySwitch {
    val switcher = SourceSwitcher()

    /** True while a request is running on a fallback source (drives the quiet loading line). */
    val switching: StateFlow<Boolean> get() = switcher.switching
}
