package com.focusmode.app.ui

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.AppEntryRules
import com.focusmode.app.data.EntryRoute
import com.focusmode.app.data.OnboardingStore
import com.focusmode.app.data.PermissionGateStore
import com.focusmode.app.data.auth.AuthConfig
import com.focusmode.app.data.auth.AuthSession
import com.focusmode.app.data.profile.ProfileState
import com.focusmode.app.ui.auth.AuthFlow
import com.focusmode.app.ui.auth.AuthScreen
import com.focusmode.app.ui.onboarding.OnboardingFlow
import com.focusmode.app.ui.screens.PermissionGateScreen
import com.focusmode.app.ui.screens.SplashScreen
import com.focusmode.app.ui.screens.SplashState
import com.focusmode.app.ui.theme.FocusModeTheme
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.launch

/**
 * Task 3: the one place that decides which top-level screen the person sees, and the only place that connects the
 * onboarding, the account screens, the profile and Home. Every piece is reused as it was; this only wires them.
 *
 * ```
 * New user         Splash -> Welcome -> 7 questions -> Celebration -> Sign up -> "Welcome" -> Permissions -> Home
 * Existing user    Splash -> (saved login found) -> Home (Permissions first if one is missing)
 * Logged-out user  Splash -> Log in -> "Welcome back" -> Permissions (if any is missing) -> Home
 * ```
 * [AppEntryRules.route] picks the route from facts that are all saved on the phone, so the right screen appears on the
 * first frame after every restart, with no flash of another screen. The three routes are siblings, not stacked
 * overlays: Home is not even composed while someone is logged out, so no authenticated screen, dialog or request can
 * show through, and the Android Back button has no earlier onboarding or account screen to return to.
 *
 * Blocking, limits and timers run in services and keep working whatever this screen shows.
 */
/** True only while Home is really on screen (past splash, sign-up / login and permissions). Admin popups wait for it. */
object HomeVisible {
    @Volatile var value: Boolean = false
}

@Composable
fun AppEntry(vm: AppViewModel) {
    val context = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val onboarding = remember { OnboardingStore.get(context) }
    val onboardingDone by onboarding.welcomeDone.collectAsStateWithLifecycle()
    val requiredFor by onboarding.requiredFor.collectAsStateWithLifecycle()
    val session by vm.auth.session.collectAsStateWithLifecycle()
    val profileState by vm.profile.state.collectAsStateWithLifecycle()
    val permissions by vm.permissions.collectAsStateWithLifecycle()
    val gateStore = remember { PermissionGateStore.get(context) }
    val permissionsSkipped by gateStore.skipped.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    val user = (session as? AuthSession.SignedIn)?.user
    val authRequired = AuthConfig.authRequired

    // The splash plays once per launch; rotation or a process-internal reopen skips it.
    var showSplash by rememberSaveable { mutableStateOf(!SplashState.shown) }
    // After a login the account screen stays until Continue is pressed on its "Welcome" confirmation.
    var holdAuth by rememberSaveable { mutableStateOf(false) }
    // "I already have an account" on the welcome screen.
    var wantsLogin by rememberSaveable { mutableStateOf(false) }

    val route = AppEntryRules.route(
        signedIn = user != null,
        onboardingDone = onboardingDone,
        authRequired = authRequired,
        ownOnboardingRequired = user != null && requiredFor == user.uid,
        holdAuth = holdAuth,
        wantsLogin = wantsLogin,
        // Home opens when every required permission is allowed, or after "Skip for now" on the permission page.
        permissionsGranted = AppEntryRules.permissionStepDone(permissions.allRequiredGranted, permissionsSkipped),
    )

    // Admin popups may only appear once Home is on screen, never over the splash, onboarding, sign-up / login or permissions.
    val homeNow = route == EntryRoute.Home && !showSplash
    SideEffect { HomeVisible.value = homeNow }
    DisposableEffect(Unit) { onDispose { HomeVisible.value = false; PopupWebDialog.dismissAll() } }
    // Logout, an expired login, the login screen, onboarding or the permission page: any popup still open is closed.
    LaunchedEffect(homeNow) { if (!homeNow) PopupWebDialog.dismissAll() }

    // The account screen is showing to a logged-out person: from now on it also covers the confirmation after the login.
    val loggedOutOnAuth = user == null && route == EntryRoute.Auth
    LaunchedEffect(loggedOutOnAuth) { if (loggedOutOnAuth) holdAuth = true }

    // Whatever Home was showing (Settings, a notification's target ...) is not reopened after a logout / login.
    // A pending "Emergency access" shortcut must not pop up later, over a different account's Home.
    LaunchedEffect(route) {
        if (route != EntryRoute.Home) {
            vm.screen = Screen.Home
            vm.emergencyRequested = false
        }
    }

    // A login that exists on this phone means the onboarding is behind this person (new phone, old install).
    LaunchedEffect(route, onboardingDone) {
        if (route == EntryRoute.Home && !onboardingDone) {
            onboarding.markWelcomeDone()
            onboarding.clearDraft()
        }
    }

    // A new account on a shared phone finished its own onboarding on an earlier start (killed before the final step).
    LaunchedEffect(profileState, requiredFor) {
        val ready = profileState as? ProfileState.Ready
        if (ready != null && requiredFor == ready.profile.uid && ready.profile.onboarding != null) {
            onboarding.clearRequired()
        }
    }

    // The welcome notification of a brand-new account is held back until notifications are allowed (the permission page
    // comes after sign-up), then shown once, as soon as the person is past the "Welcome" confirmation.
    LaunchedEffect(permissions.notifications, route, user?.uid) {
        if (user != null && permissions.notifications && route != EntryRoute.Auth) {
            com.focusmode.app.data.auth.WelcomeNotifier.showPending(context)
        }
    }

    // Home's greeting shows the account's name (and the right one after switching accounts).
    val accountName = (profileState as? ProfileState.Ready)?.profile?.displayName?.takeIf { it.isNotBlank() }
        ?: user?.name?.takeIf { it.isNotBlank() }
    LaunchedEffect(user?.uid, accountName) {
        if (user != null && accountName != null) vm.setUserName(accountName)
    }

    // Back in the foreground: ask the server whether the saved login still stands (expired / deleted / disabled).
    // Offline never logs anyone out; a dead login lands on the login screen with an explanation.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) vm.auth.revalidate()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    FocusModeTheme(state.themeMode) {
        // Status / navigation bar icons readable on the splash and on the onboarding / account screens.
        val view = LocalView.current
        val darkTheme = FocusTheme.colors.isDark
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                val lightBars = !darkTheme && !showSplash
                controller.isAppearanceLightStatusBars = lightBars
                controller.isAppearanceLightNavigationBars = lightBars
            }
        }

        Box(Modifier.fillMaxSize()) {
            when (route) {
                EntryRoute.Home -> FocusAppContent(vm, showSplash)

                EntryRoute.Permissions -> if (!showSplash) PermissionGateScreen(vm, onSkip = gateStore::skip)

                EntryRoute.Onboarding -> if (!showSplash) {
                    // Resumes where an interrupted onboarding stopped (question and answers).
                    val draft = remember { onboarding.loadDraft() }
                    OnboardingFlow(
                        initialDraft = draft,
                        onProgress = onboarding::saveDraft,
                        onQuestionsFinished = { answers ->
                            // Saved on the phone, unclaimed, with the "done" flag in the same commit. For a new
                            // visitor the route now becomes the account screen; the answers join the account that
                            // is created next (ProfileRepository), never two accounts.
                            onboarding.saveAnswers(answers)
                        },
                        onFinished = {
                            // Only when a logged-in new account answered its own questions.
                            val uid = user?.uid
                            if (uid != null && requiredFor == uid) {
                                scope.launch {
                                    vm.profile.claimPendingOnboarding()
                                    onboarding.clearRequired()
                                }
                            }
                        },
                        onHaveAccount = if (user == null && authRequired) {
                            { wantsLogin = true }
                        } else null,
                    )
                }

                EntryRoute.Auth -> if (!showSplash) {
                    val startOnLogin = remember {
                        AppEntryRules.startOnLogin(
                            hasUnclaimedAnswers = onboarding.hasUnclaimedAnswers(),
                            wantsLogin = wantsLogin,
                            hasNotice = vm.auth.notice.value != null,
                        )
                    }
                    AuthFlow(
                        startScreen = if (startOnLogin) AuthScreen.Login else AuthScreen.SignUp,
                        onFinished = { isNew ->
                            val uid = (vm.auth.session.value as? AuthSession.SignedIn)?.user?.uid
                            holdAuth = false
                            wantsLogin = false
                            if (uid != null) {
                                if (AppEntryRules.newAccountNeedsOnboarding(isNew, onboarding.hasAnswersFor(uid))) {
                                    onboarding.requireFor(uid)
                                } else {
                                    // A login to an existing account never asks the questions again: the account
                                    // already has its answers. Clear everything that could bring them back.
                                    if (!isNew && onboarding.requiredFor.value == uid) onboarding.clearRequired()
                                    if (!onboardingDone) onboarding.markWelcomeDone()
                                    onboarding.clearDraft()
                                }
                            }
                        },
                        // No Skip: Home needs an account. Only "I already have an account" can leave the screen,
                        // and it leads back to the welcome screen.
                        onSkip = null,
                        onClose = if (wantsLogin && user == null) {
                            { wantsLogin = false }
                        } else null,
                    )
                }
            }

            AnimatedVisibility(
                visible = showSplash,
                enter = EnterTransition.None,
                exit = fadeOut(tween(450)) + scaleOut(tween(450), targetScale = 1.05f),
            ) {
                SplashScreen(onFinished = {
                    SplashState.shown = true
                    showSplash = false
                })
            }
        }
    }
}
