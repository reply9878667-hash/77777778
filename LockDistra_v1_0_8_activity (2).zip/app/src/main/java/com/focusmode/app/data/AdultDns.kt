package com.focusmode.app.data

/**
 * DNS and IPv4/UDP packet helpers for the Adult Content DNS filter (service/AdultDnsVpnService.kt).
 * No Android classes, so everything here is unit-testable.
 *
 * The filter only ever handles plain DNS over UDP: it reads the question, answers "blocked" itself or
 * hands the question to a family-safe upstream resolver. Nothing else is looked at or stored.
 */
object AdultDns {

    const val TYPE_A = 1
    const val TYPE_AAAA = 28

    const val RCODE_OK = 0
    const val RCODE_SERVFAIL = 2
    const val RCODE_NXDOMAIN = 3

    /** One DNS question: the host asked for (lower case, no trailing dot), its record type and class. */
    class Question(val name: String, val type: Int, val cls: Int, val end: Int)

    /**
     * Names browsers / systems use to find an encrypted-DNS (DoH) server, and Firefox's "canary" name. Answering
     * "does not exist" for them keeps browsers on the normal DNS the filter controls instead of a private channel
     * that would skip it.
     */
    private val dohNames: Set<String> = setOf(
        "use-application-dns.net",
        "dns.google", "dns64.dns.google",
        "cloudflare-dns.com", "mozilla.cloudflare-dns.com", "chrome.cloudflare-dns.com", "one.one.one.one",
        "security.cloudflare-dns.com", "family.cloudflare-dns.com",
        "dns.quad9.net", "dns9.quad9.net", "dns10.quad9.net", "dns11.quad9.net",
        "doh.opendns.com", "dns.opendns.com", "doh.familyshield.opendns.com",
        "dns.adguard.com", "dns.adguard-dns.com", "unfiltered.adguard-dns.com", "family.adguard-dns.com",
        "dns.nextdns.io", "doh.cleanbrowsing.org", "dns.sb", "doh.dns.sb", "doh.mullvad.net", "dns.mullvad.net",
        "doh.libredns.gr", "dns.twnic.tw", "doh.pub", "dns.alidns.com", "doh.360.cn",
        "dnsforge.de", "dns.digitale-gesellschaft.ch", "doh.applied-privacy.net", "dns.switch.ch",
    )

    fun isDohName(name: String): Boolean {
        if (name in dohNames) return true
        // NextDNS gives every account its own name: <id>.dns.nextdns.io
        return name.endsWith(".dns.nextdns.io") || name.endsWith(".cloudflare-dns.com")
    }

    /** Reads the first question of a DNS query, or null when the packet is not a plain, well-formed query. */
    fun parseQuestion(p: ByteArray, len: Int = p.size): Question? {
        if (len < 17) return null
        val flags = u16(p, 2)
        if (flags and 0x8000 != 0) return null                  // a response, not a query
        if ((flags shr 11) and 0xF != 0) return null            // only standard queries
        if (u16(p, 4) < 1) return null                          // needs a question
        var i = 12
        val sb = StringBuilder()
        while (true) {
            if (i >= len) return null
            val l = p[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if (l and 0xC0 != 0) return null                    // compression is not used in a question
            if (l > 63 || i + 1 + l > len) return null
            if (sb.isNotEmpty()) sb.append('.')
            for (k in 0 until l) {
                val ch = p[i + 1 + k].toInt() and 0xFF
                if (ch >= 128) return null
                sb.append(ch.toChar().lowercaseChar())
            }
            if (sb.length > 253) return null
            i += 1 + l
        }
        if (i + 4 > len) return null
        return Question(sb.toString(), u16(p, i), u16(p, i + 2), i + 4)
    }

    /**
     * The answer for a blocked name: A -> 0.0.0.0, AAAA -> ::, anything else -> an empty, successful answer.
     * The sinkhole address refuses connections at once, so the page fails fast instead of hanging.
     */
    fun sinkholeResponse(query: ByteArray, q: Question): ByteArray {
        val wantsAddress = q.type == TYPE_A || q.type == TYPE_AAAA
        val rdLen = if (q.type == TYPE_AAAA) 16 else 4
        val size = q.end + if (wantsAddress) 12 + rdLen else 0
        val out = ByteArray(size)
        System.arraycopy(query, 0, out, 0, q.end)
        // QR=1, keep opcode and RD, RA=1, RCODE=0
        val rd = query[2].toInt() and 0x01
        out[2] = (0x80 or rd).toByte()
        out[3] = 0x80.toByte()
        put16(out, 4, 1)                                         // QDCOUNT
        put16(out, 6, if (wantsAddress) 1 else 0)               // ANCOUNT
        put16(out, 8, 0)                                         // NSCOUNT
        put16(out, 10, 0)                                        // ARCOUNT
        if (wantsAddress) {
            var o = q.end
            out[o++] = 0xC0.toByte(); out[o++] = 0x0C            // name: pointer to the question
            put16(out, o, q.type); o += 2
            put16(out, o, 1); o += 2                             // class IN
            put16(out, o, 0); put16(out, o + 2, 60); o += 4      // TTL 60 s
            put16(out, o, rdLen); o += 2
            // the address bytes stay 0
        }
        return out
    }

    /** "This name does not exist" (NXDOMAIN) or another bare error answer for [query]. */
    fun errorResponse(query: ByteArray, q: Question, rcode: Int): ByteArray {
        val out = ByteArray(q.end)
        System.arraycopy(query, 0, out, 0, q.end)
        val rd = query[2].toInt() and 0x01
        out[2] = (0x80 or rd).toByte()
        out[3] = (0x80 or (rcode and 0xF)).toByte()
        put16(out, 4, 1)
        put16(out, 6, 0); put16(out, 8, 0); put16(out, 10, 0)
        return out
    }

    /** Marks [resp] "truncated" and keeps only header + question, for an upstream answer too big for one tunnel packet. */
    fun truncated(resp: ByteArray): ByteArray {
        val q = parseQuestionOfResponse(resp) ?: return resp
        val out = ByteArray(q)
        System.arraycopy(resp, 0, out, 0, q)
        out[2] = (out[2].toInt() or 0x02).toByte()               // TC
        put16(out, 6, 0); put16(out, 8, 0); put16(out, 10, 0)
        return out
    }

    private fun parseQuestionOfResponse(p: ByteArray): Int? {
        if (p.size < 17) return null
        var i = 12
        while (true) {
            if (i >= p.size) return null
            val l = p[i].toInt() and 0xFF
            if (l == 0) { i++; break }
            if (l and 0xC0 != 0) return null
            i += 1 + l
        }
        return if (i + 4 <= p.size) i + 4 else null
    }

    // ---- IPv4 / UDP packets on the tunnel ---------------------------------------------------------

    /** A UDP datagram read from the tunnel. [payload] is the DNS message. */
    class UdpPacket(
        val srcAddr: ByteArray, val dstAddr: ByteArray,
        val srcPort: Int, val dstPort: Int,
        val payload: ByteArray,
    )

    /** What a raw tunnel packet is, for the filter loop. */
    sealed class Parsed {
        class Udp(val packet: UdpPacket) : Parsed()
        /** Anything that is not a UDP/IPv4 packet (TCP to a blocked DNS-over-HTTPS address, ICMP, ...): dropped. */
        object Other : Parsed()
    }

    fun parsePacket(b: ByteArray, len: Int): Parsed {
        if (len < 28) return Parsed.Other
        val version = (b[0].toInt() shr 4) and 0xF
        if (version != 4) return Parsed.Other
        val ihl = (b[0].toInt() and 0xF) * 4
        if (ihl < 20 || len < ihl + 8) return Parsed.Other
        val total = u16(b, 2)
        if (total < ihl + 8 || total > len) return Parsed.Other
        if (b[9].toInt() != 17) return Parsed.Other
        // Fragments are never produced for a DNS query; skip them.
        if (u16(b, 6) and 0x3FFF != 0) return Parsed.Other
        val udpLen = u16(b, ihl + 4)
        if (udpLen < 8 || ihl + udpLen > total) return Parsed.Other
        val payload = b.copyOfRange(ihl + 8, ihl + udpLen)
        return Parsed.Udp(
            UdpPacket(
                srcAddr = b.copyOfRange(12, 16), dstAddr = b.copyOfRange(16, 20),
                srcPort = u16(b, ihl), dstPort = u16(b, ihl + 2), payload = payload
            )
        )
    }

    /** The IPv4/UDP packet that carries [payload] back to the sender of [req] (addresses and ports swapped). */
    fun buildReply(req: UdpPacket, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val o = ByteArray(total)
        o[0] = 0x45.toByte()
        put16(o, 2, total)
        put16(o, 4, 0)
        put16(o, 6, 0x4000)                                      // don't fragment
        o[8] = 64                                                // TTL
        o[9] = 17                                                // UDP
        System.arraycopy(req.dstAddr, 0, o, 12, 4)               // source = the address that was asked
        System.arraycopy(req.srcAddr, 0, o, 16, 4)
        put16(o, 10, 0)
        put16(o, 10, ipChecksum(o, 20))
        put16(o, 20, req.dstPort)
        put16(o, 22, req.srcPort)
        put16(o, 24, 8 + payload.size)
        put16(o, 26, 0)                                          // UDP checksum is optional over IPv4
        System.arraycopy(payload, 0, o, 28, payload.size)
        return o
    }

    fun ipChecksum(b: ByteArray, headerLen: Int): Int {
        var sum = 0L
        var i = 0
        while (i < headerLen) {
            sum += u16(b, i)
            i += 2
        }
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun u16(b: ByteArray, i: Int): Int = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    private fun put16(b: ByteArray, i: Int, v: Int) {
        b[i] = (v shr 8).toByte()
        b[i + 1] = v.toByte()
    }
}
