package com.focusmode.app.data

import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

/**
 * Adult-website blocklist core. No Android classes, so everything here is unit-testable.
 *
 * Storage format ("sorted domain file"): UTF-8 text, one lowercase ASCII domain per line,
 * '\n' line ends, strictly ascending by plain byte order, no duplicates, no comments. That lets
 * [SortedDomainIndex] look a host up with a binary search straight on disk, so a list with
 * hundreds of thousands of entries costs almost no memory.
 *
 * Matching rule: a listed entry blocks itself and every subdomain of it ("example.com" blocks
 * "m.example.com"). Entries are matched at a dot boundary only.
 */
object AdultBlocklist {

    /** Hosts that must never be blocked, even if a source list contains them (false-positive guard). */
    private val neverBlock: Set<String> = setOf(
        "google.com", "youtube.com", "youtu.be", "bing.com", "duckduckgo.com", "yahoo.com",
        "wikipedia.org", "wikimedia.org", "reddit.com", "x.com", "twitter.com", "facebook.com",
        "instagram.com", "tumblr.com", "blogspot.com", "wordpress.com", "medium.com", "github.com",
        "microsoft.com", "apple.com", "amazon.com", "cloudflare.com", "archive.org", "pinterest.com",
        "telegram.org", "t.me", "discord.com", "discord.gg", "snapchat.com", "tiktok.com",
        "whatsapp.com", "netflix.com", "twitch.tv", "imgur.com", "giphy.com", "gstatic.com",
        "googleapis.com", "googleusercontent.com", "anthropic.com", "claude.ai",
        "free.fr", "over-blog.com", "canalblog.com", "wixsite.com", "weebly.com", "pages.dev",
        "github.io", "netlify.app", "vercel.app", "herokuapp.com", "fc2.com", "livejournal.com",
    )

    /** True when [domain] (or a parent of it) is on the never-block list. */
    fun isProtected(domain: String): Boolean =
        candidates(domain).any { it in neverBlock }

    /**
     * The host and each of its parent domains, most specific first, stopping before a bare TLD:
     * "a.b.example.com" -> a.b.example.com, b.example.com, example.com.
     */
    fun candidates(host: String): List<String> {
        val out = ArrayList<String>(6)
        var h = host
        while (true) {
            out.add(h)
            val dot = h.indexOf('.')
            if (dot < 0) break
            val parent = h.substring(dot + 1)
            if (!parent.contains('.')) break
            h = parent
        }
        return out
    }

    /**
     * Whether [rawHost] (anything [WebsiteRules.normalize] accepts, e.g. an address-bar text) is
     * covered by the list in [index]. Hosts under a never-block domain are never matched, so a
     * source list that carries a user-subdomain of a big platform cannot close that platform.
     */
    fun matches(rawHost: String, index: SortedDomainIndex): Boolean {
        val host = WebsiteRules.normalize(rawHost) ?: return false
        val cands = candidates(host)
        for (c in cands) {
            if (c in neverBlock) return false
        }
        for (c in cands) {
            if (index.contains(c)) return true
        }
        // The list can never hold every adult site (new ones appear daily), so a host whose NAME is plainly adult
        // is closed too. Checked after the never-block guard above.
        return looksAdult(host)
    }

    // ---- Name-based detection (catches sites that are not in the list) -----------------------------

    /** Parts of a host name that are adult beyond reasonable doubt, wherever they sit in the name. */
    private val adultParts: List<String> = listOf(
        "porn", "xxx", "hentai", "xvideo", "xnxx", "xhamster", "xxnx", "redtube", "youporn", "brazzers",
        "chaturbate", "stripchat", "bongacams", "livejasmin", "onlyfans", "camgirl", "nudes", "cumshot",
        "blowjob", "handjob", "bukkake", "sexcam", "sexchat", "sexvideo", "sexstor", "sexfilm", "sexmovie",
        "sextube", "freesex", "hotsex", "adultfriendfinder", "fuckbook", "milfs", "camsoda", "spankbang",
    )

    /** Words that are adult only when they are a whole piece of the name ("sex-videos.com", "free.sex"), not inside "essex". */
    private val adultTokens: Set<String> = setOf("sex", "sexy", "sexo", "sexe", "xxx", "porno", "pornos", "nude", "nsfw18", "erotica")

    /** Sites that contain an adult word but are not adult: shops, and porn-recovery help. */
    private val notAdultNames: List<String> = listOf(
        "xxxlutz", "brainonporn", "fightthenewdrug", "pornharms", "pornfree", "stoppornaddiction",
        "pornography-addiction", "nofap", "covenanteyes",
    )

    /** True when the NAME of [host] (already normalized) is plainly adult. Never true for a never-block host. */
    fun looksAdult(host: String): Boolean {
        val cands = candidates(host)
        if (cands.any { it in neverBlock }) return false
        if (notAdultNames.any { host.contains(it) }) return false
        val labels = host.split('.')
        // The last label is the TLD (".xxx", ".porn", ".sex", ".adult" are adult by definition).
        val tld = labels.last()
        if (tld == "xxx" || tld == "porn" || tld == "sex" || tld == "adult" || tld == "sexy") return true
        val name = labels.dropLast(1)
        for (label in name) {
            for (part in adultParts) if (label.contains(part)) return true
            for (token in label.split('-')) if (token in adultTokens) return true
        }
        return false
    }

    // ---- Parsing & validation ---------------------------------------------------------------

    /**
     * Extracts a domain from one line of a public list. Understands plain domains, hosts-file lines
     * ("0.0.0.0 example.com"), AdGuard/ABP lines ("||example.com^") and dnsmasq lines
     * ("address=/example.com/0.0.0.0"). Comments, blanks, IP-only lines and anything that is not a
     * valid host name give null.
     */
    fun parseLine(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty() || s[0] == '#' || s[0] == '!' || s[0] == '[' || s[0] == '/') return null
        val hash = s.indexOf(" #")
        if (hash >= 0) s = s.substring(0, hash).trim()
        when {
            s.startsWith("||") -> {
                s = s.removePrefix("||")
                val end = s.indexOfFirst { it == '^' || it == '/' || it == '$' }
                if (end >= 0) s = s.substring(0, end)
            }
            s.startsWith("address=/") -> {
                s = s.removePrefix("address=/")
                val end = s.indexOf('/')
                if (end >= 0) s = s.substring(0, end)
            }
            s.startsWith("server=/") -> {
                s = s.removePrefix("server=/")
                val end = s.indexOf('/')
                if (end >= 0) s = s.substring(0, end)
            }
            else -> {
                val parts = s.split(Regex("\\s+"))
                s = when {
                    parts.size >= 2 && looksLikeIp(parts[0]) -> parts[1]
                    parts.size == 1 -> parts[0]
                    else -> return null
                }
            }
        }
        s = s.removePrefix("*.").removePrefix(".")
        if (s.contains('*') || s.contains('|') || s.contains('^')) return null
        val d = normalizeEntry(s) ?: return null
        return d
    }

    private fun looksLikeIp(s: String) =
        s == "::" || s == "::1" || s.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$"))

    /** Normalizes a list entry; unlike [WebsiteRules.normalize] this keeps a leading "www." out and rejects paths. */
    fun normalizeEntry(raw: String): String? {
        val s = raw.trim().lowercase()
        if (s.isEmpty() || s.contains('/') || s.contains(':') || s.contains('@') || s.any { it.isWhitespace() }) return null
        return WebsiteRules.normalize(s)
    }

    /** [dataLines]: non-blank, non-comment lines seen. [parsedOk]: of those, lines that held a valid domain. */
    data class ParseStats(val dataLines: Int, val parsedOk: Int, val kept: Int)

    /** Result of turning raw source text into a clean, sorted, de-duplicated domain set. */
    data class Built(val domains: List<String>, val stats: ParseStats)

    private fun isCommentOrBlank(line: String): Boolean {
        val t = line.trim()
        return t.isEmpty() || t[0] == '#' || t[0] == '!' || t[0] == '['
    }

    /**
     * Builds the clean list from the lines of one or more sources: parse, validate, drop entries
     * that sit under the never-block list, de-duplicate, sort in byte order, and drop entries
     * already covered by a listed parent domain (a parent blocks its subdomains anyway).
     */
    fun build(lines: Sequence<String>): Built {
        var dataLines = 0
        var parsedOk = 0
        val set = HashSet<String>()
        for (line in lines) {
            if (isCommentOrBlank(line)) continue
            dataLines++
            val d = parseLine(line) ?: continue
            parsedOk++
            if (isProtected(d)) continue
            set.add(d)
        }
        val sorted = set.toMutableList().also { it.sortWith(BYTE_ORDER) }
        val kept = ArrayList<String>(sorted.size)
        for (d in sorted) {
            val covered = candidates(d).drop(1).any { it in set }
            if (!covered) kept.add(d)
        }
        return Built(kept, ParseStats(dataLines, parsedOk, kept.size))
    }

    /** Plain byte-order comparison, the order the on-disk file and its binary search use. */
    val BYTE_ORDER: Comparator<String> = Comparator { a, b ->
        val n = minOf(a.length, b.length)
        for (i in 0 until n) {
            val d = a[i].code - b[i].code
            if (d != 0) return@Comparator d
        }
        a.length - b.length
    }

    fun encode(domains: List<String>): ByteArray {
        val sb = StringBuilder(domains.size * 16)
        for (d in domains) sb.append(d).append('\n')
        return sb.toString().toByteArray(Charsets.UTF_8)
    }

    fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

    // ---- Update safety ----------------------------------------------------------------------

    /** Why a downloaded list was refused. */
    enum class Refusal {
        TOO_SMALL, TOO_MANY_BAD_LINES, SHRANK_TOO_MUCH, TOO_LARGE, NOT_SORTED_OR_DUPLICATE, NONE
    }

    const val MIN_ENTRIES = 50
    const val MAX_ENTRIES = 3_000_000
    /** A refresh that drops more than this share of the current list is treated as broken. */
    const val MAX_SHRINK = 0.5
    /** At least this share of the non-comment lines must be valid domains, or the file is not a domain list. */
    const val MIN_VALID_RATIO = 0.90

    /**
     * Decides whether [built] may replace a working list of [currentCount] entries. Never accepts an
     * empty, tiny, mostly-garbage or sharply shrunk list.
     */
    fun judge(built: Built, currentCount: Int): Refusal {
        val n = built.domains.size
        if (n < MIN_ENTRIES) return Refusal.TOO_SMALL
        if (n > MAX_ENTRIES) return Refusal.TOO_LARGE
        val d = built.stats.dataLines
        if (d > 0 && built.stats.parsedOk.toDouble() / d < MIN_VALID_RATIO) return Refusal.TOO_MANY_BAD_LINES
        if (currentCount > 0 && n < currentCount * (1.0 - MAX_SHRINK)) return Refusal.SHRANK_TOO_MUCH
        return Refusal.NONE
    }

    /** Checks the file really is a sorted, unique, valid domain file; used on install and after every download. */
    fun verifyFile(file: File): Int {
        var count = 0
        var prev: String? = null
        file.bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                if (line.isEmpty()) throw IllegalStateException("blank line")
                if (normalizeEntry(line) != line) throw IllegalStateException("bad entry: $line")
                val p = prev
                if (p != null && BYTE_ORDER.compare(p, line) >= 0) throw IllegalStateException("not sorted/unique at: $line")
                prev = line
                count++
            }
        }
        return count
    }
}

/**
 * Binary search over a sorted domain file without loading it. Lines are '\n' separated, ASCII.
 * Thread-safe (lookups are serialized on the file handle); a lookup reads roughly 20 small blocks.
 */
class SortedDomainIndex(private val file: File) : AutoCloseable {

    private var raf: RandomAccessFile? = null

    val size: Long get() = file.length()
    val exists: Boolean get() = file.isFile && file.length() > 0

    @Synchronized
    private fun handle(): RandomAccessFile =
        raf ?: RandomAccessFile(file, "r").also { raf = it }

    @Synchronized
    override fun close() {
        try { raf?.close() } catch (_: Exception) {}
        raf = null
    }

    @Synchronized
    fun contains(domain: String): Boolean {
        if (!exists) return false
        val target = domain.toByteArray(Charsets.US_ASCII)
        val f = handle()
        var lo = 0L
        var hi = f.length()
        // Invariant: any line starting in [lo, hi) is a candidate; lines start after '\n' or at 0.
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            val start = lineStart(f, mid)
            val line = readLine(f, start)
            val cmp = compare(line.bytes, target)
            when {
                cmp == 0 -> return true
                cmp < 0 -> lo = start + line.bytes.size + 1 // line is smaller: continue after it
                else -> hi = start
            }
        }
        return false
    }

    private fun lineStart(f: RandomAccessFile, pos: Long): Long {
        var p = pos
        while (p > 0) {
            f.seek(p - 1)
            if (f.read() == '\n'.code) return p
            p--
        }
        return 0L
    }

    private class Line(val bytes: ByteArray)

    private fun readLine(f: RandomAccessFile, start: Long): Line {
        f.seek(start)
        val buf = java.io.ByteArrayOutputStream(32)
        while (true) {
            val b = f.read()
            if (b < 0 || b == '\n'.code) break
            buf.write(b)
        }
        return Line(buf.toByteArray())
    }

    private fun compare(a: ByteArray, b: ByteArray): Int {
        val n = minOf(a.size, b.size)
        for (i in 0 until n) {
            val d = (a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)
            if (d != 0) return d
        }
        return a.size - b.size
    }
}
