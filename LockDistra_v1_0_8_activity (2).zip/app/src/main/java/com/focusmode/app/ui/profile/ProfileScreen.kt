package com.focusmode.app.ui.profile

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.OnboardingQuestions
import com.focusmode.app.data.profile.ProfileOnboarding
import com.focusmode.app.data.profile.ProfileRepository
import com.focusmode.app.data.profile.ProfileResult
import com.focusmode.app.data.profile.ProfileRules
import com.focusmode.app.data.profile.ProfileState
import com.focusmode.app.data.profile.SyncStatus
import com.focusmode.app.data.profile.UserProfile
import com.focusmode.app.ui.auth.AuthMessage
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.theme.FocusTheme
import java.text.DateFormat
import java.util.Date

/**
 * The profile of the logged-in account: avatar / photo, name, registered email, account information, the seven
 * onboarding answers, and Edit profile. All data comes from [ProfileRepository] (phone copy first, then the server),
 * so it shows at once, works offline and always belongs to the account that is logged in.
 *
 * @param onBack leaves the screen
 * @param onOpenAuth opens the login screens (shown when nobody is logged in)
 * @param onNameChanged called after a successful save with the new name (keeps the Home greeting in step)
 */
@Composable
fun ProfileScreen(
    onBack: () -> Unit,
    onOpenAuth: () -> Unit,
    onNameChanged: (String) -> Unit,
) {
    val context = LocalContext.current
    val repo = remember { ProfileRepository.get(context) }
    val state by repo.state.collectAsStateWithLifecycle()
    var editing by rememberSaveable { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { repo.refresh() }

    val current = state
    // If the account goes away while editing (logged out elsewhere), the edit form closes.
    LaunchedEffect(current is ProfileState.Ready) { if (current !is ProfileState.Ready) editing = false }
    if (editing && current is ProfileState.Ready) {
        BackHandler { editing = false }
        EditProfileScreen(
            profile = current.profile,
            onCancel = { editing = false },
            onSave = { name, avatar, photo ->
                val result = repo.updateProfile(name, avatar, photo)
                if (result is ProfileResult.Saved) {
                    onNameChanged(ProfileRules.cleanName(name))
                    notice = if (result.onServer) "Profile saved." else "Saved on this phone. It will sync when you're back online."
                    editing = false
                }
                result
            },
        )
        return
    }
    val c = FocusTheme.colors
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Text("Profile", style = MaterialTheme.typography.titleLarge)
        }

        when (current) {
            ProfileState.Loading -> Box(Modifier.fillMaxWidth().padding(vertical = 64.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = c.accent)
            }

            ProfileState.SignedOut -> FocusCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("You're not logged in", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Log in or create an account to keep your profile and your answers safe.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.muted,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(16.dp))
                    PrimaryButton("Log in or create account", onClick = onOpenAuth)
                }
            }

            is ProfileState.Ready -> {
                notice?.let {
                    AuthMessage(it, isError = false)
                    Spacer(Modifier.height(12.dp))
                }
                SyncBanner(current, onRetry = { repo.refresh() })
                HeaderCard(current.profile, onEdit = { notice = null; editing = true })
                Spacer(Modifier.height(24.dp))
                SectionLabel("Account")
                AccountCard(current.profile, current.sync, current.pending)
                Spacer(Modifier.height(24.dp))
                SectionLabel("Your focus setup")
                AnswersCard(current.profile.onboarding)
            }
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun SyncBanner(state: ProfileState.Ready, onRetry: () -> Unit) {
    val c = FocusTheme.colors
    when (state.sync) {
        SyncStatus.SYNCING -> {
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = c.accent)
                Spacer(Modifier.size(10.dp))
                Text("Syncing your profile...", style = MaterialTheme.typography.bodySmall, color = c.muted)
            }
        }
        SyncStatus.OFFLINE, SyncStatus.ERROR -> {
            AuthMessage(state.message.orEmpty(), isError = state.sync == SyncStatus.ERROR)
            TextButton(onClick = onRetry) { Text("Try again", color = c.accent) }
            Spacer(Modifier.height(4.dp))
        }
        SyncStatus.SYNCED -> Unit
    }
}

@Composable
private fun HeaderCard(profile: UserProfile, onEdit: () -> Unit) {
    val c = FocusTheme.colors
    FocusCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            ProfileAvatar(profile.displayName, profile.avatarId, profile.photoB64, size = 104.dp)
            Spacer(Modifier.height(14.dp))
            Text(profile.displayName, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
            if (profile.email.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(profile.email, style = MaterialTheme.typography.bodyMedium, color = c.muted, textAlign = TextAlign.Center)
            }
            Spacer(Modifier.height(18.dp))
            PrimaryButton("Edit profile", onClick = onEdit, icon = Icons.Rounded.Edit)
        }
    }
}

@Composable
private fun AccountCard(profile: UserProfile, sync: SyncStatus, pending: Boolean) {
    val date = remember(profile.createdAt) {
        if (profile.createdAt > 0L) DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(profile.createdAt)) else null
    }
    FocusCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            InfoRow("Name", profile.displayName)
            Divider()
            InfoRow("Email", profile.email.ifBlank { "Not available" })
            Divider()
            InfoRow("Signed in with", profile.provider.label)
            if (date != null) {
                Divider()
                InfoRow("Member since", date)
            }
            Divider()
            InfoRow(
                "Storage",
                when {
                    sync == SyncStatus.SYNCING -> "Syncing..."
                    pending -> "Saved on this phone, not synced yet"
                    else -> "Saved to your account"
                },
            )
        }
    }
}

@Composable
private fun AnswersCard(ob: ProfileOnboarding?) {
    val c = FocusTheme.colors
    FocusCard(Modifier.fillMaxWidth()) {
        if (ob == null) {
            Text(
                "No onboarding answers are saved for this account yet.",
                style = MaterialTheme.typography.bodyMedium,
                color = c.muted,
            )
            return@FocusCard
        }
        val q = OnboardingQuestions
        fun label(question: String, id: String?) = ProfileRules.optionLabel(question, id)
        val distractions = ob.distractions.mapNotNull { label(q.DISTRACTIONS, it) }.joinToString(", ")
        Column(Modifier.fillMaxWidth()) {
            InfoRow("Name", ob.name.ifBlank { "Not answered" })
            Divider()
            InfoRow("Main goal", label(q.GOAL, ob.goal) ?: "Not answered")
            Divider()
            InfoRow("Biggest distractions", distractions.ifBlank { "Not answered" })
            Divider()
            InfoRow("Daily phone use", label(q.PHONE_TIME, ob.phoneTime) ?: "Not answered")
            Divider()
            InfoRow("Focus session", label(q.SESSION_LENGTH, ob.sessionLength) ?: "Not answered")
            Divider()
            InfoRow("Daily focus goal", ProfileRules.dailyGoalText(ob.dailyGoal, ob.dailyGoalMinutes) ?: "Not answered")
            Divider()
            InfoRow("Heard about us from", label(q.SOURCE, ob.source) ?: "Skipped")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    val c = FocusTheme.colors
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = c.muted, modifier = Modifier.weight(0.42f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = c.text, modifier = Modifier.weight(0.58f), textAlign = TextAlign.End)
    }
}

@Composable
private fun Divider() = HorizontalDivider(color = FocusTheme.colors.stroke)
