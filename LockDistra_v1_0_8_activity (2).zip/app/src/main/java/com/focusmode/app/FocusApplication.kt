package com.focusmode.app

import android.app.Application
import com.focusmode.app.data.online.FirebaseGateway

/**
 * Only starts Firebase (when this build has a config). Everything else in LockDistra starts exactly
 * as before. Nothing goes over the network until a trusted phone is connected.
 */
class FocusApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // FIRST thing in the process: after a restart the system may start this process (to bind the accessibility
        // service) before or without the boot broadcast reaching it. Nothing may run before the cover is up.
        runCatching {
            if (android.os.SystemClock.elapsedRealtime() < 5 * 60_000L) {
                com.focusmode.app.service.BootCoverService.startIfNeeded(this, "app start")
            }
        }
        runCatching { com.focusmode.app.service.LostGuardService.startIfNeeded(this) }
        FirebaseGateway.init(this)
        // Join the "all" topic once, so the admin's message to every phone arrives.
        runCatching { FirebaseGateway.subscribeBroadcast(this) }
        // The admin message channel must exist BEFORE a push arrives with the app closed (the system shows that
        // push itself, on this channel), so it is created here at every start.
        runCatching { com.focusmode.app.service.AdminMessageNotifications.ensureChannel(this) }
        // Older builds kept a permanent "Ready for unlock requests" notification alive. The Worker's push
        // replaced it, so remove what is left of it after an update.
        runCatching {
            val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
            nm.cancel(1011)
            nm.deleteNotificationChannel("approver_listener_v1")
        }
        // Bedtime Mode: re-arm its start / end alarm (a force-stop clears alarms).
        runCatching { com.focusmode.app.service.BedtimeEngine.sync(this) }
        // Auto Focus: re-arm the start-time alarm and start a window that is already running. This is what makes it
        // work with the app closed: the alarm / Accessibility service wakes the process, and this runs first.
        runCatching {
            com.focusmode.app.service.AutoFocusEngine.process(this)
            com.focusmode.app.service.AutoFocusEngine.schedule(this)
        }
        // Day Coach: re-arm the alarm for the next block / reminder and do what is already due (a force-stop clears alarms).
        runCatching { com.focusmode.app.service.DayCoachEngine.tick(this) }
        // Study: new-video notifications for followed channels (the same schedule is kept, never doubled).
        runCatching { com.focusmode.app.service.StudyUpdatesWorker.schedule(this) }
        // Adult Content Blocking: make sure the bundled domain database is installed locally (disk work, off the main thread).
        Thread {
            runCatching { com.focusmode.app.data.AdultBlockStore.get(this).ensureInstalled() }
        }.start()
        // Nothing connects at start-up. The connection opens when something happens (a request is sent, a push
        // arrives, a screen needs it) and Firebase closes it again when idle.
    }
}
