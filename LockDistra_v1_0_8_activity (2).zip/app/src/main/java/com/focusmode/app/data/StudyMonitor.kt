package com.focusmode.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Where the Study videos are coming from right now. Only the title colour shows it; no message is ever shown to the person. */
enum class StudyMode {
    /** YouTube Data API (normal). Title keeps its normal colour. */
    API,

    /** YouTube's page data read directly ([StudyNative]): the API is resting. Title turns yellow. */
    PAGE,

    /** The WebView search ([StudyWebSearch]): last backup. Title turns red. */
    WEB,
}

/**
 * Remembers the source that last delivered results, so the screen can tint the title. Pure Kotlin (a StateFlow), so the
 * repository, the API and the screen can all use it, and it is unit tested on the JVM.
 */
object StudyMonitor {
    private val state = MutableStateFlow(StudyMode.API)
    val mode: StateFlow<StudyMode> = state

    /** A source just delivered live results (or, for [StudyMode.WEB], just took over). */
    fun report(m: StudyMode) { state.value = m }

    /**
     * What the NEXT request will use, before any answer is known: an API that is ready means [StudyMode.API]; a resting API
     * moves API to PAGE (a WEB state stays, it is already a backup).
     */
    fun sync(apiAvailable: Boolean) {
        if (apiAvailable) state.value = StudyMode.API
        else if (state.value == StudyMode.API) state.value = StudyMode.PAGE
    }
}
