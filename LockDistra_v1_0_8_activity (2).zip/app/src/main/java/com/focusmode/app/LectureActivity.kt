package com.focusmode.app

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.lifecycleScope
import com.focusmode.app.data.BookmarkRules
import com.focusmode.app.data.LectureBookmarkRemote
import com.focusmode.app.data.auth.AuthRepository
import com.focusmode.app.data.auth.AuthSession
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.LectureLayout
import com.focusmode.app.data.LectureLink
import com.focusmode.app.data.LectureLockStore
import com.focusmode.app.data.LectureTarget
import com.focusmode.app.data.VideoRatio
import com.focusmode.app.ui.lecture.BookmarkBar
import com.focusmode.app.ui.lecture.LecturePlantPanel
import com.focusmode.app.ui.lecture.LecturePreviewPanel
import com.focusmode.app.ui.lecture.LecturePlayerHtml
import com.focusmode.app.ui.theme.FocusModeTheme

/**
 * Lecture Lock player. The lecture link chosen in the start wizard (any platform) plays here and this page can show
 * nothing else:
 *  - YouTube: LockDistra's own player (the official embedded player with LockDistra's controls: play / pause, 10 s skip, seek,
 *    speed, rotate / full screen). In portrait the running session's timer and plant are shown under the video; in
 *    landscape the video fills the screen. No suggestions: the player's touches are covered and its end screen is
 *    hidden. The watched time is saved, so the lecture resumes where it stopped.
 *  - If YouTube does not allow a video to be embedded, the player switches to the normal page by itself (the page is
 *    pinned to the same video, suggestions are hidden as far as YouTube's page allows, and it resumes at the saved time).
 *  - Every other link: the page is opened as it is; any move to another page of the site is cancelled and the lecture is
 *    loaded again. Sign-in pages stay reachable.
 *
 * The Accessibility service closes the platform's own app and its site in the browsers while the lecture runs, so
 * there is no other way to play a different video of that platform.
 */
class LectureActivity : ComponentActivity() {

    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var bar: LinearLayout
    private lateinit var playerBox: FrameLayout
    private lateinit var plantHost: ComposeView
    private lateinit var web: WebView
    private lateinit var target: LectureTarget
    private lateinit var tryPage: TextView
    /** The "Background" button of the top bar: background play on / off (the same switch as in the player). */
    private lateinit var bgButton: TextView
    private lateinit var store: LectureLockStore

    /** Set when a Study video is just being watched (no Focus session): the player shows its details and "Start Focus Mode". */
    private var previewVideo: com.focusmode.app.data.StudyVideo? = null

    /** Where the watched time is saved: the YouTube video id, or the link for any other lecture. */
    private lateinit var posKey: String

    /** Bookmarks of this video (own player only: the normal-page fallback has no way to read / set the time). */
    private lateinit var bookmarkStore: com.focusmode.app.data.LectureBookmarkStore
    private var bookmarks by mutableStateOf<List<com.focusmode.app.data.Bookmark>>(emptyList())
    private var bookmarksOn by mutableStateOf(false)
    private var syncNote by mutableStateOf("")
    private val bookmarkSyncLock = Mutex()
    private val bookmarkRemote by lazy { LectureBookmarkRemote(this) }

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    /** YouTube only: true while LockDistra's own player is shown, false after the switch to the normal page. */
    private var embedMode = false

    /** The page the lecture link ended up on after its redirects; the first page load may move freely. */
    private var settledUrl: String? = null
    private var firstLoadDone = false

    /** True while the own player fills the whole screen (landscape). */
    private var fullscreen = false

    /** Shape (width / height) of the lecture video: 16:9 until the real one is found (then it is remembered). */
    private var ratio = LectureLayout.DEFAULT_RATIO
    private var lastSize = 0 to 0

    /** Keeps the Focus timer in step with the lecture (it stands still while the lecture is not playing). */
    private val timerHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val timerTick = object : Runnable {
        override fun run() {
            if (previewVideo == null) runCatching { com.focusmode.app.service.LectureTimerGuard.tick(applicationContext) }
            timerHandler.postDelayed(this, 300L)
        }
    }

    /** Which seconds of the lecture were really watched (seeking to the end does not count). Null for a Study preview. */
    private var watch: com.focusmode.app.data.LectureWatch? = null
    private var lastWatchSave = 0L
    @Volatile private var lastDuration = 0.0

    /** Player menu switches for this video (both off unless the person turned them on). */
    @Volatile private var pipOn = false
    @Volatile private var repeatOn = false
    /** True while the player is in the small floating window. */
    private var inPip = false

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = LectureLockStore.get(this)
        val url = intent.getStringExtra(EXTRA_URL) ?: store.url
        val parsed = url?.let { LectureLink.parse(it) }
        if (parsed == null) {
            finish()
            return
        }
        target = parsed
        previewVideo = intent.getStringExtra(EXTRA_PREVIEW_VIDEO)?.let { com.focusmode.app.data.StudyRules.fromJson(it).firstOrNull() }
        posKey = target.youtubeId ?: target.url
        bookmarkStore = com.focusmode.app.data.LectureBookmarkStore.get(this)
        bookmarks = bookmarkStore.list(posKey)
        if (previewVideo == null) watch = com.focusmode.app.data.LectureWatch(store.watched(posKey))
        pipOn = store.option(posKey, "pip")
        repeatOn = store.option(posKey, "rep")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val focusStore = FocusStore.get(applicationContext)
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bar = buildBar()
        web = WebView(this).apply { setBackgroundColor(Color.BLACK) }
        playerBox = FrameLayout(this).apply {
            addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        plantHost = ComposeView(this).apply {
            setContent {
                val st by focusStore.state.collectAsStateWithLifecycle()
                FocusModeTheme(st.themeMode) {
                    val pv = previewVideo
                    Column(Modifier.fillMaxSize()) {
                        Box(Modifier.weight(1f)) {
                            if (pv != null) LecturePreviewPanel(pv, onStartFocus = { startFocusFromPreview(pv) }) else LecturePlantPanel(st)
                        }
                        // Bottom strip: pause + bookmark this moment, or jump to a saved one.
                        if (bookmarksOn) BookmarkBar(
                            bookmarks = bookmarks,
                            syncNote = syncNote,
                            onCapture = { done -> captureBookmarkTime(done) },
                            onSave = { sec, title -> bookmarks = bookmarkStore.add(posKey, sec, title); syncBookmarks() },
                            onDelete = { id -> bookmarks = bookmarkStore.remove(posKey, id); syncBookmarks() },
                            onSeek = { sec -> seekVideoTo(sec) },
                            onResume = { playVideo() },
                        )
                    }
                }
            }
        }
        content.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        content.addView(playerBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        content.addView(plantHost, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        keepClearOfSystemBars()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = backPressed()
        })

        configure(web)
        embedMode = target.youtubeId != null
        bookmarksOn = embedMode
        tryPage.visibility = if (embedMode) View.VISIBLE else View.GONE
        bgButton.visibility = if (embedMode) View.VISIBLE else View.GONE
        updateBgButton()
        // Background play was left ON for this video: Android 12+ needs the floating-window setting from the start.
        if (Build.VERSION.SDK_INT >= 31) runCatching { setPictureInPictureParams(pipParams()) }
        val known = store.ratio(posKey)
        if (known > 0f) ratio = LectureLayout.clampRatio(known)
        else VideoRatio.fromLink(target.url)?.let { ratio = it; store.saveRatio(posKey, it) }
        val settled = ratio != LectureLayout.DEFAULT_RATIO || known > 0f
        // The free height is only known once the screen is laid out (and again after a rotation): lay out again then.
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val size = (r - l) to (b - t)
            if (size != lastSize) {
                lastSize = size
                if (::web.isInitialized) applyLayout()
            }
        }
        applyLayout()
        load()
        if (embedMode && !settled) detectRatio()
        syncBookmarks()
    }

    /** YouTube: asks for the video's real shape once (off the main thread), then redraws the player and the layout. */
    private fun detectRatio() {
        val id = target.youtubeId ?: return
        Thread {
            // One more try when the first look-up fails (slow network), so the video is not left in a 16:9 box.
            val found = VideoRatio.fetchYoutube(id) ?: run { Thread.sleep(2500); VideoRatio.fetchYoutube(id) } ?: return@Thread
            store.saveRatio(posKey, found)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                ratio = found
                web.evaluateJavascript("if(window.setRatio)setRatio(" + found + ")", null)
                applyLayout()
            }
        }.start()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Opened again for the same session: it is already playing, nothing to do.
        setIntent(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::web.isInitialized) applyLayout()
    }

    override fun onStart() {
        super.onStart()
        visible = true
        timerHandler.removeCallbacks(timerTick)
        timerHandler.post(timerTick)
    }

    override fun onStop() {
        // Still "in the floating window" when the screen stops: the window was closed with its X, so stop the sound.
        if (inPip && ::web.isInitialized) web.evaluateJavascript("try{P.pauseVideo()}catch(e){}", null)
        visible = false
        timerHandler.removeCallbacks(timerTick)
        saveWatch(force = true)
        super.onStop()
    }

    // ---- Background play = Picture-in-Picture (the video stays visible in a small window; see LECTURE_PIP.md) ----

    private fun pipParams(): PictureInPictureParams {
        val shape = ratio.coerceIn(0.42f, 2.38f)
        val b = PictureInPictureParams.Builder().setAspectRatio(Rational((shape * 1000).toInt(), 1000))
        if (Build.VERSION.SDK_INT >= 31) b.setAutoEnterEnabled(pipOn && embedMode)
        return b.build()
    }

    private fun pipAllowed(): Boolean =
        Build.VERSION.SDK_INT >= 26 && pipOn && embedMode && !isFinishing && customView == null &&
            packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Home / recents pressed while the switch is on: the video moves to the floating window and keeps playing.
        if (pipAllowed() && !inPip) runCatching { enterPictureInPictureMode(pipParams()) }
    }

    @Suppress("DEPRECATION")
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (::web.isInitialized) web.evaluateJavascript("if(window.setPip)setPip(" + isInPictureInPictureMode + ")", null)
        applyLayout()
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.onResume()
    }

    override fun onPause() {
        // The lecture keeps playing with the screen on; it is paused only when this screen really goes away.
        if (::web.isInitialized && isFinishing) web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        visible = false
        timerHandler.removeCallbacks(timerTick)
        if (::web.isInitialized) {
            (web.parent as? ViewGroup)?.removeView(web)
            web.stopLoading()
            web.destroy()
        }
        super.onDestroy()
    }

    private fun backPressed() {
        when {
            customView != null -> hideCustom()
            isLandscape() -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else -> finish()
        }
    }

    // ---- UI ----------------------------------------------------------------------------------

    private fun isLandscape() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun toggleLandscape() {
        requestedOrientation = if (isLandscape()) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    /**
     * Portrait + own player: the video in a box of its own shape (16:9, 4:3, vertical ...) with the timer and plant under
     * it, but only when enough room is left for them; otherwise the strip is hidden and the video gets the free height.
     * Landscape + own player: the video fills the screen (no bar, no system bars). The normal page always fills the screen.
     */
    private fun applyLayout() {
        if (inPip) {
            // Floating window: only the picture, no bar, no timer / plant strip.
            val pl = playerBox.layoutParams as LinearLayout.LayoutParams
            pl.height = 0
            pl.weight = 1f
            playerBox.layoutParams = pl
            bar.visibility = View.GONE
            plantHost.visibility = View.GONE
            root.setPadding(0, 0, 0, 0)
            return
        }
        val land = isLandscape()
        // Full screen (landscape + own player): the video goes behind the status / navigation bars and the camera cutout.
        fullscreen = embedMode && land
        val lp = playerBox.layoutParams as LinearLayout.LayoutParams
        var showPanel = false
        if (embedMode && !land) {
            val density = resources.displayMetrics.density
            val width = if (content.width > 0) content.width else resources.displayMetrics.widthPixels
            val available = if (content.height > 0) content.height - bar.height else 0
            val plan = LectureLayout.plan(available, width, ratio, (MIN_PANEL_DP * density).toInt())
            showPanel = plan.showPanel
            if (plan.showPanel) {
                lp.height = plan.videoHeight
                lp.weight = 0f
            } else {
                lp.height = 0
                lp.weight = 1f
            }
        } else {
            lp.height = 0
            lp.weight = 1f
        }
        playerBox.layoutParams = lp
        plantHost.visibility = if (showPanel) View.VISIBLE else View.GONE
        val immersive = fullscreen
        bar.visibility = if (immersive) View.GONE else View.VISIBLE
        if (customView == null) hideSystemBars(immersive)
        root.requestApplyInsets()
    }

    private fun buildBar(): LinearLayout {
        val dp = resources.displayMetrics.density
        fun button(text: String, onClick: () -> Unit) = TextView(this).apply {
            this.text = text
            setTextColor(Color.parseColor("#C77DFF"))
            textSize = 13f
            setPadding((8 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt())
            setOnClickListener { onClick() }
        }
        val title = TextView(this).apply {
            text = if (previewVideo != null) "Study video" else "Lecture  ·  only this video plays"
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        tryPage = button("Not playing?") { switchToPage() }
        bgButton = button("Background") { toggleBackground() }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#14102B"))
            setPadding((14 * dp).toInt(), 0, (4 * dp).toInt(), 0)
            addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val pv = previewVideo
            if (pv != null) addView(button("Focus Mode") { startFocusFromPreview(pv) })
            else addView(button("Change video") { changeVideo() })
            addView(bgButton)
            addView(button("Rotate") { toggleLandscape() })
            addView(button("Close") { finish() })
        }
    }

    /** Android 15 draws apps edge to edge: keep the bar and the player clear of the system bars. */
    @Suppress("DEPRECATION")
    private fun keepClearOfSystemBars() {
        root.setOnApplyWindowInsetsListener { v, insets ->
            // In full screen the video covers everything (nothing is kept clear), otherwise it stays clear of the bars.
            if (fullscreen || inPip || customView != null) v.setPadding(0, 0, 0, 0)
            else v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            insets
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(w: WebView) {
        w.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            loadWithOverviewMode = true
            useWideViewPort = true
        }
        w.addJavascriptInterface(PlayerBridge(), BRIDGE)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)

        w.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                customView = view
                customCallback = callback
                content.visibility = View.GONE
                root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                hideSystemBars(true)
            }

            override fun onHideCustomView() = hideCustom()
        }

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                return if (allowed(request.url.toString())) false else {
                    denied()
                    true
                }
            }

            // Pages that change the address by themselves (no new load): bring the lecture back at once, at the
            // time already watched (not from the start).
            override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                if (url == null || !firstLoadDone || embedMode) return
                if (!allowed(url)) {
                    denied()
                    val back = target.youtubeId?.let { resumeUrl(it) } ?: settledUrl ?: target.url
                    view.post { view.loadUrl(back) }
                }
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (!firstLoadDone && url != null && url != "about:blank") {
                    firstLoadDone = true
                    if (!LectureLink.isLoginPage(url)) settledUrl = url
                }
                if (!embedMode && url != null && url != "about:blank") view.evaluateJavascript(pageScript(), null)
                // The video's shape may have been found while the player page was still loading.
                if (embedMode && url != null && url != "about:blank") {
                    view.evaluateJavascript("if(window.setRatio)setRatio(" + ratio + ")", null)
                    pushSkipped() // parts skipped earlier (saved) show on the bar again after a reload
                }
            }
        }
    }

    private fun allowed(url: String): Boolean {
        // The embedded player is the whole page: nothing may be opened from it.
        if (embedMode) return false
        if (!firstLoadDone) return true
        return LectureLink.isSameLecture(target, url, settledUrl) || LectureLink.isLoginPage(url)
    }

    private fun denied() {
        Toast.makeText(this, "Only your lecture video can play", Toast.LENGTH_SHORT).show()
    }

    /** The normal YouTube page of the video, opened at the time already watched. */
    private fun resumeUrl(id: String): String {
        val pos = store.position(posKey)
        return "https://m.youtube.com/watch?v=$id" + if (pos >= 5) "&t=${pos}s" else ""
    }

    /**
     * Runs on the normal (non-embedded) page: jumps to the saved time once the video is ready, reports the watched time
     * every 2 seconds and, on YouTube, hides the suggestion lists / Shorts shelves as far as the page's own names allow.
     */
    private fun pageScript(): String {
        val start = store.position(posKey).let { if (it >= 5) it else 0 }
        return PAGE_SCRIPT.replace("__START__", start.toString()).replace("__BRIDGE__", BRIDGE)
    }

    private fun load() {
        firstLoadDone = false
        settledUrl = null
        val id = target.youtubeId
        if (embedMode && id != null) {
            // YouTube refuses an embed whose page claims to BE youtube.com (error 152) and wants to know which app
            // embeds it, so the page gets the app's own address as origin / Referer. Any player error is reported to
            // the app, which then opens the normal page on its own.
            val origin = "https://$packageName"
            val startAt = store.position(posKey).let { if (it >= 5) it else 0 }
            web.loadDataWithBaseURL("$origin/", LecturePlayerHtml.build(id, origin, startAt, BRIDGE, ratio = ratio, pip = pipOn, repeat = repeatOn), "text/html", "utf-8", null)
            firstLoadDone = true
        } else {
            web.loadUrl(if (id != null) resumeUrl(id) else target.url)
        }
    }

    /** YouTube video that does not allow embedding: show its normal page, pinned to this one video. */
    private fun switchToPage() {
        embedMode = false
        bookmarksOn = false
        tryPage.visibility = View.GONE
        bgButton.visibility = View.GONE
        applyLayout()
        load()
    }

    // ---- Bookmarks ---------------------------------------------------------------------------

    /** Pauses the own player right now and hands back the second it stopped at (-1 = could not be read). */
    private fun captureBookmarkTime(done: (Int) -> Unit) {
        if (!embedMode || !::web.isInitialized) { done(-1); return }
        web.evaluateJavascript("(function(){try{var t=P.getCurrentTime()||0;P.pauseVideo();return Math.floor(t)}catch(e){return -1}})()") { r ->
            val sec = r?.trim()?.toDoubleOrNull()?.toInt() ?: -1
            if (sec < 0) Toast.makeText(this, "Could not read the video time. Try again in a moment.", Toast.LENGTH_SHORT).show()
            done(sec)
        }
    }

    /**
     * Joins this phone's bookmarks of the video with the copy on the server (account login needed), so they follow the person to
     * another phone. Offline or logged out: nothing is lost, the bookmarks stay on the phone and go up with the next sync.
     */
    private fun syncBookmarks() {
        if (!embedMode || !BookmarkRules.syncable(posKey)) return
        val uid = (AuthRepository.get(this).session.value as? AuthSession.SignedIn)?.user?.uid
        if (uid == null) {
            syncNote = "Log in to keep your bookmarks on the server."
            return
        }
        val video = posKey
        lifecycleScope.launch(Dispatchers.IO) {
            bookmarkSyncLock.withLock {
                val note = try {
                    bookmarkRemote.sync(uid, video, bookmarkStore)
                    "Saved on the server with your account."
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    "No connection: saved on this phone, it goes to the server later."
                }
                val shown = bookmarkStore.list(video)
                withContext(Dispatchers.Main) {
                    if (video == posKey) { bookmarks = shown; syncNote = note }
                }
            }
        }
    }

    private fun seekVideoTo(seconds: Int) {
        if (!embedMode || !::web.isInitialized) return
        web.evaluateJavascript("try{P.seekTo(" + seconds.coerceAtLeast(0) + ",true);P.playVideo()}catch(e){}", null)
    }

    private fun playVideo() {
        if (!embedMode || !::web.isInitialized) return
        web.evaluateJavascript("try{P.playVideo()}catch(e){}", null)
    }

    /** Called by the pages' scripts (own player and normal page). Runs on a background thread. */
    private inner class PlayerBridge {
        @JavascriptInterface
        fun onPlayerError(code: Double, unused: Double) {
            runOnUiThread {
                if (!embedMode || isFinishing) return@runOnUiThread
                Toast.makeText(this@LectureActivity, "Opening the normal YouTube page for this video", Toast.LENGTH_LONG).show()
                switchToPage()
            }
        }

        /** Every second from the page: 1 = the video is really playing (not paused, not buffering), 0 = it is not. */
        @JavascriptInterface
        fun onPlayState(playing: Double) {
            if (previewVideo != null) return
            playingAt = if (playing != 0.0) android.os.SystemClock.elapsedRealtime() else 0L
        }

        @JavascriptInterface
        fun onProgress(seconds: Double, duration: Double) = onTick(seconds, duration, 1.0)

        /** A progress report every few seconds: position, video length and the chosen speed. */
        @JavascriptInterface
        fun onTick(seconds: Double, duration: Double, speed: Double) {
            if (duration.isFinite() && duration > 0) lastDuration = duration
            if (seconds.isNaN() || seconds < 3) return
            val nearEnd = duration.isFinite() && duration > 30 && seconds >= duration - 8
            // Only part of the lecture that really played counts (a jump to the end does not).
            val w = watch
            if (w != null && duration.isFinite() && duration > 0) {
                w.report(seconds, duration, speed, android.os.SystemClock.elapsedRealtime())
                saveWatch(force = false)
                pushSkipped()
            }
            // A jump to the end does not finish the lecture, so the position is only reset when the lecture was really watched.
            val finishedForReal = nearEnd && (w == null || w.enough(duration))
            store.savePosition(posKey, if (finishedForReal) 0 else seconds.toInt())
            // "Turn OFF when the lecture ends" with a locked session: the safety timer follows what is still left to WATCH
            // (not the position), so dragging the seek bar to the end does not shorten the session.
            if (previewVideo == null && store.autoEnd && !repeatOn && duration.isFinite() && duration > 30) {
                val left = if (w != null) duration - w.watchedSeconds(duration) else duration - seconds
                val remainingMs = (left.coerceAtLeast(0.0) * 1000).toLong() + 2 * 60_000L
                com.focusmode.app.service.FocusController.syncEndToLecture(applicationContext, remainingMs)
            }
        }

        @JavascriptInterface
        fun onEnded(durationSeconds: Double, unused: Double) {
            // The page tells the video's length, so the check also works when the end was reached before the first progress report.
            if (durationSeconds.isFinite() && durationSeconds > 0) lastDuration = durationSeconds
            runOnUiThread { endFocusAfterLecture() }
        }

        @JavascriptInterface
        fun onOption(name: String, on: Double) {
            val v = on != 0.0
            when (name) {
                "pip" -> { pipOn = v; store.setOption(posKey, "pip", v); runOnUiThread { updateBgButton(); if (Build.VERSION.SDK_INT >= 31) runCatching { setPictureInPictureParams(pipParams()) } } }
                "rep" -> { repeatOn = v; store.setOption(posKey, "rep", v) }
            }
        }

        @JavascriptInterface
        fun onToggleLandscape(a: Double, b: Double) {
            runOnUiThread { toggleLandscape() }
        }
    }

    /**
     * "After this lecture" was chosen in the start wizard: the lecture is over, so Focus Mode (or the Pomodoro) ends by
     * itself. Only while a session really runs, so replaying the video later does nothing.
     */
    private fun endFocusAfterLecture() {
        if (isFinishing || previewVideo != null || !store.autoEnd) {
            // Nothing to protect (no "turn off after the lecture"): the video simply ended, so the next play starts fresh.
            store.savePosition(posKey, 0)
            if (previewVideo == null) {
                store.clearWatched(posKey)
                watch = com.focusmode.app.data.LectureWatch()
                // The lecture is over; the session goes on with a normal timer (it is no longer tied to the player).
                store.setDone(true)
            }
            return
        }
        val app = applicationContext
        val pomodoro = com.focusmode.app.data.PomodoroStore.get(app).current().active
        val focus = FocusStore.get(app).current().focusActive
        if (!focus && !pomodoro) {
            store.savePosition(posKey, 0)
            store.clearWatched(posKey)
            watch = com.focusmode.app.data.LectureWatch()
            return
        }
        // The video reached its end, but was it watched? A jump to the end (seek bar, +10 s again and again) does not
        // finish the lecture: Focus Mode stays on and the player offers to continue at the first part that was skipped.
        val w = watch
        val dur = lastDuration
        if (w != null && dur > 30 && !w.enough(dur)) {
            val gap = w.firstGap(dur)
            Toast.makeText(this, "Part of the lecture was skipped. Focus Mode stays on until you have watched it.", Toast.LENGTH_LONG).show()
            if (embedMode) web.evaluateJavascript("if(window.setSkipped)setSkipped(" + gap + ")", null)
            else web.evaluateJavascript("(function(){var v=document.querySelector('video');if(v){v.currentTime=" + gap + ";v.play()}})()", null)
            return
        }
        store.savePosition(posKey, 0)
        store.clearWatched(posKey)
        store.setAutoEnd(false)
        // A plain Focus session counts as finished; a Pomodoro cycle is ended as a whole.
        com.focusmode.app.service.FocusController.stop(app, completed = !pomodoro)
        Toast.makeText(this, "Lecture finished \uD83C\uDF93 Focus Mode is off. Great job! \uD83C\uDF89", Toast.LENGTH_LONG).show()
        finish()
    }

    /** Sends the skipped parts to the player's seek bar, where they show as red marks (own player only). */
    private fun pushSkipped() {
        if (!embedMode) return
        val w = watch ?: return
        val d = lastDuration
        if (d <= 30) return
        val json = w.skippedJson(d)
        runOnUiThread {
            if (::web.isInitialized && !isFinishing) web.evaluateJavascript("if(window.setGaps)setGaps($json)", null)
        }
    }

    /** Saves the watched parts (at most every 6 seconds, and always when the screen stops). */
    private fun saveWatch(force: Boolean) {
        val w = watch ?: return
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && now - lastWatchSave < 6_000L) return
        lastWatchSave = now
        if (!w.isEmpty()) store.saveWatched(posKey, w)
    }

    private fun updateBgButton() {
        if (!::bgButton.isInitialized) return
        bgButton.text = if (pipOn) "Background: On" else "Background"
        bgButton.setTextColor(if (pipOn) Color.WHITE else Color.parseColor("#C77DFF"))
        bgButton.setTypeface(null, if (pipOn) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
    }

    /**
     * The top bar's "Background" button: switch background play on / off for this video. While it is on, pressing Home keeps the
     * video playing in a small floating window (see LECTURE_PIP.md); it is the same switch as in the player's gear menu.
     */
    private fun toggleBackground() {
        if (!embedMode) return
        val on = !pipOn
        pipOn = on
        store.setOption(posKey, "pip", on)
        if (Build.VERSION.SDK_INT >= 31) runCatching { setPictureInPictureParams(pipParams()) }
        web.evaluateJavascript("if(window.setBg)setBg(" + on + ")", null)
        updateBgButton()
        Toast.makeText(
            this,
            if (on) "Background play ON. Press Home and the video keeps playing in a small window." else "Background play OFF.",
            Toast.LENGTH_SHORT
        ).show()
    }

    /** Preview: the video looked good, so Focus Mode starts for it. Study / the app picks the video up and opens the start wizard. */
    private fun startFocusFromPreview(v: com.focusmode.app.data.StudyVideo) {
        com.focusmode.app.data.StudyStore.get(applicationContext).armFocusStart(v)
        com.focusmode.app.data.LockSession.markOwnLaunch()
        runCatching {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            )
        }
        finish()
    }

    /** "Change video": back into the app's Study section to pick another (learning-only) video. The session keeps running. */
    private fun changeVideo() {
        com.focusmode.app.data.LockSession.markOwnLaunch()
        runCatching {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_OPEN_STUDY, true)
                    .putExtra(com.focusmode.app.data.IntentGuard.EXTRA_KEY, com.focusmode.app.data.IntentGuard.key(this))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }
        finish()
    }

    private fun hideCustom() {
        val v = customView ?: return
        root.removeView(v)
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        content.visibility = View.VISIBLE
        applyLayout()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars(hide: Boolean) {
        // Let the picture use the area behind the camera notch in full screen.
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = if (hide) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            }
        }
        window.decorView.systemUiVisibility = if (hide) {
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        } else View.SYSTEM_UI_FLAG_VISIBLE
    }

    companion object {
        const val EXTRA_URL = "com.focusmode.app.extra.LECTURE_URL"
        private const val BRIDGE = "ReWireBridge"

        /** The timer / plant strip is shown under the video only when at least this much height is left for it. */
        private const val MIN_PANEL_DP = 180 + 64 // + the bookmark strip at the bottom

        private const val PAGE_SCRIPT = """(function(){
if(window.__rwOn)return;window.__rwOn=1;var seeked=false,start=__START__;
if(location.host.indexOf('youtube.com')>=0){var st=document.createElement('style');
st.textContent='ytm-watch-next-secondary-results-renderer,ytm-related-chip-cloud-renderer,ytm-shorts-lockup-view-model,ytm-reel-shelf-renderer,ytm-comments-entry-point-header-renderer{display:none!important}';
(document.head||document.documentElement).appendChild(st);}
setInterval(function(){var v=document.querySelector('video');if(!v)return;
try{__BRIDGE__.onPlayState((!v.paused&&!v.ended&&v.readyState>=3)?1:0)}catch(e){}
if(!seeked&&v.readyState>0){seeked=true;if(start>5&&v.duration>start)v.currentTime=start;}
if(seeked&&v.currentTime>0){try{__BRIDGE__.onTick(v.currentTime,v.duration||0,v.playbackRate||1)}catch(e){}}
if(v.ended){if(!window.__rwEnd){window.__rwEnd=1;try{__BRIDGE__.onEnded(v.duration||0,0)}catch(e){}}}else window.__rwEnd=0;},2000);
})();"""

        /** When the page last said "the video is playing" (SystemClock.elapsedRealtime); 0 = not playing. */
        @Volatile private var playingAt = 0L

        /** The lecture really plays on screen right now: the player is showing AND the page said "playing" a moment ago. */
        fun playingNow(): Boolean =
            visible && playingAt != 0L && android.os.SystemClock.elapsedRealtime() - playingAt < 5_000L

        /** True while the player is on screen (read by the Accessibility service). */
        @Volatile
        var visible = false
            private set

        const val EXTRA_PREVIEW_VIDEO = "com.focusmode.app.extra.PREVIEW_VIDEO"

        /** Plays a Study video right away (no Focus session needed); the player shows "Start Focus Mode" under it. */
        fun previewIntent(context: Context, v: com.focusmode.app.data.StudyVideo): Intent =
            Intent(context, LectureActivity::class.java)
                .putExtra(EXTRA_URL, v.watchUrl)
                .putExtra(EXTRA_PREVIEW_VIDEO, com.focusmode.app.data.StudyRules.toJson(listOf(v)))

        fun launchIntent(context: Context, url: String): Intent =
            Intent(context, LectureActivity::class.java)
                .putExtra(EXTRA_URL, url)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
}
