package com.focusmode.app.ui.screens

import androidx.compose.ui.draw.clip
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.ui.components.AuroraBackground
import com.focusmode.app.ui.onboarding.BuddyPose
import com.focusmode.app.ui.onboarding.FocusBuddy
import com.focusmode.app.ui.theme.PoppinsFamily
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Remembers, for this process only, that the splash has already played once. */
object SplashState {
    @Volatile
    var shown: Boolean = false
}

private val SplashBase = Color(0xFF090514)
private val SplashMint = Color(0xFFC044FF)
private val SplashDeep = Color(0xFF7C3AED)
private val SplashText = Color(0xFFFFFFFF)
private val SplashMuted = Color(0xFFB9B0DA)

/**
 * Launch screen: only the cartoon buddy, waving hello, with the welcome text under it and the small
 * "By Re Arena" watermark at the bottom. Then the app opens ([onFinished] after about 2.8 s).
 * Always dark, whatever theme the rest of the app uses.
 */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val buddyAlpha = remember { Animatable(0f) }
    val buddyScale = remember { Animatable(0.85f) }
    val textAlpha = remember { Animatable(0f) }
    val brandAlpha = remember { Animatable(0f) }
    // Waves and talks ("Hey there!") first, then keeps waving quietly.
    var pose by remember { mutableStateOf(BuddyPose.GreetingTalking) }

    LaunchedEffect(Unit) {
        coroutineScope {
            launch { buddyAlpha.animateTo(1f, tween(450)) }
            launch { buddyScale.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = 180f)) }
            launch { delay(400); textAlpha.animateTo(1f, tween(650)) }
            launch { delay(900); brandAlpha.animateTo(1f, tween(650)) }
            launch { delay(1900); pose = BuddyPose.Greeting }
            launch { delay(2600) }
        }
        onFinished()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(SplashBase)
            // Swallow touches so nothing underneath reacts while the splash is up.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        AuroraBackground(
            modifier = Modifier.fillMaxSize(),
            base = SplashBase,
            glowA = SplashMint,
            glowB = SplashDeep,
        )

        Column(
            Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            androidx.compose.foundation.Image(
                painter = androidx.compose.ui.res.painterResource(com.focusmode.app.R.drawable.ic_lockdistra_logo),
                contentDescription = "LockDistra",
                modifier = Modifier
                    .size(240.dp)
                    .graphicsLayer {
                        scaleX = buddyScale.value
                        scaleY = buddyScale.value
                        alpha = buddyAlpha.value
                    }
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(44.dp)),
            )

            Spacer(Modifier.height(20.dp))
            Column(
                Modifier.graphicsLayer {
                    alpha = textAlpha.value
                    translationY = (1f - textAlpha.value) * 16.dp.toPx()
                },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Welcome",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontFamily = PoppinsFamily,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    ),
                    color = SplashText
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "to LockDistra",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = PoppinsFamily,
                        letterSpacing = 0.8.sp
                    ),
                    color = SplashMuted
                )
            }
        }

        // The only branding: a small "By Re Arena" watermark, centred at the bottom.
        Text(
            buildAnnotatedString {
                withStyle(SpanStyle(color = SplashMuted, fontWeight = FontWeight.Normal, letterSpacing = 0.8.sp)) {
                    append("By ")
                }
                withStyle(SpanStyle(color = SplashMint, fontWeight = FontWeight.SemiBold, letterSpacing = 1.4.sp)) {
                    append("Re Arena")
                }
            },
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 32.dp)
                .graphicsLayer { alpha = brandAlpha.value }
        )
    }
}
