package com.focusmode.app.data.profile

import android.content.Context
import android.content.SharedPreferences
import com.focusmode.app.data.auth.AuthProvider
import org.json.JSONObject

/**
 * The phone's copy of each account's profile (private app storage, not in backups: allowBackup is off).
 * One record per Firebase uid, so a record can only ever be shown to the account it belongs to. It is what
 * keeps the profile available instantly, offline and across restarts, and what remembers changes that
 * haven't reached the server yet.
 */
class ProfileStore private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("user_profiles", Context.MODE_PRIVATE)

    private fun key(uid: String) = "p_$uid"

    fun load(uid: String): LocalRecord? {
        val raw = prefs.getString(key(uid), null) ?: return null
        return try {
            val o = JSONObject(raw)
            if (o.optString("uid") != uid) return null
            val ob = o.optJSONObject("ob")?.let { b ->
                ProfileOnboarding(
                    name = b.optString("name"),
                    goal = b.str("goal"),
                    distractions = ProfileRules.decodeIds(b.str("distractions")),
                    phoneTime = b.str("phoneTime"),
                    sessionLength = b.str("sessionLength"),
                    dailyGoal = b.str("dailyGoal"),
                    dailyGoalMinutes = if (b.has("dailyGoalMinutes")) b.optInt("dailyGoalMinutes") else null,
                    source = b.str("source"),
                    completedAt = b.optLong("completedAt"),
                )
            }
            LocalRecord(
                profile = UserProfile(
                    uid = uid,
                    displayName = o.optString("name"),
                    email = o.optString("email"),
                    provider = AuthProvider.fromId(o.optString("provider")),
                    avatarId = o.optString("avatar"),
                    photoB64 = o.str("photo"),
                    createdAt = o.optLong("createdAt"),
                    updatedAt = o.optLong("updatedAt"),
                    onboarding = ob,
                ),
                dirtyProfile = o.optBoolean("dp"),
                dirtyOnboarding = o.optBoolean("do"),
                dirtyPhoto = o.optBoolean("dph"),
            )
        } catch (_: Exception) {
            null // unreadable copy: the server copy is fetched again
        }
    }

    fun save(rec: LocalRecord) {
        val p = rec.profile
        val o = JSONObject()
            .put("uid", p.uid)
            .put("name", p.displayName)
            .put("email", p.email)
            .put("provider", p.provider.name)
            .put("avatar", p.avatarId)
            .put("createdAt", p.createdAt)
            .put("updatedAt", p.updatedAt)
            .put("dp", rec.dirtyProfile)
            .put("do", rec.dirtyOnboarding)
            .put("dph", rec.dirtyPhoto)
        if (p.photoB64 != null) o.put("photo", p.photoB64)
        p.onboarding?.let { b ->
            val j = JSONObject().put("name", b.name).put("completedAt", b.completedAt)
            b.goal?.let { j.put("goal", it) }
            if (b.distractions.isNotEmpty()) j.put("distractions", ProfileRules.encodeIds(b.distractions))
            b.phoneTime?.let { j.put("phoneTime", it) }
            b.sessionLength?.let { j.put("sessionLength", it) }
            b.dailyGoal?.let { j.put("dailyGoal", it) }
            b.dailyGoalMinutes?.let { j.put("dailyGoalMinutes", it) }
            b.source?.let { j.put("source", it) }
            o.put("ob", j)
        }
        prefs.edit().putString(key(p.uid), o.toString()).commit()
    }

    /** Logging out removes the phone's copy, unless it holds changes the server doesn't have yet. */
    fun deleteIfSynced(uid: String) {
        val rec = load(uid)
        if (rec == null || !rec.pending) prefs.edit().remove(key(uid)).commit()
    }

    private fun JSONObject.str(k: String): String? =
        if (has(k) && !isNull(k)) optString(k).takeIf { it.isNotEmpty() } else null

    companion object {
        @Volatile private var instance: ProfileStore? = null

        fun get(context: Context): ProfileStore =
            instance ?: synchronized(this) {
                instance ?: ProfileStore(context.applicationContext).also { instance = it }
            }
    }
}
