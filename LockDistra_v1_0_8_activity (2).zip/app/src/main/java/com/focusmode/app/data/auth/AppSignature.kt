package com.focusmode.app.data.auth

import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import java.security.MessageDigest

/**
 * The SHA-1 fingerprint of the key THIS install was signed with. Google sign-in only opens when exactly this value is
 * added to the Android app in the Firebase console, so debug builds show it next to a Google error. Never throws.
 */
object AppSignature {
    @Suppress("DEPRECATION")
    fun sha1(context: Context): String? {
        return try {
            val pm = context.packageManager
            val signers: Array<Signature>? = if (Build.VERSION.SDK_INT >= 28) {
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners
            } else {
                pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures
            }
            val first = signers?.firstOrNull() ?: return null
            MessageDigest.getInstance("SHA-1").digest(first.toByteArray()).joinToString(":") { "%02X".format(it) }
        } catch (_: Exception) {
            null
        }
    }
}
