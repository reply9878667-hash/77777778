package com.focusmode.app.data

import java.net.IDN

/**
 * Website blocking rules, kept free of Android classes so they can be unit-tested.
 *
 * Websites are blocked per app: the YouTube panel owns "youtube.com", the Instagram panel owns
 * "instagram.com", and so on. A rule is a bare domain plus a switch for subdomains.
 */
data class WebsiteRule(
    /** Normalized host: lower case, no scheme / path / port / "www.". */
    val domain: String,
    val enabled: Boolean = true,
    /** True: "m.youtube.com" and "music.youtube.com" match "youtube.com" too. */
    val subdomains: Boolean = true,
)

object WebsiteRules {

    const val MAX_PER_APP = 30

    private val schemeRegex = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://")

    /**
     * Turns what the person typed (or what a browser's address bar shows) into a plain domain, or
     * null when it is not a usable host name.
     *
     * Accepts "youtube.com", "www.youtube.com", "https://m.youtube.com/watch?v=x", "YouTube.com:443"
     * and similar. Rejects search text ("how to youtube.com"), single words, IP addresses and
     * anything that is not a valid host name. A leading "www." is dropped because "www.x.com" and
     * "x.com" are the same site.
     */
    fun normalize(raw: String): String? {
        var s = raw.trim()
        if (s.isEmpty() || s.length > 2048) return null
        s = schemeRegex.replace(s, "")
        if (s.startsWith("//")) s = s.substring(2)
        // Host part only: up to the first / ? #
        val end = s.indexOfFirst { it == '/' || it == '?' || it == '#' }
        if (end >= 0) s = s.substring(0, end)
        // user:pass@host
        val at = s.lastIndexOf('@')
        if (at >= 0) s = s.substring(at + 1)
        // :port
        val colon = s.lastIndexOf(':')
        if (colon >= 0) {
            val port = s.substring(colon + 1)
            if (port.isEmpty() || !port.all { it.isDigit() } || port.length > 5) return null
            s = s.substring(0, colon)
        }
        if (s.isEmpty() || s.any { it.isWhitespace() }) return null
        s = s.trimEnd('.').lowercase()
        if (s.any { it.code > 127 }) {
            s = try {
                IDN.toASCII(s).lowercase()
            } catch (_: Exception) {
                return null
            }
        }
        if (s.startsWith("www.")) s = s.removePrefix("www.")
        return if (isValidHost(s)) s else null
    }

    /** Names people type instead of a link, and the site they mean. Anything else single-word becomes "<word>.com". */
    private val knownNames: Map<String, String> = mapOf(
        "youtube" to "youtube.com", "yt" to "youtube.com", "instagram" to "instagram.com", "insta" to "instagram.com",
        "facebook" to "facebook.com", "fb" to "facebook.com", "tiktok" to "tiktok.com", "snapchat" to "snapchat.com",
        "twitter" to "twitter.com", "x" to "x.com", "reddit" to "reddit.com", "netflix" to "netflix.com",
        "pinterest" to "pinterest.com", "twitch" to "twitch.tv", "discord" to "discord.com", "telegram" to "telegram.org",
        "whatsapp" to "whatsapp.com", "primevideo" to "primevideo.com", "hotstar" to "hotstar.com",
    )

    /**
     * Like [normalize], but also understands a plain website NAME: "youtube" -> youtube.com, "pornhub" -> pornhub.com.
     * Search text with spaces is still rejected. Used when the person ADDS a site by hand.
     */
    fun fromTyped(raw: String): String? {
        normalize(raw)?.let { return it }
        val w = raw.trim().lowercase()
        if (w.isEmpty() || w.length > 63 || !w.all { it in 'a'..'z' || it in '0'..'9' || it == '-' }) return null
        val guess = knownNames[w] ?: "$w.com"
        return normalize(guess)
    }

    private fun isValidHost(host: String): Boolean {
        if (host.length > 253) return false
        val labels = host.split('.')
        if (labels.size < 2) return false
        for (l in labels) {
            if (l.isEmpty() || l.length > 63) return false
            if (l.first() == '-' || l.last() == '-') return false
            if (!l.all { it in 'a'..'z' || it in '0'..'9' || it == '-' }) return false
        }
        val tld = labels.last()
        // Rules out IP addresses ("192.168.0.1") and "file.txt"-style numbers; punycode TLDs allowed.
        return tld.startsWith("xn--") || (tld.length >= 2 && tld.all { it in 'a'..'z' })
    }

    /**
     * Whether [host] (already normalized) is covered by [rule]. A subdomain matches only at a dot
     * boundary, so "notyoutube.com" and "youtube.com.evil.net" never match "youtube.com".
     */
    fun matches(host: String, rule: WebsiteRule): Boolean {
        if (!rule.enabled) return false
        val h = host
        val d = rule.domain
        if (h == d) return true
        return rule.subdomains && h.endsWith(".$d")
    }

    /**
     * Splits what was typed or pasted into separate entries: commas, semicolons, spaces and new lines all separate.
     * ("youtube.com, instagram.com facebook.com" -> three entries.)
     */
    fun splitInput(raw: String): List<String> =
        raw.split(Regex("[,;\\s]+")).map { it.trim() }.filter { it.isNotEmpty() }

    /** Result of an add / edit. */
    enum class Result { OK, ALREADY_THERE, INVALID, LOCKED, FULL }
}

/** Everything saved for website blocking. */
data class WebsiteState(
    /** Apps whose "Website blocking" switch is on. */
    val enabledApps: Set<String> = emptySet(),
    val rules: Map<String, List<WebsiteRule>> = emptyMap(),
) {
    fun isOn(pkg: String) = pkg in enabledApps
    fun rulesFor(pkg: String): List<WebsiteRule> = rules[pkg].orEmpty()

    /** Apps that currently block at least one site. */
    fun activeOwners(): List<String> =
        enabledApps.filter { owner -> rulesFor(owner).any { it.enabled } }

    val hasActiveRules: Boolean get() = activeOwners().isNotEmpty()

    fun isRuleActive(pkg: String, domain: String): Boolean =
        isOn(pkg) && rulesFor(pkg).any { it.enabled && it.domain == domain }

    /** The app and rule that cover [host], looking only at [owners] (all active apps by default). */
    fun firstMatch(host: String, owners: Collection<String> = activeOwners()): Pair<String, WebsiteRule>? {
        for (owner in owners) {
            if (!isOn(owner)) continue
            val rule = rulesFor(owner).firstOrNull { WebsiteRules.matches(host, it) }
            if (rule != null) return owner to rule
        }
        return null
    }
}

/** Apps that get a "Website blocking" option, with the sites to suggest when it is first switched on. */
object WebsiteCatalog {
    /**
     * Owner key of the person's own list of websites that belong to no app ("Blocked websites"). It is stored like an
     * app's list (same rules, same switches) and is enforced in the browsers during every focus session.
     */
    const val GENERAL = "*"

    private val defaults: Map<String, List<String>> = mapOf(
        "com.google.android.youtube" to listOf("youtube.com", "youtu.be"),
        "com.instagram.android" to listOf("instagram.com"),
        "com.facebook.katana" to listOf("facebook.com", "fb.com"),
        "com.zhiliaoapp.musically" to listOf("tiktok.com"),
        "com.ss.android.ugc.trill" to listOf("tiktok.com"),
        "com.snapchat.android" to listOf("snapchat.com"),
        "com.twitter.android" to listOf("x.com", "twitter.com"),
        "com.reddit.frontpage" to listOf("reddit.com"),
        "com.netflix.mediaclient" to listOf("netflix.com"),
        "com.pinterest" to listOf("pinterest.com"),
        "tv.twitch.android.app" to listOf("twitch.tv"),
        "com.discord" to listOf("discord.com", "discord.gg"),
        "org.telegram.messenger" to listOf("telegram.org", "t.me"),
        "com.whatsapp" to listOf("whatsapp.com"),
        "com.amazon.avod.thirdpartyclient" to listOf("primevideo.com"),
    )

    fun supports(pkg: String) = pkg in defaults
    fun suggested(pkg: String): List<String> = defaults[pkg].orEmpty()
}

/** Browsers whose address bar LockDistra reads, and the view ids that hold it. */
object WebsiteBrowsers {

    private const val CHROMIUM_ID = "url_bar"

    /** package -> view id names (without the "<package>:id/" prefix) of the address bar. */
    private val urlBarIds: Map<String, List<String>> = mapOf(
        "com.android.chrome" to listOf(CHROMIUM_ID),
        "com.chrome.beta" to listOf(CHROMIUM_ID),
        "com.chrome.dev" to listOf(CHROMIUM_ID),
        "com.chrome.canary" to listOf(CHROMIUM_ID),
        "org.chromium.chrome" to listOf(CHROMIUM_ID),
        "com.brave.browser" to listOf(CHROMIUM_ID),
        "com.microsoft.emmx" to listOf(CHROMIUM_ID),
        "com.vivaldi.browser" to listOf(CHROMIUM_ID),
        "com.opera.browser" to listOf("url_field", CHROMIUM_ID),
        "org.mozilla.firefox" to listOf("mozac_browser_toolbar_url_view"),
        "org.mozilla.firefox_beta" to listOf("mozac_browser_toolbar_url_view"),
        "org.mozilla.fenix" to listOf("mozac_browser_toolbar_url_view"),
        "com.sec.android.app.sbrowser" to listOf("location_bar_edit_text"),
        "com.duckduckgo.mobile.android" to listOf("omnibarTextInput"),
    )

    val supportedNames = "Chrome, Edge, Brave, Firefox, Samsung Internet, Opera, Vivaldi and DuckDuckGo"

    fun isSupported(pkg: String) = pkg in urlBarIds

    /** Fully qualified resource ids to look up, most likely first. */
    fun urlBarIds(pkg: String): List<String> =
        urlBarIds[pkg].orEmpty().map { "$pkg:id/$it" }
}

/** When a site rule actually blocks, and who may change rules while a session runs. */
object WebsitePolicy {

    /**
     * A site is closed while its app is blocked by a running session, or once the app's daily
     * limit is used up, unless extra time (trusted phone / emergency) is running for that app.
     */
    fun shouldEnforce(sessionBlocks: Boolean, limitBlocks: Boolean, extraTime: Boolean): Boolean =
        (sessionBlocks || limitBlocks) && !extraTime

    /** Adding a site or switching blocking ON tightens things. */
    fun canTighten(s: FocusState) = ContentPolicy.canSetFeature(s, false, true)

    /** Deleting, editing, switching a site OFF or turning off subdomains loosens things. */
    fun canLoosen(s: FocusState) = ContentPolicy.canSetFeature(s, true, false)
}

/**
 * The add / edit / remove / switch rules for a [WebsiteState], as pure functions. [WebsiteStore] (the
 * global rules) and the Focus Profiles (their own rules) both use them, so a site is checked, limited and
 * seeded the same way in both. Who is allowed to change what ([WebsitePolicy]) is decided by the caller and
 * passed in as [canTighten] / [canLoosen]; a profile that is not running passes true.
 */
object WebsiteEdits {

    class Change(val state: WebsiteState, val result: WebsiteRules.Result)

    /** The new state, [s] itself when nothing has to change, or null when the change is not allowed. */
    fun setAppEnabled(s: WebsiteState, pkg: String, on: Boolean, canTighten: Boolean, canLoosen: Boolean): WebsiteState? {
        if (s.isOn(pkg) == on) return s
        if (!(if (on) canTighten else canLoosen)) return null
        val apps = if (on) s.enabledApps + pkg else s.enabledApps - pkg
        val rules = LinkedHashMap(s.rules)
        if (on && s.rulesFor(pkg).isEmpty()) {
            val seeded = WebsiteCatalog.suggested(pkg).map { WebsiteRule(it) }
            if (seeded.isNotEmpty()) rules[pkg] = seeded
        }
        return WebsiteState(apps, rules)
    }

    fun addSite(s: WebsiteState, pkg: String, raw: String, subdomains: Boolean, canTighten: Boolean): Change {
        val domain = WebsiteRules.fromTyped(raw) ?: return Change(s, WebsiteRules.Result.INVALID)
        if (!canTighten) return Change(s, WebsiteRules.Result.LOCKED)
        val list = s.rulesFor(pkg)
        if (list.any { it.domain == domain }) return Change(s, WebsiteRules.Result.ALREADY_THERE)
        if (list.size >= WebsiteRules.MAX_PER_APP) return Change(s, WebsiteRules.Result.FULL)
        val rules = LinkedHashMap(s.rules)
        rules[pkg] = list + WebsiteRule(domain, enabled = true, subdomains = subdomains)
        // The standalone list has no master switch: it is on as soon as it holds a site (each site has its own switch).
        val apps = if (pkg == WebsiteCatalog.GENERAL) s.enabledApps + pkg else s.enabledApps
        return Change(WebsiteState(apps, rules), WebsiteRules.Result.OK)
    }

    /** Outcome of adding several sites at once; the lists hold the entries as they were typed. */
    class Bulk(
        val state: WebsiteState,
        val added: List<String>,
        val duplicates: List<String>,
        val invalid: List<String>,
        val full: List<String>,
        val locked: Boolean,
    ) {
        val allDone: Boolean get() = duplicates.isEmpty() && invalid.isEmpty() && full.isEmpty() && !locked
    }

    /** Adds every entry of [raw] (see [WebsiteRules.splitInput]); one bad entry never stops the others. */
    fun addSites(s: WebsiteState, pkg: String, raw: String, subdomains: Boolean, canTighten: Boolean): Bulk {
        var cur = s
        val added = ArrayList<String>(); val dup = ArrayList<String>()
        val bad = ArrayList<String>(); val full = ArrayList<String>()
        var locked = false
        for (token in WebsiteRules.splitInput(raw)) {
            val change = addSite(cur, pkg, token, subdomains, canTighten)
            when (change.result) {
                WebsiteRules.Result.OK -> { cur = change.state; added += token }
                WebsiteRules.Result.ALREADY_THERE -> dup += token
                WebsiteRules.Result.INVALID -> bad += token
                WebsiteRules.Result.FULL -> full += token
                WebsiteRules.Result.LOCKED -> locked = true
            }
        }
        if (added.isEmpty() && dup.isEmpty() && bad.isEmpty() && full.isEmpty() && !locked) bad += raw.trim()
        return Bulk(cur, added, dup, bad, full, locked)
    }

    fun editSite(s: WebsiteState, pkg: String, oldDomain: String, raw: String, subdomains: Boolean, canLoosen: Boolean): Change {
        val domain = WebsiteRules.fromTyped(raw) ?: return Change(s, WebsiteRules.Result.INVALID)
        val list = s.rulesFor(pkg)
        val index = list.indexOfFirst { it.domain == oldDomain }
        if (index < 0) return Change(s, WebsiteRules.Result.INVALID)
        if (!canLoosen) return Change(s, WebsiteRules.Result.LOCKED)
        if (domain != oldDomain && list.any { it.domain == domain }) return Change(s, WebsiteRules.Result.ALREADY_THERE)
        val rules = LinkedHashMap(s.rules)
        rules[pkg] = list.toMutableList().also { it[index] = it[index].copy(domain = domain, subdomains = subdomains) }
        return Change(WebsiteState(s.enabledApps, rules), WebsiteRules.Result.OK)
    }

    fun removeSite(s: WebsiteState, pkg: String, domain: String, canLoosen: Boolean): WebsiteState? {
        if (!canLoosen) return null
        val rules = LinkedHashMap(s.rules)
        rules[pkg] = s.rulesFor(pkg).filterNot { it.domain == domain }
        return WebsiteState(s.enabledApps, rules)
    }

    /** Null when the site is unknown or the change is not allowed. */
    fun setSiteEnabled(s: WebsiteState, pkg: String, domain: String, on: Boolean, canTighten: Boolean, canLoosen: Boolean): WebsiteState? {
        val list = s.rulesFor(pkg)
        val index = list.indexOfFirst { it.domain == domain }
        if (index < 0) return null
        if (list[index].enabled == on) return s
        if (!(if (on) canTighten else canLoosen)) return null
        val rules = LinkedHashMap(s.rules)
        rules[pkg] = list.toMutableList().also { it[index] = it[index].copy(enabled = on) }
        return WebsiteState(s.enabledApps, rules)
    }
}
