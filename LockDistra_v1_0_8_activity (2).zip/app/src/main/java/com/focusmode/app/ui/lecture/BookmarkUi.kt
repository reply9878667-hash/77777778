package com.focusmode.app.ui.lecture

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.Bookmark
import com.focusmode.app.data.BookmarkRules
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.theme.FocusTheme

/**
 * The strip at the very bottom of the player screen: "Add bookmark" (pauses the video at this second and opens a small form at
 * the bottom, not a full screen) and "Bookmarks" (the saved spots of this video; tap one to jump there).
 *
 * [onCapture] pauses the video and gives back the second it stopped at (-1 when the time could not be read).
 * [onSave] is told the second and the text; [onSeek] jumps the video; [onResume] plays again after the form is closed.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarkBar(
    bookmarks: List<Bookmark>,
    syncNote: String,
    onCapture: ((Int) -> Unit) -> Unit,
    onSave: (Int, String) -> Unit,
    onDelete: (Long) -> Unit,
    onSeek: (Int) -> Unit,
    onResume: () -> Unit,
) {
    val c = FocusTheme.colors
    var addAt by remember { mutableStateOf<Int?>(null) }
    var showList by remember { mutableStateOf(false) }

    Row(
        Modifier.fillMaxWidth().background(c.card).padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PrimaryButton("Add bookmark", { onCapture { sec -> if (sec >= 0) addAt = sec } }, Modifier.weight(1f), icon = Icons.Filled.BookmarkAdd)
        OutlinedButton(onClick = { showList = true }, modifier = Modifier.weight(1f).height(48.dp)) {
            Icon(Icons.Filled.Bookmarks, contentDescription = null, tint = c.accent)
            Spacer(Modifier.width(8.dp))
            Text("Bookmarks (${bookmarks.size})", color = c.text, maxLines = 1)
        }
    }

    val at = addAt
    if (at != null) {
        var text by remember(at) { mutableStateOf("") }
        val focus = remember { FocusRequester() }
        val close = { addAt = null; onResume() }
        LaunchedEffect(at) { runCatching { focus.requestFocus() } }
        ModalBottomSheet(
            onDismissRequest = close,
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = c.background,
            contentColor = c.text,
        ) {
            Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding().imePadding()) {
                Text("Bookmark at ${BookmarkRules.time(at)}", style = MaterialTheme.typography.titleMedium, color = c.text)
                Text("Video is paused here.", style = MaterialTheme.typography.bodySmall, color = c.muted)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(BookmarkRules.MAX_TITLE) },
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    placeholder = { Text("Topic, heading or important point") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { onSave(at, text); close() }),
                )
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = close, modifier = Modifier.weight(1f).height(48.dp)) { Text("Cancel", color = c.text) }
                    PrimaryButton("Save", { onSave(at, text); close() }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }

    if (showList) {
        ModalBottomSheet(
            onDismissRequest = { showList = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false),
            containerColor = c.background,
            contentColor = c.text,
        ) {
            Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding()) {
                Text("Bookmarks", style = MaterialTheme.typography.titleMedium, color = c.text)
                if (syncNote.isNotEmpty()) Text(syncNote, style = MaterialTheme.typography.bodySmall, color = c.muted)
                Spacer(Modifier.height(8.dp))
                if (bookmarks.isEmpty()) {
                    Text("Nothing saved for this video yet. Tap \"Add bookmark\" at an important moment.", style = MaterialTheme.typography.bodyMedium, color = c.muted)
                    Spacer(Modifier.height(20.dp))
                } else {
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(bookmarks, key = { it.id }) { b ->
                            Row(
                                Modifier.fillMaxWidth().clickable { showList = false; onSeek(b.seconds) }.padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(
                                    BookmarkRules.time(b.seconds), color = c.accent, style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.background(c.cardHigh, RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
                                )
                                Spacer(Modifier.width(12.dp))
                                Text(b.title, color = c.text, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                IconButton(onClick = { onDelete(b.id) }) { Icon(Icons.Filled.Delete, contentDescription = "Delete bookmark", tint = c.muted) }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}
