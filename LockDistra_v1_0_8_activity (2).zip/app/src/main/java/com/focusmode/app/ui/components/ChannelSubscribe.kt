package com.focusmode.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.ChannelAlerts
import com.focusmode.app.data.StudyStore
import com.focusmode.app.ui.theme.FocusTheme

/**
 * The channel's Subscribe control, like YouTube's. Not subscribed: "Subscribe" (it subscribes, then asks what to be
 * notified about). Subscribed: "Subscribed" (asks "Unsubscribe?" first, so a stray tap never unsubscribes) and a bell
 * that opens the notification choice (All / Personalized / None) of this channel only.
 * Same store calls as before ([StudyStore.follow] / [StudyStore.unfollow]); nothing else changes.
 */
@Composable
fun ChannelSubscribeControl(
    store: StudyStore,
    channelId: String,
    channelName: String,
    modifier: Modifier = Modifier,
    /** True on the channel page: the button stretches across the row. */
    wide: Boolean = false,
    /** True under a playing video: a small white pill (not the big purple button), so it never looks like "Start Focus Mode". */
    compact: Boolean = false,
    onChanged: (subscribed: Boolean) -> Unit = {},
) {
    val c = FocusTheme.colors
    var subscribed by remember(channelId) { mutableStateOf(store.isFollowing(channelId)) }
    var mode by remember(channelId) { mutableStateOf(store.alertMode(channelId)) }
    var confirmUnsubscribe by remember(channelId) { mutableStateOf(false) }
    var pickAlerts by remember(channelId) { mutableStateOf(false) }

    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        val buttonModifier = if (wide) Modifier.weight(1f) else Modifier
        if (subscribed) {
            OutlinedButton(onClick = { confirmUnsubscribe = true }, modifier = buttonModifier) {
                Text("Subscribed", color = c.accent)
            }
            IconButton(onClick = { pickAlerts = true }) {
                Icon(
                    when (mode) {
                        ChannelAlerts.ALL -> Icons.Rounded.NotificationsActive
                        ChannelAlerts.PERSONALIZED -> Icons.Rounded.Notifications
                        ChannelAlerts.NONE -> Icons.Rounded.NotificationsOff
                    },
                    "Notifications: ${label(mode)}", tint = c.accent
                )
            }
        } else if (compact) {
            Button(
                onClick = {
                    store.follow(channelId, channelName)
                    subscribed = true
                    mode = store.alertMode(channelId)
                    onChanged(true)
                    pickAlerts = true
                },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF14102B)),
            ) { Text("Subscribe", style = MaterialTheme.typography.labelLarge) }
        } else {
            PrimaryButton("Subscribe", {
                store.follow(channelId, channelName)
                subscribed = true
                mode = store.alertMode(channelId)
                onChanged(true)
                pickAlerts = true
            }, buttonModifier)
        }
    }

    if (confirmUnsubscribe) {
        AlertDialog(
            onDismissRequest = { confirmUnsubscribe = false },
            containerColor = c.card, titleContentColor = c.text, textContentColor = c.muted,
            title = { Text("Unsubscribe from ${channelName.ifEmpty { "this channel" }}?", style = MaterialTheme.typography.titleLarge) },
            text = { Text("You will stop getting its new-video notifications and it will leave your trusted channels.") },
            confirmButton = {
                TextButton(onClick = {
                    store.unfollow(channelId)
                    subscribed = false
                    confirmUnsubscribe = false
                    pickAlerts = false
                    onChanged(false)
                }) { Text("Unsubscribe", color = c.warning) }
            },
            dismissButton = { TextButton(onClick = { confirmUnsubscribe = false }) { Text("Cancel", color = c.accent) } }
        )
    }

    if (pickAlerts && subscribed) {
        AlertDialog(
            onDismissRequest = { pickAlerts = false },
            containerColor = c.card, titleContentColor = c.text, textContentColor = c.muted,
            title = { Text("Notifications", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column {
                    Text(channelName, style = MaterialTheme.typography.bodySmall, color = c.muted)
                    Spacer(Modifier.height(8.dp))
                    ChannelAlerts.values().forEach { m ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                store.setAlertMode(channelId, m)
                                mode = m
                            }.padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = mode == m,
                                onClick = { store.setAlertMode(channelId, m); mode = m },
                                colors = RadioButtonDefaults.colors(selectedColor = c.accent, unselectedColor = c.muted)
                            )
                            Column(Modifier.padding(start = 4.dp)) {
                                Text(label(m), style = MaterialTheme.typography.bodyLarge, color = c.text)
                                Text(hint(m), style = MaterialTheme.typography.bodySmall, color = c.muted)
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { pickAlerts = false }) { Text("Done", color = c.accent) } }
        )
    }
}

private fun label(m: ChannelAlerts) = when (m) {
    ChannelAlerts.ALL -> "All"
    ChannelAlerts.PERSONALIZED -> "Personalized"
    ChannelAlerts.NONE -> "None"
}

private fun hint(m: ChannelAlerts) = when (m) {
    ChannelAlerts.ALL -> "Every new video from this channel"
    ChannelAlerts.PERSONALIZED -> "Only new videos that match your subjects"
    ChannelAlerts.NONE -> "No notifications from this channel"
}
