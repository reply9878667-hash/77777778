package com.focusmode.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Eco
import androidx.compose.material.icons.outlined.School
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.focusmode.app.R
import com.focusmode.app.ui.components.BrandMark
import com.focusmode.app.data.PomodoroPhase
import com.focusmode.app.data.PomodoroState
import com.focusmode.app.ui.components.FocusTimerCard
import com.focusmode.app.ui.components.NightScenery
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.remember
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.EmergencyState
import com.focusmode.app.data.FocusControl
import com.focusmode.app.data.ContentState
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.PLANT_MAX_GROWTH
import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.HomeShimmer
import com.focusmode.app.ui.components.shimmerReveal
import com.focusmode.app.ui.components.staggeredEntrance
import com.focusmode.app.ui.formatClock
import com.focusmode.app.ui.formatMinutes
import com.focusmode.app.ui.plantStage
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay
import java.util.Calendar


@Composable
fun DashboardScreen(
    state: FocusState,
    permissions: PermissionStatus,
    blockedCount: Int,
    onRingClick: () -> Unit,
    onEndEmergency: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenProfile: () -> Unit,
    onFinishSetup: () -> Unit,
    /** Name of the Focus Profile in use, or null when none is saved. */
    focusProfileName: String?,
    onOpenFocusProfile: () -> Unit,
    /** Name of the app the running emergency window opened (empty if none). */
    emergencyLabel: String,
    onControlChange: (FocusControl, Boolean) -> Unit,
    pomodoro: PomodoroState,
    exactAlarmsMissing: Boolean,
    onPomodoroStart: () -> Unit,
    onPomodoroPause: () -> Unit,
    onPomodoroResume: () -> Unit,
    onPomodoroStop: () -> Unit,
    onPomodoroDurations: (focusMin: Int, breakMin: Int) -> Unit,
    onGrantExactAlarms: () -> Unit,
) {
    val c = FocusTheme.colors

    // The first-open shimmer counts as played once it has run (or Home was left); it never repeats on tab switches.
    val shimmerArmed = HomeShimmer.armed
    LaunchedEffect(shimmerArmed) {
        if (shimmerArmed) {
            try {
                delay(HomeShimmer.SWEEP_MS.toLong() * HomeShimmer.SWEEPS + 400L)
            } finally {
                HomeShimmer.done = true
            }
        }
    }

    // Live clock, only ticking while a session is running.
    val now by produceState(System.currentTimeMillis(), state.focusActive) {
        value = System.currentTimeMillis()
        while (state.focusActive) {
            delay(250)
            value = System.currentTimeMillis()
        }
    }

    val paused = state.emergencyActive(now)
    val limited = state.sessionEnd > 0L
    val remaining = (state.sessionEnd - now).coerceAtLeast(0L)
    val total = (state.sessionEnd - state.sessionStart).coerceAtLeast(1L)
    val progress = if (limited) remaining.toFloat() / total else 1f

    val timeText = if (limited) formatClock(remaining) else formatClock(now - state.sessionStart)
    val caption = when {
        paused -> "Emergency access"
        limited -> "of ${formatMinutes(state.sessionMinutes)} left"
        else -> "no time limit"
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
    ) {
        Box(Modifier.shimmerReveal(16.dp)) {
            Header(name = state.userName, onProfile = onOpenProfile, onSettings = onOpenSettings)
        }

        Spacer(Modifier.height(12.dp))

        AnimatedVisibility(
            visible = !permissions.accessibility,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column {
                FocusCard(
                    onClick = onFinishSetup,
                    padding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.WarningAmber, null, tint = c.warning, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Finish setup", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Blocking needs the accessibility permission.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted
                            )
                        }
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.muted)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        val idleText = if (state.lastDurationMin > 0) formatClock(state.lastDurationMin * 60_000L) else "No limit"
        Box(Modifier.fillMaxWidth().shimmerReveal(30.dp)) {
            HeroCard(
                greeting = greeting(),
                active = state.focusActive,
                paused = paused,
                progress = progress,
                timeText = timeText,
                caption = caption,
                idleText = idleText,
                onClick = onRingClick,
            )
        }

        Spacer(Modifier.height(10.dp))
        Text(
            text = when {
                pomodoro.phase == PomodoroPhase.BREAK -> "Break time. Your focus restrictions are paused for now."
                !state.focusActive -> "Pick a duration and the apps you blocked go quiet."
                paused -> "Blocking is paused for a moment."
                else -> "$blockedCount app${if (blockedCount == 1) "" else "s"} blocked. You've got this."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = c.muted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        // Daily Task Planner: self-contained (own store), no Focus / blocking / Pomodoro state involved.
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().shimmerReveal(24.dp)) { DailyTaskPlanner() }

        // Day Coach: tomorrow's plan in blocks; coaches the day with messages and Focus Mode. Own store, nothing at night is blocked.
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().shimmerReveal(24.dp)) { DayCoachCard() }

        Spacer(Modifier.height(12.dp))
        FocusCard(
            modifier = Modifier.shimmerReveal(24.dp),
            onClick = onOpenFocusProfile,
            padding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Shield, null, tint = c.accent, modifier = Modifier.size(22.dp))
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Focus Profile", style = MaterialTheme.typography.titleMedium)
                    Text(
                        focusProfileName ?: "Not set up yet",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        maxLines = 1
                    )
                }
                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.muted)
            }
        }

        // Pomodoro: hidden during a plain focus session, shown while idle or while its own cycle runs.
        AnimatedVisibility(
            visible = !state.focusActive || pomodoro.active,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column {
                Spacer(Modifier.height(14.dp))
                PomodoroCard(
                    pomodoro = pomodoro,
                    focus = state,
                    nothingBlocked = blockedCount == 0 && !state.blockShorts,
                    exactAlarmsMissing = exactAlarmsMissing,
                    onStart = onPomodoroStart,
                    onPause = onPomodoroPause,
                    onResume = onPomodoroResume,
                    onStop = onPomodoroStop,
                    onDurations = onPomodoroDurations,
                    onGrantExactAlarms = onGrantExactAlarms,
                )
            }
        }

        // Advanced controls sit directly under the LockDistra ring while a session is running.
        AnimatedVisibility(
            visible = state.focusActive,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column {
                Spacer(Modifier.height(20.dp))
                FocusControlsCard(state = state, onChange = onControlChange)
            }
        }

        // Only while an emergency window is actually open: a small status strip with "Close now".
        // (Emergency is configured per app, in Apps; there is no Emergency section on Home.)
        AnimatedVisibility(
            visible = state.focusActive && paused,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column {
                Spacer(Modifier.height(12.dp))
                FocusCard(padding = PaddingValues(horizontal = 20.dp, vertical = 14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (emergencyLabel.isBlank()) "Emergency access" else "Emergency: $emergencyLabel",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "${formatClock(state.emergencyUntil - now)} left, then it is blocked again",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.warning
                            )
                        }
                        TextButton(onClick = onEndEmergency) {
                            Text("Close now", color = c.accent)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { BrandMark(centered = true) }
        Spacer(Modifier.height(if (state.focusActive) 96.dp else 24.dp))
    }
}

/** Night-scene card with the greeting and the glass timer card. */
@Composable
private fun HeroCard(
    greeting: String,
    active: Boolean,
    paused: Boolean,
    progress: Float,
    timeText: String,
    caption: String,
    idleText: String,
    onClick: () -> Unit,
) {
    val c = FocusTheme.colors
    val shape = RoundedCornerShape(30.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, c.stroke, shape)
    ) {
        NightScenery(Modifier.matchParentSize())
        Column(Modifier.padding(horizontal = 16.dp, vertical = 18.dp)) {
            Text(
                greeting,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 24.sp),
                color = Color.White,
                modifier = Modifier.padding(start = 4.dp)
            )
            Text(
                "Stay Focused!",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFC9C2E6),
                modifier = Modifier.padding(start = 4.dp)
            )
            Spacer(Modifier.height(78.dp))
            FocusTimerCard(
                active = active,
                paused = paused,
                progress = progress,
                timeText = timeText,
                caption = caption,
                idleText = idleText,
                onClick = onClick,
            )
        }
    }
}

@Composable
private fun Header(name: String, onProfile: () -> Unit, onSettings: () -> Unit) {
    val c = FocusTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable(onClick = onProfile)
                .padding(end = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row {
                    Text("Lock", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = c.text)
                    Text("Distra", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = c.accent)
                }
                Text(
                    if (name.isBlank()) "Focus \u2022 Plan \u2022 Achieve" else "Hi, $name",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    maxLines = 1
                )
            }
        }
        Spacer(Modifier.weight(1f))
        CircleIconButton(Icons.Outlined.Settings, "Settings", onSettings)
    }
}

private fun greeting(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 5..11 -> "Good Morning!"
        in 12..16 -> "Good Afternoon!"
        in 17..21 -> "Good Evening!"
        else -> "Late Night Focus"
    }
}
