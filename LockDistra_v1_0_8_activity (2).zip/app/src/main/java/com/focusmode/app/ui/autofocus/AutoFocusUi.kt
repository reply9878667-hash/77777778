package com.focusmode.app.ui.autofocus

import android.app.TimePickerDialog
import android.text.format.DateFormat
import com.focusmode.app.service.AutoFocusEngine
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.AutoFocusFormat
import com.focusmode.app.data.AutoFocusNotifier
import com.focusmode.app.data.AutoFocusSchedule
import com.focusmode.app.data.AutoFocusStore
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

/**
 * The editor for Auto Focus: on/off switch, start time, end time and days. Used inside the Settings card and inside the
 * dialog that the "Auto" button on Home opens, so both always look and behave the same.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AutoFocusEditor(
    schedule: AutoFocusSchedule,
    onChange: (AutoFocusSchedule) -> Unit,
    editable: Boolean,
    accessibilityOn: Boolean,
    onGrantAccessibility: () -> Unit,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val is24 = remember { DateFormat.is24HourFormat(context) }
    var note by remember { mutableStateOf<String?>(null) }

    fun commit(next: AutoFocusSchedule) {
        if (!editable) return
        note = null
        onChange(next)
        if (next.enabled && next.currentWindow(System.currentTimeMillis()) != null) {
            note = "This time is running right now, so Auto Focus starts from the next one. " +
                "Start Focus Mode by hand if you want it now."
        }
    }

    fun pickTime(initial: Int, onPicked: (Int) -> Unit) {
        if (!editable) return
        TimePickerDialog(context, { _, h, m -> onPicked(h * 60 + m) }, initial / 60, initial % 60, is24).show()
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Auto Focus", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (schedule.enabled && schedule.isValid)
                        "On at ${AutoFocusFormat.time(schedule.startMin, is24)}, off at ${AutoFocusFormat.time(schedule.endMin, is24)}" +
                            if (schedule.endsNextDay) " (next day)" else ""
                    else "Off",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (schedule.enabled) c.accent else c.muted
                )
            }
            FocusSwitch(
                checked = schedule.enabled,
                enabled = editable,
                onCheckedChange = { on -> commit(schedule.copy(enabled = on)) }
            )
        }

        Text(
            "Focus Mode turns on by itself at the start time and turns off at the end time, on the days you choose.",
            style = MaterialTheme.typography.bodySmall,
            color = c.muted
        )

        Text("Time", style = MaterialTheme.typography.labelMedium, color = c.text)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            SoftChip("Starts ${AutoFocusFormat.time(schedule.startMin, is24)}", false, {
                pickTime(schedule.startMin) { picked ->
                    if (picked == schedule.endMin) note = "Start and end time can't be the same."
                    else commit(schedule.copy(startMin = picked))
                }
            })
            SoftChip("Ends ${AutoFocusFormat.time(schedule.endMin, is24)}", false, {
                pickTime(schedule.endMin) { picked ->
                    if (picked == schedule.startMin) note = "Start and end time can't be the same."
                    else commit(schedule.copy(endMin = picked))
                }
            })
        }

        Text("Days", style = MaterialTheme.typography.labelMedium, color = c.text)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AutoFocusSchedule.DAY_NAMES.forEachIndexed { i, name ->
                SoftChip(name, schedule.hasDay(i), {
                    val next = schedule.toggleDay(i)
                    if (next.days == 0) note = "Choose at least one day." else commit(next)
                })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SoftChip("Every day", schedule.days == AutoFocusSchedule.EVERY_DAY, { commit(schedule.copy(days = AutoFocusSchedule.EVERY_DAY)) })
            SoftChip("Mon–Fri", schedule.days == AutoFocusSchedule.WEEKDAYS, { commit(schedule.copy(days = AutoFocusSchedule.WEEKDAYS)) })
            SoftChip("Sat–Sun", schedule.days == AutoFocusSchedule.WEEKEND, { commit(schedule.copy(days = AutoFocusSchedule.WEEKEND)) })
        }

        if (schedule.enabled && schedule.isValid) {
            val now = System.currentTimeMillis()
            val next = schedule.nextWindow(now)
            val running = schedule.currentWindow(now)
            Text(
                when {
                    running != null -> "Current window ends at ${AutoFocusFormat.timeOf(running.endMs, is24)}."
                    next != null -> "Next: ${AutoFocusFormat.dayLabel(next.startMs, now)}, ${AutoFocusFormat.timeOf(next.startMs, is24)}."
                    else -> ""
                },
                style = MaterialTheme.typography.bodySmall,
                color = c.text
            )
        }

        if (schedule.enabled && !accessibilityOn) {
            Text(
                "Auto Focus needs LockDistra's Accessibility access, otherwise it can't block anything.",
                style = MaterialTheme.typography.bodySmall,
                color = c.warning
            )
            SoftChip("Allow accessibility", true, onGrantAccessibility)
        }

        if (!editable) {
            Text("Settings are locked right now, so Auto Focus can't be changed.", style = MaterialTheme.typography.bodySmall, color = c.warning)
        }
        note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
    }
}

/** Settings > Focus > Auto Focus. */
@Composable
fun AutoFocusCard(
    schedule: AutoFocusSchedule,
    onChange: (AutoFocusSchedule) -> Unit,
    editable: Boolean,
    accessibilityOn: Boolean,
    onGrantAccessibility: () -> Unit,
) {
    FocusCard {
        AutoFocusEditor(schedule, onChange, editable, accessibilityOn, onGrantAccessibility)
    }
}

/** Opened by the "Auto" button on Home. */
@Composable
fun AutoFocusDialog(
    schedule: AutoFocusSchedule,
    onChange: (AutoFocusSchedule) -> Unit,
    editable: Boolean,
    accessibilityOn: Boolean,
    onGrantAccessibility: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Automatic Focus Mode", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                AutoFocusEditor(schedule, onChange, editable, accessibilityOn, onGrantAccessibility)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = c.accent) } }
    )
}

/** The small "Auto" button on Home. A dot shows that the schedule is on. */
@Composable
fun AutoFocusChip(on: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = FocusTheme.colors
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (on) c.accentSoft else c.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(Icons.Rounded.Schedule, "Auto Focus", tint = if (on) c.accent else c.muted, modifier = Modifier.size(18.dp))
        Text("Auto", style = MaterialTheme.typography.labelLarge, color = if (on) c.accent else c.text)
        if (on) Spacer(Modifier.size(7.dp).clip(CircleShape).background(c.accent))
    }
}

/**
 * Keeps the schedule going while LockDistra's screen is open: re-arms the start-time alarm whenever the schedule changes and
 * checks every 15 seconds. The real work lives in [AutoFocusEngine], which also runs with the app closed (alarm,
 * Accessibility service, restart), so Auto Focus does not depend on this screen.
 */
@Composable
fun AutoFocusHost(
    store: AutoFocusStore,
    focusActive: Boolean,
    pomodoroActive: Boolean,
    accessibilityOn: Boolean,
) {
    val schedule by store.schedule.collectAsStateWithLifecycle()
    val context = LocalContext.current
    LaunchedEffect(schedule, focusActive, pomodoroActive, accessibilityOn) {
        while (true) {
            AutoFocusEngine.process(context)
            AutoFocusEngine.schedule(context)
            delay(15_000)
        }
    }
}
