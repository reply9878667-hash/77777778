package com.focusmode.app.data

/**
 * How Focus Mode may be turned OFF by hand. Chosen in Settings > Focus, used by every "end the session" button.
 *
 *  - NORMAL   : the existing "End focus" confirmation (the default, the old behaviour).
 *  - PASSWORD : the existing App lock PIN / password must be typed.
 *  - ONLINE   : the trusted phone must approve through the existing online approval.
 *
 * A finished timer always ends the session by itself, whatever is chosen here.
 * Kept free of Android classes so the rules can be unit tested on a plain JVM (FocusOffMethodTest).
 */
enum class FocusOffMethod(val id: String, val label: String) {
    NORMAL("normal", "Normal Button"),
    PASSWORD("password", "Password"),
    ONLINE("online", "Online Approval");

    companion object {
        /** Unknown / missing value falls back to the old behaviour. */
        fun fromId(id: String?): FocusOffMethod = entries.firstOrNull { it.id == id } ?: NORMAL
    }
}

object FocusOffRules {

    /**
     * Why [method] cannot be used yet (text that tells the person what to set up), or null when it is ready.
     * Reuses what already exists: the App lock (PIN / password) and the connected trusted phone with its
     * recovery code. Nothing here sets anything up by itself.
     */
    fun setupError(
        method: FocusOffMethod,
        passwordLockSet: Boolean,
        phoneConnected: Boolean,
        hasRecoveryCode: Boolean,
        onlineConfigured: Boolean,
    ): String? = when (method) {
        FocusOffMethod.NORMAL -> null
        FocusOffMethod.PASSWORD ->
            if (!passwordLockSet) "No password is set. Turn on the App lock (PIN or password) under Security first."
            else null
        FocusOffMethod.ONLINE ->
            if (!onlineConfigured) "Online approval isn't set up in this build."
            else if (!phoneConnected) "Online approval isn't set up. Connect a trusted phone under Security > Trusted phone first."
            // The recovery code is NOT required here: the OFF dialog never asks for it (showRecovery = false), so a
            // connected trusted phone is all this method needs. Requiring it made a working setup look "not set up".
            else null
    }

    /**
     * The method that really protects the OFF button right now. When the chosen one lost its setup
     * (App lock removed, phone disconnected) the plain button is the only thing that can still work,
     * so nobody is ever locked into a session they cannot end. Both removals already ask for the PIN
     * or the recovery code, and the start popup refuses to start with a method that is not ready.
     */
    fun effective(chosen: FocusOffMethod, error: String?): FocusOffMethod =
        if (error == null) chosen else FocusOffMethod.NORMAL

    /** The method may only be changed between sessions, and only when LockDistra settings are unlocked. */
    fun canChange(focusActive: Boolean, canChangeSettings: Boolean): Boolean = !focusActive && canChangeSettings

    /**
     * Disconnecting the trusted phone while a session runs with Online Approval chosen would remove the
     * only way to end it (and the check above would then fall back to the plain button). Refused.
     */
    fun unlinkBlockedReason(focusActive: Boolean, chosen: FocusOffMethod): String? =
        if (focusActive && chosen == FocusOffMethod.ONLINE)
            "Focus Mode is ON and uses Online Approval to turn OFF. Disconnect the trusted phone after the session ends."
        else null

    /** Whether a Pomodoro action that lifts the restrictions needs the OFF method. Only a running Focus round does. */
    fun gatesPomodoroAction(focusActive: Boolean, pomodoroActive: Boolean): Boolean = focusActive && pomodoroActive
}

/** One row of the "what will be blocked" preview. */
data class PreviewApp(val pkg: String, val label: String)

/** What the "Ready to Start Focus Mode?" popup shows. Built from the profile that will really be used. */
data class StartPreview(
    val apps: List<PreviewApp>,
    val appTotal: Int,
    val games: List<PreviewApp>,
    val gameTotal: Int,
    val sites: List<String>,
    val siteTotal: Int,
) {
    val isEmpty: Boolean get() = appTotal == 0 && gameTotal == 0 && siteTotal == 0
}

object StartPreviewRules {
    /** Icons shown per group. The rest becomes "+ N more". */
    const val MAX_APPS = 4
    const val MAX_GAMES = 3
    const val MAX_SITES = 3

    /**
     * [blocked] is the package set the session will block: the selected Focus Profile's, or the phone-wide list when
     * no profile exists (the same choice FocusProfileRuntime makes once the session runs). [isGame] splits games
     * from apps. Packages that are not installed any more ([label] returns null) are left out. [sites] are
     * the enabled website rules.
     */
    fun build(
        blocked: Collection<String>,
        isGame: (String) -> Boolean,
        label: (String) -> String?,
        sites: List<String>,
    ): StartPreview {
        val shown = blocked.mapNotNull { pkg -> label(pkg)?.let { PreviewApp(pkg, it) } }
            .sortedBy { it.label.lowercase() }
        val (games, apps) = shown.partition { isGame(it.pkg) }
        val cleanSites = sites.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        return StartPreview(
            apps = apps.take(MAX_APPS),
            appTotal = apps.size,
            games = games.take(MAX_GAMES),
            gameTotal = games.size,
            sites = cleanSites.take(MAX_SITES),
            siteTotal = cleanSites.size,
        )
    }

    /** Enabled website rules of a website state (profile's or phone-wide), as plain domains. */
    fun siteDomains(state: WebsiteState): List<String> =
        state.enabledApps.sorted().flatMap { app -> state.rulesFor(app).filter { it.enabled }.map { it.domain } }

    /** "+ 3 more" text for a group, or null when everything is shown. */
    fun more(total: Int, shown: Int): String? = if (total > shown) "+ ${total - shown} more" else null
}
