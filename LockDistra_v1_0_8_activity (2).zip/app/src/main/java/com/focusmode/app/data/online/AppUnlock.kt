package com.focusmode.app.data.online

/**
 * "More time in one app", asked from the block screen of an app that is closed (focus block, daily
 * limit, Shorts / Reels limit). The trusted phone types how many minutes and approves; this phone
 * then lets that one app run for that long. No Android classes here, so the rules run in plain
 * JVM unit tests (see AppUnlockTest.kt).
 */
object AppUnlockRules {

    // The same numbers BlockActivity uses for its screens.
    const val REASON_APP = 0
    const val REASON_LIMIT = 3
    const val REASON_CATEGORY = 6

    /** Longest app name sent along with a request. */
    const val MAX_NAME = 40

    /** Only these block screens offer "Request to unlock". Settings, protection, in-app sections do not. */
    fun canRequest(reason: Int): Boolean =
        reason == REASON_APP || reason == REASON_LIMIT || reason == REASON_CATEGORY

    /** A short phrase for the trusted phone: why the app is closed. */
    fun reasonText(reason: Int): String = when (reason) {
        REASON_LIMIT -> "its daily limit is used up"
        REASON_CATEGORY -> "its Shorts / Reels limit is used up"
        else -> "LockDistra is blocking it"
    }

    /** What is safe to send as the app's name: no separator, no control characters, short. */
    fun cleanName(raw: String, fallback: String): String {
        val cleaned = raw.filter { it != '|' && !it.isISOControl() }.trim().take(MAX_NAME)
        return cleaned.ifBlank { fallback.take(MAX_NAME) }
    }

    /**
     * What the trusted phone typed, as minutes. Null when it is empty, not a whole number, or
     * outside [ApprovalProtocol.MIN_GRANT_MIN]..[ApprovalProtocol.MAX_GRANT_MIN].
     */
    fun parseMinutes(input: String): Int? {
        val n = input.trim().toIntOrNull() ?: return null
        return if (n in ApprovalProtocol.MIN_GRANT_MIN..ApprovalProtocol.MAX_GRANT_MIN) n else null
    }

    /** "15 min", "1 h", "1 h 30 min". */
    fun describe(minutes: Int): String {
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h == 0 -> "$m min"
            m == 0 -> "$h h"
            else -> "$h h $m min"
        }
    }
}

/** One approved extra time window for one app. */
data class AppGrant(
    val pkg: String,
    val durationMs: Long,
    /** Wall-clock end, used only when the phone restarted (the monotonic clock starts over then). */
    val untilWall: Long,
    val startElapsed: Long,
    val boot: Int,
)

object AppGrantRules {

    fun newGrant(pkg: String, minutes: Int, wallNow: Long, elapsedNow: Long, bootNow: Int): AppGrant {
        val ms = minutes.coerceIn(ApprovalProtocol.MIN_GRANT_MIN, ApprovalProtocol.MAX_GRANT_MIN) * 60_000L
        return AppGrant(pkg, ms, wallNow + ms, elapsedNow, bootNow)
    }

    /**
     * Time left. Within the same boot it follows the monotonic clock, so turning the phone's date
     * back does not stretch the window. After a restart it falls back to the wall clock, never
     * giving more than the granted length.
     */
    fun remainingMs(g: AppGrant, wallNow: Long, elapsedNow: Long, bootNow: Int): Long {
        val left = if (g.boot == bootNow && elapsedNow >= g.startElapsed) {
            g.durationMs - (elapsedNow - g.startElapsed)
        } else {
            minOf(g.untilWall - wallNow, g.durationMs)
        }
        return left.coerceIn(0L, g.durationMs)
    }

    fun isActive(g: AppGrant, wallNow: Long, elapsedNow: Long, bootNow: Int): Boolean =
        remainingMs(g, wallNow, elapsedNow, bootNow) > 0L

    fun encode(g: AppGrant): String = "${g.pkg}|${g.durationMs}|${g.untilWall}|${g.startElapsed}|${g.boot}"

    fun decode(raw: String): AppGrant? {
        val p = raw.split('|')
        if (p.size != 5 || p[0].isBlank()) return null
        return AppGrant(
            pkg = p[0],
            durationMs = p[1].toLongOrNull() ?: return null,
            untilWall = p[2].toLongOrNull() ?: return null,
            startElapsed = p[3].toLongOrNull() ?: return null,
            boot = p[4].toIntOrNull() ?: return null,
        )
    }
}
