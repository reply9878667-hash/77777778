package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Saved settings for educational Shorts (allowed channels, automatic detection) and for the
 * "Inside apps" section blocks. Lives in device-protected storage like the other stores, so it is
 * available right after a restart. Every change goes through [ContentPolicy] first, using the
 * live LockDistra state, so a running session's locks apply no matter which screen calls.
 *
 * Nothing here records what was watched: only the channel handles that were blocked, newest
 * first, capped at [ContentPolicy.MAX_RECENT], so the user can allow one with a tap later.
 */
class ContentStore private constructor(private val context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "content_filters")

    private val _state = MutableStateFlow(read())
    val state: StateFlow<ContentState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _state.value = read()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun current(): ContentState = read()

    private fun focus(): FocusState = FocusStore.get(context).current()

    private fun read() = ContentState(
        channels = ListCodec.decode(prefs.getString(K_CHANNELS, null))
            .mapNotNull { ListCodec.unpair(it) }
            .map { EduChannel(it.first, it.second) },
        autoDetect = prefs.getBoolean(K_AUTO, false),
        recentBlocked = ListCodec.decode(prefs.getString(K_RECENT, null)),
        enabledFeatures = HashSet(prefs.getStringSet(K_FEATURES, emptySet()) ?: emptySet()),
        customSections = ListCodec.decode(prefs.getString(K_CUSTOM, null))
            .mapNotNull { ListCodec.unpair(it) }
            .map { CustomSection(it.first, it.second) },
    )

    // ---- Educational channels ---------------------------------------------------------------

    enum class AddResult { ADDED, ALREADY_THERE, INVALID, LOCKED, FULL }

    @Synchronized
    fun addChannel(raw: String): AddResult {
        val channel = EducationMatcher.parseChannelInput(raw) ?: return AddResult.INVALID
        val s = read()
        if (!ContentPolicy.canAddChannel(focus())) return AddResult.LOCKED
        if (s.channels.any { it.key == channel.key }) return AddResult.ALREADY_THERE
        if (s.channels.size >= ContentPolicy.MAX_CHANNELS) return AddResult.FULL
        val updated = (s.channels + channel).sortedBy { it.display.lowercase() }
        prefs.edit().putString(K_CHANNELS, encodeChannels(updated)).apply()
        return AddResult.ADDED
    }

    @Synchronized
    fun removeChannel(key: String): Boolean {
        if (!ContentPolicy.canRemoveChannel(focus())) return false
        val s = read()
        prefs.edit().putString(K_CHANNELS, encodeChannels(s.channels.filterNot { it.key == key })).apply()
        return true
    }

    @Synchronized
    fun setAutoDetect(on: Boolean): Boolean {
        val s = read()
        if (!ContentPolicy.canSetAutoDetect(focus(), s.autoDetect, on)) return false
        prefs.edit().putBoolean(K_AUTO, on).apply()
        return true
    }

    /** Bookkeeping only (no policy check): remembers a blocked channel so it can be allowed later. */
    @Synchronized
    fun noteBlockedChannel(handle: String) {
        val h = handle.trim()
        if (h.isEmpty()) return
        val s = read()
        val list = (listOf(h) + s.recentBlocked.filterNot { it.equals(h, ignoreCase = true) })
            .take(ContentPolicy.MAX_RECENT)
        if (list != s.recentBlocked) prefs.edit().putString(K_RECENT, ListCodec.encode(list)).apply()
    }

    @Synchronized
    fun clearRecentBlocked() {
        prefs.edit().remove(K_RECENT).apply()
    }

    // ---- Section blocks ---------------------------------------------------------------------

    @Synchronized
    fun setFeature(id: String, on: Boolean): Boolean {
        if (FeatureCatalog.byId(id) == null) return false
        val s = read()
        if (!ContentPolicy.canSetFeature(focus(), id in s.enabledFeatures, on)) return false
        val set = HashSet(s.enabledFeatures)
        if (on) set.add(id) else set.remove(id)
        prefs.edit().putStringSet(K_FEATURES, set).apply()
        return true
    }

    @Synchronized
    fun addCustom(pkg: String, label: String): Boolean {
        val clean = label.trim().replace(Regex("\\s+"), " ").take(30)
        if (pkg.isBlank() || clean.length < 2) return false
        if (!ContentPolicy.canAddCustom(focus())) return false
        val s = read()
        val section = CustomSection(pkg, clean)
        if (s.customSections.any { it.id == section.id }) return true
        if (s.customSections.size >= ContentPolicy.MAX_CUSTOM) return false
        prefs.edit().putString(K_CUSTOM, encodeCustom(s.customSections + section)).apply()
        return true
    }

    @Synchronized
    fun removeCustom(id: String): Boolean {
        if (!ContentPolicy.canRemoveCustom(focus())) return false
        val s = read()
        prefs.edit().putString(K_CUSTOM, encodeCustom(s.customSections.filterNot { it.id == id })).apply()
        return true
    }

    private fun encodeChannels(list: List<EduChannel>) =
        ListCodec.encode(list.map { ListCodec.pair(it.key, it.display) })

    private fun encodeCustom(list: List<CustomSection>) =
        ListCodec.encode(list.map { ListCodec.pair(it.pkg, it.label) })

    companion object {
        private const val K_CHANNELS = "edu_channels"
        private const val K_AUTO = "edu_auto_detect"
        private const val K_RECENT = "edu_recent_blocked"
        private const val K_FEATURES = "features_on"
        private const val K_CUSTOM = "custom_sections"

        @Volatile
        private var instance: ContentStore? = null

        fun get(context: Context): ContentStore =
            instance ?: synchronized(this) {
                instance ?: ContentStore(context.applicationContext).also { instance = it }
            }
    }
}
