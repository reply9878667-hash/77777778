package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

const val EMERGENCY_DEFAULT_LIMIT = 3
const val EMERGENCY_MAX_LIMIT = 10

/** When the used-attempt counters start again from zero. */
object EmergencyReset {
    const val EVERY_SESSION = 0
    const val EVERY_DAY = 1
    const val MANUAL = 2
}

/**
 * Emergency settings for one app. [limit] is how many times Emergency access may open the app,
 * [used] how many times it already did.
 */
data class EmergencyApp(
    val pkg: String,
    val enabled: Boolean,
    val limit: Int,
    val used: Int,
) {
    val remaining: Int get() = if (enabled) (limit - used).coerceAtLeast(0) else 0
    val available: Boolean get() = enabled && remaining > 0
}

data class EmergencyState(
    val apps: Map<String, EmergencyApp> = emptyMap(),
    val resetMode: Int = EmergencyReset.EVERY_SESSION,
) {
    fun app(pkg: String): EmergencyApp? = apps[pkg]
    val enabledCount: Int get() = apps.values.count { it.enabled }
    val availableCount: Int get() = apps.values.count { it.available }
}

/**
 * Which apps Emergency access may open, and how many times each. Saved in SharedPreferences
 * (device-protected storage, like the rest) so counts survive app restarts and reboots.
 *
 * Rules that make it a safety valve instead of a bypass:
 *  - every app is OFF until the user switches it on;
 *  - each use is counted when the window opens and is never refunded;
 *  - while a session runs the lists can only be tightened (no new apps, no higher limits, no
 *    counter reset), and not at all if app changes or settings are locked.
 */
class EmergencyStore private constructor(private val context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "emergency_access")

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<EmergencyState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _state.value = readState()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun current(): EmergencyState = readState()

    // ---- Reading ----------------------------------------------------------------------------

    @Synchronized
    private fun readState(): EmergencyState {
        rollOverIfNeeded()
        return EmergencyState(readApps(), prefs.getInt(K_RESET, EmergencyReset.EVERY_SESSION))
    }

    private fun readApps(): Map<String, EmergencyApp> {
        val out = HashMap<String, EmergencyApp>()
        for (raw in prefs.getStringSet(K_APPS, emptySet()) ?: emptySet()) {
            val p = raw.split('|')
            if (p.size < 4) continue
            val limit = p[2].toIntOrNull() ?: continue
            val used = p[3].toIntOrNull() ?: 0
            out[p[0]] = EmergencyApp(p[0], p[1] == "1", limit.coerceIn(1, EMERGENCY_MAX_LIMIT), used.coerceAtLeast(0))
        }
        return out
    }

    private fun writeApps(apps: Map<String, EmergencyApp>) {
        val set = apps.values.map { "${it.pkg}|${if (it.enabled) 1 else 0}|${it.limit}|${it.used}" }.toSet()
        prefs.edit().putStringSet(K_APPS, set).apply()
    }

    // ---- Policy -----------------------------------------------------------------------------

    private fun focus(): FocusState = FocusStore.get(context).current()

    // ---- Editing ----------------------------------------------------------------------------

    /** Switches Emergency access on or off for [pkg]. Returns true if the change was applied. */
    @Synchronized
    fun setEnabled(pkg: String, enabled: Boolean): Boolean {
        val s = focus()
        val apps = readApps().toMutableMap()
        val existing = apps[pkg]
        if (existing?.enabled == enabled) return true
        if (!EmergencyPolicy.canSetEnabled(s, enabled)) return false
        apps[pkg] = (existing ?: EmergencyApp(pkg, false, EMERGENCY_DEFAULT_LIMIT, 0)).copy(enabled = enabled)
        writeApps(apps)
        return true
    }

    /** Sets how many times [pkg] may be opened. While a session runs it can only go down. */
    @Synchronized
    fun setLimit(pkg: String, limit: Int): Boolean {
        val s = focus()
        val value = limit.coerceIn(1, EMERGENCY_MAX_LIMIT)
        val apps = readApps().toMutableMap()
        val existing = apps[pkg] ?: EmergencyApp(pkg, false, EMERGENCY_DEFAULT_LIMIT, 0)
        if (existing.limit == value) return true
        if (!EmergencyPolicy.canSetLimit(s, existing.limit, value)) return false
        apps[pkg] = existing.copy(limit = value)
        writeApps(apps)
        return true
    }

    fun setResetMode(mode: Int): Boolean {
        val s = focus()
        if (s.focusActive || s.changesLocked) return false
        prefs.edit().putInt(K_RESET, mode.coerceIn(0, 2)).apply()
        return true
    }

    /** Gives every app its attempts back. Not possible while a session runs. */
    @Synchronized
    fun resetCounts(): Boolean {
        val s = focus()
        if (s.focusActive || s.changesLocked) return false
        clearUsed()
        return true
    }

    // ---- Using an attempt -------------------------------------------------------------------

    /**
     * Uses one attempt for [pkg] if it is enabled and has some left. Returns true if an attempt
     * was used. The check and the count happen together, so two quick taps cannot use one
     * attempt twice or go past the limit.
     */
    @Synchronized
    fun consume(pkg: String): Boolean {
        rollOverIfNeeded()
        val apps = readApps().toMutableMap()
        val updated = EmergencyPolicy.consume(apps[pkg]) ?: return false
        apps[pkg] = updated
        writeApps(apps)
        return true
    }

    /** Called when a new focus session starts. */
    @Synchronized
    fun onSessionStart() {
        if (prefs.getInt(K_RESET, EmergencyReset.EVERY_SESSION) == EmergencyReset.EVERY_SESSION) clearUsed()
    }

    // ---- Internals --------------------------------------------------------------------------

    private fun clearUsed() {
        writeApps(readApps().mapValues { it.value.copy(used = 0) })
    }

    @Synchronized
    private fun rollOverIfNeeded() {
        val today = LocalDate.now().toString()
        if (prefs.getString(K_DAY, null) == today) return
        prefs.edit().putString(K_DAY, today).apply()
        if (prefs.getInt(K_RESET, EmergencyReset.EVERY_SESSION) == EmergencyReset.EVERY_DAY) clearUsed()
    }

    companion object {
        private const val K_APPS = "apps"
        private const val K_RESET = "reset_mode"
        private const val K_DAY = "day"

        @Volatile
        private var instance: EmergencyStore? = null

        fun get(context: Context): EmergencyStore =
            instance ?: synchronized(this) {
                instance ?: EmergencyStore(context.applicationContext).also { instance = it }
            }
    }
}
