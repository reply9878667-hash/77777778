package com.focusmode.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Remembers app openings and which suggestions were shown, dismissed or already used. Stored on this phone only. */
class SmartSuggestStore private constructor(context: Context) {
    private val prefs = Storage.prefs(context, FILE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<SuggestState> = _state.asStateFlow()

    @Synchronized fun recordOpen() = update { it.copy(opens = it.opens + 1) }
    @Synchronized fun markShown(id: String, now: Long = System.currentTimeMillis()) = update { SmartSuggest.withShown(it, id, now) }
    @Synchronized fun dismissForever(id: String) = update { SmartSuggest.withDismissed(it, id) }
    @Synchronized fun markUsed(id: String) = update { SmartSuggest.withUsed(it, id) }
    @Synchronized fun setEnabled(on: Boolean) = update { it.copy(enabled = on) }

    private fun update(change: (SuggestState) -> SuggestState) {
        val next = change(_state.value)
        if (next == _state.value) return
        _state.value = next
        val e = prefs.edit()
            .putBoolean(K_ENABLED, next.enabled)
            .putInt(K_OPENS, next.opens)
            .putLong(K_LAST, next.lastShownAt)
        for ((id, l) in next.logs) {
            e.putString(P_LOG + id, "${l.shown},${l.lastShownOpen},${if (l.dismissed) 1 else 0},${if (l.usedEver) 1 else 0}")
        }
        e.apply()
    }

    private fun read(): SuggestState {
        val logs = HashMap<String, SuggestLog>()
        for (f in SmartSuggest.features) {
            val p = prefs.getString(P_LOG + f.id, null)?.split(',') ?: continue
            if (p.size != 4) continue
            logs[f.id] = SuggestLog(p[0].toIntOrNull() ?: 0, p[1].toIntOrNull() ?: 0, p[2] == "1", p[3] == "1")
        }
        return SuggestState(
            enabled = prefs.getBoolean(K_ENABLED, true),
            opens = prefs.getInt(K_OPENS, 0),
            lastShownAt = prefs.getLong(K_LAST, 0L),
            logs = logs,
        )
    }

    companion object {
        private const val FILE = "smart_suggest"
        private const val K_ENABLED = "enabled"
        private const val K_OPENS = "opens"
        private const val K_LAST = "last_shown"
        private const val P_LOG = "log_"

        @Volatile private var instance: SmartSuggestStore? = null

        fun get(context: Context): SmartSuggestStore =
            instance ?: synchronized(this) {
                instance ?: SmartSuggestStore(context.applicationContext).also { instance = it }
            }
    }
}
