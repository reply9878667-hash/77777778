package com.focusmode.app.service

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.PomodoroPhase
import com.focusmode.app.data.PomodoroRules
import com.focusmode.app.data.PomodoroState
import com.focusmode.app.data.PomodoroStore

/**
 * Pomodoro cycle on top of the existing Focus Mode: Focus time is an ordinary focus session
 * ([FocusController]), Break time is simply "no session", so the blocked apps, limits and website
 * rules the user saved are never edited, only switched on and off by the session starting and ending.
 *
 * Order matters in every transition: the focus session is started (or ended) first and the saved
 * phase is updated second, so a service tick in between never sees a half-finished change.
 */
object PomodoroEngine {

    enum class StartResult { OK, ALREADY_RUNNING, SESSION_RUNNING }

    @Synchronized
    fun start(context: Context): StartResult {
        val app = context.applicationContext
        val store = PomodoroStore.get(app)
        val s = store.current()
        if (s.active) return StartResult.ALREADY_RUNNING
        if (FocusStore.get(app).current().focusActive) return StartResult.SESSION_RUNNING
        FocusController.start(app, s.focusMin, fromPomodoro = true, newSession = true)
        store.update { it.copy(phase = PomodoroPhase.FOCUS, round = 1, paused = false, pausedLeftMs = 0L) }
        Notifications.refreshStatus(app)
        return StartResult.OK
    }

    /**
     * Pauses the cycle. Pausing a Focus round ends its session (restrictions off) and is refused
     * while "Allow turning LockDistra OFF" is switched off, like ending a session by hand.
     */
    @Synchronized
    fun pause(context: Context): Boolean {
        val app = context.applicationContext
        val store = PomodoroStore.get(app)
        val s = store.current()
        if (!s.running) return true
        when (s.phase) {
            PomodoroPhase.FOCUS -> {
                val fs = FocusStore.get(app).current()
                if (!fs.canTurnOff) return false
                val left = (fs.sessionEnd - System.currentTimeMillis()).coerceAtLeast(1_000L)
                store.update { it.copy(paused = true, pausedLeftMs = left) }
                FocusController.stop(app, fromPomodoro = true)
            }
            PomodoroPhase.BREAK -> {
                val left = breakLeftMs(app, s)
                store.update { it.copy(paused = true, pausedLeftMs = left) }
                FocusEngine.cancelWakeup(app)
                app.stopService(Intent(app, FocusService::class.java))
            }
            PomodoroPhase.IDLE -> Unit
        }
        return true
    }

    @Synchronized
    fun resume(context: Context) {
        val app = context.applicationContext
        val store = PomodoroStore.get(app)
        val s = store.current()
        if (!s.active || !s.paused) return
        when (s.phase) {
            PomodoroPhase.FOCUS -> {
                val total = s.focusMin * 60_000L
                val left = s.pausedLeftMs.coerceIn(1_000L, total)
                FocusController.start(
                    app, s.focusMin, durationMs = left, elapsedMs = total - left,
                    fromPomodoro = true, newSession = false,
                )
                store.update { it.copy(paused = false, pausedLeftMs = 0L) }
                Notifications.refreshStatus(app)
            }
            PomodoroPhase.BREAK -> {
                val left = s.pausedLeftMs.coerceAtLeast(1_000L)
                store.update { beginBreakClock(it.copy(paused = false, pausedLeftMs = 0L), app, left) }
                ensureService(app)
                FocusEngine.scheduleAt(app, System.currentTimeMillis() + left)
            }
            PomodoroPhase.IDLE -> Unit
        }
    }

    /**
     * Ends the cycle. Refused only while a Focus round runs and "Allow turning LockDistra OFF" is
     * switched off (the round itself is locked); between rounds the cycle can always be stopped,
     * so a locked Pomodoro can never become a trap.
     */
    @Synchronized
    fun stop(context: Context): Boolean {
        val app = context.applicationContext
        val store = PomodoroStore.get(app)
        val s = store.current()
        if (!s.active) return true
        if (s.phase == PomodoroPhase.FOCUS && !s.paused && !FocusStore.get(app).current().canTurnOff) return false
        endCycle(app)
        return true
    }

    /** Idle first (so the service is not revived), then end any session and clear the notifications. */
    @Synchronized
    fun endCycle(context: Context) {
        val app = context.applicationContext
        PomodoroStore.get(app).update { it.copy(phase = PomodoroPhase.IDLE, round = 0, paused = false, pausedLeftMs = 0L) }
        FocusController.stop(app, fromPomodoro = true)
        Notifications.cancelPomodoro(app)
    }

    /**
     * The Focus round's session just ended because its timer ran out. Starts the Break: no session
     * runs, so Focus restrictions are off, and the service stays up to count the break.
     * Returns true when the Pomodoro took over (the usual "session complete" message is skipped).
     */
    @Synchronized
    fun onFocusCompleted(context: Context): Boolean {
        val app = context.applicationContext
        val store = PomodoroStore.get(app)
        val s = store.current()
        if (s.phase != PomodoroPhase.FOCUS || s.paused) return false
        val ms = s.breakMin * 60_000L
        store.update { beginBreakClock(it.copy(phase = PomodoroPhase.BREAK), app, ms) }
        ensureService(app)
        FocusEngine.scheduleAt(app, System.currentTimeMillis() + ms)
        Notifications.postBreakStarted(app, s.focusMin, s.breakMin)
        return true
    }

    /**
     * Time check, safe to call often. Returns true while a Break is counting down (the caller
     * keeps the service and alarms); false when there is nothing for the Pomodoro to do.
     */
    @Synchronized
    fun process(context: Context): Boolean {
        val app = context.applicationContext
        val store = PomodoroStore.get(app)
        val s = store.current()
        if (!s.active || s.paused) return false
        when (s.phase) {
            PomodoroPhase.FOCUS -> {
                // A Focus round always has a session. Without one the cycle is stale: end it.
                if (!FocusStore.get(app).current().focusActive) store.update {
                    it.copy(phase = PomodoroPhase.IDLE, round = 0, paused = false)
                }
                return false
            }
            PomodoroPhase.BREAK -> {
                if (breakLeftMs(app, s) > 0L) return true
                FocusController.start(app, s.focusMin, fromPomodoro = true, newSession = false)
                store.update {
                    it.copy(
                        phase = PomodoroPhase.FOCUS, round = s.round + 1,
                        breakEndWall = 0L, breakEndElapsed = 0L, breakBoot = -1,
                    )
                }
                Notifications.refreshStatus(app)
                Notifications.postBreakOver(app, s.breakMin)
                return true
            }
            PomodoroPhase.IDLE -> return false
        }
    }

    /** Re-arms the end-of-break alarm and the service. Called when the app, the alarm or a boot wakes us. */
    fun ensureScheduled(context: Context) {
        val app = context.applicationContext
        val s = PomodoroStore.get(app).current()
        if (s.phase != PomodoroPhase.BREAK || s.paused) return
        val left = breakLeftMs(app, s)
        FocusEngine.scheduleAt(app, System.currentTimeMillis() + left)
        ensureService(app)
    }

    /** After a restart or app update: a break that was running carries on (or ends, if its time has passed). */
    fun resumeIfNeeded(context: Context) {
        val app = context.applicationContext
        if (!PomodoroStore.get(app).current().running) return
        if (process(app)) ensureScheduled(app)
    }

    fun breakLeftMs(context: Context, s: PomodoroState): Long =
        PomodoroRules.breakLeftMs(s, System.currentTimeMillis(), SystemClock.elapsedRealtime(), bootCount(context))

    /** Stamps a break of [ms] starting now on both clocks. */
    private fun beginBreakClock(s: PomodoroState, context: Context, ms: Long): PomodoroState = s.copy(
        breakEndWall = System.currentTimeMillis() + ms,
        breakEndElapsed = SystemClock.elapsedRealtime() + ms,
        breakBoot = bootCount(context),
    )

    private fun ensureService(app: Context) {
        Notifications.ensureChannels(app)
        try {
            ContextCompat.startForegroundService(app, Intent(app, FocusService::class.java))
        } catch (_: Exception) {
            // Android may refuse a background start; the end-of-break alarm still brings the next round.
        }
    }

    private fun bootCount(context: Context): Int = try {
        Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) {
        -1
    }
}
