package com.focusmode.app.ui.onboarding

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.OnboardingAnswers
import com.focusmode.app.data.OnboardingReactions
import com.focusmode.app.data.OnboardingQuestion
import com.focusmode.app.data.OnboardingQuestions
import com.focusmode.app.data.QuestionType
import com.focusmode.app.data.Typewriter
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusBackground
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay
import kotlin.math.max

/**
 * Onboarding Part 2A: the seven question screens, one at a time.
 *
 * The screen is stateless about the flow: the caller (see [OnboardingFlow]) owns the current
 * [index] and the [answers]. This screen owns only what is purely visual (typing animation, scroll).
 *
 * Layout: header (Back + "Question n of 7" + progress) -> the same mascot -> the question in the
 * mascot's speech bubble -> the answer options -> Next. The mascot, header and button stay put;
 * only the question and its options slide when the question changes. Portrait stacks everything and
 * scrolls on short screens; landscape puts the mascot and question on the left, options on the right.
 *
 * @param onBack  Back button or system back. The caller decides what "back" means on question 1.
 * @param onNext  Next button. The caller decides what "next" means on question 7.
 */
@Composable
fun QuestionsScreen(
    index: Int,
    answers: OnboardingAnswers,
    onAnswersChange: (OnboardingAnswers) -> Unit,
    onBack: () -> Unit,
    onNext: () -> Unit,
) {
    val questions = OnboardingQuestions.all
    val total = questions.size
    val question = questions[index.coerceIn(0, total - 1)]
    val isLast = index >= total - 1
    val canContinue = answers.canContinue(question)
    val focus = LocalFocusManager.current

    BackHandler { back(focus, onBack) }

    // ---- The mascot "types" each new question once; going back shows it instantly ------------
    var seenUpTo by rememberSaveable { mutableIntStateOf(-1) }
    var skipped by remember(index) { mutableStateOf(false) }
    var shown by remember(index) { mutableIntStateOf(if (index <= seenUpTo) Typewriter.length(question.prompt) else 0) }
    var talking by remember { mutableStateOf(false) }

    LaunchedEffect(index) {
        val units = Typewriter.length(question.prompt)
        if (index <= seenUpTo) {
            shown = units
            return@LaunchedEffect
        }
        talking = true
        try {
            delay(260) // let the slide settle first
            for (i in 1..units) {
                if (skipped) break
                shown = i
                delay(22)
            }
            shown = units
        } finally {
            talking = false
            seenUpTo = max(seenUpTo, index)
        }
    }
    val pose = if (talking) BuddyPose.Talking else BuddyPose.Idle

    // ---- Part 2C: how the mascot feels about this question, and a reaction to every answer -----
    val mood = OnboardingReactions.moodFor(question.id, answers)
    val signature = OnboardingReactions.signature(question.id, answers)
    val signatureOnArrival = remember(index) { signature }
    var reactionTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(signature) {
        // Only the person's own input counts; arriving on a question (even with a saved answer) does not.
        if (signature != signatureOnArrival) reactionTick++
    }

    // ---- Pieces --------------------------------------------------------------------------------
    val bubble: @Composable (Int, BubbleTail) -> Unit = { idx, tail ->
        val q = questions[idx]
        QuestionBubble(
            question = q,
            shownUnits = if (idx == index) shown else Typewriter.length(q.prompt),
            tail = tail,
            onTap = { skipped = true },
        )
    }
    val options: @Composable (Int) -> Unit = { idx ->
        val q = questions[idx]
        AnswerArea(
            question = q,
            answers = answers,
            onAnswersChange = onAnswersChange,
            onDone = { if (answers.canContinue(q)) next(focus, onNext) },
        )
    }
    val button: @Composable () -> Unit = {
        PrimaryButton(
            text = if (isLast) "Finish" else "Next",
            onClick = { next(focus, onNext) },
            enabled = canContinue,
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            // Opaque and touch-swallowing, like the welcome screen: nothing underneath may react.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        FocusBackground(Modifier.matchParentSize())

        BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
            val fullHeight = maxHeight
            val landscape = maxWidth > maxHeight

            Column(Modifier.fillMaxSize()) {
                QuestionHeader(index = index, total = total, onBack = { back(focus, onBack) })

                if (landscape) {
                    Row(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                    ) {
                        Column(
                            Modifier
                                .weight(0.9f)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            FocusBuddy(
                                pose = pose,
                                modifier = Modifier.fillMaxWidth().height((fullHeight * 0.42f).coerceIn(110.dp, 220.dp)),
                                mood = mood,
                                reactionTick = reactionTick,
                            )
                            QuestionTransition(index) { idx -> bubble(idx, BubbleTail.Start) }
                        }
                        Column(Modifier.weight(1.1f).fillMaxHeight()) {
                            val scroll = rememberScrollState()
                            LaunchedEffect(index) { scroll.scrollTo(0) }
                            Column(Modifier.weight(1f).verticalScroll(scroll)) {
                                QuestionTransition(index) { idx -> options(idx) }
                            }
                            Spacer(Modifier.height(12.dp))
                            button()
                        }
                    }
                } else {
                    val scroll = rememberScrollState()
                    LaunchedEffect(index) { scroll.scrollTo(0) }

                    // Shrink the mascot while the keyboard is open (question 1) so the field stays visible.
                    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
                    val mascotHeight by animateDpAsState(
                        if (imeOpen) (fullHeight * 0.12f).coerceIn(56.dp, 100.dp)
                        else (fullHeight * 0.20f).coerceIn(96.dp, 180.dp),
                        tween(250), label = "questionMascot"
                    )

                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(scroll)
                            .padding(horizontal = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        FocusBuddy(
                            pose = pose,
                            modifier = Modifier.fillMaxWidth().height(mascotHeight),
                            mood = mood,
                            reactionTick = reactionTick,
                        )
                        Spacer(Modifier.height(4.dp))
                        QuestionTransition(index) { idx ->
                            Column {
                                bubble(idx, BubbleTail.Top)
                                Spacer(Modifier.height(20.dp))
                                options(idx)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                    }
                    Box(Modifier.padding(start = 24.dp, end = 24.dp, top = 8.dp, bottom = 16.dp)) { button() }
                }
            }
        }
    }
}

private fun next(focus: FocusManager, onNext: () -> Unit) {
    focus.clearFocus()
    onNext()
}

private fun back(focus: FocusManager, onBack: () -> Unit) {
    focus.clearFocus()
    onBack()
}

/** Slides the new question in from the side it is "coming from" (right when going forward). */
@Composable
private fun QuestionTransition(index: Int, content: @Composable (Int) -> Unit) {
    AnimatedContent(
        targetState = index,
        transitionSpec = {
            val dir = if (targetState > initialState) 1 else -1
            (slideInHorizontally(tween(320)) { it * dir / 3 } + fadeIn(tween(320, delayMillis = 60)))
                .togetherWith(slideOutHorizontally(tween(260)) { -it * dir / 3 } + fadeOut(tween(160)))
                .using(SizeTransform(clip = false) { _, _ -> tween(300) })
        },
        label = "questionTransition",
    ) { idx -> content(idx) }
}

// ---- Header ------------------------------------------------------------------------------------

@Composable
private fun QuestionHeader(index: Int, total: Int, onBack: () -> Unit) {
    val c = FocusTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 24.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircleIconButton(
            icon = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = "Back",
            onClick = onBack,
        )
        Spacer(Modifier.size(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                "Question ${index + 1} of $total",
                style = MaterialTheme.typography.labelLarge,
                color = c.muted,
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (i in 0 until total) {
                    val fill by animateColorAsState(
                        if (i <= index) c.gradMid else c.ringTrack, tween(300), label = "progress$i"
                    )
                    Box(
                        Modifier
                            .weight(1f)
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(fill)
                    )
                }
            }
        }
    }
}

// ---- Question bubble ---------------------------------------------------------------------------

@Composable
private fun QuestionBubble(
    question: OnboardingQuestion,
    shownUnits: Int,
    tail: BubbleTail,
    onTap: () -> Unit,
) {
    val c = FocusTheme.colors
    BuddySpeechBubble(
        modifier = Modifier
            .fillMaxWidth()
            // Tap the bubble to skip the typing (same as the welcome screen).
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onTap),
        tail = tail,
    ) {
        TypedText(
            full = question.prompt,
            shownUnits = shownUnits,
            style = MaterialTheme.typography.titleLarge,
            color = c.text,
        )
        question.hint?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium, color = c.muted)
        }
    }
}

// ---- Answers -----------------------------------------------------------------------------------

@Composable
private fun AnswerArea(
    question: OnboardingQuestion,
    answers: OnboardingAnswers,
    onAnswersChange: (OnboardingAnswers) -> Unit,
    onDone: () -> Unit,
) {
    when (question.type) {
        QuestionType.Text -> NameField(
            value = answers.text(question.id),
            onValueChange = { onAnswersChange(answers.withText(question.id, it)) },
            onDone = onDone,
        )

        QuestionType.SingleChoice, QuestionType.MultiChoice -> {
            val multi = question.type == QuestionType.MultiChoice
            val chosen = answers.selected(question.id)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (option in question.options) {
                    OptionRow(
                        label = option.label,
                        selected = option.id in chosen,
                        multi = multi,
                        onClick = {
                            onAnswersChange(
                                if (multi) answers.withToggled(question.id, option.id)
                                else answers.withSingle(question.id, option.id)
                            )
                        },
                    )
                }
                if (question.id == OnboardingQuestions.DAILY_GOAL &&
                    OnboardingQuestions.DAILY_GOAL_CUSTOM_OPTION in chosen
                ) {
                    CustomGoalField(
                        value = answers.customGoalText,
                        onValueChange = { onAnswersChange(answers.withCustomGoalText(it)) },
                        onDone = onDone,
                    )
                }
            }
        }
    }
}

/** Shown under the options when "Set my own goal" is picked: the daily goal in minutes. */
@Composable
private fun CustomGoalField(value: String, onValueChange: (String) -> Unit, onDone: () -> Unit) {
    val c = FocusTheme.colors
    val typed = value.toIntOrNull()
    val outOfRange = value.isNotEmpty() &&
        (typed == null || typed !in OnboardingQuestions.CUSTOM_GOAL_MIN..OnboardingQuestions.CUSTOM_GOAL_MAX)
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        isError = outOfRange,
        label = { Text("Minutes per day") },
        supportingText = {
            Text(
                "Between ${OnboardingQuestions.CUSTOM_GOAL_MIN} and ${OnboardingQuestions.CUSTOM_GOAL_MAX} minutes",
                style = MaterialTheme.typography.bodySmall,
            )
        },
        textStyle = MaterialTheme.typography.bodyLarge,
        shape = RoundedCornerShape(20.dp),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = c.text,
            unfocusedTextColor = c.text,
            errorTextColor = c.text,
            focusedContainerColor = c.card,
            unfocusedContainerColor = c.card,
            errorContainerColor = c.card,
            focusedBorderColor = c.accent,
            unfocusedBorderColor = c.stroke,
            errorBorderColor = c.warning,
            cursorColor = c.accent,
            focusedLabelColor = c.accent,
            unfocusedLabelColor = c.muted,
            errorLabelColor = c.warning,
            focusedSupportingTextColor = c.muted,
            unfocusedSupportingTextColor = c.muted,
            errorSupportingTextColor = c.warning,
        ),
    )
}

@Composable
private fun NameField(value: String, onValueChange: (String) -> Unit, onDone: () -> Unit) {
    val c = FocusTheme.colors
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text("Your name", style = MaterialTheme.typography.bodyLarge) },
        textStyle = MaterialTheme.typography.bodyLarge,
        shape = RoundedCornerShape(20.dp),
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Done),
        keyboardActions = KeyboardActions(onDone = { onDone() }),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = c.text,
            unfocusedTextColor = c.text,
            focusedContainerColor = c.card,
            unfocusedContainerColor = c.card,
            focusedBorderColor = c.accent,
            unfocusedBorderColor = c.stroke,
            cursorColor = c.accent,
            focusedPlaceholderColor = c.muted,
            unfocusedPlaceholderColor = c.muted,
        ),
    )
}

@Composable
private fun OptionRow(label: String, selected: Boolean, multi: Boolean, onClick: () -> Unit) {
    val c = FocusTheme.colors
    FocusCard(
        modifier = Modifier
            .fillMaxWidth()
            .semantics(mergeDescendants = true) {
                role = if (multi) Role.Checkbox else Role.RadioButton
                this.selected = selected
            },
        onClick = onClick,
        padding = PaddingValues(horizontal = 18.dp, vertical = 15.dp),
        highlight = selected,
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyLarge, color = c.text, modifier = Modifier.weight(1f))
            Spacer(Modifier.size(12.dp))
            SelectionMark(selected = selected, multi = multi)
        }
    }
}

/** Round for single choice, rounded square for multiple choice; filled with a tick when selected. */
@Composable
private fun SelectionMark(selected: Boolean, multi: Boolean) {
    val c = FocusTheme.colors
    val shape = if (multi) RoundedCornerShape(7.dp) else CircleShape
    val fill by animateColorAsState(if (selected) c.gradMid else Color.Transparent, tween(200), label = "markFill")
    val edge by animateColorAsState(if (selected) c.gradMid else c.muted.copy(alpha = 0.6f), tween(200), label = "markEdge")
    Box(
        Modifier
            .size(24.dp)
            .clip(shape)
            .background(fill)
            .border(2.dp, edge, shape),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) Icon(Icons.Rounded.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
    }
}
