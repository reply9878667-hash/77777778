package com.focusmode.app.data

/**
 * Platforms whose own apps / sites are closed during a session once a lecture is chosen on them, so no OTHER video of
 * that platform can play. A platform that is not listed (any other website) is [WEB]: only its site is closed in the
 * browsers LockDistra watches, there is no app to close.
 */
enum class LecturePlatform(val label: String, val hosts: List<String>, val packages: Set<String>) {
    YOUTUBE("YouTube", listOf("youtube.com", "youtu.be", "youtube-nocookie.com"), setOf("com.google.android.youtube")),
    FACEBOOK("Facebook", listOf("facebook.com", "fb.watch", "fb.com", "fb.me"), setOf("com.facebook.katana", "com.facebook.lite")),
    INSTAGRAM("Instagram", listOf("instagram.com", "instagr.am"), setOf("com.instagram.android")),
    VIMEO("Vimeo", listOf("vimeo.com"), setOf("com.vimeo.android.videoapp")),
    X("X", listOf("x.com", "twitter.com"), setOf("com.twitter.android")),
    TWITCH("Twitch", listOf("twitch.tv"), setOf("tv.twitch.android.app")),
    DAILYMOTION("Dailymotion", listOf("dailymotion.com", "dai.ly"), setOf("com.dailymotion.dailymotion")),
    WEB("this website", emptyList(), emptySet());
}

/**
 * The lecture the person pasted. [url] is the cleaned-up link (always https), [host] its site without "www.",
 * [youtubeId] is set for a single YouTube video.
 */
data class LectureTarget(
    val url: String,
    val host: String,
    val platform: LecturePlatform,
    val youtubeId: String?,
) {
    /** Hosts that are closed in the browsers while the lecture runs. Empty for Google Drive style file links. */
    val blockedHosts: Set<String>
        get() = when {
            platform != LecturePlatform.WEB -> platform.hosts.toSet()
            host in NEVER_BLOCK_HOSTS -> emptySet()
            else -> setOf(host)
        }

    /** True when [pkg] is the app of the lecture's platform. */
    fun blocksApp(pkg: String): Boolean = pkg in platform.packages

    private companion object {
        /** Shared file hosts: closing them would close much more than "other videos". */
        val NEVER_BLOCK_HOSTS = setOf("drive.google.com", "docs.google.com", "google.com", "dropbox.com")
    }
}

/**
 * "Lecture Lock": before Focus Mode starts the person can paste the link of the one video they will watch, from ANY
 * platform (YouTube, Facebook, Instagram, Vimeo, a website, a direct .mp4 ...). Only that video is meant to play; the
 * rest of the phone stays as it is. This file turns whatever was pasted into a [LectureTarget].
 *
 * Pure logic, no Android classes, so it can be unit tested on the JVM.
 */
object LectureLink {
    private val ID = Regex("^[A-Za-z0-9_-]{11}$")
    private val SCHEME = Regex("^[A-Za-z][A-Za-z0-9+.-]*:")
    private val DOMAIN_LIKE = Regex("^(?:[A-Za-z0-9-]+\\.)+[A-Za-z]{2,}(?::\\d+)?(?:[/?#]\\S*)?$")
    private val PATH_ID = Regex("^/(?:shorts|live|embed|v)/([A-Za-z0-9_-]{11})(?:[/?#].*)?$")
    private val SHORT_ID = Regex("^/([A-Za-z0-9_-]{11})(?:[/?#].*)?$")
    private val DRIVE_FILE = Regex("^/file/d/([A-Za-z0-9_-]+)(?:/.*)?$")

    /** Pieces of a link: host (lower case, no "www."), path (starts with "/", may be empty) and query (without "?"). */
    private data class Parts(val host: String, val path: String, val query: String)

    /**
     * The lecture in [raw], or null when there is nothing usable: no link at all, a link that is not http(s), or a
     * YouTube link that is not one single video (home page, channel, playlist only). [raw] may be a link, a link
     * without "https://", or the text a Share button produces ("Title https://youtu.be/...").
     */
    fun parse(raw: String): LectureTarget? {
        for (token in raw.trim().split(Regex("\\s+"))) {
            val t = token.trim().trim('<', '>', '"', '\'', '(', ')', ',')
            if (t.isEmpty()) continue
            val withScheme = when {
                SCHEME.containsMatchIn(t) -> if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else continue
                DOMAIN_LIKE.matches(t) -> "https://$t"
                else -> continue
            }
            val parts = split(withScheme) ?: continue
            return build(parts, withScheme)
        }
        return null
    }

    private fun split(url: String): Parts? {
        val rest = url.substringAfter("://")
        val authority = rest.substringBefore('/').substringBefore('?').substringBefore('#')
        val host = authority.substringAfterLast('@').substringBefore(':').lowercase().removePrefix("www.")
        if (host.isEmpty() || '.' !in host || host.endsWith(".")) return null
        val afterHost = rest.substring(authority.length)
        val noFragment = afterHost.substringBefore('#')
        val path = noFragment.substringBefore('?')
        val query = if ('?' in noFragment) noFragment.substringAfter('?') else ""
        return Parts(host, path, query)
    }

    private fun platformOf(host: String): LecturePlatform =
        LecturePlatform.entries.firstOrNull { p -> p.hosts.any { host == it || host.endsWith(".$it") } } ?: LecturePlatform.WEB

    private fun queryValue(query: String, key: String): String? =
        query.split('&').firstNotNullOfOrNull { kv ->
            if (kv.substringBefore('=') == key) kv.substringAfter('=', "") else null
        }

    private fun youtubeId(host: String, path: String, query: String): String? {
        val id = if (host == "youtu.be" || host.endsWith(".youtu.be")) SHORT_ID.matchEntire(path)?.groupValues?.get(1)
        else PATH_ID.matchEntire(path)?.groupValues?.get(1)
            ?: if (path == "/watch") queryValue(query, "v")?.takeIf { ID.matches(it) } else null
        return id
    }

    private fun build(p: Parts, original: String): LectureTarget? {
        val platform = platformOf(p.host)
        if (platform == LecturePlatform.YOUTUBE) {
            val id = youtubeId(p.host, p.path, p.query) ?: return null
            return LectureTarget(watchUrl(id), "youtube.com", platform, id)
        }
        // Google Drive "view" links only show a page around the file; "preview" is the player itself.
        if (p.host == "drive.google.com") {
            DRIVE_FILE.matchEntire(p.path)?.let {
                return LectureTarget("https://drive.google.com/file/d/${it.groupValues[1]}/preview", p.host, platform, null)
            }
        }
        val clean = if (original.startsWith("http://", true)) "https://" + original.substring(7) else original
        return LectureTarget(clean, p.host, platform, null)
    }

    fun watchUrl(videoId: String) = "https://www.youtube.com/watch?v=$videoId"

    /** True when [host] is [site] or one of its sub-domains. */
    fun hostMatches(host: String, site: String): Boolean {
        val h = host.lowercase().removePrefix("www.")
        return h == site || h.endsWith(".$site")
    }

    /** True when [host] belongs to one of [sites]. */
    fun hostMatchesAny(host: String, sites: Set<String>): Boolean = sites.any { hostMatches(host, it) }

    private val LOGIN_WORDS = listOf("login", "log_in", "signin", "sign-in", "accounts", "checkpoint", "oauth", "consent", "recover")

    /** Sign-in pages a platform shows before the video; they have to stay reachable. */
    fun isLoginPage(url: String): Boolean {
        val p = split(url) ?: return false
        val path = p.path.lowercase()
        return LOGIN_WORDS.any { it in path } || LOGIN_WORDS.any { it in p.host }
    }

    /**
     * Whether [url] shows the lecture [target] (or the page it settled on, [settled]). Hosts are compared by family
     * (m.facebook.com = facebook.com), then the path and, when the lecture link has one, the "v" / "id" value.
     */
    fun isSameLecture(target: LectureTarget, url: String, settled: String? = null): Boolean {
        val now = split(url) ?: return false
        if (target.youtubeId != null) {
            return youtubeId(now.host, now.path, now.query) == target.youtubeId
        }
        for (ref in listOfNotNull(target.url, settled)) {
            val r = split(ref) ?: continue
            if (!sameFamily(r.host, now.host)) continue
            if (r.path.trimEnd('/') != now.path.trimEnd('/')) continue
            val ok = listOf("v", "id", "video_id", "story_fbid", "fbid").all { k ->
                val want = queryValue(r.query, k)
                want == null || want == queryValue(now.query, k)
            }
            if (ok) return true
        }
        return false
    }

    private fun sameFamily(a: String, b: String): Boolean {
        if (a == b) return true
        val pa = platformOf(a)
        return pa != LecturePlatform.WEB && pa == platformOf(b)
    }
}
