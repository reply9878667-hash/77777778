package com.focusmode.app.data.profile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Turns a picture picked from the gallery into a small square JPEG (256 x 256, about 15-40 KB) as Base64, so the
 * profile photo can live in the same database as the rest of the profile (no extra storage service needed).
 */
object ProfilePhotos {

    private const val SIDE = 256

    /** null when the file can't be read as a picture. */
    suspend fun process(context: Context, uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val resolver = context.applicationContext.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext null

            var sample = 1
            while (bounds.outWidth / (sample * 2) >= SIDE && bounds.outHeight / (sample * 2) >= SIDE) sample *= 2
            val decoded = resolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
            } ?: return@withContext null

            val rotation = resolver.openInputStream(uri)?.use { stream ->
                when (ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f

            // Centre square crop, then scale to SIDE x SIDE.
            val side = minOf(decoded.width, decoded.height)
            val x = (decoded.width - side) / 2
            val y = (decoded.height - side) / 2
            val matrix = Matrix().apply {
                postScale(SIDE.toFloat() / side, SIDE.toFloat() / side)
                if (rotation != 0f) postRotate(rotation)
            }
            val out = Bitmap.createBitmap(decoded, x, y, side, side, matrix, true)

            var quality = 85
            var text: String
            do {
                val bytes = ByteArrayOutputStream().also { out.compress(Bitmap.CompressFormat.JPEG, quality, it) }.toByteArray()
                text = Base64.encodeToString(bytes, Base64.NO_WRAP)
                quality -= 15
            } while (text.length > ProfileRules.MAX_PHOTO_CHARS && quality >= 25)
            text.takeIf { it.length <= ProfileRules.MAX_PHOTO_CHARS }
        } catch (_: Exception) {
            null
        }
    }
}
