package com.focusmode.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Keeps the Auto Focus schedule on this phone (SharedPreferences, nothing leaves the device) and remembers which
 * window was already handled, so that a session the person ended by hand is not started again inside the same window.
 */
class AutoFocusStore private constructor(context: Context) {
    private val prefs = Storage.prefs(context, FILE)

    private val _schedule = MutableStateFlow(read())
    val schedule: StateFlow<AutoFocusSchedule> = _schedule.asStateFlow()

    /** Start time (ms) of the last window that was started or deliberately skipped. */
    val lastHandledStart: Long get() = prefs.getLong(KEY_HANDLED, 0L)

    fun markHandled(window: AutoFocusWindow) {
        prefs.edit().putLong(KEY_HANDLED, window.startMs).apply()
    }

    /**
     * Saves the schedule. Turning it on or editing it while the chosen time is already running does NOT lock the phone
     * on the spot: that window is skipped and Auto Focus starts from the next one (Focus can still be started by hand).
     */
    fun save(next: AutoFocusSchedule, now: Long = System.currentTimeMillis()) {
        if (!next.isValid && next.enabled) return
        next.currentWindow(now)?.let { markHandled(it) }
        prefs.edit()
            .putBoolean(KEY_ENABLED, next.enabled)
            .putInt(KEY_START, next.startMin)
            .putInt(KEY_END, next.endMin)
            .putInt(KEY_DAYS, next.days)
            .apply()
        _schedule.value = next
    }

    private fun read(): AutoFocusSchedule {
        val d = AutoFocusSchedule()
        return AutoFocusSchedule(
            enabled = prefs.getBoolean(KEY_ENABLED, d.enabled),
            startMin = prefs.getInt(KEY_START, d.startMin),
            endMin = prefs.getInt(KEY_END, d.endMin),
            days = prefs.getInt(KEY_DAYS, d.days),
        )
    }

    companion object {
        private const val FILE = "auto_focus"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_START = "start_min"
        private const val KEY_END = "end_min"
        private const val KEY_DAYS = "days"
        private const val KEY_HANDLED = "last_handled_start"

        @Volatile private var instance: AutoFocusStore? = null

        fun get(context: Context): AutoFocusStore =
            instance ?: synchronized(this) {
                instance ?: AutoFocusStore(context.applicationContext).also { instance = it }
            }
    }
}
