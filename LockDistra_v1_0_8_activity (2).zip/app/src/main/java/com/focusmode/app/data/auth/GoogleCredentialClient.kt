package com.focusmode.app.data.auth

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.focusmode.app.BuildConfig
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import kotlinx.coroutines.CancellationException

data class GoogleIdentity(val idToken: String, val displayName: String?, val email: String?)

/**
 * Shows Android's "Sign in with Google" sheet (Credential Manager) and returns the Google ID token. It does not
 * touch Firebase; [FirebaseAuthService] exchanges the token. Needs the OAuth WEB client id (AuthConfig.webClientId)
 * and, for the sheet to open at all, an Android OAuth client with this app's package + SHA-1 in the same Google
 * Cloud project (Firebase creates it when the SHA-1 is added to the Android app). See AUTH_TASK1.md.
 */
class GoogleCredentialClient {

    /** @throws AuthCancelledException the person closed the sheet. @throws AuthException any other problem. */
    suspend fun getIdentity(activity: Activity, webClientId: String): GoogleIdentity {
        // Forget any earlier choice first, so Android always shows the chooser with EVERY Google account on this
        // phone (and "Add another account") instead of silently reusing the last one.
        AuthDebug.reset()
        AuthDebug.note("1 opening the Google sheet")
        clear(activity)
        val credential = try {
            // 1st try: the "Sign in with Google" sheet. It lists all accounts on the phone.
            fetch(activity, GetSignInWithGoogleOption.Builder(webClientId).build())
        } catch (e: NoCredentialException) {
            try {
                // 2nd try: the account bottom sheet with no "already used here" filter and no auto-pick.
                fetch(
                    activity,
                    GetGoogleIdOption.Builder()
                        .setServerClientId(webClientId)
                        .setFilterByAuthorizedAccounts(false)
                        .setAutoSelectEnabled(false)
                        .build(),
                )
            } catch (e2: NoCredentialException) {
                throw AuthException(AuthErrorKind.GOOGLE_NO_ACCOUNT, withDebugDetail(activity, AuthErrors.message(AuthErrorKind.GOOGLE_NO_ACCOUNT), e2), e2)
            }
        }

        if (credential !is CustomCredential || credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            throw AuthException(AuthErrorKind.GOOGLE_FAILED)
        }
        return try {
            val google = GoogleIdTokenCredential.createFrom(credential.data)
            AuthDebug.note("3 account chosen: ${google.id}")
            GoogleIdentity(google.idToken, google.displayName, google.id)
        } catch (e: GoogleIdTokenParsingException) {
            throw AuthException(AuthErrorKind.GOOGLE_FAILED, cause = e)
        }
    }

    /** One Credential Manager call; closing the sheet / other errors are turned into the app's own exceptions. */
    private suspend fun fetch(activity: Activity, option: androidx.credentials.CredentialOption): androidx.credentials.Credential {
        val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
        return try {
            CredentialManager.create(activity).getCredential(activity, request).credential
                .also { AuthDebug.note("2 sheet returned: ${it.type}") }
        } catch (e: GetCredentialCancellationException) {
            AuthDebug.note("sheet cancelled: ${e.type}: ${e.message}")
            // Android also reports "cancelled" when the account was picked but Google refuses this build (the SHA-1 of
            // its key is not added to the Android app in Firebase). That looks like nothing happening at all, so debug
            // builds say so and show the SHA-1; release builds stay silent, as a real cancel should be.
            if (BuildConfig.DEBUG) {
                val sha = AppSignature.sha1(activity) ?: "unknown"
                throw AuthException(
                    AuthErrorKind.GOOGLE_FAILED,
                    "Google closed without signing in. If you did not press Back yourself, this build's SHA-1 is not " +
                        "added in Firebase. SHA-1: $sha  (Firebase > Project settings > Your apps > com.focusmode.app > " +
                        "Add fingerprint. Wait a minute, then try again.)",
                    e,
                )
            }
            throw AuthCancelledException()
        } catch (e: NoCredentialException) {
            AuthDebug.note("no credential: ${e.message}")
            throw e
        } catch (e: CancellationException) {
            throw e
        } catch (e: GetCredentialException) {
            AuthDebug.note("sheet error: ${e.type}: ${e.message}")
            throw AuthException(AuthErrorKind.GOOGLE_FAILED, withDebugDetail(activity, AuthErrors.message(AuthErrorKind.GOOGLE_FAILED), e), e)
        } catch (e: Exception) {
            AuthDebug.note("unexpected: ${e.javaClass.simpleName}: ${e.message}")
            throw AuthException(AuthErrorKind.GOOGLE_FAILED, cause = e)
        }
    }

    /** Forget the chosen Google account so the next sign-in shows the account chooser again. Never throws. */
    suspend fun clear(context: Context) {
        try {
            CredentialManager.create(context.applicationContext).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Logging out must never fail because of this.
        }
    }

    /**
     * Debug builds show Google's reason and THIS build's SHA-1 (a missing or different SHA-1 in Firebase is by far the
     * most common reason the account sheet does not open, and Android then often just says "no account");
     * release builds stay plain.
     */
    private fun withDebugDetail(context: Context, base: String, e: Exception): String {
        if (!BuildConfig.DEBUG) return base
        val type = (e as? GetCredentialException)?.type ?: e.javaClass.simpleName
        val sha = AppSignature.sha1(context)?.let { " This build's SHA-1: $it (add it to the Android app in Firebase)." }.orEmpty()
        return "$base ($type: ${e.message.orEmpty()}.$sha)"
    }
}
