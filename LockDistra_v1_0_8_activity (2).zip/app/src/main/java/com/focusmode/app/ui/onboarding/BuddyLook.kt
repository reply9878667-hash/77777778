package com.focusmode.app.ui.onboarding

import com.focusmode.app.data.BuddyMood

/**
 * What a [BuddyMood] looks like, as plain numbers. [FocusBuddy] glides from one look to the next,
 * so every number here is a target, never a jump. The defaults are Part 1's mascot unchanged.
 *
 * Face numbers come first in [toArray] (they move at once); body numbers follow (they start a
 * moment later, which looks more natural than everything changing in the same frame).
 */
internal data class BuddyLook(
    // ---- face ----
    val smile: Float = 1f,        // mouth curve: 1 = normal smile, 0 = flat, below 0 = small frown
    val grin: Float = 0f,         // open happy mouth
    val joy: Float = 0f,          // eyes squint with happiness
    val browRaise: Float = 0f,    // both brows up
    val worry: Float = 0f,        // inner ends of the brows up (worried)
    val browAsym: Float = 0f,     // one brow higher (curious)
    val eyeScale: Float = 1f,     // eye height, above 1 = wide eyes
    val gazeX: Float = 0f,        // where the eyes look, left/right
    val gazeY: Float = 0f,        // where the eyes look, up/down (positive = down, toward the options)
    val tilt: Float = 0f,         // head tilt in degrees
    val lean: Float = 0f,         // head leans sideways
    val blush: Float = 1f,        // cheek colour strength
    // ---- body ----
    val hop: Float = 0f,          // little jumps (height)
    val hopRate: Float = 1.4f,    // jumps per second
    val cheer: Float = 0f,        // free arm raised
    val chin: Float = 0f,         // hand on chin
    val wave: Float = 0f,         // waving hand
    val sparkle: Float = 0f,      // sparkles around the head
    val sweat: Float = 0f,        // sweat drop
    val query: Float = 0f,        // question mark
    val thinkFace: Float = 0f,    // Part 1's "thinking" face (eyes up, brow raised, side mouth)
    val thoughts: Float = 0f,     // thought bubble
    val reactJoy: Float = 0f,     // how much a reaction (option picked) makes the eyes smile
    val reactSparkle: Float = 0f, // how much a reaction sprinkles sparkles
) {
    fun toArray() = floatArrayOf(
        smile, grin, joy, browRaise, worry, browAsym, eyeScale, gazeX, gazeY, tilt, lean, blush,
        hop, hopRate, cheer, chin, wave, sparkle, sweat, query, thinkFace, thoughts, reactJoy, reactSparkle,
    )

    companion object {
        const val SIZE = 24
        const val FACE_COUNT = 12

        const val SMILE = 0; const val GRIN = 1; const val JOY = 2; const val BROW_RAISE = 3
        const val WORRY = 4; const val BROW_ASYM = 5; const val EYE_SCALE = 6; const val GAZE_X = 7
        const val GAZE_Y = 8; const val TILT = 9; const val LEAN = 10; const val BLUSH = 11
        const val HOP = 12; const val HOP_RATE = 13; const val CHEER = 14; const val CHIN = 15
        const val WAVE = 16; const val SPARKLE = 17; const val SWEAT = 18; const val QUERY = 19
        const val THINK_FACE = 20; const val THOUGHTS = 21; const val REACT_JOY = 22; const val REACT_SPARKLE = 23
    }
}

internal fun BuddyMood.look(): BuddyLook = when (this) {
    BuddyMood.Neutral -> BuddyLook()

    BuddyMood.Friendly -> BuddyLook(
        smile = 1.2f, joy = 0.12f, browRaise = 1.5f, tilt = 3f, blush = 1.25f, gazeY = 1f, wave = 1f,
    )

    BuddyMood.Happy -> BuddyLook(
        smile = 1.3f, grin = 0.7f, joy = 0.55f, browRaise = 3f, tilt = 2f, blush = 1.4f,
        hop = 2.2f, hopRate = 1.6f, wave = 1f, sparkle = 1f, reactJoy = 0.3f, reactSparkle = 1f,
    )

    BuddyMood.Interested -> BuddyLook(
        smile = 0.9f, browRaise = 2.5f, browAsym = 0.6f, eyeScale = 1.1f, gazeX = 3f, gazeY = 3f,
        tilt = 5f, lean = 3f, reactJoy = 0.3f,
    )

    BuddyMood.Concerned -> BuddyLook(
        smile = -0.25f, browRaise = 1f, worry = 0.9f, eyeScale = 1.05f, gazeX = -3f, gazeY = 1f,
        tilt = -3f, blush = 0.6f, chin = 1f, sweat = 0.8f,
    )

    BuddyMood.Thoughtful -> BuddyLook(
        tilt = -2f, chin = 1f, thinkFace = 1f, thoughts = 1f,
    )

    BuddyMood.Pleased -> BuddyLook(
        smile = 1.3f, grin = 0.35f, joy = 0.45f, browRaise = 2.5f, tilt = 3f, blush = 1.3f,
        hop = 1.2f, sparkle = 0.8f, reactJoy = 0.4f, reactSparkle = 1f,
    )

    BuddyMood.Worried -> BuddyLook(
        smile = -0.4f, browRaise = 1.5f, worry = 1.1f, eyeScale = 1.1f, gazeX = -3f, gazeY = 2f,
        tilt = -4f, blush = 0.5f, chin = 1f, sweat = 1f,
    )

    BuddyMood.Encouraging -> BuddyLook(
        smile = 1.25f, grin = 0.5f, joy = 0.2f, browRaise = 2.5f, tilt = 3f, blush = 1.2f,
        hop = 1.4f, hopRate = 1.2f, cheer = 1f, sparkle = 0.6f, reactJoy = 0.4f, reactSparkle = 1f,
    )

    BuddyMood.Excited -> BuddyLook(
        smile = 1.35f, grin = 1f, joy = 0.45f, browRaise = 3.5f, eyeScale = 1.1f, blush = 1.4f,
        hop = 3.2f, hopRate = 1.8f, cheer = 1f, wave = 1f, sparkle = 1f, reactSparkle = 1f,
    )

    // The arms, hops and body sway of the dance come from BuddyDance.kt; this is only the face.
    BuddyMood.Celebrating -> BuddyLook(
        smile = 1.35f, grin = 0.6f, joy = 0.6f, browRaise = 3f, blush = 1.5f, sparkle = 1f,
        reactJoy = 0.2f, reactSparkle = 1f,
    )

    BuddyMood.Curious -> BuddyLook(
        smile = 0.85f, browRaise = 2f, browAsym = 1f, eyeScale = 1.12f, gazeX = 4f, gazeY = 1.5f,
        tilt = 7f, lean = 4f, query = 1f, reactJoy = 0.2f,
    )
}
