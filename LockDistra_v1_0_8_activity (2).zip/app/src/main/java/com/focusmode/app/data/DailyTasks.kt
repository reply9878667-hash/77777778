package com.focusmode.app.data

import java.time.Instant
import java.time.ZoneId

/**
 * Daily Task Planner (Home screen). A deliberately small to-do list: tasks are tagged Today or Tomorrow,
 * checked off, and unfinished Tomorrow tasks move to Today when a new local calendar day begins.
 *
 * It shares nothing with Focus Mode, Focus Profile, App Blocking or Pomodoro.
 * Kept free of Android classes so the rules can be unit tested on a plain JVM (DailyTasksTest).
 */
enum class TaskTag(val code: Int) {
    /** Created but not yet put under Today or Tomorrow. */
    NONE(0),
    TODAY(1),
    TOMORROW(2);

    companion object {
        fun fromCode(code: Int): TaskTag = entries.firstOrNull { it.code == code } ?: NONE
    }
}

data class DailyTask(
    val id: Long,
    val text: String,
    val tag: TaskTag = TaskTag.NONE,
    val done: Boolean = false,
)

/**
 * All planner data. [lastDay] is the local calendar day (yyyymmdd) the Tomorrow list was last settled for;
 * 0 means "never", which is the case only before the very first task.
 */
data class TaskBoard(
    val tasks: List<DailyTask> = emptyList(),
    val lastDay: Int = 0,
)

object DailyTaskRules {

    const val MAX_TEXT = 200

    /** One-line text, trimmed, inner whitespace collapsed. Null when nothing usable is left. */
    fun cleanText(raw: String): String? {
        val t = raw.replace(Regex("\\s+"), " ").trim().take(MAX_TEXT).trim()
        return t.ifEmpty { null }
    }

    /** The local calendar day of [ms] as yyyymmdd, in the phone's current time zone. Increases with the date. */
    fun dayKey(ms: Long, zone: ZoneId = ZoneId.systemDefault()): Int {
        val d = Instant.ofEpochMilli(ms).atZone(zone).toLocalDate()
        return d.year * 10_000 + d.monthValue * 100 + d.dayOfMonth
    }

    /**
     * Settles the lists for [today].
     *  - Same day: nothing changes.
     *  - A later day (one day or many, an app restart, or the phone being off over midnight): every UNFINISHED
     *    Tomorrow task becomes a Today task. A FINISHED Tomorrow task is not moved into Today; it simply leaves
     *    Tomorrow (it keeps its done mark), so Tomorrow is empty afterwards.
     *  - An earlier day (time zone change or the clock set back): nothing moves, the marker just follows the clock,
     *    so the next real midnight still works.
     */
    fun rollover(board: TaskBoard, today: Int): TaskBoard {
        if (board.lastDay == today) return board
        if (board.lastDay == 0 || today < board.lastDay) return board.copy(lastDay = today)
        val moved = board.tasks.map { t ->
            when {
                t.tag != TaskTag.TOMORROW -> t
                t.done -> t.copy(tag = TaskTag.NONE)
                else -> t.copy(tag = TaskTag.TODAY)
            }
        }
        return TaskBoard(moved, today)
    }

    /** Adds a task at the end. Blank text adds nothing. */
    fun add(board: TaskBoard, raw: String): TaskBoard {
        val text = cleanText(raw) ?: return board
        val id = (board.tasks.maxOfOrNull { it.id } ?: 0L) + 1L
        return board.copy(tasks = board.tasks + DailyTask(id, text))
    }

    fun setDone(board: TaskBoard, id: Long, done: Boolean): TaskBoard =
        board.copy(tasks = board.tasks.map { if (it.id == id) it.copy(done = done) else it })

    /** Gives every task in [ids] the tag [tag] (also used to change a tag later). */
    fun assign(board: TaskBoard, ids: Set<Long>, tag: TaskTag): TaskBoard =
        board.copy(tasks = board.tasks.map { if (it.id in ids) it.copy(tag = tag) else it })

    fun inTag(board: TaskBoard, tag: TaskTag): List<DailyTask> = board.tasks.filter { it.tag == tag }

    // ---- Saving ------------------------------------------------------------------------------------------------

    /** One task per line: id TAB tagCode TAB doneFlag TAB text (text escaped so it can never break the format). */
    fun encode(tasks: List<DailyTask>): String =
        tasks.joinToString("\n") { "${it.id}\t${it.tag.code}\t${if (it.done) 1 else 0}\t${escape(it.text)}" }

    /** Reads what [encode] wrote. A damaged line is skipped; it never breaks the rest of the list. */
    fun decode(data: String?): List<DailyTask> {
        if (data.isNullOrEmpty()) return emptyList()
        val seen = HashSet<Long>()
        val out = ArrayList<DailyTask>()
        for (line in data.split("\n")) {
            val p = line.split("\t", limit = 4)
            if (p.size < 4) continue
            val id = p[0].toLongOrNull() ?: continue
            val text = cleanText(unescape(p[3])) ?: continue
            if (!seen.add(id)) continue
            out += DailyTask(id, text, TaskTag.fromCode(p[1].toIntOrNull() ?: 0), p[2] == "1")
        }
        return out
    }

    private fun escape(s: String): String =
        s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r")

    private fun unescape(s: String): String {
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                when (s[i + 1]) {
                    't' -> sb.append('\t')
                    'n' -> sb.append('\n')
                    'r' -> sb.append('\r')
                    '\\' -> sb.append('\\')
                    else -> sb.append(s[i + 1])
                }
                i += 2
            } else {
                sb.append(ch)
                i++
            }
        }
        return sb.toString()
    }
}
