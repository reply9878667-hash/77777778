package com.focusmode.app.data

/**
 * Website Usage Limits: a daily time limit for one website, like an App Usage Limit but for a site opened in a
 * supported browser. Kept free of Android classes so the rules can be unit-tested.
 *
 * A limit is a bare domain ("youtube.com"). Every page of that site counts toward it: subpages (/watch, /shorts ...)
 * and subdomains (m.youtube.com, music.youtube.com). A few well-known sites also have a second address that belongs
 * to the same site ("youtu.be", "twitter.com" for "x.com"); those count toward the same limit.
 */
data class WebsiteLimit(
    /** Normalized host: lower case, no scheme / path / port / "www.". */
    val domain: String,
    val limitMin: Int,
    /** OFF keeps the limit saved but neither blocks nor stops it from being edited. */
    val enabled: Boolean = true,
) {
    val limitMs: Long get() = limitMin * 60_000L
}

/** Everything the screens need: the saved limits and today's used time per domain. */
data class WebsiteLimitState(
    val limits: List<WebsiteLimit> = emptyList(),
    /** Today's usage in milliseconds, per [WebsiteLimit.domain]. */
    val usedMs: Map<String, Long> = emptyMap(),
) {
    val hasActive: Boolean get() = limits.any { it.enabled }

    fun usedFor(domain: String): Long = usedMs[domain] ?: 0L

    fun limitFor(domain: String): WebsiteLimit? = limits.firstOrNull { it.domain == domain }

    /** True when the limit is ON and today's time is used up. */
    fun isReached(domain: String): Boolean =
        limitFor(domain)?.let { it.enabled && usedFor(domain) >= it.limitMs } ?: false
}

object WebsiteLimitRules {

    const val MAX_LIMITS = 30

    /** Longest limit: 23 h 59 min, the same ceiling the app limit editor has (23 h + 59 min). */
    const val MAX_MINUTES = 23 * 60 + 59

    const val DEFAULT_MINUTES = 30

    /** Handy first choices in the editor: name shown -> domain saved. */
    val suggestions: List<Pair<String, String>> = listOf(
        "YouTube" to "youtube.com",
        "Instagram" to "instagram.com",
        "Facebook" to "facebook.com",
        "X" to "x.com",
        "Reddit" to "reddit.com",
        "Netflix" to "netflix.com",
    )

    /** Outcome of an add / edit. */
    enum class Result { OK, ALREADY_THERE, OVERLAPS, INVALID, BAD_TIME, FULL, LOCKED, NO_ACCESS }

    class Change(val limits: List<WebsiteLimit>, val result: Result)

    // Second addresses of the same site. Each entry lists every address of that site.
    private val sameSite: List<List<String>> = listOf(
        listOf("youtube.com", "youtu.be"),
        listOf("x.com", "twitter.com", "t.co"),
        listOf("facebook.com", "fb.com", "fb.watch"),
        listOf("instagram.com", "instagr.am"),
    )

    /** [domain] plus the other addresses of the same site, if it has any. */
    fun addressesOf(domain: String): List<String> =
        sameSite.firstOrNull { domain in it } ?: listOf(domain)

    /** Whether [host] (already normalized) belongs to the site [domain]: the domain itself or any subdomain of it. */
    fun covers(domain: String, host: String): Boolean =
        addressesOf(domain).any { host == it || host.endsWith(".$it") }

    /** The limit that covers [host], or null. With no overlapping limits (see [add]) there is at most one. */
    fun find(limits: List<WebsiteLimit>, host: String): WebsiteLimit? =
        limits.firstOrNull { covers(it.domain, host) }

    private fun related(a: String, b: String) = a == b || a.endsWith(".$b") || b.endsWith(".$a")

    /** The same website (same domain, or another address of the same site). */
    private fun sameWebsite(a: String, b: String): Boolean = addressesOf(a).any { it in addressesOf(b) }

    /** One covers the other, for example "google.com" and "mail.google.com". */
    private fun nested(a: String, b: String): Boolean =
        addressesOf(a).any { x -> addressesOf(b).any { y -> related(x, y) } }

    fun clampMinutes(min: Int) = min.coerceIn(1, MAX_MINUTES)

    fun validMinutes(min: Int) = min in 1..MAX_MINUTES

    /**
     * Adds a limit for what was typed (a domain, a link or a plain name such as "youtube"). Rejects: text that is not
     * a website, a time of 0, a site that already has a limit (duplicate), a site that overlaps one that has a limit,
     * and a full list.
     */
    fun add(limits: List<WebsiteLimit>, raw: String, minutes: Int): Change {
        val domain = WebsiteRules.fromTyped(raw) ?: return Change(limits, Result.INVALID)
        if (!validMinutes(minutes)) return Change(limits, Result.BAD_TIME)
        conflict(limits, domain, ignore = null)?.let { return Change(limits, it) }
        if (limits.size >= MAX_LIMITS) return Change(limits, Result.FULL)
        return Change(limits + WebsiteLimit(domain, minutes, enabled = true), Result.OK)
    }

    /** Changes the site and / or the time of [oldDomain]. Its ON / OFF switch stays as it was. */
    fun edit(limits: List<WebsiteLimit>, oldDomain: String, raw: String, minutes: Int): Change {
        val index = limits.indexOfFirst { it.domain == oldDomain }
        if (index < 0) return Change(limits, Result.INVALID)
        val domain = WebsiteRules.fromTyped(raw) ?: return Change(limits, Result.INVALID)
        if (!validMinutes(minutes)) return Change(limits, Result.BAD_TIME)
        conflict(limits, domain, ignore = oldDomain)?.let { return Change(limits, it) }
        val next = limits.toMutableList()
        next[index] = next[index].copy(domain = domain, limitMin = minutes)
        return Change(next, Result.OK)
    }

    fun remove(limits: List<WebsiteLimit>, domain: String): List<WebsiteLimit> =
        limits.filterNot { it.domain == domain }

    fun setEnabled(limits: List<WebsiteLimit>, domain: String, on: Boolean): List<WebsiteLimit> =
        limits.map { if (it.domain == domain) it.copy(enabled = on) else it }

    /** ALREADY_THERE for the same website, OVERLAPS when one limit would cover the other; null when it is free. */
    private fun conflict(limits: List<WebsiteLimit>, domain: String, ignore: String?): Result? {
        val others = limits.filter { it.domain != ignore }
        if (others.any { sameWebsite(it.domain, domain) }) return Result.ALREADY_THERE
        if (others.any { nested(it.domain, domain) }) return Result.OVERLAPS
        return null
    }

    /**
     * What counts as time on a site: a browser must be in front with the screen on, and the address bar must have
     * shown the site recently. [msSinceRead] is how long ago the address bar was last read successfully.
     *
     * A browser can hide its address bar while a page is scrolled, so a site is still counted for [maxUnreadMs] after
     * the last successful read. After that nothing is counted until the address bar can be read again: an honest gap
     * rather than a guess.
     */
    fun countsNow(browserInFront: Boolean, screenOn: Boolean, msSinceRead: Long, maxUnreadMs: Long = MAX_UNREAD_MS): Boolean =
        browserInFront && screenOn && msSinceRead in 0..maxUnreadMs

    const val MAX_UNREAD_MS = 5 * 60_000L

    /** Seconds a tick may add at most, so a stalled service never books a long gap as usage. */
    const val MAX_TICK_MS = 5_000L

    fun tickDelta(rawDeltaMs: Long): Long = rawDeltaMs.coerceIn(0L, MAX_TICK_MS)
}
