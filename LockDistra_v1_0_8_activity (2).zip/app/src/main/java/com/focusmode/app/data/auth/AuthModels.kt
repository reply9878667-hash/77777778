package com.focusmode.app.data.auth

/** How the person signed in. Only these two exist today; add a case here when a provider is added. */
enum class AuthProvider(val label: String) {
    EMAIL("Email and password"),
    GOOGLE("Google"),
    ;

    companion object {
        fun fromId(id: String?): AuthProvider = if (id == GOOGLE.name) GOOGLE else EMAIL
    }
}

/** The signed-in person. No password, no token: those never leave Firebase's own storage. */
data class AuthUser(
    val uid: String,
    val name: String,
    val email: String,
    val provider: AuthProvider,
    val emailVerified: Boolean = false,
)

/** What the rest of the app may observe (`AuthRepository.session`). A later profile phase builds on this. */
sealed interface AuthSession {
    data object SignedOut : AuthSession
    data class SignedIn(val user: AuthUser) : AuthSession
}

enum class AuthErrorKind {
    INVALID_INPUT,
    NOT_CONFIGURED,
    GOOGLE_NOT_CONFIGURED,
    OFFLINE,
    TIMEOUT,
    EMAIL_IN_USE,
    ACCOUNT_EXISTS_OTHER_METHOD,
    INVALID_EMAIL,
    WEAK_PASSWORD,
    WRONG_CREDENTIALS,
    USER_DISABLED,
    TOO_MANY_REQUESTS,
    PROVIDER_DISABLED,
    ALREADY_SIGNED_IN,
    IDENTITY_LOCKED,
    GOOGLE_NO_ACCOUNT,
    GOOGLE_FAILED,
    BUSY,
    UNKNOWN,
}

/** Result of every repository action. The UI never sees an exception. */
sealed interface AuthResult {
    data class Success(val user: AuthUser, val isNewAccount: Boolean) : AuthResult
    data class Failure(val kind: AuthErrorKind, val message: String) : AuthResult

    /** Finished without a user (password reset mail sent, logged out). */
    data object Done : AuthResult

    /** The person closed the Google account sheet. Not an error: nothing is shown. */
    data object Cancelled : AuthResult
}
