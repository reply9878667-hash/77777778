package com.focusmode.app.service

import android.content.Context
import android.content.pm.ApplicationInfo
import java.util.concurrent.ConcurrentHashMap

/** Tells whether an installed app is a game (Android's own game category / flag). */
object GameApps {
    private val cache = ConcurrentHashMap<String, Boolean>()

    @Suppress("DEPRECATION")
    fun isGame(context: Context, pkg: String): Boolean = cache.getOrPut(pkg) {
        try {
            val info = context.packageManager.getApplicationInfo(pkg, 0)
            info.category == ApplicationInfo.CATEGORY_GAME ||
                (info.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        } catch (_: Exception) {
            false
        }
    }
}
