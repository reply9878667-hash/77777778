package com.focusmode.app.service

import android.app.AppOpsManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat

/**
 * The permissions LockDistra cannot work without. Home opens only when none of them is missing (see AppEntryRules).
 * Device admin (uninstall protection) is NOT here: it is an optional protection with its own switch in Settings.
 */
enum class RequiredPermission { ACCESSIBILITY, USAGE_ACCESS, NOTIFICATIONS, BATTERY, EXACT_ALARMS }

data class PermissionStatus(
    val accessibility: Boolean = false,
    val usageAccess: Boolean = false,
    val notifications: Boolean = false,
    val deviceAdmin: Boolean = false,
    val batteryUnrestricted: Boolean = false,
    /** Exact alarms (Android 12+ setting). Always true before Android 12, so older phones are never asked. */
    val exactAlarms: Boolean = true,
    /** "Display over other apps": only used for the blur cover shown after a restart. Optional. */
    val overlay: Boolean = false,
) {
    fun missingRequired(): List<RequiredPermission> = buildList {
        if (!accessibility) add(RequiredPermission.ACCESSIBILITY)
        if (!usageAccess) add(RequiredPermission.USAGE_ACCESS)
        if (!notifications) add(RequiredPermission.NOTIFICATIONS)
        if (!batteryUnrestricted) add(RequiredPermission.BATTERY)
        if (!exactAlarms) add(RequiredPermission.EXACT_ALARMS)
    }

    val allRequiredGranted: Boolean get() = missingRequired().isEmpty()
}

object Permissions {

    fun read(context: Context) = PermissionStatus(
        accessibility = isAccessibilityEnabled(context),
        usageAccess = hasUsageAccess(context),
        notifications = NotificationManagerCompat.from(context).areNotificationsEnabled(),
        deviceAdmin = isAdminActive(context),
        batteryUnrestricted = isIgnoringBatteryOptimizations(context),
        exactAlarms = FocusEngine.canScheduleExact(context),
        overlay = Settings.canDrawOverlays(context),
    )

    fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val mine = ComponentName(context, AppBlockerService::class.java)
        return enabled.split(':').any {
            ComponentName.unflattenFromString(it) == mine
        }
    }

    fun hasUsageAccess(context: Context): Boolean {
        val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ops.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    /**
     * Extra steps for phone makers that stop background apps even after the normal battery
     * exemption. Null when the maker is not known to need any.
     */
    fun oemBatteryHint(): String? = when (Build.MANUFACTURER.lowercase()) {
        "xiaomi", "redmi", "poco" ->
            "Xiaomi / Redmi / POCO: also turn on Autostart for LockDistra and set Battery saver to \"No restrictions\" in the app's info page."
        "oppo", "realme", "oneplus" ->
            "OPPO / realme / OnePlus: also allow Auto-launch and Background activity for LockDistra in its app info page."
        "vivo", "iqoo" ->
            "vivo / iQOO: also allow Autostart and set Background power usage to \"High\" for LockDistra."
        "samsung" ->
            "Samsung: also remove LockDistra from \"Sleeping apps\" and \"Deep sleeping apps\" (Battery > Background usage limits)."
        "huawei", "honor" ->
            "Huawei / Honor: also set LockDistra to \"Manage manually\" with Auto-launch, Secondary launch and Run in background all on."
        else -> null
    }

    fun adminComponent(context: Context) = ComponentName(context, FocusAdminReceiver::class.java)

    fun isAdminActive(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return dpm.isAdminActive(adminComponent(context))
    }

    fun removeAdmin(context: Context) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        dpm.removeActiveAdmin(adminComponent(context))
    }
}
