package com.focusmode.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.KeywordEdits
import com.focusmode.app.data.KeywordRules
import com.focusmode.app.data.KeywordState
import com.focusmode.app.data.WebsiteBrowsers
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.theme.FocusTheme

/** What the Keyword Blocking card can do. The store behind it applies the session locks; the two flags only grey out controls. */
internal class KeywordActions(
    val canTighten: Boolean,
    val canLoosen: Boolean,
    val onEnabled: (Boolean) -> Boolean,
    val onCheckPages: (Boolean) -> Boolean,
    val onAdd: (raw: String, partial: Boolean) -> KeywordEdits.Bulk,
    val onEdit: (old: String, raw: String, partial: Boolean) -> KeywordRules.Result,
    val onRemove: (word: String) -> Boolean,
    val onRuleEnabled: (word: String, on: Boolean) -> Boolean,
)

/**
 * Keyword Blocking, as one card in the Blocking section (next to Website Blocking). Everything for it is in here:
 * the master switch, a simple input with an Add button (several keywords at once, comma separated), the saved
 * keywords with edit / delete / their own switch, and the page-title option.
 *
 * Honest scope: only the address bar and, when the browser exposes it, the page title and headings of the supported
 * browsers are checked. Other browsers, other apps and the text inside pages are not.
 */
@Composable
internal fun KeywordBlockingCard(
    state: KeywordState,
    actions: KeywordActions,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    var open by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var partialNew by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var refused by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<String?>(null) }

    fun add() {
        refused = false
        if (text.isBlank()) { message = "Type a keyword first."; return }
        val bulk = actions.onAdd(text, partialNew)
        when {
            bulk.allDone -> { text = ""; message = null }
            bulk.locked -> message = "Changes are locked right now."
            else -> {
                // Keep only what was not added, so it can be corrected; say why.
                text = (bulk.invalid + bulk.duplicates + bulk.full).joinToString(", ")
                message = buildString {
                    if (bulk.added.isNotEmpty()) append("Added ${bulk.added.size}. ")
                    if (bulk.invalid.isNotEmpty()) append("Not usable (2 to ${KeywordRules.MAX_LENGTH} characters, letters or numbers): ${bulk.invalid.joinToString(", ")}. ")
                    if (bulk.duplicates.isNotEmpty()) append("Already in the list: ${bulk.duplicates.joinToString(", ")}. ")
                    if (bulk.full.isNotEmpty()) append("List is full: ${bulk.full.joinToString(", ")}.")
                }.trim()
            }
        }
    }

    FocusCard(
        modifier = modifier,
        padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        highlight = state.isActive,
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { open = !open }) {
                    Text("Keyword Blocking", style = MaterialTheme.typography.titleMedium)
                    Text(
                        when {
                            state.isActive -> "ON • ${state.activeCount} keyword${if (state.activeCount == 1) "" else "s"}"
                            state.enabled -> "ON • add a keyword to start"
                            state.rules.isNotEmpty() -> "Off • ${state.rules.size} keyword${if (state.rules.size == 1) "" else "s"} saved"
                            else -> "Close browser pages that match your words"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.enabled) c.accent else c.muted
                    )
                }
                Icon(
                    if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    if (open) "Hide keywords" else "Show keywords",
                    tint = c.muted,
                    modifier = Modifier.clickable { open = !open }
                )
                Spacer(Modifier.size(8.dp))
                FocusSwitch(
                    checked = state.enabled,
                    enabled = if (state.enabled) actions.canLoosen else actions.canTighten,
                    onCheckedChange = { refused = !actions.onEnabled(it) }
                )
            }

            if (open) {
                Spacer(Modifier.height(12.dp))
                // Simple input + Add button.
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.take(400); message = null },
                        singleLine = true,
                        placeholder = { Text("e.g. gambling, instagram") },
                        isError = message != null && text.isNotBlank(),
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.size(10.dp))
                    PrimaryButton("Add", onClick = { add() }, modifier = Modifier.width(92.dp), enabled = actions.canTighten)
                }
                if (message != null) {
                    Text(message!!, style = MaterialTheme.typography.bodySmall, color = c.warning, modifier = Modifier.padding(top = 6.dp))
                }
                Text(
                    "Separate several keywords with commas. A keyword closes a page only when it appears as a whole word " +
                        "(\"sex\" does not close \"Essex\").",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(top = 6.dp)
                )
                Spacer(Modifier.height(4.dp))
                SwitchLine(
                    title = "New keywords also match inside words",
                    note = "\"porn\" would also close \"pornhub\". Can close more than you meant.",
                    checked = partialNew,
                    enabled = true,
                    onChange = { partialNew = it }
                )

                Spacer(Modifier.height(10.dp))
                if (state.rules.isEmpty()) {
                    Text("No keywords yet.", style = MaterialTheme.typography.bodySmall, color = c.muted)
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    state.rules.forEach { rule ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(rule.word, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                                Text(
                                    if (rule.partial) "Also inside longer words" else "Whole word only",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = c.muted
                                )
                            }
                            IconButton(onClick = { editing = rule.word }, enabled = actions.canLoosen) {
                                Icon(Icons.Rounded.Edit, "Edit ${rule.word}", tint = if (actions.canLoosen) c.muted else c.muted.copy(alpha = 0.4f), modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = { refused = !actions.onRemove(rule.word) }, enabled = actions.canLoosen) {
                                Icon(Icons.Rounded.Delete, "Delete ${rule.word}", tint = if (actions.canLoosen) c.muted else c.muted.copy(alpha = 0.4f), modifier = Modifier.size(18.dp))
                            }
                            FocusSwitch(
                                checked = rule.enabled,
                                enabled = if (rule.enabled) actions.canLoosen else actions.canTighten,
                                onCheckedChange = { refused = !actions.onRuleEnabled(rule.word, it) }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                SwitchLine(
                    title = "Check page titles and headings",
                    note = "Also looks at what the browser shares about the page. More thorough, a little more battery.",
                    checked = state.checkPages,
                    enabled = if (state.checkPages) actions.canLoosen else actions.canTighten,
                    onChange = { refused = !actions.onCheckPages(it) }
                )
                if (refused) {
                    Text(
                        "This can't be changed right now (a focus session or lock is active).",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.warning,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                Text(
                    "Works in ${WebsiteBrowsers.supportedNames}: the address bar (links and searches) and, when the browser shares " +
                        "them, the page title and headings. Other browsers, other apps, in-app web views and the text inside " +
                        "pages are not checked.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                )
            }
        }
    }

    editing?.let { old ->
        val rule = state.rules.firstOrNull { it.word == old }
        if (rule == null) editing = null
        else EditKeywordDialog(
            word = rule.word,
            partial = rule.partial,
            onSave = { raw, partial -> actions.onEdit(old, raw, partial) },
            onDismiss = { editing = null },
        )
    }
}

@Composable
private fun EditKeywordDialog(
    word: String,
    partial: Boolean,
    onSave: (String, Boolean) -> KeywordRules.Result,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var text by remember { mutableStateOf(word) }
    var inside by remember { mutableStateOf(partial) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Edit keyword", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(KeywordRules.MAX_LENGTH + 10); error = null },
                    singleLine = true,
                    isError = error != null,
                )
                if (error != null) {
                    Text(error!!, style = MaterialTheme.typography.bodySmall, color = c.warning, modifier = Modifier.padding(top = 4.dp))
                }
                Spacer(Modifier.height(12.dp))
                SwitchLine(
                    title = "Also match inside words",
                    note = "\"porn\" would also close \"pornhub\"",
                    checked = inside,
                    enabled = true,
                    onChange = { inside = it }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when (onSave(text, inside)) {
                    KeywordRules.Result.OK -> onDismiss()
                    KeywordRules.Result.INVALID -> error = "Use 2 to ${KeywordRules.MAX_LENGTH} characters with letters or numbers"
                    KeywordRules.Result.ALREADY_THERE -> error = "This keyword is already in the list"
                    KeywordRules.Result.FULL -> error = "Too many keywords"
                    KeywordRules.Result.LOCKED -> error = "Changes are locked right now"
                }
            }) { Text("Save", color = c.accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}
