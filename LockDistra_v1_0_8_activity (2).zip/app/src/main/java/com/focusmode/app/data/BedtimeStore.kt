package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Calendar

/**
 * Saved Bedtime Mode settings, in device-protected storage like the other stores so the schedule
 * is readable right after a restart. Separate file ("bedtime"): it shares nothing with the focus
 * session, limits or website rules.
 */
class BedtimeStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "bedtime")

    private val _state = MutableStateFlow(read())
    val state: StateFlow<BedtimeState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _state.value = read()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun current(): BedtimeState = read()

    private fun read() = BedtimeState(
        enabled = prefs.getBoolean(K_ENABLED, false),
        startMin = BedtimeRules.clamp(prefs.getInt(K_START, BedtimeRules.DEFAULT_START)),
        endMin = BedtimeRules.clamp(prefs.getInt(K_END, BedtimeRules.DEFAULT_END)),
        apps = prefs.getStringSet(K_APPS, null)?.toSet() ?: emptySet(),
    )

    @Synchronized
    fun update(change: (BedtimeState) -> BedtimeState): BedtimeState {
        val next = change(read())
        prefs.edit()
            .putBoolean(K_ENABLED, next.enabled)
            .putInt(K_START, BedtimeRules.clamp(next.startMin))
            .putInt(K_END, BedtimeRules.clamp(next.endMin))
            // A fresh set: SharedPreferences must never be handed the set it already holds.
            .putStringSet(K_APPS, HashSet(next.apps))
            .commit()
        return next
    }

    /** True when the app is blocked by Bedtime Mode right now. Cheap: no disk access. */
    fun blocks(pkg: String, now: Long = System.currentTimeMillis()): Boolean =
        BedtimeRules.blocks(_state.value, pkg, minuteOfDay(now))

    /** True while the window is open and at least one app is selected. */
    fun isActive(now: Long = System.currentTimeMillis()): Boolean =
        BedtimeRules.active(_state.value, minuteOfDay(now))

    companion object {
        private const val K_ENABLED = "enabled"
        private const val K_START = "start_min"
        private const val K_END = "end_min"
        private const val K_APPS = "apps"

        @Volatile
        private var instance: BedtimeStore? = null

        fun get(context: Context): BedtimeStore =
            instance ?: synchronized(this) {
                instance ?: BedtimeStore(context.applicationContext).also { instance = it }
            }

        /** Local minutes after midnight for [ms] (follows the phone's time zone and date). */
        fun minuteOfDay(ms: Long): Int {
            val c = Calendar.getInstance().apply { timeInMillis = ms }
            return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        }

        fun msIntoMinute(ms: Long): Long {
            val c = Calendar.getInstance().apply { timeInMillis = ms }
            return c.get(Calendar.SECOND) * 1_000L + c.get(Calendar.MILLISECOND)
        }
    }
}
