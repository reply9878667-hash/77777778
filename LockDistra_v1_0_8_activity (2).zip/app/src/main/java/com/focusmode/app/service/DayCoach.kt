package com.focusmode.app.service

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focusmode.app.MainActivity
import com.focusmode.app.R
import com.focusmode.app.data.CoachEvent
import com.focusmode.app.data.CoachEventType
import com.focusmode.app.data.CoachMessage
import com.focusmode.app.data.CoachMessages
import com.focusmode.app.data.DayCoachRules
import com.focusmode.app.data.DayCoachStore
import com.focusmode.app.data.IntentGuard
import com.focusmode.app.data.Storage
import com.focusmode.app.data.TaskStore

/**
 * Day Coach: says good morning at the day start, tells the first task of the list 5 minutes later, reminds about
 * tomorrow's tasks 15 minutes before sleep and says good night at the sleep time. It works with the app closed:
 *  1. one exact alarm is always set for the next thing the coach has to do (it survives the app being closed),
 *  2. the Accessibility service calls [poll] every few seconds as a second chance,
 *  3. a restart, an app update or a clock / time-zone change sets the alarm again ([DayCoachReceiver]).
 * All of them go through [process], which does every due event exactly once (the done events are remembered).
 * What happens when is decided by [DayCoachRules.events]; this file only does it (messages, alarm).
 *
 * The messages are notifications: they show when the app is closed and as a banner over the app while it is open.
 * The coach never blocks anything.
 */
object DayCoachEngine {

    private const val REQ_TICK = 7401
    private const val PREFS = "daycoach_runtime"
    private const val K_HANDLED = "handled"

    const val CH_COACH = "daycoach_v1"
    private const val CH_OLD_NAG = "daycoach_nag_v1"
    private const val ID_MORNING = 7415
    private const val ID_TASK = 7412
    private const val ID_NIGHT = 7413

    private const val CUSHION_MS = 500L

    // ---- Doing things -------------------------------------------------------------------------------------------

    /** Does every event that is due and not done yet. Returns true when it did something. Safe to call often. */
    @Synchronized
    fun process(context: Context, now: Long = System.currentTimeMillis()): Boolean {
        val app = context.applicationContext
        val st = DayCoachStore.get(app).current()
        if (!st.enabled) return false
        val today = DayCoachRules.dayKey(now)
        val prefs = Storage.prefs(app, PREFS)
        val handled = prefs.getStringSet(K_HANDLED, null)?.toMutableSet() ?: mutableSetOf()
        val due = DayCoachRules.due(DayCoachRules.events(st, today), handled, now)
        if (due.isEmpty()) return false
        // Marked before it is done: an event that crashes can never repeat in a loop.
        handled.addAll(due.map { it.key })
        prefs.edit().putStringSet(K_HANDLED, HashSet(DayCoachRules.pruneHandled(handled, today))).commit()
        for (e in due) runCatching { execute(app, e, now) }
        return true
    }

    /** Called often by the Accessibility service: does what is due and moves the alarm on when something happened. */
    fun poll(context: Context) {
        if (process(context)) sync(context)
    }

    /** [process], then the alarm for what comes next. Used by the alarm, restarts and time changes. */
    fun tick(context: Context) {
        process(context)
        sync(context)
    }

    private fun execute(app: Context, e: CoachEvent, now: Long) {
        val st = DayCoachStore.get(app).current()
        val tasks = TaskStore.get(app).also { it.refreshDate(now) }.state.value
        when (e.type) {
            // "Good morning, 5 minutes to get fresh" is pointless when the phone woke up late (the first-task message follows at once).
            CoachEventType.DAY_START ->
                if (now - e.at < DayCoachRules.FRESH_UP_MIN * 60_000L) post(app, ID_MORNING, CoachMessages.goodMorning())
            CoachEventType.FIRST_TASK ->
                post(app, ID_TASK, CoachMessages.firstTask(DayCoachRules.firstTask(tasks)))
            CoachEventType.PLAN_REMINDER ->
                post(app, ID_NIGHT, CoachMessages.planReminder(DayCoachRules.tomorrowCount(tasks)))
            // Replaces the reminder, so the last thing on the screen at night is "Good night".
            CoachEventType.GOOD_NIGHT ->
                post(app, ID_NIGHT, CoachMessages.goodNight(st.dayStartMin))
        }
    }

    // ---- Changes made in the app --------------------------------------------------------------------------------

    /**
     * Marks events that are already in the past as done, so switching the coach on or changing a time never fires a
     * pile of old messages.
     */
    @Synchronized
    fun baseline(context: Context, graceMs: Long = 60_000L) {
        val app = context.applicationContext
        val st = DayCoachStore.get(app).current()
        val now = System.currentTimeMillis()
        val today = DayCoachRules.dayKey(now)
        val prefs = Storage.prefs(app, PREFS)
        val handled = prefs.getStringSet(K_HANDLED, null)?.toMutableSet() ?: mutableSetOf()
        DayCoachRules.events(st, today)
            .filter { it.at < now - graceMs }
            .forEach { handled += it.key }
        prefs.edit().putStringSet(K_HANDLED, HashSet(DayCoachRules.pruneHandled(handled, today))).commit()
    }

    fun onEnabled(context: Context) {
        baseline(context)
        sync(context)
    }

    fun onSettingsChanged(context: Context) {
        baseline(context)
        sync(context)
    }

    // ---- The alarm ----------------------------------------------------------------------------------------------

    /** Sets the alarm for the next event (or removes it when the coach is off). One fixed id: never duplicates. */
    @Synchronized
    fun sync(context: Context) {
        val app = context.applicationContext
        val st = DayCoachStore.get(app).current()
        if (!st.enabled) {
            cancelAlarm(app)
            return
        }
        val now = System.currentTimeMillis()
        val handled = Storage.prefs(app, PREFS).getStringSet(K_HANDLED, null) ?: emptySet()
        val next = DayCoachRules.nextAt(DayCoachRules.events(st, DayCoachRules.dayKey(now)), handled, now)
        arm(app, (next ?: (now + 6 * 60 * 60_000L)) + CUSHION_MS)
    }

    private fun arm(context: Context, at: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = tickIntent(context)
        try {
            // Exact when the person allows "Alarms & reminders"; otherwise Android may be a few minutes late.
            if (FocusEngine.canScheduleExact(context)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancelAlarm(context: Context) {
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickIntent(context))
    }

    private fun tickIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQ_TICK,
            Intent(context, DayCoachReceiver::class.java).setAction(DayCoachReceiver.ACTION_TICK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    // ---- Notifications ------------------------------------------------------------------------------------------

    private fun ensureChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_COACH, "Day Coach", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Good morning, your first task, the reminder to set tomorrow's tasks, and good night."
                setShowBadge(false)
            }
        )
        // The old "plan reminders" channel is not used any more.
        nm.deleteNotificationChannel(CH_OLD_NAG)
    }

    @SuppressLint("MissingPermission")
    private fun post(context: Context, id: Int, msg: CoachMessage) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        ensureChannels(context)
        val open = PendingIntent.getActivity(
            context, 7410,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(context)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(context, CH_COACH)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(msg.title)
            .setContentText(msg.text.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(msg.text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
        nmc.notify(id, b.build())
    }
}

/**
 * Wakes the Day Coach: its own alarm, a restart, an app update, and a change of the phone's time or time zone. It only
 * ever runs [DayCoachEngine], which decides from the saved times and the clock, so a broadcast sent by another app can
 * not make the coach do anything it would not.
 */
class DayCoachReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        DayCoachEngine.tick(context)
    }

    companion object {
        const val ACTION_TICK = "com.focusmode.app.action.DAY_COACH_TICK"
    }
}
