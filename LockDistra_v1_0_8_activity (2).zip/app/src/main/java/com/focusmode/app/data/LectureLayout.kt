package com.focusmode.app.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** What the lecture screen (portrait, LockDistra's own player) should show: the video's height and whether the timer/plant strip fits under it. */
data class LecturePlan(val videoHeight: Int, val showPanel: Boolean)

/**
 * Decides the portrait layout of the lecture screen from the video's real shape.
 * The video keeps its own ratio (never cropped or stretched); the Focus timer / plant strip is shown only when at least
 * [minPanel] pixels are left under it, otherwise it is hidden and the video gets the whole free height.
 */
object LectureLayout {
    const val DEFAULT_RATIO = 16f / 9f
    private const val MIN_RATIO = 0.4f
    private const val MAX_RATIO = 2.6f

    fun clampRatio(r: Float): Float = if (r.isNaN() || r <= 0f) DEFAULT_RATIO else r.coerceIn(MIN_RATIO, MAX_RATIO)

    /** [available] = free height under the top bar (px), [width] = screen width (px). available <= 0 means "not measured yet". */
    fun plan(available: Int, width: Int, ratio: Float, minPanel: Int): LecturePlan {
        val wanted = (width / clampRatio(ratio)).toInt()
        if (available <= 0) return LecturePlan(wanted, true)
        return if (available - wanted >= minPanel) LecturePlan(wanted, true)
        else LecturePlan(available, false)
    }
}

/** Finds a YouTube video's shape (width / height) so it can be shown in its own ratio. */
object VideoRatio {
    /** Reads "width" and "height" of a YouTube oEmbed answer; null when it has no usable size. */
    fun parseOEmbed(json: String): Float? = try {
        val o = JSONObject(json)
        val w = o.optDouble("width", 0.0)
        val h = o.optDouble("height", 0.0)
        if (w > 0 && h > 0) LectureLayout.clampRatio((w / h).toFloat()) else null
    } catch (e: Exception) {
        null
    }

    private const val PORTRAIT = 9f / 16f

    /**
     * The shape a link tells by itself, with no network: Shorts / Reels style links are always vertical (9:16).
     * Null when the link says nothing (the real shape is then looked up).
     */
    fun fromLink(url: String): Float? {
        val u = url.lowercase().substringBefore('#')
        val host = u.substringAfter("://").substringBefore('/').substringBefore('?').removePrefix("www.")
        val path = "/" + u.substringAfter("://").substringAfter('/', "").substringBefore('?')
        val vertical = when {
            host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com") -> path.startsWith("/shorts/")
            host.endsWith("instagram.com") -> path.startsWith("/reel/") || path.startsWith("/reels/")
            host.endsWith("facebook.com") || host == "fb.watch" -> path.startsWith("/reel/") || path.startsWith("/reels/")
            else -> false
        }
        return if (vertical) PORTRAIT else null
    }

    /** Network call: run it off the main thread. Null when it fails (the caller then keeps 16:9). */
    fun fetchYoutube(videoId: String): Float? = try {
        val watch = URLEncoder.encode("https://www.youtube.com/watch?v=$videoId", "UTF-8")
        val c = URL("https://www.youtube.com/oembed?format=json&url=$watch").openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 6000
        try {
            if (c.responseCode == 200) parseOEmbed(c.inputStream.bufferedReader().readText()) else null
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }
}
