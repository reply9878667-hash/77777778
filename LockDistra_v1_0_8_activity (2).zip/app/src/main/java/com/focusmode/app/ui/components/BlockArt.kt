package com.focusmode.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.ui.theme.FocusTheme

/*
 * Look of the block screen ("Daily Limit Reached!", "Site Blocked!", ...): a drawn illustration (a sad kid next to a
 * chained phone with a padlock), a title bar, a "Daily Limit / Used Today" card, a tip card and the buttons.
 * Everything is drawn in code from SVG path data, so there are no image files and it stays sharp on every screen.
 */

/** Colours of the block screen, light (like the design) and a dark version for the app's dark theme. */
internal class BlockPalette(val dark: Boolean) {
    val bgTop = if (dark) Color(0xFF0D0820) else Color(0xFFFFFFFF)
    val bgBottom = if (dark) Color(0xFF1B1140) else Color(0xFFEEE8FC)
    val card = if (dark) Color(0xFF1A1240) else Color(0xFFF1ECFE)
    val cardStroke = if (dark) Color(0xFF3B2B73) else Color(0xFFDCD3F8)
    val title = if (dark) Color(0xFFFFFFFF) else Color(0xFF16114A)
    val body = if (dark) Color(0xFFC9C1E8) else Color(0xFF2E2A5E)
    val purple = if (dark) Color(0xFFC77DFF) else Color(0xFF7A1FD4)
    val divider = if (dark) Color(0xFF3B2B73) else Color(0xFFC9BEF0)
    val warn = Color(0xFFFFC107)
}

internal class ArtShape(
    val d: String,
    /** Colour (ARGB Long), a palette token name (String) or null. */
    val fill: Any?,
    val stroke: Long?,
    val strokeWidth: Float,
    val alpha: Float,
    /** degrees, pivot x, pivot y */
    val rot: FloatArray?,
)

private const val ART_W = 400f
private const val ART_H = 262f

private val ART_SHAPES: List<ArtShape> = listOf(
        ArtShape("M38,128 C28,62 92,30 150,40 C196,18 300,14 352,50 C396,82 392,152 372,192 C354,236 300,252 200,254 C110,256 48,232 38,128 Z", "blob", null, 0f, 1.0f, null),
        ArtShape("M22,254 C4,206 18,152 46,128 C58,172 52,218 22,254 Z", 0xFFA99CF4L, null, 0f, 1.0f, null),
        ArtShape("M48,254 C42,218 56,192 80,180 C84,208 72,238 48,254 Z", 0xFF8E80EAL, null, 0f, 1.0f, null),
        ArtShape("M378,254 C396,208 384,166 356,142 C346,186 352,226 378,254 Z", 0xFFA99CF4L, null, 0f, 1.0f, null),
        ArtShape("M352,254 C358,222 346,196 322,184 C318,212 330,240 352,254 Z", 0xFF8E80EAL, null, 0f, 1.0f, null),
        ArtShape("M146,26 L158,42", null, 0xFF4F46E5L, 8f, 1.0f, null),
        ArtShape("M134,50 L156,56", null, 0xFF4F46E5L, 8f, 1.0f, null),
        ArtShape("M348,62 L366,52", null, 0xFF4F46E5L, 8f, 1.0f, null),
        ArtShape("M350,92 L378,84", null, 0xFF4F46E5L, 8f, 1.0f, null),
        ArtShape("M50.00,254.00 A62,6 0 1 1 174.00,254.00 A62,6 0 1 1 50.00,254.00 Z", 0xFF6B58C8L, null, 0f, 0.18f, null),
        ArtShape("M194,22 H298 A26,26 0 0 1 324,48 V228 A26,26 0 0 1 298,254 H194 A26,26 0 0 1 168,228 V48 A26,26 0 0 1 194,22 Z", "phoneBody", 0xFF4A3C9CL, 3f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M195,31 H297 A18,18 0 0 1 315,49 V227 A18,18 0 0 1 297,245 H195 A18,18 0 0 1 177,227 V49 A18,18 0 0 1 195,31 Z", 0xFFF7F5FFL, null, 0f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M226.5,34 H265.5 A4.5,4.5 0 0 1 270,38.5 V38.5 A4.5,4.5 0 0 1 265.5,43 H226.5 A4.5,4.5 0 0 1 222,38.5 V38.5 A4.5,4.5 0 0 1 226.5,34 Z", 0xFF2B2853L, null, 0f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M208.00,98.00 A38,38 0 1 1 284.00,98.00 A38,38 0 1 1 208.00,98.00 Z", 0xFFFFFFFFL, 0xFFE53935L, 9f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M233,79 L266,98 L233,117 Z", 0xFF26224AL, 0xFF26224AL, 5f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M220,72 L272,124", null, 0xFFE53935L, 9f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M193,152 H255 A4,4 0 0 1 259,156 V156 A4,4 0 0 1 255,160 H193 A4,4 0 0 1 189,156 V156 A4,4 0 0 1 193,152 Z", 0xFFDCD6F2L, null, 0f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M193,168 H281 A4,4 0 0 1 285,172 V172 A4,4 0 0 1 281,176 H193 A4,4 0 0 1 189,172 V172 A4,4 0 0 1 193,168 Z", 0xFFE6E1F6L, null, 0f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M193,184 H247 A4,4 0 0 1 251,188 V188 A4,4 0 0 1 247,192 H193 A4,4 0 0 1 189,188 V188 A4,4 0 0 1 193,184 Z", 0xFFDCD6F2L, null, 0f, 1.0f, floatArrayOf(3f, 246f, 140f)),
        ArtShape("M142.52,110.15 A9.5,5.6 38.04704253182609 1 1 157.48,121.85 A9.5,5.6 38.04704253182609 1 1 142.52,110.15 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M142.52,109.35 A9.5,5.6 38.04704253182609 1 1 157.48,121.05 A9.5,5.6 38.04704253182609 1 1 142.52,109.35 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M157.04,121.49 A5.5,4.6 37.522669693339196 1 1 165.77,128.19 A5.5,4.6 37.522669693339196 1 1 157.04,121.49 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M165.04,127.66 A9.5,5.6 36.97276248956805 1 1 180.21,139.09 A9.5,5.6 36.97276248956805 1 1 165.04,127.66 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M165.04,126.86 A9.5,5.6 36.97276248956805 1 1 180.21,138.29 A9.5,5.6 36.97276248956805 1 1 165.04,126.86 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M179.23,138.33 A5.5,4.6 36.39551840690735 1 1 188.08,144.86 A5.5,4.6 36.39551840690735 1 1 179.23,138.33 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M186.79,143.94 A9.5,5.6 35.78897345918333 1 1 202.21,155.06 A9.5,5.6 35.78897345918333 1 1 186.79,143.94 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M186.79,143.14 A9.5,5.6 35.78897345918333 1 1 202.21,154.26 A9.5,5.6 35.78897345918333 1 1 186.79,143.14 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M200.66,153.93 A5.5,4.6 35.15098548888297 1 1 209.65,160.26 A5.5,4.6 35.15098548888297 1 1 200.66,153.93 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M207.79,159.00 A9.5,5.6 34.47921568612564 1 1 223.46,169.75 A9.5,5.6 34.47921568612564 1 1 207.79,159.00 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M207.79,158.20 A9.5,5.6 34.47921568612564 1 1 223.46,168.95 A9.5,5.6 34.47921568612564 1 1 207.79,158.20 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M221.33,168.29 A5.5,4.6 33.77110817846126 1 1 230.48,174.40 A5.5,4.6 33.77110817846126 1 1 221.33,168.29 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M228.03,172.82 A9.5,5.6 33.02386755579665 1 1 243.97,183.18 A9.5,5.6 33.02386755579665 1 1 228.03,172.82 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M228.03,172.02 A9.5,5.6 33.02386755579665 1 1 243.97,182.38 A9.5,5.6 33.02386755579665 1 1 228.03,172.02 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M253.21,181.60 A9.5,5.6 -22.249023657212366 1 1 270.79,174.40 A9.5,5.6 -22.249023657212366 1 1 253.21,181.60 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M253.21,180.80 A9.5,5.6 -22.249023657212366 1 1 270.79,173.60 A9.5,5.6 -22.249023657212366 1 1 253.21,180.80 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M267.95,175.51 A5.5,4.6 -27.89727103094763 1 1 277.67,170.36 A5.5,4.6 -27.89727103094763 1 1 267.95,175.51 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M275.32,171.97 A9.5,5.6 -33.36636600105956 1 1 291.18,161.53 A9.5,5.6 -33.36636600105956 1 1 275.32,171.97 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M275.32,171.17 A9.5,5.6 -33.36636600105956 1 1 291.18,160.73 A9.5,5.6 -33.36636600105956 1 1 275.32,171.17 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M289.01,162.87 A5.5,4.6 -38.571252251170144 1 1 297.61,156.01 A5.5,4.6 -38.571252251170144 1 1 289.01,162.87 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M296.10,157.53 A9.5,5.6 -43.45184230102203 1 1 309.90,144.47 A9.5,5.6 -43.45184230102203 1 1 296.10,157.53 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M296.10,156.73 A9.5,5.6 -43.45184230102203 1 1 309.90,143.67 A9.5,5.6 -43.45184230102203 1 1 296.10,156.73 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M308.63,145.52 A5.5,4.6 -47.97373108248011 1 1 315.99,137.35 A5.5,4.6 -47.97373108248011 1 1 308.63,145.52 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M315.42,138.25 A9.5,5.6 -52.1250163489018 1 1 327.08,123.25 A9.5,5.6 -52.1250163489018 1 1 315.42,138.25 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M315.42,137.45 A9.5,5.6 -52.1250163489018 1 1 327.08,122.45 A9.5,5.6 -52.1250163489018 1 1 315.42,137.45 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M326.73,123.49 A5.5,4.6 -55.91112838428339 1 1 332.90,114.38 A5.5,4.6 -55.91112838428339 1 1 326.73,123.49 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M333.16,114.17 A9.5,5.6 -59.34933204294713 1 1 342.84,97.83 A9.5,5.6 -59.34933204294713 1 1 333.16,114.17 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M333.16,113.37 A9.5,5.6 -59.34933204294713 1 1 342.84,97.03 A9.5,5.6 -59.34933204294713 1 1 333.16,113.37 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M144.25,136.51 A9.5,5.6 35.3112134396332 1 1 159.75,147.49 A9.5,5.6 35.3112134396332 1 1 144.25,136.51 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M144.25,135.71 A9.5,5.6 35.3112134396332 1 1 159.75,146.69 A9.5,5.6 35.3112134396332 1 1 144.25,135.71 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M160.94,148.25 A5.5,4.6 33.77110817846126 1 1 170.08,154.36 A5.5,4.6 33.77110817846126 1 1 160.94,148.25 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M170.56,154.75 A9.5,5.6 32.07052903505634 1 1 186.66,164.84 A9.5,5.6 32.07052903505634 1 1 170.56,154.75 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M170.56,153.95 A9.5,5.6 32.07052903505634 1 1 186.66,164.04 A9.5,5.6 32.07052903505634 1 1 170.56,153.95 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M186.55,164.70 A5.5,4.6 30.186535881195333 1 1 196.06,170.23 A5.5,4.6 30.186535881195333 1 1 186.55,164.70 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M195.21,169.85 A9.5,5.6 28.09257661929092 1 1 211.97,178.80 A9.5,5.6 28.09257661929092 1 1 195.21,169.85 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M195.21,169.05 A9.5,5.6 28.09257661929092 1 1 211.97,178.00 A9.5,5.6 28.09257661929092 1 1 195.21,169.05 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M210.52,177.98 A5.5,4.6 25.75812172197562 1 1 220.42,182.76 A5.5,4.6 25.75812172197562 1 1 210.52,177.98 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M218.20,181.86 A9.5,5.6 23.148462985306647 1 1 235.67,189.33 A9.5,5.6 23.148462985306647 1 1 218.20,181.86 Z", null, 0xFF6E7385L, 3.6f, 1.0f, null),
        ArtShape("M218.20,181.06 A9.5,5.6 23.148462985306647 1 1 235.67,188.53 A9.5,5.6 23.148462985306647 1 1 218.20,181.06 Z", null, 0xFFB9BDCAL, 1.4f, 1.0f, null),
        ArtShape("M232.84,188.10 A5.5,4.6 20.224859431168078 1 1 243.16,191.90 A5.5,4.6 20.224859431168078 1 1 232.84,188.10 Z", 0xFF8B90A0L, 0xFF6E7385L, 2.2f, 1.0f, null),
        ArtShape("M225,182 C225,148 273,148 273,182", null, 0xFF9EA3B3L, 13f, 1.0f, null),
        ArtShape("M225,182 C225,152 273,152 273,182", null, 0xFFD7DAE4L, 4f, 1.0f, null),
        ArtShape("M236,238 L250,258 L264,238 Z", 0xFF5632CBL, null, 0f, 1.0f, null),
        ArtShape("M221,174 H277 A17,17 0 0 1 294,191 V225 A17,17 0 0 1 277,242 H221 A17,17 0 0 1 204,225 V191 A17,17 0 0 1 221,174 Z", "lockBody", 0xFF4B2AB8L, 2f, 1.0f, null),
        ArtShape("M249,183 L272,191 L272,210 C272,222 262,230 249,236 C236,230 226,222 226,210 L226,191 Z", 0xFFFFFFFFL, null, 0f, 1.0f, null),
        ArtShape("M238,208 L246,216 L260,200", null, 0xFF5A32D0L, 6f, 1.0f, null),
        ArtShape("M70,240 C68,222 90,214 116,214 C142,214 166,222 166,240 C166,250 150,254 118,254 C88,254 72,250 70,240 Z", 0xFF2E2F3FL, null, 0f, 1.0f, null),
        ArtShape("M58.19,244.78 A20,12 -8 1 1 97.81,239.22 A20,12 -8 1 1 58.19,244.78 Z", 0xFFF4F4F9L, 0xFFCFCFDBL, 1.5f, 1.0f, null),
        ArtShape("M114.10,242.12 A18,10 6 1 1 149.90,245.88 A18,10 6 1 1 114.10,242.12 Z", 0xFFDADAE6L, 0xFFBDBDCCL, 1.5f, 1.0f, null),
        ArtShape("M74,166 C76,148 92,144 108,144 C130,144 148,150 154,168 L158,218 C142,228 94,228 76,218 Z", "hoodie", null, 0f, 1.0f, null),
        ArtShape("M90,146 C98,164 120,164 128,146 Z", 0xFF3F25B5L, null, 0f, 1.0f, null),
        ArtShape("M82,174 C88,198 122,206 148,194", null, 0xFF5A3DE2L, 19f, 1.0f, null),
        ArtShape("M150,172 C148,194 112,208 84,198", null, 0xFF4A2FD0L, 17f, 1.0f, null),
        ArtShape("M139.50,195.00 A6.5,6.5 0 1 1 152.50,195.00 A6.5,6.5 0 1 1 139.50,195.00 Z", 0xFFFFD9B8L, null, 0f, 1.0f, null),
        ArtShape("M79.50,198.00 A6.5,6.5 0 1 1 92.50,198.00 A6.5,6.5 0 1 1 79.50,198.00 Z", 0xFFFFD9B8L, null, 0f, 1.0f, null),
        ArtShape("M56.50,134.00 A7.5,7.5 0 1 1 71.50,134.00 A7.5,7.5 0 1 1 56.50,134.00 Z", 0xFFFFD3B0L, null, 0f, 1.0f, null),
        ArtShape("M138.50,134.00 A7.5,7.5 0 1 1 153.50,134.00 A7.5,7.5 0 1 1 138.50,134.00 Z", 0xFFFFD3B0L, null, 0f, 1.0f, null),
        ArtShape("M65.00,128.00 A40,39 0 1 1 145.00,128.00 A40,39 0 1 1 65.00,128.00 Z", 0xFFFFDDBEL, null, 0f, 1.0f, null),
        ArtShape("M60,124 C54,98 70,78 94,75 C102,68 122,68 128,76 C146,78 156,100 148,124 C144,110 136,102 126,99 C116,110 94,110 80,101 C72,104 64,112 60,124 Z", 0xFF8A4B2AL, null, 0f, 1.0f, null),
        ArtShape("M72,88 C62,82 64,70 76,70 C80,76 80,84 78,90 Z", 0xFF8A4B2AL, null, 0f, 1.0f, null),
        ArtShape("M118,74 C124,64 138,66 140,76 C134,78 126,78 118,74 Z", 0xFF8A4B2AL, null, 0f, 1.0f, null),
        ArtShape("M90,84 C98,78 108,78 114,82", null, 0xFFB76A3BL, 3f, 1.0f, null),
        ArtShape("M126,88 C134,90 140,96 142,104", null, 0xFFB76A3BL, 3f, 1.0f, null),
        ArtShape("M84,121 L97,118", null, 0xFF6B3A22L, 2.2f, 1.0f, null),
        ArtShape("M126,121 L113,118", null, 0xFF6B3A22L, 2.2f, 1.0f, null),
        ArtShape("M85,130 Q91,137 98,130", null, 0xFF4A2E26L, 2.8f, 1.0f, null),
        ArtShape("M112,130 Q119,137 125,130", null, 0xFF4A2E26L, 2.8f, 1.0f, null),
        ArtShape("M98,150 Q105,144 112,150", null, 0xFFB5524AL, 2.6f, 1.0f, null),
        ArtShape("M78.00,142.00 A6,3.5 0 1 1 90.00,142.00 A6,3.5 0 1 1 78.00,142.00 Z", 0xFFFF9E8FL, null, 0f, 0.55f, null),
        ArtShape("M120.00,142.00 A6,3.5 0 1 1 132.00,142.00 A6,3.5 0 1 1 120.00,142.00 Z", 0xFFFF9E8FL, null, 0f, 0.55f, null),
)

private fun token(name: String, dark: Boolean): Any = when (name) {
    "blob" -> if (dark) Color(0x403F2A8A) else Color(0xFFEDE7FC)
    "phoneBody" -> listOf(Color(0xFF7C68D8), Color(0xFF574AB3)) to (22f to 254f)
    "lockBody" -> listOf(Color(0xFF7E5BF6), Color(0xFF5430C9)) to (174f to 242f)
    "hoodie" -> listOf(Color(0xFF5B3AE6), Color(0xFF3B22B8)) to (144f to 226f)
    else -> Color.Transparent
}

/** The picture at the top of the block screen. It floats up and down very slightly. */
@Composable
internal fun BlockIllustration(modifier: Modifier = Modifier) {
    val dark = FocusTheme.colors.isDark
    val paths = remember { ART_SHAPES.map { PathParser().parsePathString(it.d).toPath() } }
    val float by rememberInfiniteTransition(label = "blockArt").animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "blockArtFloat"
    )
    Canvas(
        modifier
            .fillMaxWidth()
            .aspectRatio(ART_W / ART_H)
            .graphicsLayer { translationY = float.dp.toPx() }
    ) {
        val k = size.width / ART_W
        withTransform({ scale(k, k, Offset.Zero) }) {
            ART_SHAPES.forEachIndexed { i, s ->
                val draw: androidx.compose.ui.graphics.drawscope.DrawScope.() -> Unit = {
                    val raw = s.fill
                    val fill = if (raw is String) token(raw, dark) else raw
                    when (fill) {
                        is Long -> drawPath(paths[i], Color(fill), alpha = s.alpha)
                        is Color -> drawPath(paths[i], fill, alpha = s.alpha)
                        is Pair<*, *> -> {
                            @Suppress("UNCHECKED_CAST")
                            val g = fill as Pair<List<Color>, Pair<Float, Float>>
                            drawPath(
                                paths[i],
                                Brush.verticalGradient(g.first, startY = g.second.first, endY = g.second.second),
                                alpha = s.alpha
                            )
                        }
                    }
                    val st = s.stroke
                    if (st != null) {
                        drawPath(
                            paths[i],
                            Color(st),
                            alpha = s.alpha,
                            style = Stroke(s.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }
                }
                val r = s.rot
                if (r == null) draw() else rotate(r[0], Offset(r[1], r[2])) { draw() }
            }
        }
    }
}

/** Vertical wash behind the whole screen. */
internal fun blockBackground(p: BlockPalette): Brush = Brush.verticalGradient(listOf(p.bgTop, p.bgBottom))

/** Title in a rounded bar: every word in the dark colour, the last word in purple ("Daily Limit Reached!"). */
@Composable
internal fun BlockTitleBar(text: String, p: BlockPalette, modifier: Modifier = Modifier) {
    val cut = text.trimEnd().lastIndexOf(' ')
    val styled: AnnotatedString = buildAnnotatedString {
        if (cut < 0) {
            withStyle(SpanStyle(color = p.purple)) { append(text) }
        } else {
            withStyle(SpanStyle(color = p.title)) { append(text.substring(0, cut + 1)) }
            withStyle(SpanStyle(color = p.purple)) { append(text.substring(cut + 1)) }
        }
    }
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(p.card)
            .padding(horizontal = 12.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            styled,
            style = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, letterSpacing = (-0.5).sp),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun BlockCardShell(p: BlockPalette, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(p.card)
            .border(1.dp, p.cardStroke, RoundedCornerShape(22.dp))
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) { content() }
}

/** Clock | Daily Limit | Used Today. */
@Composable
internal fun BlockUsageCard(limitText: String, usedText: String, p: BlockPalette, modifier: Modifier = Modifier) {
    BlockCardShell(p, modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Schedule, null, tint = p.purple, modifier = Modifier.size(46.dp))
            Spacer(Modifier.width(14.dp))
            Box(Modifier.width(1.5.dp).height(52.dp).background(p.divider))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Daily Limit", style = MaterialTheme.typography.bodyMedium, color = p.body)
                Text(limitText, style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp), color = p.title)
            }
            Box(Modifier.width(1.5.dp).height(52.dp).background(p.divider))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Used Today", style = MaterialTheme.typography.bodyMedium, color = p.body)
                Text(usedText, style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp), color = p.purple)
            }
        }
    }
}

/** Clock | label | big value (countdowns: "Unlocks tomorrow in", "Bedtime ends in", "Focus session remaining"). */
@Composable
internal fun BlockTimeCard(
    label: String,
    value: String,
    progress: Float?,
    p: BlockPalette,
    modifier: Modifier = Modifier,
) {
    BlockCardShell(p, modifier) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Schedule, null, tint = p.purple, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(14.dp))
                Box(Modifier.width(1.5.dp).height(46.dp).background(p.divider))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.bodyMedium, color = p.body)
                    Text(
                        value,
                        style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 26.sp, fontFeatureSettings = "tnum"),
                        color = p.purple
                    )
                }
            }
            if (progress != null) {
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(p.cardStroke)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(progress.coerceIn(0f, 1f))
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(p.purple)
                    )
                }
            }
        }
    }
}

/** Lightbulb | "Take a Break!" + one line. */
@Composable
internal fun BlockTipCard(
    title: String,
    text: String,
    p: BlockPalette,
    modifier: Modifier = Modifier,
    /** Replaces the lightbulb (the focus screens show the plant here). */
    leading: (@Composable () -> Unit)? = null,
) {
    BlockCardShell(p, modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (leading != null) Box(Modifier.size(52.dp)) { leading() }
            else Icon(Icons.Rounded.Lightbulb, null, tint = Color(0xFFFFC21A), modifier = Modifier.size(44.dp))
            Spacer(Modifier.width(14.dp))
            Box(Modifier.width(1.5.dp).height(52.dp).background(p.divider))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = TextStyle(fontWeight = FontWeight.ExtraBold, fontSize = 19.sp), color = p.purple)
                Text(text, style = MaterialTheme.typography.bodyMedium, color = p.body)
            }
        }
    }
}
