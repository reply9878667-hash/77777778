package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * What a Focus Profile blocks and limits. The same kinds of settings the Blocking screen edits for the
 * whole phone, but kept per profile. While a focus session runs, the selected profile's settings are what the
 * blockers use (see [FocusProfileRuntime]); nothing here ever changes the global settings.
 */
data class FocusProfileSettings(
    /** Blocked apps and games (a game is an ordinary app in the list). */
    val blocked: Set<String> = emptySet(),
    /** YouTube Shorts. */
    val blockShorts: Boolean = false,
    /** Section blocks of other apps (Instagram Reels, WhatsApp Status ...), by [FeatureCatalog] id. */
    val features: Set<String> = emptySet(),
    /** Website blocking, in the same shape as the global one. */
    val websites: WebsiteState = WebsiteState(),
    /** Daily limit of individual apps. */
    val limits: List<AppLimit> = emptyList(),
    /** Emergency access chosen in each limit's editor (key = package). */
    val limitEmergency: Map<String, EmergencyDraft> = emptyMap(),
) {
    val siteCount: Int get() = websites.enabledApps.sumOf { app -> websites.rulesFor(app).count { it.enabled } }
    val isEmpty: Boolean
        get() = blocked.isEmpty() && !blockShorts && features.isEmpty() && siteCount == 0 && limits.isEmpty()

    /** One line for the profile screen, e.g. "3 apps/games - 2 sites - 1 limit". */
    fun summary(): String {
        val parts = ArrayList<String>()
        if (blocked.isNotEmpty()) parts += "${blocked.size} app${if (blocked.size == 1) "" else "s"}/games"
        val sections = features.count { FeatureCatalog.byId(it) != null } + if (blockShorts) 1 else 0
        if (sections > 0) parts += "$sections Shorts/Reels"
        if (siteCount > 0) parts += "$siteCount site${if (siteCount == 1) "" else "s"}"
        if (limits.isNotEmpty()) parts += "${limits.size} limit${if (limits.size == 1) "" else "s"}"
        return if (parts.isEmpty()) "Nothing selected yet" else parts.joinToString(" \u2022 ")
    }

    // ---- Edits: each returns a new copy, so the screens use the same call shapes as the global ones.

    fun withBlocked(pkg: String, on: Boolean) = copy(blocked = if (on) blocked + pkg else blocked - pkg)

    fun withShorts(on: Boolean) = copy(blockShorts = on)

    /** Unknown ids are ignored, like [ContentStore.setFeature]. */
    fun withFeature(id: String, on: Boolean): FocusProfileSettings =
        if (FeatureCatalog.byId(id) == null) this else copy(features = if (on) features + id else features - id)

    fun withLimit(limit: AppLimit): FocusProfileSettings =
        copy(limits = limits.filterNot { it.pkg == limit.pkg } + limit)

    fun withLimitEmergency(pkg: String, draft: EmergencyDraft): FocusProfileSettings = copy(
        limitEmergency = limitEmergency + (pkg to EmergencyDraft(
            draft.enabled,
            LimitEmergencyRules.clampAttempts(draft.attempts),
            LimitEmergencyRules.clampMinutes(draft.minutes),
        ))
    )

    fun withoutLimit(pkg: String) = copy(
        limits = limits.filterNot { it.pkg == pkg },
        limitEmergency = limitEmergency - pkg,
    )

    fun withWebsites(next: WebsiteState) = copy(websites = next)
}

/**
 * Text form of the parts of [FocusProfileSettings] that are not plain string sets. Same layout the
 * global stores use (WebsiteStore rules, UsageLimitStore limits), and free of Android so it can be tested.
 */
object FocusProfileCodec {

    fun encodeRules(rules: Map<String, List<WebsiteRule>>): String = ListCodec.encode(
        rules.flatMap { (pkg, list) ->
            list.map { ListCodec.pair(pkg, "${it.domain}|${if (it.enabled) 1 else 0}${if (it.subdomains) 1 else 0}") }
        }
    )

    fun decodeRules(raw: String?): Map<String, List<WebsiteRule>> {
        val rules = LinkedHashMap<String, MutableList<WebsiteRule>>()
        for (entry in ListCodec.decode(raw)) {
            val (pkg, body) = ListCodec.unpair(entry) ?: continue
            val bar = body.lastIndexOf('|')
            if (bar <= 0 || body.length - bar - 1 != 2) continue
            val flags = body.substring(bar + 1)
            rules.getOrPut(pkg) { ArrayList() }
                .add(WebsiteRule(body.substring(0, bar), enabled = flags[0] == '1', subdomains = flags[1] == '1'))
        }
        return rules
    }

    fun encodeLimits(limits: List<AppLimit>): Set<String> =
        limits.map { "${it.pkg}|${it.limitMin}|${it.remindMin}" }.toSet()

    fun decodeLimits(raw: Set<String>): List<AppLimit> = raw.mapNotNull { line ->
        val p = line.split('|')
        val limit = p.getOrNull(1)?.toIntOrNull()
        val remind = p.getOrNull(2)?.toIntOrNull()
        if (p.size != 3 || p[0].isEmpty() || limit == null || remind == null || limit <= 0) null
        else AppLimit(p[0], limit, remind)
    }.sortedBy { it.pkg }

    fun encodeEmergency(map: Map<String, EmergencyDraft>): Set<String> =
        map.map { (pkg, d) -> "$pkg|${if (d.enabled) 1 else 0}|${d.attempts}|${d.minutes}" }.toSet()

    fun decodeEmergency(raw: Set<String>): Map<String, EmergencyDraft> {
        val out = LinkedHashMap<String, EmergencyDraft>()
        for (line in raw) {
            val p = line.split('|')
            val attempts = p.getOrNull(2)?.toIntOrNull()
            val minutes = p.getOrNull(3)?.toIntOrNull()
            if (p.size != 4 || p[0].isEmpty() || attempts == null || minutes == null) continue
            out[p[0]] = EmergencyDraft(
                p[1] == "1",
                LimitEmergencyRules.clampAttempts(attempts),
                LimitEmergencyRules.clampMinutes(minutes),
            )
        }
        return out
    }
}

/**
 * One saved Focus Profile: slot, name, timestamps and its [settings].
 *
 * Not related to the account profile in `data/profile` (name / photo of the logged-in person).
 */
data class FocusProfile(
    /** 1 or 2: shown as "Profile #1" / "Profile #2". */
    val slot: Int,
    val name: String,
    val createdAt: Long,
    val updatedAt: Long,
    val settings: FocusProfileSettings = FocusProfileSettings(),
)

data class FocusProfilesState(
    val profiles: List<FocusProfile> = emptyList(),
    /** Slot of the profile in use, or 0 when there is none. */
    val selectedSlot: Int = 0,
) {
    fun get(slot: Int): FocusProfile? = profiles.firstOrNull { it.slot == slot }
    val selected: FocusProfile? get() = get(selectedSlot)
    val hasAny: Boolean get() = profiles.isNotEmpty()
}

/** Pure rules, kept apart from Android so they can be unit-tested. */
object FocusProfileRules {
    const val MAX_PROFILES = 2
    const val MAX_NAME = 24
    val SLOTS: List<Int> = (1..MAX_PROFILES).toList()

    fun validSlot(slot: Int) = slot in 1..MAX_PROFILES

    fun defaultName(slot: Int) = "Profile #$slot"

    /** Trimmed, inner whitespace collapsed, cut to [MAX_NAME]. */
    fun cleanName(raw: String): String =
        raw.trim().replace(Regex("\\s+"), " ").take(MAX_NAME).trim()

    /** Message to show under the name field, or null when the name is fine. */
    fun nameError(raw: String): String? =
        if (cleanName(raw).isEmpty()) "Give your profile a name." else null

    /** The profile to use after [removed] was deleted: the other saved one, or none (0). */
    fun selectionAfterDelete(state: FocusProfilesState, removed: Int): Int {
        if (state.selectedSlot != removed) return state.selectedSlot
        return state.profiles.firstOrNull { it.slot != removed }?.slot ?: 0
    }
}

/**
 * Saved Focus Profiles, in device-protected storage like the other stores. Own file
 * ("focus_profiles"): it shares nothing with the focus session, limits or blocking rules.
 */
class FocusProfileStore private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences = Storage.prefs(context, "focus_profiles")

    /**
     * While a session runs the selected profile is what blocks, so choosing another one, editing or deleting it
     * follows the same lock as editing the phone-wide blocking lists ("Allow app changes" / Prevent changes).
     * Outside a session, and in a Pomodoro Break, profiles can always be edited.
     */
    private fun mayEdit(): Boolean {
        val s = FocusStore.get(appContext).current()
        return s.canEditFocusProfiles
    }

    private val _state = MutableStateFlow(read())
    val state: StateFlow<FocusProfilesState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _state.value = read()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    private fun read(): FocusProfilesState {
        val list = FocusProfileRules.SLOTS.mapNotNull { slot ->
            val name = prefs.getString(key(K_NAME, slot), null) ?: return@mapNotNull null
            FocusProfile(
                slot = slot,
                name = name,
                createdAt = prefs.getLong(key(K_CREATED, slot), 0L),
                updatedAt = prefs.getLong(key(K_UPDATED, slot), 0L),
                settings = readSettings(slot),
            )
        }
        val selected = prefs.getInt(K_SELECTED, 0)
        return FocusProfilesState(
            profiles = list,
            // Never point at a profile that does not exist.
            selectedSlot = if (list.any { it.slot == selected }) selected else 0,
        )
    }

    private fun readSettings(slot: Int) = FocusProfileSettings(
        blocked = HashSet(prefs.getStringSet(key(K_BLOCKED, slot), null) ?: emptySet()),
        blockShorts = prefs.getBoolean(key(K_SHORTS, slot), false),
        features = HashSet(prefs.getStringSet(key(K_FEATURES, slot), null) ?: emptySet()),
        websites = WebsiteState(
            enabledApps = HashSet(prefs.getStringSet(key(K_WEB_APPS, slot), null) ?: emptySet()),
            rules = FocusProfileCodec.decodeRules(prefs.getString(key(K_WEB_RULES, slot), null)),
        ),
        limits = FocusProfileCodec.decodeLimits(prefs.getStringSet(key(K_LIMITS, slot), null) ?: emptySet()),
        limitEmergency = FocusProfileCodec.decodeEmergency(prefs.getStringSet(key(K_LIMIT_EMG, slot), null) ?: emptySet()),
    )

    /**
     * Creates or renames the profile in [slot]. The first profile saved becomes the selected one.
     * Returns false for a bad slot or an empty name.
     */
    @Synchronized
    fun save(slot: Int, rawName: String, now: Long = System.currentTimeMillis()): Boolean {
        if (!FocusProfileRules.validSlot(slot)) return false
        val name = FocusProfileRules.cleanName(rawName)
        if (name.isEmpty()) return false
        val current = read()
        val existing = current.get(slot)
        // A new profile can become the selected one at once, so it follows the same lock as a switch.
        if (existing == null && !mayEdit()) return false
        val edit = prefs.edit()
            .putString(key(K_NAME, slot), name)
            .putLong(key(K_CREATED, slot), existing?.createdAt ?: now)
            .putLong(key(K_UPDATED, slot), now)
        if (current.selected == null) edit.putInt(K_SELECTED, slot)
        edit.commit()
        _state.value = read()
        return true
    }

    /** Deletes the profile in [slot]; the selection moves to the other profile if there is one. */
    @Synchronized
    fun delete(slot: Int) {
        if (!FocusProfileRules.validSlot(slot) || !mayEdit()) return
        val current = read()
        if (current.get(slot) == null) return
        prefs.edit()
            .remove(key(K_NAME, slot))
            .remove(key(K_CREATED, slot))
            .remove(key(K_UPDATED, slot))
            .remove(key(K_BLOCKED, slot))
            .remove(key(K_SHORTS, slot))
            .remove(key(K_FEATURES, slot))
            .remove(key(K_WEB_APPS, slot))
            .remove(key(K_WEB_RULES, slot))
            .remove(key(K_LIMITS, slot))
            .remove(key(K_LIMIT_EMG, slot))
            .putInt(K_SELECTED, FocusProfileRules.selectionAfterDelete(current, slot))
            .commit()
        _state.value = read()
    }

    /**
     * Changes what the profile in [slot] blocks and limits. Only that profile's own keys are written: the
     * other profile, the global blocking settings and the normal App Limits are never touched. Ignored
     * when the slot has no saved profile.
     */
    @Synchronized
    fun updateSettings(slot: Int, change: (FocusProfileSettings) -> FocusProfileSettings) {
        if (!mayEdit()) return
        val current = read().get(slot) ?: return
        val next = change(current.settings)
        if (next == current.settings) return
        prefs.edit()
            // Fresh sets: SharedPreferences must never be handed the set it already holds.
            .putStringSet(key(K_BLOCKED, slot), HashSet(next.blocked))
            .putBoolean(key(K_SHORTS, slot), next.blockShorts)
            .putStringSet(key(K_FEATURES, slot), HashSet(next.features))
            .putStringSet(key(K_WEB_APPS, slot), HashSet(next.websites.enabledApps))
            .putString(key(K_WEB_RULES, slot), FocusProfileCodec.encodeRules(next.websites.rules))
            .putStringSet(key(K_LIMITS, slot), HashSet(FocusProfileCodec.encodeLimits(next.limits)))
            .putStringSet(key(K_LIMIT_EMG, slot), HashSet(FocusProfileCodec.encodeEmergency(next.limitEmergency)))
            .putLong(key(K_UPDATED, slot), System.currentTimeMillis())
            .commit()
        _state.value = read()
    }

    /** Makes the saved profile in [slot] the one in use. Ignored when that slot is empty. */
    @Synchronized
    fun select(slot: Int) {
        if (read().get(slot) == null || !mayEdit()) return
        prefs.edit().putInt(K_SELECTED, slot).commit()
        _state.value = read()
    }

    companion object {
        private const val K_NAME = "name"
        private const val K_CREATED = "created"
        private const val K_UPDATED = "updated"
        private const val K_SELECTED = "selected"
        private const val K_BLOCKED = "blocked"
        private const val K_SHORTS = "shorts"
        private const val K_FEATURES = "features"
        private const val K_WEB_APPS = "web_apps"
        private const val K_WEB_RULES = "web_rules"
        private const val K_LIMITS = "limits"
        private const val K_LIMIT_EMG = "limit_emg"

        private fun key(field: String, slot: Int) = "${field}_$slot"

        @Volatile
        private var instance: FocusProfileStore? = null

        fun get(context: Context): FocusProfileStore =
            instance ?: synchronized(this) {
                instance ?: FocusProfileStore(context.applicationContext).also { instance = it }
            }
    }
}
