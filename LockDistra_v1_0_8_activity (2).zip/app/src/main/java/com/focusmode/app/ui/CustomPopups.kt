package com.focusmode.app.ui

import android.app.Activity
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import com.focusmode.app.data.online.FirebaseGateway
import org.json.JSONArray
import org.json.JSONObject

/*
 * Popups designed in the admin panel with the admin's own HTML + CSS + JavaScript.
 *
 * The admin's code can call:   ReWire.update()   opens the link set in the panel
 *                              ReWire.open("https://...")   opens any https link
 *                              ReWire.close()   closes the popup (ignored on a forced update)
 *
 * Where to call (config/main is the JSON the admin panel saves):
 *   - App opens:      if (!CustomUpdatePopup.maybeShow(activity, cfg.optJSONObject("update"), BuildConfig.VERSION_CODE))
 *                         CustomPopups.maybeShow(activity, cfg.optJSONArray("popups"), "app")
 *   - Study opens:    CustomPopups.maybeShow(activity, cfg.optJSONArray("popups"), "study")
 * Each returns true when it showed something. Only one popup is shown at a time.
 */

/** The transparent full-screen WebView dialog both popup kinds use. */
internal object PopupWebDialog {

    /** The popup that is on screen right now (if any), so it can be closed when the person leaves Home. */
    @Volatile private var current: Dialog? = null

    /**
     * Closes the popup that is showing. Called when the person is no longer inside the app (logout, expired login,
     * login screen, onboarding, permission page) so a popup can never stay in front of those screens.
     */
    fun dismissAll() {
        val d = current ?: return
        Handler(Looper.getMainLooper()).post { runCatching { d.dismiss() }; if (current === d) current = null }
    }

    fun show(
        activity: Activity, html: String, css: String, js: String, link: String,
        closable: Boolean, closeOnLink: Boolean, onLink: () -> Unit = {},
    ) {
        // Last safety net for every popup kind: only while Home is really on screen (logged in, past splash,
        // onboarding, login and permissions). Anywhere else the popup is simply not drawn.
        if (!HomeVisible.value) return
        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(closable)
        dialog.setCanceledOnTouchOutside(false)

        val web = WebView(activity)
        web.setBackgroundColor(Color.TRANSPARENT)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        // One soft entrance: the page fades in and settles from slightly smaller.
        web.alpha = 0f
        web.scaleX = 0.94f
        web.scaleY = 0.94f
        web.webViewClient = object : WebViewClient() {
            // A tapped link never loads inside the popup: https opens in the browser, anything else is ignored.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                openLink(activity, request.url.toString())
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(DecelerateInterpolator()).start()
            }
        }
        val bridge = Bridge(activity, dialog, link, closable, closeOnLink, onLink)
        web.addJavascriptInterface(bridge, "ReWire")

        val root = FrameLayout(activity)
        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        dialog.setContentView(root)
        dialog.setOnDismissListener {
            if (current === dialog) current = null
            web.removeAllViews(); web.destroy()
        }
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setDimAmount(0.6f)
        }
        web.loadDataWithBaseURL("https://rewire.local/", page(html, css, js), "text/html", "utf-8", null)
        current = dialog
        dialog.show()
    }

    /** Same wrapper the admin preview uses: the admin's CSS, then HTML, then JavaScript. */
    private fun page(html: String, css: String, js: String): String =
        "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>html,body{margin:0;min-height:100%;background:transparent}</style>" +
            "<style>" + css.replace(Regex("</style", RegexOption.IGNORE_CASE), "<\\\\/style") + "</style></head><body>" +
            html + "<script>" + js.replace(Regex("</script", RegexOption.IGNORE_CASE), "<\\\\/script") +
            "</script></body></html>"

    private class Bridge(
        private val activity: Activity,
        private val dialog: Dialog,
        private val link: String,
        private val closable: Boolean,
        private val closeOnLink: Boolean,
        private val onLink: () -> Unit,
    ) {
        private val main = Handler(Looper.getMainLooper())

        @JavascriptInterface
        fun update() {
            main.post {
                onLink()
                openLink(activity, link)
                if (closeOnLink) dialog.dismiss()
            }
        }

        @JavascriptInterface
        fun open(url: String?) {
            main.post { openLink(activity, url.orEmpty()) }
        }

        @JavascriptInterface
        fun close() {
            main.post { if (closable) dialog.dismiss() }
        }
    }

    fun openLink(context: Context, url: String) {
        if (!url.startsWith("https://")) return
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
            // No app can open this link on the phone.
        }
    }
}

/** The update popup (admin panel, Update tab): phones older than the version code, once, "Not now" returns later. */
object CustomUpdatePopup {
    private const val PREFS = "rewire_custom_update"
    private const val KEY_DONE = "done_id"
    private const val KEY_SHOWN_ID = "shown_id"
    private const val KEY_SHOWN_AT = "shown_at"

    private data class Spec(
        val id: String, val html: String, val css: String, val js: String, val link: String,
        val everyone: Boolean, val versionCode: Int, val repeatHours: Int, val force: Boolean,
    )

    private fun parse(update: JSONObject?): Spec? {
        if (update == null || !update.optBoolean("enabled", false)) return null
        val html = update.optString("html", "")
        val link = update.optString("link", update.optString("apkUrl", ""))
        val id = update.optString("id", "")
        if (html.isBlank() || id.isBlank() || !link.startsWith("https://")) return null
        return Spec(
            id = id, html = html, css = update.optString("css", ""), js = update.optString("js", ""), link = link,
            everyone = update.optString("who", "older") == "all", versionCode = update.optInt("versionCode", 0),
            repeatHours = update.optInt("repeatHours", 6).coerceAtLeast(0), force = update.optBoolean("force", false),
        )
    }

    private fun shouldShow(prefs: android.content.SharedPreferences, spec: Spec, installedVersionCode: Int): Boolean {
        if (!spec.everyone && installedVersionCode >= spec.versionCode) return false
        if (prefs.getString(KEY_DONE, null) == spec.id) return false
        if (spec.force) return true
        if (prefs.getString(KEY_SHOWN_ID, null) == spec.id) {
            if (spec.repeatHours == 0) return false
            if (FirebaseGateway.serverNow() - prefs.getLong(KEY_SHOWN_AT, 0L) < spec.repeatHours * 3_600_000L) return false
        }
        return true
    }

    /** True when the popup was shown (so the old simple update dialog can be skipped). */
    fun maybeShow(activity: Activity, update: JSONObject?, installedVersionCode: Int): Boolean {
        if (!HomeVisible.value) return false // not logged in / not on Home: nothing is shown and nothing is counted
        val spec = parse(update) ?: return false
        if (activity.isFinishing || activity.isDestroyed) return false
        val prefs = activity.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!shouldShow(prefs, spec, installedVersionCode)) return false
        prefs.edit().putString(KEY_SHOWN_ID, spec.id).putLong(KEY_SHOWN_AT, FirebaseGateway.serverNow()).apply()
        PopupWebDialog.show(
            activity, spec.html, spec.css, spec.js, spec.link,
            closable = !spec.force, closeOnLink = !spec.force,
        ) {
            // "Every phone" has no version to compare, so a tap marks it done. "Older phones" stops by itself after updating.
            if (spec.everyone) prefs.edit().putString(KEY_DONE, spec.id).apply()
        }
        return true
    }
}

/** The popups (admin panel, Popups tab): "inside Study" or "when the app opens", with start/end, repeat and a max count. */
object CustomPopups {
    private const val PREFS = "rewire_custom_popups"

    /** [where] is "app" or "study". Shows the first popup that is ON, in its time window and not used up. */
    fun maybeShow(activity: Activity, popups: JSONArray?, where: String): Boolean {
        if (!HomeVisible.value) return false // not logged in / not on Home: nothing is shown and nothing is counted
        if (popups == null || activity.isFinishing || activity.isDestroyed) return false
        val prefs = activity.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val now = FirebaseGateway.serverNow()
        for (i in 0 until popups.length()) {
            val p = popups.optJSONObject(i) ?: continue
            if (!p.optBoolean("enabled", true)) continue
            if ((if (p.optString("where", "study") == "app") "app" else "study") != where) continue
            val id = p.optString("id", "")
            val html = p.optString("html", "")
            if (id.isBlank() || html.isBlank()) continue // old form popups (no code) are not drawn here
            val link = p.optString("link", "")
            if (link.isNotEmpty() && !link.startsWith("https://")) continue
            val start = p.optLong("startAt", 0L)
            val end = p.optLong("endAt", 0L)
            if (start > 0 && now < start) continue
            if (end > 0 && now > end) continue
            val count = prefs.getInt("c_$id", 0)
            val maxShows = p.optInt("maxShows", 0)
            if (maxShows > 0 && count >= maxShows) continue
            if (count > 0) {
                val repeatHours = p.optInt("repeatHours", 0)
                if (repeatHours <= 0) continue // 0 = only once
                if (now - prefs.getLong("t_$id", 0L) < repeatHours * 3_600_000L) continue
            }
            prefs.edit().putInt("c_$id", count + 1).putLong("t_$id", now).apply()
            PopupWebDialog.show(
                activity, html, p.optString("css", ""), p.optString("js", ""), link,
                closable = p.optBoolean("dismissible", true), closeOnLink = true,
            )
            return true
        }
        return false
    }
}
