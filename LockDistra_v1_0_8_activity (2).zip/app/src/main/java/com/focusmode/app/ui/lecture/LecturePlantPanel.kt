package com.focusmode.app.ui.lecture

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.data.FocusState
import com.focusmode.app.ui.components.PlantView
import com.focusmode.app.ui.formatClock
import kotlinx.coroutines.delay

/** Without a time limit the plant takes this long to reach full bloom (same as the Focus screen). */
private const val OPEN_ENDED_GROW_MS = 60L * 60_000L

/** Shown under the lecture video (portrait): the running session's timer and the plant that grows with it. */
@Composable
fun LecturePlantPanel(state: FocusState) {
    val now by produceState(System.currentTimeMillis(), state.focusActive) {
        value = System.currentTimeMillis()
        while (state.focusActive) {
            delay(250)
            value = System.currentTimeMillis()
        }
    }
    val limited = state.sessionEnd > 0L
    val elapsed = (now - state.sessionStart).coerceAtLeast(0L)
    val total = (state.sessionEnd - state.sessionStart).coerceAtLeast(1L)
    val progress = when {
        !state.focusActive -> 0f
        limited -> (elapsed.toFloat() / total).coerceIn(0f, 1f)
        else -> (elapsed.toFloat() / OPEN_ENDED_GROW_MS).coerceIn(0f, 1f)
    }
    val timeText = if (limited) formatClock((state.sessionEnd - now).coerceAtLeast(0L)) else formatClock(elapsed)

    // Timer and plant sit together in the middle of the space under the video (not timer at the top and plant at the bottom).
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0A17)),
        contentAlignment = Alignment.Center,
    ) {
        val plantHeight = (maxHeight - 84.dp).coerceIn(120.dp, 280.dp)
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            if (state.focusActive) {
                Text(
                    timeText,
                    style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 44.sp, letterSpacing = 1.sp, fontFeatureSettings = "tnum"),
                    color = Color.White,
                    maxLines = 1,
                )
                Spacer(Modifier.height(4.dp))
            }
            PlantView(
                growth = state.plantGrowth,
                active = state.focusActive,
                progress = if (state.focusActive) progress else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(plantHeight),
            )
        }
    }
}
