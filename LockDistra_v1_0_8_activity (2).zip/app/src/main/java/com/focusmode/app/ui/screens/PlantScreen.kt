package com.focusmode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.PLANT_MAX_GROWTH
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusProgressBar
import com.focusmode.app.ui.components.PlantView
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.components.staggeredEntrance
import com.focusmode.app.ui.formatClock
import com.focusmode.app.ui.plantStage
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

private val reminderOptions = listOf(0 to "Off", 15 to "15 min", 30 to "30 min", 45 to "45 min")

/**
 * The plant has its own page. It grows here, and only when the person confirms "yes, I'm studying"
 * (a tap anywhere in the open app, or the button in the reminder notification).
 */
@Composable
fun PlantScreen(
    state: FocusState,
    onBack: () -> Unit,
    onReminderChange: (Int) -> Unit,
    onResetPlant: () -> Unit,
) {
    val c = FocusTheme.colors
    val now by produceState(System.currentTimeMillis(), state.focusActive) {
        value = System.currentTimeMillis()
        while (state.focusActive) {
            delay(1_000)
            value = System.currentTimeMillis()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .staggeredEntrance(0)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Column {
                Text("Your plant", style = MaterialTheme.typography.titleLarge)
                Text(
                    "${state.plantGrowth} of $PLANT_MAX_GROWTH growth",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            FocusCard(
                padding = PaddingValues(20.dp),
                highlight = state.checkInPending,
                modifier = Modifier.staggeredEntrance(1)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(plantStage(state.plantGrowth), style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(10.dp))
                    PlantView(
                        growth = state.plantGrowth,
                        active = state.focusActive,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(340.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    FocusProgressBar(
                        progress = state.plantGrowth.toFloat() / PLANT_MAX_GROWTH,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = when {
                            state.checkInPending ->
                                "Are you studying? Tap anywhere in the app, or use the button in the notification."
                            !state.focusActive ->
                                "The plant grows while LockDistra is on, each time you confirm you are studying."
                            state.reminderMinutes == 0 ->
                                "Check-ins are off, so the plant rests until you turn them on."
                            state.nextReminderAt > 0L ->
                                "Next check-in in ${formatClock(state.nextReminderAt - now)}."
                            else -> "Check-ins are on."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.checkInPending) c.warning else c.muted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (state.plantGrowth >= PLANT_MAX_GROWTH) {
                        TextButton(onClick = onResetPlant) { Text("Plant a new seed", color = c.accent) }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            SectionLabel("Check-in every", Modifier.staggeredEntrance(2))
            FocusCard(modifier = Modifier.staggeredEntrance(3)) {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        reminderOptions.forEach { (min, label) ->
                            SoftChip(
                                text = label,
                                selected = state.reminderMinutes == min,
                                onClick = { if (state.canChangeFocusSettings) onReminderChange(min) }
                            )
                        }
                    }
                    if (!state.canChangeFocusSettings) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Check-in timing is locked right now.",
                            style = MaterialTheme.typography.bodySmall,
                            color = c.warning
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            SectionLabel("How it works", Modifier.staggeredEntrance(4))
            FocusCard(modifier = Modifier.staggeredEntrance(5)) {
                Text(
                    "At every check-in LockDistra asks if you are studying. If the app is open, tap anywhere. " +
                        "If it is closed, tap \"Yes, I'm studying\" in the notification; you stay in your lecture or notes " +
                        "and the app does not open. The plant only grows when you confirm.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.muted
                )
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

/** Full-screen question shown over the open app while a check-in waits. Any tap answers "yes". */
@Composable
fun CheckInOverlay(onTap: () -> Unit) {
    val c = FocusTheme.colors
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.62f))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTap
            ),
        contentAlignment = Alignment.Center
    ) {
        FocusCard(padding = PaddingValues(28.dp), modifier = Modifier.padding(32.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.Eco, null, tint = c.accent, modifier = Modifier.size(44.dp))
                Spacer(Modifier.height(12.dp))
                Text("Are you studying?", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Tap anywhere to say yes. Your plant will grow.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.muted,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
