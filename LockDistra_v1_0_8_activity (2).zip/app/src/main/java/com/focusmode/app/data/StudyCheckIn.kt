package com.focusmode.app.data

/**
 * Study Check-In: while Focus Mode runs, LockDistra asks "Are You Still Studying?" every N minutes. The person has one
 * minute to tap "I'm Studying". A missed check-in tells the trusted phone, but ONLY when the effective OFF method is
 * Online Approval. It never ends the session and never touches the Focus / Pomodoro timer.
 *
 * Kept free of Android classes so the rules can be unit tested on a plain JVM (StudyCheckInTest).
 */
object StudyCheckInRules {

    /** 0 = no check-ins (the default, so nothing changes for anyone who does not turn this on). */
    const val OFF = 0
    val PRESETS = listOf(10, 15)
    /** The one-minute response window means an interval must be clearly longer than that. */
    const val MIN_CUSTOM = 2
    const val MAX_CUSTOM = 180

    const val RESPONSE_WINDOW_MS = 60_000L

    /**
     * A missed check-in is only reported if it is noticed this soon after its deadline. If the phone was asleep or
     * off for longer, nobody knows whether the prompt was ever seen, so the check-in is dropped quietly instead of
     * telling the trusted person something that may not be true.
     */
    const val MISSED_GRACE_MS = 120_000L

    /** A missed-check-in alert that could not be delivered is given up this long after the miss. */
    const val ALERT_MAX_AGE_MS = 5 * 60_000L
    const val ALERT_MAX_TRIES = 4
    const val ALERT_RETRY_GAP_MS = 20_000L

    /** Off (0), or a whole number of minutes inside [MIN_CUSTOM]..[MAX_CUSTOM]. */
    fun clamp(minutes: Int): Int = if (minutes <= 0) OFF else minutes.coerceIn(MIN_CUSTOM, MAX_CUSTOM)

    fun isCustom(minutes: Int): Boolean = minutes > 0 && minutes !in PRESETS

    fun label(minutes: Int): String = if (minutes <= 0) "Off" else "Every $minutes minutes"

    /** Like the OFF method: changed only between sessions, so check-ins cannot be switched off mid-session. */
    fun canChange(focusActive: Boolean, canChangeSettings: Boolean): Boolean = !focusActive && canChangeSettings

    /** The trusted phone is told only when Online Approval really is how Focus Mode turns OFF right now. */
    fun alertAllowed(effectiveMethod: FocusOffMethod): Boolean = effectiveMethod == FocusOffMethod.ONLINE

    enum class Step {
        NONE,
        /** Time to ask. */
        PROMPT,
        /** The minute ran out without an answer. */
        MISSED,
        /** The minute ran out but too late to know what happened (see [MISSED_GRACE_MS]). */
        EXPIRED,
    }

    /**
     * What is due right now. [deadline] != 0 means a prompt is waiting for its answer; [nextAt] is when the next one
     * is due. Pure: the caller applies the step and stores the result.
     */
    fun decide(focusActive: Boolean, intervalMin: Int, nextAt: Long, deadline: Long, now: Long): Step {
        if (!focusActive || intervalMin <= 0) return Step.NONE
        if (deadline != 0L) {
            return when {
                now < deadline -> Step.NONE
                now - deadline <= MISSED_GRACE_MS -> Step.MISSED
                else -> Step.EXPIRED
            }
        }
        return if (nextAt != 0L && now >= nextAt) Step.PROMPT else Step.NONE
    }

    /** Next prompt time, counted from when this prompt was shown (so the rhythm does not drift). */
    fun nextAfterPrompt(shownAt: Long, intervalMin: Int): Long = shownAt + intervalMin * 60_000L

    /**
     * Id sent to the Worker for one missed check-in. The same miss always gives the same id (so a retry can never
     * become a second alert) and different misses never share one. Fits the Worker's 10-40 character rule.
     */
    fun alertId(seq: Long, missedAt: Long): String = "ci_${seq}_${missedAt.toString(36)}"

    /** Whether to (re)try telling the trusted phone about miss number [missSeq] right now. */
    fun alertDue(
        missSeq: Long,
        sentSeq: Long,
        missedAt: Long,
        now: Long,
        effectiveMethod: FocusOffMethod,
        tries: Int,
        lastTryAt: Long,
    ): Boolean =
        missSeq > sentSeq &&
            alertAllowed(effectiveMethod) &&
            now - missedAt in 0..ALERT_MAX_AGE_MS &&
            tries < ALERT_MAX_TRIES &&
            (tries == 0 || now - lastTryAt >= ALERT_RETRY_GAP_MS)

    /** A confirmation only counts for the prompt that is really waiting (a forged / old tap does nothing). */
    fun acceptsConfirm(tapSeq: Long, currentSeq: Long, deadline: Long, focusActive: Boolean): Boolean =
        focusActive && deadline != 0L && tapSeq > 0L && tapSeq == currentSeq

    // ---- Text -------------------------------------------------------------------------------------------------

    const val PROMPT_TITLE = "Are You Still Studying?"
    const val PROMPT_TEXT = "Please confirm that you are actively studying."
    const val PROMPT_BUTTON = "I'm Studying"

    /** Shown on the TRUSTED phone. An alert to look into, not a claim that the person stopped studying. */
    const val ALERT_TITLE = "Study Check-In Missed"
    const val ALERT_TEXT =
        "The user has not responded to the study confirmation for one minute. Please check whether they are studying."
}
