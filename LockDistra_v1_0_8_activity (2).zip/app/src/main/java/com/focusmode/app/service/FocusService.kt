package com.focusmode.app.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.PomodoroStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps LockDistra alive in the background and shows the permanent status notification.
 * Time-based transitions (timer end, emergency end, plant reminders) are driven from here.
 */
class FocusService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService() requires startForeground() within seconds, even if we are
        // about to stop, so always promote first.
        val notification = Notifications.buildStatus(this)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(
                    this, Notifications.ID_STATUS, notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(Notifications.ID_STATUS, notification)
            }
        } catch (_: Exception) {
            // Android refused the foreground promotion (a background start on 12+). Do not crash the app:
            // blocking keeps running from the saved session in the accessibility service, and the alarm /
            // next app start try again.
            stopSelf()
            return START_NOT_STICKY
        }

        if (!sessionOrBreak()) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        if (loop?.isActive != true) {
            loop = scope.launch {
                while (isActive) {
                    FocusEngine.process(this@FocusService)
                    if (!sessionOrBreak()) break
                    delay(1_000)
                }
            }
        }
        return START_STICKY
    }

    /** The service is needed while a focus session runs, and during a running Pomodoro break. */
    private fun sessionOrBreak() =
        FocusStore.get(this).current().focusActive || PomodoroStore.get(this).current().running

    /** Swiping LockDistra out of recents must not stop a running session. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        FocusEngine.scheduleSoon(this)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        // Destroyed while a session is still running (killed by the system): come back quickly.
        // A normal stop ends the session first, so nothing is scheduled then.
        FocusEngine.scheduleSoon(this)
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
