package com.focusmode.app.data

/** Where the Pomodoro cycle is. IDLE = not started (or stopped). */
enum class PomodoroPhase { IDLE, FOCUS, BREAK }

/**
 * Saved Pomodoro cycle. The Focus phase is a normal LockDistra focus session (its end time lives in
 * [FocusState]); only the Break needs its own clock, because no session runs during it.
 */
data class PomodoroState(
    val phase: PomodoroPhase = PomodoroPhase.IDLE,
    val focusMin: Int = PomodoroRules.DEFAULT_FOCUS,
    val breakMin: Int = PomodoroRules.DEFAULT_BREAK,
    /** Number of the current Focus round, starting at 1. */
    val round: Int = 0,
    val paused: Boolean = false,
    /** Time left in the paused phase. */
    val pausedLeftMs: Long = 0L,
    /** End of the running Break: wall clock, monotonic clock and the boot it belongs to. */
    val breakEndWall: Long = 0L,
    val breakEndElapsed: Long = 0L,
    val breakBoot: Int = -1,
) {
    /** A cycle exists (running or paused). */
    val active: Boolean get() = phase != PomodoroPhase.IDLE

    /** Time is passing: the background service must stay alive. */
    val running: Boolean get() = active && !paused
}

object PomodoroRules {
    const val DEFAULT_FOCUS = 25
    const val DEFAULT_BREAK = 5
    const val MIN_FOCUS = 1
    const val MAX_FOCUS = 180
    const val MIN_BREAK = 1
    const val MAX_BREAK = 60

    fun clampFocus(min: Int) = min.coerceIn(MIN_FOCUS, MAX_FOCUS)
    fun clampBreak(min: Int) = min.coerceIn(MIN_BREAK, MAX_BREAK)

    /** Durations may only be changed while no cycle exists, so a running cycle can't be shortened. */
    fun canEditDurations(s: PomodoroState) = !s.active

    /**
     * Milliseconds left in a Break. While the phone has not restarted both clocks are used and
     * the smaller value wins, so moving the date back cannot stretch a break. After a restart
     * (or when Android does not report a boot number) only the wall clock is available.
     */
    fun breakLeftMs(s: PomodoroState, wallNow: Long, elapsedNow: Long, boot: Int): Long {
        val wallLeft = s.breakEndWall - wallNow
        val sameBoot = s.breakBoot != -1 && s.breakBoot == boot
        val left = if (sameBoot) minOf(wallLeft, s.breakEndElapsed - elapsedNow) else wallLeft
        return left.coerceAtLeast(0L)
    }

    fun breakStartedText(focusMin: Int, breakMin: Int) =
        "Your $focusMin-minute focus session is complete! Enjoy your $breakMin-minute break. " +
            "All Focus restrictions are temporarily unlocked."

    fun breakOverText(breakMin: Int) =
        "Your $breakMin-minute break is over! Focus restrictions are now active again."
}
