package com.focusmode.app.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.text.format.DateFormat
import android.widget.Toast
import com.focusmode.app.data.AutoFocusFormat
import com.focusmode.app.data.AutoFocusNotifier
import com.focusmode.app.data.AutoFocusStore
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.PomodoroStore

/**
 * Makes Auto Focus happen WITHOUT the app being open. Before, only the screen of the app checked the schedule, so
 * when LockDistra was closed (swiped away, or killed by a phone that is strict with background apps) Focus Mode never
 * turned on. Now three things start it, any one is enough:
 *  1. an alarm set with Android's AlarmManager for the start time (it survives the app being closed or killed),
 *  2. the Accessibility service, which keeps running and looks every few seconds (see AppBlockerService.pollLoop),
 *  3. a restart, an app update, or a change of the phone's time / time zone (the alarm is set again).
 * The app screen still checks too. All of them go through [process], which starts a window only once.
 */
object AutoFocusEngine {

    private const val REQ_AUTO_FOCUS = 7301
    private const val RETRY_MS = 30_000L

    /**
     * Starts Focus Mode if an Auto Focus window is running and has not been handled yet. Safe to call as often as
     * wanted. Returns true when it changed something (started, or gave up for this window).
     */
    @Synchronized
    fun process(context: Context, now: Long = System.currentTimeMillis()): Boolean {
        val app = context.applicationContext
        val store = AutoFocusStore.get(app)
        val schedule = store.schedule.value
        val window = schedule.currentWindow(now) ?: return false
        if (store.lastHandledStart == window.startMs) return false

        val focusActive = FocusStore.get(app).current().focusActive
        val pomodoroActive = PomodoroStore.get(app).current().active
        return when {
            // Already focusing (started by hand): leave it alone and don't restart it later in this window.
            focusActive -> {
                store.markHandled(window)
                true
            }
            // A Pomodoro is waited out; the alarm tries again.
            pomodoroActive -> false
            !Permissions.isAccessibilityEnabled(app) -> {
                store.markHandled(window)
                AutoFocusNotifier.couldNotStart(app)
                toast(app, "Auto Focus couldn't start: allow Accessibility access first.")
                true
            }
            else -> {
                store.markHandled(window)
                FocusController.start(app, AutoFocusFormat.remainingMinutes(window, now))
                val endText = AutoFocusFormat.timeOf(window.endMs, DateFormat.is24HourFormat(app))
                AutoFocusNotifier.started(app, endText)
                toast(app, "Auto Focus started until $endText.")
                true
            }
        }
    }

    /** Sets (or cancels) the alarm for the next time Auto Focus has something to do. */
    @Synchronized
    fun schedule(context: Context, now: Long = System.currentTimeMillis()) {
        val app = context.applicationContext
        val store = AutoFocusStore.get(app)
        val schedule = store.schedule.value
        val current = schedule.currentWindow(now)
        val at = when {
            // A window is running but could not start yet (a Pomodoro is running): look again shortly.
            current != null && store.lastHandledStart != current.startMs -> now + RETRY_MS
            else -> schedule.nextWindow(now)?.startMs
        }
        val am = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(app)
        if (at == null) {
            am.cancel(pi)
            return
        }
        try {
            if (FocusEngine.canScheduleExact(app)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun pendingIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQ_AUTO_FOCUS,
            Intent(context, AutoFocusReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun toast(context: Context, text: String) {
        Handler(Looper.getMainLooper()).post {
            try {
                Toast.makeText(context, text, Toast.LENGTH_LONG).show()
            } catch (_: Exception) {
            }
        }
    }
}

/**
 * Wakes LockDistra for Auto Focus: the start-time alarm, a restart, an app update, or a change of the phone's time or time
 * zone. It only ever runs [AutoFocusEngine], which decides from the saved schedule and the clock, so a broadcast sent
 * by another app cannot start anything the schedule would not start.
 */
class AutoFocusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AutoFocusEngine.process(context)
        AutoFocusEngine.schedule(context)
    }
}
