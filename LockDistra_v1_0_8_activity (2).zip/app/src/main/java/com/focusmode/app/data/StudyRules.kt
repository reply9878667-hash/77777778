package com.focusmode.app.data

import org.json.JSONArray
import org.json.JSONObject

/** One YouTube video as the Study section shows it. */
data class StudyVideo(
    val id: String,
    val title: String,
    val channelId: String,
    val channelTitle: String,
    val thumbUrl: String,
    val seconds: Int,
    val categoryId: String,
    val embeddable: Boolean,
    /** When it was uploaded (milliseconds since 1970); 0 = not known. */
    val publishedAt: Long = 0L,
    /** The start of the video's description ("" = none / not known: only the API gives it). */
    val description: String = "",
    /** The language the uploader set for the video's audio / text ("" = not set), e.g. "hi", "en-US", "es". */
    val audioLang: String = "",
) {
    /** A Short: one minute (YouTube now allows up to three) or less. */
    val isShort: Boolean get() = seconds in 1..StudyRules.SHORT_MAX_SECONDS

    val watchUrl: String get() = LectureLink.watchUrl(id)
}

/** A channel the person trusts (always allowed, whatever its category). */
data class StudyChannel(val id: String, val name: String)

/** A channel's public details, for its page: picture, handle, subscribers, number of videos. */
data class StudyChannelInfo(
    val id: String,
    val name: String,
    val handle: String,
    val avatarUrl: String,
    val subscribers: Long?,
    val videoCount: Long?,
    /** Two-letter country the channel set ("IN"), or "" when it set none. */
    val country: String = "",
    /** The channel's own description ("" = it has none). */
    val description: String = "",
)

/** What a pasted channel link or name points to. */
sealed class ChannelRef {
    data class Handle(val handle: String) : ChannelRef()
    data class Id(val id: String) : ChannelRef()
}

/**
 * NO_KEY / BAD_KEY / QUOTA = the YouTube API cannot be used (QUOTA = its limit, never "no internet").
 * NETWORK = the phone could not reach the source. BAD_ANSWER = the source answered, but with something unreadable.
 * NOT_FOUND = the thing asked for does not exist (a channel with no uploads playlist). OTHER = anything else.
 */
enum class StudyErrorKind { NO_KEY, BAD_KEY, QUOTA, NETWORK, BAD_ANSWER, NOT_FOUND, OTHER }

/** [dailyLimit] is false for a short "too many requests this minute" answer, which clears by itself in a minute. */
open class StudyException(
    val kind: StudyErrorKind,
    message: String,
    val dailyLimit: Boolean = true,
    /** Which source failed: the YouTube API, Direct YouTube (page data) or the Web search. */
    val source: StudyMode = StudyMode.API,
    /** The finer cause (timeout, 5xx, invalid key ...) for source detection ([StudySources]); NONE = the kind says it all. */
    val reason: SourceReason = SourceReason.NONE,
) : Exception(message) {
    /** Direct YouTube answered, but its page held nothing readable (the Web search is the next backup, as before). */
    val isPageUnreadable: Boolean get() = kind == StudyErrorKind.BAD_ANSWER && source == StudyMode.PAGE
}

/**
 * The rules of the Study section: what counts as "study", how YouTube's answers are read, and how results are cached.
 * No Android classes, so it is unit tested on the JVM.
 *
 * YouTube has no "study only" switch, so a video is shown only when it passes ALL of these:
 *  - it is public, embeddable, not live, and has a known length;
 *  - it is in the Education category, or its channel is one the person added as trusted;
 *  - its title / channel name has no distraction word (a trusted channel is only held to the "never" list).
 */
object StudyRules {
    const val EDUCATION_CATEGORY = "27"
    const val SHORT_MAX_SECONDS = 180

    /** A saved description is cut to this length (the lists are kept on the phone, so they must stay small). */
    const val DESCRIPTION_MAX = 300
    private const val CHANNEL_DESCRIPTION_MAX = 600

    /** Subjects offered at first. The person can add their own. */
    val DEFAULT_SUBJECTS = listOf(
        "Maths", "Science", "Physics", "Chemistry", "Biology", "English", "Hindi",
        "History", "Geography", "Civics", "Economics", "Computer Science",
    )

    // The word lists live in [StudyBlocklist] (adult words are never shown, even from a trusted channel; the rest is
    // everything that is not studying: comedy, gaming, movies, songs, gossip, betting...).

    private fun hasAdult(text: String): Boolean = StudyBlocklist.adultHit(text) != null
    private fun hasDistraction(text: String): Boolean = StudyBlocklist.videoDistractionHit(text) != null

    /** A search suggestion is shown only when it has no distraction word (same lists as the videos). */
    fun suggestionAllowed(text: String): Boolean = StudyBlocklist.blockedSearch(text) == null

    /** True when [text] has a word that is never shown (adult content). */
    fun hasNeverWord(text: String): Boolean = hasAdult(text)

    /** True when [text] has a typical distraction word (gaming, prank, movie...). */
    fun hasDistractionWord(text: String): Boolean = hasDistraction(text)

    /** Google's suggestion answer `["query",["a","b",...]]` -> up to [max] allowed suggestions. */
    fun parseSuggestions(json: String, max: Int = 8): List<String> = try {
        val list = JSONArray(json).getJSONArray(1)
        (0 until list.length()).map { list.getString(it).trim() }
            .filter { it.isNotEmpty() && suggestionAllowed(it) }
            .distinct()
            .take(max)
    } catch (e: Exception) {
        emptyList()
    }

    /** At most this many videos of one channel in the home feed (with enough channels to choose from). */
    const val MAX_PER_CHANNEL = 3
    private const val MIN_CHANNELS_FOR_CAP = 6

    /**
     * Mixes the feed like YouTube: videos of different channels one after the other, never several of the same channel in a
     * row (unless only one channel is left). Round 1 holds the first video of every channel, round 2 the second, and so on;
     * each channel keeps its own order and has at most [maxPerChannel] videos (no cap when fewer than 6 channels exist,
     * so a small feed is not cut down).
     */
    fun diversify(list: List<StudyVideo>, maxPerChannel: Int = MAX_PER_CHANNEL): List<StudyVideo> {
        val groups = LinkedHashMap<String, ArrayList<StudyVideo>>()
        for (v in list) groups.getOrPut(v.channelId.ifEmpty { v.id }) { ArrayList() } += v
        val cap = if (groups.size >= MIN_CHANNELS_FOR_CAP) maxPerChannel else Int.MAX_VALUE
        val picked = groups.values.map { it.take(cap) }
        val total = picked.sumOf { it.size }
        val out = ArrayList<StudyVideo>(total)
        var round = 0
        while (out.size < total) {
            for (g in picked) if (round < g.size) out += g[round]
            round++
        }
        return out
    }

    /** True when [v] may be shown. [trusted] = ids of the person's trusted channels. */
    fun accept(v: StudyVideo, trusted: Set<String>, watched: Set<String> = emptySet()): Boolean {
        if (!v.embeddable || v.seconds <= 0) return false
        val isTrusted = v.channelId in trusted
        // A followed channel is trusted fully. A channel that was only played a lot skips the category check (a study channel
        // is not always filed as "Education"), but its distracting videos (entertainment, gaming...) are still left out.
        if (!isTrusted && v.channelId !in watched && v.categoryId != EDUCATION_CATEGORY) return false
        val text = v.title + " " + v.channelTitle
        if (hasAdult(text)) return false
        if (!isTrusted && hasDistraction(text)) return false
        return true
    }

    /**
     * Shorts are wider than long videos: besides Education (27), Science & Technology (28) and News & Politics (25) count, because
     * explainer / knowledge creators (current affairs, GK, science facts, history) are filed there. Everything else about [accept]
     * stays: adult and distraction words, and the video has to be embeddable. A Short in a language that is not Indian or English is left out.
     */
    /** Topics of the extra Shorts search of the home feed and of the Shorts chips. */
    val KNOWLEDGE_QUERIES = listOf("GK facts", "Current affairs", "Science facts", "History explained", "Economy explained", "Geography facts")

    val SHORT_CATEGORIES = setOf(EDUCATION_CATEGORY, "28", "25")

    /** Languages (first part of the code) that can be shown: the Indian ones and English. "" = not set = shown. */
    private val SHORT_LANGS = setOf("en", "hi", "bn", "ta", "te", "mr", "gu", "kn", "ml", "pa", "ur", "or", "as", "sa", "ne", "mai", "bho", "raj")

    fun isAbroadLanguage(lang: String): Boolean {
        val first = lang.trim().lowercase().substringBefore('-').substringBefore('_')
        return first.isNotEmpty() && first !in SHORT_LANGS
    }

    fun acceptShort(v: StudyVideo, trusted: Set<String>, watched: Set<String> = emptySet()): Boolean {
        if (!v.embeddable || v.seconds <= 0) return false
        val isTrusted = v.channelId in trusted
        if (!isTrusted && isAbroadLanguage(v.audioLang)) return false
        if (!isTrusted && v.channelId !in watched && v.categoryId !in SHORT_CATEGORIES) return false
        val text = v.title + " " + v.channelTitle
        if (hasAdult(text)) return false
        if (!isTrusted && hasDistraction(text)) return false
        return true
    }

    // ---- reading YouTube's answers ---------------------------------------------------------------------------

    /** "PT1H2M3S" -> 3723. Live streams ("P0D") and anything unreadable -> 0. */
    fun parseDuration(iso: String?): Int {
        if (iso.isNullOrBlank()) return 0
        val m = Regex("^P(?:(\\d+)D)?(?:T(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?)?$").matchEntire(iso.trim()) ?: return 0
        fun g(i: Int) = m.groupValues[i].toIntOrNull() ?: 0
        return g(1) * 86400 + g(2) * 3600 + g(3) * 60 + g(4)
    }

    /** Video ids of a search.list answer, in order. */
    fun parseSearchIds(json: String): List<String> = try {
        val items = JSONObject(json).optJSONArray("items") ?: JSONArray()
        (0 until items.length()).mapNotNull { items.getJSONObject(it).optJSONObject("id")?.optString("videoId")?.takeIf { s -> s.isNotEmpty() } }
    } catch (e: Exception) {
        emptyList()
    }

    fun parseNextPage(json: String): String? = try {
        JSONObject(json).optString("nextPageToken").takeIf { it.isNotEmpty() }
    } catch (e: Exception) {
        null
    }

    /** Video ids of a playlistItems.list answer (a channel's uploads). */
    fun parsePlaylistIds(json: String): List<String> = try {
        val items = JSONObject(json).optJSONArray("items") ?: JSONArray()
        (0 until items.length()).mapNotNull {
            items.getJSONObject(it).optJSONObject("contentDetails")?.optString("videoId")?.takeIf { s -> s.isNotEmpty() }
        }
    } catch (e: Exception) {
        emptyList()
    }

    /** Where YouTube keeps a video's picture; used when an answer came without one (always exists in 480 x 360). */
    fun fallbackThumb(id: String): String = "https://i.ytimg.com/vi/$id/hqdefault.jpg"

    /**
     * A web address of a picture the phone can really load: https only (plain http is blocked on Android), "//host/..." gets
     * https, and anything that is not a web address is treated as missing ("").
     */
    fun imageUrl(raw: String?): String {
        val t = raw?.trim().orEmpty()
        return when {
            t.startsWith("https://") -> t
            t.startsWith("//") -> "https:$t"
            t.startsWith("http://") -> "https://" + t.removePrefix("http://")
            else -> ""
        }
    }

    /** True when [body] looks like a JSON object (an HTML page from a login / error screen is not). */
    fun isAnswerObject(body: String): Boolean = body.trimStart().startsWith("{")

    /** Videos of a videos.list answer (parts snippet, contentDetails, status). Private and live ones are left out. */
    fun parseVideos(json: String): List<StudyVideo> = try {
        val items = JSONObject(json).optJSONArray("items") ?: JSONArray()
        // One broken item is skipped on its own: it must not take the whole answer down with it.
        (0 until items.length()).mapNotNull { i ->
            val o = items.optJSONObject(i) ?: return@mapNotNull null
            val id = o.optString("id")
            if (id.isEmpty()) return@mapNotNull null
            val sn = o.optJSONObject("snippet") ?: return@mapNotNull null
            val st = o.optJSONObject("status")
            if (st != null && st.optString("privacyStatus", "public") != "public") return@mapNotNull null
            if (sn.optString("liveBroadcastContent", "none") != "none") return@mapNotNull null
            val th = sn.optJSONObject("thumbnails")
            val thumb = imageUrl(
                listOf("maxres", "standard", "high", "medium", "default").firstNotNullOfOrNull { k -> th?.optJSONObject(k)?.optString("url")?.takeIf { it.isNotEmpty() } }
            ).ifEmpty { fallbackThumb(id) }
            StudyVideo(
                id = id,
                title = sn.optString("title").trim().ifEmpty { "Untitled video" },
                channelId = sn.optString("channelId"),
                channelTitle = sn.optString("channelTitle").trim(),
                thumbUrl = thumb,
                seconds = parseDuration(o.optJSONObject("contentDetails")?.optString("duration")),
                categoryId = sn.optString("categoryId"),
                embeddable = st?.optBoolean("embeddable", true) ?: true,
                publishedAt = parseTime(sn.optString("publishedAt")),
                description = sn.optString("description").trim().take(DESCRIPTION_MAX),
                audioLang = sn.optString("defaultAudioLanguage").ifEmpty { sn.optString("defaultLanguage") }.trim(),
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    /** First channel of a channels.list answer. */
    fun parseChannel(json: String): StudyChannel? = try {
        val o = JSONObject(json).optJSONArray("items")?.optJSONObject(0)
        val id = o?.optString("id").orEmpty()
        val name = o?.optJSONObject("snippet")?.optString("title").orEmpty()
        if (id.isNotEmpty()) StudyChannel(id, name.ifEmpty { id }) else null
    } catch (e: Exception) {
        null
    }

    /** Channels of a channels.list answer (parts snippet, statistics): name, handle, round picture, counts. */
    fun parseChannelInfos(json: String): List<StudyChannelInfo> = try {
        val items = JSONObject(json).optJSONArray("items") ?: JSONArray()
        (0 until items.length()).mapNotNull { i ->
            val o = items.getJSONObject(i)
            val id = o.optString("id").takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            val sn = o.optJSONObject("snippet")
            val st = o.optJSONObject("statistics")
            val th = sn?.optJSONObject("thumbnails")
            val pic = imageUrl(listOf("medium", "default", "high").firstNotNullOfOrNull { k -> th?.optJSONObject(k)?.optString("url")?.takeIf { it.isNotEmpty() } })
            val hidden = st?.optBoolean("hiddenSubscriberCount", false) ?: false
            StudyChannelInfo(
                id = id,
                name = sn?.optString("title").orEmpty().ifEmpty { id },
                handle = sn?.optString("customUrl").orEmpty(),
                avatarUrl = pic,
                subscribers = if (hidden) null else st?.optString("subscriberCount")?.toLongOrNull(),
                videoCount = st?.optString("videoCount")?.toLongOrNull(),
                country = sn?.optString("country").orEmpty().uppercase(),
                description = sn?.optString("description").orEmpty().trim().take(CHANNEL_DESCRIPTION_MAX),
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    /** 1234 -> "1.2K", 2500000 -> "2.5M". */
    fun formatCount(n: Long): String = when {
        n >= 1_000_000_000 -> trimCount(n / 1_000_000_000.0) + "B"
        n >= 1_000_000 -> trimCount(n / 1_000_000.0) + "M"
        n >= 1_000 -> trimCount(n / 1_000.0) + "K"
        else -> n.toString()
    }

    private fun trimCount(v: Double): String {
        val t = (Math.floor(v * 10) / 10.0)
        return if (t >= 100 || t == Math.floor(t)) t.toLong().toString() else t.toString()
    }

    /**
     * What went wrong, from an error answer of the API. The reason can sit in `error.errors[].reason`, in
     * `error.details[].reason` (newer key / app restriction errors) or in `error.status`: all three are read.
     * Order matters: a used-up DAILY quota rests until the reset, a "too many requests" answer rests only a minute,
     * a key problem rests a few minutes (see [StudyApi]), and everything else (5xx, odd answers) is not the key's fault.
     */
    fun parseError(httpCode: Int, body: String): StudyException {
        val reasons = ArrayList<String>()
        try {
            val err = JSONObject(body).optJSONObject("error")
            err?.optJSONArray("errors")?.let { a -> for (i in 0 until a.length()) reasons += a.optJSONObject(i)?.optString("reason").orEmpty() }
            err?.optJSONArray("details")?.let { a -> for (i in 0 until a.length()) reasons += a.optJSONObject(i)?.optString("reason").orEmpty() }
            reasons += err?.optString("status").orEmpty()
        } catch (e: Exception) {
            // not JSON: the code alone decides
        }
        fun has(vararg r: String) = reasons.any { it in r }
        return when {
            has("quotaExceeded", "dailyLimitExceeded") ->
                StudyException(StudyErrorKind.QUOTA, "Today's free YouTube limit is used up. It resets once a day.", reason = SourceReason.DAILY_LIMIT)
            has("rateLimitExceeded", "userRateLimitExceeded", "RATE_LIMIT_EXCEEDED", "RESOURCE_EXHAUSTED") || httpCode == 429 ->
                StudyException(StudyErrorKind.QUOTA, "YouTube is busy for a moment. Try again in a minute.", dailyLimit = false, reason = SourceReason.RATE_LIMIT)
            has("playlistNotFound", "channelNotFound", "videoNotFound", "notFound") || httpCode == 404 ->
                StudyException(StudyErrorKind.NOT_FOUND, "YouTube has nothing for this request.")
            has("keyInvalid", "API_KEY_INVALID") || httpCode == 400 && body.contains("API key", true) ->
                StudyException(StudyErrorKind.BAD_KEY, "This YouTube API key is not valid.", reason = SourceReason.INVALID_KEY)
            httpCode == 401 || httpCode == 403 ->
                StudyException(StudyErrorKind.BAD_KEY, "This key cannot use the YouTube Data API.", reason = SourceReason.KEY_REFUSED)
            // 5xx stays kind OTHER (the old fallback rule is unchanged); only the cause is named, for source detection.
            httpCode == 503 ->
                StudyException(StudyErrorKind.OTHER, "YouTube did not answer properly (code $httpCode).", reason = SourceReason.SERVICE_UNAVAILABLE)
            httpCode in 500..599 ->
                StudyException(StudyErrorKind.OTHER, "YouTube did not answer properly (code $httpCode).", reason = SourceReason.SERVER_ERROR)
            else -> StudyException(StudyErrorKind.OTHER, "YouTube did not answer properly (code $httpCode).", reason = SourceReason.UNKNOWN_ERROR)
        }
    }

    // ---- channels the person adds ------------------------------------------------------------------------------

    private val CHANNEL_ID = Regex("^UC[A-Za-z0-9_-]{22}$")
    private val HANDLE = Regex("^[A-Za-z0-9._-]{3,}$")

    /** A pasted channel: "@name", "youtube.com/@name", "youtube.com/channel/UC...", or a bare channel id. Null when unusable. */
    fun parseChannelRef(raw: String): ChannelRef? {
        var t = raw.trim().trim('<', '>', '"', '\'')
        if (t.isEmpty()) return null
        if (CHANNEL_ID.matches(t)) return ChannelRef.Id(t)
        if (t.contains("/")) {
            val path = t.substringAfter("://").substringAfter('/').substringBefore('?').substringBefore('#')
            val host = t.substringAfter("://").substringBefore('/').lowercase().removePrefix("www.").removePrefix("m.")
            if (!host.endsWith("youtube.com")) return null
            val parts = path.split('/').filter { it.isNotEmpty() }
            val first = parts.firstOrNull() ?: return null
            return when {
                first.startsWith("@") -> HANDLE.matchEntire(first.drop(1))?.let { ChannelRef.Handle(first.drop(1)) }
                first == "channel" -> parts.getOrNull(1)?.takeIf { CHANNEL_ID.matches(it) }?.let { ChannelRef.Id(it) }
                else -> null
            }
        }
        t = t.removePrefix("@")
        return if (HANDLE.matches(t)) ChannelRef.Handle(t) else null
    }

    /** The "uploads" playlist of a channel id (UCxxxx -> UUxxxx). */
    fun uploadsPlaylist(channelId: String): String = "UU" + channelId.removePrefix("UC")

    /**
     * The heading of an error card. It names the source that failed (YouTube API, Direct YouTube or the Web search) and keeps
     * a used-up API limit apart from a plain network problem.
     */
    fun errorTitle(e: StudyException, searching: Boolean): String {
        // Every source failed: the switcher wrote one clear heading for it (see SwitchMessages).
        if (e is SourcesExhausted) return e.title
        return when (e.kind) {
            StudyErrorKind.QUOTA -> if (e.dailyLimit) "YouTube API limit reached" else "YouTube API is busy"
            StudyErrorKind.BAD_KEY, StudyErrorKind.NO_KEY -> "YouTube API is not available"
            StudyErrorKind.NETWORK -> when (e.source) {
                StudyMode.API -> "Could not reach the YouTube API"
                StudyMode.PAGE -> "Could not reach YouTube"
                StudyMode.WEB -> "Could not load the web search"
            }
            StudyErrorKind.BAD_ANSWER -> when (e.source) {
                StudyMode.API -> "YouTube API gave an unreadable answer"
                StudyMode.PAGE -> "YouTube's page could not be read"
                StudyMode.WEB -> "The web page could not be read"
            }
            StudyErrorKind.NOT_FOUND -> "Nothing found"
            StudyErrorKind.OTHER -> if (searching) "Search failed" else "Could not load videos"
        }
    }

    // ---- cache -----------------------------------------------------------------------------------------------

    fun toJson(list: List<StudyVideo>): String = JSONArray().also { arr ->
        list.forEach { v ->
            arr.put(
                JSONObject().put("id", v.id).put("t", v.title).put("ci", v.channelId).put("cn", v.channelTitle)
                    .put("th", v.thumbUrl).put("s", v.seconds).put("cat", v.categoryId).put("e", v.embeddable).put("p", v.publishedAt)
                    .put("d", v.description).put("al", v.audioLang)
            )
        }
    }.toString()

    /** Saved videos back. A damaged entry is skipped on its own (before, one bad entry threw the whole saved list away). */
    fun fromJson(json: String?): List<StudyVideo> {
        val arr = try { JSONArray(json ?: "[]") } catch (e: Exception) { return emptyList() }
        val out = ArrayList<StudyVideo>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isEmpty()) continue
            out += StudyVideo(
                id, o.optString("t").ifEmpty { "Untitled video" }, o.optString("ci"), o.optString("cn"),
                o.optString("th").ifEmpty { fallbackThumb(id) }, o.optInt("s"), o.optString("cat"), o.optBoolean("e", true),
                o.optLong("p", 0L), o.optString("d"), o.optString("al"),
            )
        }
        return out
    }

    /** "2024-05-01T10:20:30Z" (YouTube's upload time) -> milliseconds since 1970; 0 when unreadable. */
    fun parseTime(iso: String?): Long {
        if (iso.isNullOrBlank()) return 0L
        return try {
            val clean = iso.trim().replace(Regex("\\.\\d+"), "").removeSuffix("Z")
            val f = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
            f.timeZone = java.util.TimeZone.getTimeZone("UTC")
            f.parse(clean)?.time ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    private val AGO = Regex("(\\d+)\\s*(second|minute|hour|day|week|month|year)s?\\s+ago", RegexOption.IGNORE_CASE)

    /**
     * YouTube's search page only says "3 days ago" / "Streamed 2 weeks ago" (no date). This turns such a label found anywhere in
     * [text] (for example "1.2M views 3 days ago") into an approximate upload time; 0 when the text has no such label.
     */
    fun parseAgoLabel(text: String?, now: Long = System.currentTimeMillis()): Long {
        val m = AGO.find(text.orEmpty()) ?: return 0L
        val n = m.groupValues[1].toLongOrNull() ?: return 0L
        val minute = 60_000L
        val unit = when (m.groupValues[2].lowercase()) {
            "second" -> 1_000L
            "minute" -> minute
            "hour" -> 60 * minute
            "day" -> 24 * 60 * minute
            "week" -> 7 * 24 * 60 * minute
            "month" -> 30 * 24 * 60 * minute
            else -> 365 * 24 * 60 * minute
        }
        return (now - n * unit).coerceAtLeast(1L)
    }

    /** "2024-05-01T10:20:30-07:00" or "2024-05-01" (the watch page's upload time) -> milliseconds since 1970; 0 when unreadable. */
    fun parseIsoDate(iso: String?): Long {
        val t = iso?.trim().orEmpty()
        if (t.isEmpty()) return 0L
        val patterns = listOf("yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd")
        for (pt in patterns) {
            try {
                val f = java.text.SimpleDateFormat(pt, java.util.Locale.US)
                if (pt == "yyyy-MM-dd") f.timeZone = java.util.TimeZone.getTimeZone("UTC")
                val d = f.parse(t.replace(Regex("\\.\\d+"), ""))
                if (d != null) return d.time
            } catch (e: Exception) {
                // try the next pattern
            }
        }
        return 0L
    }

    /** "5 minutes ago", "3 hours ago", "2 days ago", "3 weeks ago", "4 months ago", "1 year ago" (like YouTube); "" when unknown. */
    fun timeAgo(publishedAt: Long, now: Long = System.currentTimeMillis()): String {
        if (publishedAt <= 0L) return ""
        val minutes = ((now - publishedAt) / 60_000L).coerceAtLeast(0L)
        fun unit(n: Long, name: String) = "$n $name" + (if (n == 1L) "" else "s") + " ago"
        val hours = minutes / 60
        val days = hours / 24
        return when {
            minutes < 1 -> "just now"
            minutes < 60 -> unit(minutes, "minute")
            hours < 24 -> unit(hours, "hour")
            days < 7 -> unit(days, "day")
            days < 30 -> unit(days / 7, "week")
            days < 365 -> unit(days / 30, "month")
            else -> unit(days / 365, "year")
        }
    }

    /** "1:02:03" / "12:05" / "0:45". */
    fun formatLength(seconds: Int): String {
        val h = seconds / 3600
        val m = seconds % 3600 / 60
        val s = seconds % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    /** Subjects rotated by [slot] so each refresh looks at a different few (saves the daily free limit). */
    /**
     * Keeps the order, but puts channels of other countries after the Indian ones (or leaves them out when [dropForeign]).
     * A channel is "foreign" only when it clearly set another country: no country, a trusted channel or India = not foreign.
     * [countries]: channel id -> country. If dropping would leave nothing, nothing is dropped.
     */
    fun indiaFirst(list: List<StudyVideo>, countries: Map<String, String>, trusted: Set<String>, dropForeign: Boolean): List<StudyVideo> {
        fun foreign(v: StudyVideo): Boolean {
            if (v.channelId in trusted) return false
            val c = countries[v.channelId].orEmpty()
            return c.isNotEmpty() && c != "IN"
        }
        val (abroad, home) = list.partition(::foreign)
        return if (dropForeign && home.isNotEmpty()) home else home + abroad
    }

    fun pickSubjects(subjects: List<String>, count: Int, slot: Long): List<String> {
        if (subjects.size <= count) return subjects
        val start = (slot % subjects.size).toInt()
        return List(count) { subjects[(start + it) % subjects.size] }
    }
}
