package com.focusmode.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.focusmode.app.R

@Immutable
data class FocusColors(
    val background: Color,
    val card: Color,
    val cardHigh: Color,
    val stroke: Color,
    val accent: Color,
    val accentSoft: Color,
    val onAccent: Color,
    val text: Color,
    val muted: Color,
    val ringTrack: Color,
    val warning: Color,
    val isDark: Boolean,
    // Plant palette
    val trunk: Color,
    val leafLight: Color,
    val leafMid: Color,
    val leafDeep: Color,
    val blossom: Color,
    val soil: Color,
    // Neon gradient used for the main buttons, the active tab and the timer ring.
    val gradStart: Color,
    val gradMid: Color,
    val gradEnd: Color,
    val glow: Color,
)

private val DarkFocusColors = FocusColors(
    background = Color(0xFF090514),
    card = Color(0xFF140C2C),
    cardHigh = Color(0xFF1D1340),
    stroke = Color(0xFF33225F),
    accent = Color(0xFFC044FF),
    accentSoft = Color(0xFF2A1650),
    onAccent = Color(0xFFFFFFFF),
    text = Color(0xFFFFFFFF),
    muted = Color(0xFFB9B0DA),
    ringTrack = Color(0xFF241743),
    warning = Color(0xFFFFC107),
    isDark = true,
    trunk = Color(0xFF9C7A5B),
    leafLight = Color(0xFF8DF0BD),
    leafMid = Color(0xFF4ADE9C),
    leafDeep = Color(0xFF1FA774),
    blossom = Color(0xFFFFB3C7),
    soil = Color(0xFF2A2119),
    gradStart = Color(0xFF7C3AED),
    gradMid = Color(0xFFC026D3),
    gradEnd = Color(0xFFEC4899),
    glow = Color(0xFFC044FF),
)

private val LightFocusColors = FocusColors(
    background = Color(0xFFF7F3FF),
    card = Color(0xFFFFFFFF),
    cardHigh = Color(0xFFF0E9FF),
    stroke = Color(0xFFE3D8F8),
    accent = Color(0xFF7C3AED),
    accentSoft = Color(0xFFEDE3FF),
    onAccent = Color(0xFFFFFFFF),
    text = Color(0xFF1B1033),
    muted = Color(0xFF6B5F8A),
    ringTrack = Color(0xFFE6DCF8),
    warning = Color(0xFFB9791B),
    isDark = false,
    trunk = Color(0xFF8A6A4C),
    leafLight = Color(0xFF7FD6A6),
    leafMid = Color(0xFF3DB17D),
    leafDeep = Color(0xFF1F7A56),
    blossom = Color(0xFFF08FB0),
    soil = Color(0xFFD9CDB8),
    gradStart = Color(0xFF7C3AED),
    gradMid = Color(0xFFA855F7),
    gradEnd = Color(0xFFDB2777),
    glow = Color(0xFF9333EA),
)

val LocalFocusColors = staticCompositionLocalOf { DarkFocusColors }

object FocusTheme {
    val colors: FocusColors
        @Composable @ReadOnlyComposable get() = LocalFocusColors.current
}

/** Poppins (res/font/poppins.ttf). Bold and semi-bold are drawn by Android from the regular weight. */
val PoppinsFamily = FontFamily(Font(R.font.poppins, FontWeight.Normal))
private val Sans = PoppinsFamily
private val Serif = PoppinsFamily

private val FocusTypography = Typography(
    displayLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 56.sp, letterSpacing = (-1).sp),
    displayMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 44.sp, letterSpacing = (-0.5).sp),
    headlineLarge = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 32.sp, lineHeight = 38.sp),
    headlineMedium = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, letterSpacing = (-0.2).sp),
    titleMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
    bodyLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, letterSpacing = 0.2.sp),
    labelMedium = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 12.sp, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 11.sp, letterSpacing = 1.2.sp),
)

/** [themeMode]: 0 = follow system, 1 = light, 2 = dark. */
@Composable
fun FocusModeTheme(themeMode: Int, content: @Composable () -> Unit) {
    val dark = when (themeMode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val c = if (dark) DarkFocusColors else LightFocusColors
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent,
            background = c.background, onBackground = c.text,
            surface = c.card, onSurface = c.text,
            surfaceVariant = c.cardHigh, onSurfaceVariant = c.muted,
            outline = c.stroke, secondaryContainer = c.accentSoft, onSecondaryContainer = c.text,
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent,
            background = c.background, onBackground = c.text,
            surface = c.card, onSurface = c.text,
            surfaceVariant = c.cardHigh, onSurfaceVariant = c.muted,
            outline = c.stroke, secondaryContainer = c.accentSoft, onSecondaryContainer = c.text,
        )
    }
    CompositionLocalProvider(
        LocalFocusColors provides c,
        LocalContentColor provides c.text,
    ) {
        MaterialTheme(colorScheme = scheme, typography = FocusTypography, content = content)
    }
}
