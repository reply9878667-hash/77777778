package com.focusmode.app.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.focusmode.app.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Everything the Study section remembers: the YouTube API key the person pasted (or the one built into the app), the
 * subjects they follow, their trusted channels, and the last results (so the section opens at once and saves the free
 * daily YouTube limit). SharedPreferences only; the rules live in [StudyRules].
 */
class StudyStore private constructor(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Sent with every YouTube call, so a key restricted to "Android apps" (package + SHA-1) accepts this app. */
    val androidPackage: String get() = appContext.packageName

    /** SHA-1 of the certificate this APK is signed with, as 40 hex capitals (empty if it cannot be read). */
    val androidCertSha1: String by lazy { computeCertSha1() }

    @Suppress("DEPRECATION")
    private fun computeCertSha1(): String = try {
        val pm = appContext.packageManager
        val sig = if (Build.VERSION.SDK_INT >= 28) {
            pm.getPackageInfo(appContext.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            pm.getPackageInfo(appContext.packageName, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()
        }
        if (sig == null) "" else MessageDigest.getInstance("SHA-1").digest(sig.toByteArray()).joinToString("") { "%02X".format(it) }
    } catch (e: Exception) {
        ""
    }

    /** True once the "benefits of Study mode" popup was shown (it appears only the first time Study is opened). */
    var benefitsSeen: Boolean
        get() = prefs.getBoolean(KEY_BENEFITS_SEEN, false)
        set(v) { prefs.edit().putBoolean(KEY_BENEFITS_SEEN, v).apply() }

    /** The key built into this APK (nothing is typed in the app any more); an old saved key is only a fallback. */
    var apiKey: String
        get() = BuildConfig.YOUTUBE_API_KEY.trim().ifEmpty { prefs.getString(KEY_API, "").orEmpty().trim() }
        set(v) { prefs.edit().putString(KEY_API, v.trim()).apply() }

    /** The key field may hold several keys separated by commas, spaces or new lines; they are tried in this order. */
    val apiKeyList: List<String> get() = apiKey.split(Regex("[\\s,;]+")).filter { it.length >= 20 }

    private fun deadId(key: String) = "dead_" + key.takeLast(10)

    /** True while this key is resting (its daily limit is used up, or YouTube refused it a moment ago). */
    fun isKeyResting(key: String): Boolean = System.currentTimeMillis() < prefs.getLong(deadId(key), 0L)

    /** Rests a key until [untilMs] (epoch). Kept on the phone, so every later call skips it at once. [why] = QUOTA (limit) or BAD_KEY (refused). */
    fun restKey(key: String, untilMs: Long, why: StudyErrorKind = StudyErrorKind.QUOTA) {
        prefs.edit().putLong(deadId(key), untilMs).putString(deadId(key) + "_why", why.name).apply()
    }

    /** When [key] stops resting (epoch ms); 0 or the past = it does not rest. */
    fun restUntil(key: String): Long = prefs.getLong(deadId(key), 0L)

    /**
     * The on / off switch of a source (API, Direct YouTube, Web). Always on until switched off; there is no screen for it
     * yet, so today only code can switch one off. A switched-off source shows as DISABLED, nothing else.
     */
    fun isSourceEnabled(mode: StudyMode): Boolean = prefs.getBoolean(KEY_SOURCE_ON + mode.name, true)

    fun setSourceEnabled(mode: StudyMode, on: Boolean) { prefs.edit().putBoolean(KEY_SOURCE_ON + mode.name, on).apply() }

    /** Why [key] rests: a used-up limit (QUOTA, also when nothing was saved) or a refused key (BAD_KEY). */
    fun restReason(key: String): StudyErrorKind =
        if (prefs.getString(deadId(key) + "_why", null) == StudyErrorKind.BAD_KEY.name) StudyErrorKind.BAD_KEY else StudyErrorKind.QUOTA

    /** True when at least one key can still be asked (none is resting). False = the daily limit is used up for now. */
    val apiAvailable: Boolean get() = apiKeyList.any { !isKeyResting(it) }

    /** True when the key comes from the app itself, so nothing needs to be typed. */
    val keyBuiltIn: Boolean get() = BuildConfig.YOUTUBE_API_KEY.isNotBlank()

    /** Subjects the person can pick from (defaults plus their own). */
    var subjects: List<String>
        get() = readList(KEY_SUBJECTS) ?: StudyRules.DEFAULT_SUBJECTS
        set(v) { prefs.edit().putString(KEY_SUBJECTS, JSONArray(v).toString()).apply() }

    /** Subjects switched on (they shape the suggestions). Empty = all of [subjects]. */
    var selected: List<String>
        get() = readList(KEY_SELECTED).orEmpty()
        set(v) { prefs.edit().putString(KEY_SELECTED, JSONArray(v).toString()).apply() }

    var channels: List<StudyChannel>
        get() = try {
            val arr = JSONArray(prefs.getString(KEY_CHANNELS, "[]"))
            (0 until arr.length()).map { arr.getJSONObject(it).let { o -> StudyChannel(o.getString("id"), o.optString("n")) } }
        } catch (e: Exception) {
            emptyList()
        }
        set(v) {
            val arr = JSONArray()
            v.forEach { arr.put(JSONObject().put("id", it.id).put("n", it.name)) }
            prefs.edit().putString(KEY_CHANNELS, arr.toString()).apply()
        }

    /** New-video notifications for followed channels: always on (there is no switch in the app any more). */
    val alertsOn: Boolean get() = true

    /** Ids of uploads already seen (oldest first, capped), so one video is announced only once. */
    var seenIds: List<String>
        get() = readList(KEY_SEEN).orEmpty()
        set(v) { prefs.edit().putString(KEY_SEEN, JSONArray(v).toString()).apply() }

    /** A channel's first look only remembers what is already there; it never notifies about old videos. */
    fun isSeeded(channelId: String): Boolean = prefs.getBoolean(SEEDED + channelId, false)
    fun markSeeded(channelId: String) { prefs.edit().putBoolean(SEEDED + channelId, true).apply() }
    fun forgetSeeded(channelId: String) { prefs.edit().remove(SEEDED + channelId).apply() }

    /** Videos of recent new-video notifications, so a tap can open the right one (newest last, few kept). */
    fun setPendingOpen(v: StudyVideo) {
        val list = StudyRules.fromJson(prefs.getString(KEY_PENDING, null)).filter { it.id != v.id } + v
        prefs.edit().putString(KEY_PENDING, StudyRules.toJson(list.takeLast(8))).apply()
    }

    /** Called when the notification of video [id] is tapped; Study opens that video once. */
    fun armPending(id: String) { prefs.edit().putString(KEY_ARMED, id).apply() }

    fun takePendingOpen(): StudyVideo? {
        val id = prefs.getString(KEY_ARMED, null)?.takeIf { it.isNotEmpty() } ?: return null
        prefs.edit().remove(KEY_ARMED).apply()
        return StudyRules.fromJson(prefs.getString(KEY_PENDING, null)).firstOrNull { it.id == id }
    }

    /** Channels of the videos the person played in Study, with how often (so suggestions come from the same channels). */
    private fun readWatched(): MutableMap<String, Pair<String, Int>> {
        val out = LinkedHashMap<String, Pair<String, Int>>()
        try {
            val arr = JSONArray(prefs.getString(KEY_WATCHED, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out[o.getString("id")] = o.optString("n") to o.optInt("c", 1)
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun noteWatched(channelId: String, name: String) {
        if (channelId.isEmpty()) return
        val m = readWatched()
        val old = m[channelId]
        m[channelId] = name.ifEmpty { old?.first.orEmpty() } to ((old?.second ?: 0) + 1)
        val arr = JSONArray()
        m.entries.sortedByDescending { it.value.second }.take(MAX_WATCHED).forEach {
            arr.put(JSONObject().put("id", it.key).put("n", it.value.first).put("c", it.value.second))
        }
        prefs.edit().putString(KEY_WATCHED, arr.toString()).apply()
    }

    /** The channels played most, best first. */
    fun topWatched(count: Int): List<StudyChannel> =
        readWatched().entries.sortedByDescending { it.value.second }.take(count).map { StudyChannel(it.key, it.value.first) }

    /** "Start Focus Mode" was pressed on the video player: Study picks this video up when the app comes back. */
    fun armFocusStart(v: StudyVideo) {
        prefs.edit().putString(KEY_FOCUS_START, StudyRules.toJson(listOf(v))).apply()
    }

    fun takeFocusStart(): StudyVideo? {
        val raw = prefs.getString(KEY_FOCUS_START, null) ?: return null
        prefs.edit().remove(KEY_FOCUS_START).apply()
        return StudyRules.fromJson(raw).firstOrNull()
    }

    /** The last searches (newest first), shown when the search box is opened empty, like YouTube's history. */
    val recents: List<String> get() = readList(KEY_RECENT).orEmpty()

    fun addRecent(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        val list = (listOf(t) + recents.filter { !it.equals(t, ignoreCase = true) }).take(MAX_RECENT)
        prefs.edit().putString(KEY_RECENT, JSONArray(list).toString()).apply()
    }

    fun removeRecent(q: String) {
        prefs.edit().putString(KEY_RECENT, JSONArray(recents.filter { !it.equals(q, ignoreCase = true) }).toString()).apply()
    }

    // ---- the bell: new videos of followed channels, kept even when the phone's notification is off ----

    fun inbox(): List<StudyVideo> = StudyRules.fromJson(prefs.getString(KEY_INBOX, null))

    fun addToInbox(v: StudyVideo) {
        val list = (listOf(v) + inbox().filter { it.id != v.id }).take(MAX_INBOX)
        val unread = (readList(KEY_UNREAD).orEmpty().filter { it != v.id } + v.id).takeLast(MAX_INBOX)
        prefs.edit().putString(KEY_INBOX, StudyRules.toJson(list)).putString(KEY_UNREAD, JSONArray(unread).toString()).apply()
    }

    fun unreadCount(): Int {
        val ids = inbox().map { it.id }.toSet()
        return readList(KEY_UNREAD).orEmpty().count { it in ids }
    }

    fun markInboxRead() { prefs.edit().remove(KEY_UNREAD).apply() }

    fun clearInbox() { prefs.edit().remove(KEY_INBOX).remove(KEY_UNREAD).apply() }

    // ---- channel pictures ----

    /** Channel id -> round picture address ("" = the channel has none). */
    fun avatars(): Map<String, String> = try {
        val o = JSONObject(prefs.getString(KEY_AVATARS, "{}"))
        o.keys().asSequence().associateWith { o.optString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    fun saveAvatars(more: Map<String, String>) {
        val merged = (avatars() + more).toList().takeLast(MAX_AVATARS).toMap()
        prefs.edit().putString(KEY_AVATARS, JSONObject(merged).toString()).apply()
    }

    // ---- channel countries (to show mostly Indian channels, like YouTube does for an Indian viewer) ----

    /** Channel id -> two-letter country the channel set ("" = it set none). */
    fun countries(): Map<String, String> = try {
        val o = JSONObject(prefs.getString(KEY_COUNTRIES, "{}"))
        o.keys().asSequence().associateWith { o.optString(it) }
    } catch (e: Exception) {
        emptyMap()
    }

    fun saveCountries(more: Map<String, String>) {
        val merged = (countries() + more).toList().takeLast(MAX_COUNTRIES).toMap()
        prefs.edit().putString(KEY_COUNTRIES, JSONObject(merged).toString()).apply()
    }

    fun isFollowing(channelId: String): Boolean = channels.any { it.id == channelId }

    fun follow(channelId: String, name: String) {
        if (!isFollowing(channelId)) {
            channels = channels + StudyChannel(channelId, name.ifEmpty { channelId })
            setFollowedAt(channelId, System.currentTimeMillis())
        }
    }

    /** When this channel was followed (epoch ms); 0 = not known (followed by an older version). */
    fun followedAt(channelId: String): Long = prefs.getLong(FOLLOWED + channelId, 0L)
    fun setFollowedAt(channelId: String, at: Long) { prefs.edit().putLong(FOLLOWED + channelId, at).apply() }

    /** The last time the new-video check ran (epoch ms, 0 = never) and a short plain-words result of it. */
    var lastCheckAt: Long
        get() = prefs.getLong(KEY_LAST_CHECK_AT, 0L)
        set(v) { prefs.edit().putLong(KEY_LAST_CHECK_AT, v).apply() }
    var lastCheckNote: String
        get() = prefs.getString(KEY_LAST_CHECK_NOTE, "").orEmpty()
        set(v) { prefs.edit().putString(KEY_LAST_CHECK_NOTE, v).apply() }

    fun unfollow(channelId: String) {
        channels = channels.filter { it.id != channelId }
        forgetSeeded(channelId)
        prefs.edit().remove(FOLLOWED + channelId).apply()
        removeAlertMode(channelId)
    }

    // ---- notification choice per subscribed channel (All / Personalized / None), kept until changed ----

    private fun readAlertModes(): JSONObject = try {
        JSONObject(prefs.getString(KEY_ALERT_MODES, "{}"))
    } catch (e: Exception) {
        JSONObject()
    }

    /** This channel's choice; a channel that never chose is [ChannelAlerts.ALL]. */
    fun alertMode(channelId: String): ChannelAlerts = ChannelAlerts.fromKey(readAlertModes().optString(channelId, null))

    fun setAlertMode(channelId: String, mode: ChannelAlerts) {
        // Turned on again after "None": only uploads from now on are new (the first look must not flood with the old ones).
        if (alertMode(channelId) == ChannelAlerts.NONE && mode != ChannelAlerts.NONE) setFollowedAt(channelId, System.currentTimeMillis())
        prefs.edit().putString(KEY_ALERT_MODES, readAlertModes().put(channelId, mode.key).toString()).apply()
        // While it is off nothing is looked at; when it is back on, the first look is silent so old uploads do not flood.
        if (mode == ChannelAlerts.NONE) forgetSeeded(channelId)
    }

    private fun removeAlertMode(channelId: String) {
        prefs.edit().putString(KEY_ALERT_MODES, readAlertModes().also { it.remove(channelId) }.toString()).apply()
    }

    /** A cached list of videos and the time it was saved, or null. */
    fun cached(key: String, maxAgeMs: Long, now: Long = System.currentTimeMillis()): List<StudyVideo>? {
        val at = prefs.getLong(CACHE_AT + key.hashCode(), 0L)
        if (at == 0L || now - at > maxAgeMs) return null
        return StudyRules.fromJson(prefs.getString(CACHE + key.hashCode(), null))
    }

    fun saveCache(key: String, list: List<StudyVideo>, now: Long = System.currentTimeMillis()) {
        prefs.edit().putString(CACHE + key.hashCode(), StudyRules.toJson(list)).putLong(CACHE_AT + key.hashCode(), now).apply()
    }

    fun clearCache() {
        val e = prefs.edit()
        prefs.all.keys.filter { it.startsWith(CACHE) || it.startsWith(CACHE_AT) }.forEach { e.remove(it) }
        e.apply()
    }

    private fun readList(key: String): List<String>? {
        val raw = prefs.getString(key, null) ?: return null
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        private const val FILE = "study"
        private const val KEY_API = "api_key"
        private const val KEY_SOURCE_ON = "source_on_"
        private const val KEY_SUBJECTS = "subjects"
        private const val KEY_SELECTED = "selected"
        private const val KEY_CHANNELS = "channels"
        private const val KEY_ALERT_MODES = "channel_alert_modes"
        private const val KEY_WATCHED = "watched_channels"
        private const val KEY_FOCUS_START = "focus_start"
        private const val MAX_WATCHED = 12
        private const val KEY_RECENT = "recent_searches"
        private const val KEY_BENEFITS_SEEN = "benefits_seen"
        private const val MAX_RECENT = 10
        private const val KEY_INBOX = "inbox"
        private const val KEY_UNREAD = "inbox_unread"
        private const val MAX_INBOX = 30
        private const val KEY_AVATARS = "avatars"
        private const val MAX_AVATARS = 400
        private const val KEY_COUNTRIES = "countries"
        private const val MAX_COUNTRIES = 800
        private const val KEY_SEEN = "seen_ids"
        private const val KEY_PENDING = "pending_open"
        private const val KEY_ARMED = "armed_open"
        private const val SEEDED = "seeded_"
        private const val FOLLOWED = "followed_"
        private const val KEY_LAST_CHECK_AT = "updates_last_check_at"
        private const val KEY_LAST_CHECK_NOTE = "updates_last_check_note"
        private const val CACHE = "cache_"
        private const val CACHE_AT = "cache_at_"

        @Volatile private var instance: StudyStore? = null

        fun get(context: Context): StudyStore =
            instance ?: synchronized(this) {
                instance ?: StudyStore(context.applicationContext).also { instance = it }
            }
    }
}
