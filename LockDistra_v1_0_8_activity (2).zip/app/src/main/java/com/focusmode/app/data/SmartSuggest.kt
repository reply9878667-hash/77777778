package com.focusmode.app.data

/** One feature LockDistra can suggest: what it is called, what it does and why it helps. Plain text only, never an advertisement. */
data class SuggestFeature(
    val id: String,
    val title: String,
    val what: String,
    val benefits: List<String>,
    val actionLabel: String,
)

/** What is remembered about one suggestion. */
data class SuggestLog(
    /** How many times it was shown. */
    val shown: Int = 0,
    /** The app-open count when it was last shown (so it is not shown again at once). */
    val lastShownOpen: Int = 0,
    /** "Don't show again": never suggested again. */
    val dismissed: Boolean = false,
    /** The person has used this feature at least once (recorded when it is seen in use). */
    val usedEver: Boolean = false,
)

data class SuggestState(
    val enabled: Boolean = true,
    /** How many times the app was opened. */
    val opens: Int = 0,
    val lastShownAt: Long = 0L,
    val logs: Map<String, SuggestLog> = emptyMap(),
) {
    fun log(id: String): SuggestLog = logs[id] ?: SuggestLog()
}

/**
 * Smart Feature Suggestions: a short card that points out a useful feature the person has not tried.
 * No Android classes, so the rules are unit-tested.
 *
 * A feature is suggested only when ALL of these hold:
 *  - it is not in use (switched on / set up / used before) and was not dismissed for good;
 *  - the app has been opened at least [FIRST_AFTER_OPENS] times (a feature left unused for one or two openings);
 *  - it was shown fewer than [MAX_SHOWS] times, and at least [OPENS_BETWEEN] app openings have passed since it was last shown;
 *  - at least [COOLDOWN_MS] have passed since ANY suggestion was shown, so there is never more than one at a time.
 * Features are tried in the order of [features], most useful first.
 */
object SmartSuggest {

    const val FIRST_AFTER_OPENS = 2
    const val OPENS_BETWEEN = 3
    const val MAX_SHOWS = 2
    const val COOLDOWN_MS = 12L * 60 * 60 * 1000

    const val LECTURE = "lecture"
    const val BEDTIME = "bedtime"
    const val FOCUS_PROFILE = "focus_profile"
    const val WEBSITE_BLOCKING = "website_blocking"
    const val AUTO_FOCUS = "auto_focus"
    const val ADULT_BLOCKING = "adult_blocking"
    const val LIMITS = "limits"
    const val POMODORO = "pomodoro"
    const val APP_LOCK = "app_lock"

    val features: List<SuggestFeature> = listOf(
        SuggestFeature(
            LECTURE, "Play a lecture with a video link",
            "Paste a lecture link when you start Focus Mode. It plays inside LockDistra and only that video can play.",
            listOf(
                "High-quality video playback with speed and quality controls",
                "Learning without distractions: other videos stay closed",
                "Focus Mode turns OFF by itself when the lecture ends",
            ),
            "Start with a lecture",
        ),
        SuggestFeature(
            AUTO_FOCUS, "Automatic Focus Mode",
            "Choose a start and end time and the days. Focus Mode then turns on and off by itself.",
            listOf(
                "A study routine without having to remember to start",
                "Works even when LockDistra is closed",
                "Pick only the days you need",
            ),
            "Set a schedule",
        ),
        SuggestFeature(
            FOCUS_PROFILE, "Focus Profiles",
            "Save different sets of blocked apps, games and websites, for example one for study and one for work.",
            listOf(
                "Switch between routines in one tap",
                "Each profile has its own limits and website rules",
                "No need to change settings before every session",
            ),
            "Create a profile",
        ),
        SuggestFeature(
            WEBSITE_BLOCKING, "Website blocking",
            "Close distracting websites in your browser while a session runs or an app's limit is used up.",
            listOf(
                "Stops the browser from becoming a way around a blocked app",
                "Blocks a site together with its subdomains",
                "Set up once per app",
            ),
            "Choose websites",
        ),
        SuggestFeature(
            BEDTIME, "Bedtime mode",
            "Pick apps that close automatically at night, between a start and an end time.",
            listOf(
                "Less late-night scrolling, better sleep",
                "Runs on its own every night",
                "You choose exactly which apps close",
            ),
            "Set up Bedtime",
        ),
        SuggestFeature(
            ADULT_BLOCKING, "Adult content protection",
            "Blocks adult websites in your browsers and apps with one switch.",
            listOf(
                "Nothing to add yourself: a built-in list does the work",
                "Works even without a focus session",
                "Keeps working after a restart",
            ),
            "Open protection",
        ),
        SuggestFeature(
            LIMITS, "Daily app limits",
            "Give an app a daily time limit instead of blocking it completely. It closes when the time is used up.",
            listOf(
                "Keep useful apps without losing hours to them",
                "A warning comes before the time ends",
                "The limit resets every day",
            ),
            "Set a limit",
        ),
        SuggestFeature(
            POMODORO, "Pomodoro",
            "Short focus rounds with breaks in between. Blocked apps open again during each break.",
            listOf(
                "Study in rounds that are easy to start",
                "Breaks are built in, so you don't burn out",
                "Repeats until you stop it",
            ),
            "Show me",
        ),
        SuggestFeature(
            APP_LOCK, "App lock",
            "Protect LockDistra with a PIN, password or fingerprint, and use it as the way to turn Focus Mode off.",
            listOf(
                "A rule can't be undone in a weak moment",
                "Fingerprint unlock for quick access",
                "Others can't change your settings",
            ),
            "Open settings",
        ),
    )

    private val byId: Map<String, SuggestFeature> = features.associateBy { it.id }
    fun feature(id: String): SuggestFeature? = byId[id]

    /**
     * The suggestion to show now, or null. [inUse] holds the ids of features that are currently in use.
     */
    fun pick(state: SuggestState, inUse: Set<String>, now: Long, catalog: List<SuggestFeature> = features): SuggestFeature? {
        if (!state.enabled) return null
        if (state.opens < FIRST_AFTER_OPENS) return null
        if (state.lastShownAt != 0L && now - state.lastShownAt < COOLDOWN_MS) return null
        return catalog.firstOrNull { f ->
            val log = state.log(f.id)
            f.id !in inUse && !log.usedEver && !log.dismissed && log.shown < MAX_SHOWS &&
                (log.shown == 0 || state.opens - log.lastShownOpen >= OPENS_BETWEEN)
        }
    }

    /** Applies "this suggestion was shown". */
    fun withShown(state: SuggestState, id: String, now: Long): SuggestState {
        val l = state.log(id)
        return state.copy(
            lastShownAt = now,
            logs = state.logs + (id to l.copy(shown = l.shown + 1, lastShownOpen = state.opens)),
        )
    }

    fun withDismissed(state: SuggestState, id: String): SuggestState =
        state.copy(logs = state.logs + (id to state.log(id).copy(dismissed = true)))

    fun withUsed(state: SuggestState, id: String): SuggestState {
        val l = state.log(id)
        return if (l.usedEver) state else state.copy(logs = state.logs + (id to l.copy(usedEver = true)))
    }
}
