package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

/** A daily usage limit for one app. [remindMin] of 0 means no reminder. */
data class AppLimit(
    val pkg: String,
    val limitMin: Int,
    val remindMin: Int,
) {
    val limitMs: Long get() = limitMin * 60_000L
}

data class LimitsState(
    val limits: List<AppLimit> = emptyList(),
    /** Today's usage in milliseconds, per package. */
    val usedMs: Map<String, Long> = emptyMap(),
    val floatingTimer: Boolean = true,
    /** 0 = floating timer always on screen, otherwise it slides out every this many minutes. */
    val floatingEveryMin: Int = 0,
    /** Floating timer over games. On by default: the timer shows in every app that has a limit. */
    val floatingOverGames: Boolean = true,
    /** [TimerStyle.id] of the chosen timer design. */
    val floatingStyle: String = TimerStyle.DEFAULT_ID,
    /** Daily limits for Shorts / Reels / Status. [AppLimit.pkg] holds the [ShortForm.id]. */
    val categoryLimits: List<AppLimit> = emptyList(),
    /** Today's usage per [ShortForm.id], in milliseconds. */
    val categoryUsedMs: Map<String, Long> = emptyMap(),
    /** Emergency access for each limited app (key = package) and each limited content (key = id). */
    val emergency: Map<String, LimitEmergency> = emptyMap(),
)

/**
 * When the floating timer should slide in. [sinceMs] is active use of the app since the last
 * popup; it is kept per app, so switching apps never resets or skips it.
 */
object PopupSchedule {
    fun isDue(sinceMs: Long, everyMin: Int): Boolean = everyMin > 0 && sinceMs >= everyMin * 60_000L
}

/**
 * Daily app limits and today's usage, persisted in SharedPreferences so they survive process
 * death, app restarts and reboots. Usage resets by itself when the calendar day changes.
 */
class UsageLimitStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "usage_limits")

    // Runs once, before the first state is read (see migrateTimerOverGames).
    @Suppress("unused")
    private val migrated: Unit = migrateTimerOverGames()

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<LimitsState> = _state.asStateFlow()

    /** Cheap lookup for the accessibility service, which asks on every window event. */
    @Volatile
    private var cache: Map<String, AppLimit> = readLimits()

    @Volatile
    private var catCache: Map<String, AppLimit> = readCategoryLimits()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        cache = readLimits()
        catCache = readCategoryLimits()
        _state.value = readState()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    // ---- Limits -----------------------------------------------------------------------------

    fun limitFor(pkg: String): AppLimit? = cache[pkg]

    fun hasLimits(): Boolean = cache.isNotEmpty()

    /** Any app limit or any Shorts / Reels / Status limit. */
    fun hasAnyLimit(): Boolean = cache.isNotEmpty() || catCache.isNotEmpty()

    fun setLimit(limit: AppLimit) {
        val set = HashSet(prefs.getStringSet(K_LIMITS, emptySet()) ?: emptySet())
        set.removeAll { it.substringBefore('|') == limit.pkg }
        set.add("${limit.pkg}|${limit.limitMin}|${limit.remindMin}")
        // A changed limit gets a fresh chance to remind.
        val reminded = HashSet(prefs.getStringSet(K_REMINDED, emptySet()) ?: emptySet())
        reminded.remove(limit.pkg)
        prefs.edit().putStringSet(K_LIMITS, set).putStringSet(K_REMINDED, reminded).apply()
    }

    fun removeLimit(pkg: String) {
        val set = HashSet(prefs.getStringSet(K_LIMITS, emptySet()) ?: emptySet())
        set.removeAll { it.substringBefore('|') == pkg }
        prefs.edit().putStringSet(K_LIMITS, set).remove(K_USED + pkg).apply()
        clearEmergency(pkg)
    }

    // ---- Category limits (YouTube Shorts, Instagram Reels, WhatsApp Status ...) ---------------

    fun categoryLimit(id: String): AppLimit? = catCache[id]

    fun hasCategoryLimit(pkg: String): Boolean = catCache.keys.any { ShortFormCatalog.byId(it)?.pkg == pkg }

    /** Ids of the content kinds inside [pkg] that have a daily limit. */
    fun categoryIdsFor(pkg: String): List<String> = catCache.keys.filter { ShortFormCatalog.byId(it)?.pkg == pkg }

    fun setCategoryLimit(id: String, limitMin: Int) {
        if (ShortFormCatalog.byId(id) == null || limitMin <= 0) return
        val set = HashSet(prefs.getStringSet(K_CAT_LIMITS, emptySet()) ?: emptySet())
        set.removeAll { it.substringBefore('|') == id }
        set.add("$id|$limitMin")
        prefs.edit().putStringSet(K_CAT_LIMITS, set).apply()
    }

    fun removeCategoryLimit(id: String) {
        val set = HashSet(prefs.getStringSet(K_CAT_LIMITS, emptySet()) ?: emptySet())
        set.removeAll { it.substringBefore('|') == id }
        prefs.edit().putStringSet(K_CAT_LIMITS, set).remove(K_CAT_USED + id).apply()
        clearEmergency(id)
    }

    fun categoryUsedMs(id: String): Long {
        rollOverIfNeeded()
        return prefs.getLong(K_CAT_USED + id, 0L)
    }

    @Synchronized
    fun addCategoryUsage(id: String, deltaMs: Long): Long {
        rollOverIfNeeded()
        val total = prefs.getLong(K_CAT_USED + id, 0L) + deltaMs.coerceAtLeast(0L)
        prefs.edit().putLong(K_CAT_USED + id, total).apply()
        return total
    }

    fun isCategoryReached(id: String): Boolean {
        val limit = catCache[id] ?: return false
        return categoryUsedMs(id) >= limit.limitMs
    }

    // ---- Emergency access for limits --------------------------------------------------------

    /** Emergency settings and today's use for a limit. A limit never configured gets the defaults. */
    @Synchronized
    fun emergencyFor(key: String): LimitEmergency {
        rollOverIfNeeded()
        val raw = (prefs.getStringSet(K_EMG_CFG, emptySet()) ?: emptySet()).firstOrNull { it.substringBefore('|') == key }
        val p = raw?.split('|')
        val base = if (p != null && p.size >= 4) {
            LimitEmergency(
                enabled = p[1] == "1",
                attempts = LimitEmergencyRules.clampAttempts(p[2].toIntOrNull() ?: LimitEmergencyRules.DEFAULT_ATTEMPTS),
                minutes = LimitEmergencyRules.clampMinutes(p[3].toIntOrNull() ?: LimitEmergencyRules.DEFAULT_MINUTES),
            )
        } else LimitEmergency()
        return base.copy(used = prefs.getInt(K_EMG_USED + key, 0), activeUntil = prefs.getLong(K_EMG_UNTIL + key, 0L))
    }

    @Synchronized
    fun setEmergency(key: String, enabled: Boolean, attempts: Int, minutes: Int) {
        val set = HashSet(prefs.getStringSet(K_EMG_CFG, emptySet()) ?: emptySet())
        set.removeAll { it.substringBefore('|') == key }
        set.add("$key|${if (enabled) 1 else 0}|${LimitEmergencyRules.clampAttempts(attempts)}|${LimitEmergencyRules.clampMinutes(minutes)}")
        prefs.edit().putStringSet(K_EMG_CFG, set).apply()
    }

    /** Uses one attempt and opens the window. False when it is off, used up, or already running. */
    @Synchronized
    fun startEmergency(key: String, now: Long = System.currentTimeMillis()): Boolean {
        val next = LimitEmergencyRules.start(emergencyFor(key), now) ?: return false
        prefs.edit().putInt(K_EMG_USED + key, next.used).putLong(K_EMG_UNTIL + key, next.activeUntil).apply()
        return true
    }

    /** Milliseconds left in the running emergency window for [key] (0 when none). */
    fun emergencyLeftMs(key: String, now: Long = System.currentTimeMillis()): Long =
        prefs.getLong(K_EMG_UNTIL + key, 0L).let { if (it > now) it - now else 0L }

    fun emergencyActive(key: String, now: Long = System.currentTimeMillis()): Boolean = emergencyLeftMs(key, now) > 0L

    private fun clearEmergency(key: String) {
        val set = HashSet(prefs.getStringSet(K_EMG_CFG, emptySet()) ?: emptySet())
        set.removeAll { it.substringBefore('|') == key }
        prefs.edit().putStringSet(K_EMG_CFG, set).remove(K_EMG_USED + key).remove(K_EMG_UNTIL + key).apply()
    }

    fun floatingTimer(): Boolean = prefs.getBoolean(K_FLOATING, true)

    fun setFloatingTimer(on: Boolean) {
        prefs.edit().putBoolean(K_FLOATING, on).apply()
    }

    fun floatingOverGames(): Boolean = prefs.getBoolean(K_FLOAT_GAMES, true)

    fun setFloatingOverGames(on: Boolean) {
        prefs.edit().putBoolean(K_FLOAT_GAMES, on).apply()
    }

    /** Active-use milliseconds in [pkg] since its timer popup last slid in (survives app switches). */
    fun sincePopupMs(pkg: String): Long {
        rollOverIfNeeded()
        return prefs.getLong(K_SINCE + pkg, 0L)
    }

    /**
     * Makes the timer popup slide in the next time [pkg] is used, even when it is set to "every N min"
     * (used right after a used-up limit was raised, so the person sees how much time they got).
     */
    fun requestPopupNow(pkg: String) {
        prefs.edit().putLong(K_SINCE + pkg, 24 * 60 * 60_000L).apply()
    }

    fun setSincePopupMs(pkg: String, ms: Long) {
        prefs.edit().putLong(K_SINCE + pkg, ms.coerceAtLeast(0L)).apply()
    }

    fun floatingStyleId(): String = TimerStyle.fromId(prefs.getString(K_FLOAT_STYLE, null)).id

    fun setFloatingStyle(id: String) {
        prefs.edit().putString(K_FLOAT_STYLE, TimerStyle.fromId(id).id).apply()
    }

    fun floatingEveryMin(): Int = prefs.getInt(K_FLOAT_EVERY, 0)

    fun setFloatingEveryMin(min: Int) {
        prefs.edit().putInt(K_FLOAT_EVERY, min.coerceIn(0, 60)).apply()
    }

    // ---- Usage ------------------------------------------------------------------------------

    fun usedMs(pkg: String): Long {
        rollOverIfNeeded()
        return prefs.getLong(K_USED + pkg, 0L)
    }

    /** Adds [deltaMs] to today's usage and returns the new total. */
    @Synchronized
    fun addUsage(pkg: String, deltaMs: Long): Long {
        rollOverIfNeeded()
        val total = prefs.getLong(K_USED + pkg, 0L) + deltaMs.coerceAtLeast(0L)
        prefs.edit().putLong(K_USED + pkg, total).apply()
        return total
    }

    /** Raises today's usage to [ms] if it is lower (used to reconcile with Android's own stats). */
    @Synchronized
    fun raiseUsageTo(pkg: String, ms: Long) {
        rollOverIfNeeded()
        if (prefs.getLong(K_USED + pkg, 0L) < ms) prefs.edit().putLong(K_USED + pkg, ms).apply()
    }

    fun isReached(pkg: String): Boolean {
        val limit = cache[pkg] ?: return false
        return usedMs(pkg) >= limit.limitMs
    }

    fun wasReminded(pkg: String): Boolean {
        rollOverIfNeeded()
        return pkg in (prefs.getStringSet(K_REMINDED, emptySet()) ?: emptySet())
    }

    fun markReminded(pkg: String) {
        val reminded = HashSet(prefs.getStringSet(K_REMINDED, emptySet()) ?: emptySet())
        reminded.add(pkg)
        prefs.edit().putStringSet(K_REMINDED, reminded).apply()
    }

    // ---- Internals --------------------------------------------------------------------------

    /**
     * Earlier versions defaulted "Also over games" to off, so the timer never showed over a game
     * (and anything Android files under games). The timer must show in every limited app, so the
     * old default is switched on once. After that the person's own choice is respected.
     */
    private fun migrateTimerOverGames() {
        if (prefs.getBoolean(K_MIGRATED_GAMES, false)) return
        prefs.edit().putBoolean(K_FLOAT_GAMES, true).putBoolean(K_MIGRATED_GAMES, true).apply()
    }

    @Synchronized
    private fun rollOverIfNeeded() {
        val today = LocalDate.now().toString()
        if (prefs.getString(K_DAY, null) == today) return
        val editor = prefs.edit().putString(K_DAY, today).remove(K_REMINDED)
        prefs.all.keys.filter { it.startsWith(K_USED) || it.startsWith(K_CAT_USED) || it.startsWith(K_SINCE) || it.startsWith(K_EMG_USED) }
            .forEach { editor.remove(it) }
        editor.apply()
    }

    private fun readLimits(): Map<String, AppLimit> {
        val out = HashMap<String, AppLimit>()
        for (raw in prefs.getStringSet(K_LIMITS, emptySet()) ?: emptySet()) {
            val p = raw.split('|')
            if (p.size < 3) continue
            val limit = p[1].toIntOrNull() ?: continue
            val remind = p[2].toIntOrNull() ?: 0
            out[p[0]] = AppLimit(p[0], limit, remind)
        }
        return out
    }

    private fun readCategoryLimits(): Map<String, AppLimit> {
        val out = HashMap<String, AppLimit>()
        for (raw in prefs.getStringSet(K_CAT_LIMITS, emptySet()) ?: emptySet()) {
            val p = raw.split('|')
            if (p.size < 2 || ShortFormCatalog.byId(p[0]) == null) continue
            val min = p[1].toIntOrNull() ?: continue
            if (min > 0) out[p[0]] = AppLimit(p[0], min, 0)
        }
        return out
    }

    private fun readState(): LimitsState {
        rollOverIfNeeded()
        val cats = readCategoryLimits().values.sortedBy { it.pkg }
        val limits = readLimits().values.sortedBy { it.pkg }
        return LimitsState(
            limits = limits,
            usedMs = limits.associate { it.pkg to prefs.getLong(K_USED + it.pkg, 0L) },
            floatingTimer = prefs.getBoolean(K_FLOATING, true),
            floatingEveryMin = prefs.getInt(K_FLOAT_EVERY, 0),
            floatingOverGames = prefs.getBoolean(K_FLOAT_GAMES, true),
            floatingStyle = TimerStyle.fromId(prefs.getString(K_FLOAT_STYLE, null)).id,
            categoryLimits = cats,
            categoryUsedMs = cats.associate { it.pkg to prefs.getLong(K_CAT_USED + it.pkg, 0L) },
            emergency = (limits.map { it.pkg } + cats.map { it.pkg }).associateWith { emergencyFor(it) },
        )
    }

    companion object {
        private const val K_LIMITS = "limits"
        private const val K_USED = "used_"
        private const val K_DAY = "day"
        private const val K_CAT_LIMITS = "cat_limits"
        private const val K_CAT_USED = "cused_"
        private const val K_SINCE = "since_"
        private const val K_REMINDED = "reminded"
        private const val K_FLOATING = "floating_timer"
        private const val K_FLOAT_EVERY = "floating_every_min"
        private const val K_FLOAT_GAMES = "floating_over_games"
        private const val K_FLOAT_STYLE = "floating_style"
        private const val K_EMG_CFG = "emg_cfg"
        private const val K_EMG_USED = "emg_used_"
        private const val K_EMG_UNTIL = "emg_until_"
        private const val K_MIGRATED_GAMES = "migrated_timer_over_games_v1"

        @Volatile
        private var instance: UsageLimitStore? = null

        fun get(context: Context): UsageLimitStore =
            instance ?: synchronized(this) {
                instance ?: UsageLimitStore(context.applicationContext).also { instance = it }
            }
    }
}
