package com.focusmode.app.data.auth

/** Plain-language text for every failure, and the mapping from Firebase error codes. No Firebase classes here. */
object AuthErrors {

    /** Shown on the login screen after a saved login stopped being valid (account deleted / disabled, token revoked). */
    const val SESSION_EXPIRED = "Your session has expired. Please log in again."

    fun message(kind: AuthErrorKind): String = when (kind) {
        AuthErrorKind.INVALID_INPUT -> "Check the highlighted fields."
        AuthErrorKind.NOT_CONFIGURED -> "Accounts aren't set up in this build."
        AuthErrorKind.GOOGLE_NOT_CONFIGURED -> "Google sign-in isn't set up in this build."
        AuthErrorKind.OFFLINE -> "No internet connection. Check it and try again."
        AuthErrorKind.TIMEOUT -> "The server took too long to answer. Try again."
        AuthErrorKind.EMAIL_IN_USE -> "This email already has an account. Log in instead."
        AuthErrorKind.ACCOUNT_EXISTS_OTHER_METHOD ->
            "This email already has an account that uses a different sign-in method. Try the other one."
        AuthErrorKind.INVALID_EMAIL -> "That email address doesn't look right."
        AuthErrorKind.WEAK_PASSWORD ->
            "That password is too weak. Use ${AuthConfig.MIN_PASSWORD} or more characters with letters and numbers."
        AuthErrorKind.WRONG_CREDENTIALS ->
            "Wrong email or password. If you signed up with Google, use Continue with Google."
        AuthErrorKind.USER_DISABLED -> "This account has been disabled."
        AuthErrorKind.TOO_MANY_REQUESTS -> "Too many tries. Wait a few minutes and try again."
        AuthErrorKind.PROVIDER_DISABLED ->
            "This sign-in method is turned off. Enable it in the Firebase console (Authentication > Sign-in method)."
        AuthErrorKind.ALREADY_SIGNED_IN -> "You're already logged in. Log out first."
        AuthErrorKind.IDENTITY_LOCKED -> "Disconnect the trusted phone first, then try again."
        AuthErrorKind.GOOGLE_NO_ACCOUNT ->
            "No Google account found on this phone. Add one in your phone's Settings, then try again."
        AuthErrorKind.GOOGLE_FAILED -> "Google sign-in didn't work. Try again."
        AuthErrorKind.BUSY -> "Please wait, something is already in progress."
        AuthErrorKind.UNKNOWN -> "Something went wrong. Try again."
    }

    /** Firebase Auth `errorCode` -> kind, for the email / password and credential calls. */
    fun kindOfFirebaseCode(code: String?): AuthErrorKind = when (code) {
        "ERROR_EMAIL_ALREADY_IN_USE", "ERROR_CREDENTIAL_ALREADY_IN_USE" -> AuthErrorKind.EMAIL_IN_USE
        "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL" -> AuthErrorKind.ACCOUNT_EXISTS_OTHER_METHOD
        "ERROR_INVALID_EMAIL", "ERROR_MISSING_EMAIL" -> AuthErrorKind.INVALID_EMAIL
        "ERROR_WEAK_PASSWORD" -> AuthErrorKind.WEAK_PASSWORD
        "ERROR_WRONG_PASSWORD", "ERROR_USER_NOT_FOUND", "ERROR_INVALID_CREDENTIAL",
        "ERROR_INVALID_LOGIN_CREDENTIALS" -> AuthErrorKind.WRONG_CREDENTIALS
        "ERROR_USER_DISABLED" -> AuthErrorKind.USER_DISABLED
        "ERROR_TOO_MANY_REQUESTS" -> AuthErrorKind.TOO_MANY_REQUESTS
        "ERROR_OPERATION_NOT_ALLOWED", "ERROR_ADMIN_RESTRICTED_OPERATION" -> AuthErrorKind.PROVIDER_DISABLED
        "ERROR_NETWORK_REQUEST_FAILED" -> AuthErrorKind.OFFLINE
        else -> AuthErrorKind.UNKNOWN
    }

    /** Codes that mean "this saved login is no longer valid" (account deleted or disabled, token revoked). */
    fun isDeadSessionCode(code: String?): Boolean = code in DEAD_SESSION

    private val DEAD_SESSION = setOf(
        "ERROR_USER_DISABLED", "ERROR_USER_NOT_FOUND", "ERROR_USER_TOKEN_EXPIRED", "ERROR_INVALID_USER_TOKEN",
    )
}
