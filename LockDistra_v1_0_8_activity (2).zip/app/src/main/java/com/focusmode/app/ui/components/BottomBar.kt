package com.focusmode.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.ui.Screen
import com.focusmode.app.ui.theme.FocusTheme

private data class BarItem(val screen: Screen, val label: String, val icon: ImageVector, val iconOn: ImageVector)

private val barItems = listOf(
    BarItem(Screen.Home, "Home", Icons.Outlined.Home, Icons.Filled.Home),
    BarItem(Screen.Apps, "Blocking", Icons.Outlined.Block, Icons.Filled.Block),
    BarItem(Screen.Limits, "Limits", Icons.Outlined.Schedule, Icons.Filled.Schedule),
    BarItem(Screen.Study, "Study", Icons.Outlined.School, Icons.Filled.School),
)

/** The screens that show the bottom bar. Everything else (session, plant ...) is full screen. */
val BottomBarScreens = setOf(Screen.Home, Screen.Apps, Screen.Limits, Screen.Study)

/** One tab of [FocusTabBar]. */
class TabBarItem(val label: String, val icon: ImageVector, val iconOn: ImageVector)

/** Glass bottom bar of the four main screens (Home, Blocking, Limits, Study). */
@Composable
fun FocusBottomBar(
    selected: Screen,
    onSelect: (Screen) -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusTabBar(
        items = barItems.map { TabBarItem(it.label, it.icon, it.iconOn) },
        selectedIndex = barItems.indexOfFirst { it.screen == selected },
        onSelect = { onSelect(barItems[it].screen) },
        modifier = modifier,
    )
}

/**
 * The same glass bar with a glowing line under the active tab, for any set of tabs. The main screens use it through
 * [FocusBottomBar]; the Focus Profile screen uses it with its own two tabs.
 */
@Composable
fun FocusTabBar(
    items: List<TabBarItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    val shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .shadow(24.dp, shape, ambientColor = c.glow.copy(alpha = 0.5f), spotColor = Color(0x99000000))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(c.cardHigh, c.card)))
            .navigationBarsPadding()
    ) {
        // Thin lit edge along the top.
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.05f),
                            c.accent.copy(alpha = 0.7f),
                            Color.White.copy(alpha = 0.05f)
                        )
                    )
                )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEachIndexed { index, item ->
                val on = index == selectedIndex
                val tint = if (on) c.text else c.muted
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onSelect(index) }
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Icon(if (on) item.iconOn else item.icon, item.label, tint = if (on) c.accent else c.muted, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.height(2.dp))
                    Text(
                        item.label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontSize = 11.5.sp,
                            letterSpacing = 0.sp,
                            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal
                        ),
                        color = tint,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(4.dp))
                    Box(
                        Modifier
                            .width(30.dp)
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                if (on) Brush.horizontalGradient(
                                    listOf(Color.Transparent, c.gradMid, c.accent, c.gradMid, Color.Transparent)
                                ) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                    )
                }
            }
        }
    }
}
