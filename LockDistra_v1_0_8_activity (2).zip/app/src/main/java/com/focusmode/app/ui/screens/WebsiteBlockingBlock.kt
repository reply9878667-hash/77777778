package com.focusmode.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.WebsiteBrowsers
import com.focusmode.app.data.WebsiteEdits
import com.focusmode.app.data.WebsiteRule
import com.focusmode.app.data.WebsiteRules
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.theme.FocusTheme

/**
 * "<App> website blocking" inside the app's restriction sheet. One switch; the site list, the
 * add button and the browser note only appear once it is on.
 */
@Composable
internal fun WebsiteBlockingBlock(
    appLabel: String,
    on: Boolean,
    rules: List<WebsiteRule>,
    /** Adding a site / switching ON is allowed right now. */
    canTighten: Boolean,
    /** Deleting, editing or switching OFF is allowed right now. */
    canLoosen: Boolean,
    onOnChange: (Boolean) -> Unit,
    onAdd: (raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onEdit: (old: String, raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onRemove: (String) -> Unit,
    onRuleEnabled: (domain: String, on: Boolean) -> Unit,
) {
    val c = FocusTheme.colors
    SwitchLine(
        title = "$appLabel website blocking",
        note = when {
            !on -> "Off"
            rules.none { it.enabled } -> "On, no sites yet"
            else -> "${rules.count { it.enabled }} site${if (rules.count { it.enabled } == 1) "" else "s"} blocked in browsers"
        },
        checked = on,
        enabled = if (on) canLoosen else canTighten,
        onChange = onOnChange
    )

    if (!on) return

    Spacer(Modifier.height(10.dp))
    WebsiteSiteList(
        rules = rules,
        canTighten = canTighten,
        canLoosen = canLoosen,
        onAdd = onAdd,
        onEdit = onEdit,
        onRemove = onRemove,
        onRuleEnabled = onRuleEnabled,
    )
}

/**
 * The list of sites with edit / delete / ON-OFF per site, the "Add website" button, the browser note and the add / edit
 * dialog. Shared by an app's panel and by the "Blocked websites" list in the Website Blocking card, so both look and
 * behave the same. [onAddMany] (only the card passes it) lets several sites be typed or pasted at once.
 */
@Composable
internal fun WebsiteSiteList(
    rules: List<WebsiteRule>,
    canTighten: Boolean,
    canLoosen: Boolean,
    onAdd: (raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onEdit: (old: String, raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onRemove: (String) -> Unit,
    onRuleEnabled: (domain: String, on: Boolean) -> Unit,
    onAddMany: ((raw: String, subdomains: Boolean) -> WebsiteEdits.Bulk)? = null,
) {
    val c = FocusTheme.colors
    // null = closed, "" = adding, anything else = editing that domain
    var dialogFor by remember { mutableStateOf<String?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        rules.forEach { rule ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(rule.domain, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        if (rule.subdomains) "Includes subdomains" else "Exact domain only",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
                IconButton(onClick = { dialogFor = rule.domain }, enabled = canLoosen) {
                    Icon(Icons.Rounded.Edit, "Edit ${rule.domain}", tint = if (canLoosen) c.muted else c.muted.copy(alpha = 0.4f), modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { onRemove(rule.domain) }, enabled = canLoosen) {
                    Icon(Icons.Rounded.Delete, "Delete ${rule.domain}", tint = if (canLoosen) c.muted else c.muted.copy(alpha = 0.4f), modifier = Modifier.size(18.dp))
                }
                FocusSwitch(
                    checked = rule.enabled,
                    enabled = if (rule.enabled) canLoosen else canTighten,
                    onCheckedChange = { onRuleEnabled(rule.domain, it) }
                )
            }
        }
    }
    TextButton(onClick = { dialogFor = "" }, enabled = canTighten) {
        Text(if (onAddMany != null) "Add websites" else "Add website", color = if (canTighten) c.accent else c.muted)
    }
    Text(
        "Closed in ${WebsiteBrowsers.supportedNames} during focus sessions and after the daily limit is used up. " +
            "Other browsers and in-app web views are not covered.",
        style = MaterialTheme.typography.bodySmall,
        color = c.muted,
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
    )

    dialogFor?.let { editing ->
        SiteDialog(
            editing = editing.ifEmpty { null },
            initialSubdomains = rules.firstOrNull { it.domain == editing }?.subdomains ?: true,
            onSave = { raw, sub -> if (editing.isEmpty()) onAdd(raw, sub) else onEdit(editing, raw, sub) },
            onSaveMany = if (editing.isEmpty()) onAddMany else null,
            onDismiss = { dialogFor = null },
        )
    }
}

@Composable
private fun SiteDialog(
    editing: String?,
    initialSubdomains: Boolean,
    onSave: (String, Boolean) -> WebsiteRules.Result,
    onDismiss: () -> Unit,
    /** Several sites at once (adding in the Website Blocking card); null = one site, as in an app's panel. */
    onSaveMany: ((String, Boolean) -> WebsiteEdits.Bulk)? = null,
) {
    val c = FocusTheme.colors
    var text by remember { mutableStateOf(editing.orEmpty()) }
    var subdomains by remember { mutableStateOf(initialSubdomains) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text(if (editing == null) (if (onSaveMany != null) "Add websites" else "Add website") else "Edit website", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(300); error = null },
                    singleLine = onSaveMany == null,
                    placeholder = { Text(if (onSaveMany != null) "youtube.com, instagram.com ..." else "link or name: example.com, youtube") },
                    isError = error != null,
                )
                if (error != null) {
                    Text(error!!, style = MaterialTheme.typography.bodySmall, color = c.warning, modifier = Modifier.padding(top = 4.dp))
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Include subdomains", style = MaterialTheme.typography.titleMedium, color = c.text)
                        Text("m.example.com, music.example.com ...", style = MaterialTheme.typography.bodySmall, color = c.muted)
                    }
                    Spacer(Modifier.size(12.dp))
                    FocusSwitch(checked = subdomains, enabled = true, onCheckedChange = { subdomains = it })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (onSaveMany != null) {
                    val bulk = onSaveMany(text, subdomains)
                    if (bulk.allDone) { onDismiss(); return@TextButton }
                    if (bulk.locked) { error = "Changes are locked right now"; return@TextButton }
                    // Keep only what was not added, so it can be corrected; say why.
                    val left = bulk.invalid + bulk.duplicates + bulk.full
                    text = left.joinToString(", ")
                    error = buildString {
                        if (bulk.added.isNotEmpty()) append("Added ${bulk.added.size}. ")
                        if (bulk.invalid.isNotEmpty()) append("Not a website: ${bulk.invalid.joinToString(", ")}. ")
                        if (bulk.duplicates.isNotEmpty()) append("Already in the list: ${bulk.duplicates.joinToString(", ")}. ")
                        if (bulk.full.isNotEmpty()) append("List is full: ${bulk.full.joinToString(", ")}.")
                    }.trim()
                    return@TextButton
                }
                when (onSave(text, subdomains)) {
                    WebsiteRules.Result.OK -> onDismiss()
                    WebsiteRules.Result.INVALID -> error = "Enter a link or a website name, like example.com or youtube"
                    WebsiteRules.Result.ALREADY_THERE -> error = "This website is already in the list"
                    WebsiteRules.Result.FULL -> error = "Too many websites for this app"
                    WebsiteRules.Result.LOCKED -> error = "Changes are locked right now"
                }
            }) { Text("Save", color = c.accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}
