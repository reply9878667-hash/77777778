package com.focusmode.app.data

/**
 * How the floating timer looks. Chosen in Usage limits > Timer design. The circle that the timer
 * shrinks into (tap, or drag to an edge) is separate and always looks the same; these designs are
 * for the normal (wide) shape.
 */
enum class TimerStyle(
    val id: String,
    val title: String,
    val showsIcon: Boolean,
    val showsLabel: Boolean,
    val hasBox: Boolean,
    /** Icon above the time instead of beside it. */
    val stacked: Boolean = false,
) {
    CLASSIC("classic", "Logo + name + time", showsIcon = true, showsLabel = true, hasBox = true),
    LOGO_TIME("logo_time", "Logo + time", showsIcon = true, showsLabel = false, hasBox = true),
    TIME_ONLY("time_only", "Only time", showsIcon = false, showsLabel = false, hasBox = true),
    STACKED("stacked", "Logo above time", showsIcon = true, showsLabel = false, hasBox = true, stacked = true),
    TEXT_ONLY("text_only", "Plain text", showsIcon = false, showsLabel = false, hasBox = false);

    /** The words in the timer, given the app / content name and the already formatted time. */
    fun text(label: String, remaining: String): String =
        if (showsLabel && label.isNotEmpty()) "$label · $remaining" else remaining

    companion object {
        const val DEFAULT_ID = "classic"

        fun fromId(id: String?): TimerStyle = values().firstOrNull { it.id == id } ?: CLASSIC
    }
}

/**
 * Keeps the floating timer from being moved by accident.
 *
 * After it has been left alone for [IDLE_LOCK_MS] it locks: dragging does nothing. To move it
 * again, tap it [TAPS_TO_UNLOCK] times in a row (each tap within [TAP_GAP_MS] of the last).
 * Once unlocked it can be dragged, and it locks again after another [IDLE_LOCK_MS] of no touch.
 */
class TimerLock(locked: Boolean = false) {

    var locked: Boolean = locked
        private set

    private var taps = 0
    private var lastTapAt = 0L

    /** Taps still needed to unlock (0 when already unlocked). */
    val tapsLeft: Int get() = if (locked) TAPS_TO_UNLOCK - taps else 0

    /** A tap on the timer. Returns true on the tap that unlocks it. Does nothing when unlocked. */
    fun onTap(nowMs: Long): Boolean {
        if (!locked) return false
        taps = if (taps > 0 && nowMs - lastTapAt <= TAP_GAP_MS) taps + 1 else 1
        lastTapAt = nowMs
        if (taps >= TAPS_TO_UNLOCK) {
            taps = 0
            locked = false
            return true
        }
        return false
    }

    /** A drag tried while locked: it breaks the run of taps. */
    fun onDragAttempt() {
        taps = 0
    }

    fun lockNow() {
        locked = true
        taps = 0
    }

    companion object {
        const val TAPS_TO_UNLOCK = 5
        const val TAP_GAP_MS = 2_000L
        const val IDLE_LOCK_MS = 5_000L
    }
}
