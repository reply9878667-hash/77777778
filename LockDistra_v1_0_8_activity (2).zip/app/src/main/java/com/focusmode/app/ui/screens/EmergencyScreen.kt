package com.focusmode.app.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.EMERGENCY_MAX_LIMIT
import com.focusmode.app.data.EmergencyApp
import com.focusmode.app.data.EmergencyReset
import com.focusmode.app.data.EmergencyState
import com.focusmode.app.data.FocusState
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.AppListSkeleton
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.components.staggeredEntrance
import com.focusmode.app.ui.theme.FocusTheme

private val resetOptions = listOf(
    EmergencyReset.EVERY_SESSION to "Every session",
    EmergencyReset.EVERY_DAY to "Every day",
    EmergencyReset.MANUAL to "Manual",
)

/** Small banner used wherever something is locked for the running session. */
@Composable
internal fun LockedNote(text: String) {
    val c = FocusTheme.colors
    FocusCard(padding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Lock, null, tint = c.warning, modifier = Modifier.size(20.dp))
            Spacer(Modifier.size(12.dp))
            Text(text, style = MaterialTheme.typography.bodySmall, color = c.muted)
        }
    }
}

/**
 * Chooses which apps Emergency access may open and how many times each. Every app starts OFF.
 * While a session runs, settings can only be tightened (an app switched off, a limit lowered),
 * and not at all when app changes or settings are locked.
 */
@Composable
fun EmergencyAppsScreen(
    state: FocusState,
    emergency: EmergencyState,
    apps: List<AppInfo>,
    loaded: Boolean,
    onBack: () -> Unit,
    onEnabledChange: (pkg: String, enabled: Boolean) -> Unit,
    onLimitChange: (pkg: String, limit: Int) -> Unit,
    onResetModeChange: (Int) -> Unit,
    onResetCounts: () -> Unit,
) {
    val c = FocusTheme.colors
    var query by remember { mutableStateOf("") }
    val running = state.focusActive
    val frozen = com.focusmode.app.data.EmergencyPolicy.editsLocked(state)

    val q = query.trim()
    val visible = if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
    val enabledApps = visible.filter { emergency.app(it.packageName)?.enabled == true }
    val otherApps = visible.filter { emergency.app(it.packageName)?.enabled != true }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .staggeredEntrance(0)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Column {
                Text("Emergency apps", style = MaterialTheme.typography.titleLarge)
                Text(
                    if (emergency.enabledCount == 0) "Choose what a real emergency may open"
                    else "${emergency.enabledCount} app${if (emergency.enabledCount == 1) "" else "s"} allowed, saved automatically",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        SearchField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.staggeredEntrance(1).padding(horizontal = 20.dp)
        )

        if (!loaded) {
            AppListSkeleton(rows = 9)
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (running) {
                item {
                    LockedNote(
                        if (frozen) "Emergency settings are locked right now. Unlock changes (or wait for the session to end) to edit them."
                        else "A session is running. You can switch apps off or lower a limit, but not add apps or raise limits."
                    )
                }
            }

            if (q.isEmpty()) {
                item(key = "refresh") {
                    FocusCard(padding = PaddingValues(horizontal = 18.dp, vertical = 16.dp)) {
                        Column {
                            Text("Attempts come back", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                resetOptions.forEach { (mode, label) ->
                                    SoftChip(
                                        text = label,
                                        selected = emergency.resetMode == mode,
                                        onClick = { if (!running) onResetModeChange(mode) }
                                    )
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                when (emergency.resetMode) {
                                    EmergencyReset.EVERY_SESSION -> "Every new focus session starts with full attempts."
                                    EmergencyReset.EVERY_DAY -> "Attempts refill at midnight, however many sessions you run."
                                    else -> "Attempts only refill when you press reset, and only between sessions."
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted
                            )
                            if (emergency.resetMode == EmergencyReset.MANUAL && !running) {
                                TextButton(onClick = onResetCounts) { Text("Reset all attempts", color = c.accent) }
                            }
                            if (running) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    "This can't be changed while a session is running.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = c.warning
                                )
                            }
                        }
                    }
                }
            }

            if (enabledApps.isNotEmpty()) {
                item(key = "label_on") { SectionLabel("Allowed in an emergency", Modifier.padding(top = 8.dp)) }
                items(enabledApps, key = { "on_" + it.packageName }) { app ->
                    EmergencyRow(
                        app = app,
                        config = emergency.app(app.packageName),
                        running = running,
                        frozen = frozen,
                        onEnabledChange = onEnabledChange,
                        onLimitChange = onLimitChange,
                    )
                }
            }
            if (otherApps.isNotEmpty()) {
                item(key = "label_off") {
                    SectionLabel(if (enabledApps.isEmpty()) "All apps" else "Not allowed", Modifier.padding(top = 8.dp))
                }
                items(otherApps, key = { "off_" + it.packageName }) { app ->
                    EmergencyRow(
                        app = app,
                        config = emergency.app(app.packageName),
                        running = running,
                        frozen = frozen,
                        onEnabledChange = onEnabledChange,
                        onLimitChange = onLimitChange,
                    )
                }
            }
            if (visible.isEmpty()) {
                item {
                    Text(
                        "No apps match \"$q\"",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.muted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 24.dp).fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun EmergencyRow(
    app: AppInfo,
    config: EmergencyApp?,
    running: Boolean,
    frozen: Boolean,
    onEnabledChange: (String, Boolean) -> Unit,
    onLimitChange: (String, Int) -> Unit,
) {
    val c = FocusTheme.colors
    val enabled = config?.enabled == true
    val limit = config?.limit ?: 3
    FocusCard(
        modifier = Modifier.animateContentSize(),
        padding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        highlight = enabled
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(app.packageName, 44.dp)
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(
                        when {
                            !enabled -> "Off"
                            config!!.remaining == 0 -> "No attempts left"
                            else -> "${config.remaining} of ${config.limit} attempts left"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = when {
                            !enabled -> c.muted
                            config!!.remaining == 0 -> c.warning
                            else -> c.accent
                        }
                    )
                }
                FocusSwitch(
                    checked = enabled,
                    // While a session runs an app can be switched off but not on.
                    enabled = !(running && (frozen || !enabled)),
                    onCheckedChange = { onEnabledChange(app.packageName, it) }
                )
            }
            if (enabled) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Emergency uses", style = MaterialTheme.typography.labelMedium, color = c.muted)
                        Text(
                            "How many times it can be opened",
                            style = MaterialTheme.typography.bodySmall,
                            color = c.muted
                        )
                    }
                    CircleIconButton(
                        Icons.Rounded.Remove, "Fewer",
                        onClick = { if (!frozen && limit > 1) onLimitChange(app.packageName, limit - 1) }
                    )
                    Text(
                        "$limit",
                        style = MaterialTheme.typography.titleLarge,
                        color = c.text,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 14.dp)
                    )
                    CircleIconButton(
                        Icons.Rounded.Add, "More",
                        onClick = { if (!running && limit < EMERGENCY_MAX_LIMIT) onLimitChange(app.packageName, limit + 1) }
                    )
                }
            }
        }
    }
}
