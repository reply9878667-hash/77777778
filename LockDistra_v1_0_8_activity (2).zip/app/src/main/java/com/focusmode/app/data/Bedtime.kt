package com.focusmode.app.data

/**
 * Bedtime Mode: its own daily schedule and its own list of apps. It never touches the Focus
 * session's blocked apps, App Limits, Pomodoro or website rules.
 *
 * Times are minutes after local midnight (0..1439). A window whose end is earlier than its start
 * (22:00 to 07:00) crosses midnight. Everything here is plain Kotlin so it can be unit tested on a JVM.
 */
data class BedtimeState(
    val enabled: Boolean = false,
    val startMin: Int = BedtimeRules.DEFAULT_START,
    val endMin: Int = BedtimeRules.DEFAULT_END,
    val apps: Set<String> = emptySet(),
) {
    /** On, with a usable schedule and at least one app: the only case that blocks or notifies. */
    val armed: Boolean get() = enabled && apps.isNotEmpty() && BedtimeRules.validWindow(startMin, endMin)
}

object BedtimeRules {
    const val DEFAULT_START = 22 * 60
    const val DEFAULT_END = 7 * 60
    const val DAY_MIN = 24 * 60
    private const val MINUTE_MS = 60_000L

    /** Start and end must differ (equal times would mean "never" or "always", which is unclear). */
    fun validWindow(startMin: Int, endMin: Int) = startMin != endMin

    fun clamp(min: Int) = min.coerceIn(0, DAY_MIN - 1)

    /** Whether [minuteOfDay] is inside the window. The start is included, the end is not. */
    fun inWindow(startMin: Int, endMin: Int, minuteOfDay: Int): Boolean {
        if (!validWindow(startMin, endMin)) return false
        return if (startMin < endMin) minuteOfDay in startMin until endMin
        else minuteOfDay >= startMin || minuteOfDay < endMin
    }

    /** Whether [pkg] is blocked by Bedtime Mode at [minuteOfDay]. */
    fun blocks(s: BedtimeState, pkg: String, minuteOfDay: Int): Boolean =
        s.armed && pkg in s.apps && inWindow(s.startMin, s.endMin, minuteOfDay)

    /** Whether the window is open at [minuteOfDay] (for the schedule, apps aside). */
    fun active(s: BedtimeState, minuteOfDay: Int): Boolean =
        s.armed && inWindow(s.startMin, s.endMin, minuteOfDay)

    /**
     * Milliseconds until the window next opens (when closed) or closes (when open). "Now" is given
     * as the local [minuteOfDay] plus [msIntoMinute]. A daylight-saving change in between only
     * makes this a little early or late; the alarm is re-armed at every wake-up. Between one second
     * and one day.
     */
    fun msToNextBoundary(s: BedtimeState, minuteOfDay: Int, msIntoMinute: Long): Long {
        val toStart = minutesUntil(minuteOfDay, s.startMin)
        val toEnd = minutesUntil(minuteOfDay, s.endMin)
        val minutes = if (inWindow(s.startMin, s.endMin, minuteOfDay)) toEnd else toStart
        return (minutes * MINUTE_MS - msIntoMinute).coerceAtLeast(1_000L)
    }

    /** Minutes from [from] until the clock shows [target]; a full day when they are equal. */
    fun minutesUntil(from: Int, target: Int): Int {
        val d = (target - from + DAY_MIN) % DAY_MIN
        return if (d == 0) DAY_MIN else d
    }

    /** "10:00 PM" style text. */
    fun format(min: Int): String {
        val m = clamp(min)
        val h24 = m / 60
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        return "%d:%02d %s".format(h12, m % 60, if (h24 < 12) "AM" else "PM")
    }

    fun startedTitle() = "Bedtime Mode is ON"
    fun startedText() = "Bedtime Mode is ON. Selected applications are now blocked."
    fun endedTitle() = "Bedtime Mode is OFF"
    fun endedText() = "Bedtime Mode is OFF. Your selected applications are unlocked."
}
