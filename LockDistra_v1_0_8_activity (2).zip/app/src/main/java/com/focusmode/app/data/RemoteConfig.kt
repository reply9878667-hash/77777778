package com.focusmode.app.data

import android.content.Context
import com.focusmode.app.data.online.FirebaseGateway
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

/**
 * The settings the admin panel saves (popups, update popup, promoted video). Read from the server at most once every
 * 45 seconds and kept on the phone, so an offline phone still uses the last copy. Never throws.
 */
object RemoteConfig {
    private const val PREFS = "rewire_remote_config"
    private const val MAX_AGE_MS = 45_000L

    private fun parse(text: String): JSONObject? = try { JSONObject(text) } catch (_: Exception) { null }

    suspend fun get(context: Context): JSONObject? {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val saved = prefs.getString("json", null)
        val age = System.currentTimeMillis() - prefs.getLong("at", 0L)
        if (saved != null && age in 0..MAX_AGE_MS) return parse(saved)
        val fetched = try {
            FirebaseGateway.readAdminConfig(app)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
        if (fetched != null) {
            prefs.edit().putString("json", fetched).putLong("at", System.currentTimeMillis()).apply()
            return parse(fetched)
        }
        return saved?.let { parse(it) }
    }
}

/** The promoted video (admin panel, Promoted video tab): one video placed first in Study home / search, with pacing. */
object PromoVideo {
    private const val PREFS = "rewire_promo_video"

    /** [surface] is "home" or "search". Returns the video to show first, or null. Blocking: run off the main thread. */
    suspend fun next(context: Context, surface: String): StudyVideo? {
        val app = context.applicationContext
        val promo = RemoteConfig.get(app)?.optJSONObject("promo") ?: return null
        if (!promo.optBoolean("enabled", false)) return null
        if (surface == "home" && !promo.optBoolean("onHome", true)) return null
        if (surface == "search" && !promo.optBoolean("inSearch", true)) return null
        val id = promo.optString("id", "")
        val videoId = promo.optString("videoId", "")
        if (id.isBlank() || videoId.length != 11) return null
        val count = promo.optInt("count", 5).coerceIn(1, 100)
        val days = promo.optInt("days", 4).coerceIn(1, 60)
        val gapMs = days * 24L * 3_600_000L / count
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val shown = prefs.getInt("c_${id}_$surface", 0)
        val last = prefs.getLong("t_${id}_$surface", 0L)
        val now = System.currentTimeMillis()
        if (shown >= count) return null
        if (shown > 0 && now - last in 0 until gapMs) return null
        var video: StudyVideo? = null
        try {
            video = StudyApi(StudyStore.get(app)).details(listOf(videoId)).firstOrNull()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // YouTube not reachable right now: show nothing extra
        }
        if (video == null) return null
        prefs.edit().putInt("c_${id}_$surface", shown + 1).putLong("t_${id}_$surface", now).apply()
        return video
    }

    /** Puts the promoted video first in the home feed (Shorts list when it is a Short). */
    fun inFeed(feed: StudyFeed, promo: StudyVideo?): StudyFeed {
        if (promo == null) return feed
        return if (promo.isShort) feed.copy(shorts = listOf(promo) + feed.shorts.filter { it.id != promo.id })
        else feed.copy(videos = listOf(promo) + feed.videos.filter { it.id != promo.id })
    }
}
