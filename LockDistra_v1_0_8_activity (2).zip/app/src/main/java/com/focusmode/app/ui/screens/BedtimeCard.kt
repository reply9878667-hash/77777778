package com.focusmode.app.ui.screens

import androidx.compose.material3.Icon
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.Icons
import android.app.TimePickerDialog
import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.BedtimeRules
import com.focusmode.app.data.BedtimeState
import com.focusmode.app.data.BedtimeStore
import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

/**
 * Bedtime Mode, as one compact card in the Blocking section: a switch, the start and end time,
 * and the apps it closes. It has its own schedule and its own app list, so the Focus session's
 * blocked apps are never changed from here (and the other way round).
 */
@Composable
internal fun BedtimeCard(
    bedtime: BedtimeState,
    apps: List<AppInfo>,
    permissions: PermissionStatus,
    onEnabled: (Boolean) -> Unit,
    onTimes: (startMin: Int, endMin: Int) -> Boolean,
    onApps: (Set<String>) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    var picking by remember { mutableStateOf(false) }
    // Times and apps stay folded until the header is tapped; the switch and the status line are always visible.
    var open by remember { mutableStateOf(false) }
    var timeError by remember { mutableStateOf(false) }

    // Apps that were uninstalled stay in the saved list but are not shown or counted.
    val byPkg = remember(apps) { apps.associateBy { it.packageName } }
    val selected = remember(bedtime.apps, byPkg) {
        bedtime.apps.mapNotNull { byPkg[it] }.sortedBy { it.label.lowercase() }
    }

    // Refreshes the "active now" line once a minute.
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            delay(30_000)
            value = System.currentTimeMillis()
        }
    }
    val active = BedtimeRules.active(bedtime, BedtimeStore.minuteOfDay(now))

    fun pickTime(initial: Int, onPicked: (Int) -> Unit) {
        TimePickerDialog(
            context,
            { _, h, m -> onPicked(h * 60 + m) },
            initial / 60, initial % 60,
            DateFormat.is24HourFormat(context)
        ).show()
    }

    FocusCard(modifier = modifier, padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), highlight = bedtime.enabled) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { open = !open }) {
                    Text("Bedtime Mode", style = MaterialTheme.typography.titleMedium)
                    Text(
                        when {
                            !bedtime.enabled -> "Block chosen apps every night"
                            active -> "ON now • apps unlock at ${BedtimeRules.format(bedtime.endMin)}"
                            else -> "Scheduled • blocks at ${BedtimeRules.format(bedtime.startMin)}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (bedtime.enabled) c.accent else c.muted
                    )
                }
                Icon(
                    if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    if (open) "Hide details" else "Show details",
                    tint = c.muted,
                    modifier = Modifier.clickable { open = !open }
                )
                Spacer(Modifier.size(8.dp))
                FocusSwitch(
                    checked = bedtime.enabled,
                    onCheckedChange = {
                        onEnabled(it)
                        // Nothing to block yet: go straight to choosing apps.
                        if (it && bedtime.apps.isEmpty()) picking = true
                    }
                )
            }

            if (open) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                SoftChip(
                    text = "From ${BedtimeRules.format(bedtime.startMin)}",
                    selected = false,
                    onClick = {
                        pickTime(bedtime.startMin) { timeError = !onTimes(it, bedtime.endMin) }
                    }
                )
                SoftChip(
                    text = "To ${BedtimeRules.format(bedtime.endMin)}",
                    selected = false,
                    onClick = {
                        pickTime(bedtime.endMin) { timeError = !onTimes(bedtime.startMin, it) }
                    }
                )
            }
            Text(
                if (timeError) "Start and end time can't be the same."
                else "Every day" + if (bedtime.startMin > bedtime.endMin) ", overnight into the next morning." else ".",
                style = MaterialTheme.typography.bodySmall,
                color = if (timeError) c.warning else c.muted,
                modifier = Modifier.padding(top = 6.dp)
            )

            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth().clickable { picking = true },
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selected.isEmpty()) {
                    Text(
                        "No apps selected",
                        style = MaterialTheme.typography.bodyMedium,
                        color = c.muted,
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    selected.take(MAX_ICONS).forEach {
                        AppIcon(it.packageName, 28.dp)
                        Spacer(Modifier.size(6.dp))
                    }
                    Text(
                        selected.take(2).joinToString(", ") { it.label } +
                            if (selected.size > 2) " +${selected.size - 2}" else "",
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        modifier = Modifier.weight(1f)
                    )
                }
                TextButton(onClick = { picking = true }) {
                    Text(if (selected.isEmpty()) "Choose apps" else "Edit (${selected.size})", color = c.accent)
                }
            }

            }

            if (bedtime.enabled && !permissions.accessibility) {
                Text(
                    "Turn on LockDistra's Accessibility access in Settings, or apps can't be blocked.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning,
                    modifier = Modifier.padding(top = 4.dp)
                )
            } else if (bedtime.enabled && !permissions.notifications) {
                Text(
                    "Notifications are off, so you won't be told when Bedtime starts and ends. Blocking still works.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }

    if (picking) {
        BedtimeAppPicker(
            apps = apps.filter { !it.isSettings },
            selected = bedtime.apps,
            onChange = onApps,
            onDismiss = { picking = false }
        )
    }
}

private const val MAX_ICONS = 5

/** Multi-select list. Every tick is saved at once, like the rest of Blocking. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BedtimeAppPicker(
    apps: List<AppInfo>,
    selected: Set<String>,
    onChange: (Set<String>) -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var query by remember { mutableStateOf("") }
    val q = query.trim()
    val shown = if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(Modifier.padding(horizontal = 20.dp).navigationBarsPadding()) {
            Text("Bedtime apps", style = MaterialTheme.typography.titleLarge)
            Text(
                "${apps.count { it.packageName in selected }} selected. Calls and emergency services are never blocked.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            Spacer(Modifier.height(12.dp))
            SearchField(value = query, onValueChange = { query = it })
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f, fill = false)) {
                items(shown, key = { it.packageName }) { app ->
                    val on = app.packageName in selected
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onChange(if (on) selected - app.packageName else selected + app.packageName) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(app.packageName, 36.dp)
                        Spacer(Modifier.size(12.dp))
                        Text(app.label, style = MaterialTheme.typography.bodyLarge, maxLines = 1, modifier = Modifier.weight(1f))
                        Checkbox(
                            checked = on,
                            onCheckedChange = { onChange(if (it) selected + app.packageName else selected - app.packageName) },
                            colors = CheckboxDefaults.colors(checkedColor = c.accent)
                        )
                    }
                }
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) {
                Text("Done", color = c.accent)
            }
        }
    }
}
