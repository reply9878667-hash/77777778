package com.focusmode.app.service

import android.content.Context
import com.focusmode.app.data.FocusOffMethod
import com.focusmode.app.data.FocusOffRules
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.LockStore
import com.focusmode.app.data.StudyCheckInRules
import com.focusmode.app.data.StudyCheckInRules.Step
import com.focusmode.app.data.online.OnlineManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Study Check-In, driven by the existing [FocusEngine.process] (the foreground service ticks it every second, and the
 * existing doze-safe alarm / app resume call it too). No service, timer or listener of its own.
 *
 *  - [process] shows the prompt when due, calls a check-in missed one minute later, and (Online Approval only) tells
 *    the trusted phone once.
 *  - [confirm] is "I'm Studying".
 *
 * Nothing here touches the Focus / Pomodoro timer, the blocking lists or the session itself.
 */
object StudyCheckInEngine {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sending = AtomicBoolean(false)

    // In-memory only: they just space out retries for the one miss that is still unsent. If the process dies they
    // start again, which is fine because the persisted "handled" number and the Worker's record stop any duplicate.
    @Volatile private var triesSeq = 0L
    @Volatile private var tries = 0
    @Volatile private var lastTryAt = 0L

    /** Safe to call often and from any thread (the store makes each step happen once). */
    fun process(context: Context, s: FocusState, now: Long) {
        val app = context.applicationContext
        val store = FocusStore.get(app)
        when (StudyCheckInRules.decide(s.focusActive, s.studyMin, s.studyNextAt, s.studyDeadline, now)) {
            Step.PROMPT -> {
                if (!Notifications.canShowStudyCheckIn(app)) {
                    // Nobody could see it (notifications are off): skip this turn. Never a "missed" check-in.
                    store.skipStudyCheckIn(now)
                } else {
                    val seq = store.beginStudyCheckIn(now)
                    if (seq != 0L && !Notifications.postStudyCheckIn(app, seq)) store.dropStudyCheckIn()
                }
            }
            Step.MISSED -> {
                if (store.markStudyCheckInMissed(now) != 0L) Notifications.cancelStudyCheckIn(app)
            }
            Step.EXPIRED -> {
                store.dropStudyCheckIn()
                Notifications.cancelStudyCheckIn(app)
            }
            Step.NONE -> Unit
        }
        sendAlertIfDue(app, store.current(), now)
    }

    /** "I'm Studying": records the confirmation and removes the prompt. Returns true if it counted. */
    fun confirm(context: Context, seq: Long): Boolean {
        val app = context.applicationContext
        val ok = FocusStore.get(app).confirmStudyCheckIn(seq, System.currentTimeMillis())
        Notifications.cancelStudyCheckIn(app)
        return ok
    }

    /**
     * The OFF method that really protects Focus Mode right now (the same rule the OFF button uses): Online Approval
     * only counts while the trusted phone is still connected and set up.
     */
    private fun effectiveOffMethod(context: Context): FocusOffMethod {
        val chosen = FocusStore.get(context).current().offMethod
        val online = OnlineManager.get(context)
        val st = online.state.value
        val error = FocusOffRules.setupError(
            chosen, LockStore.get(context).state.value.enabled, st.phoneConnected, st.hasRecovery, online.configured,
        )
        return FocusOffRules.effective(chosen, error)
    }

    private fun sendAlertIfDue(app: Context, s: FocusState, now: Long) {
        // Cheap checks first: this runs every second.
        if (s.studyMissSeq <= s.studySentSeq) return
        if (triesSeq != s.studyMissSeq) { triesSeq = s.studyMissSeq; tries = 0; lastTryAt = 0L }
        val due = StudyCheckInRules.alertDue(
            s.studyMissSeq, s.studySentSeq, s.studyMissAt, now, effectiveOffMethod(app), tries, lastTryAt,
        )
        if (!due) {
            // Too old, out of tries, or the method is not Online Approval: this miss is finished, nothing is sent.
            val old = now - s.studyMissAt > StudyCheckInRules.ALERT_MAX_AGE_MS
            val method = effectiveOffMethod(app)
            if (old || tries >= StudyCheckInRules.ALERT_MAX_TRIES || !StudyCheckInRules.alertAllowed(method)) {
                FocusStore.get(app).markStudyAlertHandled(s.studyMissSeq)
            }
            return
        }
        if (!sending.compareAndSet(false, true)) return // one send at a time: no duplicate for the same miss
        val seq = s.studyMissSeq
        val id = StudyCheckInRules.alertId(seq, s.studyMissAt)
        tries++
        lastTryAt = now
        scope.launch {
            try {
                if (OnlineManager.get(app).notifyStudyCheckInMissed(id)) {
                    FocusStore.get(app).markStudyAlertHandled(seq)
                }
            } catch (_: Exception) {
                // Stays unsent; the next tick retries after a short gap, up to the limits in StudyCheckInRules.
            } finally {
                sending.set(false)
            }
        }
    }
}
