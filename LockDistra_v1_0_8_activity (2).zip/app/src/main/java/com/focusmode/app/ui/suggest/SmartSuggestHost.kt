package com.focusmode.app.ui.suggest

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.SmartSuggest
import com.focusmode.app.data.SmartSuggestStore
import com.focusmode.app.data.SuggestFeature
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

/**
 * Smart Feature Suggestions: a clean card at the bottom of Home that points out ONE feature the person has not used
 * yet (name, what it does, benefits, a button to use it). [inUse] lists the features already in use, which are never
 * suggested. The rules (when, how often, never twice at once) are in [SmartSuggest].
 *
 * Buttons: the action, "Not now" (it may come back once, a few openings later) and "Don't show again".
 * There is no advertising of any kind; the text is LockDistra's own.
 */
@Composable
fun SmartSuggestHost(
    store: SmartSuggestStore,
    /** The screen is quiet: Home is open and no dialog, session or other hint is in the way. */
    enabled: Boolean,
    inUse: Set<String>,
    /** The person pressed the action button of the feature with this id. */
    onAction: (String) -> Unit,
) {
    var current by remember { mutableStateOf<SuggestFeature?>(null) }
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(enabled) {
        if (!enabled) { visible = false; return@LaunchedEffect }
        if (current != null) { visible = true; return@LaunchedEffect }
        // Let the screen settle first, and never interrupt the first moments on Home.
        delay(3500)
        val f = SmartSuggest.pick(store.state.value, inUse, System.currentTimeMillis())
        if (f != null) {
            store.markShown(f.id)
            current = f
            visible = true
        }
    }

    // Something the person set up while the card was open: drop it.
    val showingId = current?.id
    LaunchedEffect(showingId, inUse) {
        if (showingId != null && showingId in inUse) {
            current = null
            visible = false
        }
    }

    Box(Modifier.fillMaxSize()) {
        AnimatedVisibility(
            visible = visible && current != null,
            enter = slideInVertically { it / 2 } + fadeIn(),
            exit = slideOutVertically { it / 2 } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            val f = current ?: return@AnimatedVisibility
            SuggestionCard(
                feature = f,
                onAction = { visible = false; current = null; onAction(f.id) },
                onLater = { visible = false; current = null },
                onNever = { store.dismissForever(f.id); visible = false; current = null },
            )
        }
    }
}

@Composable
private fun SuggestionCard(feature: SuggestFeature, onAction: () -> Unit, onLater: () -> Unit, onNever: () -> Unit) {
    val c = FocusTheme.colors
    Box(Modifier.navigationBarsPadding().padding(start = 16.dp, end = 16.dp, bottom = 88.dp)) {
        FocusCard(padding = PaddingValues(horizontal = 18.dp, vertical = 16.dp), highlight = true) {
            Column(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Lightbulb, null, tint = c.accent, modifier = Modifier.size(18.dp))
                    Text("Suggestion for you", style = MaterialTheme.typography.labelMedium, color = c.accent)
                }
                Spacer(Modifier.height(6.dp))
                Text(feature.title, style = MaterialTheme.typography.titleMedium, color = c.text)
                Spacer(Modifier.height(4.dp))
                Text(feature.what, style = MaterialTheme.typography.bodySmall, color = c.muted)
                Spacer(Modifier.height(10.dp))
                feature.benefits.forEach { b ->
                    Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(bottom = 4.dp)) {
                        Icon(Icons.Rounded.Check, null, tint = c.accent, modifier = Modifier.padding(top = 2.dp).size(14.dp))
                        Spacer(Modifier.size(8.dp))
                        Text(b, style = MaterialTheme.typography.bodySmall, color = c.text)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = onAction,
                        colors = ButtonDefaults.buttonColors(containerColor = c.accent)
                    ) { Text(feature.actionLabel) }
                    TextButton(onClick = onLater) { Text("Not now", color = c.muted) }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onNever) { Text("Don't show again", color = c.muted, style = MaterialTheme.typography.labelSmall) }
                }
            }
        }
    }
}
