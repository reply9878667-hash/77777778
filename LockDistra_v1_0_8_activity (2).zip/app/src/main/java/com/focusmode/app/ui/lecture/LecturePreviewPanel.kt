package com.focusmode.app.ui.lecture

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.LinkInteractionListener
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.StudyApi
import com.focusmode.app.data.StudyNative
import com.focusmode.app.data.StudyRules
import com.focusmode.app.data.StudyStore
import com.focusmode.app.data.StudyVideo
import com.focusmode.app.ui.components.ChannelSubscribeControl
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Shown under a Study video that is playing (portrait), like the details under a YouTube video: title, channel, Subscribe, and
 * the one action "Start Focus Mode" (the video then plays alone in the locked player).
 */
@Composable
fun LecturePreviewPanel(video: StudyVideo, onStartFocus: () -> Unit) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val store = remember { StudyStore.get(context) }

    // What the list knew about the video. A video that came from YouTube's search page (not the API) has no description and only an
    // approximate upload time, so the full description and the real upload time are asked for once, right when the video opens.
    var description by remember(video.id) { mutableStateOf(video.description) }
    var publishedAt by remember(video.id) { mutableStateOf(video.publishedAt) }
    var loading by remember(video.id) { mutableStateOf(true) }
    LaunchedEffect(video.id) {
        val info = withContext(Dispatchers.IO) {
            // 1) The watch page: the creator's FULL notes, free (no daily API limit used).
            var found = StudyNative.watchInfo(video.id)
            // 2) Otherwise the API (1 unit): it gives the start of the description and the exact upload time.
            if (found == null || found.description.isEmpty()) {
                val api = runCatching { StudyApi(store).details(listOf(video.id)).firstOrNull() }.getOrNull()
                if (api != null) {
                    found = StudyNative.WatchInfo(
                        description = found?.description?.ifEmpty { api.description } ?: api.description,
                        publishedAt = if ((found?.publishedAt ?: 0L) > 0L) found!!.publishedAt else api.publishedAt,
                    )
                }
            }
            found
        }
        if (info != null) {
            if (info.description.length >= description.length) description = info.description
            if (info.publishedAt > 0L) publishedAt = info.publishedAt
        }
        loading = false
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text(video.title.ifBlank { "Study video" }, style = MaterialTheme.typography.titleMedium, color = c.text, maxLines = 3, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                listOf(video.channelTitle, StudyRules.timeAgo(publishedAt)).filter { it.isNotEmpty() }.joinToString("  ·  "),
                style = MaterialTheme.typography.bodyMedium, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (video.channelId.isNotEmpty()) {
                Spacer(Modifier.width(8.dp))
                ChannelSubscribeControl(store, video.channelId, video.channelTitle, compact = true)
            }
        }
        // Video length, and the upload time, as YouTube shows them under a video.
        val facts = listOfNotNull(
            video.seconds.takeIf { it > 0 }?.let { "Length " + StudyRules.formatLength(it) },
            StudyRules.timeAgo(publishedAt).takeIf { it.isNotEmpty() }?.let { "Uploaded $it" },
        )
        if (facts.isNotEmpty()) {
            Spacer(Modifier.height(2.dp))
            Text(facts.joinToString("  ·  "), style = MaterialTheme.typography.bodySmall, color = c.muted)
        }

        // The description is OPEN by default: creators put their notes, chapters and links there. The title row folds / opens it.
        var open by remember(video.id) { mutableStateOf(true) }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Description", style = MaterialTheme.typography.titleSmall, color = c.text, modifier = Modifier.weight(1f))
            Switch(
                checked = open, onCheckedChange = { open = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White, checkedTrackColor = c.accent,
                    uncheckedThumbColor = c.muted, uncheckedTrackColor = c.cardHigh,
                ),
            )
        }
        if (open) {
            Spacer(Modifier.height(4.dp))
            when {
                description.isNotBlank() -> {
                    val linkColor = Color(0xFF8AB4F8)
                    val text = remember(description) { linkified(description, linkColor) { openLink(context, it) } }
                    SelectionContainer {
                        Text(text, style = MaterialTheme.typography.bodyMedium, color = c.muted, modifier = Modifier.fillMaxWidth())
                    }
                }
                loading -> Text("Loading description…", style = MaterialTheme.typography.bodySmall, color = c.muted)
                else -> Text("This video has no description (or it could not be loaded right now).", style = MaterialTheme.typography.bodySmall, color = c.muted)
            }
        }
        Spacer(Modifier.height(14.dp))
        PrimaryButton("Start Focus Mode", onStartFocus, Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text(
            "Like this video? Start Focus Mode to watch it alone, with every other app blocked.",
            style = MaterialTheme.typography.bodySmall, color = c.muted
        )
    }
}

private val URL_REGEX = Regex("https?://[^\\s<>\"]+")

/** The description with every web address underlined and tappable (opens in the browser / the matching app). */
private fun linkified(text: String, linkColor: Color, onOpen: (String) -> Unit): androidx.compose.ui.text.AnnotatedString =
    buildAnnotatedString {
        var last = 0
        for (m in URL_REGEX.findAll(text)) {
            // A full stop, comma or bracket right after a link belongs to the sentence, not to the link.
            val url = m.value.trimEnd('.', ',', ')', ']', '!', '?', ';', ':', '\'')
            if (url.length < 11) continue
            append(text.substring(last, m.range.first))
            withLink(
                LinkAnnotation.Clickable(
                    tag = url,
                    styles = TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)),
                    linkInteractionListener = LinkInteractionListener { onOpen(url) },
                )
            ) { append(url) }
            last = m.range.first + url.length
        }
        append(text.substring(last))
    }

private fun openLink(context: android.content.Context, url: String) {
    try {
        context.startActivity(
            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))
                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    } catch (e: Exception) {
        android.widget.Toast.makeText(context, "No app can open this link", android.widget.Toast.LENGTH_SHORT).show()
    }
}
