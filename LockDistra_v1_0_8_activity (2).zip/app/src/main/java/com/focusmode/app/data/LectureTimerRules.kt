package com.focusmode.app.data

/**
 * The Focus timer is attached to the lecture (Lecture Lock): it runs only while the lecture really plays on screen.
 * Paused, buffering (slow network), or the person left the player (Home, another app, screen off): the timer stands still,
 * and a "Back to Focus" notification brings the person back. Plain Kotlin, unit tested on the JVM.
 */
object LectureTimerRules {

    /** The person has been away from the player this long before the "Back to Focus" notification is posted. */
    const val AWAY_NOTICE_MS = 4_000L

    /** One check never moves the timer by more than this (a stopped service must not credit a long gap). */
    const val MAX_STEP_MS = 60_000L

    /**
     * True when the session timer must stand still: a plain Focus session that has a lecture, whose lecture is not playing right now.
     * Not for a Pomodoro (it has its own rounds), and not after the lecture counted as finished (then the timer runs normally).
     */
    fun shouldFreeze(focusActive: Boolean, hasLecture: Boolean, pomodoroActive: Boolean, lectureDone: Boolean, playing: Boolean): Boolean =
        focusActive && hasLecture && !pomodoroActive && !lectureDone && !playing

    /** How far the end of the session moves for the time since the previous check (0 for the first check). */
    fun stepMs(lastCheckMs: Long, nowMs: Long): Long = if (lastCheckMs <= 0L) 0L else (nowMs - lastCheckMs).coerceIn(0L, MAX_STEP_MS)

    /** "Back to Focus" is posted once, after the person was in the player and then stayed away for [AWAY_NOTICE_MS]. */
    fun shouldNotify(frozen: Boolean, seenInPlayer: Boolean, playerVisible: Boolean, awayMs: Long, alreadyNotified: Boolean): Boolean =
        frozen && seenInPlayer && !playerVisible && awayMs >= AWAY_NOTICE_MS && !alreadyNotified
}
