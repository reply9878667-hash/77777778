package com.focusmode.app.ui.onboarding

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.BuddyMood
import com.focusmode.app.data.OnboardingCelebration
import com.focusmode.app.data.Typewriter
import com.focusmode.app.ui.components.FocusBackground
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

/**
 * Onboarding Part 2D: the final celebration. The same mascot as on every other onboarding screen pops
 * in, waves, then dances (see [BuddyDance]); a soft glow pulses behind it and a little confetti drifts
 * down. The mascot says "Awesome, <name>!" in its speech bubble, using the name from question 1, and
 * one Continue button ends the onboarding.
 *
 * Scene: pop in -> wave and greet (typing the headline) -> dance while the rest is typed -> relaxed
 * dance until the person continues. Tap the bubble to skip the typing; tap the mascot to make it react.
 *
 * @param name the answer to question 1 (the screen trims it and falls back gracefully if empty).
 * @param onContinue the person pressed Continue: the flow hands the answers on and finishes.
 * @param onBack system back: returns to question 7 with every answer still there.
 */
@Composable
fun CelebrationScreen(
    name: String,
    onContinue: () -> Unit,
    onBack: () -> Unit,
) {
    val c = FocusTheme.colors
    BackHandler(onBack = onBack)

    val headline = remember(name) { OnboardingCelebration.headline(name) }
    val body = OnboardingCelebration.BODY
    val headTotal = remember(headline) { Typewriter.length(headline) }
    val bodyTotal = remember(body) { Typewriter.length(body) }

    // Remembered across rotation, so turning the phone shows the finished scene instead of replaying it.
    var played by rememberSaveable { mutableStateOf(false) }
    var shownHead by remember { mutableIntStateOf(if (played) headTotal else 0) }
    var shownBody by remember { mutableIntStateOf(if (played) bodyTotal else 0) }
    var skipped by remember { mutableStateOf(false) }
    var talking by remember { mutableStateOf(false) }
    var dancing by remember { mutableStateOf(played) }
    var reactionTick by remember { mutableIntStateOf(0) }

    val mascotIn = remember { Animatable(if (played) 1f else 0f) }
    val bubbleIn = remember { Animatable(if (played) 1f else 0f) }

    LaunchedEffect(Unit) {
        if (played) return@LaunchedEffect
        mascotIn.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow))
    }
    LaunchedEffect(Unit) {
        if (played) return@LaunchedEffect
        delay(1100) // greet first (waving, happy), then start dancing
        dancing = true
    }
    LaunchedEffect(Unit) {
        if (played) return@LaunchedEffect
        delay(500)
        bubbleIn.animateTo(1f, tween(450))
        talking = true
        try {
            for (i in 1..headTotal) {
                if (skipped) break
                shownHead = i
                delay(38)
            }
            shownHead = headTotal
            if (!skipped) delay(250)
            for (i in 1..bodyTotal) {
                if (skipped) break
                shownBody = i
                delay(22)
            }
            shownBody = bodyTotal
            played = true
        } finally {
            talking = false
        }
    }

    val buttonReady = shownHead >= headTotal
    val buttonAlpha by animateFloatAsState(if (buttonReady) 1f else 0f, tween(420), label = "celebrationButton")

    // A soft glow behind the mascot that breathes.
    val glowTransition = rememberInfiniteTransition(label = "celebrationGlow")
    val glow = glowTransition.animateFloat(
        initialValue = 0.28f, targetValue = 0.5f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Reverse),
        label = "glowAlpha",
    )

    val mascot: @Composable (Modifier) -> Unit = { m ->
        Box(
            m.drawBehind {
                drawCircle(
                    Brush.radialGradient(
                        listOf(c.glow.copy(alpha = glow.value), Color.Transparent),
                        center = center, radius = size.minDimension * 0.62f
                    ),
                    radius = size.minDimension * 0.62f, center = center
                )
            },
            contentAlignment = Alignment.Center
        ) {
            FocusBuddy(
                pose = if (talking) BuddyPose.Talking else BuddyPose.Idle,
                mood = if (dancing) BuddyMood.Celebrating else BuddyMood.Happy,
                reactionTick = reactionTick,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        val e = mascotIn.value
                        alpha = e.coerceIn(0f, 1f)
                        scaleX = 0.6f + 0.4f * e
                        scaleY = 0.6f + 0.4f * e
                        translationY = (1f - e) * 50.dp.toPx()
                    }
                    // Tap the mascot: it reacts (a nod, a tilt or a hop) on top of its dance.
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                        reactionTick++
                    }
            )
        }
    }

    val bubble: @Composable (BubbleTail) -> Unit = { tail ->
        BuddySpeechBubble(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    alpha = bubbleIn.value
                    translationY = (1f - bubbleIn.value) * 18.dp.toPx()
                }
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    skipped = true
                },
            tail = tail,
        ) {
            TypedText(
                full = headline,
                shownUnits = shownHead,
                style = MaterialTheme.typography.headlineMedium,
                color = c.text,
            )
            Spacer(Modifier.height(10.dp))
            TypedText(
                full = body,
                shownUnits = shownBody,
                style = MaterialTheme.typography.bodyLarge,
                color = c.muted,
            )
        }
    }

    val button: @Composable () -> Unit = {
        PrimaryButton(
            text = "Continue",
            onClick = onContinue,
            enabled = buttonReady,
            modifier = Modifier.graphicsLayer {
                alpha = buttonAlpha
                translationY = (1f - buttonAlpha) * 14.dp.toPx()
            }
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            // Opaque and touch-swallowing, like the other onboarding screens.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        FocusBackground(Modifier.matchParentSize())
        Confetti(Modifier.matchParentSize())

        BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
            val fullHeight = maxHeight
            val landscape = maxWidth > maxHeight
            val scroll = rememberScrollState()

            if (landscape) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(0.95f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        mascot(Modifier.fillMaxSize())
                    }
                    Column(
                        Modifier.weight(1.05f).fillMaxHeight().verticalScroll(scroll),
                        verticalArrangement = Arrangement.Center
                    ) {
                        bubble(BubbleTail.Start)
                        Spacer(Modifier.height(20.dp))
                        button()
                    }
                }
            } else {
                // Portrait: the mascot is the main attraction (about 46% of the height), message and
                // button below. Short screens scroll instead of squeezing anything.
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = fullHeight)
                        .verticalScroll(scroll)
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Spacer(Modifier.height(12.dp)) // room for the jumps
                    mascot(Modifier.fillMaxWidth().height((fullHeight * 0.46f).coerceIn(190.dp, 400.dp)))
                    Spacer(Modifier.height(6.dp))
                    bubble(BubbleTail.Top)
                    Spacer(Modifier.height(24.dp))
                    button()
                    Spacer(Modifier.height(8.dp))
                }
            }
        }
    }
}

// ---- Confetti ----------------------------------------------------------------------------------

private class ConfettiPiece(
    val x: Float,        // 0..1 across the width
    val offset: Float,   // where in its fall it starts, 0..1
    val speed: Float,    // falls per second (fraction of the height)
    val sway: Float,     // dp of side to side drift
    val swayRate: Float,
    val phase: Float,
    val size: Float,     // dp
    val spin: Float,     // degrees per second
    val round: Boolean,
    val color: Int,
)

/**
 * A light sprinkling of confetti in the app's own colours. Every piece's position is worked out from
 * one clock (no per-piece state, no allocations of objects that live on), drawn in one Canvas, so it
 * costs almost nothing. It fades in at the start instead of appearing all at once.
 */
@Composable
private fun Confetti(modifier: Modifier) {
    val c = FocusTheme.colors
    val palette = remember(c.gradStart, c.gradMid, c.gradEnd, c.leafLight, c.blossom, c.accent) {
        listOf(c.gradStart, c.gradMid, c.gradEnd, c.leafLight, c.blossom, c.accent)
    }
    val pieces = remember {
        val r = Random(2024)
        List(34) {
            ConfettiPiece(
                x = r.nextFloat(), offset = r.nextFloat(), speed = 0.07f + r.nextFloat() * 0.09f,
                sway = 6f + r.nextFloat() * 14f, swayRate = 0.8f + r.nextFloat() * 1.4f,
                phase = r.nextFloat() * 6.28f, size = 5f + r.nextFloat() * 5f,
                spin = (r.nextFloat() - 0.5f) * 360f, round = r.nextInt(3) == 0,
                color = r.nextInt(6),
            )
        }
    }
    var timeMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { now -> timeMs = (now - start) / 1_000_000L }
        }
    }
    // Fades in on first composition.
    val visible = remember { Animatable(0f) }
    LaunchedEffect(Unit) { visible.animateTo(1f, tween(1200)) }

    Canvas(modifier) {
        val t = timeMs / 1000f
        val a = visible.value
        if (a <= 0f) return@Canvas
        for (p in pieces) {
            val fall = (t * p.speed + p.offset) % 1f
            val y = fall * (size.height + 40.dp.toPx()) - 20.dp.toPx()
            val x = p.x * size.width + p.sway.dp.toPx() * sin(t * p.swayRate + p.phase)
            val s = p.size.dp.toPx()
            val col = palette[p.color].copy(alpha = 0.8f * a)
            if (p.round) {
                drawCircle(col, radius = s * 0.5f, center = Offset(x, y))
            } else {
                rotate(t * p.spin + p.phase * 57f, Offset(x, y)) {
                    drawRoundRect(col, Offset(x - s / 2f, y - s * 0.3f), Size(s, s * 0.6f), CornerRadius(s * 0.15f))
                }
            }
        }
    }
}
