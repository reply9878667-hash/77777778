package com.focusmode.app.ui.onboarding

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.Typewriter
import com.focusmode.app.ui.components.BrandMark
import com.focusmode.app.ui.components.FocusBackground
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

/** The mascot's first words (kept exactly as written). */
const val WELCOME_HEADLINE = "Hey there! \uD83D\uDC4B Welcome!"
const val WELCOME_BODY =
    "Main tumhari focus journey mein tumhara dost banne wala hoon. " +
        "Chalo, pehle tumhare baare mein thoda jaante hain!"

/**
 * Part 1 of onboarding: the mascot waves, introduces itself in a speech bubble and waits for the
 * person to press Start. Nothing is asked and nothing is saved here.
 *
 * The scene plays like this: pop in and wave -> say the headline (still waving) -> say the rest ->
 * a short thinking moment ("what shall I ask first?") -> relaxed idle. Tapping the bubble skips the
 * typing. [skipIntro] shows the finished scene at once (used when returning from the questions). The button appears as soon as the headline is written; it never waits for the full text.
 *
 * [onHaveAccount] (Task 3): when set, a small text link under the button lets a person who already registered
 * (new phone, reinstall) go to the login screen instead of the questions.
 */
@Composable
fun WelcomeScreen(onContinue: () -> Unit, skipIntro: Boolean = false, onHaveAccount: (() -> Unit)? = null) {
    val c = FocusTheme.colors

    // Remembered across rotation, so turning the phone shows the finished scene instead of replaying it.
    var played by rememberSaveable { mutableStateOf(skipIntro) }
    val headTotal = remember { Typewriter.length(WELCOME_HEADLINE) }
    val bodyTotal = remember { Typewriter.length(WELCOME_BODY) }
    var shownHead by remember { mutableIntStateOf(if (played) headTotal else 0) }
    var shownBody by remember { mutableIntStateOf(if (played) bodyTotal else 0) }
    var pose by remember { mutableStateOf(if (played) BuddyPose.Idle else BuddyPose.Greeting) }
    var skipped by remember { mutableStateOf(false) }

    // Entrance: the mascot pops in, the bubble follows.
    val mascotIn = remember { Animatable(if (played) 1f else 0f) }
    val bubbleIn = remember { Animatable(if (played) 1f else 0f) }

    LaunchedEffect(Unit) {
        if (played) return@LaunchedEffect
        mascotIn.animateTo(1f, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessLow))
    }
    LaunchedEffect(Unit) {
        if (played) return@LaunchedEffect
        delay(450)
        bubbleIn.animateTo(1f, tween(500))
    }
    LaunchedEffect(Unit) {
        if (played) return@LaunchedEffect
        delay(900) // hello wave first, then speak
        pose = BuddyPose.GreetingTalking
        for (i in 1..headTotal) {
            if (skipped) break
            shownHead = i
            delay(42)
        }
        shownHead = headTotal
        if (!skipped) delay(300)
        pose = BuddyPose.Talking
        for (i in 1..bodyTotal) {
            if (skipped) break
            shownBody = i
            delay(30)
        }
        shownBody = bodyTotal
        pose = BuddyPose.Thinking
        delay(1500)
        pose = BuddyPose.Idle
        played = true
    }

    val buttonReady = shownHead >= headTotal
    val buttonAlpha by animateFloatAsState(if (buttonReady) 1f else 0f, tween(420), label = "welcomeButton")

    val mascot: @Composable (Modifier) -> Unit = { m ->
        FocusBuddy(
            pose = pose,
            modifier = m.graphicsLayer {
                val e = mascotIn.value
                alpha = e.coerceIn(0f, 1f)
                scaleX = 0.7f + 0.3f * e
                scaleY = 0.7f + 0.3f * e
                translationY = (1f - e) * 40.dp.toPx()
            }
        )
    }

    val bubble: @Composable (BubbleTail) -> Unit = { tail ->
        BuddySpeechBubble(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    alpha = bubbleIn.value
                    translationY = (1f - bubbleIn.value) * 18.dp.toPx()
                }
                // Tap the bubble to skip the typing.
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                    skipped = true
                },
            tail = tail,
        ) {
            TypedText(
                full = WELCOME_HEADLINE,
                shownUnits = shownHead,
                style = MaterialTheme.typography.headlineMedium,
                color = c.text,
            )
            Spacer(Modifier.height(10.dp))
            TypedText(
                full = WELCOME_BODY,
                shownUnits = shownBody,
                style = MaterialTheme.typography.bodyLarge,
                color = c.muted,
            )
        }
    }

    val button: @Composable () -> Unit = {
        PrimaryButton(
            text = "Let's Start",
            onClick = onContinue,
            enabled = buttonReady,
            modifier = Modifier.graphicsLayer {
                alpha = buttonAlpha
                translationY = (1f - buttonAlpha) * 14.dp.toPx()
            }
        )
    }

    val haveAccount: @Composable () -> Unit = {
        if (onHaveAccount != null) {
            TextButton(
                onClick = onHaveAccount,
                modifier = Modifier.graphicsLayer { alpha = buttonAlpha },
                enabled = buttonReady,
            ) {
                Text("I already have an account? Log in", color = c.accent, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold))
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            // Opaque and touch-swallowing: nothing underneath may show or react.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        FocusBackground(Modifier.matchParentSize())

        BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
            val fullHeight = maxHeight
            val landscape = maxWidth > maxHeight
            val scroll = rememberScrollState()

            if (landscape) {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(0.9f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                        mascot(Modifier.fillMaxSize())
                    }
                    Column(
                        Modifier
                            .weight(1.1f)
                            .fillMaxHeight()
                            .verticalScroll(scroll),
                        verticalArrangement = Arrangement.Center
                    ) {
                        bubble(BubbleTail.Start)
                        Spacer(Modifier.height(20.dp))
                        button()
                        haveAccount()
                    }
                }
            } else {
                // Portrait: mascot on top (about 42% of the height), bubble and button below.
                // Short screens scroll instead of squeezing anything.
                Column(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(min = fullHeight)
                        .verticalScroll(scroll)
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val mascotHeight = (fullHeight * 0.42f).coerceIn(150.dp, 360.dp)
                    mascot(Modifier.fillMaxWidth().height(mascotHeight))
                    Spacer(Modifier.height(6.dp))
                    bubble(BubbleTail.Top)
                    Spacer(Modifier.height(24.dp))
                    button()
                    haveAccount()
                    Spacer(Modifier.height(16.dp))
                    BrandMark(centered = true, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
