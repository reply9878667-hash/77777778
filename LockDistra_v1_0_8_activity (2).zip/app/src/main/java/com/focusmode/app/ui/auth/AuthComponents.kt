package com.focusmode.app.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.ui.theme.FocusTheme

/**
 * Full-screen page used by every account screen: the app's background colour, system-bar and keyboard insets,
 * scrolling when the keyboard or a small / landscape screen needs it, and a readable width on tablets. It also
 * swallows taps so nothing underneath can be pressed.
 */
@Composable
internal fun AuthPage(content: @Composable ColumnScope.() -> Unit) {
    val c = FocusTheme.colors
    Box(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .pointerInput(Unit) { detectTapGestures { } }
            .statusBarsPadding()
            .imePadding()
            .navigationBarsPadding(),
        contentAlignment = Alignment.TopCenter,
    ) {
        Column(
            Modifier
                .widthIn(max = 460.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            content = content,
        )
    }
}

@Composable
internal fun AuthHeading(title: String, subtitle: String) {
    val c = FocusTheme.colors
    Text(title, style = MaterialTheme.typography.headlineMedium, color = c.text)
    Spacer(Modifier.height(6.dp))
    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = c.muted)
}

@Composable
private fun authFieldColors() = FocusTheme.colors.let { c ->
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = c.text,
        unfocusedTextColor = c.text,
        errorTextColor = c.text,
        focusedBorderColor = c.accent,
        unfocusedBorderColor = c.stroke,
        errorBorderColor = c.warning,
        cursorColor = c.accent,
        errorCursorColor = c.warning,
        focusedLabelColor = c.accent,
        unfocusedLabelColor = c.muted,
        errorLabelColor = c.warning,
        focusedSupportingTextColor = c.muted,
        unfocusedSupportingTextColor = c.muted,
        errorSupportingTextColor = c.warning,
        errorTrailingIconColor = c.muted,
    )
}

/**
 * One input. [error] turns it amber and shows the message under it; [hint] is the quiet help text shown while
 * there is no error. [isPassword] adds the show / hide eye. Next moves to the next field, Done runs [onDone].
 */
@Composable
internal fun AuthTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    error: String?,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    isPassword: Boolean = false,
    last: Boolean = false,
    hint: String? = null,
    onDone: () -> Unit = {},
) {
    val focus = LocalFocusManager.current
    var visible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        enabled = enabled,
        isError = error != null,
        supportingText = (error ?: hint)?.let { text -> { Text(text) } },
        visualTransformation = if (isPassword && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(
            keyboardType = if (isPassword) KeyboardType.Password else keyboardType,
            imeAction = if (last) ImeAction.Done else ImeAction.Next,
        ),
        keyboardActions = KeyboardActions(
            onNext = { focus.moveFocus(FocusDirection.Down) },
            onDone = {
                focus.clearFocus()
                onDone()
            },
        ),
        trailingIcon = if (isPassword) {
            {
                IconButton(onClick = { visible = !visible }) {
                    Icon(
                        if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                        contentDescription = if (visible) "Hide password" else "Show password",
                    )
                }
            }
        } else null,
        colors = authFieldColors(),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.fillMaxWidth(),
    )
}

/** "Continue with Google" button. Swap [GoogleMark] for Google's official asset before publishing. */
@Composable
internal fun GoogleButton(text: String, loading: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val c = FocusTheme.colors
    val shape = RoundedCornerShape(28.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(shape)
            .background(if (c.isDark) c.card else Color.White)
            .border(BorderStroke(1.dp, c.stroke), shape)
            .clickable(enabled = enabled && !loading, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = c.accent)
        } else {
            GoogleMark()
        }
        Spacer(Modifier.size(12.dp))
        Text(
            text,
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 15.sp),
            color = if (c.isDark) c.text else Color(0xFF1F1F1F),
        )
    }
}

/** A plain "G" badge. Not the official multi-colour logo: use Google's brand asset for a store release. */
@Composable
private fun GoogleMark() {
    Box(
        Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(Color.White)
            .border(BorderStroke(1.dp, Color(0xFFDADCE0)), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
internal fun OrDivider() {
    val c = FocusTheme.colors
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        HorizontalDivider(Modifier.weight(1f), color = c.stroke)
        Text("or", Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall, color = c.muted)
        HorizontalDivider(Modifier.weight(1f), color = c.stroke)
    }
}

/** A message box: amber for an error, accent for good news. Announced by screen readers when it appears. */
@Composable
internal fun AuthMessage(text: String, isError: Boolean) {
    val c = FocusTheme.colors
    val tint = if (isError) c.warning else c.accent
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(tint.copy(alpha = 0.12f))
            .border(BorderStroke(1.dp, tint.copy(alpha = 0.45f)), shape)
            .padding(12.dp)
            .semantics { liveRegion = LiveRegionMode.Polite },
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Icon(Icons.Rounded.ErrorOutline, null, tint = tint, modifier = Modifier.size(20.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = c.text)
    }
}

/** "Already have an account?  Log in" */
@Composable
internal fun AuthSwitchRow(question: String, action: String, enabled: Boolean, onClick: () -> Unit) {
    val c = FocusTheme.colors
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Text(question, style = MaterialTheme.typography.bodyMedium, color = c.muted)
        TextButton(onClick = onClick, enabled = enabled) {
            Text(action, color = c.accent, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
internal fun AuthSkipButton(enabled: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
        Text("Skip for now", color = FocusTheme.colors.muted, textAlign = TextAlign.Center)
    }
}
