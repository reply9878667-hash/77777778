package com.focusmode.app.ui.tips

/**
 * One feature hint. It is shown on [screen] (the name of the `Screen` enum entry, e.g. "Home"), only once the person has
 * used the app enough ([minOpens] app launches, [minSessions] Focus sessions started).
 *
 * [target] is the key of a `Modifier.tipTarget(key)` on screen: when that element is visible it is spotlighted
 * (dimmed screen, glowing ring around it). Without a target, or when the element is not on screen, the hint appears as a
 * plain card at the bottom. [actionLabel] adds a "Try it" style button that calls the host's `onAction(id)`.
 */
data class Tip(
    val id: String,
    val screen: String,
    val title: String,
    val body: String,
    val target: String? = null,
    val actionLabel: String? = null,
    val minOpens: Int = 0,
    val minSessions: Int = 0,
)

data class TipsState(
    val enabled: Boolean = true,
    val opens: Int = 0,
    val sessions: Int = 0,
    val seen: Set<String> = emptySet(),
    val lastShownAt: Long = 0L,
)

object FeatureTips {
    /** At most one hint in this time, so features are introduced gradually, not all at once. */
    const val COOLDOWN_MS = 3L * 60 * 60 * 1000

    /**
     * The order is the order they are introduced in. To add a hint: add a line here, and (for a spotlight) put
     * `.tipTarget("your_key")` on the element.
     */
    val all: List<Tip> = listOf(
        Tip(
            id = "auto_focus", screen = "Home", target = "auto_chip", minOpens = 2,
            title = "Automatic Focus Mode",
            body = "Tap Auto to choose a start and end time. Focus Mode then turns on and off by itself, every day you pick.",
            actionLabel = "Set it up",
        ),
        Tip(
            id = "focus_profile", screen = "Home", minSessions = 1,
            title = "Focus Profiles",
            body = "Save different sets of blocked apps, for example one for study and one for work, and pick one before you start.",
            actionLabel = "Open profiles",
        ),
        Tip(
            id = "limits", screen = "Apps", minSessions = 2,
            title = "Daily app limits",
            body = "Give an app a daily time limit instead of blocking it fully. It closes by itself when the time is used up.",
            actionLabel = "Open limits",
        ),
        Tip(
            id = "pomodoro", screen = "Home", minSessions = 3,
            title = "Try Pomodoro",
            body = "Short focus rounds with breaks in between, on Home under the timer. Your blocked apps open again during each break.",
        ),
        Tip(
            id = "bedtime", screen = "Apps", minSessions = 3,
            title = "Bedtime mode",
            body = "Choose apps that close at night automatically, so late scrolling doesn't cost you sleep.",
        ),
        Tip(
            id = "prevent_changes", screen = "Settings", minSessions = 4,
            title = "Prevent changes",
            body = "Lock LockDistra's own settings so a rule can't be undone in a weak moment.",
        ),
        Tip(
            id = "app_lock", screen = "Settings", minSessions = 5,
            title = "App lock",
            body = "Protect LockDistra with a PIN, password or fingerprint, and use it as the way to turn Focus Mode off.",
        ),
    )

    /** The next hint to show on [screen] right now, or null (tips off, too soon after the last one, or nothing left). */
    fun pick(state: TipsState, screen: String, now: Long, tips: List<Tip> = all): Tip? {
        if (!state.enabled) return null
        if (now - state.lastShownAt < COOLDOWN_MS) return null
        return tips.firstOrNull {
            it.screen == screen && it.id !in state.seen &&
                state.opens >= it.minOpens && state.sessions >= it.minSessions
        }
    }
}
