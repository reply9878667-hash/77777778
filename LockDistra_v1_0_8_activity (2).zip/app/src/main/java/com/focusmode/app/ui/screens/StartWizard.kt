package com.focusmode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.mutableStateOf
import com.focusmode.app.data.StudyCheckInRules
import com.focusmode.app.ui.components.SoftChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.platform.LocalClipboardManager
import com.focusmode.app.data.LectureLink
import com.focusmode.app.data.AppLimit
import com.focusmode.app.data.FocusControl
import com.focusmode.app.data.FocusOffMethod
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.StartPreview
import com.focusmode.app.data.StartPreviewRules
import com.focusmode.app.ui.theme.FocusTheme

private enum class WizardStep { PROFILE, BLOCKED, INFO, STUDY, CONTROLS, LECTURE, OFF_METHOD }

/**
 * The pop-up walkthrough shown EVERY time Focus Mode or a Pomodoro is about to start:
 *  1. no Focus Profile yet -> offer to create one (only shown when none exists),
 *  2. what will stay blocked / limited (apps, games, websites, limits),
 *  3. other things worth knowing (how long it runs),
 *  4. the Study Check-In interval,
 *  5. the "Allow ..." switches, so nothing is switched on or off behind the person's back,
 *  6. how Focus Mode may be turned OFF (Normal / Password / Online). A method that is not set up yet cannot be
 *     chosen, so a session can never be started with an unusable way out.
 * Nothing starts until the last step's button is pressed.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StartWizard(
    title: String,
    hasProfile: Boolean,
    profileName: String?,
    preview: StartPreview,
    limits: List<AppLimit>,
    labelOf: (String) -> String?,
    shortsBlocked: Boolean,
    sectionCount: Int,
    infoLines: List<String>,
    offMethod: FocusOffMethod,
    /** Why a method cannot be used yet (null = it can be used). */
    offErrorFor: (FocusOffMethod) -> String?,
    /** Saves the chosen method; false when it could not be saved right now. */
    onSelectOffMethod: (FocusOffMethod) -> Boolean,
    /** Saves the Study Check-In interval in minutes (0 = off); false when it was refused (for example no notifications). */
    onSelectStudy: (Int) -> Boolean,
    state: FocusState,
    /** True for a session that has no end time (the first switch must then stay on). */
    noEndSession: Boolean,
    startLabel: String,
    /** Label of the last button when "turn OFF when the lecture ends" is on (no duration is asked then); null = same as [startLabel]. */
    startLabelWhenAutoEnd: String? = null,
    onControlChange: (FocusControl, Boolean) -> Unit,
    onCreateProfile: () -> Unit,
    onFinish: () -> Unit,
    onDismiss: () -> Unit,
    /** Called just before [onFinish] with the cleaned-up pasted lecture link (any platform), or null when the step was skipped / left empty. */
    onLectureChosen: (String?) -> Unit = {},
    /** Called right after [onLectureChosen]: true = turn Focus Mode off by itself when the lecture ends. Always false without a lecture link. */
    onAutoEndChosen: (Boolean) -> Unit = {},
    /** A link that arrived through the Share button: the lecture step comes FIRST with this link already filled in, the other steps follow. */
    initialLink: String? = null,
    /** Your animated character; it asks the lecture question. The default is a small placeholder. */
    character: @Composable () -> Unit = { DefaultWizardCharacter() },
) {
    val c = FocusTheme.colors
    val steps = remember(hasProfile, initialLink != null) {
        // The way to turn Focus Mode OFF is asked EVERY time, with or without a Focus Profile, and it is always the last
        // step: nothing starts before it has been chosen.
        val base = if (hasProfile) listOf(WizardStep.BLOCKED, WizardStep.INFO, WizardStep.CONTROLS, WizardStep.LECTURE, WizardStep.OFF_METHOD)
        else WizardStep.entries.toList()
        // From the Share button the link page comes first; the OFF method is still the last step.
        if (initialLink != null) listOf(WizardStep.LECTURE) + base.filter { it != WizardStep.LECTURE } else base
    }
    var linkText by remember { mutableStateOf(initialLink.orEmpty()) }
    var endAfterLecture by remember { mutableStateOf(false) }
    val lecture = LectureLink.parse(linkText)
    // Something was typed but it is not a usable video link: the step can't be passed until it is fixed or cleared.
    val lectureInvalid = linkText.isNotBlank() && lecture == null
    val clipboard = LocalClipboardManager.current
    var index by remember { mutableIntStateOf(0) }
    var note by remember { mutableStateOf<String?>(null) }
    var customStudy by remember { mutableIntStateOf(if (StudyCheckInRules.isCustom(state.studyMin)) state.studyMin else 20) }
    var customOpen by remember { mutableStateOf(false) }
    val offError = offErrorFor(offMethod)
    val step = steps[index.coerceIn(0, steps.lastIndex)]
    val last = index >= steps.lastIndex
    // Clear any message when the step changes.
    androidx.compose.runtime.LaunchedEffect(index) { note = null }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    steps.forEachIndexed { i, _ ->
                        Spacer(
                            Modifier
                                .size(if (i == index) 18.dp else 8.dp, 8.dp)
                                .clip(CircleShape)
                                .background(if (i <= index) c.accent else c.muted.copy(alpha = 0.35f))
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Step ${index + 1} of ${steps.size}", style = MaterialTheme.typography.labelSmall, color = c.muted)
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    when (step) {
                        WizardStep.PROFILE -> "Create your Focus Profile"
                        WizardStep.BLOCKED -> "What stays blocked"
                        WizardStep.INFO -> "Before you start"
                        WizardStep.STUDY -> "Study Check-In"
                        WizardStep.CONTROLS -> "What stays possible"
                        WizardStep.LECTURE -> "Watching a lecture?"
                        WizardStep.OFF_METHOD -> "How to turn it OFF"
                    },
                    style = MaterialTheme.typography.titleLarge
                )
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (step) {
                    WizardStep.PROFILE -> {
                        Text(
                            "You haven't created a Focus Profile yet. A profile saves which apps, games and websites " +
                                "to block and which limits to use, so $title knows exactly what to do.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            "Create one now, or continue and LockDistra will use your phone-wide blocking settings.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    WizardStep.BLOCKED -> {
                        Text(
                            (profileName?.let { "Profile: $it. " } ?: "") +
                                "While $title is on, these stay blocked. Apps with a limit can only be used within it.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (preview.isEmpty && limits.isEmpty() && !shortsBlocked && sectionCount == 0) {
                            Text("Nothing is selected to block yet. You can choose apps under Blocking.", style = MaterialTheme.typography.bodySmall)
                        }
                        if (preview.appTotal > 0) PreviewGroup("Applications", preview.apps, preview.appTotal)
                        if (preview.gameTotal > 0) PreviewGroup("Games", preview.games, preview.gameTotal)
                        if (preview.siteTotal > 0) {
                            Text("Websites (${preview.siteTotal})", style = MaterialTheme.typography.labelMedium, color = c.text)
                            val more = StartPreviewRules.more(preview.siteTotal, preview.sites.size)
                            Text(preview.sites.joinToString(", ") + (more?.let { "  $it" } ?: ""), style = MaterialTheme.typography.bodySmall)
                        }
                        if (limits.isNotEmpty()) {
                            Text("Daily limits (${limits.size})", style = MaterialTheme.typography.labelMedium, color = c.text)
                            limits.mapNotNull { l -> labelOf(l.pkg)?.let { it to l.limitMin } }.take(4).forEach { (name, min) ->
                                Text("$name: $min min a day", style = MaterialTheme.typography.bodySmall)
                            }
                            StartPreviewRules.more(limits.size, limits.size.coerceAtMost(4))?.let {
                                Text(it, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (shortsBlocked) Text("YouTube Shorts are blocked.", style = MaterialTheme.typography.bodySmall)
                        if (sectionCount > 0) Text("$sectionCount app section(s), like Reels or Status, are blocked.", style = MaterialTheme.typography.bodySmall)
                    }

                    WizardStep.INFO -> {
                        infoLines.forEach { Text(it, style = MaterialTheme.typography.bodyMedium, color = c.text) }
                        Text(
                            "Next you choose a Study Check-In, what stays possible, and how it can be turned OFF.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    WizardStep.STUDY -> {
                        Text(
                            "While it runs, LockDistra can ask \"Are You Still Studying?\" at this interval. You get 1 minute to tap \"I'm Studying\".",
                            style = MaterialTheme.typography.bodySmall
                        )
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            SoftChip("Off", state.studyMin == 0 && !customOpen, {
                                customOpen = false; note = if (!onSelectStudy(StudyCheckInRules.OFF)) "Couldn't change it right now." else null
                            })
                            StudyCheckInRules.PRESETS.forEach { m ->
                                SoftChip("Every $m minutes", state.studyMin == m && !customOpen, {
                                    customOpen = false; note = if (!onSelectStudy(m)) "Allow notifications first, then choose again." else null
                                })
                            }
                            SoftChip("Custom", customOpen || StudyCheckInRules.isCustom(state.studyMin), { customOpen = true })
                        }
                        if (customOpen || StudyCheckInRules.isCustom(state.studyMin)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SoftChip("-5", false, { customStudy = (customStudy - 5).coerceAtLeast(StudyCheckInRules.MIN_CUSTOM) })
                                SoftChip("-1", false, { customStudy = (customStudy - 1).coerceAtLeast(StudyCheckInRules.MIN_CUSTOM) })
                                Text("$customStudy min", style = MaterialTheme.typography.titleMedium, color = c.text)
                                SoftChip("+1", false, { customStudy = StudyCheckInRules.clamp(customStudy + 1) })
                                SoftChip("+5", false, { customStudy = StudyCheckInRules.clamp(customStudy + 5) })
                            }
                            SoftChip("Set $customStudy min", state.studyMin == customStudy, {
                                note = if (!onSelectStudy(customStudy)) "Allow notifications first, then choose again." else null
                            })
                        }
                        Text(
                            if (state.studyMin == 0) "No check-ins." else "Every ${state.studyMin} minutes while it runs.",
                            style = MaterialTheme.typography.bodySmall, color = c.text
                        )
                    }

                    WizardStep.CONTROLS -> {
                        Text(
                            "Check every switch. A switch you turn off stays off until the session ends.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        FocusControlSwitches(state = state, noEndSession = noEndSession, onChange = onControlChange)
                    }

                    WizardStep.LECTURE -> {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            character()
                            Text(
                                if (initialLink != null) "Your shared link is ready. Press Next for the remaining steps; then Focus Mode starts and the lecture opens by itself."
                                else "Distracted by other videos? Paste your lecture link from any platform (YouTube, Facebook, " +
                                    "Instagram, a website ...). It opens by itself and only that video will play.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = c.text
                            )
                        }
                        OutlinedTextField(
                            value = linkText,
                            onValueChange = { linkText = it },
                            singleLine = true,
                            isError = lectureInvalid,
                            placeholder = { Text("Paste any video link") },
                            trailingIcon = {
                                TextButton(onClick = { clipboard.getText()?.text?.let { linkText = it } }) {
                                    Text("Paste", color = c.accent)
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = c.text,
                                unfocusedTextColor = c.text,
                                cursorColor = c.accent,
                                focusedBorderColor = c.accent,
                                unfocusedBorderColor = c.muted.copy(alpha = 0.5f),
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            when {
                                lectureInvalid -> "This isn't a video link. For YouTube, paste the link of one video."
                                lecture != null -> "Done. It opens when Focus Mode starts. Other videos on " +
                                    (if (lecture.platform == com.focusmode.app.data.LecturePlatform.WEB) lecture.host else lecture.platform.label) +
                                    " stay closed meanwhile."
                                else -> "Optional. Only the platform of this link is affected, nothing else on your phone."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (lectureInvalid) c.warning else c.muted
                        )
                    }

                    WizardStep.OFF_METHOD -> {
                        Text("Choose how Focus Mode can be turned OFF.", style = MaterialTheme.typography.bodyMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            FocusOffMethod.entries.forEach { m ->
                                SoftChip(m.label, offMethod == m, {
                                    note = null
                                    if (m != offMethod) {
                                        // Password needs the App lock set up, Online needs the trusted phone: check BEFORE choosing.
                                        val error = offErrorFor(m)
                                        if (error != null) note = error
                                        else if (!onSelectOffMethod(m)) note = "Couldn't change it right now."
                                    }
                                })
                            }
                        }
                        Text(
                            when (offMethod) {
                                FocusOffMethod.NORMAL -> "Focus Mode turns OFF with the normal End button."
                                FocusOffMethod.PASSWORD -> "Focus Mode turns OFF only after you enter your PIN / password (App lock)."
                                FocusOffMethod.ONLINE -> "Focus Mode turns OFF only after your trusted phone approves the request."
                            },
                            style = MaterialTheme.typography.bodySmall
                        )
                        // "Set it up" only for a real setup error; "Couldn't change it" is a different problem.
                        note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
                            ?: offError?.let { Text("$it Set it up in Settings, then choose it here.", style = MaterialTheme.typography.bodySmall, color = c.warning) }

                        // Only when a lecture link was entered: Focus Mode can end by itself when the lecture finishes.
                        if (lecture != null) {
                            Spacer(Modifier.height(4.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("After this lecture \uD83C\uDF93", style = MaterialTheme.typography.titleSmall, color = c.text)
                                    Text(
                                        if (endAfterLecture) "Focus Mode turns OFF by itself the moment the lecture ends \u2705"
                                        else "Focus Mode keeps running after the lecture, until you turn it off.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = c.muted
                                    )
                                }
                                androidx.compose.material3.Switch(checked = endAfterLecture, onCheckedChange = { endAfterLecture = it })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            val blocked = step == WizardStep.LECTURE && lectureInvalid
            when {
                step == WizardStep.PROFILE -> TextButton(onClick = onCreateProfile) {
                    Text("Create Focus Profile", color = c.accent)
                }
                last -> TextButton(enabled = offError == null && !blocked, onClick = { onLectureChosen(lecture?.url); onAutoEndChosen(lecture != null && endAfterLecture); onFinish() }) {
                    Text(
                        if (lecture != null && endAfterLecture && startLabelWhenAutoEnd != null) startLabelWhenAutoEnd else startLabel,
                        color = if (offError == null && !blocked) c.accent else c.muted
                    )
                }
                else -> TextButton(enabled = !blocked, onClick = { index++ }) {
                    Text("Next", color = if (blocked) c.muted else c.accent)
                }
            }
        },
        dismissButton = {
            Row {
                if (index > 0) TextButton(onClick = { index-- }) { Text("Back", color = c.muted) }
                if (step == WizardStep.LECTURE) {
                    // Skip = no lecture link: nothing is restricted. On the last step it also starts, so the start button's rule applies.
                    TextButton(enabled = !last || offError == null, onClick = {
                        linkText = ""
                        if (last) { onLectureChosen(null); onAutoEndChosen(false); onFinish() } else index++
                    }) { Text("Skip", color = c.muted) }
                }
                if (step == WizardStep.PROFILE) TextButton(onClick = { index++ }) { Text("Continue without", color = c.muted) }
                else if (index == 0) TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) }
            }
        }
    )
}

/** Placeholder for the animated character: pass your own through StartWizard(character = { ... }). */
@Composable
private fun DefaultWizardCharacter() {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(FocusTheme.colors.accentSoft),
        contentAlignment = Alignment.Center
    ) { Text("🌱", style = MaterialTheme.typography.titleLarge) }
}
