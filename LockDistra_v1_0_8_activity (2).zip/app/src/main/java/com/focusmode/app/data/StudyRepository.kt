package com.focusmode.app.data

/** What the Study home shows: normal videos and Shorts, both already filtered to study content. */
data class StudyFeed(val videos: List<StudyVideo>, val shorts: List<StudyVideo>)

/** One more screenful for the endless Home scroll: new videos / Shorts, and whether there may be still more after them. */
data class StudyMore(val feed: StudyFeed, val hasMore: Boolean)

/**
 * Builds the Study feed and search results: asks YouTube, applies [StudyRules.accept], keeps results for a while.
 * Blocking calls; run them off the main thread.
 */
class StudyRepository(private val store: StudyStore, private val api: StudyApi = StudyApi(store)) {

    /**
     * Part 3/4: every request that more than one source can serve goes through this one switcher (API > Direct YouTube > Web;
     * see [StudySwitch]). The repository only says HOW each source does the job; WHICH source runs, what happens on a failure,
     * cool-downs and duplicate requests are decided there.
     */
    private val switcher = StudySwitch.switcher
    private val facts: SourceFacts = StoreFacts(store)

    /** Followed channels: fully trusted. */
    private fun followed(): Set<String> = store.channels.map { it.id }.toSet()

    /** Channels the person plays most: not held to the category check, but distracting videos are still left out. */
    private fun watched(): Set<String> = store.topWatched(WATCHED_TRUSTED).map { it.id }.toSet()

    /** Channels whose newest uploads fill the feed: followed first, then the most played ones. */
    private fun feedChannels(): List<StudyChannel> = (store.channels + store.topWatched(WATCHED_IN_FEED)).distinctBy { it.id }

    private fun keep(list: List<StudyVideo>): List<StudyVideo> {
        val f = followed()
        val w = watched()
        return list.filter { if (it.isShort) StudyRules.acceptShort(it, f, w) else StudyRules.accept(it, f, w) }
    }

    /**
     * Asks YouTube once for the picture and country of [ids] and remembers both ("" = the channel has none). An id that is
     * already being asked for by another call is skipped, so the home feed, a search and the logo loader never send the same
     * request twice. A picture that is already known is never replaced by an empty one. May throw [StudyException].
     */
    private fun learnChannels(ids: Collection<String>) {
        // Pictures are an extra: never worth a request to an API that is cooling down after a failure.
        if (!switcher.isUsable(StudyMode.API, facts)) return
        val mine =synchronized(learning) { ids.filter { it.isNotEmpty() }.distinct().filter { learning.add(it) } }
        if (mine.isEmpty()) return
        try {
            val known = store.avatars()
            val byId = api.channelInfos(mine).associateBy { it.id }
            store.saveCountries(mine.associateWith { byId[it]?.country.orEmpty() })
            store.saveAvatars(mine.associateWith { byId[it]?.avatarUrl.orEmpty().ifEmpty { known[it].orEmpty() } })
        } finally {
            synchronized(learning) { learning.removeAll(mine.toSet()) }
        }
    }

    /**
     * Channels of other countries come after the Indian ones ([dropForeign]: they are left out). The country of a channel is asked
     * once (1 unit per 50 channels) and remembered. If the lookup fails the list is returned as it was.
     */
    private fun indiaFirst(list: List<StudyVideo>, dropForeign: Boolean, lookup: Boolean = true): List<StudyVideo> {
        val known = store.countries()
        val missing = list.map { it.channelId }.filter { it.isNotEmpty() && it !in known }.distinct()
        if (missing.isNotEmpty() && !lookup) {
            // A search must not wait for this extra request: the order uses what is already known, the rest is learned in the background.
            POOL.execute { runCatching { learnChannels(missing) } }
        } else if (missing.isNotEmpty()) {
            try {
                learnChannels(missing)
            } catch (e: StudyException) {
                // no country information right now: keep the order
            }
        }
        return StudyRules.indiaFirst(list, store.countries(), followed() + watched(), dropForeign)
    }

    private fun subjectsInUse(): List<String> = store.selected.ifEmpty { store.subjects }

    /** Home: newest uploads of trusted channels (cheap) plus a few subject searches (rotating). */
    /**
     * [quiet] = a background refresh of the saved pool for the NEXT app launch: the mix the person already sees is not replaced.
     */
    fun feed(force: Boolean, quiet: Boolean = false, manual: Boolean = false): StudyFeed {
        StudyMonitor.sync(store.apiAvailable)
        val subjects = subjectsInUse()
        val key = feedKey(subjects)
        if (!force) store.cached(key, FEED_MAX_AGE)?.let { return session(key) ?: split(it) }
        // Every source failed / is cooling down: the last saved feed (any age) stays on screen instead of an error screen.
        fun stale(): StudyFeed? = store.cached(key, Long.MAX_VALUE)?.takeIf { it.isNotEmpty() }?.let { split(it) }
        return try {
            switcher.run(
                StudyOp.FEED, "$key|$force|$quiet", facts, manual,
                mapOf(
                    StudyMode.API to { apiFeed(subjects, key, force, quiet) },
                    // Direct YouTube: fresh videos from the page-data search instead of an old saved list.
                    StudyMode.PAGE to { webFeed(subjects, key, force, quiet) },
                ),
            )
        } catch (e: StudyException) {
            stale() ?: throw e
        }
    }

    /** Home feed from the YouTube Data API. Throws when it brings nothing (the switcher then asks the next source). */
    private fun apiFeed(subjects: List<String>, key: String, force: Boolean, quiet: Boolean): StudyFeed {
        val ids = LinkedHashSet<String>()
        var failure: StudyException? = null
        fun attempt(block: () -> Unit) {
            try { block() } catch (e: StudyException) { if (failure == null) failure = e }
        }
        // A pull-to-refresh must bring something new: it picks another pair of subjects each time (the cache time slot is kept otherwise).
        val slot = if (force) System.currentTimeMillis() / 1000 else System.currentTimeMillis() / FEED_MAX_AGE
        // All the requests (channel uploads + subject searches) go out AT THE SAME TIME instead of one after the other
        // (before: about 10 requests in a row, so the first screen waited for the sum of all of them).
        val jobs = ArrayList<() -> List<String>>()
        feedChannels().take(MAX_CHANNELS).forEach { ch -> jobs += { api.uploadIds(ch.id) } }
        StudyRules.pickSubjects(subjects, SUBJECTS_PER_REFRESH, slot).forEach { s ->
            jobs += { api.searchIds(s, shorts = false).first }
            jobs += { api.searchIds(s, shorts = true).first }
        }
        // One knowledge Shorts search per refresh (GK, current affairs, science facts, history...), rotating.
        jobs += { api.searchIds(StudyRules.KNOWLEDGE_QUERIES[(slot % StudyRules.KNOWLEDGE_QUERIES.size).toInt()], shorts = true).first }
        for (r in parallel(jobs)) {
            val list = r.getOrNull()
            if (list != null) ids.addAll(list)
            else { val e = r.exceptionOrNull(); if (e is StudyException) attempt { throw e } }
        }
        if (force) resetMore()
        if (ids.isEmpty()) throw (failure ?: StudyException(StudyErrorKind.OTHER, "No study videos found right now."))
        // The home feed shows Indian channels only (other countries are left out); a search keeps them, but last.
        val detailed = api.details(ids.toList())
        val kept = indiaFirst(keep(detailed), dropForeign = true)
        if (kept.isNotEmpty()) { savePool(key, kept); if (!quiet) sessionMix = null }
        return split(kept)
    }

    private fun feedKey(subjects: List<String>): String =
        "feed5:" + subjects.sorted().joinToString(",") + "|" + feedChannels().joinToString(",") { it.id }

    /** The cached home feed (any age), for an instant first screen, or null. */
    fun cachedFeed(): StudyFeed? {
        val subjects = subjectsInUse()
        val key = feedKey(subjects)
        return session(key) ?: store.cached(key, Long.MAX_VALUE)?.let { split(it) }
    }

    // ---- a different mix on every app launch ---------------------------------------------------------------------

    /** The mix chosen for this app launch, if the pool it was made from is still the current one. */
    private fun session(key: String): StudyFeed? = sessionMix?.takeIf { it.first == key }?.second

    /**
     * Every video the Home feed fetched lately is kept in one pool (newest first, at most [POOL_MAX]), not only the last answer.
     */
    private fun savePool(key: String, fresh: List<StudyVideo>) {
        val old = store.cached(key, Long.MAX_VALUE).orEmpty()
        // The same video from two sources (API + page data) stays ONE entry and keeps the richer details of both.
        store.saveCache(key, StudyMerge.merge(fresh, old).take(POOL_MAX))
    }

    /**
     * First screen of a new app launch: a fresh random pick from the saved pool, so Study does not open on the same list every
     * time. The pick is remembered for the rest of this launch, so leaving Study and coming back inside the app shows the same
     * list (until a pull-down refresh). Null when nothing is saved yet (the normal load then runs). Instant: no network.
     */
    fun launchFeed(): StudyFeed? {
        val key = feedKey(subjectsInUse())
        session(key)?.let { return it }
        val pool = store.cached(key, Long.MAX_VALUE)?.takeIf { it.isNotEmpty() } ?: return null
        val mix = split(pool.shuffled().take(SESSION_SIZE))
        sessionMix = key to mix
        return mix
    }

    /** True when the saved pool is older than half an hour, so a quiet refresh ([feed] with quiet = true) is worth its cost. */
    fun needsQuietRefresh(): Boolean = store.cached(feedKey(subjectsInUse()), QUIET_REFRESH_AGE) == null

    /** Suggestions for the text typed so far (blocking; run off the main thread). */
    fun suggest(text: String): List<String> = api.suggest(text)

    /** Suggestions already fetched for exactly this text (memory only), or null. Instant. */
    fun cachedSuggest(text: String): List<String>? = api.cachedSuggest(text)

    private val channelHitsCache = java.util.Collections.synchronizedMap(HashMap<String, Pair<Long, List<NativeChannel>>>())

    /**
     * EDUCATIONAL channels whose NAME matches what was typed, so a creator's channel can be found by name (the video search
     * alone only shows videos). Candidates come from YouTube's search page (no API limit); adult / distraction names are
     * dropped and each channel's own videos are checked ([isEducationalChannel]). Blocking; never throws: an empty list on
     * any failure. Kept for an hour.
     */
    fun searchChannels(query: String): List<NativeChannel> {
        val q = query.trim()
        if (q.length < 2) return emptyList()
        val key = q.lowercase()
        channelHitsCache[key]?.let { (at, list) -> if (System.currentTimeMillis() - at < SEARCH_MAX_AGE) return list }
        val candidates = try {
            StudyNative.searchChannels(q).filter { StudyBlocklist.blockedSearch(it.name) == null }.take(6)
        } catch (e: Exception) {
            return emptyList()
        }
        // Only EDUCATIONAL channels are listed: each candidate's own recent videos are checked (all candidates at the same time).
        val verdicts = parallel(candidates.map { c -> { isEducationalChannel(c) } })
        val list = candidates.filterIndexed { i, _ -> verdicts[i].getOrDefault(false) }.take(5)
        if (list.isNotEmpty()) channelHitsCache[key] = System.currentTimeMillis() to list
        return list
    }

    /**
     * Is this channel an educational one? A followed (or most played) channel is trusted already. Otherwise its newest uploads
     * are looked at: with the API, at least half of them (and at least 2) must pass the normal Study rules (Education category,
     * no adult / distraction words; Shorts use the wider Shorts categories). Without the API the page-data search of the
     * channel's name is used: at least 2 of its own videos must pass the Study text rules. Anything unverifiable is NOT shown.
     */
    private fun isEducationalChannel(ch: NativeChannel): Boolean {
        if (ch.id in followed() || ch.id in watched()) return true
        if (switcher.isUsable(StudyMode.API, facts)) {
            try {
                val ids = api.uploadIds(ch.id, 10)
                if (ids.isEmpty()) return false
                val vids = api.details(ids)
                if (vids.isEmpty()) return false
                val none = emptySet<String>()
                val good = vids.count { if (it.isShort) StudyRules.acceptShort(it, none) else StudyRules.accept(it, none) }
                return good >= 2 && good * 2 >= vids.size
            } catch (e: StudyException) {
                // the API cannot answer right now: the page-data check below decides
            }
        }
        return try {
            nativeSearch(ch.name).count { it.channelId == ch.id } >= 2
        } catch (e: Exception) {
            false
        }
    }

    fun search(query: String, shorts: Boolean, pageToken: String? = null, manual: Boolean = false): StudyPage {
        val q = query.trim()
        if (q.isEmpty()) return StudyPage(emptyList(), null)
        StudyMonitor.sync(store.apiAvailable)
        // The first page of a search is kept for an hour: a repeated tap on a subject costs nothing.
        val key = "q4:" + (if (shorts) "s:" else "v:") + q.lowercase() + "|" + store.channels.joinToString(",") { it.id }
        // The cached first page also remembers where the next page starts, so endless scrolling still works on a repeated search.
        if (pageToken == null) store.cached(key, SEARCH_MAX_AGE)?.let { return StudyPage(it, searchNext[key]) }
        // A next page (token) and Shorts exist only in the API: no other source can continue them. The screen keeps the list it has.
        if (shorts || pageToken != null) {
            return switcher.run(StudyOp.SEARCH_MORE, "$key|$pageToken", facts, manual, mapOf(StudyMode.API to { apiSearch(q, shorts, pageToken, key) }))
        }
        // First page: API, then Direct YouTube (page data: no daily limit, no WebView), then the web search (opened by the screen
        // when the switcher throws WebHandoff). A source that failed lately is skipped at once, never waited for.
        return switcher.run(
            StudyOp.SEARCH, key, facts, manual,
            mapOf(
                StudyMode.API to { apiSearch(q, false, null, key) },
                StudyMode.PAGE to { StudyPage(nativeSearch(q), null) },
            ),
        )
    }

    private fun apiSearch(q: String, shorts: Boolean, pageToken: String?, key: String): StudyPage {
        var token = pageToken
        var kept: List<StudyVideo> = emptyList()
        var next: String? = null
        // YouTube's own page can come back with nothing the study rules accept: look at the following page (at most 3 in all) instead of an empty screen.
        for (attempt in 0 until 3) {
            val (ids, n) = api.searchIds(q, shorts, token)
            next = n
            if (ids.isNotEmpty()) {
                // dropForeign = false and no country wait: the results show as soon as the details arrive.
                kept = if (shorts) indiaFirst(keep(api.details(ids)).filter { it.isShort }, dropForeign = true, lookup = true)
                else indiaFirst(keep(api.details(ids)).filter { !it.isShort }, dropForeign = false, lookup = false)
            }
            if (kept.isNotEmpty() || n == null) break
            token = n
        }
        if (pageToken == null && kept.isNotEmpty()) { store.saveCache(key, kept); searchNext[key] = next }
        return StudyPage(kept, next)
    }

    // ---- search without the API (page data; no daily limit, no WebView) ----------------------------------------

    /**
     * Study search read from YouTube's own search page data ([StudyNative]); every result still has to pass the Study text
     * rules ([StudyWeb.judge]). Two searches go out at the same time (the typed words, and the same with "full chapter") so
     * enough lessons survive the filter. Kept for an hour. Throws [StudyException]: NETWORK when YouTube could not be reached,
     * QUOTA when its page could not be read at all (the screen then falls back to the WebView search).
     */
    private fun nativeSearch(query: String): List<StudyVideo> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val key = "n2:" + q.lowercase() + "|" + store.channels.joinToString(",") { it.id }
        store.cached(key, SEARCH_MAX_AGE)?.let { return it }
        val variants = listOf(q, "$q full chapter").distinct()
        val results = parallel(variants.map { v -> { StudyNative.search(v) } })
        val all = LinkedHashMap<String, NativeResult>()
        var unreadable = false
        var failed = false
        var firstError: Throwable? = null
        for (r in results) {
            val list = r.getOrNull()
            if (list != null) list.forEach { all.putIfAbsent(it.id, it) }
            else { failed = true; if (firstError == null) firstError = r.exceptionOrNull(); if (r.exceptionOrNull() is NoDataException) unreadable = true }
        }
        if (all.isNotEmpty() || !failed) StudyMonitor.report(StudyMode.PAGE)
        // Direct YouTube's own outcome (one of the two searches answering is enough to call it working).
        if (all.isNotEmpty() || !failed) StudySources.tracker.success(StudyMode.PAGE)
        else StudySources.tracker.failure(StudyMode.PAGE, SourceClassifier.fromPage(firstError))
        if (all.isEmpty()) {
            // The page came, but held nothing readable: that is NOT a used-up limit (it used to be reported as one).
            if (unreadable) throw StudyException(StudyErrorKind.BAD_ANSWER, "YouTube's search page could not be read.", source = StudyMode.PAGE)
            if (failed) throw StudyException(StudyErrorKind.NETWORK, "No internet, or YouTube could not be reached.", source = StudyMode.PAGE)
            return emptyList()
        }
        val trusted = followed()
        val names = (store.channels + store.topWatched(WATCHED_TRUSTED)).map { it.name }.filter { it.isNotBlank() }
        val verdict = StudyWeb.judge(
            all.values.map { it.card }, emptyMap(), false, trusted, watched(), names, StudyWeb.isStudyQuery(q, store.subjects), q,
        )
        val ok = verdict.allowed.toSet()
        // The channel pictures the page showed are kept, so logos appear even while the API cannot be asked for them.
        val pictures = all.values.filter { it.channelId.isNotEmpty() && it.avatarUrl.isNotEmpty() && it.id in ok }
            .associate { it.channelId to it.avatarUrl }
        if (pictures.isNotEmpty()) {
            val have = store.avatars()
            val fresh = pictures.filter { (id, _) -> have[id].isNullOrEmpty() }
            if (fresh.isNotEmpty()) store.saveAvatars(fresh)
        }
        val videos = all.values
            .filter { it.durationLabel.isNotBlank() } // no length = a live stream: not for Study
            .filter { it.id in ok || (it.channelId in trusted && !StudyRules.hasNeverWord(it.title)) }
            .map {
                StudyVideo(
                    id = it.id, title = it.title, channelId = it.channelId, channelTitle = it.channelTitle,
                    thumbUrl = StudyRules.fallbackThumb(it.id), seconds = StudyWeb.parseDurationLabel(it.durationLabel),
                    categoryId = "", embeddable = true, publishedAt = it.publishedAt,
                )
            }
            .filter { !it.isShort }
        if (videos.isNotEmpty()) store.saveCache(key, videos)
        return videos
    }

    /** Home feed without the API: a few subjects searched at the same time, mixed channel by channel. */
    private fun webFeed(subjects: List<String>, key: String, force: Boolean, quiet: Boolean = false): StudyFeed {
        val slot = if (force) System.currentTimeMillis() / 1000 else System.currentTimeMillis() / FEED_MAX_AGE
        val picks = StudyRules.pickSubjects(subjects.ifEmpty { listOf("Maths", "Science") }, 3, slot)
        val results = parallel(picks.map { s -> { nativeSearch(s) } })
        val all = ArrayList<StudyVideo>()
        var failure: StudyException? = null
        for (r in results) {
            val list = r.getOrNull()
            if (list != null) all += list
            else { val e = r.exceptionOrNull(); if (e is StudyException && failure == null) failure = e }
        }
        val unique = all.distinctBy { it.id }
        if (force) resetMore()
        // Nothing: throw, so the switcher moves on; the saved copy is shown by [feed] only when every source failed.
        if (unique.isEmpty()) throw (failure ?: StudyException(StudyErrorKind.OTHER, "No study videos found right now."))
        savePool(key, unique)
        if (!quiet) sessionMix = null
        return split(unique)
    }

    private var nativeMoreIdx = 0

    /** Endless Home scroll without the API: the next subject / lesson-type searches (each different from the last). */
    private fun nativeMore(seen: Set<String>): StudyMore {
        val subjects = subjectsInUse().ifEmpty { listOf("Maths", "Science") }
        val total = subjects.size * MORE_SUFFIXES.size
        val shown = HashSet(seen)
        val collected = ArrayList<StudyVideo>()
        var failure: StudyException? = null
        var tries = 0
        while (collected.size < MIN_MORE && tries < 3) {
            val idx = synchronized(moreTokens) { nativeMoreIdx++ }
            if (idx >= total) break
            tries++
            val s = subjects[idx % subjects.size]
            val suffix = MORE_SUFFIXES[(idx / subjects.size) % MORE_SUFFIXES.size]
            try {
                nativeSearch("$s $suffix").forEach { if (shown.add(it.id)) collected += it }
            } catch (e: StudyException) {
                if (failure == null) failure = e
            }
        }
        val f = failure
        if (collected.isEmpty() && f != null) throw f
        val more = synchronized(moreTokens) { nativeMoreIdx < total }
        return StudyMore(split(collected), more)
    }

    private fun split(list: List<StudyVideo>): StudyFeed {
        val seen = HashSet<String>()
        val unique = list.filter { seen.add(it.id) }
        // Different channels one after the other (never a run of the same channel), like YouTube's home.
        return StudyFeed(StudyRules.diversify(unique.filter { !it.isShort }), StudyRules.diversify(unique.filter { it.isShort }))
    }

    /** Fetches the round pictures of channels not known yet and remembers them ("" = the channel has none). */
    fun loadAvatars(channelIds: Collection<String>) {
        val known = store.avatars()
        val missing = channelIds.filter { it.isNotEmpty() && it !in known }.distinct().take(50)
        if (missing.isEmpty()) return
        learnChannels(missing)
    }

    /**
     * A channel's details for its page (picture, handle, counts, description). When the API cannot answer, what the phone saved
     * (name, picture) is returned instead, so the channel page still opens with the right name and logo. Never throws.
     */
    fun channelInfo(channelId: String): StudyChannelInfo? {
        if (channelId.isEmpty()) return null
        return try {
            switcher.run(
                StudyOp.CHANNEL_INFO, "info|$channelId", facts, false,
                mapOf(
                    StudyMode.API to {
                        val info = api.channelInfos(listOf(channelId)).firstOrNull()
                        if (info != null && info.avatarUrl.isNotEmpty()) store.saveAvatars(mapOf(info.id to info.avatarUrl))
                        info
                    },
                ),
            )
        } catch (e: StudyException) {
            savedChannelInfo(channelId)
        }
    }

    /** The channel as the phone remembers it (null when its name is not known: the screen then keeps the name it was opened with). */
    private fun savedChannelInfo(channelId: String): StudyChannelInfo? {
        val name = savedChannelName(channelId)
        if (name.isBlank()) return null
        return StudyChannelInfo(channelId, name, "", store.avatars()[channelId].orEmpty(), null, null)
    }

    private fun savedChannelName(channelId: String): String =
        (store.channels + store.topWatched(WATCHED_TRUSTED)).firstOrNull { it.id == channelId }?.name.orEmpty()

    /**
     * A page of one channel's own videos and Shorts (the channel is trusted here, so its category does not matter). The first page
     * may come from Direct YouTube when the API cannot answer: only videos whose channel id IS this channel are kept, so a video of
     * another channel is never shown on this channel's page. Next pages (tokens) are API only.
     */
    fun channelPage(channelId: String, pageToken: String?, manual: Boolean = false): StudyPage {
        if (channelId.isEmpty()) return StudyPage(emptyList(), null)
        // Opening the same channel again (back, then tap again) shows its first page at once instead of asking YouTube again.
        if (pageToken == null) channelFirstPage[channelId]?.let { (at, page) -> if (System.currentTimeMillis() - at <= CHANNEL_PAGE_AGE) return page }
        val fromApi = {
            val (ids, next) = api.uploadPage(channelId, 30, pageToken)
            if (ids.isEmpty()) StudyPage(emptyList(), null) else {
                val trusted = setOf(channelId)
                val page = StudyPage(api.details(ids).filter { StudyRules.accept(it, trusted) }, next)
                // Only a page the API delivered is remembered: a partial page from another source must not hide the full one later.
                if (pageToken == null && page.videos.isNotEmpty()) channelFirstPage[channelId] = System.currentTimeMillis() to page
                page
            }
        }
        if (pageToken != null) return switcher.run(StudyOp.CHANNEL_MORE, "page|$channelId|$pageToken", facts, manual, mapOf(StudyMode.API to fromApi))
        return switcher.run(
            StudyOp.CHANNEL_PAGE, "page|$channelId", facts, manual,
            mapOf(
                StudyMode.API to fromApi,
                StudyMode.PAGE to { nativeChannelPage(channelId) },
            ),
        )
    }

    /** The channel's videos found by its saved name in the page-data search; only this channel's own videos count. */
    private fun nativeChannelPage(channelId: String): StudyPage {
        val name = savedChannelName(channelId)
        if (name.isBlank()) throw NotServed("This channel's videos need the YouTube API, which is not available right now.", StudyMode.PAGE)
        val mine = nativeSearch(name).filter { it.channelId == channelId }
        if (mine.isEmpty()) throw NotServed("This channel's videos could not be found right now.", StudyMode.PAGE)
        return StudyPage(mine, null)
    }

    // ---- endless Home scroll ---------------------------------------------------------------------------------

    // Where the next page of each source starts (memory only). A key with a null token = that source has no more pages.
    private val moreTokens = HashMap<String, String?>()
    private var moreKey = ""

    private fun resetMore() = synchronized(moreTokens) { moreTokens.clear(); nativeMoreIdx = 0 }

    /**
     * The next screenful for the Home scroll, so it never ends (like YouTube's home). Main source: the older uploads of the
     * followed / most played channels (1 unit per page, all channels asked at the same time). When there are no channels (or
     * they are used up) the subjects are searched page by page instead (100 units per page). [seen] = ids already on screen.
     * Blocking: run it off the main thread. Throws only when nothing at all could be loaded.
     */
    fun feedMore(seen: Set<String>, manual: Boolean = false): StudyMore {
        StudyMonitor.sync(store.apiAvailable)
        val subjects = subjectsInUse()
        val key = feedKey(subjects)
        synchronized(moreTokens) { if (key != moreKey) { moreTokens.clear(); nativeMoreIdx = 0; moreKey = key } }
        return switcher.run(
            StudyOp.FEED_MORE, key, facts, manual,
            mapOf(
                StudyMode.API to { apiMore(seen, subjects) },
                StudyMode.PAGE to { nativeMore(seen) },
            ),
        )
    }

    private fun apiMore(seen: Set<String>, subjects: List<String>): StudyMore {
        val shown = HashSet(seen)
        val collected = ArrayList<StudyVideo>()
        var failure: StudyException? = null
        var hasMore = true
        // A page can be filtered down to nothing by the study rules: try up to 3 pages before giving up for now.
        for (round in 0 until 3) {
            val ids = LinkedHashSet<String>()
            val jobs = ArrayList<Pair<String, () -> Pair<List<String>, String?>>>()
            for (ch in feedChannels().take(MAX_CHANNELS)) {
                val k = "c:" + ch.id
                val state = synchronized(moreTokens) { if (moreTokens.containsKey(k)) moreTokens[k] to true else null to false }
                if (state.second && state.first == null) continue // that channel has no more pages
                jobs += k to { api.uploadPage(ch.id, MORE_PER_CHANNEL, state.first) }
            }
            if (jobs.isEmpty()) {
                // No channel pages left: continue with the subject searches.
                for (s in subjects.take(SUBJECTS_PER_MORE)) {
                    val k = "s:" + s
                    val state = synchronized(moreTokens) { if (moreTokens.containsKey(k)) moreTokens[k] to true else null to false }
                    if (state.second && state.first == null) continue
                    jobs += k to { api.searchIds(s, shorts = false, pageToken = state.first) }
                }
            }
            if (jobs.isEmpty()) { hasMore = false; break }
            val results = parallel(jobs.map { j -> { j.second() } })
            for (i in results.indices) {
                val page = results[i].getOrNull()
                if (page != null) {
                    synchronized(moreTokens) { moreTokens[jobs[i].first] = page.second }
                    ids.addAll(page.first)
                } else {
                    val e = results[i].exceptionOrNull()
                    if (failure == null && e is StudyException) failure = e
                }
            }
            val fresh = ids.filter { it !in shown }
            if (fresh.isNotEmpty()) {
                val detailed = try { api.details(fresh) } catch (e: StudyException) { if (failure == null) failure = e; emptyList() }
                val kept = indiaFirst(keep(detailed), dropForeign = true)
                kept.forEach { if (shown.add(it.id)) collected += it }
            }
            if (collected.size >= MIN_MORE) break
        }
        val firstFailure = failure
        // Nothing came and a request failed: throw, the switcher asks the next source (page data) for the next screenful.
        if (collected.isEmpty() && firstFailure != null && hasMore) throw firstFailure
        val more = synchronized(moreTokens) {
            hasMore && (moreTokens.isEmpty() || moreTokens.values.any { it != null })
        }
        return StudyMore(split(collected), more)
    }

    /** Runs the jobs at the same time on a small thread pool and returns each outcome in the same order. */
    private fun <T> parallel(jobs: List<() -> T>): List<Result<T>> {
        val futures = jobs.map { job -> POOL.submit(java.util.concurrent.Callable<Result<T>> { runCatching(job) }) }
        return futures.map { f -> try { f.get() } catch (e: Exception) { Result.failure<T>(e) } }
    }

    // ---- web search (backup when the daily limit is used up) -------------------------------------------------

    /** What the API said about videos judged in web search (id -> video), so a tap plays it with its full details. */
    private val webDetails = object : LinkedHashMap<String, StudyVideo>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, StudyVideo>?): Boolean = size > WEB_CACHE
    }

    /**
     * Decides the result cards a web search page showed. With the API available the normal Study rules decide (1 unit per
     * 50 videos); when the limit is used up only the page's own words are known, so the looser text rules decide.
     * Blocking: run it off the main thread. Never throws.
     */
    fun judgeWeb(cards: List<WebCard>, queryIsStudy: Boolean, query: String = ""): WebVerdict {
        if (cards.isEmpty()) return WebVerdict(emptyList(), emptyList())
        var details: Map<String, StudyVideo> = emptyMap()
        var worked = false
        if (switcher.isUsable(StudyMode.API, facts)) {
            try {
                details = api.details(cards.map { it.id }).associateBy { it.id }
                worked = true
                synchronized(webDetails) { webDetails.putAll(details) }
            } catch (e: StudyException) {
                // limit used up / no internet: the text rules below decide
            }
        }
        val names = (store.channels + store.topWatched(WATCHED_TRUSTED)).map { it.name }.filter { it.isNotBlank() }
        return StudyWeb.judge(cards, details, worked, followed(), watched(), names, queryIsStudy, query)
    }

    /** The video to play after a tap in web search: the API's full details when known, otherwise what the page showed. */
    fun webVideo(id: String, title: String, durationLabel: String): StudyVideo =
        synchronized(webDetails) { webDetails[id] } ?: StudyWeb.minimalVideo(id, title, durationLabel)

    fun addChannel(raw: String): StudyChannel {
        val ref = StudyRules.parseChannelRef(raw)
            ?: throw StudyException(StudyErrorKind.OTHER, "Paste a channel link (youtube.com/@name) or a name like @name.")
        val ch = api.channel(ref)
        if (store.channels.none { it.id == ch.id }) store.channels = store.channels + ch
        return ch
    }

    companion object {
        /** Shared worker threads for requests that can run side by side (daemon: never keep the app alive). */
        private val POOL: java.util.concurrent.ExecutorService = java.util.concurrent.Executors.newFixedThreadPool(8) { r ->
            Thread(r, "study-net").apply { isDaemon = true }
        }
        /** Channel ids whose picture / country is being asked for right now (see [learnChannels]). */
        private val learning: MutableSet<String> = HashSet()
        private const val CHANNEL_PAGE_AGE = 10L * 60 * 1000
        /** The first page of the channels opened lately: channel id -> (time, page). Memory only. */
        private val channelFirstPage: MutableMap<String, Pair<Long, StudyPage>> = java.util.Collections.synchronizedMap(
            object : LinkedHashMap<String, Pair<Long, StudyPage>>(16, 0.75f, true) {
                override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Pair<Long, StudyPage>>?): Boolean = size > 20
            }
        )
        /** Search first page -> next page token (memory only, see [search]). */
        private val searchNext: MutableMap<String, String?> = java.util.Collections.synchronizedMap(HashMap<String, String?>())
        /** The mix chosen for this app launch (process-wide: the repository itself is created again on every Study open). */
        @Volatile private var sessionMix: Pair<String, StudyFeed>? = null
        private const val POOL_MAX = 150
        private const val SESSION_SIZE = 60
        private const val QUIET_REFRESH_AGE = 30L * 60 * 1000
        private val MORE_SUFFIXES = listOf("important questions", "one shot revision", "ncert solutions", "previous year questions", "concepts explained")
        private const val MORE_PER_CHANNEL = 15
        private const val SUBJECTS_PER_MORE = 1
        private const val MIN_MORE = 6
        private const val FEED_MAX_AGE = 6L * 60 * 60 * 1000
        private const val SEARCH_MAX_AGE = 60L * 60 * 1000
        private const val MAX_CHANNELS = 8
        private const val SUBJECTS_PER_REFRESH = 1
        private const val WATCHED_IN_FEED = 3
        private const val WATCHED_TRUSTED = 6
        private const val WEB_CACHE = 300
    }
}

/** The live facts of the phone's settings that decide whether a source may be used ([SourceSwitcher.check]). */
internal class StoreFacts(private val store: StudyStore) : SourceFacts {
    override fun enabled(mode: StudyMode): Boolean = store.isSourceEnabled(mode)

    override fun apiKeyCount(): Int = store.apiKeyList.size

    override fun apiRest(now: Long): ApiRest? {
        val keys = store.apiKeyList
        return SourceClassifier.fromResting(keys.map { store.restReason(it) }, keys.map { store.restUntil(it) }, now)
            ?.let { ApiRest(it.retryAtMs, it.reason) }
    }
}
