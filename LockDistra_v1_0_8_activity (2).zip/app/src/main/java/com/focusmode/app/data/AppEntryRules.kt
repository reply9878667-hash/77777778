package com.focusmode.app.data

/**
 * The top-level places the app can be in (Task 3). Everything else (Home's tabs, Settings, Profile ...) lives inside Home.
 * [Permissions] sits between the account / onboarding screens and Home: Home opens only once every required
 * permission is allowed.
 */
enum class EntryRoute { Onboarding, Auth, Permissions, Home }

/**
 * Which top-level screen is showing. Plain Kotlin (no Android types), so it is unit tested on the JVM.
 *
 * ```
 * New user         Welcome -> 7 questions -> Celebration -> Account (sign up) -> Home
 * Existing user    start -> saved login found -> Home
 * Logged-out user  start -> Account (log in) -> Home
 * ```
 * Home is never composed for a logged-out person, so "authenticated screens are closed after logout" is a property of
 * this one function and not something every screen has to remember.
 */
object AppEntryRules {

    /**
     * @param signedIn a login is saved (restored from the phone at start, so this is right on the first frame).
     * @param onboardingDone the seven questions were completed on this phone (`OnboardingStore.welcomeDone`).
     * @param authRequired accounts are mandatory AND set up in this build (`AuthConfig.authRequired`).
     * @param ownOnboardingRequired the logged-in account is brand new on a phone whose answers belong to somebody
     *   else, so it answers the questions itself (`OnboardingStore.requiredFor == uid`).
     * @param holdAuth the account screen is still showing its "Welcome" confirmation after a successful login. The
     *   person has to press Continue; Home does not jump in underneath.
     * @param wantsLogin "I already have an account" was chosen on the welcome screen.
     * @param permissionsGranted every required permission is allowed right now (`PermissionStatus.allRequiredGranted`).
     *   Checked on every start and every return to the app, so a permission switched off later closes Home again.
     */
    fun route(
        signedIn: Boolean,
        onboardingDone: Boolean,
        authRequired: Boolean,
        ownOnboardingRequired: Boolean,
        holdAuth: Boolean,
        wantsLogin: Boolean,
        permissionsGranted: Boolean = true,
    ): EntryRoute {
        if (signedIn) {
            return when {
                holdAuth -> EntryRoute.Auth
                ownOnboardingRequired -> EntryRoute.Onboarding
                !permissionsGranted -> EntryRoute.Permissions
                else -> EntryRoute.Home
            }
        }
        if (!onboardingDone) {
            return if (wantsLogin && authRequired) EntryRoute.Auth else EntryRoute.Onboarding
        }
        return when {
            authRequired -> EntryRoute.Auth
            !permissionsGranted -> EntryRoute.Permissions
            else -> EntryRoute.Home
        }
    }

    /**
     * The permission step is over when every required permission is allowed, or when the person pressed
     * "Skip for now" on the permission page. Passed to [route] as `permissionsGranted`.
     */
    fun permissionStepDone(allRequiredGranted: Boolean, skipped: Boolean): Boolean = allRequiredGranted || skipped

    /**
     * Which account screen opens first. A person who just finished the questions (answers waiting for an account)
     * is creating an account: Sign up. Everybody else (logged out, expired session, "I already have an account")
     * is logging in: Log in. An expired-session message always goes with Log in.
     */
    fun startOnLogin(hasUnclaimedAnswers: Boolean, wantsLogin: Boolean, hasNotice: Boolean): Boolean =
        hasNotice || wantsLogin || !hasUnclaimedAnswers

    /**
     * After the account screen: should a brand-new account answer the questions itself? Yes when it was created now
     * and the phone holds no answers for it (they were taken by an earlier account, or never given).
     * A login to an existing account never does: its answers are on the server or already handled.
     */
    fun newAccountNeedsOnboarding(isNewAccount: Boolean, answersForThisAccount: Boolean): Boolean =
        isNewAccount && !answersForThisAccount
}
