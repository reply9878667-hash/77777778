package com.focusmode.app.data.online

/**
 * Which ways open LockDistra's own screens. Kept free of Android classes so the rules can be
 * unit tested on a plain JVM (see OnlineUnlockTest.kt).
 *
 *  - PASSWORD : the existing PIN / password lock, exactly as before (the default).
 *  - ONLINE   : the trusted phone approves a request over the internet.
 *  - BOTH     : either one opens the app.
 */
enum class UnlockMode(val id: String) {
    PASSWORD("password"),
    ONLINE("online"),
    BOTH("both");

    val usesPassword: Boolean get() = this != ONLINE
    val usesOnline: Boolean get() = this != PASSWORD

    companion object {
        /** Unknown / missing value falls back to the old behaviour. */
        fun fromId(id: String?): UnlockMode = entries.firstOrNull { it.id == id } ?: PASSWORD
    }
}

/** What the lock screen offers right now. */
data class UnlockMethods(val password: Boolean, val online: Boolean) {
    val both: Boolean get() = password && online
}

object UnlockGateRules {

    /**
     * Whether the lock screen must stand in front of the app at all.
     *
     * Online approval fails CLOSED: with ONLINE or BOTH selected the gate stays up even when the
     * pairing data can't be read any more (lost Keystore key, cleared data ...). The person then
     * gets the offline recovery code instead of an open app.
     */
    fun gateActive(mode: UnlockMode, passwordLockSet: Boolean): Boolean =
        (mode.usesPassword && passwordLockSet) || mode.usesOnline

    /** The methods to show on the lock screen. */
    fun methods(mode: UnlockMode, passwordLockSet: Boolean): UnlockMethods =
        UnlockMethods(
            password = mode.usesPassword && passwordLockSet,
            online = mode.usesOnline,
        )

    /** An error text, or null when [mode] may be switched on. */
    fun canSelect(
        mode: UnlockMode,
        passwordLockSet: Boolean,
        phoneConnected: Boolean,
        hasRecoveryCode: Boolean,
    ): String? = when (mode) {
        UnlockMode.PASSWORD -> null
        UnlockMode.ONLINE ->
            if (!phoneConnected) "Connect a trusted phone first."
            else if (!hasRecoveryCode) "Connect the trusted phone again to get a recovery code."
            else null
        UnlockMode.BOTH ->
            if (!passwordLockSet) "Turn on the App lock (PIN or password) first."
            else if (!phoneConnected) "Connect a trusted phone first."
            else if (!hasRecoveryCode) "Connect the trusted phone again to get a recovery code."
            else null
    }

    /**
     * Mode after the password lock is turned off. ONLINE alone does not need a password, BOTH
     * has nothing left to be "both" with, so it becomes ONLINE; PASSWORD stays as it was.
     */
    fun modeAfterPasswordLockOff(mode: UnlockMode): UnlockMode =
        if (mode == UnlockMode.BOTH) UnlockMode.ONLINE else mode

    /** Mode after the trusted phone is disconnected: back to the password lock. */
    fun modeAfterUnlink(mode: UnlockMode): UnlockMode = UnlockMode.PASSWORD
}
