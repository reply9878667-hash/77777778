package com.focusmode.app.data.auth

import java.util.Locale

/**
 * Input rules for the account forms. Plain Kotlin (no Android classes), so they run in unit tests.
 * Each function returns the message to show, or null when the value is fine.
 */
object AuthValidation {

    private val EMAIL = Regex(
        "^[A-Za-z0-9._%+'-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?" +
            "(?:\\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\\.[A-Za-z]{2,}$"
    )
    private val SPACES = Regex("\\s+")

    /** Same cleaning as the trusted-phone display name: no control characters, no '|', single spaces. */
    fun cleanName(raw: String): String =
        raw.filter { !it.isISOControl() && it != '|' }.trim().replace(SPACES, " ").take(AuthConfig.MAX_NAME)

    fun cleanEmail(raw: String): String = raw.trim().lowercase(Locale.ROOT)

    fun nameError(raw: String): String? {
        val n = cleanName(raw)
        return when {
            n.isEmpty() -> "Type your name."
            n.length < AuthConfig.MIN_NAME || n.none { it.isLetter() } -> "Your name needs 2 or more letters."
            else -> null
        }
    }

    fun emailError(raw: String): String? {
        val e = cleanEmail(raw)
        return when {
            e.isEmpty() -> "Type your email address."
            e.length > AuthConfig.MAX_EMAIL || !EMAIL.matches(e) -> "That email address doesn't look right."
            else -> null
        }
    }

    /** Rule for a NEW password (sign up). Passwords are never trimmed or changed. */
    fun newPasswordError(password: String): String? = when {
        password.isEmpty() -> "Create a password."
        password.length < AuthConfig.MIN_PASSWORD -> "Use at least ${AuthConfig.MIN_PASSWORD} characters."
        password.length > AuthConfig.MAX_PASSWORD -> "Use ${AuthConfig.MAX_PASSWORD} characters or fewer."
        password.none { it.isLetter() } || password.none { it.isDigit() } -> "Mix letters and numbers."
        else -> null
    }

    fun confirmError(password: String, confirm: String): String? = when {
        confirm.isEmpty() -> "Type your password again."
        confirm != password -> "The passwords don't match."
        else -> null
    }

    /** Log in only checks that something was typed: older accounts may have a shorter password. */
    fun loginPasswordError(password: String): String? =
        if (password.isEmpty()) "Type your password." else null
}
