package com.focusmode.app

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.BedtimeRules
import com.focusmode.app.data.BedtimeStore
import com.focusmode.app.data.ContentStore
import com.focusmode.app.data.EmergencyApp
import com.focusmode.app.data.EmergencyStore
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.LimitEmergency
import com.focusmode.app.data.KeywordStore
import com.focusmode.app.data.ListCodec
import com.focusmode.app.data.ShortFormCatalog
import com.focusmode.app.data.UsageLimitStore
import com.focusmode.app.data.IntentGuard
import com.focusmode.app.data.WebsiteLimitStore
import com.focusmode.app.data.WebsiteStore
import com.focusmode.app.data.online.AppGrantStore
import com.focusmode.app.data.online.AppUnlockRules
import com.focusmode.app.data.online.AppUnlockUi
import com.focusmode.app.data.online.OnlineManager
import com.focusmode.app.service.FocusController
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.AuroraBackground
import com.focusmode.app.ui.components.BlockIllustration
import com.focusmode.app.ui.components.BlockPalette
import com.focusmode.app.ui.components.BlockTimeCard
import com.focusmode.app.ui.components.BlockTipCard
import com.focusmode.app.ui.components.BlockTitleBar
import com.focusmode.app.ui.components.BlockUsageCard
import com.focusmode.app.ui.components.blockBackground
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusProgressBar
import com.focusmode.app.ui.components.PlantView
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SecondaryButton
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.components.staggeredEntrance
import com.focusmode.app.ui.formatClock
import com.focusmode.app.ui.formatMinutes
import com.focusmode.app.ui.theme.FocusModeTheme
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay
import java.util.Calendar

/**
 * Animated full-screen cover shown on top of a blocked app. Back goes home, and Emergency access
 * can open this one app for 2, 3 or 4 minutes when it is switched on for the app, the session
 * allows it and attempts are left.
 */
class BlockActivity : ComponentActivity() {

    private var blockedPackage by mutableStateOf("")
    private var reason by mutableStateOf(REASON_APP)
    private var detail by mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The block screen is always shown upright, like a normal app, even when the blocked app is full screen / landscape
        // (a video, a game ...). The manifest sets it too; this covers devices that ignore the manifest value at launch.
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        enableEdgeToEdge()
        readIntent(intent)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })

        setContent {
            val store = remember { FocusStore.get(applicationContext) }
            val limitStore = remember { UsageLimitStore.get(applicationContext) }
            val emergencyStore = remember { EmergencyStore.get(applicationContext) }
            val contentStore = remember { ContentStore.get(applicationContext) }
            val contentState by contentStore.state.collectAsStateWithLifecycle()
            val websiteStore = remember { WebsiteStore.get(applicationContext) }
            val websiteState by websiteStore.state.collectAsStateWithLifecycle()
            val adultStore = remember { com.focusmode.app.data.AdultBlockStore.get(applicationContext) }
            val adultState by adultStore.state.collectAsStateWithLifecycle()
            val keywordStore = remember { KeywordStore.get(applicationContext) }
            val keywordState by keywordStore.state.collectAsStateWithLifecycle()
            val state by store.state.collectAsStateWithLifecycle()
            val emergencyState by emergencyStore.state.collectAsStateWithLifecycle()
            val online = remember { OnlineManager.get(applicationContext) }
            val onlineState by online.state.collectAsStateWithLifecycle()
            val appUnlockUi by online.appUnlockUi.collectAsStateWithLifecycle()

            FocusModeTheme(state.themeMode) {
                // An old answer (rejected, expired ...) from an earlier visit is not shown again.
                LaunchedEffect(Unit) { online.resetAppUnlock() }
                // The trusted phone gave time: closing this screen reveals the app underneath.
                LaunchedEffect(appUnlockUi, blockedPackage) {
                    val u = appUnlockUi
                    if (u is AppUnlockUi.Granted && u.pkg == blockedPackage &&
                        AppGrantStore.get(applicationContext).isActive(blockedPackage)
                    ) {
                        online.resetAppUnlock()
                        finish()
                    }
                }
                // If the session ended (timer ran out) while this screen was up, get out of the way.
                // (The protection screen is not tied to a session, so it stays until dismissed.)
                LaunchedEffect(state.focusActive, reason) {
                    if (!state.focusActive && (reason == REASON_APP || reason == REASON_SHORTS || reason == REASON_SETTINGS || reason == REASON_FEATURE)) finish()
                }
                // Bedtime screen: goes away when the window ends or the app / schedule is changed.
                val bedtimeStore = remember { BedtimeStore.get(applicationContext) }
                val bedtimeState by bedtimeStore.state.collectAsStateWithLifecycle()
                LaunchedEffect(reason, blockedPackage, bedtimeState) {
                    if (reason != REASON_BEDTIME) return@LaunchedEffect
                    while (true) {
                        if (!bedtimeStore.blocks(blockedPackage)) { finish(); return@LaunchedEffect }
                        delay(1_000)
                    }
                }
                // A limit screen goes away by itself once the limit is raised or removed.
                val limitsState by limitStore.state.collectAsStateWithLifecycle()
                val isCategory = reason == REASON_CATEGORY
                val limit = if (isCategory) limitsState.categoryLimits.firstOrNull { it.pkg == detail }
                else limitsState.limits.firstOrNull { it.pkg == blockedPackage }
                val used = if (isCategory) limitsState.categoryUsedMs[detail] ?: 0L
                else limitsState.usedMs[blockedPackage] ?: 0L
                LaunchedEffect(reason, limit, used) {
                    if ((reason == REASON_LIMIT || isCategory) && (limit == null || used < limit.limitMs)) finish()
                }
                // A website screen goes away once its rule is off / deleted, or nothing blocks it any more.
                LaunchedEffect(reason, detail, websiteState, state.focusActive, limitsState) {
                    if (reason != REASON_WEBSITE) return@LaunchedEffect
                    val pair = ListCodec.unpair(detail)
                    if (pair == null) { finish(); return@LaunchedEffect }
                    val (owner, domain) = pair
                    val ownerLimit = limitsState.limits.firstOrNull { it.pkg == owner }
                    val limitHit = ownerLimit != null && (limitsState.usedMs[owner] ?: 0L) >= ownerLimit.limitMs
                    if (!websiteState.isRuleActive(owner, domain) || (!state.focusActive && !limitHit)) finish()
                }
                // A website-limit screen goes away once that limit is raised, switched off or removed (it is read from the
                // store itself, so a change that was just saved is seen at once).
                val siteLimitStore = remember { WebsiteLimitStore.get(applicationContext) }
                val siteLimitState by siteLimitStore.state.collectAsStateWithLifecycle()
                LaunchedEffect(reason, detail, siteLimitState) {
                    if (reason == REASON_WEBSITE_LIMIT && !siteLimitStore.isReached(detail)) finish()
                }
                // Adult-site screen goes away if the protection is switched off.
                LaunchedEffect(reason, adultState.enabled) {
                    if (reason == REASON_ADULT && !adultState.enabled) finish()
                }
                // Keyword screen goes away once Keyword Blocking is off or that keyword is deleted / switched off.
                LaunchedEffect(reason, detail, keywordState) {
                    if (reason == REASON_KEYWORD &&
                        (!keywordState.enabled || keywordState.rules.none { it.enabled && it.word == detail })
                    ) finish()
                }
                // Emergency access for this limit (set in the limit editor). Key: package or content id.
                val limitKey = if (isCategory) detail else blockedPackage
                val limitEmergency = limitsState.emergency[limitKey] ?: limitStore.emergencyFor(limitKey)
                BlockScreen(
                    appName = labelFor(blockedPackage),
                    packageName = blockedPackage,
                    reason = reason,
                    detail = when {
                        isCategory -> ShortFormCatalog.byId(detail)?.title.orEmpty()
                        reason == REASON_WEBSITE -> ListCodec.unpair(detail)?.second.orEmpty()
                        else -> detail
                    },
                    shortsHaveExceptions = contentState.hasShortsExceptions,
                    sessionStart = state.sessionStart,
                    sessionEnd = state.sessionEnd,
                    limitMinutes = if (reason == REASON_WEBSITE_LIMIT) siteLimitState.limitFor(detail)?.limitMin ?: 0 else limit?.limitMin ?: 0,
                    // Today's real usage (read again whenever the stored usage changes).
                    usedMs = if (reason == REASON_WEBSITE_LIMIT) {
                        siteLimitStore.usedMs(siteLimitState.limitFor(detail)?.domain ?: detail)
                    } else used,
                    bedtimeEndMin = bedtimeState.endMin,
                    emergencyAllowed = state.allowEmergency,
                    emergencyApp = emergencyState.app(blockedPackage),
                    limitEmergency = limitEmergency,
                    onLimitEmergency = {
                        if (limitStore.startEmergency(limitKey)) {
                            // Closing this screen reveals the app underneath.
                            finish()
                        } else {
                            Toast.makeText(
                                applicationContext,
                                "No emergency attempts left for this limit today.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    canRequestUnlock = onlineState.phoneConnected && online.configured &&
                        AppUnlockRules.canRequest(reason),
                    trustedPhoneName = onlineState.approverName,
                    requestUi = appUnlockUi,
                    serverNow = online::serverNow,
                    onRequestUnlock = {
                        online.requestAppUnlock(blockedPackage, labelFor(blockedPackage), reason)
                    },
                    onCancelRequest = online::cancelAppUnlock,
                    onGoHome = ::goHome,
                    onContinue = ::continueInApp,
                    onOpenFocus = {
                        startActivity(
                            Intent(this@BlockActivity, MainActivity::class.java)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        )
                        finish()
                    },
                    onChangeLimit = {
                        val open = Intent(this@BlockActivity, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        if (reason == REASON_WEBSITE_LIMIT) {
                            // Website limits are in the Blocking screen, next to Website Blocking.
                            open.putExtra(MainActivity.EXTRA_OPEN_BLOCKING, true)
                                .putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(applicationContext))
                        } else {
                            open.putExtra(MainActivity.EXTRA_OPEN_LIMITS, true)
                        }
                        startActivity(open)
                        finish()
                    },
                    onEmergency = { minutes ->
                        if (FocusController.startEmergency(applicationContext, blockedPackage, minutes)) {
                            // Closing this screen reveals the app underneath.
                            finish()
                        } else {
                            Toast.makeText(
                                applicationContext,
                                "Emergency access isn't available for this app right now.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                )
            }
        }
    }

    /**
     * The cover belongs to the moment the blocked app was opened. Once the person leaves it (Home, Recents, another
     * app) it closes, so it can never wait in the background and come back later over a different app or the lecture.
     * A pending "Request to unlock" keeps it open: the answer of the trusted phone still has to land here.
     */
    override fun onStop() {
        super.onStop()
        if (isFinishing || isChangingConfigurations) return
        val ui = OnlineManager.get(applicationContext).appUnlockUi.value
        if (ui is AppUnlockUi.Sending || ui is AppUnlockUi.Waiting) return
        finish()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readIntent(intent)
    }

    private fun readIntent(intent: Intent?) {
        blockedPackage = intent?.getStringExtra(EXTRA_PACKAGE).orEmpty()
        reason = intent?.getIntExtra(EXTRA_REASON, REASON_APP) ?: REASON_APP
        detail = intent?.getStringExtra(EXTRA_DETAIL).orEmpty()
    }

    private fun labelFor(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) {
        "This app"
    }

    /**
     * "Continue to <app>": close this screen and stay in the app. The accessibility service gets the blocked
     * Short / section / link out of the way with Back, so only that is left behind (not the whole app).
     */
    private fun continueInApp() {
        com.focusmode.app.service.AppBlockerService.instance?.continueInApp(blockedPackage)
        finish()
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    companion object {
        const val EXTRA_PACKAGE = "package"
        const val EXTRA_REASON = "reason"
        /** Optional short text: the blocked section ("Reels in Instagram") or Shorts channel handle. */
        const val EXTRA_DETAIL = "detail"
        const val REASON_APP = 0
        const val REASON_SHORTS = 1
        const val REASON_PROTECTION = 2
        const val REASON_LIMIT = 3
        const val REASON_SETTINGS = 4
        /** A blocked section inside an otherwise allowed app (Reels, Search, ...). */
        const val REASON_FEATURE = 5
        /** Today's daily limit for Shorts / Reels / Status is used up. EXTRA_DETAIL holds its id. */
        const val REASON_CATEGORY = 6
        /** A blocked website in a browser. EXTRA_DETAIL holds the owning app and the domain (ListCodec pair). */
        const val REASON_WEBSITE = 7
        /** The app is closed by Bedtime Mode's daily schedule. */
        const val REASON_BEDTIME = 8
        /** An adult website matched the built-in blocklist. EXTRA_DETAIL holds the host. */
        const val REASON_ADULT = 9
        /** A page matched one of the person's own keywords. EXTRA_DETAIL holds the keyword. */
        const val REASON_KEYWORD = 10
        /** Today's daily limit for a website in a browser is used up. EXTRA_DETAIL holds the domain. */
        const val REASON_WEBSITE_LIMIT = 11

        /** Blocks of ONE part of an app (a Short, a section, a link): the rest of the app can still be used. */
        fun canContinue(reason: Int): Boolean = reason == REASON_SHORTS || reason == REASON_FEATURE ||
            reason == REASON_CATEGORY || reason == REASON_WEBSITE || reason == REASON_ADULT || reason == REASON_KEYWORD ||
            reason == REASON_WEBSITE_LIMIT
    }
}

@Composable
private fun BlockScreen(
    appName: String,
    packageName: String,
    reason: Int,
    detail: String,
    shortsHaveExceptions: Boolean,
    sessionStart: Long,
    sessionEnd: Long,
    limitMinutes: Int,
    usedMs: Long,
    bedtimeEndMin: Int,
    emergencyAllowed: Boolean,
    emergencyApp: EmergencyApp?,
    limitEmergency: LimitEmergency,
    onLimitEmergency: () -> Unit,
    canRequestUnlock: Boolean,
    trustedPhoneName: String?,
    requestUi: AppUnlockUi,
    serverNow: () -> Long,
    onRequestUnlock: () -> Unit,
    onCancelRequest: () -> Unit,
    onGoHome: () -> Unit,
    onContinue: () -> Unit,
    onOpenFocus: () -> Unit,
    onChangeLimit: () -> Unit,
    onEmergency: (Int) -> Unit,
) {
    val c = FocusTheme.colors
    var showEmergency by remember { mutableStateOf(false) }

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(500)
        }
    }

    val isCategory = reason == BlockActivity.REASON_CATEGORY
    val isLimit = reason == BlockActivity.REASON_LIMIT || isCategory
    val isProtection = reason == BlockActivity.REASON_PROTECTION
    val isWebsite = reason == BlockActivity.REASON_WEBSITE
    // Protection, limit and website screens have no emergency / "back to focus" actions.
    val isBedtime = reason == BlockActivity.REASON_BEDTIME
    val isAdult = reason == BlockActivity.REASON_ADULT
    val isKeyword = reason == BlockActivity.REASON_KEYWORD
    // A website's daily limit looks like a limit screen, but it has no Emergency access (that belongs to app limits).
    val isSiteLimit = reason == BlockActivity.REASON_WEBSITE_LIMIT
    val noSession = isLimit || isSiteLimit || isProtection || isWebsite || isBedtime || isAdult || isKeyword
    val tint = if (isLimit || isSiteLimit) c.warning else c.accent
    val context = LocalContext.current
    val growth = remember { FocusStore.get(context).current().plantGrowth }

    // Remaining-time information, where it applies.
    val limited = sessionEnd > 0L
    val sessionTotal = (sessionEnd - sessionStart).coerceAtLeast(1L)
    val sessionLeft = (sessionEnd - now).coerceAtLeast(0L)
    val sessionFraction = if (limited) sessionLeft.toFloat() / sessionTotal else 1f

    val infoLabel: String?
    val infoValue: String?
    val infoProgress: Float?
    when {
        isProtection || isAdult || isKeyword -> { infoLabel = null; infoValue = null; infoProgress = null }
        isBedtime -> {
            infoLabel = "Bedtime ends in"
            infoValue = formatClock(
                BedtimeRules.minutesUntil(BedtimeStore.minuteOfDay(now), bedtimeEndMin) * 60_000L -
                    BedtimeStore.msIntoMinute(now)
            )
            infoProgress = null
        }
        isLimit || isSiteLimit -> {
            infoLabel = "Unlocks tomorrow in"
            infoValue = formatClock(msUntilMidnight(now))
            infoProgress = null
        }
        limited -> {
            infoLabel = "Focus session remaining"
            infoValue = formatClock(sessionLeft)
            infoProgress = sessionFraction
        }
        sessionStart > 0L -> {
            infoLabel = "Focusing for"
            infoValue = formatClock(now - sessionStart)
            infoProgress = null
        }
        else -> { infoLabel = null; infoValue = null; infoProgress = null }
    }

    val p = BlockPalette(c.isDark)
    val title = when {
        isLimit || isSiteLimit -> "Daily Limit Reached!"
        isProtection -> "Protected!"
        reason == BlockActivity.REASON_SETTINGS -> "Settings Locked!"
        isWebsite || isAdult -> "Site Blocked!"
        isKeyword -> "Page Blocked!"
        isBedtime -> "Time to Wind Down!"
        else -> "Stay With It!"
    }
    val subtitle = when (reason) {
        BlockActivity.REASON_SHORTS ->
            if (shortsHaveExceptions)
                "This Short isn't from one of your educational channels" +
                    (if (detail.isNotEmpty()) " ($detail)" else "") +
                    ", so it is blocked while LockDistra is on."
            else "YouTube Shorts is blocked while LockDistra is on."
        BlockActivity.REASON_FEATURE ->
            "${detail.ifEmpty { "This section" }} is blocked while LockDistra is on. " +
                "The rest of $appName still works."
        BlockActivity.REASON_SETTINGS ->
            "Android Settings is blocked while LockDistra is on. Calls, emergency services, " +
                "the power menu and quick settings still work."
        BlockActivity.REASON_CATEGORY ->
            "You have used your daily limit for $appName ${detail.ifEmpty { "this content" }}."
        BlockActivity.REASON_LIMIT ->
            "You have used your daily limit for $appName."
        BlockActivity.REASON_WEBSITE_LIMIT ->
            "You have used your daily limit for ${detail.ifEmpty { "this website" }}."
        BlockActivity.REASON_WEBSITE ->
            "${detail.ifEmpty { "This website" }} is blocked in $appName while LockDistra is on. " +
                "Other sites still work."
        BlockActivity.REASON_KEYWORD ->
            "This page matched your blocked keyword \"${detail.ifEmpty { "keyword" }}\", so it is closed in $appName. " +
                "Other pages still work."
        BlockActivity.REASON_ADULT ->
            "${detail.ifEmpty { "This website" }} is an adult website, so it is blocked in " +
                "$appName by LockDistra's Adult Content Protection."
        BlockActivity.REASON_PROTECTION ->
            "LockDistra's uninstall protection is on, so this screen is closed. " +
                "To change it, open LockDistra and go to Settings."
        BlockActivity.REASON_BEDTIME ->
            "$appName is blocked by Bedtime Mode until ${BedtimeRules.format(bedtimeEndMin)}. " +
                "Calls and emergency services still work."
        else -> "$appName is blocked while LockDistra is on."
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(blockBackground(p))
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            val minHeight = maxHeight
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .heightIn(min = minHeight)
                    .padding(horizontal = 22.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                BlockIllustration(Modifier.staggeredEntrance(1))
                Spacer(Modifier.height(10.dp))

                BlockTitleBar(title, p, Modifier.staggeredEntrance(2))

                // Which app (or browser) was stopped.
                if (reason != BlockActivity.REASON_PROTECTION && packageName.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier
                            .staggeredEntrance(3)
                            .clip(CircleShape)
                            .background(p.card)
                            .border(1.dp, p.cardStroke, CircleShape)
                            .padding(start = 6.dp, end = 14.dp, top = 5.dp, bottom = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(packageName, 26.dp)
                        Spacer(Modifier.size(8.dp))
                        Text(appName, style = MaterialTheme.typography.labelLarge, color = p.title)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyLarge,
                    color = p.body,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.staggeredEntrance(3)
                )

                if (isLimit || isSiteLimit) {
                    // Real numbers: the limit that was set and what was used today.
                    val limitMs = limitMinutes * 60_000L
                    Spacer(Modifier.height(16.dp))
                    BlockUsageCard(
                        limitText = blockDuration(limitMs),
                        usedText = blockDuration(minOf(usedMs, limitMs)),
                        p = p,
                        modifier = Modifier.staggeredEntrance(4)
                    )
                }
                if (infoLabel != null && infoValue != null) {
                    Spacer(Modifier.height(12.dp))
                    BlockTimeCard(infoLabel, infoValue, infoProgress, p, Modifier.staggeredEntrance(4))
                }
                val showPlant = !(isLimit || isSiteLimit || isProtection || isBedtime || isWebsite || isAdult || isKeyword)
                val tipTitle: String?
                val tipText: String
                when {
                    isCategory -> { tipTitle = "Take a Break!"; tipText = "Come back tomorrow for more time. The rest of $appName still works." }
                    isLimit -> { tipTitle = "Take a Break!"; tipText = "Come back tomorrow for more time." }
                    isSiteLimit -> { tipTitle = "Take a Break!"; tipText = "Come back tomorrow for more time. Other sites still work." }
                    isProtection -> { tipTitle = null; tipText = "" }
                    isBedtime -> { tipTitle = "Time to Rest!"; tipText = "Sleep well and come back fresh tomorrow." }
                    else -> { tipTitle = "Stay Focused!"; tipText = "Every minute you hold on helps your plant grow." }
                }
                if (tipTitle != null) {
                    Spacer(Modifier.height(12.dp))
                    BlockTipCard(
                        title = tipTitle,
                        text = tipText,
                        p = p,
                        modifier = Modifier.staggeredEntrance(4),
                        leading = if (showPlant) {
                            { PlantView(growth = growth, active = true, modifier = Modifier.fillMaxSize()) }
                        } else null
                    )
                }

                Spacer(Modifier.height(22.dp))
                Column(Modifier.fillMaxWidth().staggeredEntrance(5)) {
                    val homeText = if (noSession) "Go to Home" else "Back to Focus"
                    if (BlockActivity.canContinue(reason)) {
                        // Only one part of the app is blocked: carry on in the app, without that part.
                        PrimaryButton(text = "Continue to $appName", onClick = onContinue)
                        Spacer(Modifier.height(12.dp))
                        SecondaryButton(text = homeText, onClick = onGoHome)
                    } else {
                        PrimaryButton(text = homeText, onClick = onGoHome, icon = Icons.Rounded.Home)
                    }
                    if (isLimit || isSiteLimit) {
                        Spacer(Modifier.height(12.dp))
                        SecondaryButton(text = "Change limit", onClick = onChangeLimit)
                    }
                    if (canRequestUnlock) {
                        // Ask the trusted phone for more time in this app. Shown for a focus block,
                        // a daily limit and a Shorts / Reels limit; the answer closes this screen.
                        val mine = when (requestUi) {
                            is AppUnlockUi.Sending -> requestUi.pkg == packageName
                            is AppUnlockUi.Waiting -> requestUi.pkg == packageName
                            is AppUnlockUi.Rejected -> requestUi.pkg == packageName
                            is AppUnlockUi.Expired -> requestUi.pkg == packageName
                            is AppUnlockUi.Failed -> requestUi.pkg == packageName
                            else -> false
                        }
                        val waiting = mine && (requestUi is AppUnlockUi.Sending || requestUi is AppUnlockUi.Waiting)
                        Spacer(Modifier.height(12.dp))
                        SecondaryButton(
                            text = if (waiting) "Cancel request" else "Request to unlock",
                            onClick = { if (waiting) onCancelRequest() else onRequestUnlock() }
                        )
                        if (mine) {
                            Spacer(Modifier.height(10.dp))
                            val phone = trustedPhoneName ?: "your trusted phone"
                            val (text, warn) = when (requestUi) {
                                is AppUnlockUi.Sending -> "Sending the request..." to false
                                is AppUnlockUi.Waiting -> {
                                    val left = (requestUi.expiresAt - serverNow()).coerceAtLeast(0L)
                                    "Waiting for $phone to answer (${formatClock(left)}). " +
                                        "You can leave this screen; $appName opens by itself if it is approved." to false
                                }
                                is AppUnlockUi.Rejected -> "$phone said no." to true
                                is AppUnlockUi.Expired -> "No answer from $phone. Try again." to true
                                is AppUnlockUi.Failed -> requestUi.message to true
                                else -> "" to false
                            }
                            if (text.isNotEmpty()) {
                                Text(
                                    text,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (warn) c.warning else c.muted,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                    if (reason == BlockActivity.REASON_SETTINGS) {
                        // Recovery stays in the user's hands: the session can be ended from the app.
                        Spacer(Modifier.height(12.dp))
                        SecondaryButton(text = "Open LockDistra", onClick = onOpenFocus)
                    }
                    if (isLimit && limitEmergency.enabled) {
                        // Emergency access for a daily limit: a few minutes, a few times a day.
                        Spacer(Modifier.height(12.dp))
                        SecondaryButton(
                            text = when {
                                showEmergency -> "Hide emergency access"
                                limitEmergency.available -> "Emergency access (${limitEmergency.remaining} left)"
                                else -> "Emergency access (none left)"
                            },
                            onClick = { showEmergency = !showEmergency }
                        )
                    }
                    if (!noSession) {
                        Spacer(Modifier.height(12.dp))
                        val usable = emergencyAllowed && emergencyApp?.available == true
                        SecondaryButton(
                            text = when {
                                showEmergency -> "Hide emergency access"
                                usable -> "Emergency access (${emergencyApp?.remaining} left)"
                                else -> "Emergency access"
                            },
                            onClick = { showEmergency = !showEmergency }
                        )
                    }
                }
                AnimatedVisibility(
                    visible = showEmergency && isLimit && limitEmergency.enabled,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(16.dp))
                        Text(
                            if (limitEmergency.available)
                                "Use ${formatMinutes(limitEmergency.minutes)} more of " +
                                    "${if (isCategory) "$appName ${detail.ifEmpty { "this content" }}" else appName}. " +
                                    "${limitEmergency.remaining} of ${limitEmergency.attempts} emergency " +
                                    "attempts left today. It closes again by itself."
                            else "No emergency attempts left today (0 of ${limitEmergency.attempts}). They come back tomorrow.",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (limitEmergency.available) c.muted else c.warning,
                            textAlign = TextAlign.Center
                        )
                        if (limitEmergency.available) {
                            Spacer(Modifier.height(12.dp))
                            SoftChip(
                                "Use emergency (${limitEmergency.minutes} min)",
                                selected = false,
                                onClick = onLimitEmergency
                            )
                        }
                    }
                }
                AnimatedVisibility(
                    visible = showEmergency && !noSession,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(16.dp))
                        val usable = emergencyAllowed && emergencyApp?.available == true
                        Text(
                            when {
                                !emergencyAllowed -> "Emergency access is switched off for this session."
                                emergencyApp == null || !emergencyApp.enabled ->
                                    "$appName isn't set up for Emergency access."
                                emergencyApp.remaining == 0 ->
                                    "No emergency attempts left for $appName (0 of ${emergencyApp.limit})."
                                else -> "Open $appName for a few minutes. ${emergencyApp.remaining} of " +
                                    "${emergencyApp.limit} attempts left. It is blocked again by itself."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (usable) c.muted else c.warning,
                            textAlign = TextAlign.Center
                        )
                        if (usable) {
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf(1, 2, 3, 4, 5).forEach { m ->
                                    SoftChip("$m min", selected = false, onClick = { onEmergency(m) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** "30 Minutes", "1 Hour", "1 h 30 min": a daily limit / used time for the usage card. */
private fun blockDuration(ms: Long): String {
    val total = (ms / 60_000L).toInt().coerceAtLeast(0)
    val h = total / 60
    val m = total % 60
    return when {
        h == 0 -> if (m == 1) "1 Minute" else "$m Minutes"
        m == 0 -> if (h == 1) "1 Hour" else "$h Hours"
        else -> "$h h $m min"
    }
}

/** Milliseconds from [now] until the next local midnight, when daily usage resets. */
private fun msUntilMidnight(now: Long): Long {
    val next = Calendar.getInstance().apply {
        timeInMillis = now
        add(Calendar.DAY_OF_YEAR, 1)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    return next.timeInMillis - now
}
