package com.focusmode.app.ui.screens

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.PomodoroPhase
import com.focusmode.app.data.PomodoroRules
import com.focusmode.app.data.PomodoroState
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusProgressBar
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SecondaryButton
import com.focusmode.app.ui.formatClock
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

/**
 * Compact Pomodoro controls on the Home screen. Idle: the two durations and Start. Running: which
 * phase it is (Focus or Break), the countdown, and Pause / Resume / Stop. It never chooses what is
 * blocked: Focus time uses exactly the apps, limits and sites the person already set up.
 */
@Composable
fun PomodoroCard(
    pomodoro: PomodoroState,
    focus: FocusState,
    /** Nothing is selected to block, so Focus time would not block anything yet. */
    nothingBlocked: Boolean,
    /** Android 12+ and "Alarms & reminders" is off: breaks can end a little late with the screen off. */
    exactAlarmsMissing: Boolean,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onStop: () -> Unit,
    onDurations: (focusMin: Int, breakMin: Int) -> Unit,
    onGrantExactAlarms: () -> Unit,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val onBreak = pomodoro.phase == PomodoroPhase.BREAK
    val phaseColor = if (onBreak) c.leafMid else c.accent

    // Ticks only while time is passing in a running cycle.
    val now by produceState(System.currentTimeMillis(), pomodoro.running) {
        value = System.currentTimeMillis()
        while (pomodoro.running) {
            delay(500)
            value = System.currentTimeMillis()
        }
    }

    FocusCard(padding = PaddingValues(horizontal = 18.dp, vertical = 16.dp)) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Pomodoro", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                if (pomodoro.active) {
                    Text(
                        when {
                            pomodoro.paused -> "PAUSED"
                            onBreak -> "BREAK"
                            else -> "FOCUS \u2022 ROUND ${pomodoro.round}"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = c.onAccent,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(if (pomodoro.paused) c.muted else phaseColor)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            if (!pomodoro.active) {
                Text(
                    "${pomodoro.focusMin} min focus, then ${pomodoro.breakMin} min break, repeating until you stop it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Spacer(Modifier.height(10.dp))
                DurationRow("Focus", pomodoro.focusMin, PomodoroRules.MIN_FOCUS, PomodoroRules.MAX_FOCUS, 5) {
                    onDurations(it, pomodoro.breakMin)
                }
                Spacer(Modifier.height(6.dp))
                DurationRow("Break", pomodoro.breakMin, PomodoroRules.MIN_BREAK, PomodoroRules.MAX_BREAK, 1) {
                    onDurations(pomodoro.focusMin, it)
                }
                if (nothingBlocked) {
                    Text(
                        "No apps are selected to block yet, so focus time won't block anything. Choose them under Blocking.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.warning,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    text = "Start Pomodoro",
                    onClick = onStart,
                    enabled = !focus.focusActive,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                val left: Long
                val total: Long
                if (pomodoro.paused) {
                    left = pomodoro.pausedLeftMs
                    total = (if (onBreak) pomodoro.breakMin else pomodoro.focusMin) * 60_000L
                } else if (onBreak) {
                    left = PomodoroRules.breakLeftMs(
                        pomodoro, now, SystemClock.elapsedRealtime(), bootCountOf(context)
                    )
                    total = pomodoro.breakMin * 60_000L
                } else {
                    left = (focus.sessionEnd - now).coerceAtLeast(0L)
                    total = pomodoro.focusMin * 60_000L
                }
                Text(
                    formatClock(left),
                    style = MaterialTheme.typography.headlineLarge,
                    color = phaseColor,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
                Text(
                    when {
                        pomodoro.paused -> "Paused. Focus restrictions are off until you resume."
                        onBreak -> "Break time. Focus restrictions are paused; the next round starts by itself."
                        else -> "Focus time. Your blocked apps stay closed."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
                )
                Spacer(Modifier.height(10.dp))
                FocusProgressBar(
                    progress = (left.toFloat() / total.coerceAtLeast(1L)).coerceIn(0f, 1f),
                    color = phaseColor,
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton(
                        text = if (pomodoro.paused) "Resume" else "Pause",
                        onClick = if (pomodoro.paused) onResume else onPause,
                        modifier = Modifier.weight(1f)
                    )
                    SecondaryButton(text = "Stop", onClick = onStop, modifier = Modifier.weight(1f))
                }
            }

            if (exactAlarmsMissing) {
                TextButton(onClick = onGrantExactAlarms) {
                    Text("Allow exact timing for breaks", color = c.accent, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun DurationRow(label: String, value: Int, min: Int, max: Int, step: Int, onChange: (Int) -> Unit) {
    val c = FocusTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        CircleIconButton(Icons.Rounded.Remove, "Shorter $label", onClick = { onChange((value - step).coerceAtLeast(min)) })
        Text(
            "$value min",
            style = MaterialTheme.typography.titleMedium,
            color = c.text,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp).size(width = 64.dp, height = 24.dp)
        )
        CircleIconButton(Icons.Rounded.Add, "Longer $label", onClick = { onChange((value + step).coerceAtMost(max)) })
    }
}

private fun bootCountOf(context: android.content.Context): Int = try {
    android.provider.Settings.Global.getInt(context.contentResolver, android.provider.Settings.Global.BOOT_COUNT, -1)
} catch (_: Exception) {
    -1
}
