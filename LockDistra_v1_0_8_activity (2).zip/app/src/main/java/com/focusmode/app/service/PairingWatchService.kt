package com.focusmode.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.focusmode.app.MainActivity
import com.focusmode.app.R
import com.focusmode.app.data.IntentGuard
import com.focusmode.app.data.online.OnlineManager
import com.focusmode.app.data.online.PairingUi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Whether one of LockDistra's screens is on screen right now (set by MainActivity). */
object AppVisibility {
    @Volatile private var started = 0

    val visible: Boolean get() = started > 0

    fun onStart(context: Context) {
        started++
        // Looking at the app is the answer to "someone wants to connect": the dialog is on screen.
        PairingNotifications.cancel(context)
    }

    fun onStop() {
        if (started > 0) started--
    }
}

/**
 * Keeps LockDistra alive while a connector code is waiting for the second phone, so the request
 * is not lost when the person leaves the app (Android would otherwise end the process and the
 * code would silently stop working). When the second phone enters the code and the app is not on
 * screen, this posts a notification; tapping it opens LockDistra, which shows "Connect this phone?"
 * with Yes / No on whatever screen is open.
 */
class PairingWatchService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification(this)
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(ID, notification)
        }
        val manager = OnlineManager.get(this)
        if (!manager.configured) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started) {
            started = true
            scope.launch {
                manager.pairingUi.collect { ui ->
                    when (ui) {
                        is PairingUi.ConfirmPhone -> {
                            if (!AppVisibility.visible) PairingNotifications.show(this@PairingWatchService, ui.deviceName)
                        }
                        PairingUi.Idle, is PairingUi.Done, is PairingUi.Failed -> {
                            PairingNotifications.cancel(this@PairingWatchService)
                            ServiceCompat.stopForeground(this@PairingWatchService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                            stopSelf()
                        }
                        else -> PairingNotifications.cancel(this@PairingWatchService)
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "pairing_wait_v1"
        private const val ID = 1012

        private fun buildNotification(context: Context): Notification {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Connecting a trusted phone", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Shown while your connector code waits for the second phone."
                    setShowBadge(false)
                }
            )
            val open = PendingIntent.getActivity(
                context, ID,
                Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_leaf)
                .setContentTitle("Waiting for your second phone")
                .setContentText("Enter the connector code there. You can leave this app.")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setCategory(NotificationCompat.CATEGORY_SERVICE)
                .setContentIntent(open)
                .build()
        }

        /** Starts the wait. Call while the app is on screen (Android refuses it from the background). */
        fun start(context: Context) {
            val app = context.applicationContext
            try {
                ContextCompat.startForegroundService(app, Intent(app, PairingWatchService::class.java))
            } catch (_: Exception) {
                // Without it pairing still works while the app stays open.
            }
        }
    }
}

/** "Someone entered your code": the heads-up that brings the person back to say Yes or No. */
object PairingNotifications {
    private const val CHANNEL = "pairing_request_v1"
    private const val ID = 1013

    private fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Connect requests", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Asks you to accept the second phone you are connecting."
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(ID)
    }

    @SuppressLint("MissingPermission")
    fun show(context: Context, deviceName: String) {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return
        ensureChannel(context)
        val open = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(context))
        }
        val pending = PendingIntent.getActivity(
            context, ID, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("Connect this phone?")
            .setContentText("\"$deviceName\" entered your connector code. Tap to accept or decline.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("\"$deviceName\" entered your connector code. Tap to accept or decline."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        NotificationManagerCompat.from(context).notify(ID, n)
    }
}
