package com.focusmode.app.service

import android.content.Context
import android.os.SystemClock
import com.focusmode.app.LectureActivity
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.LectureLockStore
import com.focusmode.app.data.LectureTimerRules
import com.focusmode.app.data.PomodoroStore

/**
 * Ties the Focus timer to the lecture. Called about once a second by the blocking service (so it also works with the app
 * closed) and a few times a second by the open player (so the timer on screen stands still smoothly).
 *
 *  - Lecture not playing (paused, buffering on a slow network, ended in the middle, person left the player): the end of the
 *    session moves forward by the time that passed, so the timer stands still.
 *  - The person was in the player and left it: one "Back to Focus" notification; tapping it opens the lecture again.
 *  - The lecture counted as finished, or a Pomodoro is running: nothing changes.
 */
object LectureTimerGuard {

    /** True while the timer stands still (the status notification then says "Timer paused"). */
    @Volatile var frozen: Boolean = false
        private set

    private var lastCheck = 0L
    private var wasFrozen = false
    private var seenInPlayer = false
    private var awaySince = 0L
    private var notified = false
    private var sessionKey = 0L

    @Synchronized
    fun tick(context: Context) {
        val app = context.applicationContext
        val now = SystemClock.elapsedRealtime()
        val last = lastCheck
        lastCheck = now

        val focusStore = FocusStore.get(app)
        val s = focusStore.current()
        // A new session starts clean: nothing is left over from the earlier one (the time the timer stood still is taken out of the key).
        val key = s.sessionStart - s.lectureShiftMs
        if (key != sessionKey) {
            sessionKey = key
            wasFrozen = false
            seenInPlayer = false
            awaySince = 0L
            if (notified) { Notifications.cancelBackToFocus(app); notified = false }
        }
        val lecture = LectureLockStore.get(app)
        val target = lecture.target
        val playerVisible = LectureActivity.visible
        val freeze = LectureTimerRules.shouldFreeze(
            focusActive = s.focusActive,
            hasLecture = target != null,
            pomodoroActive = PomodoroStore.get(app).current().active,
            lectureDone = lecture.isDone,
            playing = LectureActivity.playingNow(),
        )

        // The part of time since the last check that the lecture was not playing: the timer does not count it.
        if (freeze && wasFrozen) focusStore.shiftSession(LectureTimerRules.stepMs(last, now))

        if (!s.focusActive) {
            seenInPlayer = false
        } else if (playerVisible && target != null) {
            seenInPlayer = true
        }

        // "Back to Focus"
        if (!freeze || playerVisible) awaySince = 0L else if (awaySince == 0L) awaySince = now
        if (notified && (!freeze || playerVisible)) {
            Notifications.cancelBackToFocus(app)
            notified = false
        }
        val awayMs = if (awaySince == 0L) 0L else now - awaySince
        if (target != null && LectureTimerRules.shouldNotify(freeze, seenInPlayer, playerVisible, awayMs, notified)) {
            notified = true
            Notifications.postBackToFocus(app, target.url)
        }

        if (freeze != wasFrozen) {
            wasFrozen = freeze
            frozen = freeze
            Notifications.refreshStatus(app)
        }
    }
}
