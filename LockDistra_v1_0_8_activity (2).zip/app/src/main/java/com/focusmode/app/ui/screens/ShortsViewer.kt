package com.focusmode.app.ui.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.focusmode.app.data.StudyRules
import com.focusmode.app.data.StudyStore
import com.focusmode.app.data.StudyVideo
import kotlinx.coroutines.delay

/**
 * Shorts the way YouTube shows them: one Short fills the screen, swipe up for the next one, swipe down for the one before.
 * Only the Short that is on screen has a player (the others show their picture), so it stays light. Tap = pause / play.
 * It loops, like YouTube. [onNearEnd] is called when the last few Shorts come into view, so a list that can grow does.
 */
@Composable
fun ShortsViewer(
    videos: List<StudyVideo>,
    startId: String,
    onNearEnd: () -> Unit,
    onOpenChannel: (StudyVideo) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val store = remember { StudyStore.get(context) }
    val start = remember(startId) { videos.indexOfFirst { it.id == startId }.coerceAtLeast(0) }
    val pager = rememberPagerState(initialPage = start) { videos.size }
    val page = pager.settledPage

    BackHandler(onBack = onBack)

    // A Short counts as "watched" (shapes the suggestions) only after a few seconds on it, not while swiping past.
    LaunchedEffect(page, videos.size) {
        if (page >= videos.size - 3) onNearEnd()
        val v = videos.getOrNull(page) ?: return@LaunchedEffect
        delay(5000)
        store.noteWatched(v.channelId, v.channelTitle)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        VerticalPager(state = pager, modifier = Modifier.fillMaxSize(), key = { videos[it].id }) { index ->
            val v = videos[index]
            ShortPage(v, active = index == pager.settledPage, onOpenChannel = { onOpenChannel(v) })
        }
        IconButton(onClick = onBack, modifier = Modifier.statusBarsPadding().padding(4.dp).align(Alignment.TopStart)) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Color.White)
        }
    }
}

@Composable
private fun ShortPage(v: StudyVideo, active: Boolean, onOpenChannel: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (active) ShortPlayer(v.id, v.thumbUrl, Modifier.fillMaxSize())
        else Thumb(v.thumbUrl, Modifier.fillMaxSize())

        Column(
            Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                .padding(start = 16.dp, end = 16.dp, top = 48.dp, bottom = 20.dp)
        ) {
            if (v.channelTitle.isNotEmpty()) {
                Text(
                    v.channelTitle, style = MaterialTheme.typography.titleSmall, color = Color.White, fontWeight = FontWeight.Bold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clickable(onClick = onOpenChannel).padding(vertical = 6.dp)
                )
            }
            Text(v.title, style = MaterialTheme.typography.bodyMedium, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            StudyRules.timeAgo(v.publishedAt).takeIf { it.isNotEmpty() }?.let {
                Text(it, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
            }
        }
    }
}

/** Called by the player page (a background thread). */
private class ShortBridge(private val onPlayingCb: () -> Unit, private val onErrorCb: () -> Unit) {
    @JavascriptInterface
    fun onPlaying() = onPlayingCb()

    @JavascriptInterface
    fun onError() = onErrorCb()
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun ShortPlayer(id: String, thumbUrl: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var ready by remember(id) { mutableStateOf(false) }
    var failed by remember(id) { mutableStateOf(false) }

    val web = remember(id) {
        val main = Handler(Looper.getMainLooper())
        WebView(context).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            // A Short inside the pager sits in a moved / clipped layer: without its own hardware layer the video picture can
            // come out black while the sound plays. The lecture player (a plain screen) never had this.
            setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            // Same as the lecture player (which plays fine): cookies on and a chrome client, which YouTube's player expects.
            android.webkit.CookieManager.getInstance().setAcceptCookie(true)
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webChromeClient = android.webkit.WebChromeClient()
            addJavascriptInterface(ShortBridge({ main.post { ready = true } }, { main.post { failed = true } }), "ShortBridge")
            // The page never leaves the player: any address the page tries to open in the main frame is refused.
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.isForMainFrame
            }
            // Same rule as the lecture player: YouTube wants to know which app embeds it, so the app's own address is the origin.
            val origin = "https://" + context.packageName
            loadDataWithBaseURL("$origin/", ShortPlayerHtml.build(id, origin), "text/html", "utf-8", null)
        }
    }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, web) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) web.onPause() else if (event == Lifecycle.Event.ON_RESUME) web.onResume()
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            web.stopLoading()
            web.destroy()
        }
    }

    Box(modifier) {
        AndroidView(factory = { web }, modifier = Modifier.fillMaxSize())
        // The picture stays over the player until the video really plays, so there is never a black flash.
        if (!ready && !failed) Thumb(thumbUrl, Modifier.fillMaxSize())
        if (failed) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("This video cannot be played here.\nSwipe up for the next one.", color = Color.White, textAlign = TextAlign.Center)
            }
        }
        // This layer takes every touch, so the web page can never be tapped or scrolled: a tap pauses / plays, and a
        // vertical swipe reaches the pager.
        Box(Modifier.fillMaxSize().pointerInput(web) { detectTapGestures { web.evaluateJavascript("toggle()", null) } })
    }
}

/** The player page of one Short: the official IFrame player, no controls, looping. NOTE: no dollar sign in this string. */
private object ShortPlayerHtml {
    fun build(videoId: String, origin: String): String = TEMPLATE.replace("__ID__", videoId).replace("__ORIGIN__", origin)

    private const val TEMPLATE = """
<html><head><link rel="preconnect" href="https://www.youtube.com"><link rel="preconnect" href="https://i.ytimg.com"><link rel="preconnect" href="https://www.google.com"><link rel="dns-prefetch" href="https://www.googlevideo.com"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
html,body{margin:0;height:100%;background:#000;overflow:hidden}
#p,iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0}
#pz{display:none;position:absolute;top:50%;left:50%;width:72px;height:72px;margin:-36px 0 0 -36px;border-radius:36px;background:rgba(0,0,0,.5);
color:#fff;font-size:30px;line-height:72px;text-align:center;z-index:5;font-family:sans-serif}
</style></head><body>
<div id="p"></div><div id="pz">&#9654;</div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var P=null;
function note(n){try{ShortBridge[n]()}catch(e){}}
function onYouTubeIframeAPIReady(){
P=new YT.Player('p',{videoId:'__ID__',width:'100%',height:'100%',
playerVars:{autoplay:1,controls:0,disablekb:1,fs:0,rel:0,playsinline:1,modestbranding:1,iv_load_policy:3,enablejsapi:1,origin:'__ORIGIN__'},
events:{
onReady:function(){try{P.playVideo()}catch(e){}fit()},
onStateChange:function(e){
if(e.data===1){document.getElementById('pz').style.display='none';setTimeout(function(){note('onPlaying')},700)}
if(e.data===2){document.getElementById('pz').style.display='block'}
if(e.data===0){try{P.seekTo(0);P.playVideo()}catch(x){}}
},
onError:function(){note('onError')}
}});
}
/* The Short fills the whole screen (no black strip): the player is made 9:16 and at least as tall as the screen, centred, so the
   sides are cropped a little instead of leaving black bars. It is also M px taller above and below than the picture: YouTube draws
   its title bar (top), its logo and share button (bottom) on the edges of the player, so they land in those M px, outside the
   screen, and are never seen. Explicit pixels, because a percentage height can collapse in a WebView inside a pager. */
function fit(){
var f=document.querySelector('iframe');if(!f)return;
var W=window.innerWidth,H=window.innerHeight,M=110;
if(W<=0||H<=0)return;
var vh=Math.max(H,W*16/9),vw=vh*9/16;
f.style.position='absolute';f.style.width=vw+'px';f.style.height=(vh+2*M)+'px';
f.style.left=((W-vw)/2)+'px';f.style.top=(-(M+(vh-H)/2))+'px';
}
window.addEventListener('resize',fit);setInterval(fit,250);
function toggle(){
if(!P)return;
try{var s=P.getPlayerState();if(s===1)P.pauseVideo();else P.playVideo()}catch(e){}
}
</script></body></html>
"""
}
