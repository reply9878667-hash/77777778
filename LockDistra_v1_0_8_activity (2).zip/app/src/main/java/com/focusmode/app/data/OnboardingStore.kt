package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Plain rules for the first-launch onboarding. No Android types, so they are unit tested on the JVM.
 */
object OnboardingRules {

    /**
     * true  = the welcome screen was already answered (or must not be shown) -> go straight to the app.
     * false = show the welcome screen.
     *
     * @param stored the saved flag, or null when it was never written (first launch of this feature).
     * @param isUpdatedInstall the app was installed before and has only been updated since.
     * @param skipForExistingInstalls when true, people who already used the app are not shown the
     *   introduction (only brand-new installs see it). Default false: everybody sees it exactly once.
     */
    fun welcomeDone(
        stored: Boolean?,
        isUpdatedInstall: Boolean,
        skipForExistingInstalls: Boolean = SKIP_FOR_EXISTING_INSTALLS,
    ): Boolean = stored ?: (skipForExistingInstalls && isUpdatedInstall)

    /** Flip to true to show the introduction only on fresh installs, not on updates. */
    const val SKIP_FOR_EXISTING_INSTALLS = false
}

/**
 * Where the person stopped inside the onboarding (Task 3). Saved after every change so that closing the app halfway
 * brings them back to the same question with the same answers, instead of the welcome screen with nothing.
 * [step] is the name of an `OnboardingStep`, [questionIndex] the question when the step is the questions.
 */
data class OnboardingDraft(
    val step: String,
    val questionIndex: Int,
    val answers: OnboardingAnswers,
)

/**
 * Typewriter helper. Counts and cuts text by Unicode code point, so an emoji such as the waving
 * hand (two UTF-16 chars) is never split in half while the text is being "typed".
 */
object Typewriter {
    fun length(text: String): Int = text.codePointCount(0, text.length)

    fun prefix(text: String, units: Int): String {
        if (units <= 0) return ""
        if (units >= length(text)) return text
        return text.substring(0, text.offsetByCodePoints(0, units))
    }
}

/**
 * Remembers that the welcome introduction has been seen. Only this one flag lives here for now;
 * Part 2 (the questions) adds its own answers next to it. No account, login or network involved.
 */
class OnboardingStore private constructor(context: Context) {

    // The answers hold the person's name and goals, so they live in the normal private storage (encrypted with
    // the screen lock, like the login and the profile), not in the device-protected storage that is readable
    // before the first unlock. Older installs kept this file there: it is moved over once, with its content.
    private val prefs: SharedPreferences = privatePrefs(context)

    private val _welcomeDone = MutableStateFlow(load(context))
    val welcomeDone: StateFlow<Boolean> = _welcomeDone.asStateFlow()

    private fun load(context: Context): Boolean {
        val stored = if (prefs.contains(K_WELCOME_DONE)) prefs.getBoolean(K_WELCOME_DONE, false) else null
        val done = OnboardingRules.welcomeDone(stored, isUpdatedInstall(context))
        // Existing install that is skipped by the rule: remember it, so the answer never changes later.
        if (stored == null && done) prefs.edit().putBoolean(K_WELCOME_DONE, true).apply()
        return done
    }

    private fun isUpdatedInstall(context: Context): Boolean = try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        info.lastUpdateTime > info.firstInstallTime
    } catch (_: Exception) {
        false
    }

    /** The person pressed Start / Continue on the welcome screen. */
    fun markWelcomeDone() {
        prefs.edit().putBoolean(K_WELCOME_DONE, true).apply()
        _welcomeDone.value = true
    }

    // ---- Interrupted onboarding (Task 3) ----------------------------------------------------

    /** Remembers the current question and answers. Cheap (one apply), so it is called on every change. */
    fun saveDraft(draft: OnboardingDraft) {
        prefs.edit()
            .putString(K_DRAFT_STEP, draft.step)
            .putInt(K_DRAFT_INDEX, draft.questionIndex)
            .putStringSet(K_DRAFT_ANSWERS, draft.answers.encode().toSet())
            .apply()
    }

    /** The unfinished onboarding, or null when there is none (never started, or already finished). */
    fun loadDraft(): OnboardingDraft? {
        val step = prefs.getString(K_DRAFT_STEP, null) ?: return null
        return OnboardingDraft(
            step = step,
            questionIndex = prefs.getInt(K_DRAFT_INDEX, 0),
            answers = OnboardingAnswers.decode(prefs.getStringSet(K_DRAFT_ANSWERS, emptySet())?.toList().orEmpty()),
        )
    }

    fun clearDraft() {
        prefs.edit().remove(K_DRAFT_STEP).remove(K_DRAFT_INDEX).remove(K_DRAFT_ANSWERS).apply()
    }

    // ---- A new account that still owes its own answers (Task 3) ------------------------------

    private val _requiredFor = MutableStateFlow(prefs.getString(K_REQUIRED_UID, null)?.takeIf { it.isNotEmpty() })

    /**
     * The uid of a brand-new account that was created on a phone whose onboarding answers already belong to somebody
     * else (or were never given). That account goes through the onboarding once; null = nobody has to.
     * Stored, so closing the app halfway does not skip it.
     */
    val requiredFor: StateFlow<String?> = _requiredFor.asStateFlow()

    fun requireFor(uid: String) {
        prefs.edit().putString(K_REQUIRED_UID, uid).commit()
        _requiredFor.value = uid
    }

    fun clearRequired() {
        prefs.edit().remove(K_REQUIRED_UID).commit()
        _requiredFor.value = null
    }

    /** True when the phone holds answers that no account has taken yet. */
    fun hasUnclaimedAnswers(): Boolean = unclaimedAnswers() != null

    /**
     * True when the answers on this phone are [uid]'s: either still waiting for an account (the sign-up that just
     * happened is about to take them) or already moved into [uid]'s record. Needed because the move runs in the
     * background right after the sign-up, so "unclaimed" alone can already be false when the person presses Continue.
     */
    fun hasAnswersFor(uid: String): Boolean {
        if (savedAnswers().isEmpty) return false
        val owner = prefs.getString(K_CLAIMED_BY, null).orEmpty()
        return owner.isEmpty() || owner == uid
    }

    /**
     * Keeps the seven answers on this phone (private app storage only; nothing is sent anywhere,
     * no account is involved). Called once, from the celebration screen's Continue.
     */
    fun saveAnswers(answers: OnboardingAnswers) {
        // A freshly completed onboarding has not been handed to any account yet. The unfinished-draft copy is
        // replaced by this final one in the same commit, so a restart can never show the questions again.
        prefs.edit()
            .putStringSet(K_ANSWERS, answers.encode().toSet())
            .remove(K_CLAIMED_BY)
            .remove(K_DRAFT_STEP).remove(K_DRAFT_INDEX).remove(K_DRAFT_ANSWERS)
            .putBoolean(K_WELCOME_DONE, true)
            .commit()
        _welcomeDone.value = true
    }

    /**
     * The answers that were given before any account existed and have not been moved into an account yet, or
     * null. The profile system (data/profile) calls this right after a sign-up / login, saves the answers under
     * that account, and only then calls [markClaimed]. Once claimed they are never handed to a second account.
     */
    fun unclaimedAnswers(): OnboardingAnswers? {
        if (!prefs.getString(K_CLAIMED_BY, null).isNullOrEmpty()) return null
        return savedAnswers().takeUnless { it.isEmpty }
    }

    fun markClaimed(uid: String) {
        prefs.edit().putString(K_CLAIMED_BY, uid).commit()
    }

    /** The answers saved by [saveAnswers]; empty if the onboarding was never completed. */
    fun savedAnswers(): OnboardingAnswers =
        OnboardingAnswers.decode(prefs.getStringSet(K_ANSWERS, emptySet())?.toList().orEmpty())

    companion object {
        private const val FILE = "onboarding"

        private fun privatePrefs(context: Context): SharedPreferences {
            val app = context.applicationContext
            if (Build.VERSION.SDK_INT >= 24) {
                try {
                    app.moveSharedPreferencesFrom(app.createDeviceProtectedStorageContext(), FILE)
                } catch (_: Exception) {
                    // Nothing to move (new install) or not possible right now: the normal file is used as it is.
                }
            }
            return app.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }

        private const val K_WELCOME_DONE = "welcome_done"
        private const val K_ANSWERS = "answers"
        private const val K_CLAIMED_BY = "answers_claimed_by"
        private const val K_DRAFT_STEP = "draft_step"
        private const val K_DRAFT_INDEX = "draft_index"
        private const val K_DRAFT_ANSWERS = "draft_answers"
        private const val K_REQUIRED_UID = "required_for_uid"

        @Volatile
        private var instance: OnboardingStore? = null

        fun get(context: Context): OnboardingStore =
            instance ?: synchronized(this) {
                instance ?: OnboardingStore(context.applicationContext).also { instance = it }
            }
    }
}
