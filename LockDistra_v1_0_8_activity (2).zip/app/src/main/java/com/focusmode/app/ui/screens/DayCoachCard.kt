package com.focusmode.app.ui.screens

import android.app.TimePickerDialog
import android.text.format.DateFormat
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.BedtimeRules
import com.focusmode.app.data.DayCoachStore
import com.focusmode.app.service.DayCoachEngine
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.theme.FocusTheme

/**
 * Day Coach (Home screen, under Daily Tasks). Only two times are chosen: the day start and the sleep time. At the day start
 * the coach says good morning and, 5 minutes later, tells the first task of the list; 15 minutes before sleep it asks to
 * set tomorrow's tasks; at the sleep time it says good night. Nothing is planned here and nothing is blocked.
 */
@Composable
fun DayCoachCard(modifier: Modifier = Modifier) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val store = remember { DayCoachStore.get(context) }
    val settings by store.state.collectAsState()
    var open by remember { mutableStateOf(false) }

    fun pickTime(initial: Int, onPicked: (Int) -> Unit) {
        TimePickerDialog(
            context,
            { _, h, m -> onPicked(h * 60 + m) },
            initial / 60, initial % 60,
            DateFormat.is24HourFormat(context)
        ).show()
    }

    FocusCard(
        modifier = modifier.fillMaxWidth(),
        padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        highlight = settings.enabled,
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { open = !open }) {
                    Text("Day Coach \uD83E\uDDED", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (settings.enabled) "Coach ON \u2022 starts ${BedtimeRules.format(settings.dayStartMin)}, sleep ${BedtimeRules.format(settings.sleepMin)}"
                        else "Subah pehla task, raat ko kal ke tasks ka reminder",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (settings.enabled) c.accent else c.muted,
                    )
                }
                FocusSwitch(
                    checked = settings.enabled,
                    onCheckedChange = {
                        store.setEnabled(it)
                        if (it) {
                            open = true
                            DayCoachEngine.onEnabled(context)
                        } else {
                            DayCoachEngine.sync(context)
                        }
                    }
                )
            }

            if (open || settings.enabled) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    SoftChip(
                        text = "Day start ${BedtimeRules.format(settings.dayStartMin)}",
                        selected = false,
                        onClick = {
                            pickTime(settings.dayStartMin) {
                                store.setDayStart(it)
                                DayCoachEngine.onSettingsChanged(context)
                            }
                        }
                    )
                    SoftChip(
                        text = "Sleep ${BedtimeRules.format(settings.sleepMin)}",
                        selected = false,
                        onClick = {
                            pickTime(settings.sleepMin) {
                                store.setSleep(it)
                                DayCoachEngine.onSettingsChanged(context)
                            }
                        }
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Day start par Good morning, 5 min baad tumhara pehla task. Sone se 15 min pehle kal ke tasks set karne ka reminder, aur sone ke time Good night.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(end = 4.dp),
                )
            }
        }
    }
}
