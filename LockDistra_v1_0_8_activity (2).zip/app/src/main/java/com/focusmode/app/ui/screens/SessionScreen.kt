package com.focusmode.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.data.FocusState
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusBackground
import com.focusmode.app.ui.components.PlantView
import com.focusmode.app.ui.formatClock
import com.focusmode.app.ui.theme.PoppinsFamily
import kotlinx.coroutines.delay

/** Without a time limit the plant takes this long to reach full bloom. */
private const val OPEN_ENDED_GROW_MS = 60L * 60_000L

private val motivationalLines = listOf(
    "Stay with it. Every quiet minute helps you grow.",
    "Small focus, big growth.",
    "Your future self is cheering you on.",
    "Deep breath. One thing at a time.",
    "Great things grow slowly. Keep going.",
    "You're building something here.",
)

/**
 * Shown while a session runs, and ONLY this: the timer at the top, a plant that grows with the
 * session clock, and one motivational line. Everything is derived from the saved session start and
 * end, so leaving this screen (back button / system back) never touches the session, and coming
 * back through the floating Focus icon shows the same time and the same growth.
 */
@Composable
fun SessionScreen(
    state: FocusState,
    onBack: () -> Unit,
) {
    val now by produceState(System.currentTimeMillis(), state.focusActive) {
        value = System.currentTimeMillis()
        while (state.focusActive) {
            delay(250)
            value = System.currentTimeMillis()
        }
    }

    val limited = state.sessionEnd > 0L
    val elapsed = (now - state.sessionStart).coerceAtLeast(0L)
    val total = (state.sessionEnd - state.sessionStart).coerceAtLeast(1L)
    val progress = when {
        !state.focusActive -> 0f
        limited -> (elapsed.toFloat() / total).coerceIn(0f, 1f)
        else -> (elapsed.toFloat() / OPEN_ENDED_GROW_MS).coerceIn(0f, 1f)
    }
    val timeText = if (limited) formatClock((state.sessionEnd - now).coerceAtLeast(0L)) else formatClock(elapsed)
    // A new line every 30 seconds of the session.
    val line = motivationalLines[((elapsed / 30_000L) % motivationalLines.size).toInt()]

    Box(Modifier.fillMaxSize()) {
        FocusBackground(Modifier.matchParentSize(), immersive = true)

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back to home", onBack)
            }

            Spacer(Modifier.height(4.dp))
            Text(
                timeText,
                style = TextStyle(
                    fontFamily = PoppinsFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (timeText.length > 5) 52.sp else 64.sp,
                    letterSpacing = 1.sp,
                    fontFeatureSettings = "tnum"
                ),
                color = Color.White,
                textAlign = TextAlign.Center,
                maxLines = 1
            )

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                PlantView(
                    growth = state.plantGrowth,
                    active = state.focusActive,
                    progress = progress,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(400.dp)
                )
            }

            AnimatedContent(
                targetState = line,
                transitionSpec = { fadeIn(tween(700)) togetherWith fadeOut(tween(500)) },
                label = "motivation"
            ) { text ->
                Text(
                    text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color(0xFFC9C2E6),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(36.dp))
        }
    }
}
