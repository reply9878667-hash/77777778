package com.focusmode.app.data

import android.content.Context
import com.focusmode.app.data.online.FirebaseGateway
import com.focusmode.app.data.online.OnlineException
import org.json.JSONArray
import org.json.JSONObject

/**
 * One saved spot of a video: the time, and the topic / heading the person typed for it.
 * [at] is when it was last changed and [deleted] marks a removed bookmark that is kept for a while, so that a delete made on one
 * phone also reaches the other phones of the same account (see [BookmarkRules.merge]).
 */
data class Bookmark(val id: Long, val seconds: Int, val title: String, val at: Long = id, val deleted: Boolean = false)

/** Pure rules (no Android), so they can be tested on the JVM. */
object BookmarkRules {
    const val MAX_PER_VIDEO = 200
    const val MAX_TITLE = 120
    /** A deleted bookmark is remembered this long (so every phone hears about the delete), then forgotten. */
    const val TOMBSTONE_MS = 30L * 24 * 3600 * 1000
    /** The text saved on the server for one video must stay under the database rule's limit. */
    const val MAX_JSON_CHARS = 60_000
    private val VIDEO_KEY = Regex("^[A-Za-z0-9_-]{11}$")

    /** Only real YouTube videos are kept on the server (the own player is the only place with bookmarks). */
    fun syncable(videoKey: String) = VIDEO_KEY.matches(videoKey)

    /** Seconds -> "12:34" or "1:02:34". */
    fun time(seconds: Int): String {
        val s = seconds.coerceAtLeast(0)
        val h = s / 3600
        val m = s % 3600 / 60
        val x = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, x) else "%d:%02d".format(m, x)
    }

    /** What is saved when the person leaves the box empty: the time itself. */
    fun cleanTitle(raw: String, seconds: Int): String {
        val t = raw.trim().replace(Regex("\\s+"), " ").take(MAX_TITLE)
        return t.ifEmpty { "Bookmark at " + time(seconds) }
    }

    /** What the person sees: not deleted, sorted by time. */
    fun visible(all: List<Bookmark>): List<Bookmark> = all.filter { !it.deleted }.sortedBy { it.seconds }

    /** Adds a bookmark to the full list. A second bookmark at the same second replaces the old one. */
    fun add(all: List<Bookmark>, seconds: Int, rawTitle: String, id: Long): List<Bookmark> {
        val sec = seconds.coerceAtLeast(0)
        val b = Bookmark(id, sec, cleanTitle(rawTitle, sec), at = id)
        val replaced = all.map { if (!it.deleted && it.seconds == sec) it.copy(deleted = true, at = id) else it }
        val live = replaced.filter { !it.deleted }
        val capped = if (live.size >= MAX_PER_VIDEO) {
            // The earliest-made ones go first.
            val drop = live.sortedBy { it.id }.take(live.size - MAX_PER_VIDEO + 1).map { it.id }.toSet()
            replaced.map { if (it.id in drop) it.copy(deleted = true, at = id) else it }
        } else replaced
        return capped + b
    }

    fun remove(all: List<Bookmark>, id: Long, now: Long): List<Bookmark> =
        all.map { if (it.id == id && !it.deleted) it.copy(deleted = true, at = now) else it }

    /** Two copies of the same video's list (this phone, the server) become one: per bookmark the newer change wins. */
    fun merge(a: List<Bookmark>, b: List<Bookmark>, now: Long): List<Bookmark> {
        val byId = LinkedHashMap<Long, Bookmark>()
        for (x in a + b) {
            val old = byId[x.id]
            byId[x.id] = when {
                old == null -> x
                x.at > old.at -> x
                x.at < old.at -> old
                x.deleted -> x // same moment: a delete wins
                else -> old
            }
        }
        val kept = byId.values.filter { !it.deleted || now - it.at < TOMBSTONE_MS }
        // One live bookmark per second (two phones may have made one at the same second): the newer stays.
        val live = kept.filter { !it.deleted }.groupBy { it.seconds }.values.map { g -> g.maxByOrNull { it.at }!! }
        val dead = kept.filter { it.deleted }
        val liveIds = live.map { it.id }.toSet()
        val dupes = kept.filter { !it.deleted && it.id !in liveIds }.map { it.copy(deleted = true) }
        return (live + dead + dupes).sortedBy { it.seconds }
    }

    fun toJson(all: List<Bookmark>): String {
        val a = JSONArray()
        for (b in all) {
            val o = JSONObject().put("id", b.id).put("s", b.seconds).put("t", b.title).put("a", b.at)
            if (b.deleted) o.put("d", 1)
            a.put(o)
        }
        return a.toString()
    }

    fun fromJson(json: String?): List<Bookmark> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val a = JSONArray(json)
            (0 until a.length()).mapNotNull { i ->
                val o = a.optJSONObject(i) ?: return@mapNotNull null
                val id = o.optLong("id")
                Bookmark(id, o.optInt("s").coerceAtLeast(0), o.optString("t").take(MAX_TITLE), o.optLong("a", id), o.optInt("d") == 1)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

/** Bookmarks of every video, kept on the phone (and copied to the account by [LectureBookmarkRemote]). One list per video. */
class LectureBookmarkStore private constructor(context: Context) {
    private val prefs = context.getSharedPreferences("lecture_bookmarks", Context.MODE_PRIVATE)

    private fun key(video: String) = "bm_" + video.hashCode()

    /** Everything stored for the video, deleted ones included (needed for the sync). */
    @Synchronized fun raw(video: String): List<Bookmark> = BookmarkRules.fromJson(prefs.getString(key(video), null))

    @Synchronized private fun put(video: String, all: List<Bookmark>) {
        prefs.edit().putString(key(video), BookmarkRules.toJson(all)).apply()
    }

    /** What the person sees. */
    fun list(video: String): List<Bookmark> = BookmarkRules.visible(raw(video))

    @Synchronized fun add(video: String, seconds: Int, title: String): List<Bookmark> {
        val next = BookmarkRules.add(raw(video), seconds, title, System.currentTimeMillis())
        put(video, next)
        return BookmarkRules.visible(next)
    }

    @Synchronized fun remove(video: String, id: Long): List<Bookmark> {
        val next = BookmarkRules.remove(raw(video), id, System.currentTimeMillis())
        put(video, next)
        return BookmarkRules.visible(next)
    }

    /** Joins what the server sent with what is here, keeps the result and returns it (full list). */
    @Synchronized fun mergeWith(video: String, other: List<Bookmark>): List<Bookmark> {
        val merged = BookmarkRules.merge(raw(video), other, System.currentTimeMillis())
        put(video, merged)
        return merged
    }

    companion object {
        @Volatile private var instance: LectureBookmarkStore? = null

        fun get(context: Context): LectureBookmarkStore =
            instance ?: synchronized(this) {
                instance ?: LectureBookmarkStore(context.applicationContext).also { instance = it }
            }
    }
}

/**
 * Keeps one video's bookmarks on the server at users/{uid}/bookmarks/{videoId} (only the owner can read or write it:
 * firebase/database.rules.json). Same connection, REST fallback and retries as the settings backup.
 */
class LectureBookmarkRemote(context: Context) {

    private val appContext = context.applicationContext

    /**
     * Downloads the server's copy, joins it with this phone's copy, uploads the result when the server's copy was missing
     * something, and returns the joined list. Throws when there is no internet or no login (the phone's copy is untouched then).
     */
    suspend fun sync(uid: String, video: String, store: LectureBookmarkStore): List<Bookmark> {
        if (!BookmarkRules.syncable(video)) return store.raw(video)
        if (FirebaseGateway.uid(appContext) != uid) {
            throw OnlineException(OnlineException.Kind.AUTH, "This account is no longer signed in.")
        }
        val path = "users/$uid/bookmarks/$video"
        val node = FirebaseGateway.readNode(appContext, path)
        val remote = BookmarkRules.fromJson(node?.optString("data"))
        val merged = store.mergeWith(video, remote)
        if (merged.isEmpty() && node == null) return merged
        if (merged.toSet() != remote.toSet()) {
            val json = BookmarkRules.toJson(merged)
            if (json.length > BookmarkRules.MAX_JSON_CHARS) {
                throw OnlineException(OnlineException.Kind.OTHER, "Too many bookmarks for this video.")
            }
            FirebaseGateway.setNode(
                appContext, path,
                JSONObject().put("v", 1).put("updatedAt", System.currentTimeMillis()).put("data", json)
            )
        }
        return merged
    }
}
