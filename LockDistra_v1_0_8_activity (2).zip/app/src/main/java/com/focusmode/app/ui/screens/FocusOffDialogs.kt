package com.focusmode.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.LockState
import com.focusmode.app.data.online.OnlineManager
import com.focusmode.app.data.online.OnlineState
import com.focusmode.app.data.online.UnlockUi
import com.focusmode.app.ui.LockController
import com.focusmode.app.ui.online.OnlineUnlockPanel
import com.focusmode.app.ui.theme.FocusTheme

/**
 * "Password" OFF method: the existing App lock check (same wrong-try counting and lockout as everywhere
 * else). [onApproved] runs once the PIN / password was right.
 */
@Composable
fun FocusOffPasswordDialog(
    lock: LockState,
    controller: LockController,
    onApproved: () -> Unit,
    onDismiss: () -> Unit,
) {
    VerifyDialog(
        title = "Turn off Focus Mode",
        text = "Focus Mode is set to turn OFF with your password. Enter your current PIN / password to end it.",
        lock = lock,
        controller = controller,
        onVerified = onApproved,
        onDismiss = onDismiss,
    )
}

/**
 * "Online Approval" OFF method: the existing request to the trusted phone. [onApproved] runs once, when
 * the trusted phone approved this dialog's own request. Rejected / expired / failed leave Focus Mode ON.
 */
@Composable
fun FocusOffOnlineDialog(
    manager: OnlineManager,
    online: OnlineState,
    onApproved: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    val ui by manager.unlockUi.collectAsStateWithLifecycle()
    var done by remember { mutableStateOf(false) }

    // Start clean (a leftover answer of an earlier request must never count), and withdraw a request that is
    // still waiting when the dialog closes.
    LaunchedEffect(Unit) { manager.resetUnlock() }
    DisposableEffect(Unit) { onDispose { manager.cancelUnlock() } }

    LaunchedEffect(ui) {
        if (ui is UnlockUi.Approved && !done) {
            done = true
            onApproved()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Turn off Focus Mode", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Focus Mode is set to turn OFF only after your trusted phone approves.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OnlineUnlockPanel(manager = manager, online = online, showRecovery = false, forFocusOff = true)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}
