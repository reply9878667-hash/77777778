package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** What the UI may know about the lock. Never contains the PIN, a hash or the recovery code. */
data class LockState(
    val enabled: Boolean = false,
    val type: LockType = LockType.PIN,
    val biometric: Boolean = false,
    /** Seconds the app may stay in the background before it locks again. 0 = at once. */
    val autoLockSeconds: Int = 0,
    val hasRecovery: Boolean = false,
)

/**
 * Stores the app lock credential for LockDistra's own screens (dashboard, settings, emergency
 * limits). It protects nothing else on the phone.
 *
 *  - The PIN / password is never stored. Only a PBKDF2-HMAC-SHA256 hash with its own random salt.
 *  - That hash is then encrypted with a key that lives in the Android Keystore and can't be
 *    exported, so copying the preferences file off the phone is not enough to try guesses offline.
 *  - The recovery code (80 random bits) is stored as a salted hash only.
 *  - Data sits in normal credential-protected storage (not the device-protected storage the
 *    session uses), so it is unreadable until the phone is unlocked after a restart.
 *  - Wrong tries are counted on disk. From the 5th the app pauses 30 s, 1 min, 5 min, 15 min, 1 h.
 *    The pause survives closing the app and a restart.
 */
class LockStore private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences = appContext.getSharedPreferences("app_lock", Context.MODE_PRIVATE)

    // "Lock again after leaving the app" applies to every unlock method (PIN, Online approval,
    // Both), so it is not kept with the PIN data and is not wiped when the PIN lock is turned off.
    private val settings: SharedPreferences = appContext.getSharedPreferences("app_lock_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(read())
    val state: StateFlow<LockState> = _state.asStateFlow()

    private val lock = Any()

    private fun read() = LockState(
        enabled = prefs.getBoolean(K_ENABLED, false) && prefs.contains(K_HASH),
        type = if (prefs.getString(K_TYPE, "pin") == "password") LockType.PASSWORD else LockType.PIN,
        biometric = prefs.getBoolean(K_BIO, false),
        autoLockSeconds = settings.getInt(K_AUTO, prefs.getInt(K_AUTO, 0)).takeIf { it in LockRules.AUTO_LOCK_CHOICES } ?: 0,
        hasRecovery = prefs.contains(K_REC_HASH),
    )

    private fun publish() {
        _state.value = read()
    }

    fun current(): LockState = read()

    // ---- Checking -----------------------------------------------------------------------------

    /** Milliseconds a PIN / password check is still paused for, or 0. */
    fun lockoutRemainingMs(): Long = remaining(P_PIN)

    fun recoveryLockoutRemainingMs(): Long = remaining(P_REC)

    /** Checks the PIN / password. Slow on purpose (PBKDF2): call it off the main thread. */
    fun verify(secret: String): VerifyResult = synchronized(lock) {
        val wait = remaining(P_PIN)
        if (wait > 0) return VerifyResult.LockedOut(wait)
        val stored = readHash() ?: return VerifyResult.Unreadable
        val salt = runCatching { Credentials.unb64(prefs.getString(K_SALT, "") ?: "") }.getOrNull()
            ?: return VerifyResult.Unreadable
        val iterations = prefs.getInt(K_ITER, Credentials.ITERATIONS)
        val ok = Credentials.equal(Credentials.hash(secret, salt, iterations), stored)
        if (ok) {
            clearFailures(P_PIN)
            VerifyResult.Ok
        } else {
            registerFailure(P_PIN)
        }
    }

    /** Checks a recovery code without changing anything else. */
    fun checkRecovery(code: String): VerifyResult = synchronized(lock) {
        val wait = remaining(P_REC)
        if (wait > 0) return VerifyResult.LockedOut(wait)
        val saltText = prefs.getString(K_REC_SALT, null) ?: return VerifyResult.Unreadable
        val hashText = prefs.getString(K_REC_HASH, null) ?: return VerifyResult.Unreadable
        val normalized = Credentials.normalizeRecovery(code)
        if (normalized.length != Credentials.RECOVERY_LENGTH) return registerFailure(P_REC)
        val expected = runCatching { Credentials.unb64(hashText) }.getOrNull() ?: return VerifyResult.Unreadable
        val salt = runCatching { Credentials.unb64(saltText) }.getOrNull() ?: return VerifyResult.Unreadable
        val ok = Credentials.equal(Credentials.hash(normalized, salt), expected)
        if (ok) {
            clearFailures(P_REC)
            VerifyResult.Ok
        } else {
            registerFailure(P_REC)
        }
    }

    // ---- Changing -----------------------------------------------------------------------------

    /** Turns the lock on. Returns the recovery code, shown to the person once. */
    fun enable(type: LockType, secret: String): String = synchronized(lock) {
        writeCredential(type, secret)
        val code = writeNewRecovery()
        prefs.edit()
            .putBoolean(K_ENABLED, true)
            .putBoolean(K_BIO, false)
            .apply()
        clearFailures(P_PIN)
        clearFailures(P_REC)
        publish()
        code
    }

    /** New PIN / password, same recovery code. The caller has already checked the old one. */
    fun change(type: LockType, secret: String) = synchronized(lock) {
        writeCredential(type, secret)
        clearFailures(P_PIN)
        publish()
    }

    /** Sets a new PIN / password after the recovery code checked out, then issues a fresh code. */
    fun resetWithRecovery(code: String, type: LockType, secret: String): String? = synchronized(lock) {
        // Re-check without counting a failure twice; the caller already passed checkRecovery().
        val saltText = prefs.getString(K_REC_SALT, null) ?: return null
        val hashText = prefs.getString(K_REC_HASH, null) ?: return null
        val normalized = Credentials.normalizeRecovery(code)
        val expected = runCatching { Credentials.unb64(hashText) }.getOrNull() ?: return null
        val salt = runCatching { Credentials.unb64(saltText) }.getOrNull() ?: return null
        if (!Credentials.equal(Credentials.hash(normalized, salt), expected)) return null
        writeCredential(type, secret)
        val fresh = writeNewRecovery() // a used code is never valid again
        prefs.edit().putBoolean(K_ENABLED, true).apply()
        clearFailures(P_PIN)
        clearFailures(P_REC)
        publish()
        fresh
    }

    /** Replaces the recovery code. The caller has already checked the PIN / password. */
    fun newRecoveryCode(): String = synchronized(lock) {
        val code = writeNewRecovery()
        publish()
        code
    }

    fun disable() = synchronized(lock) {
        prefs.edit().clear().apply()
        publish()
    }

    fun setBiometric(on: Boolean) {
        prefs.edit().putBoolean(K_BIO, on && prefs.getBoolean(K_ENABLED, false)).apply()
        publish()
    }

    fun setAutoLockSeconds(seconds: Int) {
        if (seconds !in LockRules.AUTO_LOCK_CHOICES) return
        settings.edit().putInt(K_AUTO, seconds).apply()
        publish()
    }

    // ---- Internals ----------------------------------------------------------------------------

    private fun writeCredential(type: LockType, secret: String) {
        val salt = Credentials.newSalt()
        val hash = Credentials.hash(secret, salt)
        prefs.edit()
            .putString(K_TYPE, if (type == LockType.PASSWORD) "password" else "pin")
            .putString(K_SALT, Credentials.b64(salt))
            .putInt(K_ITER, Credentials.ITERATIONS)
            .putString(K_HASH, KeyWrap.wrap(hash))
            .apply()
    }

    private fun writeNewRecovery(): String {
        val code = Credentials.newRecoveryCode()
        val salt = Credentials.newSalt()
        val hash = Credentials.hash(Credentials.normalizeRecovery(code), salt)
        prefs.edit()
            .putString(K_REC_SALT, Credentials.b64(salt))
            .putString(K_REC_HASH, Credentials.b64(hash))
            .apply()
        return code
    }

    private fun readHash(): ByteArray? {
        val text = prefs.getString(K_HASH, null) ?: return null
        return KeyWrap.unwrap(text)
    }

    // ---- Wrong-try counting that survives restarts ----------------------------------------------

    private fun bootCount(): Int =
        runCatching { Settings.Global.getInt(appContext.contentResolver, Settings.Global.BOOT_COUNT, -1) }
            .getOrDefault(-1)

    private fun registerFailure(p: String): VerifyResult.Wrong {
        val failures = prefs.getInt("$p.fails", 0) + 1
        val pause = LockRules.lockoutMs(failures)
        val editor = prefs.edit().putInt("$p.fails", failures)
        if (pause > 0) {
            editor.putLong("$p.untilWall", System.currentTimeMillis() + pause)
                .putLong("$p.untilElapsed", SystemClock.elapsedRealtime() + pause)
                .putInt("$p.boot", bootCount())
        }
        editor.apply()
        return VerifyResult.Wrong(failures, pause)
    }

    private fun clearFailures(p: String) {
        prefs.edit()
            .remove("$p.fails").remove("$p.untilWall").remove("$p.untilElapsed").remove("$p.boot")
            .apply()
    }

    /**
     * Within one boot the monotonic clock is used, so changing the date and time on the phone
     * does not shorten a pause. After a restart the wall clock is all there is.
     */
    private fun remaining(p: String): Long {
        val wall = prefs.getLong("$p.untilWall", 0L)
        if (wall == 0L) return 0L
        val sameBoot = prefs.getInt("$p.boot", -2) == bootCount() && bootCount() != -1
        val left = if (sameBoot) {
            prefs.getLong("$p.untilElapsed", 0L) - SystemClock.elapsedRealtime()
        } else {
            wall - System.currentTimeMillis()
        }
        return left.coerceIn(0L, LockRules.MAX_LOCKOUT_MS)
    }

    // ---- Keystore wrapping ----------------------------------------------------------------------

    /** AES-GCM with a non-exportable Keystore key. Falls back to "p:" (plain hash) if the Keystore fails. */
    private object KeyWrap {
        private const val ALIAS = "focusmode_applock_v1"
        private const val PROVIDER = "AndroidKeyStore"

        private fun key(): SecretKey {
            val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
            (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
            gen.init(
                KeyGenParameterSpec.Builder(
                    ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            return gen.generateKey()
        }

        fun wrap(plain: ByteArray): String = try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val ct = cipher.doFinal(plain)
            "k:" + Credentials.b64(cipher.iv) + ":" + Credentials.b64(ct)
        } catch (_: Exception) {
            "p:" + Credentials.b64(plain)
        }

        /** Null when the value can't be read back (key gone, data damaged). */
        fun unwrap(text: String): ByteArray? = try {
            when {
                text.startsWith("p:") -> Credentials.unb64(text.removePrefix("p:"))
                text.startsWith("k:") -> {
                    val parts = text.removePrefix("k:").split(':')
                    val iv = Credentials.unb64(parts[0])
                    val ct = Credentials.unb64(parts[1])
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
                    cipher.doFinal(ct)
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private const val K_ENABLED = "enabled"
        private const val K_TYPE = "type"
        private const val K_SALT = "salt"
        private const val K_HASH = "hash"
        private const val K_ITER = "iter"
        private const val K_REC_SALT = "rec_salt"
        private const val K_REC_HASH = "rec_hash"
        private const val K_BIO = "biometric"
        private const val K_AUTO = "auto_lock_s"

        private const val P_PIN = "pin"
        private const val P_REC = "rec"

        @Volatile private var instance: LockStore? = null

        fun get(context: Context): LockStore =
            instance ?: synchronized(this) {
                instance ?: LockStore(context).also { instance = it }
            }
    }
}
