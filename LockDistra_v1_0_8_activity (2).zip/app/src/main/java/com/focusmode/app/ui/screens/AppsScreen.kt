package com.focusmode.app.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AppInfo
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material3.TextButton
import com.focusmode.app.data.AppLimit
import com.focusmode.app.data.ContentPolicy
import com.focusmode.app.data.ContentState
import com.focusmode.app.data.EmergencyState
import com.focusmode.app.data.LimitEmergency
import com.focusmode.app.data.LimitsState
import com.focusmode.app.data.ShortFormCatalog
import com.focusmode.app.ui.formatMinutes
import com.focusmode.app.data.AppRepository
import com.focusmode.app.data.BedtimeState
import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.KeywordState
import com.focusmode.app.data.WebsiteCatalog
import com.focusmode.app.data.WebsiteEdits
import com.focusmode.app.data.WebsiteLimitState
import com.focusmode.app.data.WebsitePolicy
import com.focusmode.app.data.WebsiteRules
import com.focusmode.app.data.WebsiteState
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.AppListSkeleton
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.staggeredEntrance
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.theme.FocusTheme

@Composable
internal fun AppsScreen(
    state: FocusState,
    apps: List<AppInfo>,
    loaded: Boolean,
    limits: LimitsState,
    emergency: EmergencyState,
    content: ContentState,
    websites: WebsiteState,
    bedtime: BedtimeState,
    permissions: PermissionStatus,
    onBedtimeEnabled: (Boolean) -> Unit,
    onBedtimeTimes: (startMin: Int, endMin: Int) -> Boolean,
    onBedtimeApps: (Set<String>) -> Unit,
    onWebsiteBlocking: (pkg: String, on: Boolean) -> Unit,
    onAddWebsite: (pkg: String, raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onEditWebsite: (pkg: String, old: String, raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onRemoveWebsite: (pkg: String, domain: String) -> Unit,
    onWebsiteEnabled: (pkg: String, domain: String, on: Boolean) -> Unit,
    onBack: () -> Unit,
    onToggleApp: (pkg: String, blocked: Boolean) -> Unit,
    onToggleShorts: (Boolean) -> Unit,
    onSaveLimit: (AppLimit) -> Unit,
    onRemoveLimit: (String) -> Unit,
    onSaveLimitEmergency: (key: String, enabled: Boolean, attempts: Int, minutes: Int) -> Unit,
    onEmergencyEnabled: (pkg: String, on: Boolean) -> Unit,
    onEmergencyAttempts: (pkg: String, attempts: Int) -> Unit,
    onFeatureChange: (id: String, on: Boolean) -> Unit,
    onOpenFeatures: () -> Unit,
    onOpenEducation: () -> Unit,
    /**
     * Set when this screen edits a Focus Profile instead of the phone's own settings. The data and callbacks then
     * come from the profile; the cards that are global-only (Adult content, Bedtime, Inside apps, educational
     * channels, Emergency access) are left out.
     */
    profileName: String? = null,
    /** Several sites at once for the phone-wide "Blocked websites" list. Null (a Focus Profile) = that list is not shown. */
    onAddWebsites: ((pkg: String, raw: String, subdomains: Boolean) -> WebsiteEdits.Bulk)? = null,
    /** Keyword Blocking card (phone-wide only). Null (a Focus Profile) = the card is not shown. */
    keywords: KeywordState = KeywordState(),
    keywordActions: KeywordActions? = null,
    /** Website Usage Limits card (phone-wide only). Null (a Focus Profile) = the card is not shown. */
    websiteLimits: WebsiteLimitState = WebsiteLimitState(),
    websiteLimitActions: WebsiteLimitActions? = null,
) {
    val c = FocusTheme.colors
    val forProfile = profileName != null
    var query by remember { mutableStateOf("") }
    val locked = state.focusActive
    // "Allow app restriction changes" switched off: nothing can be edited during the session.
    val frozen = !state.canEditApps || ContentPolicy.frozen(state)

    // The slide-up panel (one app at a time) and the limit editor it can open.
    var optionsFor by remember { mutableStateOf<String?>(null) }
    var editingLimit by remember { mutableStateOf<AppLimit?>(null) }
    var editingIsNew by remember { mutableStateOf(false) }

    val youtubeBlocked = AppRepository.YOUTUBE in state.blocked
    val selectedCount = apps.count { it.packageName in state.blocked && !it.isSettings } +
        if (state.blockShorts && !youtubeBlocked) 1 else 0

    val limitByPkg = remember(limits) { limits.limits.associateBy { it.pkg } }

    val q = query.trim()
    val filtered = if (q.isEmpty()) emptyList() else apps.filter { !it.isSettings && it.label.contains(q, ignoreCase = true) }
    val youtube = apps.firstOrNull { it.packageName == AppRepository.YOUTUBE }
    val popular = apps.filter { it.popular && it.packageName != AppRepository.YOUTUBE }
    val rest = apps.filter { !it.popular && !it.isSettings }

    // Switching an app ON opens its panel, so Emergency access is set up right where it is needed.
    val toggleBlock: (String, Boolean) -> Unit = { pkg, on ->
        onToggleApp(pkg, on)
        if (on) optionsFor = pkg
    }

    @Composable
    fun Group(app: AppInfo, modifier: Modifier = Modifier) {
        val blocked = app.packageName in state.blocked
        Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            AppRow(
                app = app,
                blocked = blocked,
                limit = limitByPkg[app.packageName],
                locked = locked,
                frozen = frozen,
                onToggle = toggleBlock,
                onOpen = { optionsFor = app.packageName },
            )
            // Individual in-app features (Reels, Status, Spotlight) sit directly under their app.
            ShortFormCatalog.forPackage(app.packageName)
                .filter { it.featureId != null }
                .forEach { form ->
                    val id = form.featureId!!
                    val on = content.featureOn(id)
                    FeatureRow(
                        title = "${form.appName} ${form.title} blocking",
                        note = if (blocked) "Included while ${form.appName} is blocked"
                        else "Keep ${form.appName}, block only ${form.title}",
                        checked = on || blocked,
                        enabled = !frozen && !blocked && !(locked && on),
                        onToggle = { onFeatureChange(id, it) }
                    )
                }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .staggeredEntrance(0)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Column {
                Text("Blocking", style = MaterialTheme.typography.titleLarge)
                Text(
                    "$selectedCount app${if (selectedCount == 1) "" else "s"} blocked" +
                        if (forProfile) " in $profileName, saved automatically" else ", saved automatically",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        SearchField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.staggeredEntrance(1).padding(horizontal = 20.dp)
        )

        if (!loaded) {
            AppListSkeleton(rows = 9)
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (locked) {
                item {
                    FocusCard(padding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Lock, null, tint = c.warning, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.size(12.dp))
                            Text(
                                if (frozen) "App restrictions are locked right now. Unlock changes, or wait for the session to end, to edit them."
                                else "A session is running. You can add apps, but they stay blocked until it ends.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }

            // One "Blocking" section: every kind of blocking is its own card, all in the same place.
            // Hidden while searching, so the search shows only apps.
            if (q.isEmpty()) {
                item(key = "blocking_label") { SectionLabel("Blocking") }
                item(key = "website_blocking") {
                    WebsiteBlockingCard(
                        websites = websites,
                        apps = apps,
                        onOpenApp = { optionsFor = it },
                        modifier = Modifier.padding(bottom = 2.dp),
                        own = if (forProfile || onAddWebsites == null) null else OwnSites(
                            canTighten = WebsitePolicy.canTighten(state),
                            canLoosen = WebsitePolicy.canLoosen(state),
                            onAddMany = { raw, sub -> onAddWebsites(WebsiteCatalog.GENERAL, raw, sub) },
                            onAdd = { raw, sub -> onAddWebsite(WebsiteCatalog.GENERAL, raw, sub) },
                            onEdit = { old, raw, sub -> onEditWebsite(WebsiteCatalog.GENERAL, old, raw, sub) },
                            onRemove = { onRemoveWebsite(WebsiteCatalog.GENERAL, it) },
                            onEnabled = { d, on -> onWebsiteEnabled(WebsiteCatalog.GENERAL, d, on) },
                        )
                    )
                }
                // Website Usage Limits sit right under Website Blocking: same category, separate card and controls.
                if (!forProfile && websiteLimitActions != null) {
                    item(key = "website_limits") {
                        WebsiteLimitsCard(
                            state = websiteLimits,
                            actions = websiteLimitActions,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
                if (!forProfile && keywordActions != null) {
                    item(key = "keyword_blocking") {
                        KeywordBlockingCard(
                            state = keywords,
                            actions = keywordActions,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
                if (!forProfile) {
                    item(key = "adult_blocking") {
                        AdultBlockingCard(modifier = Modifier.padding(bottom = 2.dp))
                    }
                    item(key = "bedtime") {
                        BedtimeCard(
                            bedtime = bedtime,
                            apps = apps,
                            permissions = permissions,
                            onEnabled = onBedtimeEnabled,
                            onTimes = onBedtimeTimes,
                            onApps = onBedtimeApps,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
                item(key = "apps_label") { SectionLabel("App blocking", Modifier.padding(top = 12.dp)) }
            }

            if (q.isNotEmpty()) {
                if (filtered.isEmpty()) {
                    item {
                        Text(
                            "No apps match \"$q\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = c.muted,
                            modifier = Modifier.padding(top = 24.dp).fillMaxWidth()
                        )
                    }
                } else {
                    items(filtered, key = { it.packageName }) { app -> Group(app, Modifier.animateItem()) }
                }
            } else {
                // YouTube: its three options are always visible, one under the other.
                // Shorts only exists inside YouTube, so nothing is shown without the app.
                if (youtube != null) {
                    item { SectionLabel("YouTube") }
                    item(key = "yt_group") {
                        Column(Modifier.animateItem(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            AppRow(
                                app = youtube,
                                blocked = youtubeBlocked,
                                limit = null,
                                title = "Complete YouTube App Blocking",
                                locked = locked,
                                frozen = frozen,
                                onToggle = toggleBlock,
                                onOpen = { optionsFor = youtube.packageName },
                            )
                            val ytLimit = limitByPkg[youtube.packageName]
                            LimitLineRow(
                                title = "YouTube Usage Limit",
                                note = if (ytLimit == null) "Set a daily time limit" else "${formatMinutes(ytLimit.limitMin)} a day",
                                active = ytLimit != null,
                                enabled = !frozen,
                                onClick = {
                                    editingLimit = ytLimit ?: AppLimit(youtube.packageName, limitMin = 30, remindMin = 5)
                                    editingIsNew = ytLimit == null
                                }
                            )
                            ShortsRow(
                                title = "YouTube Shorts Blocking",
                                checked = state.blockShorts || youtubeBlocked,
                                enabled = !frozen && !youtubeBlocked && !(locked && state.blockShorts),
                                note = if (youtubeBlocked) "Included while YouTube is blocked"
                                else "Keep YouTube, block only the Shorts player",
                                onToggle = onToggleShorts
                            )
                            if (!forProfile) {
                                TextButton(onClick = onOpenEducation) {
                                    Text(
                                        if (content.channels.isEmpty() && !content.autoDetect) "Educational Shorts: choose channels that stay allowed"
                                        else "Educational Shorts: ${content.channels.size} channel${if (content.channels.size == 1) "" else "s"} allowed" +
                                            if (content.autoDetect) ", auto-detect on" else "",
                                        color = c.accent
                                    )
                                }
                            }
                        }
                    }
                }

                if (!forProfile) item(key = "inside_apps") {
                    FocusCard(
                        onClick = onOpenFeatures,
                        modifier = Modifier.padding(top = 4.dp),
                        padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Inside apps", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    if (content.activeFeatureCount == 0) "Close only the distracting parts of an app"
                                    else "${content.activeFeatureCount} section${if (content.activeFeatureCount == 1) "" else "s"} blocked",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = c.muted
                                )
                            }
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.muted)
                        }
                    }
                }

                if (popular.isNotEmpty()) {
                    item { SectionLabel("Popular distractions", Modifier.padding(top = 12.dp)) }
                    items(popular, key = { it.packageName }) { app -> Group(app, Modifier.animateItem()) }
                }
                if (rest.isNotEmpty()) {
                    item { SectionLabel("All apps", Modifier.padding(top = 12.dp)) }
                    items(rest, key = { it.packageName }) { app -> Group(app, Modifier.animateItem()) }
                }
            }
        }
    }

    optionsFor?.let { pkg ->
        val app = apps.firstOrNull { it.packageName == pkg }
        if (app != null) {
            val isYoutube = pkg == AppRepository.YOUTUBE
            AppRestrictionSheet(
                app = app,
                blocked = pkg in state.blocked,
                limit = limitByPkg[pkg],
                emergency = emergency.app(pkg),
                frozen = frozen,
                running = locked,
                shortsChecked = if (isYoutube) state.blockShorts else null,
                shortsEnabled = !frozen && !(locked && state.blockShorts),
                websiteOffered = WebsiteCatalog.supports(pkg) || websites.isOn(pkg) || websites.rulesFor(pkg).isNotEmpty(),
                websiteOn = websites.isOn(pkg),
                websiteRules = websites.rulesFor(pkg),
                canTighten = WebsitePolicy.canTighten(state),
                canLoosen = WebsitePolicy.canLoosen(state),
                onWebsiteBlocking = { onWebsiteBlocking(pkg, it) },
                onAddWebsite = { raw, sub -> onAddWebsite(pkg, raw, sub) },
                onEditWebsite = { old, raw, sub -> onEditWebsite(pkg, old, raw, sub) },
                onRemoveWebsite = { onRemoveWebsite(pkg, it) },
                onWebsiteEnabled = { d, on -> onWebsiteEnabled(pkg, d, on) },
                onBlockedChange = { onToggleApp(pkg, it) },
                onShortsChange = onToggleShorts,
                onEditLimit = {
                    val existing = limitByPkg[pkg]
                    optionsFor = null
                    editingLimit = existing ?: AppLimit(pkg, limitMin = 30, remindMin = 5)
                    editingIsNew = existing == null
                },
                onEmergencyEnabled = { onEmergencyEnabled(pkg, it) },
                onEmergencyAttempts = { onEmergencyAttempts(pkg, it) },
                showEmergency = !forProfile,
                onDismiss = { optionsFor = null },
            )
        } else {
            optionsFor = null
        }
    }

    editingLimit?.let { limit ->
        LimitEditorSheet(
            limit = limit,
            label = apps.firstOrNull { it.packageName == limit.pkg }?.label ?: limit.pkg,
            isNew = editingIsNew,
            emergency = limits.emergency[limit.pkg] ?: LimitEmergency(),
            onSave = { saved, e ->
                onSaveLimit(saved)
                onSaveLimitEmergency(saved.pkg, e.enabled, e.attempts, e.minutes)
                editingLimit = null
            },
            onRemove = { onRemoveLimit(limit.pkg); editingLimit = null },
            onDismiss = { editingLimit = null }
        )
    }
}

@Composable
internal fun SearchField(value: String, onValueChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val c = FocusTheme.colors
    Row(
        modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(c.card)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = c.muted, modifier = Modifier.size(20.dp))
        Spacer(Modifier.size(10.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text("Search apps", style = MaterialTheme.typography.bodyLarge, color = c.muted)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = TextStyle(color = c.text, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun AppRow(
    app: AppInfo,
    blocked: Boolean,
    limit: AppLimit?,
    locked: Boolean,
    frozen: Boolean,
    onToggle: (String, Boolean) -> Unit,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier,
    title: String = app.label,
) {
    val c = FocusTheme.colors
    val statusColor by animateColorAsState(if (blocked) c.accent else c.muted, tween(250), label = "appStatus")
    FocusCard(
        modifier = modifier,
        onClick = onOpen,
        padding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        highlight = blocked
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app.packageName, 44.dp)
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2
                )
                Text(
                    buildString {
                        append(if (blocked) "Blocked" else "Allowed")
                        if (limit != null) append(" \u2022 ${formatMinutes(limit.limitMin)} a day")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = statusColor
                )
            }
            FocusSwitch(
                checked = blocked,
                // Once a session has started, an app that is already blocked stays blocked.
                enabled = !frozen && !(locked && blocked),
                onCheckedChange = { onToggle(app.packageName, it) }
            )
        }
    }
}

/** A tappable row for one option that is not a switch (the usage limit). */
@Composable
private fun LimitLineRow(
    title: String,
    note: String,
    active: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val c = FocusTheme.colors
    FocusCard(
        onClick = if (enabled) onClick else null,
        padding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        highlight = active
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Schedule, null, tint = c.accent, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(note, style = MaterialTheme.typography.bodySmall, color = if (active) c.accent else c.muted)
            }
            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.muted)
        }
    }
}

@Composable
private fun ShortsRow(
    title: String,
    checked: Boolean,
    enabled: Boolean,
    note: String,
    onToggle: (Boolean) -> Unit,
) {
    FeatureRow(title = title, note = note, checked = checked, enabled = enabled, onToggle = onToggle)
}

/** One in-app feature (Shorts, Reels, Status ...) with its own switch. */
@Composable
private fun FeatureRow(
    title: String,
    note: String,
    checked: Boolean,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
) {
    val c = FocusTheme.colors
    FocusCard(padding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.PlayCircle, null, tint = c.accent, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(note, style = MaterialTheme.typography.bodySmall, color = c.muted)
            }
            FocusSwitch(
                checked = checked,
                enabled = enabled,
                onCheckedChange = onToggle
            )
        }
    }
}
