package com.focusmode.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import kotlinx.coroutines.delay
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.focusmode.app.ui.theme.FocusTheme
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

// ---- Toggle ---------------------------------------------------------------------------------

/**
 * Animated switch: the thumb springs across, the track colour fades and the thumb grows slightly
 * while pressed. Drop-in replacement for the Material switch (same checked / onCheckedChange).
 */
@Composable
fun FocusSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val c = FocusTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val travel by animateFloatAsState(
        if (checked) 1f else 0f,
        spring(dampingRatio = 0.62f, stiffness = 520f),
        label = "switchTravel"
    )
    val track by animateColorAsState(if (checked) c.accent else c.cardHigh, tween(220), label = "switchTrack")
    val thumb by animateColorAsState(if (checked) c.onAccent else c.muted, tween(220), label = "switchThumb")
    val edge by animateColorAsState(if (checked) Color.Transparent else c.stroke, tween(220), label = "switchEdge")
    val thumbSize by animateDpAsState(if (pressed) 28.dp else 24.dp, tween(120), label = "switchThumbSize")

    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.5f)
            .size(width = 52.dp, height = 32.dp)
            .clip(CircleShape)
            .background(track)
            .border(1.dp, edge, CircleShape)
            .toggleable(
                value = checked,
                enabled = enabled,
                role = Role.Switch,
                interactionSource = interaction,
                indication = null,
                onValueChange = onCheckedChange
            ),
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            Modifier
                .offset(x = 4.dp + 20.dp * travel - (thumbSize - 24.dp) / 2)
                .size(thumbSize)
                .clip(CircleShape)
                .background(thumb)
        )
    }
}

// ---- Entrance -------------------------------------------------------------------------------

/** Fades and lifts the element in once, [index] * [stepMs] after it first appears. */
fun Modifier.staggeredEntrance(index: Int, stepMs: Int = 70): Modifier = composed {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(
            1f,
            tween(durationMillis = 480, delayMillis = index.coerceAtLeast(0) * stepMs, easing = FastOutSlowInEasing)
        )
    }
    graphicsLayer {
        alpha = progress.value
        translationY = (1f - progress.value) * 26.dp.toPx()
    }
}


// ---- First-open shimmer (Home) --------------------------------------------------------------

/**
 * State of the "loading" shimmer that Home plays once each time the app is opened: a light band travels from left
 * to right over placeholder shapes (like a video loading skeleton), then the real cards fade in. No sliding.
 * [armed] turns true when the splash screen is gone (the shimmer starts then); [done] when it has finished, so
 * switching tabs or coming back to Home never plays it again.
 */
object HomeShimmer {
    /** One sweep of the light band, in milliseconds. */
    const val SWEEP_MS = 650
    /** How many sweeps are shown before the content appears. */
    const val SWEEPS = 2
    private const val FADE_MS = 260

    var armed by mutableStateOf(false)
    var done by mutableStateOf(false)

    /** A fresh app open: play the shimmer again. */
    fun reset() { armed = false; done = false }

    internal const val TOTAL_MS = SWEEP_MS * SWEEPS
    internal const val FADE = FADE_MS
}

/**
 * Shows a shimmering placeholder of this element's size for [HomeShimmer.SWEEPS] sweeps, then fades the real content
 * in. The layout is measured with the content, so nothing jumps. Does nothing once [HomeShimmer.done].
 */
fun Modifier.shimmerReveal(corner: Dp = 24.dp): Modifier = composed {
    val skip = remember { HomeShimmer.done }
    if (skip) return@composed Modifier
    val c = FocusTheme.colors
    val transition = rememberInfiniteTransition(label = "homeShimmer")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(HomeShimmer.SWEEP_MS, easing = LinearEasing)),
        label = "homeShimmerShift"
    )
    val reveal = remember { Animatable(0f) }
    val armed = HomeShimmer.armed
    LaunchedEffect(armed) {
        if (armed) {
            delay(HomeShimmer.TOTAL_MS.toLong())
            reveal.animateTo(1f, tween(HomeShimmer.FADE, easing = FastOutSlowInEasing))
        }
    }
    drawWithContent {
        val r = reveal.value
        if (r < 1f) {
            val w = size.width
            val startX = -0.7f * w + 2.4f * w * shift
            val brush = Brush.linearGradient(
                colors = listOf(c.cardHigh, lerp(c.cardHigh, Color.White, if (c.isDark) 0.16f else 0.55f), c.cardHigh),
                start = Offset(startX, 0f),
                end = Offset(startX + 0.7f * w, size.height * 0.2f)
            )
            drawRoundRect(brush, cornerRadius = CornerRadius(corner.toPx()), alpha = 1f - r)
        }
        if (r > 0f) {
            drawIntoCanvas { canvas ->
                val paint = Paint().apply { alpha = r }
                canvas.saveLayer(Rect(0f, 0f, size.width, size.height), paint)
                drawContent()
                canvas.restore()
            }
        }
    }
}

// ---- Progress -------------------------------------------------------------------------------

/** Rounded progress bar whose fill glides to each new value. [progress] is 0..1. */
@Composable
fun FocusProgressBar(
    progress: Float,
    modifier: Modifier = Modifier,
    color: Color = FocusTheme.colors.accent,
    height: Dp = 6.dp,
) {
    val c = FocusTheme.colors
    val shown by animateFloatAsState(
        progress.coerceIn(0f, 1f),
        tween(700, easing = FastOutSlowInEasing),
        label = "progressBar"
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(CircleShape)
            .background(c.ringTrack)
    ) {
        Box(
            Modifier
                .fillMaxWidth(shown)
                .fillMaxHeight()
                .clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.7f), color)))
        )
    }
}

// ---- Loading skeleton -----------------------------------------------------------------------

/** Shimmering placeholder rows shown while the installed-app list loads. */
@Composable
fun AppListSkeleton(modifier: Modifier = Modifier, rows: Int = 8) {
    val c = FocusTheme.colors
    val transition = rememberInfiniteTransition(label = "skeleton")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
        label = "shimmerShift"
    )
    val start = -500f + 1700f * shift
    val brush = Brush.linearGradient(
        colors = listOf(c.cardHigh, c.stroke, c.cardHigh),
        start = Offset(start, 0f),
        end = Offset(start + 500f, 0f)
    )
    Column(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        repeat(rows) { index ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .staggeredEntrance(index, 50)
                    .clip(RoundedCornerShape(28.dp))
                    .background(c.card)
                    .border(1.dp, c.stroke, RoundedCornerShape(28.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(brush))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth(0.55f).height(13.dp).clip(CircleShape).background(brush))
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.fillMaxWidth(0.3f).height(10.dp).clip(CircleShape).background(brush))
                }
                Box(Modifier.size(width = 52.dp, height = 32.dp).clip(CircleShape).background(brush))
            }
        }
    }
}

// ---- Animated background --------------------------------------------------------------------

private class Particle(val x: Float, val phase: Float, val radius: Float)

/**
 * Slowly drifting colour glows with a few soft particles rising through them. Used behind the
 * splash screen and the blocked-app screen. Purely decorative, drawn in one Canvas.
 */
@Composable
fun AuroraBackground(
    modifier: Modifier = Modifier,
    base: Color,
    glowA: Color,
    glowB: Color,
    intensity: Float = 1f,
) {
    val transition = rememberInfiniteTransition(label = "aurora")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(20000, easing = LinearEasing)),
        label = "drift"
    )
    val rise by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(18000, easing = LinearEasing)),
        label = "rise"
    )
    val particles = remember {
        val random = Random(11)
        List(18) { Particle(random.nextFloat(), random.nextFloat(), 1.5f + random.nextFloat() * 2.5f) }
    }

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(base, lerp(base, glowA, 0.10f * intensity))))

        fun glow(color: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(color.copy(alpha = 0.30f * intensity), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = r
                ),
                radius = r,
                center = Offset(cx, cy)
            )
        }
        glow(glowA, w * (0.22f + 0.12f * sin(drift)), h * (0.16f + 0.05f * cos(drift)), w * 0.8f)
        glow(glowB, w * (0.85f + 0.10f * cos(drift)), h * (0.60f + 0.06f * sin(drift)), w * 0.75f)
        glow(glowA, w * (0.35f + 0.10f * sin(drift + 2f)), h * 1.02f, w * 0.65f)

        particles.forEach { p ->
            val t = (rise + p.phase) % 1f
            val x = w * p.x + sin(drift * 2f + p.phase * 6.2831855f) * 14.dp.toPx()
            val y = h * (1.05f - 1.1f * t)
            val a = sin(PI.toFloat() * t) * 0.45f * intensity
            drawCircle(glowA.copy(alpha = a), radius = p.radius.dp.toPx(), center = Offset(x, y))
        }
    }
}


// ---- Full-screen app background -------------------------------------------------------------

/**
 * The app-wide background: the same deep-purple night palette as the home hero, painted edge to
 * edge (behind the status and navigation bars too) so no screen shows a flat square of colour.
 * Light theme gets a soft lavender version of the same gradient.
 */
@Composable
fun FocusBackground(modifier: Modifier = Modifier, immersive: Boolean = false) {
    val c = FocusTheme.colors
    val dark = c.isDark || immersive
    val stars = remember {
        val random = Random(5)
        List(26) { Triple(random.nextFloat(), random.nextFloat() * 0.6f, 0.4f + random.nextFloat() * 0.6f) }
    }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        if (dark) {
            drawRect(
                Brush.verticalGradient(
                    listOf(Color(0xFF1B0F40), Color(0xFF110A2C), Color(0xFF090514)),
                )
            )
            fun glow(color: Color, cx: Float, cy: Float, r: Float, a: Float) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(color.copy(alpha = a), Color.Transparent), center = Offset(cx, cy), radius = r),
                    radius = r,
                    center = Offset(cx, cy)
                )
            }
            glow(Color(0xFF7C3AED), w * 0.85f, h * 0.10f, w * 0.9f, if (immersive) 0.30f else 0.22f)
            glow(Color(0xFFC026D3), w * 0.05f, h * 0.78f, w * 0.85f, if (immersive) 0.18f else 0.10f)
            stars.forEach { (x, y, a) ->
                drawCircle(Color.White.copy(alpha = 0.35f * a), radius = 1.2.dp.toPx(), center = Offset(w * x, h * y))
            }
        } else {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFEBE0FF), Color(0xFFF4EEFF), c.background)))
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFFC9A8FF).copy(alpha = 0.45f), Color.Transparent),
                    center = Offset(w * 0.85f, h * 0.08f), radius = w * 0.9f
                ),
                radius = w * 0.9f, center = Offset(w * 0.85f, h * 0.08f)
            )
        }
    }
}
