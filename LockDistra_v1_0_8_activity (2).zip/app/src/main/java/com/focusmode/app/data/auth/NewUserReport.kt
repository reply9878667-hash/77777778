package com.focusmode.app.data.auth

import android.content.Context
import com.focusmode.app.data.online.FirebaseGateway

/**
 * Tells the Worker once, right after a brand-new account is created, so the admin gets a notification.
 * Event driven: nothing is polled. If the phone is offline at that moment the "pending" mark stays and the next
 * app start sends it (the Worker ignores a second report for the same account).
 */
object NewUserReport {
    private const val PREFS = "rewire_new_user_report"
    private const val KEY = "pending_uid"

    fun markPending(context: Context, uid: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, uid).apply()
    }

    /** Sends the pending report (if any). Never throws. */
    suspend fun flush(context: Context) {
        runCatching {
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val uid = prefs.getString(KEY, null) ?: return
            if (FirebaseGateway.reportNewUser(context.applicationContext, uid)) prefs.edit().remove(KEY).apply()
        }
    }
}
