package com.focusmode.app.ui

import android.app.Activity
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal

/**
 * Fingerprint / face check through Android's own prompt (framework API, no extra library).
 * Needs Android 10 or newer and a strong biometric already enrolled in the phone's settings.
 * On older phones, or with nothing enrolled, the PIN / password is the only way in.
 */
object Biometrics {

    fun isAvailable(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        val manager = context.getSystemService(BiometricManager::class.java) ?: return false
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
                    BiometricManager.BIOMETRIC_SUCCESS
            } else {
                @Suppress("DEPRECATION")
                manager.canAuthenticate() == BiometricManager.BIOMETRIC_SUCCESS
            }
        } catch (_: Exception) {
            false
        }
    }

    /** Shows the system prompt. Returns a signal the caller can cancel, or null if it can't be shown. */
    fun prompt(
        activity: Activity,
        title: String,
        subtitle: String,
        cancelText: String,
        onSuccess: () -> Unit,
        onFailure: () -> Unit,
    ): CancellationSignal? {
        if (Build.VERSION.SDK_INT < 28) return null
        return try {
            val executor = activity.mainExecutor
            val builder = BiometricPrompt.Builder(activity)
                .setTitle(title)
                .setSubtitle(subtitle)
                .setNegativeButton(cancelText, executor) { _, _ -> onFailure() }
            if (Build.VERSION.SDK_INT >= 30) {
                builder.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            }
            val signal = CancellationSignal()
            builder.build().authenticate(
                signal,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        onFailure()
                    }
                }
            )
            signal
        } catch (_: Exception) {
            null
        }
    }
}
