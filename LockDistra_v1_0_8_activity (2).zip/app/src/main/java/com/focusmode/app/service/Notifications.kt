package com.focusmode.app.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focusmode.app.MainActivity
import com.focusmode.app.R
import com.focusmode.app.data.FocusProfileRuntime
import com.focusmode.app.data.FocusProfileStore
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.IntentGuard
import com.focusmode.app.data.PomodoroPhase
import com.focusmode.app.data.PomodoroRules
import com.focusmode.app.data.PomodoroState
import com.focusmode.app.data.PomodoroStore
import com.focusmode.app.data.StudyCheckInRules

object Notifications {

    const val CH_STATUS = "focus_status"
    const val CH_PLANT = "plant_reminder_v1"
    const val CH_LIMITS = "usage_limits_v1"
    const val CH_POMODORO = "pomodoro_v1"
    const val CH_STUDY = "study_checkin_v1"
    const val CH_STUDY_NEW = "study_new_videos_v1"
    const val CH_LECTURE = "lecture_back_v1"

    /** "App unlocked for N min": a normal heads-up (the status channel is silent, so this message was easy to miss). */
    const val CH_UNLOCK = "app_unlocked_v1"

    /** Background service line (Adult Content filter): lowest priority, nothing shown on the lock screen. */
    const val CH_QUIET = "background_service_v1"

    const val ID_STATUS = 1001
    const val ID_PLANT = 1002
    const val ID_BOOT = 1003
    const val ID_APP_UNLOCKED = 1004
    const val ID_POMODORO = 1005
    const val ID_STUDY = 1006
    const val ID_LECTURE = 1007
    private const val ID_STUDY_NEW_BASE = 30_000
    private const val ID_LIMIT_BASE = 20_000

    fun ensureChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Focus status", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shows while LockDistra is on so blocking can keep running."
                setShowBadge(false)
            }
        )

        // Neutral name on purpose: this is the line Android makes the filter show, and it must not say what it does.
        nm.createNotificationChannel(
            NotificationChannel(CH_QUIET, "Background service", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Keeps a background service of the app running."
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
                setSound(null, null)
                enableVibration(false)
                enableLights(false)
            }
        )

        nm.createNotificationChannel(
            NotificationChannel(CH_LIMITS, "App time limits", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Heads-up before an app reaches its daily time limit."
                setShowBadge(false)
            }
        )

        // Break started / break over: a normal heads-up with the phone's default notification sound.
        nm.createNotificationChannel(
            NotificationChannel(CH_POMODORO, "Pomodoro breaks", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Tells you when a Pomodoro break starts and when focus time is back."
                setSound(
                    android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                enableVibration(true)
                setShowBadge(false)
            }
        )

        val chime = Uri.parse("android.resource://${context.packageName}/${R.raw.plant_chime}")

        // Study Check-In: a heads-up over whatever is on screen, with the same short chime as the plant reminder.
        nm.createNotificationChannel(
            NotificationChannel(CH_STUDY, "Study check-ins", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Asks \"Are You Still Studying?\" at the interval you chose while Focus Mode is on."
                setSound(
                    chime,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                enableVibration(true)
                setShowBadge(false)
            }
        )

        // New video from a channel the person follows in Study (a normal notification with the video's picture).
        nm.createNotificationChannel(
            NotificationChannel(CH_STUDY_NEW, "New study videos", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "A new video from a channel you follow in the Study tab."
                setShowBadge(false)
            }
        )

        // "Back to Focus": the person left the lecture, the timer is standing still.
        nm.createNotificationChannel(
            NotificationChannel(CH_LECTURE, "Back to Focus", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Tells you that your lecture and the Focus timer are paused. Tap it to continue the lecture."
                setSound(
                    android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                enableVibration(true)
                setShowBadge(false)
            }
        )

        nm.createNotificationChannel(
            NotificationChannel(CH_UNLOCK, "App unlocked", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Tells you which app was unlocked and for how long."
                setSound(
                    android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                enableVibration(true)
                setShowBadge(false)
            }
        )

        nm.createNotificationChannel(
            NotificationChannel(CH_PLANT, "Plant reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "A short chime at each reminder interval. Tap it to help your plant grow."
                setSound(
                    chime,
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                enableVibration(false)
                setShowBadge(false)
            }
        )
    }

    private fun openApp(context: Context, requestCode: Int, configure: Intent.() -> Unit = {}): PendingIntent {
        val intent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            // Proves to MainActivity that this intent came from LockDistra's own notification.
            putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(context))
            configure()
        }
        return PendingIntent.getActivity(
            context, requestCode, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    /** "3 apps blocked", counted from the selected Focus Profile when one controls the session. */
    private fun blockedText(context: Context, s: FocusState): String {
        val profile = FocusProfileRuntime.active(s, FocusProfileStore.get(context).state.value)
        val n = FocusProfileRuntime.blockedCount(s, profile)
        return "$n app${if (n == 1) "" else "s"} blocked"
    }

    /** The permanent notification shown while LockDistra is on. */
    fun buildStatus(context: Context): Notification {
        val s = FocusStore.get(context).current()
        val now = System.currentTimeMillis()
        val pomodoro = PomodoroStore.get(context).current()
        if (!s.focusActive && pomodoro.phase == PomodoroPhase.BREAK) return buildBreakStatus(context, pomodoro)

        val builder = NotificationCompat.Builder(context, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp(context, 0))
            // If it is swiped away (Android 14+ allows that) it is shown again at once.
            .setDeleteIntent(FocusEngine.dismissIntent(context))
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setSubText(blockedText(context, s))

        when {
            s.emergencyActive(now) -> builder
                .setContentTitle("Emergency access")
                .setContentText("Blocking resumes automatically")
                .setWhen(s.emergencyUntil)
                .setChronometerCountDown(true)

            // The timer is tied to the lecture: it stands still while the lecture is not playing.
            s.sessionEnd > 0L && LectureTimerGuard.frozen -> builder
                .setUsesChronometer(false)
                .setShowWhen(false)
                .setContentTitle("Timer paused")
                .setContentText("Play your lecture to continue")

            s.sessionEnd > 0L -> builder
                .setContentTitle(if (pomodoro.phase == PomodoroPhase.FOCUS) "Focus time \u2022 round ${pomodoro.round}" else "LockDistra is on")
                .setContentText("Time remaining")
                .setWhen(s.sessionEnd)
                .setChronometerCountDown(true)

            else -> builder
                .setContentTitle("LockDistra is on")
                .setContentText("Time focused")
                .setWhen(s.sessionStart)
                .setChronometerCountDown(false)
        }

        // The shortcut only exists while Emergency access is allowed for this session.
        if (!s.emergencyActive(now) && s.canUseEmergency) {
            builder.addAction(
                0, "Emergency access",
                openApp(context, 1) { putExtra(MainActivity.EXTRA_OPEN_EMERGENCY, true) }
            )
        }
        return builder.build()
    }

    /** The permanent notification during a Pomodoro break: no restrictions, counting down to focus time. */
    private fun buildBreakStatus(context: Context, p: PomodoroState): Notification {
        val left = PomodoroEngine.breakLeftMs(context, p)
        return NotificationCompat.Builder(context, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp(context, 0))
            .setDeleteIntent(FocusEngine.dismissIntent(context))
            .setContentTitle("Break time")
            .setContentText("Focus restrictions are paused. Focus time starts again by itself.")
            .setSubText("Pomodoro")
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setWhen(System.currentTimeMillis() + left)
            .build()
    }

    /** "Break started": the focus round is over and every Focus restriction is off until the break ends. */
    @SuppressLint("MissingPermission")
    fun postBreakStarted(context: Context, focusMin: Int, breakMin: Int) =
        postPomodoro(context, "Break time", PomodoroRules.breakStartedText(focusMin, breakMin))

    /** "Break finished": restrictions are active again and the next focus round has begun. */
    @SuppressLint("MissingPermission")
    fun postBreakOver(context: Context, breakMin: Int) =
        postPomodoro(context, "Back to focus", PomodoroRules.breakOverText(breakMin))

    /** Only when the app is not on screen; inside the app the change is already visible. */
    @SuppressLint("MissingPermission")
    private fun postPomodoro(context: Context, title: String, text: String) {
        if (AppVisibility.visible) {
            cancelPomodoro(context)
            return
        }
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(context, CH_POMODORO)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setDefaults(NotificationCompat.DEFAULT_SOUND or NotificationCompat.DEFAULT_VIBRATE)
            .setContentIntent(openApp(context, 400))
            .build()
        // Same id for both messages: the newest one replaces the older one.
        nmc.notify(ID_POMODORO, n)
    }

    fun cancelPomodoro(context: Context) {
        NotificationManagerCompat.from(context).cancel(ID_POMODORO)
    }

    fun refreshStatus(context: Context) {
        val s = FocusStore.get(context).current()
        if (!s.focusActive && !PomodoroStore.get(context).current().let { it.running && it.phase == PomodoroPhase.BREAK }) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(ID_STATUS, buildStatus(context))
    }

    /** Interval check-in. The button confirms; tapping the body opens the app, where any tap confirms. */
    @SuppressLint("MissingPermission")
    fun postPlantReminder(context: Context, token: Long) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        // Only the tap of this exact reminder may grow the plant (see GrowPolicy).
        FocusStore.get(context).notePostedReminder(token)
        val tap = openApp(context, 100) {
            action = MainActivity.ACTION_GROW
            putExtra(MainActivity.EXTRA_GROW_TOKEN, token)
        }
        // The button answers right from the notification, without opening the app.
        val confirm = PendingIntent.getBroadcast(
            context, 101,
            Intent(context, CheckInReceiver::class.java).putExtra(CheckInReceiver.EXTRA_TOKEN, token),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CH_PLANT)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("Are you studying?")
            .setContentText("Tap \"Yes, I'm studying\" and your plant grows.")
            .addAction(0, "Yes, I'm studying", confirm)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(tap)
            .build()
        nmc.notify(ID_PLANT, n)
    }

    /**
     * True when a study check-in would really be seen: notifications are allowed for LockDistra and the "Study
     * check-ins" channel was not switched off. When this is false the check-in is skipped, never counted as missed.
     */
    fun canShowStudyCheckIn(context: Context): Boolean {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false
        ensureChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = nm.getNotificationChannel(CH_STUDY) ?: return true
        return ch.importance != NotificationManager.IMPORTANCE_NONE
    }

    /**
     * "Are You Still Studying?" with an "I'm Studying" button. A heads-up notification, so it appears on top of the
     * current app without opening or leaving anything; it takes itself away when the minute is up. Returns false if
     * Android refused to show it (the caller then drops the check-in instead of calling it missed).
     */
    @SuppressLint("MissingPermission")
    fun postStudyCheckIn(context: Context, seq: Long): Boolean {
        val nmc = NotificationManagerCompat.from(context)
        if (!canShowStudyCheckIn(context)) return false
        val confirm = PendingIntent.getBroadcast(
            context, 110,
            Intent(context, StudyCheckInReceiver::class.java).putExtra(StudyCheckInReceiver.EXTRA_SEQ, seq),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CH_STUDY)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(StudyCheckInRules.PROMPT_TITLE)
            .setContentText(StudyCheckInRules.PROMPT_TEXT)
            .addAction(0, StudyCheckInRules.PROMPT_BUTTON, confirm)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setTimeoutAfter(StudyCheckInRules.RESPONSE_WINDOW_MS)
            // Tapping the text opens LockDistra; only the button confirms.
            .setContentIntent(openApp(context, 111))
            .build()
        return try {
            nmc.notify(ID_STUDY, n)
            true
        } catch (_: SecurityException) {
            false
        }
    }

    fun cancelStudyCheckIn(context: Context) {
        NotificationManagerCompat.from(context).cancel(ID_STUDY)
    }

    /** "Back to Focus": posted once when the person leaves the lecture; tapping it opens the lecture again and it plays on. */
    @SuppressLint("MissingPermission")
    fun postBackToFocus(context: Context, lectureUrl: String) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        val open = PendingIntent.getActivity(
            context, 3, com.focusmode.app.LectureActivity.launchIntent(context, lectureUrl),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CH_LECTURE)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("Back to Focus")
            .setContentText("Your lecture and the timer are paused. Tap to continue.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        nmc.notify(ID_LECTURE, n)
    }

    fun cancelBackToFocus(context: Context) {
        NotificationManagerCompat.from(context).cancel(ID_LECTURE)
    }

    @SuppressLint("MissingPermission")
    fun postSessionComplete(context: Context) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(context, CH_PLANT)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("Focus session complete")
            .setContentText("Apps are unblocked. Well done.")
            .setAutoCancel(true)
            .setContentIntent(openApp(context, 2))
            .build()
        nmc.notify(ID_PLANT + 1, n)
    }

    /** "Instagram: 5 minutes left today", posted once per app per day before its limit ends. */
    @SuppressLint("MissingPermission")
    fun postLimitReminder(context: Context, pkg: String, label: String, minutesLeft: Int) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        val left = if (minutesLeft <= 1) "Less than a minute" else "$minutesLeft minutes"
        val n = NotificationCompat.Builder(context, CH_LIMITS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("$label: time is almost up")
            .setContentText("$left left of today's limit.")
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openApp(context, 200) { putExtra(MainActivity.EXTRA_OPEN_LIMITS, true) })
            .build()
        nmc.notify(ID_LIMIT_BASE + (pkg.hashCode() and 0xFFFF), n)
    }

    /** A new video of a followed channel: channel name, video title and the picture, like a YouTube notification. */
    @SuppressLint("MissingPermission")
    fun postNewStudyVideo(context: Context, v: com.focusmode.app.data.StudyVideo) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        ensureChannels(context)
        com.focusmode.app.data.StudyStore.get(context).setPendingOpen(v)
        val picture = runCatching {
            val c = java.net.URL(v.thumbUrl).openConnection() as java.net.HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            try {
                if (c.responseCode == 200) android.graphics.BitmapFactory.decodeStream(c.inputStream) else null
            } finally {
                c.disconnect()
            }
        }.getOrNull()
        val b = NotificationCompat.Builder(context, CH_STUDY_NEW)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(v.channelTitle)
            .setContentText(v.title)
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_RECOMMENDATION)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(openApp(context, 40_000 + (v.id.hashCode() and 0xFFFF)) {
                putExtra(MainActivity.EXTRA_OPEN_STUDY, true)
                putExtra(MainActivity.EXTRA_STUDY_VIDEO_ID, v.id)
            })
        if (picture != null) {
            b.setLargeIcon(picture)
            b.setStyle(NotificationCompat.BigPictureStyle().bigPicture(picture).bigLargeIcon(null as android.graphics.Bitmap?).setSummaryText(v.title))
        } else {
            b.setStyle(NotificationCompat.BigTextStyle().bigText(v.title))
        }
        nmc.notify(ID_STUDY_NEW_BASE + (v.id.hashCode() and 0xFFFF), b.build())
    }

    /** Shown after a restart brought the session back, so nothing happens silently. */
    @SuppressLint("MissingPermission")
    fun postRestored(context: Context) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        val s = FocusStore.get(context).current()
        val now = System.currentTimeMillis()
        val text = if (s.sessionEnd > now) {
            val min = ((s.sessionEnd - now + 59_999L) / 60_000L).toInt()
            "$min min left. Blocking and app limits are active again."
        } else "Blocking and app limits are active again."
        val n = NotificationCompat.Builder(context, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("Focus session restored after restart")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openApp(context, 300))
            .build()
        nmc.notify(ID_BOOT, n)
    }

    /** Tells the person that their trusted phone gave them time in an app (they may have left the block screen). */
    @SuppressLint("MissingPermission")
    /** Tapping the "unlocked" notification opens the unlocked app itself. */
    private fun grantedAppIntent(context: Context, pkg: String?): PendingIntent? {
        if (pkg == null) return null
        val launch = context.packageManager.getLaunchIntentForPackage(pkg) ?: return null
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        return PendingIntent.getActivity(
            context, 311, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun minutesText(minutes: Int): String {
        val m = minutes.coerceAtLeast(1)
        val h = m / 60
        val r = m % 60
        return when {
            h == 0 -> "$m min"
            r == 0 -> "$h h"
            else -> "$h h $r min"
        }
    }

    /** The trusted phone gave extra time: "<app> unlocked for N min". */
    fun postAppUnlocked(context: Context, appName: String, minutes: Int, pkg: String? = null) {
        postUnlocked(
            context, appName, pkg,
            "$appName unlocked for ${minutesText(minutes)}",
            "Your trusted phone unlocked this app for ${minutesText(minutes)}. It closes again by itself.",
        )
    }

    /** The limit was raised after it was used up (PIN / password / approval): "<app> unlocked for N min". */
    fun postLimitRaised(context: Context, appName: String, minutesLeft: Int, pkg: String? = null) {
        postUnlocked(
            context, appName, pkg,
            "$appName unlocked for ${minutesText(minutesLeft)}",
            "The daily limit was changed. This app is open for ${minutesText(minutesLeft)} more today.",
        )
    }

    @SuppressLint("MissingPermission")
    private fun postUnlocked(context: Context, appName: String, pkg: String?, title: String, text: String) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        // The channel may not exist yet on a phone that has not run ensureChannels since this update.
        ensureChannels(context)
        val n = NotificationCompat.Builder(context, CH_UNLOCK)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setTimeoutAfter(5 * 60_000L)
            .setContentIntent(grantedAppIntent(context, pkg) ?: openApp(context, 310))
            .build()
        nmc.notify(ID_APP_UNLOCKED, n)
    }

    @SuppressLint("MissingPermission")
    fun postRestartEnded(context: Context) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(context, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("Focus session ended by the restart")
            .setContentText("\"Restore after restart\" is off in Settings.")
            .setAutoCancel(true)
            .setContentIntent(openApp(context, 301))
            .build()
        nmc.notify(ID_BOOT, n)
    }

    @SuppressLint("MissingPermission")
    fun postNeedsAccessibility(context: Context) {
        val nmc = NotificationManagerCompat.from(context)
        if (!nmc.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(context, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("LockDistra needs Accessibility")
            .setContentText("The restart switched it off. Tap to turn it on so blocking and limits can work.")
            .setAutoCancel(true)
            .setContentIntent(openApp(context, 302))
            .build()
        nmc.notify(ID_BOOT + 1, n)
    }

    fun cancelReminder(context: Context) {
        NotificationManagerCompat.from(context).cancel(ID_PLANT)
    }
}
