package com.focusmode.app.data

import kotlin.math.abs

/** A wall-clock reading paired with the monotonic clock and the boot it was taken in. */
data class ClockAnchor(val wall: Long, val elapsed: Long, val boot: Int)

/**
 * Detects a changed phone clock during a session. The wall clock can be set by the user, the
 * monotonic clock (elapsedRealtime) cannot, so comparing the two shows a manual jump. Android-free
 * so it runs in plain JVM tests.
 */
object ClockGuard {
    /** Smaller differences are normal clock drift / network time corrections. */
    const val TOLERANCE_MS = 60_000L

    /** How often the anchor is renewed while nothing changed. */
    const val REFRESH_MS = 60_000L

    private fun sameBoot(a: ClockAnchor, elapsedNow: Long, bootNow: Int) =
        a.boot == bootNow && elapsedNow >= a.elapsed

    /**
     * How far the wall clock jumped since [anchor] (positive = moved forward). 0 when there is no
     * anchor, the phone restarted since (cannot be compared) or the difference is within tolerance.
     */
    fun jump(anchor: ClockAnchor?, wallNow: Long, elapsedNow: Long, bootNow: Int): Long {
        if (anchor == null || !sameBoot(anchor, elapsedNow, bootNow)) return 0L
        val expected = anchor.wall + (elapsedNow - anchor.elapsed)
        val diff = wallNow - expected
        return if (abs(diff) >= TOLERANCE_MS) diff else 0L
    }

    /** True when a new anchor should be saved (none yet, a restart, or the old one is a minute old). */
    fun shouldRefresh(anchor: ClockAnchor?, elapsedNow: Long, bootNow: Int): Boolean =
        anchor == null || !sameBoot(anchor, elapsedNow, bootNow) || elapsedNow - anchor.elapsed >= REFRESH_MS

    /** Moves a stored time by the clock [jump] so the time left stays the same. 0 stays 0 (= unset). */
    fun shifted(time: Long, jump: Long): Long = if (time == 0L) 0L else time + jump
}
