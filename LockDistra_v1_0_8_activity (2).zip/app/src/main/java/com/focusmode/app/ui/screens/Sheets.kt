package com.focusmode.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.FocusOffMethod
import com.focusmode.app.data.PreviewApp
import com.focusmode.app.data.StartPreview
import com.focusmode.app.data.StartPreviewRules
import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.formatMinutes
import com.focusmode.app.ui.theme.FocusTheme

private val presets = listOf(15, 25, 45, 60, 90, 120)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DurationSheet(
    initialMinutes: Int,
    hint: String? = null,
    /** True when "Allow turning LockDistra OFF" is off: a session with no end could never be left. */
    timeLimitRequired: Boolean = false,
    onStart: (minutes: Int) -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var minutes by remember { mutableIntStateOf(initialMinutes.coerceIn(5, 240)) }
    var noLimit by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("How long do you want to focus?", style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center)
            Spacer(Modifier.height(20.dp))

            AnimatedContent(
                targetState = if (noLimit) "No limit" else formatMinutes(minutes),
                transitionSpec = {
                    (slideInVertically(tween(220)) { it / 3 } + fadeIn(tween(220))) togetherWith
                        (slideOutVertically(tween(160)) { -it / 3 } + fadeOut(tween(160)))
                },
                label = "durationText"
            ) { text ->
                Text(text, style = MaterialTheme.typography.displayMedium, color = c.accent)
            }
            Spacer(Modifier.height(20.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                presets.forEach { preset ->
                    SoftChip(
                        text = formatMinutes(preset),
                        selected = !noLimit && minutes == preset,
                        onClick = { noLimit = false; minutes = preset }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Custom", style = MaterialTheme.typography.labelMedium, color = c.muted)
            Slider(
                value = minutes.toFloat(),
                onValueChange = { noLimit = false; minutes = it.toInt() },
                valueRange = 5f..240f,
                steps = 46,
                colors = SliderDefaults.colors(
                    thumbColor = c.accent,
                    activeTrackColor = c.accent,
                    inactiveTrackColor = c.ringTrack,
                    activeTickColor = c.accent,
                    inactiveTickColor = c.ringTrack,
                )
            )

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("No time limit", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (timeLimitRequired) "Needs a time limit while turning OFF is locked in Settings"
                        else "Stays on until you turn it off",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
                FocusSwitch(
                    checked = noLimit && !timeLimitRequired,
                    enabled = !timeLimitRequired,
                    onCheckedChange = { noLimit = it }
                )
            }

            if (hint != null) {
                Spacer(Modifier.height(12.dp))
                Text(
                    hint,
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(20.dp))
            PrimaryButton(
                text = "Start focus",
                icon = Icons.Rounded.PlayArrow,
                onClick = { onStart(if (noLimit && !timeLimitRequired) 0 else minutes) }
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

/** One app that Emergency access may open, with its attempts. */
data class EmergencyChoice(
    val pkg: String,
    val label: String,
    val remaining: Int,
    val limit: Int,
)

/**
 * Pick one app and how long to open it. Only apps switched on under Emergency apps appear, each
 * with its remaining attempts. Opening an app uses one attempt.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencySheet(
    choices: List<EmergencyChoice>,
    onPick: (pkg: String, minutes: Int) -> Unit,
    onManage: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var selected by remember { mutableStateOf<String?>(null) }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Emergency access", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                if (choices.isEmpty())
                    "No apps are set up for emergencies yet. Choose them under Emergency apps, ideally before a session starts."
                else
                    "Open one app for a few minutes. Every other app stays blocked, and each use counts against that app's limit.",
                style = MaterialTheme.typography.bodyMedium,
                color = c.muted,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(20.dp))

            choices.forEach { choice ->
                val usable = choice.remaining > 0
                FocusCard(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = if (usable) ({ selected = choice.pkg }) else null,
                    padding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    highlight = selected == choice.pkg
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(choice.pkg, 40.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(choice.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text(
                                if (usable) "${choice.remaining} of ${choice.limit} attempts left"
                                else "No attempts left",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (usable) c.accent else c.warning
                            )
                        }
                        if (selected == choice.pkg) {
                            Icon(Icons.Rounded.CheckCircle, null, tint = c.accent, modifier = Modifier.size(24.dp))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }

            if (choices.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (selected == null) "Choose an app, then how long" else "How long?",
                    style = MaterialTheme.typography.labelMedium,
                    color = c.muted
                )
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(1, 2, 3, 4, 5).forEach { m ->
                        FocusCard(
                            modifier = Modifier.weight(1f),
                            onClick = selected?.let { pkg -> { onPick(pkg, m) } },
                            padding = androidx.compose.foundation.layout.PaddingValues(vertical = 20.dp)
                        ) {
                            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    "$m",
                                    style = MaterialTheme.typography.displayMedium,
                                    color = if (selected == null) c.muted else c.accent
                                )
                                Text("minutes", style = MaterialTheme.typography.bodySmall, color = c.muted)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onManage) { Text("Emergency apps and limits", color = c.accent) }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionSheet(
    permissions: PermissionStatus,
    onGrantAccessibility: () -> Unit,
    onGrantNotifications: () -> Unit,
    onGrantUsage: () -> Unit,
    onContinue: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
        ) {
            Text("A few permissions first", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Android keeps these off by default. Here is exactly what each one is used for.",
                style = MaterialTheme.typography.bodyMedium,
                color = c.muted
            )
            Spacer(Modifier.height(20.dp))

            PermissionRow(
                title = "Accessibility service",
                tag = "Required",
                granted = permissions.accessibility,
                body = "Lets LockDistra see which app is on screen while a session is running, so it can cover blocked apps with the stay-focused screen. Inside apps you choose, it can also tell which section is open (for example YouTube Shorts and the channel name, or Instagram Reels). Screen text is only compared on the phone. Nothing is recorded or shared, and this app has no internet access.",
                hint = "Settings > Accessibility > Installed apps > LockDistra > turn on.",
                onGrant = onGrantAccessibility
            )
            Spacer(Modifier.height(12.dp))
            PermissionRow(
                title = "Notifications",
                tag = "Recommended",
                granted = permissions.notifications,
                body = "Shows the permanent status notification during a session and plays the plant reminder chime.",
                hint = null,
                onGrant = onGrantNotifications
            )
            Spacer(Modifier.height(12.dp))
            PermissionRow(
                title = "Usage access",
                tag = "Recommended",
                granted = permissions.usageAccess,
                body = "A backup way to find the app in front, so blocking stays reliable on phones that limit accessibility. It only reads which app was opened last.",
                hint = "Settings > Usage access > LockDistra > allow.",
                onGrant = onGrantUsage
            )

            Spacer(Modifier.height(24.dp))
            PrimaryButton(
                text = if (permissions.accessibility) "Continue" else "Accessibility is needed to continue",
                enabled = permissions.accessibility,
                onClick = onContinue
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
internal fun PermissionRow(
    title: String,
    tag: String,
    granted: Boolean,
    body: String,
    hint: String?,
    onGrant: () -> Unit,
) {
    val c = FocusTheme.colors
    FocusCard(padding = androidx.compose.foundation.layout.PaddingValues(18.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(tag, style = MaterialTheme.typography.labelMedium, color = if (tag == "Required") c.accent else c.muted)
                }
                if (granted) {
                    Icon(Icons.Rounded.CheckCircle, "Granted", tint = c.accent, modifier = Modifier.size(26.dp))
                } else {
                    SoftChip(text = "Allow", selected = true, onClick = onGrant)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(body, style = MaterialTheme.typography.bodySmall, color = c.muted)
            if (hint != null && !granted) {
                Spacer(Modifier.height(6.dp))
                Text(hint, style = MaterialTheme.typography.bodySmall, color = c.text)
            }
        }
    }
}

@Composable
fun ProfileDialog(
    currentName: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var name by remember { mutableStateOf(currentName) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Your profile", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column {
                Text("What should we call you?", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(24) },
                    singleLine = true,
                    placeholder = { Text("Your name") },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(name) }) { Text("Save", color = c.accent) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) }
        }
    )
}

@Composable
fun ConfirmStopDialog(onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = FocusTheme.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("End this session?", style = MaterialTheme.typography.titleLarge) },
        text = { Text("Your apps will be unblocked right away.") },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("End focus", color = c.warning) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Keep going", color = c.accent) }
        }
    )
}

/** Shown instead of the stop confirmation when "Allow turning LockDistra OFF" is switched off. */
@Composable
fun LockedStopDialog(endsInMs: Long, onDismiss: () -> Unit) {
    val c = FocusTheme.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("LockDistra is locked", style = MaterialTheme.typography.titleLarge) },
        text = {
            Text(
                "You switched off \"Allow turning LockDistra OFF\" for this session. " +
                    "It ends by itself when the timer finishes" +
                    (if (endsInMs > 0L) " (in ${com.focusmode.app.ui.formatClock(endsInMs)})." else ".")
            )
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Got it", color = c.accent) }
        }
    )
}

@Composable
fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = FocusTheme.colors.onAccent,
    checkedTrackColor = FocusTheme.colors.accent,
    uncheckedThumbColor = FocusTheme.colors.muted,
    uncheckedTrackColor = FocusTheme.colors.cardHigh,
    uncheckedBorderColor = FocusTheme.colors.stroke,
    disabledCheckedTrackColor = FocusTheme.colors.accent.copy(alpha = 0.45f),
    disabledCheckedThumbColor = FocusTheme.colors.onAccent.copy(alpha = 0.8f),
)


/**
 * Asked after the duration is chosen, before Focus Mode really starts: what will be blocked and how it can be
 * turned OFF again. [offMethod] is the method chosen in Settings; when it is not set up yet ([offError] is
 * not null) the start button is disabled and the text says what to set up.
 */
@Composable
fun ConfirmStartDialog(
    minutes: Int,
    preview: StartPreview,
    offMethod: FocusOffMethod,
    offError: String?,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    val length = if (minutes <= 0) "No time limit" else formatMinutes(minutes)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Ready to Start Focus Mode?", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Your selected Focus Profile restrictions will now become active. Selected applications, " +
                        "websites and games will remain blocked until Focus Mode is turned off using your selected method.",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (preview.isEmpty) {
                    Text("Nothing is selected to block yet.", style = MaterialTheme.typography.bodySmall)
                } else {
                    if (preview.appTotal > 0) {
                        PreviewGroup("Applications", preview.apps, preview.appTotal)
                    }
                    if (preview.gameTotal > 0) {
                        PreviewGroup("Games", preview.games, preview.gameTotal)
                    }
                    if (preview.siteTotal > 0) {
                        Text("Websites (${preview.siteTotal})", style = MaterialTheme.typography.labelMedium, color = c.text)
                        val more = StartPreviewRules.more(preview.siteTotal, preview.sites.size)
                        Text(
                            preview.sites.joinToString(", ") + (more?.let { "  $it" } ?: ""),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                Text(length, style = MaterialTheme.typography.bodySmall)
                Text(
                    "Focus Mode can be turned OFF using: ${offMethod.label}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.text
                )
                offError?.let {
                    Text(
                        "$it Set it up, or choose another method in Settings > Focus.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.warning
                    )
                }
            }
        },
        confirmButton = {
            TextButton(enabled = offError == null, onClick = onConfirm) {
                Text("Enable Focus Mode", color = if (offError == null) c.accent else c.muted)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) }
        }
    )
}

/** Up to a few icons with their names, then "+ N more". */
@Composable
internal fun PreviewGroup(title: String, items: List<PreviewApp>, total: Int) {
    val c = FocusTheme.colors
    Text("$title ($total)", style = MaterialTheme.typography.labelMedium, color = c.text)
    items.forEach { item ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(item.pkg, 28.dp)
            Spacer(Modifier.width(10.dp))
            Text(item.label, style = MaterialTheme.typography.bodyMedium, color = c.text, maxLines = 1)
        }
    }
    StartPreviewRules.more(total, items.size)?.let {
        Text(it, style = MaterialTheme.typography.bodySmall)
    }
}
