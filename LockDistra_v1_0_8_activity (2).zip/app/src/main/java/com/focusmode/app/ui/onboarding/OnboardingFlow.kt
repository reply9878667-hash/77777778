package com.focusmode.app.ui.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import com.focusmode.app.data.OnboardingAnswers
import com.focusmode.app.data.OnboardingDraft
import com.focusmode.app.data.OnboardingQuestions

/** The screens of the first-launch onboarding, in order. Part 2B appends its own steps here. */
enum class OnboardingStep {
    Welcome,   // Part 1
    Questions, // Part 2A: the seven questions
    Celebration, // Part 2D: "Awesome, <name>!" with the dancing mascot
}

private const val DRAFT_SAVE_DELAY_MS = 350L

private val AnswersSaver = Saver<OnboardingAnswers, ArrayList<String>>(
    save = { ArrayList(it.encode()) },
    restore = { OnboardingAnswers.decode(it) }
)

/**
 * Entry point of the first-launch onboarding, shown on top of the app.
 *
 * Welcome (Part 1) -> Question 1 ... Question 7 (Part 2A) -> Celebration (Part 2D) -> [onFinished].
 *
 * Back: question n goes to question n-1; question 1 goes back to the welcome screen (already
 * "played", so it shows its finished state at once); the celebration goes back to question 7.
 * Answers are held here, so they stay while the person moves back and forth and across rotation.
 *
 * @param onFinished called when the flow is over, right after [onQuestionsFinished]. AppEntry then moves on to the
 *   account screen (new visitor) or finishes a new account's own onboarding.
 * @param onQuestionsFinished the next-step hook: called once, with all seven answers, when Continue is
 *   pressed on the celebration screen and just before [onFinished]. AppEntry saves the answers on the
 *   phone with it (and marks the onboarding done in the same write). Account creation / login (a later part) can start from here.
 * @param initialDraft where an interrupted onboarding stopped (Task 3). The flow resumes there, with the answers
 *   given so far, instead of starting from the welcome screen.
 * @param onProgress called after every change with the current position and answers, so the host can keep a draft.
 * @param onHaveAccount when not null, the welcome screen offers "I already have an account" (Task 3): someone who
 *   already registered (new phone, reinstall) goes straight to login instead of answering the questions again.
 */
@Composable
fun OnboardingFlow(
    onFinished: () -> Unit,
    onQuestionsFinished: (OnboardingAnswers) -> Unit = {},
    initialDraft: OnboardingDraft? = null,
    onProgress: (OnboardingDraft) -> Unit = {},
    onHaveAccount: (() -> Unit)? = null,
) {
    var step by rememberSaveable {
        mutableStateOf(initialDraft?.step?.let { s -> OnboardingStep.entries.firstOrNull { it.name == s } } ?: OnboardingStep.Welcome)
    }
    var questionIndex by rememberSaveable {
        mutableIntStateOf((initialDraft?.questionIndex ?: 0).coerceIn(0, OnboardingQuestions.count - 1))
    }
    var answers by rememberSaveable(stateSaver = AnswersSaver) { mutableStateOf(initialDraft?.answers ?: OnboardingAnswers()) }
    // Once the person has left the welcome screen, coming back shows it finished (no replay).
    var welcomeSeen by rememberSaveable { mutableStateOf(initialDraft != null && initialDraft.step != OnboardingStep.Welcome.name) }

    // Keep the draft in step with the screen. (Welcome with no answers needs no draft; the Celebration is the
    // end: its Continue replaces the draft with the final answers.)
    // Debounced: typing a name changes `answers` on every key, and each save rewrites the preferences file.
    // Only the last change of a burst is written; leaving the flow cancels a write that is not due yet.
    LaunchedEffect(step, questionIndex, answers) {
        if (step != OnboardingStep.Welcome || !answers.isEmpty) {
            delay(DRAFT_SAVE_DELAY_MS)
            onProgress(OnboardingDraft(step.name, questionIndex, answers))
        }
    }

    val lastIndex = OnboardingQuestions.count - 1

    AnimatedContent(
        targetState = step,
        transitionSpec = {
            val forward = targetState.ordinal > initialState.ordinal
            val dir = if (forward) 1 else -1
            (slideInHorizontally(tween(350)) { it * dir / 4 } + fadeIn(tween(350)))
                .togetherWith(slideOutHorizontally(tween(300)) { -it * dir / 4 } + fadeOut(tween(250)))
        },
        label = "onboardingStep",
    ) { current ->
        when (current) {
            OnboardingStep.Welcome -> WelcomeScreen(
                onContinue = {
                    welcomeSeen = true
                    questionIndex = 0
                    step = OnboardingStep.Questions
                },
                skipIntro = welcomeSeen,
                onHaveAccount = onHaveAccount,
            )

            OnboardingStep.Questions -> QuestionsScreen(
                index = questionIndex,
                answers = answers,
                onAnswersChange = { answers = it },
                onBack = {
                    if (questionIndex > 0) questionIndex-- else step = OnboardingStep.Welcome
                },
                onNext = {
                    if (questionIndex < lastIndex) {
                        questionIndex++
                    } else {
                        step = OnboardingStep.Celebration
                    }
                },
            )

            OnboardingStep.Celebration -> CelebrationScreen(
                name = answers.name,
                onBack = { step = OnboardingStep.Questions }, // question 7, answers intact
                onContinue = {
                    onQuestionsFinished(answers)
                    onFinished()
                },
            )
        }
    }
}
