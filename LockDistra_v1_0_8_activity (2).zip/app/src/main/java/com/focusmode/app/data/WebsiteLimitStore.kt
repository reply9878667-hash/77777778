package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.time.LocalDate

/**
 * Saved Website Usage Limits and today's usage per site. Like [UsageLimitStore] it lives in device-protected storage,
 * so the numbers survive an app restart, process death and a reboot, and today's usage clears by itself when the
 * calendar day changes. Rules for what may be added or edited are in [WebsiteLimitRules]; who may change limits while
 * a session runs is decided by the caller (the ViewModel), the same way as for app limits.
 */
class WebsiteLimitStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "website_limits")

    private val _state = MutableStateFlow(readState())
    val state: StateFlow<WebsiteLimitState> = _state.asStateFlow()

    /** Cheap lookup for the accessibility service, which asks every second while a browser is in front. */
    @Volatile
    private var cache: List<WebsiteLimit> = readLimits()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        cache = readLimits()
        _state.value = readState()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    // ---- Limits -----------------------------------------------------------------------------

    fun limits(): List<WebsiteLimit> = cache

    /** At least one limit is ON: only then does the service watch the browsers for usage. */
    fun hasEnabled(): Boolean = cache.any { it.enabled }

    /** The limit that covers [host] (ON or OFF), or null. */
    fun limitFor(host: String): WebsiteLimit? = WebsiteLimitRules.find(cache, host)

    @Synchronized
    fun add(raw: String, minutes: Int): WebsiteLimitRules.Result {
        val change = WebsiteLimitRules.add(readLimits(), raw, minutes)
        if (change.result == WebsiteLimitRules.Result.OK) saveLimits(change.limits)
        return change.result
    }

    /** Edits [oldDomain]. Changing the site starts it at zero today; changing only the time keeps today's usage. */
    @Synchronized
    fun edit(oldDomain: String, raw: String, minutes: Int): WebsiteLimitRules.Result {
        val change = WebsiteLimitRules.edit(readLimits(), oldDomain, raw, minutes)
        if (change.result != WebsiteLimitRules.Result.OK) return change.result
        val renamed = change.limits.none { it.domain == oldDomain }
        saveLimits(change.limits)
        if (renamed) {
            rollOverIfNeeded()
            prefs.edit().remove(K_USED + oldDomain).commit()
        }
        return change.result
    }

    @Synchronized
    fun remove(domain: String) {
        saveLimits(WebsiteLimitRules.remove(readLimits(), domain))
        prefs.edit().remove(K_USED + domain).commit()
    }

    @Synchronized
    fun setEnabled(domain: String, on: Boolean) {
        val now = readLimits()
        val next = WebsiteLimitRules.setEnabled(now, domain, on)
        if (next != now) saveLimits(next)
    }

    // ---- Usage ------------------------------------------------------------------------------

    fun usedMs(domain: String): Long {
        rollOverIfNeeded()
        return prefs.getLong(K_USED + domain, 0L)
    }

    /** Adds [deltaMs] to today's usage of [domain] and returns the new total. */
    @Synchronized
    fun addUsage(domain: String, deltaMs: Long): Long {
        rollOverIfNeeded()
        val total = prefs.getLong(K_USED + domain, 0L) + deltaMs.coerceAtLeast(0L)
        prefs.edit().putLong(K_USED + domain, total).apply()
        return total
    }

    /** True when the limit for [domain] is ON and today's time is used up. */
    fun isReached(domain: String): Boolean {
        val limit = cache.firstOrNull { it.domain == domain } ?: return false
        return limit.enabled && usedMs(domain) >= limit.limitMs
    }

    /** Brings the numbers up to date (a new day clears yesterday's usage) so a screen shows today's state. */
    fun refresh() {
        rollOverIfNeeded()
        _state.value = readState()
    }

    // ---- Internals --------------------------------------------------------------------------

    @Synchronized
    private fun rollOverIfNeeded() {
        val today = LocalDate.now().toString()
        if (prefs.getString(K_DAY, null) == today) return
        val editor = prefs.edit().putString(K_DAY, today)
        prefs.all.keys.filter { it.startsWith(K_USED) }.forEach { editor.remove(it) }
        // commit(): the reset must be on disk before anything is counted into the new day.
        editor.commit()
    }

    private fun saveLimits(list: List<WebsiteLimit>) {
        val encoded = list.map { "${it.domain}|${it.limitMin}|${if (it.enabled) 1 else 0}" }
        // commit() so a limit is on disk before the service can be asked about it; the list is tiny.
        prefs.edit().putString(K_LIMITS, ListCodec.encode(encoded)).commit()
    }

    private fun readLimits(): List<WebsiteLimit> {
        val out = ArrayList<WebsiteLimit>()
        for (raw in ListCodec.decode(prefs.getString(K_LIMITS, null))) {
            val p = raw.split('|')
            if (p.size < 3) continue
            val min = p[1].toIntOrNull() ?: continue
            if (p[0].isEmpty() || !WebsiteLimitRules.validMinutes(min)) continue
            out += WebsiteLimit(p[0], min, enabled = p[2] == "1")
        }
        return out
    }

    private fun readState(): WebsiteLimitState {
        rollOverIfNeeded()
        val list = readLimits()
        return WebsiteLimitState(
            limits = list,
            usedMs = list.associate { it.domain to prefs.getLong(K_USED + it.domain, 0L) },
        )
    }

    companion object {
        private const val K_LIMITS = "limits"
        private const val K_USED = "used_"
        private const val K_DAY = "day"

        @Volatile
        private var instance: WebsiteLimitStore? = null

        fun get(context: Context): WebsiteLimitStore =
            instance ?: synchronized(this) {
                instance ?: WebsiteLimitStore(context.applicationContext).also { instance = it }
            }
    }
}
