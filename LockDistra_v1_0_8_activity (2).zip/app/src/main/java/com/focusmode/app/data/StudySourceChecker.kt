package com.focusmode.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.webkit.WebView
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL

/**
 * Reads the facts that decide the status of the three Study sources, and re-checks a source after it failed.
 * The statuses themselves live in [StudySources]; the rules that turn a fact / failure into a status are in [SourceClassifier].
 *
 * Light by design:
 *  - NO timer, NO background service, NO network callback. It runs only when the Study screen opens (see StudyScreen).
 *  - [refreshLocal] reads phone facts only (no network) and does nothing if it ran in the last [LOCAL_GAP_MS].
 *  - [verifyDue] makes a network request only for a source that FAILED, only after its cool-down ([SourceTracker.due]), and
 *    never for a working, switched-off or locally blocked source. Every request has a short timeout.
 * Blocking: call from a background thread.
 */
class StudySourceChecker(
    context: Context,
    private val store: StudyStore,
    private val tracker: SourceTracker = StudySources.tracker,
) {
    private val app = context.applicationContext

    /** Free, local checks only. Safe to call often (it skips itself inside [LOCAL_GAP_MS]); [force] ignores that. */
    fun refreshLocal(now: Long = System.currentTimeMillis(), force: Boolean = false) {
        if (!force && now - lastLocalAt < LOCAL_GAP_MS) return
        lastLocalAt = now
        val offline = isOffline()

        // YouTube API. First what earlier REAL answers saved (a key that rests), then the local facts (which never hide it).
        val keys = store.apiKeyList
        SourceClassifier.fromResting(keys.map { store.restReason(it) }, keys.map { store.restUntil(it) }, now)
            ?.let { tracker.observe(StudyMode.API, it, now) }
        tracker.applyLocal(StudyMode.API, SourceClassifier.apiLocal(store.isSourceEnabled(StudyMode.API), keys.size, offline), now)

        // Direct YouTube.
        val (installed, appEnabled) = youtubeApp()
        tracker.applyLocal(
            StudyMode.PAGE,
            SourceClassifier.directLocal(store.isSourceEnabled(StudyMode.PAGE), installed, appEnabled, permissionsOk(), offline),
            now,
        )

        // Web.
        tracker.applyLocal(
            StudyMode.WEB,
            SourceClassifier.webLocal(store.isSourceEnabled(StudyMode.WEB), webViewPresent(), offline),
            now,
        )
    }

    /**
     * Re-checks the sources that failed and are due (cool-down over). Returns the sources it asked. A source that works, is
     * switched off, or is blocked by a local fact is never asked. Run [refreshLocal] first.
     */
    fun verifyDue(now: Long = System.currentTimeMillis()): List<StudyMode> {
        val asked = ArrayList<StudyMode>()
        // Part 4/4: no connection for sure = a re-check could only fail again (and drain the battery for nothing). It waits; the
        // moment the phone is online again [onNetworkRestored] runs it.
        if (isOffline() == true) return asked
        for (mode in listOf(StudyMode.API, StudyMode.PAGE, StudyMode.WEB)) {
            if (!tracker.due(mode, now)) continue
            tracker.markChecked(mode, now)
            when (mode) {
                StudyMode.API -> StudyApi(store).ping() // the outcome is recorded by StudyApi itself
                StudyMode.PAGE -> probePage()
                StudyMode.WEB -> probeWeb()
            }
            asked += mode
        }
        return asked
    }

    /**
     * The phone just got a network (Part 4/4, called from the connectivity callback the Study screen registers while it is open).
     * Network-only failures end their cool-down, the local facts are read again (so "no internet" is cleared), and the sources that
     * failed are re-checked ONCE, so a recovered source is marked available without any screen reload. Blocking: background thread.
     * Returns the sources it asked.
     */
    fun onNetworkRestored(now: Long = System.currentTimeMillis()): List<StudyMode> {
        tracker.networkRestored(now)
        refreshLocal(now, force = true)
        return verifyDue(now)
    }

    // ---- network re-checks (only after a failure) -----------------------------------------------------------

    /** The real Direct YouTube path: one search of the page data. Working = the page came AND could be read. */
    private fun probePage() {
        val started = System.currentTimeMillis()
        try {
            StudyNative.search("maths")
            tracker.success(StudyMode.PAGE, responseMs = System.currentTimeMillis() - started)
        } catch (t: Throwable) {
            tracker.failure(StudyMode.PAGE, SourceClassifier.fromPage(t))
        }
    }

    /** Is the web server the WebView search uses reachable? A small HEAD request with a short timeout. */
    private fun probeWeb() {
        try {
            val host = URL(StudyWeb.searchUrl("maths")).let { it.protocol + "://" + it.host + "/" }
            val c = URL(host).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"
            c.connectTimeout = PROBE_TIMEOUT_MS
            c.readTimeout = PROBE_TIMEOUT_MS
            val started = System.currentTimeMillis()
            val code = try { c.responseCode } finally { c.disconnect() }
            if (code in 200..399) tracker.success(StudyMode.WEB, responseMs = System.currentTimeMillis() - started)
            else tracker.failure(StudyMode.WEB, SourceClassifier.httpFailure(code))
        } catch (e: SocketTimeoutException) {
            tracker.failure(StudyMode.WEB, SourceClassifier.fromWebError(timeout = true, network = false))
        } catch (e: java.io.IOException) {
            tracker.failure(StudyMode.WEB, SourceClassifier.fromWebError(timeout = false, network = true))
        } catch (e: Exception) {
            tracker.failure(StudyMode.WEB, SourceClassifier.fromWebError(timeout = false, network = false))
        }
    }

    // ---- local facts ----------------------------------------------------------------------------------------

    /** true = no network for sure (no connected network at all); false = a network with internet exists; null = cannot tell. */
    private fun isOffline(): Boolean? = try {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val net = cm?.activeNetwork
        when {
            cm == null -> null
            net == null -> true
            else -> if (cm.getNetworkCapabilities(net)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true) false else null
        }
    } catch (e: Exception) {
        null
    }

    /**
     * (installed, enabled) of the YouTube app. Each null = could not be read. "Not installed" is only said when Android itself
     * says the package does not exist (the manifest declares the package, so a disabled app is still found). A disabled-until-used
     * app is "unknown", not "disabled".
     */
    @Suppress("DEPRECATION")
    private fun youtubeApp(): Pair<Boolean?, Boolean?> {
        val pm = app.packageManager
        return try {
            val info = if (Build.VERSION.SDK_INT >= 33) pm.getApplicationInfo(YOUTUBE_PACKAGE, PackageManager.ApplicationInfoFlags.of(0L))
            else pm.getApplicationInfo(YOUTUBE_PACKAGE, 0)
            val setting = pm.getApplicationEnabledSetting(YOUTUBE_PACKAGE)
            val enabled: Boolean? = when (setting) {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED_UNTIL_USED -> null
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER -> false
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                else -> info.enabled // DEFAULT: the app's own manifest decides
            }
            true to enabled
        } catch (e: PackageManager.NameNotFoundException) {
            false to null
        } catch (e: Exception) {
            null to null
        }
    }

    /** The permissions the page-data and Web search need to reach YouTube. They are normal permissions, but are checked, not assumed. */
    private fun permissionsOk(): Boolean? = try {
        app.checkSelfPermission(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED &&
            app.checkSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE) == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) {
        null
    }

    /** Is a WebView provider installed and usable? (Cheap: asks Android, creates no WebView.) */
    private fun webViewPresent(): Boolean? = try {
        WebView.getCurrentWebViewPackage() != null
    } catch (e: Exception) {
        null
    }

    companion object {
        const val YOUTUBE_PACKAGE = "com.google.android.youtube"
        const val LOCAL_GAP_MS = 15_000L

        /** Shared by every checker, so opening the screen again and again does not repeat the local reads. */
        @Volatile private var lastLocalAt = 0L
        private const val PROBE_TIMEOUT_MS = 4000
    }
}
