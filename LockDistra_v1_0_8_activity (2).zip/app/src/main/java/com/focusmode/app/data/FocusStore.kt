package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

const val PLANT_MAX_GROWTH = 40

data class FocusState(
    val focusActive: Boolean = false,
    val sessionStart: Long = 0L,
    /** 0 means "no time limit". */
    val sessionEnd: Long = 0L,
    val sessionMinutes: Int = 0,
    val emergencyUntil: Long = 0L,
    val blocked: Set<String> = emptySet(),
    val blockShorts: Boolean = false,
    /** 0 means reminders are off. */
    val reminderMinutes: Int = 30,
    val nextReminderAt: Long = 0L,
    val plantGrowth: Int = 0,
    val lastGrowthToken: Long = 0L,
    val userName: String = "",
    /** 0 = follow system, 1 = light, 2 = dark. */
    val themeMode: Int = 0,
    val lastDurationMin: Int = 45,
    /** Advanced uninstall protection (needs device admin + accessibility). User-controlled. */
    val advancedProtection: Boolean = false,
    /** Bring an unfinished focus session back after a restart (user-controlled). */
    val restoreAfterRestart: Boolean = true,
    /** Package that the running emergency window opens. Empty = legacy "everything" window. */
    val emergencyPkg: String = "",
    /**
     * Advanced controls (see [FocusControl]). `true` = the action is allowed. While a session
     * runs a control can only be tightened (allowed -> not allowed), never loosened again.
     */
    val allowTurnOff: Boolean = true,
    val allowSettingsChange: Boolean = true,
    val allowEmergency: Boolean = true,
    val allowAppChanges: Boolean = true,
    /** Other ways round the session (App info, uninstall, device admin and Accessibility pages). */
    val allowOtherBypass: Boolean = false,
    /** Number of the newest plant reminder that was posted (0 = none). */
    val checkInToken: Long = 0L,
    /** "Prevent changes" is switched on. */
    val preventChanges: Boolean = false,
    /** Prevent changes is on and no editing window is open right now: nothing may be changed. */
    val changesLocked: Boolean = false,
    /** How Focus Mode may be turned OFF by hand (Settings > Focus). Changed only between sessions. */
    val offMethod: FocusOffMethod = FocusOffMethod.NORMAL,
    /** Study Check-In interval in minutes (0 = off). Changed only between sessions. See [StudyCheckInRules]. */
    val studyMin: Int = StudyCheckInRules.OFF,
    /** When the next check-in is due (0 = none scheduled). */
    val studyNextAt: Long = 0L,
    /** The running check-in must be answered by this time (0 = no check-in waiting). */
    val studyDeadline: Long = 0L,
    /** Number of the newest check-in that was shown. */
    val studySeq: Long = 0L,
    /** Newest missed check-in (0 = none), when it was missed, and the newest one whose alert was handled. */
    val studyMissSeq: Long = 0L,
    val studyMissAt: Long = 0L,
    val studySentSeq: Long = 0L,
    /** Last confirmation ("I'm Studying") and how many there have been. */
    val studyConfirmedAt: Long = 0L,
    val studyConfirmedCount: Int = 0,
    /** Total time the timer stood still while the lecture was not playing (see [LectureTimerRules]). Identifies the session. */
    val lectureShiftMs: Long = 0L,
) {
    /** A study check-in is on screen and waiting for "I'm Studying". */
    val studyCheckInWaiting: Boolean get() = focusActive && studyDeadline != 0L

    /**
     * A plant reminder is waiting for the person to confirm they are studying. It is answered
     * either by tapping anywhere in the open app or by the notification button.
     */
    val checkInPending: Boolean get() = focusActive && checkInToken > lastGrowthToken

    fun emergencyActive(now: Long) = focusActive && emergencyUntil > now

    /** True when blocking should be enforced right now (no emergency window of any kind). */
    fun blockingNow(now: Long) = focusActive && emergencyUntil <= now

    /** True when the running emergency window currently lets [pkg] through. */
    fun emergencyCovers(pkg: String, now: Long) =
        emergencyActive(now) && (emergencyPkg.isEmpty() || emergencyPkg == pkg)

    // ---- Policy helpers: every screen and service asks these, so the rules live in one place ----

    /** The user may end the session by hand. A finished timer always ends it. */
    val canTurnOff: Boolean get() = !focusActive || allowTurnOff

    /** LockDistra settings (reminders, protection switches, controls) may be changed. */
    val canChangeSettings: Boolean get() = (!focusActive || allowSettingsChange) && !changesLocked

    /**
     * Focus Mode's own settings (the switches under the LockDistra ring, OFF method, Study Check-In, check-in timing,
     * Auto Focus, restore after restart). "Prevent changes" does NOT lock these: Focus Mode is a separate thing that
     * works on its own profile. Only the running session's own rule ("Allow changing settings") applies.
     */
    val canChangeFocusSettings: Boolean get() = !focusActive || allowSettingsChange

    /** Saved Focus Profiles may be chosen / edited. Only the session's "Allow app changes" applies, never "Prevent changes". */
    val canEditFocusProfiles: Boolean get() = !focusActive || allowAppChanges

    /** Emergency access may be started. */
    val canUseEmergency: Boolean get() = focusActive && allowEmergency

    /** Blocked apps, Shorts, usage limits and emergency apps may be edited. */
    val canEditApps: Boolean get() = (!focusActive || allowAppChanges) && !changesLocked

    /** True while the guard on App info / uninstall / device admin / Accessibility pages is on. */
    val sessionGuardOn: Boolean get() = focusActive && !allowOtherBypass
}

/** The five switches under the LockDistra ring. */
enum class FocusControl { TURN_OFF, SETTINGS, EMERGENCY, APP_CHANGES, OTHER_BYPASS }

/**
 * Single source of truth, persisted in SharedPreferences so the UI, the foreground service,
 * the accessibility service and the boot receiver all see the same state synchronously.
 */
class FocusStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "focus_mode")

    private val _state = MutableStateFlow(read())
    val state: StateFlow<FocusState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _state.value = read()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    /** Always-fresh read straight from storage. */
    fun current(): FocusState = read()

    /** Re-publishes the state. Used when the editing window opens or closes (no stored value changes then). */
    fun refresh() {
        _state.value = read()
    }

    private fun read() = FocusState(
        focusActive = prefs.getBoolean(K_ACTIVE, false),
        sessionStart = prefs.getLong(K_START, 0L),
        sessionEnd = prefs.getLong(K_END, 0L),
        sessionMinutes = prefs.getInt(K_MINUTES, 0),
        emergencyUntil = prefs.getLong(K_EMERGENCY, 0L),
        blocked = HashSet(prefs.getStringSet(K_BLOCKED, emptySet()) ?: emptySet()),
        blockShorts = prefs.getBoolean(K_SHORTS, false),
        reminderMinutes = prefs.getInt(K_REMINDER, 30),
        nextReminderAt = prefs.getLong(K_NEXT_REMINDER, 0L),
        plantGrowth = prefs.getInt(K_PLANT, 0),
        lastGrowthToken = prefs.getLong(K_GROWTH_TOKEN, 0L),
        userName = prefs.getString(K_NAME, "") ?: "",
        themeMode = prefs.getInt(K_THEME, 0),
        lastDurationMin = prefs.getInt(K_LAST_DURATION, 45),
        advancedProtection = prefs.getBoolean(K_ADVANCED, false),
        restoreAfterRestart = prefs.getBoolean(K_RESTORE, true),
        emergencyPkg = prefs.getString(K_EMERGENCY_PKG, "") ?: "",
        allowTurnOff = prefs.getBoolean(K_C_OFF, true),
        allowSettingsChange = prefs.getBoolean(K_C_SETTINGS, true),
        allowEmergency = prefs.getBoolean(K_C_EMERGENCY, true),
        allowAppChanges = prefs.getBoolean(K_C_APPS, true),
        allowOtherBypass = prefs.getBoolean(K_C_BYPASS, false),
        checkInToken = prefs.getLong(K_POSTED_TOKEN, 0L),
        preventChanges = prefs.getBoolean(K_PREVENT, false),
        changesLocked = prefs.getBoolean(K_PREVENT, false) && !ChangeGuard.isOpen() && !ChangeGuard.isGraceOpen(),
        offMethod = FocusOffMethod.fromId(prefs.getString(K_OFF_METHOD, null)),
        studyMin = prefs.getInt(K_STUDY_MIN, StudyCheckInRules.OFF),
        studyNextAt = prefs.getLong(K_STUDY_NEXT, 0L),
        studyDeadline = prefs.getLong(K_STUDY_DEADLINE, 0L),
        studySeq = prefs.getLong(K_STUDY_SEQ, 0L),
        studyMissSeq = prefs.getLong(K_STUDY_MISS_SEQ, 0L),
        studyMissAt = prefs.getLong(K_STUDY_MISS_AT, 0L),
        studySentSeq = prefs.getLong(K_STUDY_SENT_SEQ, 0L),
        studyConfirmedAt = prefs.getLong(K_STUDY_OK_AT, 0L),
        studyConfirmedCount = prefs.getInt(K_STUDY_OK_COUNT, 0),
        lectureShiftMs = prefs.getLong(K_SHIFTED, 0L),
    )

    // ---- Session ----------------------------------------------------------------------------

    /**
     * [durationMs] and [elapsedMs] let a paused Pomodoro focus round continue where it stopped;
     * [remember] = false keeps a Pomodoro round from replacing the length the user picked for normal sessions.
     */
    fun startSession(
        minutes: Int,
        now: Long = System.currentTimeMillis(),
        durationMs: Long = minutes * 60_000L,
        elapsedMs: Long = 0L,
        remember: Boolean = true,
        /** Lecture session with "turn OFF when the lecture ends": the end time is a safety net that the lecture later corrects. */
        lectureTimed: Boolean = false,
    ) {
        val reminder = prefs.getInt(K_REMINDER, 30)
        val editor = prefs.edit()
            .putBoolean(K_ACTIVE, true)
            .putLong(K_START, now - elapsedMs)
            .putInt(K_MINUTES, minutes)
            .putLong(K_END, if (minutes > 0) now + durationMs else 0L)
            .putLong(K_EMERGENCY, 0L)
            .putLong(K_NEXT_REMINDER, if (reminder > 0) now + reminder * 60_000L else 0L)
            .remove(K_A_WALL).remove(K_A_ELAPSED).remove(K_A_BOOT)
            .remove(K_POSTED_TOKEN)
        // Study Check-In: the first one is a full interval after the session (or Pomodoro round) starts.
        val study = prefs.getInt(K_STUDY_MIN, StudyCheckInRules.OFF)
        editor.putLong(K_STUDY_NEXT, if (study > 0) now + study * 60_000L else 0L)
            .putLong(K_STUDY_DEADLINE, 0L)
        if (minutes > 0 && remember) editor.putInt(K_LAST_DURATION, minutes)
        // A session with no time limit can only end by hand, so "turning OFF" can never be
        // locked for it. This keeps a locked session from becoming a trap.
        if (minutes <= 0) editor.putBoolean(K_C_OFF, true)
        editor.putBoolean(K_LECTURE_TIMED, lectureTimed)
        editor.putLong(K_SHIFTED, 0L)
        editor.putString(K_EMERGENCY_PKG, "")
        editor.apply()
    }

    /**
     * Lecture session: moves the end of the session to [remainingMs] from now (the lecture's real remaining time plus
     * a small buffer). Only for a session started with `lectureTimed`, and only when the change is bigger than 30 s.
     * Returns true when the end moved.
     */
    fun setEndFromLecture(remainingMs: Long, now: Long = System.currentTimeMillis()): Boolean {
        if (!prefs.getBoolean(K_ACTIVE, false) || !prefs.getBoolean(K_LECTURE_TIMED, false)) return false
        val newEnd = now + remainingMs.coerceIn(60_000L, 6 * 60 * 60_000L)
        val oldEnd = prefs.getLong(K_END, 0L)
        if (oldEnd > 0L && kotlin.math.abs(newEnd - oldEnd) < 30_000L) return false
        val start = prefs.getLong(K_START, now)
        prefs.edit()
            .putLong(K_END, newEnd)
            .putInt(K_MINUTES, (((newEnd - start) + 59_999L) / 60_000L).toInt())
            .remove(K_A_WALL).remove(K_A_ELAPSED).remove(K_A_BOOT)
            .apply()
        return true
    }

    /**
     * The lecture is not playing, so the timer stands still: the end (and the start, reminders and the next check-in) move
     * forward by [deltaMs]. Only for a session with a time limit. Returns true when something moved.
     */
    @Synchronized
    fun shiftSession(deltaMs: Long): Boolean {
        if (deltaMs <= 0L || !prefs.getBoolean(K_ACTIVE, false)) return false
        val end = prefs.getLong(K_END, 0L)
        if (end <= 0L) return false
        val e = prefs.edit()
            .putLong(K_START, prefs.getLong(K_START, 0L) + deltaMs)
            .putLong(K_END, end + deltaMs)
            .putLong(K_SHIFTED, prefs.getLong(K_SHIFTED, 0L) + deltaMs)
        val reminder = prefs.getLong(K_NEXT_REMINDER, 0L)
        if (reminder > 0L) e.putLong(K_NEXT_REMINDER, reminder + deltaMs)
        val study = prefs.getLong(K_STUDY_NEXT, 0L)
        if (study > 0L) e.putLong(K_STUDY_NEXT, study + deltaMs)
        e.apply()
        return true
    }

    fun endSession() {
        prefs.edit()
            .putLong(K_SHIFTED, 0L)
            .putBoolean(K_LECTURE_TIMED, false)
            .putBoolean(K_ACTIVE, false)
            .putLong(K_END, 0L)
            .putLong(K_EMERGENCY, 0L)
            .putString(K_EMERGENCY_PKG, "")
            .putLong(K_NEXT_REMINDER, 0L)
            // A check-in that was waiting when the session ended is simply dropped: it is not a missed one.
            .putLong(K_STUDY_NEXT, 0L)
            .putLong(K_STUDY_DEADLINE, 0L)
            .remove(K_A_WALL).remove(K_A_ELAPSED).remove(K_A_BOOT)
            .remove(K_POSTED_TOKEN)
            .apply()
    }

    /**
     * Compares the wall clock with the monotonic clock while a session runs. If the user moved the
     * phone's clock, every saved time of the session moves with it, so changing the date or time
     * can neither end a session early nor stretch it. Returns the jump found (0 = none).
     */
    @Synchronized
    fun syncClock(wall: Long, elapsed: Long, boot: Int): Long {
        if (!prefs.getBoolean(K_ACTIVE, false)) return 0L
        val anchor = if (prefs.contains(K_A_WALL)) {
            ClockAnchor(prefs.getLong(K_A_WALL, 0L), prefs.getLong(K_A_ELAPSED, 0L), prefs.getInt(K_A_BOOT, -1))
        } else null
        val jump = ClockGuard.jump(anchor, wall, elapsed, boot)
        val refresh = jump != 0L || ClockGuard.shouldRefresh(anchor, elapsed, boot)
        if (!refresh) return 0L
        val editor = prefs.edit()
        if (jump != 0L) {
            editor.putLong(K_START, ClockGuard.shifted(prefs.getLong(K_START, 0L), jump))
                .putLong(K_END, ClockGuard.shifted(prefs.getLong(K_END, 0L), jump))
                .putLong(K_EMERGENCY, ClockGuard.shifted(prefs.getLong(K_EMERGENCY, 0L), jump))
                .putLong(K_NEXT_REMINDER, ClockGuard.shifted(prefs.getLong(K_NEXT_REMINDER, 0L), jump))
                .putLong(K_STUDY_NEXT, ClockGuard.shifted(prefs.getLong(K_STUDY_NEXT, 0L), jump))
                .putLong(K_STUDY_DEADLINE, ClockGuard.shifted(prefs.getLong(K_STUDY_DEADLINE, 0L), jump))
        }
        editor.putLong(K_A_WALL, wall).putLong(K_A_ELAPSED, elapsed).putInt(K_A_BOOT, boot).apply()
        return jump
    }

    // ---- Emergency access -------------------------------------------------------------------

    /** Opens an emergency window for one app ([pkg]) until [until]. */
    fun setEmergency(pkg: String, until: Long) {
        prefs.edit().putLong(K_EMERGENCY, until).putString(K_EMERGENCY_PKG, pkg).apply()
    }

    fun clearEmergency() {
        prefs.edit().putLong(K_EMERGENCY, 0L).putString(K_EMERGENCY_PKG, "").apply()
    }

    // ---- Blocking list ----------------------------------------------------------------------

    fun setBlocked(pkg: String, blocked: Boolean) {
        if (!read().canEditApps) return
        val set = HashSet(prefs.getStringSet(K_BLOCKED, emptySet()) ?: emptySet())
        if (blocked) set.add(pkg) else set.remove(pkg)
        prefs.edit().putStringSet(K_BLOCKED, set).apply()
    }

    fun setBlockShorts(on: Boolean) {
        if (!read().canEditApps) return
        prefs.edit().putBoolean(K_SHORTS, on).apply()
    }

    // ---- Plant ------------------------------------------------------------------------------

    fun setReminderMinutes(minutes: Int, now: Long = System.currentTimeMillis()) {
        if (!read().canChangeFocusSettings) return
        val active = prefs.getBoolean(K_ACTIVE, false)
        prefs.edit()
            .putInt(K_REMINDER, minutes)
            .putLong(K_NEXT_REMINDER, if (active && minutes > 0) now + minutes * 60_000L else 0L)
            .apply()
    }

    fun setNextReminder(at: Long) {
        prefs.edit().putLong(K_NEXT_REMINDER, at).apply()
    }

    /** Grows the plant once per notification (identified by [token]). Returns true if it grew. */
    @Synchronized
    fun growFromNotification(token: Long): Boolean {
        // Only the reminder that was really posted counts (see GrowPolicy).
        if (!GrowPolicy.accepts(token, prefs.getLong(K_POSTED_TOKEN, 0L), prefs.getLong(K_GROWTH_TOKEN, 0L))) return false
        val growth = prefs.getInt(K_PLANT, 0)
        prefs.edit()
            .putLong(K_GROWTH_TOKEN, token)
            .putInt(K_PLANT, (growth + 1).coerceAtMost(PLANT_MAX_GROWTH))
            .apply()
        return growth < PLANT_MAX_GROWTH
    }

    /** Remembers the number of the reminder just posted, so only its tap can grow the plant. */
    fun notePostedReminder(token: Long) {
        prefs.edit().putLong(K_POSTED_TOKEN, token).apply()
    }

    fun resetPlant() {
        prefs.edit().putInt(K_PLANT, 0).apply()
    }

    // ---- Profile & appearance ---------------------------------------------------------------

    fun setUserName(name: String) {
        prefs.edit().putString(K_NAME, name.trim().take(24)).apply()
    }

    fun setThemeMode(mode: Int) {
        prefs.edit().putInt(K_THEME, mode).apply()
    }

    fun setRestoreAfterRestart(on: Boolean) {
        if (!read().canChangeFocusSettings) return
        prefs.edit().putBoolean(K_RESTORE, on).apply()
    }

    // ---- Advanced controls ------------------------------------------------------------------

    /**
     * Sets one control. Returns true if the control now has the requested value.
     *
     * Outside a session the controls are free defaults. While a session runs they can only be
     * tightened: switching "allowed" off sticks until the session ends, otherwise the lock
     * would mean nothing. Nothing can change at all once "changing settings" is switched off.
     */
    @Synchronized
    fun setControl(control: FocusControl, allowed: Boolean): Boolean {
        val s = read()
        if (FocusPolicy.isAllowed(s, control) == allowed) return true
        if (!FocusPolicy.canSetControl(s, control, allowed)) return false
        val key = when (control) {
            FocusControl.TURN_OFF -> K_C_OFF
            FocusControl.SETTINGS -> K_C_SETTINGS
            FocusControl.EMERGENCY -> K_C_EMERGENCY
            FocusControl.APP_CHANGES -> K_C_APPS
            FocusControl.OTHER_BYPASS -> K_C_BYPASS
        }
        prefs.edit().putBoolean(key, allowed).apply()
        return true
    }

    // ---- How Focus Mode is turned OFF ---------------------------------------------------------

    /**
     * Chooses the OFF method. Refused while a session runs (otherwise the choice could be loosened to
     * the plain button mid-session) and while LockDistra settings are locked. Returns true if it is stored.
     */
    @Synchronized
    fun setOffMethod(method: FocusOffMethod): Boolean {
        val s = read()
        if (s.offMethod == method) return true
        if (!FocusOffRules.canChange(s.focusActive, s.canChangeFocusSettings)) return false
        prefs.edit().putString(K_OFF_METHOD, method.id).apply()
        return true
    }

    // ---- Study Check-In -----------------------------------------------------------------------------------------

    /**
     * Chooses the check-in interval (0 = off). Refused while a session runs and while LockDistra settings are locked, so
     * the check-ins cannot be switched off in the middle of a session. Returns true if it is stored.
     */
    @Synchronized
    fun setStudyCheckInMinutes(minutes: Int): Boolean {
        val s = read()
        val value = StudyCheckInRules.clamp(minutes)
        if (s.studyMin == value) return true
        if (!StudyCheckInRules.canChange(s.focusActive, s.canChangeFocusSettings)) return false
        prefs.edit().putInt(K_STUDY_MIN, value).putLong(K_STUDY_NEXT, 0L).putLong(K_STUDY_DEADLINE, 0L).apply()
        return true
    }

    /**
     * Starts the check-in that is due: gives the person [StudyCheckInRules.RESPONSE_WINDOW_MS] and schedules the next
     * one. Returns the check-in's number, or 0 when nothing is due (already started by another caller, session
     * over, check-ins off). Done in one locked step so two callers can never start the same check-in twice.
     */
    @Synchronized
    fun beginStudyCheckIn(now: Long): Long {
        val s = read()
        if (StudyCheckInRules.decide(s.focusActive, s.studyMin, s.studyNextAt, s.studyDeadline, now) !=
            StudyCheckInRules.Step.PROMPT
        ) return 0L
        val seq = s.studySeq + 1
        prefs.edit()
            .putLong(K_STUDY_SEQ, seq)
            .putLong(K_STUDY_DEADLINE, now + StudyCheckInRules.RESPONSE_WINDOW_MS)
            .putLong(K_STUDY_NEXT, StudyCheckInRules.nextAfterPrompt(now, s.studyMin))
            .apply()
        return seq
    }

    /** "I'm Studying". Counts only for the check-in that is really waiting (see [StudyCheckInRules.acceptsConfirm]). */
    @Synchronized
    fun confirmStudyCheckIn(seq: Long, now: Long): Boolean {
        val s = read()
        if (!StudyCheckInRules.acceptsConfirm(seq, s.studySeq, s.studyDeadline, s.focusActive)) return false
        prefs.edit()
            .putLong(K_STUDY_DEADLINE, 0L)
            .putLong(K_STUDY_OK_AT, now)
            .putInt(K_STUDY_OK_COUNT, s.studyConfirmedCount + 1)
            .apply()
        return true
    }

    /** The minute ran out. Returns the missed check-in's number, or 0 if it was already handled. Once per check-in. */
    @Synchronized
    fun markStudyCheckInMissed(now: Long): Long {
        val s = read()
        if (!s.focusActive || s.studyDeadline == 0L) return 0L
        prefs.edit()
            .putLong(K_STUDY_DEADLINE, 0L)
            .putLong(K_STUDY_MISS_SEQ, s.studySeq)
            .putLong(K_STUDY_MISS_AT, now)
            .apply()
        return s.studySeq
    }

    /** Drops the waiting check-in without calling it missed (could not be shown, or noticed too late to know). */
    @Synchronized
    fun dropStudyCheckIn() {
        prefs.edit().putLong(K_STUDY_DEADLINE, 0L).apply()
    }

    /** Postpones a check-in that could not be shown (notifications are off) to its next turn. Not a miss. */
    @Synchronized
    fun skipStudyCheckIn(now: Long) {
        val s = read()
        if (!s.focusActive || s.studyMin <= 0) return
        prefs.edit().putLong(K_STUDY_NEXT, StudyCheckInRules.nextAfterPrompt(now, s.studyMin)).apply()
    }

    /** The alert for miss [seq] reached the Worker (or was given up). It is never sent again. */
    @Synchronized
    fun markStudyAlertHandled(seq: Long) {
        if (seq > prefs.getLong(K_STUDY_SENT_SEQ, 0L)) prefs.edit().putLong(K_STUDY_SENT_SEQ, seq).apply()
    }

    // ---- Prevent changes --------------------------------------------------------------------

    /**
     * Switches "Prevent changes" on or off. Switching it OFF needs an open editing window (the
     * caller proved who they are first); [force] is only for when the way to unlock it is gone
     * (App lock off and no trusted phone), so it can never become a trap. Returns true if applied.
     */
    @Synchronized
    fun setPreventChanges(on: Boolean, force: Boolean = false): Boolean {
        if (!on && !force && read().changesLocked) return false
        prefs.edit().putBoolean(K_PREVENT, on).apply()
        return true
    }

    // ---- Uninstall protection ---------------------------------------------------------------

    fun setAdvancedProtection(on: Boolean, force: Boolean = false) {
        // Switching protection off is a setting change; switching it on is always fine.
        // [force] is for the system telling us the device admin is gone.
        if (!on && !force && !read().canChangeSettings) return
        prefs.edit().putBoolean(K_ADVANCED, on).apply()
    }

    companion object {
        private const val K_EMERGENCY_PKG = "emergency_pkg"
        private const val K_POSTED_TOKEN = "posted_reminder_token"
        private const val K_A_WALL = "clock_anchor_wall"
        private const val K_A_ELAPSED = "clock_anchor_elapsed"
        private const val K_A_BOOT = "clock_anchor_boot"
        private const val K_LECTURE_TIMED = "lecture_timed"
        private const val K_SHIFTED = "lecture_shifted_ms"
        private const val K_C_OFF = "ctl_allow_turn_off"
        private const val K_C_SETTINGS = "ctl_allow_settings"
        private const val K_C_EMERGENCY = "ctl_allow_emergency"
        private const val K_C_APPS = "ctl_allow_app_changes"
        private const val K_C_BYPASS = "ctl_allow_other_bypass"
        private const val K_OFF_METHOD = "focus_off_method"
        private const val K_STUDY_MIN = "study_checkin_min"
        private const val K_STUDY_NEXT = "study_checkin_next"
        private const val K_STUDY_DEADLINE = "study_checkin_deadline"
        private const val K_STUDY_SEQ = "study_checkin_seq"
        private const val K_STUDY_MISS_SEQ = "study_checkin_miss_seq"
        private const val K_STUDY_MISS_AT = "study_checkin_miss_at"
        private const val K_STUDY_SENT_SEQ = "study_checkin_sent_seq"
        private const val K_STUDY_OK_AT = "study_checkin_ok_at"
        private const val K_STUDY_OK_COUNT = "study_checkin_ok_count"
        private const val K_PREVENT = "prevent_changes"
        private const val K_ADVANCED = "advanced_protection"
        private const val K_RESTORE = "restore_after_restart"
        private const val K_ACTIVE = "active"
        private const val K_START = "start"
        private const val K_END = "end"
        private const val K_MINUTES = "minutes"
        private const val K_EMERGENCY = "emergency_until"
        private const val K_BLOCKED = "blocked_packages"
        private const val K_SHORTS = "block_shorts"
        private const val K_REMINDER = "reminder_minutes"
        private const val K_NEXT_REMINDER = "next_reminder"
        private const val K_PLANT = "plant_growth"
        private const val K_GROWTH_TOKEN = "growth_token"
        private const val K_NAME = "user_name"
        private const val K_THEME = "theme_mode"
        private const val K_LAST_DURATION = "last_duration"

        @Volatile
        private var instance: FocusStore? = null

        fun get(context: Context): FocusStore =
            instance ?: synchronized(this) {
                instance ?: FocusStore(context.applicationContext).also { instance = it }
            }
    }
}
