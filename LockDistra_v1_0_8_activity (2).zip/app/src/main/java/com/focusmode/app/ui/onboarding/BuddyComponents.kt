package com.focusmode.app.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.Typewriter
import com.focusmode.app.ui.theme.FocusTheme

/** Which edge of the bubble the little pointer sits on (toward the mascot). */
enum class BubbleTail { Top, Start }

private class BubbleShape(
    private val tail: BubbleTail,
    private val tailLength: Dp,
    private val tailHalfWidth: Dp,
    private val corner: Dp,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val len = with(density) { tailLength.toPx() }
        val half = with(density) { tailHalfWidth.toPx() }
        val r = with(density) { corner.toPx() }
        val body = Path()
        val pointer = Path()
        if (tail == BubbleTail.Top) {
            body.addRoundRect(RoundRect(0f, len, size.width, size.height, CornerRadius(r, r)))
            val cx = size.width / 2f
            pointer.moveTo(cx - half, len + 1f)
            pointer.lineTo(cx, 0f)
            pointer.lineTo(cx + half, len + 1f)
        } else {
            body.addRoundRect(RoundRect(len, 0f, size.width, size.height, CornerRadius(r, r)))
            val cy = minOf(size.height / 2f, 56f * density.density)
            pointer.moveTo(len + 1f, cy - half)
            pointer.lineTo(0f, cy)
            pointer.lineTo(len + 1f, cy + half)
        }
        pointer.close()
        return Outline.Generic(Path.combine(PathOperation.Union, body, pointer))
    }
}

/**
 * Speech bubble in the app's own card colours, with a pointer toward the mascot. The same bubble is
 * used for every line the mascot says, in the welcome screen and in the question screens later.
 */
@Composable
fun BuddySpeechBubble(
    modifier: Modifier = Modifier,
    tail: BubbleTail = BubbleTail.Top,
    content: @Composable ColumnScope.() -> Unit,
) {
    val c = FocusTheme.colors
    val tailLength = 14.dp
    val shape = BubbleShape(tail, tailLength, tailHalfWidth = 11.dp, corner = 24.dp)
    val fill = Brush.verticalGradient(listOf(c.card, lerp(c.card, c.background, if (c.isDark) 0.35f else 0f)))
    Column(
        modifier
            .shadow(10.dp, shape, ambientColor = c.glow.copy(alpha = 0.5f), spotColor = c.glow.copy(alpha = 0.5f))
            .background(fill, shape)
            .border(1.dp, c.stroke, shape)
            .padding(
                start = 20.dp + if (tail == BubbleTail.Start) tailLength else 0.dp,
                end = 20.dp,
                top = 18.dp + if (tail == BubbleTail.Top) tailLength else 0.dp,
                bottom = 18.dp,
            ),
        content = content
    )
}

/**
 * Text that appears letter by letter ("typed" by the mascot). The full text is laid out invisibly
 * underneath, so the bubble keeps its final size from the start and nothing jumps while typing.
 * Screen readers always get the complete sentence.
 */
@Composable
fun TypedText(
    full: String,
    shownUnits: Int,
    style: TextStyle,
    color: Color,
    modifier: Modifier = Modifier,
) {
    Box(modifier.semantics(mergeDescendants = true) { contentDescription = full }) {
        Text(full, style = style, color = Color.Transparent, modifier = Modifier.clearAndSetSemantics { })
        Text(
            Typewriter.prefix(full, shownUnits),
            style = style,
            color = color,
            modifier = Modifier.clearAndSetSemantics { }
        )
    }
}
