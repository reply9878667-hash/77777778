package com.focusmode.app.data

import com.focusmode.app.BuildConfig
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Optional download of a newer adult-domain list. The bundled list always works without it.
 *
 * Safety rules (all must hold, otherwise the working local list is left exactly as it was):
 *  - HTTPS only, and only from hosts in [TRUSTED_HOSTS] (or the host of the manifest URL the app was
 *    built with). Redirects are followed by hand and every hop is checked the same way.
 *  - The manifest is small, well-formed and its version is newer than the installed one.
 *  - The list is downloaded to a staging file with a size cap, its SHA-256 must equal the manifest's,
 *    it must be a clean sorted/unique domain file ([AdultBlocklist.verifyFile]), its entry count must
 *    equal the manifest's, must be at least [AdultBlocklist.MIN_ENTRIES], and must not be less than
 *    half the size of the list in use.
 *  - Only then is the staging file moved over the live file in one atomic step.
 *
 * The manifest and list are produced by `tools/build_adult_blocklist.py` (see ADULT_BLOCKLIST.md).
 */
object AdultListUpdater {

    sealed class Result(val message: String) {
        class Updated(val version: Long, val count: Int) : Result("Updated to list version $version ($count sites).")
        class UpToDate(val version: Long) : Result("Already up to date (list version $version).")
        class NotConfigured : Result("Updates are not set up in this build. The built-in list is being used.")
        class Failed(why: String) : Result("Update skipped, the current list is unchanged: $why")
    }

    val TRUSTED_HOSTS = setOf(
        "raw.githubusercontent.com",
        "github.com",
        "objects.githubusercontent.com",
        "release-assets.githubusercontent.com",
    )

    private const val MAX_MANIFEST_BYTES = 64 * 1024
    private const val MAX_LIST_BYTES = 80L * 1024 * 1024
    private const val MAX_REDIRECTS = 3
    private const val TIMEOUT_MS = 20_000

    /** Blocking; call from a background thread. Never throws. */
    fun update(store: AdultBlockStore, manifestUrl: String = BuildConfig.ADULT_LIST_MANIFEST_URL): Result {
        if (manifestUrl.isBlank()) return Result.NotConfigured().also { store.noteCheck(it.message) }
        val staging = store.stagingFile()
        val result = try {
            runUpdate(store, manifestUrl.trim(), staging)
        } catch (e: Exception) {
            Result.Failed(e.message ?: e.javaClass.simpleName)
        }
        staging.delete()
        store.noteCheck(result.message)
        return result
    }

    private fun runUpdate(store: AdultBlockStore, manifestUrl: String, staging: File): Result {
        val allowed = TRUSTED_HOSTS + hostOf(manifestUrl)
        val manifestBytes = fetch(manifestUrl, allowed, MAX_MANIFEST_BYTES.toLong(), null)
        val m = try {
            AdultBlockStore.parseManifest(String(manifestBytes, Charsets.UTF_8))
        } catch (e: Exception) {
            return Result.Failed("manifest is not valid")
        }
        if (m.version <= 0 || m.count < AdultBlocklist.MIN_ENTRIES || m.sha256.length != 64) {
            return Result.Failed("manifest is incomplete")
        }
        val installedVersion = store.installedVersion()
        if (m.version <= installedVersion) return Result.UpToDate(installedVersion)

        val listUrl = resolve(manifestUrl, m.listUrl)
        val digest = MessageDigest.getInstance("SHA-256")
        fetch(listUrl, allowed, MAX_LIST_BYTES, staging, digest)
        val sha = digest.digest().joinToString("") { "%02x".format(it) }
        if (sha != m.sha256) return Result.Failed("the download did not match its checksum")

        val n = try {
            AdultBlocklist.verifyFile(staging)
        } catch (e: Exception) {
            return Result.Failed("the downloaded list is not in the expected format")
        }
        if (n != m.count) return Result.Failed("the downloaded list is incomplete")
        val current = store.installedCount()
        if (n < AdultBlocklist.MIN_ENTRIES) return Result.Failed("the new list is too small")
        if (current > 0 && n < current * (1.0 - AdultBlocklist.MAX_SHRINK)) {
            return Result.Failed("the new list is much smaller than the current one")
        }
        store.installDownloaded(staging, m)
        return Result.Updated(m.version, n)
    }

    private fun hostOf(url: String): String =
        try { URL(url).host.lowercase() } catch (_: Exception) { "" }

    private fun resolve(base: String, ref: String): String {
        if (ref.isBlank()) throw IllegalStateException("manifest has no list address")
        return URL(URL(base), ref).toString()
    }

    /**
     * GET with manual redirects. Returns the bytes when [sink] is null (small bodies), otherwise
     * streams into [sink] and updates [digest]. Throws on anything unexpected.
     */
    private fun fetch(
        startUrl: String,
        allowedHosts: Set<String>,
        maxBytes: Long,
        sink: File?,
        digest: MessageDigest? = null,
    ): ByteArray {
        var url = startUrl
        var hops = 0
        while (true) {
            val u = URL(url)
            if (!u.protocol.equals("https", ignoreCase = true)) throw IllegalStateException("only https is allowed")
            val host = u.host.lowercase()
            if (host !in allowedHosts) throw IllegalStateException("$host is not a trusted source")
            val conn = (u.openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                requestMethod = "GET"
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("User-Agent", "LockDistra-AdultListUpdater/1")
            }
            try {
                val code = conn.responseCode
                if (code in 301..308 && code != 304) {
                    if (++hops > MAX_REDIRECTS) throw IllegalStateException("too many redirects")
                    val loc = conn.getHeaderField("Location") ?: throw IllegalStateException("bad redirect")
                    url = URL(u, loc).toString()
                    continue
                }
                if (code != 200) throw IllegalStateException("server answered $code")
                val declared = conn.contentLengthLong
                if (declared > maxBytes) throw IllegalStateException("download is too large")
                conn.inputStream.use { input ->
                    val out: java.io.OutputStream = if (sink != null) FileOutputStream(sink) else java.io.ByteArrayOutputStream()
                    var total = 0L
                    out.use { o ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val r = input.read(buf)
                            if (r < 0) break
                            total += r
                            if (total > maxBytes) throw IllegalStateException("download is too large")
                            o.write(buf, 0, r)
                            digest?.update(buf, 0, r)
                        }
                        o.flush()
                        if (o is FileOutputStream) o.fd.sync()
                    }
                    return if (out is java.io.ByteArrayOutputStream) out.toByteArray() else ByteArray(0)
                }
            } finally {
                conn.disconnect()
            }
        }
    }

    /** True when an automatic check is due: protection on, auto-update on, and the last check is over a week old. */
    fun due(state: AdultState, now: Long = System.currentTimeMillis()): Boolean =
        state.enabled && state.autoUpdate && BuildConfig.ADULT_LIST_MANIFEST_URL.isNotBlank() &&
            now - state.lastCheckAt > 7L * 24 * 60 * 60 * 1000
}
