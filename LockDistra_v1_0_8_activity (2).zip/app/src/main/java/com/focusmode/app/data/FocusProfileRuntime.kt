package com.focusmode.app.data

/**
 * Decides which settings the blockers use while Focus Mode runs. Pure (no Android), so it can be unit-tested.
 *
 * The rule is simple: while a focus session runs and a saved Focus Profile is selected, that one profile's
 * settings are the Focus restrictions (instead of the phone-wide Focus lists). In every other situation
 * (no session, a Pomodoro Break, no profile saved, selection missing) [active] is null and the blockers
 * behave exactly as before. Nothing is copied or written: the profile and the global settings stay
 * untouched, so switching the profile or ending the session needs no clean-up.
 */
object FocusProfileRuntime {

    /** The profile that controls the running session, or null (use the phone-wide Focus settings). */
    fun active(focus: FocusState, profiles: FocusProfilesState): FocusProfile? =
        if (focus.focusActive) profiles.selected else null

    /** Apps (and games) blocked by the session. */
    fun blocked(focus: FocusState, profile: FocusProfile?): Set<String> =
        profile?.settings?.blocked ?: focus.blocked

    /** YouTube Shorts blocking of the session. */
    fun blockShorts(focus: FocusState, profile: FocusProfile?): Boolean =
        profile?.settings?.blockShorts ?: focus.blockShorts

    /**
     * Section blocks (Reels, Status ...) of the session. A profile replaces the phone-wide switches and the
     * user's own sections ("Inside apps" is not part of a profile); the educational-channel exceptions for
     * Shorts are not blocks and stay as they are.
     */
    fun content(global: ContentState, profile: FocusProfile?): ContentState =
        if (profile == null) global
        else global.copy(
            enabledFeatures = profile.settings.features.filterTo(HashSet()) { FeatureCatalog.byId(it) != null },
            customSections = emptyList(),
        )

    /** Website rules the profile adds while its session runs (empty without a profile). */
    fun websites(profile: FocusProfile?): WebsiteState? = profile?.settings?.websites

    /**
     * The limit in force for [pkg]: the normal daily limit, the profile's limit, or the stricter of the two.
     * Both count against the same usage of the day, and the normal limit is never changed.
     */
    fun limitFor(normal: AppLimit?, profile: FocusProfile?, pkg: String): AppLimit? {
        val own = profile?.settings?.limits?.firstOrNull { it.pkg == pkg && it.limitMin > 0 } ?: return normal
        if (normal == null) return own
        return if (own.limitMin < normal.limitMin) own else normal
    }

    /** Apps whose usage must be counted: those with a normal limit plus those the profile limits. */
    fun limitedPackages(normal: Collection<String>, profile: FocusProfile?): Set<String> =
        normal.toHashSet().also { set ->
            profile?.settings?.limits?.filter { it.limitMin > 0 }?.mapTo(set) { it.pkg }
        }

    fun hasProfileLimits(profile: FocusProfile?): Boolean =
        profile?.settings?.limits?.any { it.limitMin > 0 } == true

    /**
     * Website rules to enforce, as (rules, owner app) pairs. Without a profile this is the old behaviour:
     * the phone-wide rules, in force while the session blocks the app or its limit is used up.
     * With a profile the phone-wide rules keep working only through their app's daily limit (as outside a
     * session) and the profile's own rules take the place of the session part.
     */
    fun websiteRules(
        global: WebsiteState,
        profile: FocusProfile?,
        focusActive: Boolean,
        sessionOpensOwner: (String) -> Boolean,
        limitBlocks: (String) -> Boolean,
        extraTime: (String) -> Boolean,
    ): List<Pair<WebsiteState, String>> {
        val out = ArrayList<Pair<WebsiteState, String>>()
        val profileSites = websites(profile)
        for (owner in global.activeOwners()) {
            val session = focusActive && profileSites == null && !sessionOpensOwner(owner)
            if (WebsitePolicy.shouldEnforce(session, limitBlocks(owner), extraTime(owner))) out += global to owner
        }
        if (profileSites != null) {
            for (owner in profileSites.activeOwners()) {
                val session = !sessionOpensOwner(owner)
                if (WebsitePolicy.shouldEnforce(session, limitBlocks(owner), extraTime(owner))) out += profileSites to owner
            }
        }
        return out
    }

    /** First rule that covers [host], with the app that owns it. */
    fun firstMatch(rules: List<Pair<WebsiteState, String>>, host: String): Pair<String, WebsiteRule>? {
        for ((state, owner) in rules) state.firstMatch(host, listOf(owner))?.let { return it }
        return null
    }

    /** Short text for the status notification: how many apps the session blocks. */
    fun blockedCount(focus: FocusState, profile: FocusProfile?): Int = blocked(focus, profile).size
}
