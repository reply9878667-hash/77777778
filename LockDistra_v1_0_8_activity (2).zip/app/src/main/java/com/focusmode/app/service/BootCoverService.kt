package com.focusmode.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.UserManager
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.focusmode.app.R
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.SafetyConfig
import com.focusmode.app.data.Storage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Does the work of the after-restart cover: shows [BootCover], keeps it on screen (and puts it back if Android
 * dropped the window), and removes it once the accessibility service is connected again.
 *
 * Safety first: it never stays longer than [MAX_MS] after the phone is unlocked ([HARD_MAX_MS] in total), so it can
 * never lock the person out of their phone.
 */
internal class BootCoverRunner(
    private val context: Context,
    private val preview: Boolean,
    private val onDone: () -> Unit,
) {
    /** Extra hook for the hosting service (stop itself when the cover is finished). */
    var onFinished: (() -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())
    private var cover = BootCover(context)
    private val startedAt = SystemClock.elapsedRealtime()
    private var unlockedAt = 0L
    private var connectedAt = 0L
    private var fullAt = 0L
    private var finished = false

    private val tick = object : Runnable {
        override fun run() {
            if (finished) return
            val now = SystemClock.elapsedRealtime()
            // The window can fail before the first unlock or be dropped by the system: put it back.
            if (!cover.isShowing) cover.show()
            handOverToAccessibilityOverlay()
            if (preview) {
                if (now - startedAt >= PREVIEW_MS) finish("Test cover shown") else handler.postDelayed(this, 300)
                return
            }
            if (AppBlockerService.connected && connectedAt == 0L) connectedAt = now
            if (AppBlockerService.fullyConnected && fullAt == 0L) fullAt = now
            if (unlockedAt == 0L && isUnlocked()) unlockedAt = now
            // The cover stays until LockDistra is REALLY working: unlocked, the full start-up finished, plus a short
            // grace, and never shorter than MIN_AFTER_UNLOCK_MS after unlock (so it is actually seen).
            // If the full start-up never finishes, the uninstall guard is still running (connected), so the cover
            // goes after FALLBACK_AFTER_UNLOCK_MS instead of blocking the phone.
            val ready = unlockedAt != 0L && now - unlockedAt >= MIN_AFTER_UNLOCK_MS &&
                ((fullAt != 0L && now - fullAt >= READY_EXTRA_MS) ||
                    (connectedAt != 0L && now - unlockedAt >= FALLBACK_AFTER_UNLOCK_MS))
            val timedOut = (unlockedAt != 0L && now - unlockedAt >= MAX_MS) || now - startedAt >= HARD_MAX_MS
            when {
                ready -> finish("Cover shown for ${(now - startedAt) / 1000}s, removed when protection was running")
                timedOut -> finish("Cover shown, removed after the time limit (protection did not start)")
                else -> handler.postDelayed(this, 400)
            }
        }
    }

    /**
     * As soon as the accessibility service is connected, the cover is redrawn as an accessibility overlay and the
     * normal "display over other apps" window is removed. Android's "Screen overlay detected" warning (the one with the
     * "Open settings" button that leads to switching the overlay off) only appears for the normal app overlay.
     */
    private fun handOverToAccessibilityOverlay() {
        if (cover.isAccessibility) return
        val svc = AppBlockerService.instance ?: return
        try {
            val next = BootCover(context, svc)
            next.show()
            if (next.isShowing) {
                val old = cover
                cover = next
                old.hide()
            }
        } catch (_: Exception) {
        }
    }

    private fun isUnlocked(): Boolean =
        Build.VERSION.SDK_INT < 24 ||
            (context.getSystemService(Context.USER_SERVICE) as UserManager).isUserUnlocked

    fun start() {
        cover.show()
        handler.post(tick)
    }

    private fun finish(message: String) {
        if (finished) return
        finished = true
        handler.removeCallbacks(tick)
        cover.hide()
        if (!preview) BootCoverService.log(context, message, force = true)
        onDone()
        onFinished?.invoke()
    }

    fun stop() {
        if (finished) return
        finished = true
        handler.removeCallbacks(tick)
        cover.hide()
    }

    private companion object {
        const val MAX_MS = 90_000L
        const val HARD_MAX_MS = 10 * 60_000L
        const val PREVIEW_MS = 5_000L
        const val READY_EXTRA_MS = 2_000L
        const val MIN_AFTER_UNLOCK_MS = 4_000L
        const val FALLBACK_AFTER_UNLOCK_MS = 10_000L
    }
}

/**
 * Hosts the after-restart cover in a foreground service, so Android keeps the process alive while it is on screen.
 * Started by [BootReceiver] right after the restart (it runs before the first unlock too) and again when the phone
 * is unlocked, and by the app's own start-up when the process was started by the restart.
 */
class BootCoverService : Service() {

    /** False when the cover lives on without this service (the service was refused and stops at once). */
    private var ownsRunner = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService() needs startForeground() within seconds, so promote first.
        Notifications.ensureChannels(this)
        val notification = NotificationCompat.Builder(this, Notifications.CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("LockDistra")
            .setContentText("Setting up protection…")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        val preview = intent?.getBooleanExtra(EXTRA_PREVIEW, false) == true
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID, notification)
            }
        } catch (_: Exception) {
            // Android won't let this service run in the foreground now: the cover keeps running in the app process.
            ownsRunner = false
            showNow(applicationContext, preview, "foreground service refused")
            stopSelf()
            return START_NOT_STICKY
        }
        // The cover is normally already on screen (BootReceiver / FocusApplication show it before this service even
        // starts). This service only keeps the process alive and stops itself when the cover is done.
        if (currentRunner() == null) {
            val why = if (preview) (if (Settings.canDrawOverlays(this)) null else "no overlay permission") else blockedReason(this)
            if (why != null) {
                log(this, "Cover not shown: $why")
                stopSelf()
                return START_NOT_STICKY
            }
            log(this, "Cover shown (waiting for protection to start)")
        }
        val hosted = showNow(applicationContext, preview, null)
        hosted.onFinished = {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (ownsRunner) stopRunner()
        super.onDestroy()
    }

    companion object {
        private const val ID = 1007
        private const val EXTRA_PREVIEW = "preview"
        private const val PREFS = "boot_cover"

        /** The one cover of this process (main thread only). Shared by the service and the in-process path. */
        private var runner: BootCoverRunner? = null

        private fun currentRunner(): BootCoverRunner? = runner

        /** Shows the cover on screen immediately (or returns the one already showing). Main thread. */
        private fun showNow(app: Context, preview: Boolean, logReason: String?): BootCoverRunner {
            runner?.let { return it }
            if (logReason != null && !preview) log(app, "Cover shown without the service ($logReason)")
            return BootCoverRunner(app, preview) { runner = null }.also {
                runner = it
                it.start()
            }
        }

        private fun stopRunner() {
            runner?.stop()
            runner = null
        }

        private fun onMain(block: () -> Unit) {
            if (Looper.myLooper() == Looper.getMainLooper()) block() else Handler(Looper.getMainLooper()).post(block)
        }

        /** Why the cover must NOT show right now (plain words), or null when it should. Never throws. */
        fun blockedReason(context: Context): String? = try {
            when {
                !SafetyConfig.UNINSTALL_PROTECTION -> "not available in this build"
                AppBlockerService.connected -> "protection was already running"
                !Settings.canDrawOverlays(context) -> "\"Display over other apps\" is not allowed"
                // Right after a restart the system settings / device-policy answers can be late or empty, so a
                // remembered "was on when last seen" answer counts too (kept in device-protected storage).
                !(Permissions.isAccessibilityEnabled(context) || remembered(context, K_ACC)) -> "Accessibility service is off"
                !(Permissions.isAdminActive(context) || remembered(context, K_ADMIN) ||
                    FocusStore.get(context).current().let { it.advancedProtection || it.focusActive }) ->
                    "Uninstall protection / Advanced protection is off"
                else -> null
            }
        } catch (e: Exception) {
            "check failed (${e.javaClass.simpleName})"
        }

        private const val K_ACC = "acc_on"
        private const val K_ADMIN = "admin_on"

        private fun remembered(context: Context, key: String): Boolean =
            try { Storage.prefs(context, PREFS).getBoolean(key, false) } catch (_: Exception) { false }

        private fun remember(context: Context, key: String, on: Boolean) {
            try { Storage.prefs(context, PREFS).edit().putBoolean(key, on).apply() } catch (_: Exception) {}
        }

        /** Last known "device admin is on" answer (device-protected storage, usable right after a restart). */
        fun rememberedAdmin(context: Context): Boolean = remembered(context, K_ADMIN)

        /** Called by the accessibility service when it connects / unbinds. */
        fun rememberAccessibility(context: Context, on: Boolean) = remember(context, K_ACC, on)

        /** Called by the device-admin receiver when the admin is switched on / off. */
        fun rememberAdmin(context: Context, on: Boolean) = remember(context, K_ADMIN, on)

        /** What is missing for the cover to appear after a restart (empty = all set). Plain words for the Settings screen. */
        fun missing(
            overlay: Boolean,
            deviceAdmin: Boolean,
            accessibility: Boolean,
            advancedProtection: Boolean,
        ): List<String> = buildList {
            if (!SafetyConfig.UNINSTALL_PROTECTION) add("not available in this build")
            if (!overlay) add("\"Display over other apps\" permission")
            if (!accessibility) add("Accessibility service")
            if (!deviceAdmin && !advancedProtection) add("Uninstall protection (Device admin) or Advanced protection")
        }

        /** Kept for older callers: true when the cover would show now. */
        fun shouldShow(context: Context): Boolean = blockedReason(context) == null

        /**
         * Starts the cover when it is useful. [source] only goes into the small log shown in Settings.
         *
         * The window is added RIGHT HERE, synchronously, before the foreground service is even asked to start. The
         * service only keeps the process alive; going through it first cost the cover several hundred ms to seconds.
         */
        fun startIfNeeded(context: Context, source: String = "restart signal") {
            val app = context.applicationContext
            val why = blockedReason(app)
            if (why != null) {
                log(app, "Cover not shown ($source): $why")
                trace(app, "cover NOT shown ($source): $why")
                return
            }
            trace(app, "cover shown ($source)")
            onMain {
                if (runner == null) log(app, "Cover shown ($source)")
                try {
                    showNow(app, preview = false, logReason = null)
                } catch (_: Exception) {
                }
            }
            try {
                ContextCompat.startForegroundService(app, Intent(app, BootCoverService::class.java))
            } catch (_: Exception) {
                // The cover is already on screen and runs in the app process on its own.
            }
        }

        /** Shows the cover for 5 seconds so the person can see what it looks like (needs the permission only). */
        fun preview(context: Context): Boolean {
            val app = context.applicationContext
            if (!Settings.canDrawOverlays(app)) return false
            return try {
                ContextCompat.startForegroundService(
                    app, Intent(app, BootCoverService::class.java).putExtra(EXTRA_PREVIEW, true)
                )
                true
            } catch (_: Exception) {
                onMain { showNow(app, preview = true, logReason = null) }
                true
            }
        }

        // ---- the small log shown in Settings -------------------------------------------------

        private fun bootKey(): Long = (System.currentTimeMillis() - SystemClock.elapsedRealtime()) / 120_000L

        /**
         * Remembers what happened at the last restart. Within one restart a "cover shown" line is not replaced by a
         * later "not shown" line (the second start signal of the same restart), unless [force].
         */
        fun log(context: Context, message: String, force: Boolean = false) {
            try {
                val p = Storage.prefs(context, PREFS)
                val sameBoot = p.getLong("boot", -1L) == bootKey()
                val old = p.getString("last", "").orEmpty()
                if (!force && sameBoot && old.startsWith("Cover shown") && message.startsWith("Cover not shown")) return
                val time = SimpleDateFormat("d MMM, HH:mm:ss", Locale.getDefault()).format(Date())
                p.edit().putLong("boot", bootKey()).putString("last", "$time: $message").apply()
            } catch (_: Exception) {
            }
        }

        // ---- restart trace: what happened, second by second since the restart (shown in Settings) ----------

        /** Adds one line ("12s: LockDistra accessibility connected BEFORE unlock"). Only within 10 minutes of a restart. */
        fun trace(context: Context, message: String) {
            try {
                val sec = SystemClock.elapsedRealtime() / 1000L
                if (sec > 600L) return
                val p = Storage.prefs(context, PREFS)
                val sameBoot = p.getLong("trace_boot", -1L) == bootKey()
                val old = if (sameBoot) p.getString("trace", "").orEmpty() else ""
                val lines = (old.split('\n').filter { it.isNotBlank() } + "${sec}s: $message").takeLast(12)
                p.edit().putLong("trace_boot", bootKey()).putString("trace", lines.joinToString("\n")).apply()
            } catch (_: Exception) {
            }
        }

        fun traceLog(context: Context): String =
            try { Storage.prefs(context, PREFS).getString("trace", "").orEmpty() } catch (_: Exception) { "" }

        fun lastLog(context: Context): String =
            try { Storage.prefs(context, PREFS).getString("last", "").orEmpty() } catch (_: Exception) { "" }
    }
}
