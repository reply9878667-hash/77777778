package com.focusmode.app.data

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/*
 * App lock rules (Task 5), kept free of Android classes so they can be unit tested on a plain JVM
 * (see app/src/test/.../AppLockPolicyTest.kt). LockStore does the storing; this file does the maths.
 */

enum class LockType { PIN, PASSWORD }

/** Answer of a PIN / password / recovery code check. */
sealed interface VerifyResult {
    object Ok : VerifyResult

    /** Wrong secret. [lockedForMs] > 0 means further tries are paused for that long. */
    data class Wrong(val failures: Int, val lockedForMs: Long) : VerifyResult

    /** Too many wrong tries; nothing was checked. */
    data class LockedOut(val remainingMs: Long) : VerifyResult

    /** The stored credential can't be read any more (for example the Keystore key was lost). */
    object Unreadable : VerifyResult
}

object LockRules {

    const val PIN_MIN = 4
    const val PIN_MAX = 8
    const val PASSWORD_MIN = 6
    const val PASSWORD_MAX = 32

    /** Wrong tries allowed before the pauses start. */
    const val FREE_TRIES = 5

    /** Allowed values of "lock after leaving the app", in seconds. 0 = immediately. */
    val AUTO_LOCK_CHOICES = listOf(0, 5, 10, 30, 60, 300)

    /** After a short trip to a system screen the app started itself (permissions), be a bit kinder. */
    const val INTERNAL_LAUNCH_GRACE_MS = 5 * 60_000L

    /** A launch counts as "ours" only if the app really went to the background right after it. */
    const val INTERNAL_LAUNCH_WINDOW_MS = 3_000L

    /** Returns an error text, or null when [secret] is acceptable as a new [type]. */
    fun validate(type: LockType, secret: String): String? = when (type) {
        LockType.PIN -> when {
            secret.length < PIN_MIN -> "Use at least $PIN_MIN digits."
            secret.length > PIN_MAX -> "Use at most $PIN_MAX digits."
            !secret.all { it in '0'..'9' } -> "A PIN can only have digits."
            isTooSimple(secret) -> "That PIN is too easy to guess. Avoid 1111, 1234 and similar."
            else -> null
        }

        LockType.PASSWORD -> when {
            secret.length < PASSWORD_MIN -> "Use at least $PASSWORD_MIN characters."
            secret.length > PASSWORD_MAX -> "Use at most $PASSWORD_MAX characters."
            secret.isBlank() -> "A password can't be only spaces."
            secret.toSet().size < 3 -> "Use at least 3 different characters."
            else -> null
        }
    }

    /** All the same digit, or a straight run up or down (1234, 8765). */
    fun isTooSimple(pin: String): Boolean {
        if (pin.isEmpty()) return true
        if (pin.all { it == pin[0] }) return true
        val up = pin.zipWithNext().all { (a, b) -> b - a == 1 }
        val down = pin.zipWithNext().all { (a, b) -> a - b == 1 }
        return up || down
    }

    /** How long to pause after the [failures]-th wrong try in a row. */
    fun lockoutMs(failures: Int): Long = when {
        failures < FREE_TRIES -> 0L
        failures == FREE_TRIES -> 30_000L
        failures == FREE_TRIES + 1 -> 60_000L
        failures == FREE_TRIES + 2 -> 5 * 60_000L
        failures == FREE_TRIES + 3 -> 15 * 60_000L
        else -> 60 * 60_000L
    }

    const val MAX_LOCKOUT_MS = 60 * 60_000L

    fun triesLeftBeforePause(failures: Int): Int = (FREE_TRIES - failures).coerceAtLeast(0)

    /**
     * Whether the app must show the lock screen again when it comes back to the front.
     * [awayMs] is how long it was out of sight. [viaOwnLaunch] is true when it left because it
     * opened a system screen itself (Accessibility settings, device admin ...).
     */
    fun shouldRelock(
        enabled: Boolean,
        unlocked: Boolean,
        awayMs: Long,
        graceSeconds: Int,
        viaOwnLaunch: Boolean,
    ): Boolean {
        if (!enabled || !unlocked) return false
        val graceMs = graceSeconds.coerceAtLeast(0) * 1000L
        val limit = if (viaOwnLaunch) maxOf(graceMs, INTERNAL_LAUNCH_GRACE_MS) else graceMs
        return awayMs >= limit
    }

    fun formatWait(ms: Long): String {
        val total = ((ms + 999) / 1000).coerceAtLeast(0)
        val m = total / 60
        val s = total % 60
        return if (m > 0) "%d:%02d".format(m, s) else "${s}s"
    }
}

/**
 * "Prevent changes": while it is on, no limit, blocked app or setting can be changed until the
 * person proves who they are (app PIN / password, recovery code, or an approval from the trusted
 * phone). Proving it opens a short editing window, then everything locks again by itself.
 * Times are monotonic (SystemClock.elapsedRealtime), so changing the phone's date does nothing.
 */
object ChangeWindowRules {

    /** How long changes stay open after a successful check. */
    const val WINDOW_MS = 5 * 60_000L

    fun isOpen(openedAt: Long, now: Long): Boolean =
        openedAt > 0L && now >= openedAt && now - openedAt < WINDOW_MS

    fun remainingMs(openedAt: Long, now: Long): Long =
        if (isOpen(openedAt, now)) WINDOW_MS - (now - openedAt) else 0L

    /**
     * Right after "Prevent changes" is switched ON, everything stays editable for this long, so a switch that was
     * turned on by mistake can still be turned off (or Prevent changes itself switched off). Then it locks.
     */
    const val GRACE_MS = 10_000L

    fun isGraceOpen(startedAt: Long, now: Long): Boolean =
        startedAt > 0L && now >= startedAt && now - startedAt < GRACE_MS

    fun graceRemainingMs(startedAt: Long, now: Long): Long =
        if (isGraceOpen(startedAt, now)) GRACE_MS - (now - startedAt) else 0L

    /** True when changes are blocked right now. */
    fun isLocked(prevent: Boolean, openedAt: Long, now: Long): Boolean =
        prevent && !isOpen(openedAt, now)

    /** An error text, or null when "Prevent changes" may be switched on (there must be a way to unlock it). */
    fun canTurnOn(passwordLockSet: Boolean, phoneConnected: Boolean): String? =
        if (passwordLockSet || phoneConnected) null
        else "Turn on App lock or connect a trusted phone first, so you can unlock changes later."
}

/** Hashing and recovery codes. PBKDF2 (HMAC-SHA256) with a random salt per secret. */
object Credentials {

    const val ITERATIONS = 120_000
    private const val KEY_BITS = 256
    private const val SALT_BYTES = 16

    // No 0/O/1/I so a code read off paper can't be mistyped.
    const val RECOVERY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    const val RECOVERY_LENGTH = 16

    private val random = SecureRandom()

    fun newSalt(): ByteArray = ByteArray(SALT_BYTES).also { random.nextBytes(it) }

    fun hash(secret: String, salt: ByteArray, iterations: Int = ITERATIONS): ByteArray {
        val spec = PBEKeySpec(secret.toCharArray(), salt, iterations, KEY_BITS)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    fun equal(a: ByteArray, b: ByteArray): Boolean = MessageDigest.isEqual(a, b)

    fun b64(bytes: ByteArray): String = Base64.getEncoder().withoutPadding().encodeToString(bytes)
    fun unb64(text: String): ByteArray = Base64.getDecoder().decode(text)

    /** 16 characters = 80 bits, shown as XXXX-XXXX-XXXX-XXXX. */
    fun newRecoveryCode(rng: SecureRandom = random): String {
        val raw = buildString {
            repeat(RECOVERY_LENGTH) { append(RECOVERY_ALPHABET[rng.nextInt(RECOVERY_ALPHABET.length)]) }
        }
        return formatRecovery(raw)
    }

    fun formatRecovery(raw: String): String = raw.chunked(4).joinToString("-")

    /** Upper case, spaces and dashes removed, so "abcd efgh..." matches "ABCD-EFGH-...". */
    fun normalizeRecovery(input: String): String =
        input.uppercase().filter { it in RECOVERY_ALPHABET }

    fun isRecoveryShapeValid(input: String): Boolean =
        normalizeRecovery(input).length == RECOVERY_LENGTH
}
