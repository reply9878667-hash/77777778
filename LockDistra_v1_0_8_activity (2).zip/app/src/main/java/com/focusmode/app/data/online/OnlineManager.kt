package com.focusmode.app.data.online

import android.content.Context
import com.focusmode.app.data.ChangeGuard
import com.focusmode.app.data.Credentials
import com.focusmode.app.data.auth.AccountHost
import com.focusmode.app.data.FocusOffRules
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.LockSession
import com.focusmode.app.data.LockStore
import com.focusmode.app.data.VerifyResult
import com.focusmode.app.service.Notifications
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull

// ---- What the screens show --------------------------------------------------------------------------

sealed interface UnlockUi {
    object Idle : UnlockUi
    object Sending : UnlockUi

    /** [expiresAt] is server time in milliseconds. */
    data class Waiting(val expiresAt: Long) : UnlockUi
    object Approved : UnlockUi
    object Rejected : UnlockUi
    object Expired : UnlockUi
    data class Failed(val message: String) : UnlockUi
}

/** The locked phone's "more time in one app" request, for the block screen of [pkg]. */
sealed interface AppUnlockUi {
    object Idle : AppUnlockUi
    data class Sending(val pkg: String) : AppUnlockUi

    /** [expiresAt] is server time in milliseconds. */
    data class Waiting(val pkg: String, val expiresAt: Long) : AppUnlockUi
    data class Granted(val pkg: String, val minutes: Int) : AppUnlockUi
    data class Rejected(val pkg: String) : AppUnlockUi
    data class Expired(val pkg: String) : AppUnlockUi
    data class Failed(val pkg: String, val message: String) : AppUnlockUi
}

sealed interface PairingUi {
    object Idle : PairingUi
    object Creating : PairingUi
    data class WaitingForPhone(val code: String) : PairingUi
    data class ConfirmPhone(val deviceName: String) : PairingUi
    object Linking : PairingUi

    /** [recoveryCode] is shown once; only its hash is kept. */
    data class Done(val recoveryCode: String) : PairingUi
    data class Failed(val message: String) : PairingUi
}

sealed interface JoinUi {
    object Idle : JoinUi
    data class Working(val message: String) : JoinUi
    data class Done(val ownerName: String) : JoinUi
    data class Failed(val message: String) : JoinUi
}

/**
 * One open request on the trusted phone. [pkg] / [appName] / [reason] are set for a "more time in
 * one app" request (the trusted phone then types the minutes); they were checked against the
 * request's MAC before this item was made.
 */
data class ApprovalItem(
    val id: String,
    val deviceName: String,
    val expiresAt: Long,
    val pkg: String? = null,
    val appName: String? = null,
    val reason: Int = 0,
) {
    val isApp: Boolean get() = pkg != null
}

/**
 * Online Approval, start to finish. One instance per process, shared by the screens and the push
 * service. It owns no UI; screens read its StateFlows.
 *
 * Locked phone:  pair (code) -> "Request to unlock" -> wait for the answer -> verify -> unlock.
 * Trusted phone: join (code) -> gets the request (push + live) -> Approve / Reject.
 */
class OnlineManager private constructor(context: Context) {

    private val app = context.applicationContext
    private val store = OnlineStore.get(app)
    private val lockStore = LockStore.get(app)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val state: StateFlow<OnlineState> = store.state
    val connected: StateFlow<Boolean> = FirebaseGateway.connected
    val configured: Boolean get() = OnlineConfig.configured
    val pushConfigured: Boolean get() = OnlineConfig.workerUrl.isNotEmpty()

    /** True when the build has an Android app id, so this phone can get a push token at all. */
    val pushAppIdOk: Boolean get() = OnlineConfig.appIdIsAndroid

    /** Call when a screen that needs the network opens, so the connection status is live. */
    fun start() {
        if (configured) FirebaseGateway.start(app)
    }

    fun serverNow(): Long = FirebaseGateway.serverNow()

    // =========================================================================================
    // Locked phone: ask for an unlock
    // =========================================================================================

    private val _unlockUi = MutableStateFlow<UnlockUi>(UnlockUi.Idle)
    val unlockUi: StateFlow<UnlockUi> = _unlockUi.asStateFlow()
    private var unlockJob: Job? = null
    private var activeRequest: Pair<String, String>? = null // ownerUid to requestId

    /**
     * [forChanges] = the request is for "Prevent changes" (opens the short editing window), not for
     * the app lock screen. The trusted phone sees the same kind of request either way.
     */
    fun requestUnlock(forChanges: Boolean = false, forFocusOff: Boolean = false) {
        if (unlockJob?.isActive == true) return
        unlockJob = scope.launch { runUnlock(forChanges, forFocusOff) }
    }

    /** Back to the start (after a rejection, an expiry or an error). */
    fun resetUnlock() {
        if (unlockJob?.isActive != true) _unlockUi.value = UnlockUi.Idle
    }

    /** Approved was shown and the lock is open: go back to the start so nothing stays on "Opening...". */
    fun finishApproved() {
        if (_unlockUi.value is UnlockUi.Approved) _unlockUi.value = UnlockUi.Idle
    }

    fun cancelUnlock() {
        unlockJob?.cancel()
        unlockJob = null
        val active = activeRequest
        activeRequest = null
        _unlockUi.value = UnlockUi.Idle
        if (active != null) scope.launch { FirebaseGateway.removeRequest(app, active.first, active.second) }
    }

    private suspend fun runUnlock(forChanges: Boolean, forFocusOff: Boolean = false) {
        val link = store.requesterLink()
        if (link == null) {
            _unlockUi.value = UnlockUi.Failed("No trusted phone is connected. Use your recovery code.")
            return
        }
        _unlockUi.value = UnlockUi.Sending
        try {
            start()
            val uid = FirebaseGateway.uid(app)
            val requestId = FirebaseGateway.newRequestId(app, uid)
            val nonce = ApprovalProtocol.newNonce()
            val deviceId = store.deviceId()
            val mac = ApprovalProtocol.requestMac(link.pairKey, uid, requestId, nonce, deviceId)
            FirebaseGateway.createRequest(app, uid, requestId, nonce, deviceId, store.deviceName(), mac)
            activeRequest = uid to requestId
            // Online for sure now: clear out anything old that an earlier request left behind.
            scope.launch { FirebaseGateway.purgeOldRequests(app, uid) }

            val sentAt = FirebaseGateway.serverNow()
            _unlockUi.value = UnlockUi.Waiting(sentAt + ApprovalProtocol.REQUEST_TTL_MS)
            // The push is a convenience: if it fails the request is still there for the trusted phone.
            scope.launch { FirebaseGateway.notifyApprover(app, requestId) }

            val expected = ExpectedRequest(uid, requestId, nonce, deviceId, link.approverUid, link.pairKey)
            val outcome = withTimeoutOrNull(ApprovalProtocol.REQUEST_TTL_MS + 3_000L) {
                FirebaseGateway.observeRequest(app, uid, requestId)
                    .map { snap ->
                        snap?.createdAt?.let { c ->
                            // Use the server's own start time for the countdown once it is known.
                            if (_unlockUi.value is UnlockUi.Waiting) {
                                _unlockUi.value = UnlockUi.Waiting(c + ApprovalProtocol.REQUEST_TTL_MS)
                            }
                        }
                        ApprovalProtocol.evaluate(snap, expected, FirebaseGateway.serverNow(), store.isUsed(requestId))
                    }
                    .first { it !is RequestOutcome.Pending }
            }

            when (outcome) {
                RequestOutcome.Approved -> {
                    // Spend it first (single use), then open. Telling the server is best effort.
                    store.markUsed(requestId)
                    // [forFocusOff] opens nothing here: the Focus OFF dialog sees Approved and ends the session itself.
                    if (!forFocusOff) {
                        if (forChanges) ChangeGuard.open(app) else LockSession.unlock()
                    }
                    _unlockUi.value = UnlockUi.Approved
                    // "Approved" is a moment, not a place to stay. Clearing it HERE (not from the
                    // lock screen, which disappears the instant the app opens) means the next time
                    // the lock screen comes up it starts clean and can never open by itself.
                    scope.launch {
                        delay(1_500)
                        finishApproved()
                    }
                    activeRequest = null
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                RequestOutcome.Rejected -> {
                    _unlockUi.value = UnlockUi.Rejected
                    activeRequest = null
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                is RequestOutcome.Invalid -> {
                    _unlockUi.value = UnlockUi.Failed(outcome.reason)
                    activeRequest = null
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                // Only "more time in one app" answers look like this; never a way into the app lock.
                is RequestOutcome.GrantedFor -> {
                    _unlockUi.value = UnlockUi.Failed("The answer was not for this request.")
                    activeRequest = null
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                RequestOutcome.Expired, RequestOutcome.Pending, null -> {
                    _unlockUi.value = UnlockUi.Expired
                    FirebaseGateway.removeRequest(app, uid, requestId)
                    activeRequest = null
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OnlineException) {
            activeRequest = null
            if (e.kind == OnlineException.Kind.PERMISSION && dropLinkIfGone(asLocked = true)) {
                _unlockUi.value = UnlockUi.Failed("The trusted phone is not connected any more. Use your recovery code, then connect again.")
            } else {
                _unlockUi.value = UnlockUi.Failed(friendly(e, whileUnlocking = true))
            }
        }
    }

    // =========================================================================================
    // Locked phone: Study Check-In missed
    // =========================================================================================

    /**
     * Study Check-In: asks the Worker to push "check-in missed" to the trusted phone. One authenticated request over
     * the same /notify route (the Worker finds the recipient from the database link, so only the connected trusted
     * phone can get it); nothing listens afterwards. [alertId] is the same for every retry of one miss, which the
     * Worker answers from its record, so a retry can never become a second alert. True = the Worker accepted it.
     */
    suspend fun notifyStudyCheckInMissed(alertId: String): Boolean {
        if (!configured || !pushConfigured || !store.current().phoneConnected) return false
        // A signed-in user is needed for the Worker's login check; this is a no-op when one already exists.
        runCatching { FirebaseGateway.uid(app) }.getOrNull() ?: return false
        return FirebaseGateway.notifyApprover(app, alertId, "checkin_missed")
    }

    // =========================================================================================
    // Locked phone: ask for more time in one app (from that app's block screen)
    // =========================================================================================

    private val _appUnlockUi = MutableStateFlow<AppUnlockUi>(AppUnlockUi.Idle)
    val appUnlockUi: StateFlow<AppUnlockUi> = _appUnlockUi.asStateFlow()
    private var appUnlockJob: Job? = null
    private var appUnlockPkg: String? = null
    private var appActiveRequest: Pair<String, String>? = null // ownerUid to requestId

    /** The block screen offers "Request to unlock" only when this is true. */
    fun canRequestAppUnlock(): Boolean = configured && store.current().phoneConnected

    /** Asks the trusted phone for more time in [pkg]. [reason] is the block screen's reason number. */
    fun requestAppUnlock(pkg: String, appName: String, reason: Int) {
        if (!AppUnlockRules.canRequest(reason) || !ApprovalProtocol.isValidPackageName(pkg)) return
        if (appUnlockJob?.isActive == true) {
            if (appUnlockPkg == pkg) return
            cancelAppUnlock()
        }
        appUnlockPkg = pkg
        appUnlockJob = scope.launch { runAppUnlock(pkg, AppUnlockRules.cleanName(appName, pkg), reason) }
    }

    /** Clears a finished answer (rejected, expired, error, granted). A running request is left alone. */
    fun resetAppUnlock() {
        val now = _appUnlockUi.value
        if (now !is AppUnlockUi.Sending && now !is AppUnlockUi.Waiting) _appUnlockUi.value = AppUnlockUi.Idle
    }

    fun cancelAppUnlock() {
        appUnlockJob?.cancel()
        appUnlockJob = null
        appUnlockPkg = null
        val active = appActiveRequest
        appActiveRequest = null
        _appUnlockUi.value = AppUnlockUi.Idle
        if (active != null) scope.launch { FirebaseGateway.removeRequest(app, active.first, active.second) }
    }

    /** Starts [pkg] after the trusted phone gave time. Best effort: the notification is the fallback. */
    private fun launchGrantedApp(pkg: String) {
        runCatching {
            val launch = app.packageManager.getLaunchIntentForPackage(pkg) ?: return
            launch.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            app.startActivity(launch)
        }
    }

    private suspend fun runAppUnlock(pkg: String, appName: String, reason: Int) {
        val link = store.requesterLink()
        if (link == null) {
            _appUnlockUi.value = AppUnlockUi.Failed(pkg, "No trusted phone is connected.")
            return
        }
        _appUnlockUi.value = AppUnlockUi.Sending(pkg)
        try {
            start()
            val uid = FirebaseGateway.uid(app)
            val requestId = FirebaseGateway.newRequestId(app, uid)
            val nonce = ApprovalProtocol.newNonce()
            val deviceId = store.deviceId()
            // The app, its name and the reason are inside the signed text, so they can't be changed
            // on the way (a different app name would only fool the person who approves).
            val mac = ApprovalProtocol.appRequestMac(link.pairKey, uid, requestId, nonce, deviceId, pkg, appName, reason)
            FirebaseGateway.createRequest(
                app, uid, requestId, nonce, deviceId, store.deviceName(), mac,
                AppRequestInfo(pkg, appName, reason),
            )
            appActiveRequest = uid to requestId
            scope.launch { FirebaseGateway.purgeOldRequests(app, uid) }

            val sentAt = FirebaseGateway.serverNow()
            _appUnlockUi.value = AppUnlockUi.Waiting(pkg, sentAt + ApprovalProtocol.REQUEST_TTL_MS)
            // The push is a convenience: if it fails the request is still there for the trusted phone.
            scope.launch { FirebaseGateway.notifyApprover(app, requestId) }

            val expected = ExpectedRequest(uid, requestId, nonce, deviceId, link.approverUid, link.pairKey, pkg, reason)
            val outcome = withTimeoutOrNull(ApprovalProtocol.REQUEST_TTL_MS + 3_000L) {
                FirebaseGateway.observeRequest(app, uid, requestId)
                    .map { snap ->
                        snap?.createdAt?.let { c ->
                            val shown = _appUnlockUi.value
                            if (shown is AppUnlockUi.Waiting && shown.pkg == pkg) {
                                _appUnlockUi.value = AppUnlockUi.Waiting(pkg, c + ApprovalProtocol.REQUEST_TTL_MS)
                            }
                        }
                        ApprovalProtocol.evaluate(snap, expected, FirebaseGateway.serverNow(), store.isUsed(requestId))
                    }
                    .first { it !is RequestOutcome.Pending }
            }

            when (outcome) {
                is RequestOutcome.GrantedFor -> {
                    // Spend it first (single use), then open the app for the granted time.
                    store.markUsed(requestId)
                    AppGrantStore.get(app).grant(pkg, outcome.minutes)
                    _appUnlockUi.value = AppUnlockUi.Granted(pkg, outcome.minutes)
                    appActiveRequest = null
                    // Open the app right away. Closing the block screen is not enough when that
                    // screen is already gone (user went Home) or the app was never really started.
                    launchGrantedApp(pkg)
                    runCatching { Notifications.postAppUnlocked(app, appName, outcome.minutes, pkg) }
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                RequestOutcome.Rejected -> {
                    _appUnlockUi.value = AppUnlockUi.Rejected(pkg)
                    appActiveRequest = null
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                is RequestOutcome.Invalid -> {
                    _appUnlockUi.value = AppUnlockUi.Failed(pkg, outcome.reason)
                    appActiveRequest = null
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                // A plain "Approved" has no time in it, so it can never open an app.
                RequestOutcome.Approved -> {
                    _appUnlockUi.value = AppUnlockUi.Failed(pkg, "The answer had no time in it.")
                    appActiveRequest = null
                    FirebaseGateway.removeRequest(app, uid, requestId)
                }
                RequestOutcome.Expired, RequestOutcome.Pending, null -> {
                    _appUnlockUi.value = AppUnlockUi.Expired(pkg)
                    FirebaseGateway.removeRequest(app, uid, requestId)
                    appActiveRequest = null
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OnlineException) {
            appActiveRequest = null
            _appUnlockUi.value = AppUnlockUi.Failed(pkg, friendly(e, whileUnlocking = true))
        }
    }

    // =========================================================================================
    // Both phones: keep the connection in step (disconnect on one side clears the other)
    // =========================================================================================

    // One live listener on links/{ownerUid} per role, only while the app is on screen. The server pushes a change
    // the moment the link is removed, so nothing is downloaded again and again; when the app is closed nothing runs
    // and the first thing the next start does is read the link once (the listener's first event).
    private var linkJob: Job? = null
    @Volatile private var appForeground = false

    /** MainActivity.onStart: the app is on screen, so the link is watched. */
    fun onAppForeground() {
        appForeground = true
        restartLinkSync()
        syncConnectionBackup()
    }

    // =========================================================================================
    // Connection backup: a connection survives logout, reinstall and a new phone (logged-in accounts)
    // =========================================================================================
    //
    // The link (links/{ownerUid}) lives on the server under the account's uid. What a phone loses on logout or reinstall
    // is its local copy of the pair key, so the key is stored with the link (readable only by the two phones, see
    // database.rules.json) and approverLinks/{approverUid}/{ownerUid} lets the trusted phone find its way back.
    private var backupJob: Job? = null

    /** Keeps the server copy complete and brings a missing local connection back. Safe to call any time; needs a logged-in account. */
    fun syncConnectionBackup() {
        if (!configured) return
        backupJob?.cancel()
        backupJob = scope.launch {
            try {
                syncConnectionBackupNow()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // Offline or refused: the next start tries again.
            }
        }
    }

    private suspend fun syncConnectionBackupNow() {
        // Only a logged-in account keeps one identity across logout and reinstall.
        if (store.current().accountEmail == null) return
        start()
        val uid = FirebaseGateway.uid(app)

        // 0. A disconnect that never reached the server is finished first, so the saved copy can't bring it back.
        store.pendingUnlink()?.let { (owner, approver) ->
            try {
                FirebaseGateway.deleteLink(app, owner)
            } catch (e: OnlineException) {
                if (e.kind != OnlineException.Kind.PERMISSION) throw e
            }
            if (approver.isNotEmpty()) runCatching { FirebaseGateway.deleteApproverIndex(app, approver, owner) }
            store.clearPendingUnlink()
        }

        val mine = store.requesterLink()
        val theirs = store.approverLink()
        var complete = true

        // 1. Locked phone: keep the server copy complete, or bring the connection back.
        if (mine != null) {
            val saved = FirebaseGateway.backupLink(app, uid, mine.approverUid, store.deviceName(), Credentials.b64(mine.pairKey))
            complete = complete && saved
        } else {
            val saved = FirebaseGateway.readLinkBackup(app, uid)
            val bytes = saved?.pairKey?.let { runCatching { Credentials.unb64(it) }.getOrNull() }
            if (saved != null && bytes != null && saved.approverUid != uid &&
                store.saveRequesterLink(saved.approverUid, saved.approverName, bytes)
            ) {
                store.setBackedUp(true)
                restartLinkSync()
            }
        }

        // 2. Trusted phone: check the saved copy, or find the phone that named this account and bring the connection back.
        if (theirs != null) {
            val saved = try {
                FirebaseGateway.readLinkBackup(app, theirs.ownerUid)
            } catch (e: OnlineException) {
                if (e.kind == OnlineException.Kind.PERMISSION) null else throw e
            }
            complete = complete && saved != null && saved.approverUid == uid && saved.pairKey != null
        } else {
            for (owner in FirebaseGateway.readOwnersOf(app, uid)) {
                val saved = try {
                    FirebaseGateway.readLinkBackup(app, owner.ownerUid)
                } catch (e: OnlineException) {
                    if (e.kind == OnlineException.Kind.PERMISSION) null else throw e
                }
                if (saved == null || saved.approverUid != uid) {
                    // The link is gone or names another phone now: drop the stale entry.
                    runCatching { FirebaseGateway.deleteApproverIndex(app, uid, owner.ownerUid) }
                    continue
                }
                val bytes = saved.pairKey?.let { runCatching { Credentials.unb64(it) }.getOrNull() } ?: continue
                if (store.saveApproverLink(owner.ownerUid, owner.ownerName, bytes)) {
                    store.setBackedUp(true)
                    registerPushToken(force = true)
                    restartLinkSync()
                    break
                }
            }
        }

        if (mine != null || theirs != null) store.setBackedUp(complete)
    }

    /**
     * Logout (or an expired login): the connection stays on the server and this phone only forgets its local copy;
     * the next login brings it back. Never throws the only copy away, and never while a session needs it.
     */
    private fun dropLocalConnectionAfterLogout() {
        if (!store.isBackedUp()) return
        if (disconnectBlockedReason() != null) return
        val st = store.current()
        if (st.phoneConnected) {
            store.setMode(UnlockGateRules.modeAfterUnlink(store.mode()))
            store.clearRequesterLinkLocalOnly()
            cancelUnlock()
            cancelAppUnlock()
            if (!lockStore.current().enabled) FocusStore.get(app).setPreventChanges(false, force = true)
        }
        if (st.isApprover) {
            stopApproverWatch()
            store.clearApproverLink()
            store.clearRegistered()
        }
        restartLinkSync()
    }

    /** MainActivity.onStop: let go of the listener. */
    fun onAppBackground() {
        appForeground = false
        linkJob?.cancel()
        linkJob = null
    }

    /** (Re)starts the watch after anything that changes the connection (paired, joined, disconnected, app start). */
    fun restartLinkSync() {
        linkJob?.cancel()
        linkJob = null
        if (!configured || !appForeground) return
        val st = store.current()
        if (!st.phoneConnected && !st.isApprover) return
        linkJob = scope.launch {
            try {
                start()
                val myUid = FirebaseGateway.uid(app)
                coroutineScope {
                    // This phone is the locked one: its link lives at links/<my uid>.
                    store.requesterLink()?.let { mine ->
                        launch {
                            FirebaseGateway.observeLink(app, myUid)
                                .catch { /* offline or refused: the next start checks again */ }
                                .collect { snap ->
                                    // A pairing / join in progress writes the link itself; never judge it half-way.
                                    if (pairingJob?.isActive == true) return@collect
                                    if (snap == null || snap.approverUid != mine.approverUid) onLinkGoneOnLockedPhone()
                                }
                        }
                    }
                    // This phone is the trusted one: the link lives at links/<owner uid>.
                    store.approverLink()?.let { theirs ->
                        launch {
                            FirebaseGateway.observeLink(app, theirs.ownerUid)
                                .catch { e ->
                                    // The rules only let the trusted phone read this path while the link exists and
                                    // names it. "Permission denied" therefore means the link is gone.
                                    if (e is OnlineException && e.kind == OnlineException.Kind.PERMISSION &&
                                        joinJob?.isActive != true
                                    ) onLinkGoneOnTrustedPhone()
                                }
                                .collect { snap ->
                                    if (joinJob?.isActive == true) return@collect
                                    if (snap == null || snap.approverUid != myUid) onLinkGoneOnTrustedPhone()
                                }
                        }
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: OnlineException) {
                // No network right now: the local state is kept, the next start checks again.
            }
        }
    }

    private fun toast(text: String) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            runCatching { android.widget.Toast.makeText(app, text, android.widget.Toast.LENGTH_LONG).show() }
        }
    }

    /** The trusted phone removed the connection: this (locked) phone forgets it too, so "Connect" shows again. */
    private fun onLinkGoneOnLockedPhone() {
        if (!store.current().phoneConnected) return
        clearLockedSide()
        toast("The trusted phone disconnected. Connect it again to use Online Approval.")
        restartLinkSync()
    }

    /** The locked phone removed the connection: this (trusted) phone forgets it too. */
    private fun onLinkGoneOnTrustedPhone() {
        if (!store.current().isApprover) return
        val ownerUid = store.approverLink()?.ownerUid
        stopApproverWatch()
        store.clearApproverLink()
        if (ownerUid != null) scope.launch {
            runCatching { FirebaseGateway.deleteApproverIndex(app, FirebaseGateway.uid(app), ownerUid) }
        }
        store.clearRegistered()
        scope.launch { runCatching { FirebaseGateway.removeToken(app) } }
        toast("The other phone disconnected. This phone is no longer a trusted phone.")
        restartLinkSync()
    }

    /** Everything the locked phone keeps about its trusted phone (same as a manual disconnect, minus the server call). */
    private fun clearLockedSide() {
        store.setMode(UnlockGateRules.modeAfterUnlink(store.mode()))
        store.clearRequesterLink()
        cancelUnlock()
        cancelAppUnlock()
        // "Prevent changes" needs a way to unlock it. Without the trusted phone and without an
        // app lock there is none left, so it goes off instead of locking everything for good.
        if (!lockStore.current().enabled) FocusStore.get(app).setPreventChanges(false, force = true)
    }

    /**
     * Safety net: a call was refused by the server. If the link really is gone there, clear the local copy so the
     * screen stops saying "connected". Returns true when the local link was cleared.
     */
    private suspend fun dropLinkIfGone(asLocked: Boolean): Boolean {
        return try {
            val uid = FirebaseGateway.uid(app)
            if (asLocked) {
                val mine = store.requesterLink() ?: return false
                val ownerUid = uid
                val gone = !FirebaseGateway.linkExists(app, ownerUid)
                if (gone && mine.approverUid.isNotEmpty()) { clearLockedSide(); true } else false
            } else {
                val theirs = store.approverLink() ?: return false
                // A refusal to read counts as "gone": the rules allow this phone to read the link only while it names it.
                val exists = try {
                    FirebaseGateway.linkExists(app, theirs.ownerUid)
                } catch (e: OnlineException) {
                    if (e.kind == OnlineException.Kind.PERMISSION) false else throw e
                }
                if (!exists) {
                    stopApproverWatch(); store.clearApproverLink(); store.clearRegistered(); true
                } else false
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            false
        }
    }

    // =========================================================================================
    // Locked phone: connect a trusted phone
    // =========================================================================================

    private val _pairingUi = MutableStateFlow<PairingUi>(PairingUi.Idle)
    val pairingUi: StateFlow<PairingUi> = _pairingUi.asStateFlow()
    private var pairingJob: Job? = null
    private var confirmGate: CompletableDeferred<Boolean>? = null
    private var pairingInvite: String? = null

    fun startPairing() {
        if (pairingJob?.isActive == true) return
        pairingJob = scope.launch { runPairing() }
    }

    fun cancelPairing() {
        pairingJob?.cancel()
        pairingJob = null
        val invite = pairingInvite
        pairingInvite = null
        _pairingUi.value = PairingUi.Idle
        if (invite != null) scope.launch { FirebaseGateway.cleanupPairing(app, invite, deleteClaim = true) }
    }

    /** The person's answer to "Connect this phone?". */
    fun confirmPairing(accept: Boolean) {
        confirmGate?.complete(accept)
    }

    fun clearPairingResult() {
        if (pairingJob?.isActive != true) _pairingUi.value = PairingUi.Idle
    }

    private suspend fun runPairing() {
        _pairingUi.value = PairingUi.Creating
        // Keeps the wait alive (and able to notify) if the person leaves the app.
        com.focusmode.app.service.PairingWatchService.start(app)
        var inviteId: String? = null
        try {
            start()
            val code = ApprovalProtocol.newPairCode()
            val id = ApprovalProtocol.inviteId(code)
            inviteId = id
            pairingInvite = id
            val key = ApprovalProtocol.pairKey(code)
            val uid = FirebaseGateway.uid(app)
            FirebaseGateway.createInvite(app, id, store.deviceName())
            _pairingUi.value = PairingUi.WaitingForPhone(ApprovalProtocol.formatPairCode(ApprovalProtocol.normalizePairCode(code)))

            val started = System.currentTimeMillis()
            val claim = withTimeoutOrNull(ApprovalProtocol.INVITE_TTL_MS) {
                FirebaseGateway.observeClaim(app, id).first { it != null && it.decision == null }
            }
            if (claim == null) {
                FirebaseGateway.cleanupPairing(app, id, deleteClaim = true)
                pairingInvite = null
                _pairingUi.value = PairingUi.Failed("The code expired. Make a new one.")
                return
            }
            if (claim.claimerUid == uid) {
                // A phone can't approve itself.
                FirebaseGateway.cleanupPairing(app, id, deleteClaim = true)
                pairingInvite = null
                _pairingUi.value = PairingUi.Failed("That is this same phone. Use a different phone.")
                return
            }

            _pairingUi.value = PairingUi.ConfirmPhone(claim.deviceName.take(40))
            val gate = CompletableDeferred<Boolean>().also { confirmGate = it }
            val left = (ApprovalProtocol.INVITE_TTL_MS - (System.currentTimeMillis() - started)).coerceAtLeast(1_000L)
            val accepted = withTimeoutOrNull(left) { gate.await() } ?: false
            confirmGate = null

            if (!accepted) {
                runCatching { FirebaseGateway.setClaimDecision(app, id, confirmed = false) }
                FirebaseGateway.cleanupPairing(app, id, deleteClaim = false)
                pairingInvite = null
                _pairingUi.value = PairingUi.Idle
                return
            }

            _pairingUi.value = PairingUi.Linking
            val name = claim.deviceName.take(40)
            if (!store.saveRequesterLink(claim.claimerUid, name, key)) {
                runCatching { FirebaseGateway.setClaimDecision(app, id, confirmed = false) }
                FirebaseGateway.cleanupPairing(app, id, deleteClaim = false)
                pairingInvite = null
                _pairingUi.value = PairingUi.Failed("This phone can't store the key safely (Android Keystore problem).")
                return
            }
            try {
                FirebaseGateway.createLink(app, uid, id, claim.claimerUid, name, pairKey = Credentials.b64(key))
                FirebaseGateway.setClaimDecision(app, id, confirmed = true)
            } catch (e: OnlineException) {
                store.clearRequesterLink()
                throw e
            }
            // The entry that lets the trusted phone find this phone again after a logout / reinstall (best effort; the
            // next app start repeats it).
            runCatching {
                if (FirebaseGateway.backupLink(app, uid, claim.claimerUid, store.deviceName(), Credentials.b64(key))) store.setBackedUp(true)
            }
            val recovery = store.newRecoveryCode()
            FirebaseGateway.cleanupPairing(app, id, deleteClaim = false)
            pairingInvite = null
            _pairingUi.value = PairingUi.Done(recovery)
            restartLinkSync()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OnlineException) {
            inviteId?.let { runCatching { FirebaseGateway.cleanupPairing(app, it, deleteClaim = true) } }
            pairingInvite = null
            _pairingUi.value = PairingUi.Failed(friendly(e))
        }
    }

    // =========================================================================================
    // Trusted phone: join with the code
    // =========================================================================================

    private val _joinUi = MutableStateFlow<JoinUi>(JoinUi.Idle)
    val joinUi: StateFlow<JoinUi> = _joinUi.asStateFlow()
    private var joinJob: Job? = null

    fun joinPairing(rawCode: String) {
        if (joinJob?.isActive == true) return
        joinJob = scope.launch { runJoin(rawCode) }
    }

    fun clearJoinResult() {
        if (joinJob?.isActive != true) _joinUi.value = JoinUi.Idle
    }

    fun cancelJoin() {
        joinJob?.cancel()
        joinJob = null
        _joinUi.value = JoinUi.Idle
    }

    private suspend fun runJoin(rawCode: String) {
        if (!ApprovalProtocol.isPairCodeShapeValid(rawCode)) {
            _joinUi.value = JoinUi.Failed("The code has ${ApprovalProtocol.PAIR_CODE_LENGTH} letters and numbers.")
            return
        }
        _joinUi.value = JoinUi.Working("Checking the code...")
        try {
            start()
            val id = ApprovalProtocol.inviteId(rawCode)
            val key = ApprovalProtocol.pairKey(rawCode)
            val uid = FirebaseGateway.uid(app)
            val invite = FirebaseGateway.readInvite(app, id)
            val tooOld = invite?.createdAt?.let { FirebaseGateway.serverNow() > it + ApprovalProtocol.INVITE_TTL_MS } ?: false
            if (invite == null || tooOld) {
                _joinUi.value = JoinUi.Failed("That code wasn't found, or it has expired.")
                return
            }
            if (invite.ownerUid == uid) {
                _joinUi.value = JoinUi.Failed("That code is from this same phone. Enter it on the other phone.")
                return
            }
            FirebaseGateway.submitClaim(app, id, store.deviceName())
            _joinUi.value = JoinUi.Working("Waiting for the other phone to confirm...")
            val answer = withTimeoutOrNull(ApprovalProtocol.INVITE_TTL_MS) {
                FirebaseGateway.observeClaim(app, id).first { it?.decision != null }
            }
            when (answer?.decision) {
                "confirmed" -> {
                    val ownerName = invite.deviceName?.take(40) ?: "Phone"
                    if (!store.saveApproverLink(invite.ownerUid, ownerName, key)) {
                        _joinUi.value = JoinUi.Failed("This phone can't store the key safely (Android Keystore problem).")
                        return
                    }
                    FirebaseGateway.cleanupPairing(app, id, deleteClaim = true)
                    registerPushToken(force = true)
                    _joinUi.value = JoinUi.Done(ownerName)
                    restartLinkSync()
                }
                "rejected" -> _joinUi.value = JoinUi.Failed("The other phone did not accept this phone.")
                else -> {
                    runCatching { FirebaseGateway.cleanupPairing(app, id, deleteClaim = true) }
                    _joinUi.value = JoinUi.Failed("No answer from the other phone. Try again.")
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OnlineException) {
            _joinUi.value = JoinUi.Failed(friendly(e))
        }
    }

    // =========================================================================================
    // Trusted phone: answer requests
    // =========================================================================================

    private val _approvals = MutableStateFlow<List<ApprovalItem>>(emptyList())
    val approvals: StateFlow<List<ApprovalItem>> = _approvals.asStateFlow()

    private val _approverError = MutableStateFlow<String?>(null)
    val approverError: StateFlow<String?> = _approverError.asStateFlow()
    private var watchJob: Job? = null

    fun startApproverWatch() {
        if (watchJob?.isActive == true) return
        val link = store.approverLink() ?: return
        watchJob = scope.launch {
            try {
                start()
                FirebaseGateway.uid(app)
                registerPushToken()
                FirebaseGateway.observePending(app, link.ownerUid)
                    .catch { e ->
                        if (e is OnlineException && e.kind == OnlineException.Kind.PERMISSION) {
                            dropLinkIfGone(asLocked = false)
                            _approverError.value = "This phone is no longer linked. Connect it again."
                        } else {
                            _approverError.value = "Connection lost. Retrying when the network is back."
                        }
                    }
                    .collect { list ->
                        _approverError.value = null
                        val now = FirebaseGateway.serverNow()
                        _approvals.value = list.filter {
                            ApprovalProtocol.approverMayAnswer(it.snap, link.ownerUid, it.id, it.mac, link.pairKey, now)
                        }.map {
                            val isApp = it.snap.kind == ApprovalProtocol.KIND_APP
                            ApprovalItem(
                                id = it.id,
                                deviceName = (it.deviceName ?: link.ownerName).take(40),
                                expiresAt = (it.snap.createdAt ?: now) + ApprovalProtocol.REQUEST_TTL_MS,
                                pkg = if (isApp) it.snap.pkg else null,
                                appName = if (isApp) it.snap.appName?.take(AppUnlockRules.MAX_NAME) else null,
                                reason = if (isApp) it.snap.reason ?: 0 else 0,
                            )
                        }.sortedByDescending { it.expiresAt }
                    }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: OnlineException) {
                _approverError.value = friendly(e)
            }
            // A dropped listener should be picked up again by the next call.
            watchJob = null
        }
    }

    fun stopApproverWatch() {
        watchJob?.cancel()
        watchJob = null
        _approvals.value = emptyList()
    }

    // Trusted phone: there is no permanent listener. The database is only listened to
    //  (a) for one request lifetime after the Worker's push arrives, and
    //  (b) while the Unlock requests screen is open.
    // Everything else is idle: no polling, no open listener, no background service.
    @Volatile private var screenWatching = false
    @Volatile private var pushWatchUntil = 0L
    private var pushStopJob: Job? = null

    /** The push arrived: listen live for one request lifetime, then let go. */
    fun onPushSignal() {
        if (!configured || !store.current().isApprover) return
        val window = ApprovalProtocol.REQUEST_TTL_MS + 5_000L
        pushWatchUntil = System.currentTimeMillis() + window
        startApproverWatch()
        pushStopJob?.cancel()
        pushStopJob = scope.launch {
            delay(window)
            if (!screenWatching) stopApproverWatch()
        }
    }

    /** The Unlock requests screen opened. */
    fun openApproverScreen() {
        screenWatching = true
        startApproverWatch()
    }

    /** The Unlock requests screen closed: stop listening unless a push window is still running. */
    fun closeApproverScreen() {
        screenWatching = false
        if (System.currentTimeMillis() >= pushWatchUntil) stopApproverWatch()
    }

    /**
     * Returns an error text, or null when the answer was sent. [minutes] is how long to open the
     * app for ("more time in one app" requests only; ignored for a rejection and for normal ones).
     */
    suspend fun answer(item: ApprovalItem, approve: Boolean, minutes: Int = 0): String? {
        val link = store.approverLink() ?: return "This phone is not a trusted phone any more."
        if (FirebaseGateway.serverNow() > item.expiresAt) return "That request has expired."
        return try {
            // Read the request fresh and verify it again before answering.
            val pending = FirebaseGateway.observePending(app, link.ownerUid).first().firstOrNull { it.id == item.id }
                ?: return "That request is no longer open."
            val snap = pending.snap
            val now = FirebaseGateway.serverNow()
            if (!ApprovalProtocol.approverMayAnswer(snap, link.ownerUid, item.id, pending.mac, link.pairKey, now)) {
                return "That request can't be verified or has expired."
            }
            val nonce = snap.nonce ?: return "That request can't be verified."
            val deviceId = snap.deviceId ?: return "That request can't be verified."
            val decision = if (approve) Decision.APPROVED else Decision.REJECTED
            // What the request says it is (read fresh from the database and already MAC-checked).
            val isApp = snap.kind == ApprovalProtocol.KIND_APP
            var grantMinutes: Int? = null
            // The proof is bound to this request, that phone and this decision (and the time).
            val proof = if (isApp) {
                val pkg = snap.pkg ?: return "That request can't be verified."
                val reason = snap.reason ?: return "That request can't be verified."
                val m = if (approve) minutes else 0
                if (approve && m !in ApprovalProtocol.MIN_GRANT_MIN..ApprovalProtocol.MAX_GRANT_MIN) {
                    return "Choose between ${ApprovalProtocol.MIN_GRANT_MIN} and ${ApprovalProtocol.MAX_GRANT_MIN} minutes."
                }
                grantMinutes = m
                ApprovalProtocol.appDecisionProof(link.pairKey, link.ownerUid, item.id, nonce, deviceId, pkg, reason, decision, m)
            } else {
                ApprovalProtocol.decisionProof(link.pairKey, link.ownerUid, item.id, nonce, deviceId, decision)
            }
            FirebaseGateway.decide(app, link.ownerUid, item.id, decision, proof, grantMinutes)
            _approvals.value = _approvals.value.filterNot { it.id == item.id }
            null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OnlineException) {
            if (e.kind == OnlineException.Kind.PERMISSION) "Too late: the request expired or was already answered."
            else friendly(e)
        }
    }

    // =========================================================================================
    // Push token (trusted phone)
    // =========================================================================================

    private val _pushProblem = MutableStateFlow<String?>(null)

    /** Why this trusted phone can't receive push right now (null = nothing known to be wrong). */
    val pushProblem: StateFlow<String?> = _pushProblem.asStateFlow()

    /** Sends this phone's push token so the Worker can reach it. Failure is not fatal, but it is shown. */
    suspend fun registerPushToken(force: Boolean = false) {
        if (!store.current().isApprover) return
        if (!configured) return
        // No Worker URL = no push: the trusted phone sees requests only while LockDistra is open. Nothing to report.
        if (!pushConfigured) {
            _pushProblem.value = null
            return
        }
        if (!OnlineConfig.appIdIsAndroid) {
            _pushProblem.value = "This build uses a web app id, so push can't work. " +
                "Put the Android app id (1:...:android:...) in firebase.properties and rebuild."
            return
        }
        try {
            val token = store.pendingToken()
                ?: withTimeout(20_000L) { FirebaseMessaging.getInstance().token.await() }
            // Same token already sent recently: nothing to do (no network call).
            val nowMs = System.currentTimeMillis()
            if (!force && store.registeredToken() == token && nowMs - store.registeredAt() < TOKEN_RECHECK_MS) {
                _pushProblem.value = null
                return
            }
            FirebaseGateway.registerToken(app, token)
            store.clearPendingToken()
            store.saveRegistered(token, nowMs)
            _pushProblem.value = null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: OnlineException) {
            _pushProblem.value = "Push is not registered yet: " + friendly(e)
        } catch (_: Exception) {
            _pushProblem.value = "This phone could not get a push token. Check the Android app id in " +
                "firebase.properties, that Google Play services is up to date, and the internet."
        }
    }

    /** Called by the messaging service when Firebase issues a new token. */
    fun onNewToken(token: String) {
        store.savePendingToken(token)
        if (store.current().isApprover && configured) scope.launch { registerPushToken(force = true) }
    }

    // =========================================================================================
    // Optional login (the name the trusted phone shows)
    // =========================================================================================

    private fun cleanAccountName(raw: String): String =
        raw.filter { !it.isISOControl() && it != '|' }.trim().replace(Regex("\\s+"), " ").take(30)

    private fun accountChangeBlocked(): String? {
        val st = store.current()
        return if (st.phoneConnected || st.isApprover)
            "Disconnect the trusted phone first (Settings), then log in or out. Another account is another identity, so the connection would break."
        else null
    }

    /**
     * The bridge the account system (data/auth) uses. Sign-up, login, Google, password reset and logout live
     * there; this only keeps Online Approval's own view in step (the name shown on unlock requests) and
     * enforces the pairing rule: the Firebase identity must not change while a trusted phone is connected.
     */
    val accountHost: AccountHost = object : AccountHost {
        override fun identityChangeBlockedReason(): String? = accountChangeBlocked()

        override fun logoutBlockedReason(): String? {
            val st = store.current()
            if (!st.phoneConnected && !st.isApprover) return null
            if (st.accountEmail == null) return accountChangeBlocked()
            disconnectBlockedReason()?.let { return it }
            if (!store.isBackedUp()) {
                syncConnectionBackup()
                return "Your connection is still being saved on the server. Connect to the internet, wait a moment, then log out again."
            }
            return null
        }

        override fun onAccountSignedIn(name: String, email: String) {
            store.saveAccount(cleanAccountName(name).ifBlank { "Me" }, email)
            // A connection saved on the server for this account comes back here.
            syncConnectionBackup()
        }

        override fun onAccountSignedOut() {
            store.clearAccount()
            dropLocalConnectionAfterLogout()
        }
    }

    /** "Skip" on the first-run login screen. */
    fun skipLogin() = store.markLoginAsked()

    // =========================================================================================
    // Settings actions
    // =========================================================================================

    /** Error text, or null when the mode was changed. */
    fun setMode(mode: UnlockMode): String? {
        val s = store.current()
        val error = UnlockGateRules.canSelect(
            mode = mode,
            passwordLockSet = lockStore.current().enabled,
            phoneConnected = s.phoneConnected,
            hasRecoveryCode = s.hasRecovery,
        )
        if (error != null) return error
        if (mode.usesOnline && !configured) return "Online approval isn't set up in this build."
        store.setMode(mode)
        if (mode.usesOnline) start()
        return null
    }

    /** Why the trusted phone may not be disconnected right now (Focus Mode is ON and uses Online Approval), or null. */
    fun disconnectBlockedReason(): String? {
        val f = FocusStore.get(app).current()
        return FocusOffRules.unlinkBlockedReason(f.focusActive, f.offMethod)
    }

    /** True when switching to [target] (or disconnecting) lowers protection and needs a fresh check. */
    fun isWeakening(target: UnlockMode): Boolean {
        val now = store.mode()
        return now.usesOnline && !target.usesOnline
    }

    /**
     * Proves the person is allowed to lower protection: the offline recovery code, or (when the
     * PIN / password lock is on) the current PIN / password. Slow (PBKDF2): off the main thread.
     */
    suspend fun authorizeChange(input: String): VerifyResult = withContext(Dispatchers.Default) {
        val lockOn = lockStore.current().enabled
        if (Credentials.isRecoveryShapeValid(input)) {
            val r = store.checkRecovery(input)
            if (r == VerifyResult.Ok || !lockOn) return@withContext r
        }
        if (lockOn) lockStore.verify(input) else store.checkRecovery(input)
    }

    /** Recovery code check for the lock screen ("trusted phone not reachable"). */
    suspend fun unlockWithRecovery(code: String): VerifyResult = withContext(Dispatchers.Default) {
        val r = store.checkRecovery(code)
        if (r == VerifyResult.Ok) LockSession.unlock()
        r
    }

    fun recoveryLockoutRemainingMs(): Long = store.recoveryLockoutRemainingMs()

    /** The person turned the PIN / password lock off: keep the online part consistent. */
    fun onPasswordLockTurnedOff() {
        val now = store.mode()
        val next = UnlockGateRules.modeAfterPasswordLockOff(now)
        if (next != now) store.setMode(next)
    }

    /** Disconnects the trusted phone from this (locked) phone. Mode goes back to the password lock. */
    suspend fun disconnectTrustedPhone() {
        val uid = runCatching { FirebaseGateway.uid(app) }.getOrNull()
        val approverUid = store.requesterLink()?.approverUid
        clearLockedSide()
        if (uid != null) {
            try {
                FirebaseGateway.deleteLink(app, uid)
                approverUid?.let { runCatching { FirebaseGateway.deleteApproverIndex(app, it, uid) } }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // Offline: finish it at the next start, otherwise the server copy would bring the connection back.
                store.setPendingUnlink(uid, approverUid.orEmpty())
            }
        }
        restartLinkSync()
    }

    /** This phone stops being a trusted approver. */
    suspend fun disconnectAsApprover() {
        val link = store.approverLink()
        val myUid = runCatching { FirebaseGateway.uid(app) }.getOrNull()
        stopApproverWatch()
        store.clearApproverLink()
        if (link != null) {
            try {
                FirebaseGateway.deleteLink(app, link.ownerUid)
                myUid?.let { runCatching { FirebaseGateway.deleteApproverIndex(app, it, link.ownerUid) } }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                store.setPendingUnlink(link.ownerUid, myUid.orEmpty())
            }
            runCatching { FirebaseGateway.removeToken(app) }
            store.clearRegistered()
        }
        restartLinkSync()
    }

    // ---- Wording ------------------------------------------------------------------------------------------

    private fun friendly(e: OnlineException, whileUnlocking: Boolean = false): String = when (e.kind) {
        OnlineException.Kind.NOT_CONFIGURED -> "Online approval isn't set up in this build."
        OnlineException.Kind.OFFLINE -> "No internet. Connect and try again."
        OnlineException.Kind.TIMEOUT -> "The server took too long. Try again."
        OnlineException.Kind.AUTH -> e.message ?: "Sign-in failed."
        OnlineException.Kind.PERMISSION ->
            if (whileUnlocking) "The trusted phone link is no longer valid. Use your recovery code, then connect again."
            else "The server refused this. The code may have been used already."
        OnlineException.Kind.OTHER -> e.message ?: "Something went wrong. Try again."
    }

    companion object {
        @Volatile private var instance: OnlineManager? = null

        fun get(context: Context): OnlineManager =
            instance ?: synchronized(this) {
                instance ?: OnlineManager(context.applicationContext).also { instance = it }
            }
    }
}

/** A push token that was sent to the Worker is not sent again for this long (Firebase reports a new one sooner). */
private const val TOKEN_RECHECK_MS = 7L * 24 * 3600_000L
