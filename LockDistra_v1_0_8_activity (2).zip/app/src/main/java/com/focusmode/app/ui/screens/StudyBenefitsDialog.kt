package com.focusmode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.ui.theme.FocusTheme

/** One benefit line: a symbol, a short bold title and one line under it. */
private data class Benefit(val symbol: String, val title: String, val line: String)

private val BENEFITS = listOf(
    Benefit("🚫", "No ads", "Nothing interrupts your learning."),
    Benefit("🎯", "Read & watch without distractions", "No comedy, games, songs or adult videos: only study."),
    Benefit("📚", "Only learning videos", "Every video is checked to be real study content."),
    Benefit("⚡", "Fast & endless", "Scroll like YouTube, new lessons keep coming."),
    Benefit("⭐", "Follow your favourite teachers", "Their new lectures reach you first."),
    Benefit("🌱", "Study, focus, grow", "Every focused minute grows your plant and your future."),
)

/** Shown ONCE, the first time the person opens the Study section. [onDone] is called when it is closed. */
@Composable
internal fun StudyBenefitsDialog(onDone: () -> Unit) {
    val c = FocusTheme.colors
    AlertDialog(
        onDismissRequest = onDone,
        containerColor = c.card, titleContentColor = c.text, textContentColor = c.muted,
        title = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("📖", style = MaterialTheme.typography.displaySmall)
                Spacer(Modifier.height(6.dp))
                Text("Welcome to Study mode", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(4.dp))
                Text("Benefits for you", style = MaterialTheme.typography.bodyMedium, color = c.accent, textAlign = TextAlign.Center)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                BENEFITS.forEach { b ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(c.accentSoft),
                            contentAlignment = Alignment.Center
                        ) { Text(b.symbol, style = MaterialTheme.typography.titleMedium) }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(b.title, style = MaterialTheme.typography.bodyLarge, color = c.text, fontWeight = FontWeight.SemiBold)
                            Text(b.line, style = MaterialTheme.typography.bodySmall, color = c.muted)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDone) { Text("Start learning", color = c.accent, fontWeight = FontWeight.Bold) }
        }
    )
}
