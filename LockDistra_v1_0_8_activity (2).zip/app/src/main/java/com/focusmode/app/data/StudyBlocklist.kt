package com.focusmode.app.data

/**
 * The big word lists of the Study section. No Android classes, so it is unit tested on the JVM.
 *
 * Two uses:
 *  - a SEARCH that has one of these words is never sent to YouTube; the person sees a short notice and the normal study
 *    videos instead ([StudyBlocklist.blockedSearch]);
 *  - the same words keep videos out of the lists (see [StudyRules] and [StudyWeb]).
 *
 * [ADULT] words are never shown, even from a trusted channel. [DISTRACTION] is everything else that is not studying.
 * Latin words are compared as whole words / phrases in lower case (so "ipl" does not hit "triple"); Hindi / Urdu script is
 * compared inside the text, because the letters carry marks that a word split would cut.
 */
object StudyBlocklist {

    /** Adult content. English, Hinglish and common misspellings. */
    val ADULT: List<String> = listOf(
        "porn", "porno", "pornhub", "pornography", "xxx", "xnxx", "xvideos", "xhamster", "redtube", "youporn", "brazzers",
        "nude", "nudes", "nudity", "naked", "nsfw", "18+", "21+", "adult only", "adults only", "sexy", "sex", "sexual", "sexting",
        "sexvideo", "sex video", "sex videos", "sex story", "sex stories", "erotic", "erotica", "onlyfans", "hentai", "ecchi",
        "boobs", "boob", "tits", "titty", "nipple", "nipples", "cleavage", "bikini", "lingerie", "topless",
        "bra", "panty", "panties", "thong", "butt", "ass", "booty", "twerk", "twerking", "striptease", "stripper",
        "hot girl", "hot girls", "hot video", "hot videos", "hot scene", "hot scenes", "hot dance", "bold scene", "bold scenes",
        "bold video", "bold videos", "bold web series", "kiss scene", "kissing scene", "kissing", "lip lock", "lip kiss",
        "romance scene", "romantic scene", "item song", "item girl", "adult", "adult video", "adult videos", "adult movie",
        "adult movies", "adult content", "adult web series", "mms", "mms leaked", "leaked video", "leaked videos", "leaked mms",
        "viral mms", "scandal video", "scandal videos", "fetish", "bdsm", "kinky", "milf", "incest", "orgasm", "masturbation",
        "masturbate", "blowjob", "handjob", "anal", "pussy", "dick", "cock", "cum", "cumshot", "squirt", "horny", "fuck",
        "fucking", "fucked", "slut", "whore", "escort", "escorts", "call girl", "call girls", "hookup", "hook up", "one night stand",
        "threesome", "gangbang", "orgy", "swinger", "gay porn", "camgirl", "cam girl", "live cam", "webcam girl",
        "chudai", "chodna", "chut", "lund", "gand", "gaand", "randi", "raand", "bhabhi ki", "devar bhabhi",
        "saali", "sali ki", "aunty ki", "desi aunty", "desi bhabhi", "desi girl", "desi girls", "desi masala",
        "garam video", "garam scene", "garma garam", "masala video", "masala videos", "gandi baat", "gandi video",
        "gande video", "gandi movie", "nanga", "nangi", "nangi video", "sexy video", "sexy videos", "sexy dance", "sexy girl",
        "sexy girls", "sexy song", "sexy songs", "suhagraat", "honeymoon video", "honeymoon scene", "first night", "romance video",
        "chumma", "chumban", "kiss video", "hot kiss", "bedroom scene", "bedroom video", "intimate scene", "intimate video",
        "private video", "private videos", "private parts", "cheating wife", "cheating husband",
    )

    /** Comedy, entertainment, games, music, movies, gossip, social media, sports, betting and other non-study content. */
    val DISTRACTION: List<String> = listOf(
        // comedy and pranks
        "comedy", "comedian", "comedians", "stand up", "standup", "stand up comedy", "funny", "funniest", "fun video", "fun videos",
        "joke", "jokes", "joking", "prank", "pranks", "prankster", "roast", "roasting", "roasted", "troll", "trolls", "trolling",
        "trolled", "meme", "memes", "memer", "memes video", "funny memes", "dank", "dank memes", "shitpost", "lol", "lmao", "rofl",
        "hasna", "hasi", "hansi", "hasao", "hasi mazak", "hansi mazak", "mazak", "mazaak", "mazedar", "maza", "majedar", "majak",
        "chutkule", "chutkula", "jokes in hindi", "funny jokes", "bakchodi", "bakchod", "bakwas", "bakwaas", "timepass", "time pass",
        "masti", "mastikhor", "faltu", "khatarnak", "dhamaal", "dhamaka", "tadka", "comedy video", "comedy videos", "comedy scene",
        "comedy scenes", "comedy show", "comedy shows", "comedy movie", "comedy movies", "comedy club", "kapil sharma", "the kapil sharma show",
        "carryminati", "carry minati", "bb ki vines", "bhuvan bam", "ashish chanchlani", "elvish yadav", "triggered insaan",
        "technoblade", "mrbeast", "mr beast", "pewdiepie",
        "tiktok", "tik tok", "reels", "reel", "insta reels", "instagram reels", "shorts video", "viral", "viral video", "viral videos",
        "trending", "trending video", "trending videos", "vines", "snapchat", "likee", "roposo",
        // vlogs and lifestyle
        "vlog", "vlogs", "vlogger", "vlogging", "daily vlog", "day in my life", "my day", "routine vlog", "haul", "shopping haul",
        "unboxing", "unbox", "review phone", "phone review", "smartphone review", "mobile review", "gadget review", "tech review",
        "mukbang", "asmr", "eating show", "eating challenge", "food challenge", "street food", "food vlog", "cooking vlog", "recipe",
        "makeup", "make up", "makeup tutorial", "skincare", "hairstyle", "hair style", "fashion", "outfit", "outfits", "ootd",
        "lookbook", "grwm", "get ready with me", "transformation", "glow up", "dating", "date night", "girlfriend", "boyfriend",
        "gf", "bf", "love story", "love stories", "love song", "love songs", "breakup", "patch up",
        "couple goals", "relationship goals", "wedding", "shaadi", "shaadi video", "sangeet",
        "mehndi", "haldi", "bridal", "bride", "honeymoon", "pregnancy vlog",
        // games
        "gameplay", "game play", "gaming", "gamer", "gamers", "gamers life", "game", "games", "let's play", "lets play", "walkthrough",
        "speedrun", "speed run", "livestream gaming", "minecraft", "roblox", "fortnite", "pubg", "bgmi", "battlegrounds", "free fire",
        "freefire", "garena", "call of duty", "warzone", "valorant", "csgo", "cs go", "counter strike", "dota", "dota 2",
        "league of legends", "lol game", "apex", "apex legends", "overwatch", "among us", "fall guys", "gta", "gta 5", "gta v",
        "gta vice city", "gta san andreas", "san andreas", "vice city", "red dead", "cyberpunk", "elden ring", "god of war",
        "spiderman game", "assassin's creed", "assassins creed", "fifa", "efootball", "ea fc", "nba 2k", "madden", "ludo",
        "ludo king", "carrom pool", "8 ball pool", "candy crush", "subway surfers", "temple run", "clash of clans",
        "clash royale", "brawl stars", "mobile legends", "genshin", "genshin impact", "pokemon", "pokémon", "pokemon go", "zelda",
        "mario", "super mario", "sonic", "roleplay", "gta rp", "montage", "highlights", "clutch", "headshot", "noob", "pro gamer",
        "esports", "e sports", "streamer", "twitch", "stream highlights", "rank push", "rank pushing", "conqueror",
        "solo vs squad", "custom room", "redeem code", "redeem codes", "diamond hack", "free diamonds", "mod apk", "hack apk",
        "cheats", "cheat code", "cheat codes", "unlimited money", "game hack", "game hacks",
        // movies, series, tv, ott
        "movie", "movies", "full movie", "full movies", "film", "films", "cinema", "bollywood", "hollywood", "tollywood", "kollywood",
        "south movie", "south movies", "south indian movie", "hindi dubbed", "dubbed movie", "dubbed movies", "dubbed", "new movie",
        "latest movie", "latest movies", "movie review", "movie reviews", "movie scene", "movie scenes", "best scenes", "best scene",
        "deleted scene", "deleted scenes", "climax", "climax scene", "fight scene", "fight scenes", "action scene", "action scenes",
        "action movie", "action movies", "horror movie", "horror movies", "horror", "ghost", "ghost story", "bhoot", "bhoot ki",
        "bhootiya", "horror story", "horror stories", "scary", "scary video", "scary videos", "haunted", "paranormal", "web series",
        "webseries", "web show", "tv show", "tv shows", "serial", "serials", "tv serial", "daily soap", "soap opera", "episode",
        "full episode", "full episodes", "netflix", "amazon prime", "prime video", "hotstar", "disney plus", "disney hotstar",
        "zee5", "sonyliv", "mx player", "alt balaji", "ullu", "kooku", "trailer", "teaser", "promo", "first look", "motion poster",
        "box office", "box office collection", "ott release", "ott", "anime", "manga", "cartoon", "cartoons",
        "doraemon", "shinchan", "shin chan", "tom and jerry", "chhota bheem", "motu patlu", "peppa pig", "ben 10", "pokemon cartoon",
        "naruto", "one piece", "dragon ball", "attack on titan", "demon slayer", "jujutsu kaisen", "death note", "marvel", "dc comics",
        "avengers", "spiderman", "spider man", "batman", "superman", "iron man", "hulk", "harry potter",
        "game of thrones", "money heist", "squid game", "stranger things", "breaking bad", "friends sitcom", "the office",
        "taarak mehta", "tmkoc", "bigg boss", "big boss", "bb ott", "khatron ke khiladi", "roadies", "splitsvilla", "splitsvilla",
        "mtv", "indian idol", "dance plus", "dance deewane", "kbc", "kaun banega crorepati", "sa re ga ma pa", "saregamapa",
        "super dancer", "india's got talent", "got talent", "voice of india", "shark tank", "mtv roadies", "love island",
        "pushpa", "kgf", "rrr", "baahubali", "bahubali", "jawan", "pathaan", "animal movie", "salaar", "jailer",
        "shah rukh khan", "shahrukh khan", "srk", "salman khan", "aamir khan", "akshay kumar", "ranveer singh", "ranbir kapoor",
        "hrithik roshan", "allu arjun", "prabhas", "ram charan", "jr ntr", "mahesh babu", "thalapathy", "rajinikanth",
        "alia bhatt", "deepika padukone", "priyanka chopra", "katrina kaif", "kareena kapoor", "kiara advani", "shraddha kapoor",
        "sunny leone", "nora fatehi", "disha patani", "urfi javed", "rakhi sawant", "poonam pandey", "sherlyn chopra",
        "bollywood gossip", "celebrity", "celebrities", "celeb", "star kids", "gossip", "gossips", "paparazzi", "red carpet",
        "fan edit", "fan edits", "status video", "whatsapp status", "wa status", "attitude status", "sad status",
        "love status", "shayari", "shayri", "sad shayari", "love shayari", "dosti shayari", "bewafa", "bewafai", "dard", "dard bhari",
        // music and songs
        "song", "songs", "gaana", "gana", "gaane", "geet", "bhajan", "kirtan", "qawwali", "ghazal", "gazal", "lofi", "lo fi",
        "lofi songs", "lofi music", "slowed reverb", "slowed and reverb", "slowed", "reverb", "bass boosted", "bass boost", "8d audio",
        "8d", "remix", "dj remix", "dj", "dj song", "dj songs", "dj mix", "dj", "mashup", "mash up", "cover song", "cover songs",
        "unplugged", "acoustic", "live concert", "concert", "live performance", "music video", "music videos", "video song", "video songs",
        "full song", "full songs", "audio song", "lyrics", "lyric video", "lyrical", "lyrical video", "karaoke", "instrumental",
        "playlist", "jukebox", "top songs", "new songs", "latest songs", "latest song", "hit songs", "hit song", "old songs", "old song",
        "romantic songs", "sad songs", "sad song", "party songs", "party song", "dance songs", "dance song", "wedding songs",
        "punjabi song", "punjabi songs", "haryanvi", "haryanvi song", "haryanvi songs", "bhojpuri", "bhojpuri song", "bhojpuri songs",
        "bhojpuri gana", "khesari lal", "pawan singh", "neelkamal singh", "sapna choudhary", "sapna chaudhary", "rap", "rap song",
        "rap battle", "hip hop", "hiphop", "edm", "k pop", "kpop", "bts", "blackpink", "arijit singh", "atif aslam",
        "badshah", "honey singh", "yo yo honey singh", "diljit dosanjh", "sidhu moose wala", "moosewala", "ap dhillon", "karan aujla",
        "neha kakkar", "shreya ghoshal", "sonu nigam", "kishore kumar", "mohammed rafi", "lata mangeshkar", "taylor swift",
        "justin bieber", "ed sheeran", "selena gomez", "billie eilish", "eminem", "drake", "tseries", "t series", "zee music",
        "sony music", "saregama", "tips official", "speed records", "gaane", "music", "singer", "singing", "dance", "singing video",
        "dance video", "dance videos", "dancing", "dance cover", "dance performance", "dance competition", "choreography",
        "reels dance", "dance challenge", "dance tutorial", "belly dance", "bollywood dance", "garba", "dandiya", "nagin dance",
        // sports (non-study)
        "ipl", "ipl 2024", "ipl 2025", "ipl 2026", "ipl match", "cricket", "cricket match", "cricket highlights", "match highlights",
        "live match", "live score", "live cricket", "t20", "t20 world cup", "world cup", "odi", "test match", "csk", "rcb", "kkr",
        "virat kohli", "kohli", "rohit sharma", "ms dhoni", "dhoni", "sachin tendulkar", "hardik pandya", "jasprit bumrah", "football",
        "football match", "premier league", "champions league", "la liga", "messi", "lionel messi", "ronaldo", "cristiano ronaldo",
        "neymar", "mbappe", "fifa world cup", "kabaddi", "pro kabaddi", "pkl", "wwe", "wrestling match", "wwe highlights", "john cena",
        "roman reigns", "undertaker", "ufc", "mma", "boxing match", "nba", "nfl", "mlb", "nhl", "formula 1", "f1", "motogp",
        "fantasy team", "dream11", "dream 11", "my11circle", "fantasy cricket", "betting", "satta", "satta matka",
        "matka", "casino", "poker", "teen patti", "rummy", "rummy circle", "online rummy", "lottery", "lotto", "jackpot", "gambling",
        "gamble", "roulette", "slot machine", "1xbet", "betway", "bet365", "winzo", "mpl", "paytm cash",
        "earn money online", "earn money", "earning app", "earning apps", "paisa kamao", "paise kamao", "ghar baithe paise", "ghar baithe kamao",
        "free money", "money hack", "money hacks", "quick money", "get rich", "get rich quick", "paisa double", "double money",
        "meme coin", "memecoin", "dogecoin", "shiba", "shiba inu",
        "binary trading",
        // random entertainment, bhai-log content
        "24 hour challenge", "24 hours challenge", "1000 rupees challenge", "survival challenge",
        "experiment gone wrong", "gone wrong", "gone sexual", "gone extreme", "expose", "exposed", "controversy", "controversial",
        "drama video", "youtube drama", "beef", "diss", "diss track", "response video", "reply video", "callout", "call out",
        "reaction video", "reaction videos", "reacting to", "react to", "reacts to", "first time reaction",
        "podcast", "podcast clips", "compilation", "compilations", "best moments", "best of",
        "tier list", "most expensive", "most dangerous", "most beautiful", "richest", "luxury", "luxurious",
        "rich vs poor", "rich vs", "billionaire lifestyle", "lamborghini", "ferrari", "bugatti", "rolls royce", "supercar",
        "car video", "car videos", "bike stunt", "bike stunts", "stunts", "stunt video", "stunt videos", "wheelie",
        "drifting", "street race", "racing", "car race", "car racing", "bike race", "bike racing", "monster truck",
        "freestyle football", "parkour", "extreme sports", "bungee", "skydiving", "fails", "fail", "epic fail", "epic fails",
        "try not to laugh", "try not to", "satisfying", "oddly satisfying", "slime", "slime video", "kinetic sand", "fidget", "fidget spinner",
        "toy", "toys", "toy review", "toys review", "toy unboxing", "surprise egg", "surprise eggs", "kids songs", "nursery rhymes",
        "kids video", "kids videos", "kids cartoon", "baby shark", "cocomelon", "ryan's world", "ryan toysreview", "pinkfong",
        "dhoom", "bakra", "bakra eid", "bhai", "bhai log", "bhailog", "bhai ka", "sasta", "chor", "chori", "chor police", "badla",
        "revenge", "revenge story", "revenge video", "murder mystery", "crime patrol",
        "crime story", "crime stories", "savdhaan india", "cid", "c i d", "real crime", "true crime", "serial killer",
        "accident video", "accident videos", "road accident", "live accident", "cctv", "cctv footage",
        "caught on camera", "caught on cctv", "shocking", "shocking video", "shocking videos", "unbelievable", "unbelievable video",
        "mysterious", "unsolved", "conspiracy", "conspiracy theory", "conspiracy theories", "illuminati", "aliens",
        "alien", "ufo", "area 51", "bermuda triangle", "rahasya", "rahasyamayi", "raaz", "raaz kholna", "sach", "shocking facts",
        "amazing facts", "random facts", "interesting facts", "unknown facts", "mind blowing facts", "crazy facts", "fun facts",
        "weird facts", "dangerous facts", "facts in hindi", "facts hindi", "ajab gajab", "ajab gazab", "anokha", "anokhi",
        "adbhut", "adbhut video", "chamatkar", "chamatkari", "magic trick", "magic tricks", "magician", "jadu", "jaadu",
        "jadugar", "black magic", "kala jadu", "tantra", "tantrik", "vashikaran", "love vashikaran", "astrology", "astrologer",
        "horoscope", "rashifal", "kundli", "kundali", "jyotish", "tarot", "tarot reading", "numerology", "palmistry",
        "love guru", "relationship advice", "love advice", "dating advice", "pickup lines", "pick up lines", "how to impress girl",
        "how to impress a girl", "how to impress boy", "how to get girlfriend", "how to propose", "how to kiss", "how to flirt",
        "flirt", "flirting", "flirty", "rizz", "simp", "sigma male", "sigma rule", "sigma rules", "alpha male",
        "andrew tate", "motivation status", "attitude", "attitude video", "attitude videos", "swag", "swagger", "gangster",
        "gangster status", "gangsters", "mafia", "goonda", "dabang", "dabangg", "tapori", "bhaigiri", "dadagiri",
        // phones, hacking, shady
        "wifi hack", "wifi password", "wifi password hack", "hack wifi", "hack instagram", "instagram hack", "facebook hack",
        "hack facebook", "whatsapp hack", "hack whatsapp", "hack account", "account hack", "hacker", "hackers",
        "jailbreak", "cracked apk", "modded", "modded apk", "premium apk", "free premium",
        "free followers", "free likes", "free subscribers", "followers hack", "likes hack", "instagram followers", "buy followers",
        "free fire hack", "pubg hack", "bgmi hack", "ludo hack", "teen patti hack", "rummy hack", "aviator", "aviator hack",
        "torrent", "torrents", "piratebay", "pirated", "pirated movies", "movierulz", "tamilrockers", "filmyzilla", "filmywap",
        "mp4moviez", "worldfree4u", "9xmovies", "khatrimaza", "vegamovies", "moviesflix", "bolly4u", "hdhub4u", "download movie",
        "download movies", "free download movie", "free download movies", "movie download", "movies download", "full hd movie",
        "720p", "1080p", "480p", "hdrip", "webrip", "bluray", "camrip", "hdcam", "dvdscr", "dual audio", "hindi dual audio",
        // trailing words that usually mean entertainment
        "entertainment", "entertaining", "entertainer", "enjoyment", "mazedaar", "full masti",
        "nightlife", "night party", "pool party", "beach", "beach party", "holiday vlog", "travel vlog",
        "trip vlog", "tour vlog", "road trip", "goa", "goa trip", "goa vlog", "manali trip", "bike trip", "bike ride", "long drive",
        "camping", "tent", "picnic", "birthday", "birthday party", "birthday vlog", "birthday surprise", "surprise", "surprise gift",
        "gift", "gifts", "gift ideas", "diy gift", "valentine", "valentines", "valentine's day", "valentines day", "rose day",
        "propose day", "chocolate day", "teddy day", "promise day", "hug day", "kiss day", "friendship day", "holi", "holi song",
        "holi songs", "diwali", "diwali vlog", "eid", "eid vlog", "christmas", "new year", "new year party", "new year vlog",
        "bigg boss 17", "bigg boss 18", "bigg boss 19", "bigg boss 20", "bb 17", "bb 18", "bb 19",
    ).distinct()

    /** Words that are also normal study words, so they must NOT block a search on their own ("rock" cycle, "cell" ...). */
    private val STUDY_SAFE_QUERIES: List<String> = listOf(
        "rock cycle", "rocks and minerals", "igneous rock", "sedimentary rock", "metamorphic rock", "pop quiz", "race condition",
        "arms race", "cold war", "world war", "world cup history", "cricket history", "history of cricket", "history of football",
        "physics of cricket", "physics of football", "dance forms of india", "classical dance", "folk dance", "indian classical music",
        "music theory", "science of music", "sound waves music", "physics of sound", "love in poetry", "romantic poets",
        "romantic poetry", "romanticism", "game theory", "theory of games", "games theory", "game development", "game design",
        "ghost in the machine", "fact and opinion", "facts and figures", "interesting facts about science", "facts about space",
        "stock market basics", "stock market basics", "share market basics", "trading basics", "forex basics", "economics of betting",
        "probability of lottery", "probability and gambling", "probability games", "poker probability", "dice probability",
        "marvel physics", "science of marvel", "sex education", "reproduction", "human reproduction", "reproductive system",
        "reproductive health", "adolescence", "puberty", "sexual reproduction", "asexual reproduction", "crime and punishment",
        "crime in india", "cyber crime", "cyber crime law", "criminal law", "criminology", "magic square", "magic squares",
        "magician's number", "black magic square", "dark matter", "dark energy", "alien species", "extraterrestrial life",
        "astrophysics", "astronomy", "astrology vs astronomy", "kundli matching", "adult education", "adult literacy", "naked eye",
        "ethical hacking", "cyber security", "dance forms", "music and dance", "art and culture", "season and weather", "stop crime", "crack the exam",
        "crack neet", "crack jee", "crack upsc", "crack ssc", "how to crack",
        "sexual reproduction", "asexual reproduction", "sexually transmitted", "sex determination", "sex linked", "sex chromosomes",
        "sex chromosome", "sex ratio", "sex hormones", "sex organs", "reproductive", "film studies", "film appreciation",
        "radiocarbon dating", "carbon dating", "dating of fossils", "dating methods", "relative dating", "absolute dating",
        "fossil dating", "game development", "game programming", "board game", "music appreciation", "music and mathematics",
        "classical music", "indian music", "art integration", "dance as a form of art", "cricket statistics", "cricket scoring",
        "football physics", "birthday paradox", "gift tax", "playlist of class", "highlights of the chapter", "marvel at",
    )

    /** Words kept only for SEARCHES. A real lesson title can hold them ("Game development", "Highlights of the chapter"). */
    private val TITLE_RELAXED: Set<String> = setOf(
        "game", "games", "music", "dance", "rap", "film", "films", "cricket", "football", "playlist", "highlights", "trailer",
        "teaser", "promo", "wedding", "birthday", "gift", "gifts", "diwali", "holi", "eid", "christmas", "new year", "dating",
        "episode", "marvel", "cinema", "singer", "singing", "edm", "concert", "best of", "beach", "goa", "cover song", "cover songs",
        "wrestling match", "boxing match", "nba", "nfl", "mlb", "nhl", "f1", "world cup", "t20", "odi", "test match",
    )

    private val DISTRACTION_VIDEO: List<String> by lazy { DISTRACTION.filter { it !in TITLE_RELAXED } }

    private val HINDI_ADULT: List<String> = listOf(
        "सेक्स", "पॉर्न", "पोर्न", "नंगी", "नंगा", "चुदाई", "चूत", "लंड", "गांड", "रंडी", "कामुक", "अश्लील", "भाभी की", "देसी भाभी",
        "गरम वीडियो", "सुहागरात", "सेक्सी", "एडल्ट", "हॉट वीडियो", "बोल्ड सीन", "किस सीन", "नग्न",
    )

    private val HINDI_DISTRACTION: List<String> = listOf(
        "कॉमेडी", "कामेडी", "चुटकुले", "चुटकुला", "जोक्स", "जोक", "मज़ाक", "मजाक", "हंसी", "मीम", "मीम्स", "प्रैंक", "रोस्ट",
        "गाना", "गाने", "गाना सुनो", "भजन", "कव्वाली", "ग़ज़ल", "गजल", "रीमिक्स", "डीजे", "डांस", "नाच", "फिल्म", "फिल्में", "मूवी",
        "वेब सीरीज", "सीरियल", "ट्रेलर", "गेम", "गेमिंग", "गेमप्ले", "पबजी", "फ्री फायर", "जीटीए", "वीडियो गेम", "भूत", "हॉरर",
        "डरावनी", "डरावना", "लव स्टोरी", "प्रेम कहानी", "गर्लफ्रेंड", "बॉयफ्रेंड", "शायरी", "स्टेटस", "रील", "रील्स", "वायरल",
        "बिग बॉस", "आईपीएल", "क्रिकेट मैच", "सट्टा", "जुआ", "सट्टा मटका", "कमाई ऐप", "पैसे कमाओ", "घर बैठे कमाओ", "राशिफल",
        "कुंडली", "ज्योतिष", "वशीकरण", "तंत्र मंत्र", "काला जादू", "जादू", "मस्ती", "टाइमपास", "बकवास", "फालतू",
    )

    // ---- reading text ---------------------------------------------------------------------------------------

    /**
     * The words of [text] for comparing: lower case, common letter swaps undone (0 -> o, 1 -> i, 3 -> e, 4 -> a, 5 -> s,
     * 7 -> t, @ -> a, $ -> s), every other mark turned into a space, and a letter repeated three or more times cut down to
     * two ("comeddyyy" -> "comeddyy"). Hindi letters are kept.
     */
    private fun normalize(text: String, leet: Boolean = false): String {
        val sb = StringBuilder(text.length + 2)
        sb.append(' ')
        for (ch in text.lowercase()) {
            val m = if (!leet) ch else when (ch) {
                '0' -> 'o'; '1' -> 'i'; '3' -> 'e'; '4' -> 'a'; '5' -> 's'; '7' -> 't'; '@' -> 'a'; '$' -> 's'
                else -> ch
            }
            sb.append(if (m.isLetterOrDigit() || m == '+' || isHindiMark(m)) m else ' ')
        }
        sb.append(' ')
        return sb.toString().replace(Regex("\\s+"), " ")
    }

    private fun isHindiMark(c: Char): Boolean = c in '\u0900'..'\u097F' || c == '\u200d' || c == '\u200c'

    /** Also compares with every letter repeated at most twice ("hotttt" -> "hott"), then once ("hott" -> "hot"). */
    private fun squeeze(s: String, keep: Int): String {
        val sb = StringBuilder(s.length)
        var run = 0
        var last = '\u0000'
        for (c in s) {
            if (c == last) run++ else { run = 1; last = c }
            if (c == ' ' || run <= keep) sb.append(c)
        }
        return sb.toString()
    }

    /** The same text seen three ways, so spelling tricks do not get through. */
    private fun views(text: String): List<String> {
        val n = normalize(text)
        val l = normalize(text, leet = true)
        return listOf(n, squeeze(n, 2), squeeze(n, 1), l, squeeze(l, 1), joinSingles(n)).distinct()
    }

    /** "s e x" -> "sex": a run of single letters written apart is joined back into one word. */
    private fun joinSingles(view: String): String {
        val out = ArrayList<String>()
        val run = StringBuilder()
        for (t in view.trim().split(' ')) {
            if (t.length == 1 && t[0].isLetter()) run.append(t)
            else {
                if (run.isNotEmpty()) { out += run.toString(); run.setLength(0) }
                if (t.isNotEmpty()) out += t
            }
        }
        if (run.isNotEmpty()) out += run.toString()
        return " " + out.joinToString(" ") + " "
    }

    private fun containsPhrase(view: String, list: List<String>): String? {
        for (w in list) {
            val key = normalize(w).trim()
            if (key.isEmpty()) continue
            if (view.contains(" $key ")) return w
        }
        return null
    }

    /** Hindi / Urdu script words are matched inside the text. */
    private fun containsHindi(raw: String, list: List<String>): String? {
        val low = raw.lowercase()
        return list.firstOrNull { low.contains(it) }
    }

    // ---- public checks -------------------------------------------------------------------------------------

    private val SAFE_NORMALIZED: List<String> by lazy {
        STUDY_SAFE_QUERIES.map { normalize(it).trim() }.filter { it.isNotEmpty() }.sortedByDescending { it.length }
    }

    /** [text] seen as words, with every known study phrase ("sex education", "game theory", "radiocarbon dating") taken out. */
    private fun stripSafe(text: String): String {
        var n = normalize(text)
        for (p in SAFE_NORMALIZED) {
            while (n.contains(" $p ")) n = n.replace(" $p ", " ")
        }
        return n
    }

    /** The word of [text] that is adult content, or null. Study phrases are ignored. */
    fun adultHit(text: String): String? {
        if (text.isBlank()) return null
        val clean = stripSafe(text)
        for (v in views(clean)) containsPhrase(v, ADULT)?.let { return it }
        return containsHindi(text, HINDI_ADULT)
    }

    /** The word of [text] that is a distraction, or null. Used for SEARCHES, so the whole list counts. */
    fun distractionHit(text: String): String? = distractionIn(text, DISTRACTION)

    /** The same for a VIDEO's title / channel: words that real lessons also use are left out ([TITLE_RELAXED]). */
    fun videoDistractionHit(text: String): String? = distractionIn(text, DISTRACTION_VIDEO)

    private fun distractionIn(text: String, list: List<String>): String? {
        if (text.isBlank()) return null
        val clean = stripSafe(text)
        for (v in views(clean)) containsPhrase(v, list)?.let { return it }
        return containsHindi(text, HINDI_DISTRACTION)
    }

    /** Why a search is not allowed: [ADULT] or [DISTRACTION] word found in it. Null = the search may go on. */
    enum class Kind { ADULT, DISTRACTION }

    data class Blocked(val kind: Kind, val word: String)

    /**
     * Checks a typed search. Adult words and every other word of the lists block it, except inside a known study phrase
     * ("sex education", "game theory class 12"). The result is null when the search may go on.
     */
    fun blockedSearch(query: String): Blocked? {
        val q = query.trim()
        if (q.isEmpty()) return null
        adultHit(q)?.let { return Blocked(Kind.ADULT, it) }
        distractionHit(q)?.let { return Blocked(Kind.DISTRACTION, it) }
        return null
    }

    /** What the person sees when a search is blocked (the same sentence for both kinds, so nothing is explained twice). */
    const val NOTICE_TITLE = "Sorry, this is not related to educational purpose"
    const val NOTICE_BODY = "Study only shows learning videos, so that search was not made. Here are study videos instead."
}
