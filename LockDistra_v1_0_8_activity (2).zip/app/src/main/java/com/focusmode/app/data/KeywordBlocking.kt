package com.focusmode.app.data

import java.net.URLDecoder

/**
 * One word or phrase the person blocks. [partial] = also match inside longer words ("porn" in "pornhub");
 * by default only whole words match, so "sex" never closes "Essex" and "ad" never closes "download".
 */
data class KeywordRule(
    val word: String,
    val enabled: Boolean = true,
    val partial: Boolean = false,
)

/** Everything saved for Keyword Blocking. */
data class KeywordState(
    /** Master switch. */
    val enabled: Boolean = false,
    /** Also look at the page title and headings the browser exposes (not only the address bar). */
    val checkPages: Boolean = true,
    val rules: List<KeywordRule> = emptyList(),
) {
    /** Something is actually being blocked: the switch is on and at least one keyword is on. */
    val isActive: Boolean get() = enabled && rules.any { it.enabled }

    val activeCount: Int get() = rules.count { it.enabled }

    /** (rule, normalized key) of every keyword that is on, built once per state. */
    internal val compiled: List<Pair<KeywordRule, String>> by lazy {
        if (!enabled) emptyList()
        else rules.filter { it.enabled }.mapNotNull { r -> KeywordRules.key(r.word)?.let { r to it } }
    }
}

/**
 * Keyword matching and editing rules, free of Android classes so they can be unit-tested.
 *
 * Text (an address bar, a page title) and keywords are both cut into lower-case words (letters and digits of any
 * language; everything else - dots, slashes, dashes, "+", "%20" - separates). A keyword matches when its words appear
 * next to each other in the text, so matching is case-insensitive and "instagram" is found in
 * "https://www.Instagram.com/reel/x", in "instagram-login" and in a search for "instagram login".
 */
object KeywordRules {

    const val MAX = 100
    const val MIN_LENGTH = 2
    /** Matching inside longer words is only allowed for keywords at least this long. */
    const val MIN_PARTIAL = 3
    const val MAX_LENGTH = 40

    enum class Result { OK, INVALID, ALREADY_THERE, LOCKED, FULL }

    private fun isWordChar(ch: Char): Boolean {
        if (ch.isLetterOrDigit()) return true
        // Combining marks belong to the word (Hindi vowel signs, accents), or words in those scripts would be cut apart.
        return when (Character.getType(ch).toByte()) {
            Character.NON_SPACING_MARK, Character.COMBINING_SPACING_MARK, Character.ENCLOSING_MARK -> true
            else -> false
        }
    }

    /** Address bars write spaces as "+" or "%20"; undo that. Bad escapes are left alone. */
    private fun decode(text: String): String {
        if (text.indexOf('%') < 0 && text.indexOf('+') < 0) return text
        return try {
            URLDecoder.decode(text.replace(Regex("%(?![0-9a-fA-F]{2})"), "%25"), "UTF-8")
        } catch (_: Exception) {
            text
        }
    }

    /** The lower-case words of [text]. */
    fun words(text: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in decode(text)) {
            if (isWordChar(ch)) sb.append(ch.lowercaseChar())
            else if (sb.isNotEmpty()) { out += sb.toString(); sb.setLength(0) }
        }
        if (sb.isNotEmpty()) out += sb.toString()
        return out
    }

    /** The words of a keyword joined by single spaces (its identity for matching and for duplicates), or null if unusable. */
    fun key(word: String): String? {
        val w = words(word)
        if (w.isEmpty()) return null
        val k = w.joinToString(" ")
        return if (k.length >= MIN_LENGTH) k else null
    }

    /**
     * What the person typed, tidied: trimmed, lower case, one space between words. Null when it is not a usable keyword
     * (empty, 1 character, longer than [MAX_LENGTH], no letters or digits).
     */
    fun clean(raw: String): String? {
        val s = raw.filterNot { it.isISOControl() }.trim().lowercase().replace(Regex("\\s+"), " ")
        if (s.isEmpty() || s.length > MAX_LENGTH) return null
        return if (key(s) == null) null else s
    }

    private fun padded(text: String): String = words(text).joinToString(" ", prefix = " ", postfix = " ")

    private fun hit(hay: String, rule: KeywordRule, key: String): Boolean =
        if (rule.partial && key.length >= MIN_PARTIAL) hay.contains(key) else hay.contains(" $key ")

    /** The first keyword that is on and found in [text], or null. */
    fun firstHit(state: KeywordState, text: String): KeywordRule? {
        if (text.isBlank()) return null
        val compiled = state.compiled
        if (compiled.isEmpty()) return null
        val hay = padded(text)
        if (hay.isBlank()) return null
        for ((rule, key) in compiled) if (hit(hay, rule, key)) return rule
        return null
    }

    /** Several entries typed or pasted at once: separated by commas, semicolons or new lines (a phrase keeps its spaces). */
    fun splitInput(raw: String): List<String> =
        raw.split(Regex("[,;\\n\\r]+")).map { it.trim() }.filter { it.isNotEmpty() }

    // ---- Saving ------------------------------------------------------------------------------

    fun encode(rules: List<KeywordRule>): String =
        ListCodec.encode(rules.map { ListCodec.pair(it.word, "${if (it.enabled) 1 else 0}${if (it.partial) 1 else 0}") })

    fun decode(raw: String?): List<KeywordRule> =
        ListCodec.decode(raw).mapNotNull { entry ->
            val (word, flags) = ListCodec.unpair(entry) ?: return@mapNotNull null
            if (flags.length != 2 || word.isEmpty()) null
            else KeywordRule(word, enabled = flags[0] == '1', partial = flags[1] == '1')
        }
}

/**
 * Add / edit / remove / switch for a keyword list, as pure functions. [KeywordStore] decides who may change what
 * (session locks) and passes it in as [canTighten] / [canLoosen], like the website rules do.
 */
object KeywordEdits {

    class Change(val rules: List<KeywordRule>, val result: KeywordRules.Result)

    fun add(list: List<KeywordRule>, raw: String, partial: Boolean, canTighten: Boolean): Change {
        val word = KeywordRules.clean(raw) ?: return Change(list, KeywordRules.Result.INVALID)
        if (!canTighten) return Change(list, KeywordRules.Result.LOCKED)
        val key = KeywordRules.key(word)
        if (list.any { KeywordRules.key(it.word) == key }) return Change(list, KeywordRules.Result.ALREADY_THERE)
        if (list.size >= KeywordRules.MAX) return Change(list, KeywordRules.Result.FULL)
        return Change(list + KeywordRule(word, enabled = true, partial = partial && key!!.length >= KeywordRules.MIN_PARTIAL), KeywordRules.Result.OK)
    }

    /** Outcome of adding several at once; the lists hold the entries as they were typed. */
    class Bulk(
        val rules: List<KeywordRule>,
        val added: List<String>,
        val duplicates: List<String>,
        val invalid: List<String>,
        val full: List<String>,
        val locked: Boolean,
    ) {
        val allDone: Boolean get() = added.isNotEmpty() && duplicates.isEmpty() && invalid.isEmpty() && full.isEmpty() && !locked
    }

    /** One bad entry never stops the others. */
    fun addMany(list: List<KeywordRule>, raw: String, partial: Boolean, canTighten: Boolean): Bulk {
        var cur = list
        val added = ArrayList<String>(); val dup = ArrayList<String>()
        val bad = ArrayList<String>(); val full = ArrayList<String>()
        var locked = false
        for (token in KeywordRules.splitInput(raw)) {
            val c = add(cur, token, partial, canTighten)
            when (c.result) {
                KeywordRules.Result.OK -> { cur = c.rules; added += token }
                KeywordRules.Result.ALREADY_THERE -> dup += token
                KeywordRules.Result.INVALID -> bad += token
                KeywordRules.Result.FULL -> full += token
                KeywordRules.Result.LOCKED -> locked = true
            }
        }
        if (added.isEmpty() && dup.isEmpty() && bad.isEmpty() && full.isEmpty() && !locked) bad += raw.trim()
        return Bulk(cur, added, dup, bad, full, locked)
    }

    /** Replaces [oldWord]; its ON/OFF state is kept. Editing loosens, so it follows the delete lock. */
    fun edit(list: List<KeywordRule>, oldWord: String, raw: String, partial: Boolean, canLoosen: Boolean): Change {
        val word = KeywordRules.clean(raw) ?: return Change(list, KeywordRules.Result.INVALID)
        val index = list.indexOfFirst { it.word == oldWord }
        if (index < 0) return Change(list, KeywordRules.Result.INVALID)
        if (!canLoosen) return Change(list, KeywordRules.Result.LOCKED)
        val key = KeywordRules.key(word)
        if (list.withIndex().any { (i, r) -> i != index && KeywordRules.key(r.word) == key }) {
            return Change(list, KeywordRules.Result.ALREADY_THERE)
        }
        val next = list.toMutableList()
        next[index] = next[index].copy(word = word, partial = partial && key!!.length >= KeywordRules.MIN_PARTIAL)
        return Change(next, KeywordRules.Result.OK)
    }

    /** Null when not allowed. */
    fun remove(list: List<KeywordRule>, word: String, canLoosen: Boolean): List<KeywordRule>? =
        if (!canLoosen) null else list.filterNot { it.word == word }

    /** Null when the keyword is unknown or the change is not allowed. */
    fun setEnabled(list: List<KeywordRule>, word: String, on: Boolean, canTighten: Boolean, canLoosen: Boolean): List<KeywordRule>? {
        val index = list.indexOfFirst { it.word == word }
        if (index < 0) return null
        if (list[index].enabled == on) return list
        if (!(if (on) canTighten else canLoosen)) return null
        return list.toMutableList().also { it[index] = it[index].copy(enabled = on) }
    }
}
