package com.focusmode.app.ui.lecture

/**
 * The page of LockDistra's own YouTube player: the official IFrame player with its own controls switched off, and LockDistra's
 * controls drawn on top in the same layout as YouTube's app:
 *  - centre: 10 s back, play / pause, 10 s forward
 *  - double tap on the left / right side of the video: 10 s back / forward (a double tap in the middle plays / pauses)
 *  - bottom: time, seek bar, full screen button;  top right: speed
 * A transparent layer over the video takes every touch, so YouTube's own buttons (logo, title, "more videos") can never
 * be tapped. When the video ends a black "Lecture finished" layer covers the player, so YouTube's end-screen
 * suggestions are never shown. It tells the app the watched time every few seconds (resume) and any player error
 * (fallback to the normal page).
 *
 * [hideBranding]: the embedded player is drawn a little taller than the video and the extra strip (where YouTube puts
 * its title bar and its logo) is covered in black. Set it to false to leave YouTube's own marks as they are
 * (YouTube's terms ask apps not to hide them, which matters for a Play Store release).
 *
 * NOTE: this is a Kotlin raw string, so the page must never contain a dollar sign or three double quotes.
 */
internal object LecturePlayerHtml {

    fun build(videoId: String, origin: String, startSeconds: Int, bridge: String, hideBranding: Boolean = true, ratio: Float = 16f / 9f,
        pip: Boolean = false, repeat: Boolean = false): String =
        TEMPLATE
            .replace("__ID__", videoId)
            .replace("__ORIGIN__", origin)
            .replace("__START__", startSeconds.coerceAtLeast(0).toString())
            .replace("__BRIDGE__", bridge)
            .replace("__MARGIN__", if (hideBranding) "72" else "0")
            .replace("__RATIO__", ratio.toString())
            .replace("__PIP__", pip.toString())
            .replace("__REP__", repeat.toString())

    private const val TEMPLATE = """
<html><head><link rel="preconnect" href="https://www.youtube.com"><link rel="preconnect" href="https://i.ytimg.com"><link rel="preconnect" href="https://www.google.com"><link rel="dns-prefetch" href="https://www.googlevideo.com"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>
html,body{margin:0;height:100%;background:#000;overflow:hidden;-webkit-tap-highlight-color:transparent;font-family:sans-serif;color:#fff;-webkit-user-select:none;user-select:none}
#box{position:absolute;left:0;top:0;width:100%;height:100%;overflow:hidden}
#box iframe,#p{position:absolute;top:0;left:0;width:100%;height:100%;border:0}
.mask{position:absolute;left:0;right:0;background:#000;z-index:2}
#tap{position:absolute;top:0;left:0;right:0;bottom:0;z-index:3}
#cv{display:none;position:absolute;left:50%;top:50%;width:84px;height:84px;margin:-42px 0 0 -42px;border-radius:42px;background:#000;z-index:5;pointer-events:none}
#cv.on{display:block}
#cv i{display:none;position:absolute;left:0;top:0;right:0;bottom:0;box-sizing:border-box;border-radius:50%;border:4px solid rgba(255,255,255,.18);border-top-color:#C044FF;animation:cvs .9s linear infinite}
#cv.spin i{display:block}
#cv b{display:none;position:absolute;left:50%;top:50%;width:0;height:0;margin:-18px 0 0 -12px;border-left:30px solid #fff;border-top:18px solid transparent;border-bottom:18px solid transparent}
#cv.pz b{display:block}
body.ui #cv b{display:none!important}
/* Controls on screen: LockDistra's own round button sits in the middle, so the cover shrinks to a small dot hidden behind its icon (no big black circle around the button). */
#cv.spin{width:64px;height:64px;margin:-32px 0 0 -32px;border-radius:32px}
#cv.pz{width:84px;height:84px;margin:-42px 0 0 -42px;border-radius:42px}
#cv.gr{width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:15px}
body.ui #cv{width:30px;height:30px;margin:-15px 0 0 -15px;border-radius:15px}
body.ui #cv i{display:none!important}
@keyframes cvs{to{transform:rotate(360deg)}}
#scrim{position:absolute;top:0;left:0;right:0;bottom:0;z-index:4;pointer-events:none;opacity:0;transition:opacity .2s;
background:linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.25) 40%,rgba(0,0,0,.25) 60%,rgba(0,0,0,.7))}
body.ui #scrim{opacity:1}
body.paused #scrim{background:linear-gradient(rgba(0,0,0,.8),rgba(0,0,0,.55) 40%,rgba(0,0,0,.55) 55%,rgba(0,0,0,.95))}
#ctl{position:absolute;top:0;left:0;right:0;bottom:0;z-index:6;opacity:0;pointer-events:none;transition:opacity .2s}
body.ui #ctl{opacity:1}
body.ui #ctl .hit{pointer-events:auto}
#top{position:absolute;top:8px;right:12px;display:flex}
#mid{position:absolute;left:0;right:0;top:50%;margin-top:-36px;height:72px;display:flex;align-items:center;justify-content:center}
.ib{background:none;border:0;padding:0;margin:0;display:flex;align-items:center;justify-content:center;color:#fff}
.ib svg{fill:#fff;display:block}
#bk,#fw{width:56px;height:56px;margin:0 22px;border-radius:28px;background:rgba(0,0,0,.35)}
#pp{width:72px;height:72px;border-radius:36px;background:rgba(0,0,0,.45)}
#sp{background:rgba(0,0,0,.45);border:0;color:#fff;border-radius:16px;padding:7px 14px;font-size:13px;font-weight:bold}
#bg{background:rgba(0,0,0,.45);border:0;color:#fff;border-radius:16px;padding:7px 12px;font-size:13px;font-weight:bold;margin-right:8px}
#bg.on{background:#C044FF}
#rp{background:rgba(0,0,0,.45);border:0;color:#fff;border-radius:16px;padding:7px 12px;font-size:13px;font-weight:bold;margin-right:8px}
#rp.on{background:#C044FF}
#gr{width:38px;height:30px;margin-right:8px;border-radius:16px;background:rgba(0,0,0,.45)}
#qm{display:none;position:absolute;top:46px;right:12px;z-index:8;background:rgba(20,16,43,.96);border-radius:12px;padding:6px 0;min-width:140px;max-height:70%;overflow-y:auto}
#qm div{padding:10px 18px;font-size:14px;white-space:nowrap}
#qm div.on{color:#C044FF;font-weight:bold}
#qm div.hd{font-size:12px;color:#aaa;padding:4px 18px 6px}
#qhint{position:absolute;bottom:74px;left:50%;transform:translateX(-50%);z-index:7;max-width:70%;text-align:center;white-space:nowrap;background:rgba(0,0,0,.62);color:#fff;border-radius:12px;padding:5px 10px;font-size:12px;font-weight:bold;opacity:0;pointer-events:none;transition:opacity .25s}
#qhint.show{opacity:1}
#bot{position:absolute;left:0;right:0;bottom:0;padding:0 14px 8px 14px}
#row{display:flex;align-items:center;justify-content:space-between;height:34px}
#tm{font-size:13px;white-space:nowrap}
#fs{width:40px;height:34px}
#sb{position:relative;height:26px;touch-action:none}
#trk{position:absolute;left:0;right:0;top:11px;height:4px;background:rgba(255,255,255,.35);border-radius:2px}
#bar{position:absolute;left:0;top:11px;height:4px;width:0;background:#C044FF;border-radius:2px}
#gaps{position:absolute;left:0;right:0;top:11px;height:4px;pointer-events:none}
#gaps i{position:absolute;top:0;height:4px;min-width:2px;background:#FF3B30;border-radius:1px}
#th{position:absolute;top:6px;left:0;width:14px;height:14px;margin-left:-7px;border-radius:7px;background:#C044FF}
.rip{position:absolute;top:50%;margin-top:-34px;width:68px;height:68px;border-radius:34px;background:rgba(255,255,255,.28);z-index:5;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:bold;opacity:0;pointer-events:none;transition:opacity .25s}
#rl{left:12%}#rr{right:12%}
#end{display:none;position:absolute;top:0;left:0;right:0;bottom:0;background:#000;color:#fff;z-index:9;align-items:center;justify-content:center;flex-direction:column}
body.pip #ctl,body.pip #scrim,body.pip #qm,body.pip .rip,body.pip #qhint{display:none!important}
#end button{background:#C044FF;color:#fff;border:0;border-radius:22px;padding:10px 26px;font-size:15px;margin-top:14px}
</style></head><body>
<div id="box"><div id="p"></div></div>
<div class="mask" id="mt" style="top:0;height:0"></div>
<div class="mask" id="mb" style="bottom:0;height:0"></div>
<div id="cv"><i></i><b></b></div>
<div id="tap"></div>
<div id="scrim"></div>
<div class="rip" id="rl">-10 s</div><div class="rip" id="rr">+10 s</div>
<div id="end"><div id="endmsg" style="font-size:18px">Lecture finished</div><div id="endsub" style="font-size:13px;color:#aaa;margin-top:6px;text-align:center;padding:0 24px"></div><button id="again">Replay</button></div>
<div id="qm"></div>
<div id="qhint"></div>
<div id="ctl">
<div id="top"><button class="hit" id="rp">Repeat: Off</button><button class="hit" id="bg">Background</button><button class="ib hit" id="gr"><svg width="22" height="22" viewBox="0 0 24 24"><path d="M19.4 13a7.5 7.5 0 0 0 0-2l2.1-1.6a.5.5 0 0 0 .1-.6l-2-3.5a.5.5 0 0 0-.6-.2l-2.5 1a7.3 7.3 0 0 0-1.7-1l-.4-2.6a.5.5 0 0 0-.5-.4h-4a.5.5 0 0 0-.5.4l-.4 2.6a7.3 7.3 0 0 0-1.7 1l-2.5-1a.5.5 0 0 0-.6.2l-2 3.5a.5.5 0 0 0 .1.6L4.6 11a7.5 7.5 0 0 0 0 2l-2.1 1.6a.5.5 0 0 0-.1.6l2 3.5c.1.2.4.3.6.2l2.5-1c.5.4 1.1.7 1.7 1l.4 2.6c0 .2.2.4.5.4h4c.3 0 .5-.2.5-.4l.4-2.6c.6-.3 1.2-.6 1.7-1l2.5 1c.2.1.5 0 .6-.2l2-3.5a.5.5 0 0 0-.1-.6L19.4 13zM12 15.5a3.5 3.5 0 1 1 0-7 3.5 3.5 0 0 1 0 7z"/></svg></button><button class="hit" id="sp">1x</button></div>
<div id="mid">
<button class="ib hit" id="bk"><svg width="30" height="30" viewBox="0 0 24 24"><path d="M12 5V1L7 6l5 5V7c3.3 0 6 2.7 6 6s-2.7 6-6 6-6-2.7-6-6H4c0 4.4 3.6 8 8 8s8-3.6 8-8-3.6-8-8-8z"/><text x="12" y="16" font-size="7.5" font-weight="bold" text-anchor="middle">10</text></svg></button>
<button class="ib hit" id="pp"></button>
<button class="ib hit" id="fw"><svg width="30" height="30" viewBox="0 0 24 24"><path d="M12 5V1l5 5-5 5V7c-3.3 0-6 2.7-6 6s2.7 6 6 6 6-2.7 6-6h2c0 4.4-3.6 8-8 8s-8-3.6-8-8 3.6-8 8-8z"/><text x="12" y="16" font-size="7.5" font-weight="bold" text-anchor="middle">10</text></svg></button>
</div>
<div id="bot">
<div id="row"><span id="tm">0:00 / 0:00</span><button class="ib hit" id="fs"></button></div>
<div id="sb" class="hit"><div id="trk"></div><div id="bar"></div><div id="gaps"></div><div id="th"></div></div>
</div>
</div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var VID='__ID__',qSel='auto',qOpen=false,qTimer=null,P=null,dur=0,seeking=false,hideT=null,ticks=0,si=0,speeds=[1,1.25,1.5,1.75,2,0.75],M=__MARGIN__,R=__RATIO__,bgOn=__PIP__,repOn=__REP__,qMis=0,qReload=0,qOk=true,qCap='',qStable=0,qNote='',lastV=-1,lastW=0,rateBad=0,rateFix=0;
var ICON_PLAY='<svg width="44" height="44" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
var ICON_PAUSE='<svg width="44" height="44" viewBox="0 0 24 24"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>';
var ICON_FS='<svg width="26" height="26" viewBox="0 0 24 24"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>';
var ICON_FSX='<svg width="26" height="26" viewBox="0 0 24 24"><path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/></svg>';
function el(i){return document.getElementById(i)}
function fmt(s){s=Math.floor(s||0);var m=Math.floor(s/60),h=Math.floor(m/60);m=m%60;var x=s%60;return(h?h+':'+(m<10?'0':''):'')+m+':'+(x<10?'0':'')+x}
/* YouTube draws its own play / pause icon and its own spinner in the middle of the video. The player is drawn big and scaled down (for 720p and up), so they shrink to a tiny dot that shows next to LockDistra's own button.
   While the video buffers, starts, is paused or has just changed state, a small black badge covers the middle: it holds LockDistra's own spinner (and a play mark while paused with the controls hidden). */
var cvAt=0;
function paintCover(){var c=document.getElementById('cv');if(!c)return;var s=state(),sp=(s==3||s==-1||s==5),gr=!sp&&s!=2&&(Date.now()-cvAt<300),on=sp||s==2||gr;c.className=(on?'on':'')+(sp?' spin':'')+((s==2&&!sp)?' pz':'')+(gr?' gr':'')}
function state(){try{return P.getPlayerState()}catch(e){return -1}}
function isLand(){return window.innerWidth>window.innerHeight}
function showCtl(){document.body.classList.add('ui');clearTimeout(hideT);hideT=setTimeout(function(){if(state()==1&&!seeking&&!qOpen)hideCtl()},3000)}
function hideCtl(){document.body.classList.remove('ui')}
function bridge(fn,a,b){try{__BRIDGE__[fn](a,b)}catch(e){}}
/* The app counts only video that really played; a jump to the end does not finish the lecture. It tells the page when parts were skipped. */
var gapAt=-1;
function txt(i,t){var e=el(i);if(e)e.textContent=t}
function setSkipped(t){gapAt=t;txt('endmsg','Part of this lecture was skipped');txt('endsub','Focus Mode stays on until the lecture is watched. Continue where you skipped.');txt('again','Watch the skipped part');el('end').style.display='flex'}
/* Skipped parts (not watched, before the furthest point reached) are drawn in red on top of the seek bar. The app sends [[from,to],...] as fractions of the video. */
function setGaps(a){var g=el('gaps'),h='',i,x,y;if(!g)return;try{for(i=0;i<a.length&&i<80;i++){x=Math.max(0,Math.min(1,+a[i][0]));y=Math.max(0,Math.min(1,+a[i][1]));if(y>x)h+='<i style="left:'+(x*100)+'%;width:'+((y-x)*100)+'%"></i>'}g.innerHTML=h}catch(e){}}
function resetEnd(){gapAt=-1;txt('endmsg','Lecture finished');txt('endsub','');txt('again','Replay')}
/* The chosen speed is kept in speeds[si] and re-applied whenever the player drops it (screen off / on, app in the background, pause / resume, buffering). */
function applySpeed(force){try{if(P&&P.setPlaybackRate&&(force||Math.abs((P.getPlaybackRate()||1)-speeds[si])>0.01))P.setPlaybackRate(speeds[si])}catch(e){}}
/* YouTube sometimes keeps REPORTING the chosen speed while the video really plays at 1x (right after start, a seek, a quality change or buffering).
   So the real speed is measured: video seconds passed / real seconds passed. If it is not the chosen speed twice in a row, the speed is set again
   (and, if that does not help, nudged: 1x for a moment, then the chosen speed). */
function checkRate(c){
var now=Date.now();
if(state()==1&&!seeking&&lastV>=0){
var dw=(now-lastW)/1000,dv=c-lastV,want=speeds[si];
if(dw>0.3&&dw<1.5){
if(Math.abs(dv/dw-want)>want*0.3){rateBad++;if(rateBad>=2){rateBad=0;rateFix++;applySpeed(true);if(rateFix%3==0){try{P.setPlaybackRate(1)}catch(e){}setTimeout(function(){applySpeed(true)},150)}}}
else{rateBad=0;rateFix=0}
}
}else{rateBad=0}
lastV=state()==1?c:-1;lastW=now;
}
/* Video quality: only the levels this video really offers are listed. YouTube treats a choice as a strong hint; if it
   has not switched after a moment, the video is reloaded at the same time with that quality. */
var QN={highres:'4320p',hd2880:'2880p',hd2160:'2160p',hd1440:'1440p',hd1080:'1080p',hd720:'720p',large:'480p',medium:'360p',small:'240p',tiny:'144p'};
try{var sq=localStorage.getItem('rwQuality');if(sq&&QN[sq])qSel=sq}catch(e){}
function qLevels(){var a=[];try{a=P.getAvailableQualityLevels()||[]}catch(e){}var o=[];for(var i=0;i<a.length;i++){if(QN[a[i]])o.push(a[i])}return o}
function closeQ(){qOpen=false;el('qm').style.display='none'}
function openQ(){
var l=qLevels(),cq=qShown(),sh=(qSel=='auto')?'auto':(cq||qSel),h='<div class="hd">Quality</div><div data-q="auto"'+(sh=='auto'?' class="on"':'')+'>Auto'+(qSel=='auto'&&cq?' ('+QN[cq]+')':'')+'</div>';
for(var i=0;i<l.length;i++){h+='<div data-q="'+l[i]+'"'+(sh==l[i]?' class="on"':'')+'>'+QN[l[i]]+'</div>'}
h+='<div class="hd" id="qnow"></div>';
el('qm').innerHTML=h;el('qm').style.display='block';qOpen=true;paintQNow();showCtl()}
function paintBg(){var b=el('bg');b.className='hit'+(bgOn?' on':'');b.textContent='Background: '+(bgOn?'On':'Off')}
function setBg(on){bgOn=!!on;paintBg()}
function paintRep(){var b=el('rp');b.className='hit'+(repOn?' on':'');b.textContent='Repeat: '+(repOn?'On':'Off')}
function setOpt(n){if(n=='pip'){bgOn=!bgOn;bridge('onOption','pip',bgOn?1:0);paintBg()}else if(n=='rep'){repOn=!repOn;bridge('onOption','rep',repOn?1:0)}openQ()}
function setPip(on){document.body.classList.toggle('pip',!!on);if(on)closeQ();layout()}
/* YouTube treats a quality choice only as a hint, so the choice is pushed with both calls, checked every half second against what really plays,
   pushed again if it differs and, as the last step, the video is reloaded at the same time with that quality (at most twice per choice). The menu
   always says which quality really plays. The choice is remembered for the next lecture. */
function qWant(){
if(qSel=='auto')return 'auto';
var o=Object.keys(QN),l=qLevels(),i=o.indexOf(qSel),k=qCap?o.indexOf(qCap):-1;
if(k>i)i=k;
if(!l.length)return o[i];
for(var j=i;j<o.length;j++){if(l.indexOf(o[j])>=0)return o[j]}
return l[l.length-1]}
function hToQ(w,h){var e=(w>=h)?Math.max(h,w*9/16):w,t=[[4320,'highres'],[2880,'hd2880'],[2160,'hd2160'],[1440,'hd1440'],[1080,'hd1080'],[720,'hd720'],[480,'large'],[360,'medium'],[240,'small'],[144,'tiny']];
for(var i=0;i<t.length;i++){if(e>=t[i][0]*0.93)return t[i][1]}return 'tiny'}
/* The REAL resolution (what is decoded), when the player tells it; otherwise what the player reports. The reported value can be just the
   requested one right after a choice, so a choice counts as done only after it has been seen on several checks in a row. */
function curQ(){var c='',s=null,k,m;
try{if(P.getStatsForNerds){s=P.getStatsForNerds();if(s){for(k in s){if(/res/i.test(k)&&!/view/i.test(k)){m=/(\d{3,4})\s*x\s*(\d{3,4})/.exec(String(s[k]));if(m){c=hToQ(+m[1],+m[2]);break}}}}}}catch(e){}
if(!c){try{c=P.getPlaybackQuality()}catch(e){}}
return c}
function pushQ(q){
try{if(P.setPlaybackQualityRange)P.setPlaybackQualityRange(q,q)}catch(e){}
try{P.setPlaybackQuality(q)}catch(e){}}
function resetAutoQ(){
try{if(P.setPlaybackQualityRange)P.setPlaybackQualityRange('tiny','highres')}catch(e){}
try{P.setPlaybackQuality('default')}catch(e){}}
function reloadAt(q){var t=0;try{t=P.getCurrentTime()||0}catch(e){}try{P.loadVideoById({videoId:VID,startSeconds:t,suggestedQuality:q})}catch(e){}}
function paintQNow(){var n=el('qnow');if(!n)return;var c=curQ(),t='Playing now: '+(QN[c]||'...');
if(qSel!='auto'&&!qOk&&qReload<2)t+='  (changing to '+QN[qWant()]+'...)';
else if(qSel!='auto'&&!qOk)t+='  (you chose '+QN[qWant()]+', but YouTube is not giving it for this video right now)';
else if(qSel!='auto'&&qWant()!=qSel)t+='  ('+QN[qSel]+' is not available, using '+QN[qWant()]+')';
n.textContent=t}
/* The tick of the menu: the highlighted line is always the quality that REALLY plays (never just the one that was tapped). */
function qShown(){var c=curQ();return QN[c]?c:''}
function paintQMenu(){var m=el('qm'),n=m.querySelectorAll('[data-q]'),cq=qShown(),sh=(qSel=='auto')?'auto':(cq||qSel),i,q;
for(i=0;i<n.length;i++){q=n[i].getAttribute('data-q');n[i].className=(q==sh)?'on':''}
var a=m.querySelector('[data-q="auto"]');if(a)a.textContent='Auto'+(qSel=='auto'&&cq?' ('+QN[cq]+')':'')}
/* A small chip on the video says which quality really plays (and, if it differs, which one was asked for). */
var lastQ='',hintT=null;
function qHint(t){var h=el('qhint');if(!h)return;h.textContent=t;h.classList.add('show');clearTimeout(hintT);hintT=setTimeout(function(){h.classList.remove('show')},3500)}
function watchQ(){var c=qShown();if(!c||state()!=1||c==lastQ)return;lastQ=c;
var w=(qSel=='auto')?'':qWant();
qHint(w&&w!=c?'Playing at '+QN[c]+'  (you chose '+QN[w]+')':(qSel!='auto'&&w!=qSel?QN[qSel]+' not supported, playing at '+QN[c]:'Playing at '+QN[c]))}
/* A high choice makes the player believe it is big: YouTube hands out high resolutions only to a big player, and a phone-sized player
   stays at 360p / 480p whatever is asked. So for 720p and up the player is drawn at that real size and scaled down to fit the video. */
function qBig(){var m={hd720:1280,hd1080:1920,hd1440:2560,hd2160:2560,hd2880:2560,highres:2560};return m[qSel]||0}
function setQ(q){
qSel=q;qMis=0;qReload=0;qCap='';qStable=0;qNote='';qOk=(q=='auto');
try{localStorage.setItem('rwQuality',q)}catch(e){}
closeQ();
lastQ='';layout();
if(q=='auto')resetAutoQ();else{pushQ(qWant());setTimeout(function(){if(qSel!='auto')pushQ(qWant())},700)}
showCtl()}
function applyQuality(){qMis=0;if(qSel!='auto')pushQ(qWant())}
function enforceQ(){
if(qSel=='auto'){qOk=true;return}
if(state()!=1)return;
var w=qWant(),c=curQ();
if(c==w){qMis=0;if(++qStable>=3){qOk=true;if(w!=qSel&&!qNote){qNote=QN[qSel]+' is not available here, playing '+QN[w];qHint(qNote)}}return}
qStable=0;qOk=false;qMis++;
if(qMis==1||qMis%4==0)pushQ(w);
if(qMis>=8){
if(qReload<2){qReload++;qMis=0;reloadAt(w)}
else if(c&&QN[c]){/* this video / phone does not give w: settle on what really plays */
var o=Object.keys(QN);if(o.indexOf(c)>o.indexOf(w)){qCap=c;qNote=QN[w]+' is not supported here, playing '+QN[c];qHint(qNote);qMis=0;qOk=true;lastQ=c}else{qMis=0}}}}
function showSpeed(){el('sp').textContent=speeds[si]+'x'}
try{var sv=parseInt(localStorage.getItem('rwSpeed'),10);if(sv>=0&&sv<speeds.length)si=sv}catch(e){}
/* The video has the shape R (width / height; 16:9 until the app knows better): the player is drawn exactly over it, plus a strip of M px above and below that is covered in black. */
function layout(){
var cw=window.innerWidth,ch=window.innerHeight;
var vw=Math.min(cw,ch*R),vh=vw/R,x=(cw-vw)/2,y=(ch-vh)/2;
var b=el('box');b.style.left=x+'px';b.style.width=vw+'px';b.style.top=(y-M)+'px';b.style.height=(vh+2*M)+'px';
var fr=document.querySelector('#box iframe'),BW=qBig(),k=BW>vw?BW/vw:1;
if(fr){if(k>1){fr.style.width=BW+'px';fr.style.height=((vh+2*M)*k)+'px';fr.style.transformOrigin='0 0';fr.style.transform='scale('+(1/k)+')'}else{fr.style.width='100%';fr.style.height='100%';fr.style.transform='none'}}
el('mt').style.height=Math.max(0,y)+'px';el('mb').style.height=Math.max(0,y)+'px';
el('fs').innerHTML=isLand()?ICON_FSX:ICON_FS;
}
function setRatio(r){if(r>0.3&&r<3){R=r;layout()}}
/* The centre button must show PAUSE while the video plays OR buffers after a seek (state 3), and PLAY only when it is really paused / stopped.
   wantPlay remembers what the person wants during buffering; the icon is also re-checked every tick so it can never stay wrong. */
var wantPlay=true,iconNow=0;
function setIcon(){var s=state();if(s==1)wantPlay=true;else if(s==2||s==0)wantPlay=false;var p=(s==1||(s==3&&wantPlay))?1:2;if(p!=iconNow){iconNow=p;el('pp').innerHTML=p==1?ICON_PAUSE:ICON_PLAY}}
function seekBy(d){if(!P)return;var t=Math.max(0,(P.getCurrentTime()||0)+d);if(dur>0)t=Math.min(t,dur-0.5);P.seekTo(t,true)}
function toggle(){var s=state();if(s==1||(s==3&&wantPlay)){wantPlay=false;P.pauseVideo()}else{wantPlay=true;P.playVideo()}setIcon()}
function rip(id){var r=el(id);r.style.opacity=1;setTimeout(function(){r.style.opacity=0},350)}
function onYouTubeIframeAPIReady(){
P=new YT.Player('p',{videoId:'__ID__',width:'100%',height:'100%',
playerVars:{autoplay:1,controls:0,disablekb:1,fs:0,rel:0,playsinline:1,modestbranding:1,iv_load_policy:3,enablejsapi:1,origin:'__ORIGIN__',start:__START__},
events:{
onReady:function(){showSpeed();try{P.playVideo()}catch(e){}applySpeed(true);layout()},
onPlaybackRateChange:function(){applySpeed()},
onPlaybackQualityChange:function(){lastQ='';qStable=0},
onStateChange:function(e){
lastV=-1;cvAt=Date.now();paintCover();
if(e.data==1){applySpeed(true);applyQuality();document.body.classList.remove('paused');el('end').style.display='none';resetEnd();setIcon();showCtl()}
else if(e.data==2){applySpeed();document.body.classList.add('paused');setIcon();showCtl()}
else if(e.data==0){if(repOn){try{P.seekTo(0,true);P.playVideo()}catch(x){}}else{el('end').style.display='flex';hideCtl();var dd=0;try{dd=P.getDuration()||0}catch(x){}bridge('onEnded',dd,0)}}
else if(e.data==3){applySpeed(true);setIcon()}
else setIcon();
},
onError:function(e){bridge('onPlayerError',e.data,0)}}});
setInterval(tick,500);
}
function tick(){
if(!P||!P.getCurrentTime)return;
applySpeed();
var c=P.getCurrentTime()||0;dur=P.getDuration()||0;
checkRate(c);enforceQ();watchQ();paintCover();if(qOpen){paintQNow();paintQMenu()}setIcon();
if(!seeking)paint(dur>0?c/dur:0,c);
ticks++;if(ticks%6==0&&c>0&&state()!=0){try{__BRIDGE__.onTick(c,dur,speeds[si])}catch(e){}}
if(ticks%2==0){try{__BRIDGE__.onPlayState(state()==1?1:0)}catch(e){}}
}
function paint(f,c){
f=Math.max(0,Math.min(1,f||0));
el('bar').style.width=(f*100)+'%';el('th').style.left=(f*100)+'%';
el('tm').textContent=fmt(c)+' / '+fmt(dur);
}
/* Taps: one tap shows / hides the controls, a double tap on the sides skips 10 s, a double tap in the middle plays / pauses. */
var lastT=0,lastZ=-1,tapTimer=null;
el('tap').addEventListener('click',function(ev){
if(qOpen){closeQ();return}
var w=window.innerWidth,z=ev.clientX<w*0.35?0:(ev.clientX>w*0.65?2:1),now=Date.now();
if(now-lastT<320&&z==lastZ){
clearTimeout(tapTimer);lastT=0;
if(z==0){seekBy(-10);rip('rl')}else if(z==2){seekBy(10);rip('rr')}else{toggle()}
showCtl();return;
}
lastT=now;lastZ=z;clearTimeout(tapTimer);
tapTimer=setTimeout(function(){if(document.body.classList.contains('ui'))hideCtl();else showCtl()},320);
});
el('pp').addEventListener('click',function(){toggle();showCtl()});
el('bk').addEventListener('click',function(){seekBy(-10);showCtl()});
el('fw').addEventListener('click',function(){seekBy(10);showCtl()});
el('sp').addEventListener('click',function(){si=(si+1)%speeds.length;try{localStorage.setItem('rwSpeed',si)}catch(e){}applySpeed(true);rateBad=0;rateFix=0;showSpeed();showCtl()});
document.addEventListener('visibilitychange',function(){showSpeed();applySpeed(true);applyQuality()});
window.addEventListener('focus',function(){showSpeed();applySpeed()});
el('bg').addEventListener('click',function(){bgOn=!bgOn;bridge('onOption','pip',bgOn?1:0);paintBg();showCtl()});
el('rp').addEventListener('click',function(){repOn=!repOn;bridge('onOption','rep',repOn?1:0);paintRep();showCtl()});
el('gr').addEventListener('click',function(){if(qOpen)closeQ();else openQ()});
el('qm').addEventListener('click',function(ev){var t=ev.target;if(t&&t.getAttribute&&t.getAttribute('data-q'))setQ(t.getAttribute('data-q'));else if(t&&t.getAttribute&&t.getAttribute('data-o'))setOpt(t.getAttribute('data-o'))});
el('fs').addEventListener('click',function(){bridge('onToggleLandscape',0,0)});
var sb=el('sb');
function frac(ev){var r=sb.getBoundingClientRect();return Math.max(0,Math.min(1,(ev.clientX-r.left)/r.width))}
sb.addEventListener('pointerdown',function(ev){seeking=true;clearTimeout(hideT);try{sb.setPointerCapture(ev.pointerId)}catch(e){}var f=frac(ev);paint(f,f*dur)});
sb.addEventListener('pointermove',function(ev){if(seeking){var f=frac(ev);paint(f,f*dur)}});
function endSeek(ev){if(!seeking)return;var f=frac(ev);seeking=false;if(dur>0)P.seekTo(f*dur,true);showCtl()}
sb.addEventListener('pointerup',endSeek);
sb.addEventListener('pointercancel',function(){seeking=false;showCtl()});
el('again').addEventListener('click',function(){var g=gapAt;el('end').style.display='none';resetEnd();P.seekTo(g>=0?g:0,true);P.playVideo()});
window.addEventListener('resize',layout);
layout();setIcon();paintBg();paintRep();
</script></body></html>
"""
}
