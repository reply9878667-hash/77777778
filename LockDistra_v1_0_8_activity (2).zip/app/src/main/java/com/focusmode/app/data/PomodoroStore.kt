package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Saved Pomodoro cycle and durations, in device-protected storage like the other stores, so a
 * running cycle is back right after a process kill or a restart. It only remembers the cycle;
 * it never touches the blocked apps, limits or website rules, which stay exactly as the user set them.
 */
class PomodoroStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "pomodoro")

    private val _state = MutableStateFlow(read())
    val state: StateFlow<PomodoroState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        _state.value = read()
    }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun current(): PomodoroState = read()

    private fun read() = PomodoroState(
        phase = runCatching { PomodoroPhase.valueOf(prefs.getString(K_PHASE, null) ?: "IDLE") }
            .getOrDefault(PomodoroPhase.IDLE),
        focusMin = PomodoroRules.clampFocus(prefs.getInt(K_FOCUS, PomodoroRules.DEFAULT_FOCUS)),
        breakMin = PomodoroRules.clampBreak(prefs.getInt(K_BREAK, PomodoroRules.DEFAULT_BREAK)),
        round = prefs.getInt(K_ROUND, 0),
        paused = prefs.getBoolean(K_PAUSED, false),
        pausedLeftMs = prefs.getLong(K_PAUSED_LEFT, 0L),
        breakEndWall = prefs.getLong(K_BREAK_WALL, 0L),
        breakEndElapsed = prefs.getLong(K_BREAK_ELAPSED, 0L),
        breakBoot = prefs.getInt(K_BREAK_BOOT, -1),
    )

    /** Applies [change] to the saved cycle in one step. commit() so a service reading it next sees it. */
    @Synchronized
    fun update(change: (PomodoroState) -> PomodoroState): PomodoroState {
        val next = change(read())
        prefs.edit()
            .putString(K_PHASE, next.phase.name)
            .putInt(K_FOCUS, PomodoroRules.clampFocus(next.focusMin))
            .putInt(K_BREAK, PomodoroRules.clampBreak(next.breakMin))
            .putInt(K_ROUND, next.round)
            .putBoolean(K_PAUSED, next.paused)
            .putLong(K_PAUSED_LEFT, next.pausedLeftMs)
            .putLong(K_BREAK_WALL, next.breakEndWall)
            .putLong(K_BREAK_ELAPSED, next.breakEndElapsed)
            .putInt(K_BREAK_BOOT, next.breakBoot)
            .commit()
        return next
    }

    /** Changes the durations. Refused while a cycle exists. */
    @Synchronized
    fun setDurations(focusMin: Int, breakMin: Int): Boolean {
        if (!PomodoroRules.canEditDurations(read())) return false
        update { it.copy(focusMin = PomodoroRules.clampFocus(focusMin), breakMin = PomodoroRules.clampBreak(breakMin)) }
        return true
    }

    companion object {
        private const val K_PHASE = "phase"
        private const val K_FOCUS = "focus_min"
        private const val K_BREAK = "break_min"
        private const val K_ROUND = "round"
        private const val K_PAUSED = "paused"
        private const val K_PAUSED_LEFT = "paused_left_ms"
        private const val K_BREAK_WALL = "break_end_wall"
        private const val K_BREAK_ELAPSED = "break_end_elapsed"
        private const val K_BREAK_BOOT = "break_boot"

        @Volatile
        private var instance: PomodoroStore? = null

        fun get(context: Context): PomodoroStore =
            instance ?: synchronized(this) {
                instance ?: PomodoroStore(context.applicationContext).also { instance = it }
            }
    }
}
