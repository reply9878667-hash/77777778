package com.focusmode.app.ui.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.focusmode.app.data.auth.AuthSession
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.theme.FocusTheme

/** The three account screens. A fourth (e.g. "verify your email") is one more value and one more branch below. */
enum class AuthScreen { SignUp, Login, Forgot }

/**
 * Account creation and login, as one self-contained overlay. Put it on top of whatever is showing; it needs
 * nothing from the host except these callbacks:
 *
 * @param startScreen where to begin (first launch: SignUp; from Settings: Login).
 * @param onFinished the person pressed Continue on the success screen (they are now logged in). The flag says
 *   whether the account was created just now (sign-up, or a first Google sign-in) rather than logged in to.
 * @param onSkip when not null, "Skip for now" is shown and calls this (first launch only).
 * @param onClose when not null, a close button and the system Back button call this (Settings only).
 *
 * Everything else (validation, Firebase, session, the trusted-phone rule) is in `data/auth`.
 */
@Composable
fun AuthFlow(
    startScreen: AuthScreen = AuthScreen.SignUp,
    onFinished: (isNewAccount: Boolean) -> Unit,
    onSkip: (() -> Unit)? = null,
    onClose: (() -> Unit)? = null,
    vm: AuthViewModel = viewModel(),
) {
    val form = vm.form
    val session by vm.session.collectAsState()
    val activity = LocalContext.current.findActivity()
    var screen by rememberSaveable { mutableStateOf(startScreen) }

    val finish = { isNew: Boolean ->
        vm.reset()
        onFinished(isNew)
    }
    val go = { to: AuthScreen ->
        vm.onScreenChanged()
        screen = to
    }

    // Why the person is here (expired session), shown once on top of the form.
    LaunchedEffect(Unit) { vm.showPendingNotice() }

    // Opened while already logged in (for example the app was restarted on the success screen): nothing to do.
    val staleOpen = form.success == null && form.busy == AuthBusy.None && session is AuthSession.SignedIn
    LaunchedEffect(staleOpen) { if (staleOpen) finish(false) }
    if (staleOpen) return

    // Back goes one step towards the screen this flow opened on, never somewhere new: Forgot -> Log in, and
    // Log in <-> Sign up only when the other one is where the person started. On the opening screen there is
    // no earlier account screen, so Back closes the flow (when the host allows it) or leaves the app.
    val backTarget: AuthScreen? = when (screen) {
        AuthScreen.Forgot -> AuthScreen.Login
        AuthScreen.Login -> if (startScreen == AuthScreen.SignUp) AuthScreen.SignUp else null
        AuthScreen.SignUp -> if (startScreen == AuthScreen.Login) AuthScreen.Login else null
    }
    BackHandler(enabled = form.success == null && backTarget != null && form.busy == AuthBusy.None) {
        backTarget?.let { go(it) }
    }
    BackHandler(enabled = form.success == null && backTarget == null && onClose != null) {
        vm.reset()
        onClose?.invoke()
    }

    val closeAction: (() -> Unit)? = onClose?.let { close -> { vm.reset(); close() } }
    val skipAction: (() -> Unit)? = onSkip?.let { skip -> { vm.reset(); skip() } }

    val success = form.success
    if (success != null) {
        SuccessScreen(success, onContinue = { finish(success.isNewAccount) })
        return
    }

    AnimatedContent(
        targetState = screen,
        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(160)) },
        label = "authScreen",
    ) { current ->
        when (current) {
            AuthScreen.SignUp -> SignUpScreen(vm, onLogin = { go(AuthScreen.Login) }, onSkip = skipAction, onClose = closeAction, activity = activity)
            AuthScreen.Login -> LoginScreen(
                vm,
                onSignUp = { go(AuthScreen.SignUp) },
                onForgot = { go(AuthScreen.Forgot) },
                onSkip = skipAction,
                onClose = closeAction,
                activity = activity,
            )
            AuthScreen.Forgot -> ForgotPasswordScreen(vm, onBack = { go(AuthScreen.Login) })
        }
    }
}

// =================================================================================================
// Sign up
// =================================================================================================

@Composable
private fun SignUpScreen(
    vm: AuthViewModel,
    onLogin: () -> Unit,
    onSkip: (() -> Unit)?,
    onClose: (() -> Unit)?,
    activity: Activity?,
) {
    val f = vm.form
    val idle = f.busy == AuthBusy.None
    AuthPage {
        CloseRow(onClose, idle)
        AuthHeading("Create your account", "Sign up in a few seconds to get started.")
        Spacer(Modifier.height(24.dp))
        GoogleButton("Continue with Google", loading = f.busy == AuthBusy.Google, enabled = idle) { vm.submitGoogle(activity) }
        Spacer(Modifier.height(18.dp))
        OrDivider()
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            AuthTextField(f.name, vm::onName, "Your name", f.nameError, idle)
            AuthTextField(f.email, vm::onEmail, "Email", f.emailError, idle, keyboardType = androidx.compose.ui.text.input.KeyboardType.Email)
            AuthTextField(
                f.password, vm::onPassword, "Password", f.passwordError, idle, isPassword = true,
                hint = "At least 8 characters, with letters and numbers.",
            )
            AuthTextField(
                f.confirm, vm::onConfirm, "Confirm password", f.confirmError, idle, isPassword = true, last = true,
                onDone = vm::submitSignUp,
            )
        }
        f.banner?.let {
            Spacer(Modifier.height(8.dp))
            AuthMessage(it, isError = true)
        }
        Spacer(Modifier.height(16.dp))
        PrimaryButton(
            text = if (f.busy == AuthBusy.Email) "Creating account..." else "Create account",
            onClick = vm::submitSignUp,
            enabled = idle,
            loading = f.busy == AuthBusy.Email,
        )
        Spacer(Modifier.height(8.dp))
        AuthSwitchRow("Already have an account?", "Log in", idle, onLogin)
        if (onSkip != null) AuthSkipButton(idle, onSkip)
    }
}

// =================================================================================================
// Log in
// =================================================================================================

@Composable
private fun LoginScreen(
    vm: AuthViewModel,
    onSignUp: () -> Unit,
    onForgot: () -> Unit,
    onSkip: (() -> Unit)?,
    onClose: (() -> Unit)?,
    activity: Activity?,
) {
    val f = vm.form
    val idle = f.busy == AuthBusy.None
    AuthPage {
        CloseRow(onClose, idle)
        AuthHeading("Welcome back", "Log in to your account.")
        Spacer(Modifier.height(24.dp))
        GoogleButton("Continue with Google", loading = f.busy == AuthBusy.Google, enabled = idle) { vm.submitGoogle(activity) }
        Spacer(Modifier.height(18.dp))
        OrDivider()
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            AuthTextField(f.email, vm::onEmail, "Email", f.emailError, idle, keyboardType = androidx.compose.ui.text.input.KeyboardType.Email)
            AuthTextField(
                f.password, vm::onPassword, "Password", f.passwordError, idle, isPassword = true, last = true,
                onDone = vm::submitLogin,
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onForgot, enabled = idle) {
                Text("Forgot password?", color = FocusTheme.colors.accent)
            }
        }
        f.banner?.let {
            AuthMessage(it, isError = true)
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(8.dp))
        PrimaryButton(
            text = if (f.busy == AuthBusy.Email) "Logging in..." else "Log in",
            onClick = vm::submitLogin,
            enabled = idle,
            loading = f.busy == AuthBusy.Email,
        )
        Spacer(Modifier.height(8.dp))
        AuthSwitchRow("New here?", "Create account", idle, onSignUp)
        if (onSkip != null) AuthSkipButton(idle, onSkip)
    }
}

// =================================================================================================
// Forgot password
// =================================================================================================

@Composable
private fun ForgotPasswordScreen(vm: AuthViewModel, onBack: () -> Unit) {
    val f = vm.form
    val idle = f.busy == AuthBusy.None
    val waiting = f.resetCooldown > 0
    AuthPage {
        Row(Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack, enabled = idle) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back to log in")
            }
        }
        AuthHeading("Reset your password", "Type your account email and we'll send you a link to choose a new password.")
        Spacer(Modifier.height(24.dp))
        AuthTextField(
            f.email, vm::onEmail, "Email", f.emailError, idle && !waiting,
            keyboardType = androidx.compose.ui.text.input.KeyboardType.Email, last = true, onDone = vm::submitReset,
        )
        f.info?.let {
            Spacer(Modifier.height(8.dp))
            AuthMessage(it, isError = false)
        }
        f.banner?.let {
            Spacer(Modifier.height(8.dp))
            AuthMessage(it, isError = true)
        }
        Spacer(Modifier.height(16.dp))
        PrimaryButton(
            text = when {
                f.busy == AuthBusy.Reset -> "Sending..."
                waiting -> "Send again in ${f.resetCooldown}s"
                f.info != null -> "Send again"
                else -> "Send reset link"
            },
            onClick = vm::submitReset,
            enabled = idle && !waiting,
            loading = f.busy == AuthBusy.Reset,
        )
        Spacer(Modifier.height(8.dp))
        AuthSwitchRow("Remembered it?", "Back to log in", idle, onBack)
    }
}

// =================================================================================================
// Success
// =================================================================================================

@Composable
private fun SuccessScreen(success: AuthSuccess, onContinue: () -> Unit) {
    val c = FocusTheme.colors
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val scale by animateFloatAsState(
        if (shown) 1f else 0.3f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "successPop",
    )
    AuthPage {
        Spacer(Modifier.height(72.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .size(96.dp)
                    .scale(scale)
                    .background(Brush.verticalGradient(listOf(c.gradMid, c.gradStart)), CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Check, contentDescription = null, tint = c.onAccent, modifier = Modifier.size(52.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        WelcomeEmojiRow(success.isNewAccount)
        Spacer(Modifier.height(16.dp))
        Text(
            if (success.isNewAccount) "Account created" else "You're logged in",
            style = MaterialTheme.typography.headlineMedium,
            color = c.text,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (success.isNewAccount) "Welcome, ${success.name}! \uD83C\uDF89" else "Welcome back, ${success.name}! \uD83D\uDC9A",
            style = MaterialTheme.typography.bodyLarge,
            color = c.muted,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(40.dp))
        PrimaryButton("Continue", onClick = onContinue)
    }
}

/** A waving hand (or a party popper for a new account) that swings, with sparkles that pulse around it. */
@Composable
private fun WelcomeEmojiRow(isNewAccount: Boolean) {
    val t = rememberInfiniteTransition(label = "welcomeEmoji")
    val swing by t.animateFloat(
        initialValue = -18f,
        targetValue = 18f,
        animationSpec = infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "swing",
    )
    val pulse by t.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("\u2728", fontSize = 26.sp, modifier = Modifier.graphicsLayer { scaleX = pulse; scaleY = pulse; alpha = pulse.coerceAtMost(1f) })
        Spacer(Modifier.width(14.dp))
        Text(
            if (isNewAccount) "\uD83C\uDF89" else "\uD83D\uDC4B",
            fontSize = 44.sp,
            modifier = Modifier.graphicsLayer { rotationZ = swing; transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.7f, 0.9f) },
        )
        Spacer(Modifier.width(14.dp))
        Text("\uD83C\uDF31", fontSize = 26.sp, modifier = Modifier.graphicsLayer { scaleX = 2f - pulse; scaleY = 2f - pulse })
    }
}

// =================================================================================================
// Small helpers
// =================================================================================================

@Composable
private fun CloseRow(onClose: (() -> Unit)?, enabled: Boolean) {
    if (onClose == null) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        IconButton(onClick = onClose, enabled = enabled) {
            Icon(Icons.Rounded.Close, contentDescription = "Close")
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
