package com.focusmode.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.WebsiteCatalog
import com.focusmode.app.data.WebsiteEdits
import com.focusmode.app.data.WebsiteRules
import com.focusmode.app.data.WebsiteState
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.theme.FocusTheme

/** What the "Blocked websites" list needs: the same add / edit / delete / switch actions as an app's list. */
internal class OwnSites(
    val canTighten: Boolean,
    val canLoosen: Boolean,
    val onAddMany: (raw: String, subdomains: Boolean) -> WebsiteEdits.Bulk,
    val onAdd: (raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    val onEdit: (old: String, raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    val onRemove: (domain: String) -> Unit,
    val onEnabled: (domain: String, on: Boolean) -> Unit,
)

/**
 * Website Blocking, as its own card in the Blocking section. Everything about website blocking is in here:
 *  - "Blocked websites": any website the person types (youtube.com, a link, several at once), each with edit,
 *    delete and its own ON/OFF switch. These close in the browsers during every focus session.
 *  - "Inside specific apps": the older per-app lists. Tapping an app opens that app's own settings panel.
 */
@Composable
internal fun WebsiteBlockingCard(
    websites: WebsiteState,
    apps: List<AppInfo>,
    onOpenApp: (pkg: String) -> Unit,
    modifier: Modifier = Modifier,
    /**
     * The person's own "Blocked websites" list (sites that belong to no app). Only the phone-wide Blocking screen
     * passes this; a Focus Profile does not, so its card stays as it was.
     */
    own: OwnSites? = null,
) {
    val c = FocusTheme.colors
    var open by remember { mutableStateOf(false) }

    // Installed apps that can block sites, plus any app that already has rules.
    val entries = remember(apps, websites) {
        apps.filter {
            WebsiteCatalog.supports(it.packageName) ||
                websites.isOn(it.packageName) ||
                websites.rulesFor(it.packageName).isNotEmpty()
        }.sortedBy { it.label.lowercase() }
    }
    val ownRules = websites.rulesFor(WebsiteCatalog.GENERAL)
    val activeApps = websites.activeOwners().count { it != WebsiteCatalog.GENERAL }
    val activeSites = websites.activeOwners().sumOf { owner -> websites.rulesFor(owner).count { it.enabled } }

    FocusCard(
        modifier = modifier,
        onClick = { open = !open },
        padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        highlight = websites.hasActiveRules
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Website Blocking", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (websites.hasActiveRules)
                            "ON • $activeSites site${if (activeSites == 1) "" else "s"} blocked" +
                                if (activeApps > 0) " • $activeApps app${if (activeApps == 1) "" else "s"}" else ""
                        else if (own != null) "Block any website in your browser"
                        else "Close chosen sites inside an app",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (websites.hasActiveRules) c.accent else c.muted
                    )
                }
                Icon(
                    if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    if (open) "Hide apps" else "Show apps",
                    tint = c.muted
                )
            }
            if (open && own != null) {
                Spacer(Modifier.height(12.dp))
                Text("BLOCKED WEBSITES", style = MaterialTheme.typography.labelSmall, color = c.muted)
                if (ownRules.isEmpty()) {
                    Text(
                        "No websites yet. Add youtube.com, instagram.com or any link.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                WebsiteSiteList(
                    rules = ownRules,
                    canTighten = own.canTighten,
                    canLoosen = own.canLoosen,
                    onAdd = own.onAdd,
                    onEdit = own.onEdit,
                    onRemove = own.onRemove,
                    onRuleEnabled = own.onEnabled,
                    onAddMany = own.onAddMany,
                )
                if (entries.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text("INSIDE SPECIFIC APPS", style = MaterialTheme.typography.labelSmall, color = c.muted)
                }
            }
            if (open && (own == null || entries.isNotEmpty())) {
                Text(
                    if (entries.isEmpty()) "None of the apps that support website blocking are installed."
                    else "Pick an app to switch website blocking on or off and to add, edit or remove its sites.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    entries.forEach { app ->
                        val rules = websites.rulesFor(app.packageName)
                        val on = websites.isOn(app.packageName)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onOpenApp(app.packageName) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(app.packageName, 32.dp)
                            Spacer(Modifier.size(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(app.label, style = MaterialTheme.typography.bodyLarge, maxLines = 1)
                                Text(
                                    when {
                                        on && rules.isNotEmpty() -> "On • ${rules.count { it.enabled }} of ${rules.size} site${if (rules.size == 1) "" else "s"} active"
                                        rules.isNotEmpty() -> "Off • ${rules.size} site${if (rules.size == 1) "" else "s"} saved"
                                        else -> "Not set up"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (on && rules.isNotEmpty()) c.accent else c.muted
                                )
                            }
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.muted)
                        }
                    }
                }
            }
        }
    }
}
