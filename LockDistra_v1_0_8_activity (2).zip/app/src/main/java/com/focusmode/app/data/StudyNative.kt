package com.focusmode.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** The page came back, but it held no search data we could read (YouTube changed its page, or a consent / bot page came). */
class NoDataException : IOException("YouTube's page held no readable search data")

/** One result read straight from YouTube's search page data. */
data class NativeResult(
    val id: String,
    val title: String,
    val channelId: String,
    val channelTitle: String,
    val durationLabel: String,
    val extra: String,
    /** The channel's round picture as the page showed it ("" = the page had none). */
    val avatarUrl: String = "",
) {
    /** Approximate upload time read from the page's "3 days ago" label; 0 = the page showed none. */
    val publishedAt: Long get() = StudyRules.parseAgoLabel(extra)

    /** The same shape the web filter ([StudyWeb]) already judges. */
    val card: WebCard get() = WebCard(id, title.take(200), "$channelTitle $extra".take(400), durationLabel)
}

/** One channel read from YouTube's search page data (the "Channel" filter). */
data class NativeChannel(val id: String, val name: String, val handle: String, val avatarUrl: String, val subsLabel: String)

/**
 * Study search WITHOUT the YouTube API and WITHOUT a WebView: one plain HTTPS request to YouTube's search page, then the
 * page's own result data (`ytInitialData`) is read as JSON. It costs none of the daily API limit and is fast (one request,
 * no page rendering). Results are still judged by [StudyWeb.judge] before anything is shown.
 *
 * It reads the page by the NAMES OF THE DATA (videoId, title, length), not by page layout, and knows both the classic
 * `videoRenderer` and the newer `lockupViewModel`. If YouTube changes the data so much that nothing is found, a
 * [NoDataException] is thrown and the app falls back to the WebView search. No Android classes: unit tested on the JVM.
 */
object StudyNative {
    const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    /** YouTube's own "Video" filter (no channels / playlists / movies). */
    private const val VIDEOS_ONLY = "EgIQAQ%253D%253D"

    /** YouTube's own "Channel" filter (only channels). */
    private const val CHANNELS_ONLY = "EgIQAg%253D%253D"

    private val DURATION = Regex("^(\\d{1,2}:)?\\d{1,2}:\\d{2}$")

    fun searchUrl(query: String): String =
        "https://www.youtube.com/results?search_query=" + URLEncoder.encode(StudyWeb.biasedQuery(query), "UTF-8") +
            "&sp=" + VIDEOS_ONLY + "&hl=en&gl=IN"

    /** The typed words exactly as typed (no study words added): a channel is found by its name. */
    fun channelSearchUrl(query: String): String =
        "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query.trim(), "UTF-8") +
            "&sp=" + CHANNELS_ONLY + "&hl=en&gl=IN"

    /** Blocking. Channels whose name matches [query], best first (at most [max]). Costs none of the daily API limit. */
    fun searchChannels(query: String, max: Int = 6): List<NativeChannel> {
        val data = extractInitialData(fetch(channelSearchUrl(query))) ?: throw NoDataException()
        return parseChannels(data, max)
    }

    /** Every channel found anywhere in [root], in page order, without repeats. Read by the names of the data, not by layout. */
    fun parseChannels(root: JSONObject, max: Int = 6): List<NativeChannel> {
        val out = ArrayList<NativeChannel>()
        val seen = HashSet<String>()
        fun add(c: NativeChannel?) {
            if (c != null && c.id.startsWith("UC") && c.name.isNotBlank() && seen.add(c.id)) out += c
        }
        fun walk(n: Any?, depth: Int) {
            if (depth > 40 || out.size >= max) return
            if (n is JSONObject) {
                val keys = n.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = n.opt(k)
                    when (k) {
                        "channelRenderer" -> if (v is JSONObject) add(channelFromRenderer(v))
                        "lockupViewModel" -> if (v is JSONObject && v.optString("contentType").contains("CHANNEL")) add(channelFromLockup(v)) else walk(v, depth + 1)
                        else -> walk(v, depth + 1)
                    }
                }
            } else if (n is JSONArray) {
                for (i in 0 until n.length()) walk(n.opt(i), depth + 1)
            }
        }
        walk(root, 0)
        return out
    }

    private fun channelFromRenderer(o: JSONObject): NativeChannel? {
        val id = o.optString("channelId")
        val name = text(o.optJSONObject("title"))
        val pic = o.optJSONObject("thumbnail")?.optJSONArray("thumbnails")?.optJSONObject(0)?.optString("url").orEmpty()
        // In the new data the handle is in subscriberCountText and the subscribers in videoCountText (older data: the other way round).
        val a = text(o.optJSONObject("subscriberCountText"))
        val b = text(o.optJSONObject("videoCountText"))
        val handle = listOf(a, b).firstOrNull { it.startsWith("@") }.orEmpty()
        val subs = listOf(a, b).firstOrNull { it.isNotBlank() && !it.startsWith("@") }.orEmpty()
        return NativeChannel(id, name, handle, StudyRules.imageUrl(if (pic.startsWith("//")) "https:$pic" else pic), subs)
    }

    private fun channelFromLockup(o: JSONObject): NativeChannel? {
        val id = o.optString("contentId").takeIf { it.startsWith("UC") } ?: findBrowseId(o) ?: return null
        val meta = o.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel")
        val name = meta?.optJSONObject("title")?.optString("content").orEmpty()
        val parts = ArrayList<String>()
        val rows = meta?.optJSONObject("metadata")?.optJSONObject("contentMetadataViewModel")?.optJSONArray("metadataRows")
        if (rows != null) for (i in 0 until rows.length()) {
            val ps = rows.optJSONObject(i)?.optJSONArray("metadataParts") ?: continue
            for (j in 0 until ps.length()) ps.optJSONObject(j)?.optJSONObject("text")?.optString("content")?.takeIf { it.isNotBlank() }?.let { parts += it }
        }
        val handle = parts.firstOrNull { it.startsWith("@") }.orEmpty()
        val subs = parts.firstOrNull { !it.startsWith("@") }.orEmpty()
        return NativeChannel(id, name, handle, findAvatar(meta), subs)
    }

    /** Blocking. Throws [IOException] (network) or [NoDataException] (nothing readable on the page). */
    fun search(query: String): List<NativeResult> {
        val html = fetch(searchUrl(query))
        return parseHtml(html)
    }

    fun parseHtml(html: String): List<NativeResult> {
        val data = extractInitialData(html) ?: throw NoDataException()
        val list = parseResults(data)
        if (list.isEmpty()) {
            // A real search with no video at all is possible, but a page with no result list at all means a layout we do not know.
            if (!html.contains("\"contents\"")) throw NoDataException()
        }
        return list
    }

    private fun fetch(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", USER_AGENT)
        c.setRequestProperty("Accept-Language", "en-IN,en;q=0.9,hi;q=0.8")
        c.setRequestProperty("Cookie", "CONSENT=YES+cb.20240101-00-p0.en+FX+000; SOCS=CAI")
        val code = c.responseCode
        if (code != 200) throw HttpStatusException(code)
        return c.inputStream.use { it.bufferedReader(Charsets.UTF_8).readText() }
    }

    /** The JSON object that follows `ytInitialData =` in the page. String-aware, so braces inside titles do not confuse it. */
    fun extractInitialData(html: String): JSONObject? =
        extractJson(html, listOf("var ytInitialData = ", "ytInitialData = ", "window[\"ytInitialData\"] = "))

    /** The JSON object that follows the first of [markers] found in [html]. String-aware. null when there is none / it is damaged. */
    fun extractJson(html: String, markers: List<String>): JSONObject? {
        for (marker in markers) {
            val at = html.indexOf(marker)
            if (at < 0) continue
            val from = at + marker.length
            val start = html.indexOf('{', from)
            if (start < 0 || start - from > 3) continue
            var depth = 0
            var inStr = false
            var esc = false
            var i = start
            while (i < html.length) {
                val ch = html[i]
                if (inStr) {
                    if (esc) esc = false
                    else if (ch == '\\') esc = true
                    else if (ch == '"') inStr = false
                } else {
                    if (ch == '"') inStr = true
                    else if (ch == '{') depth++
                    else if (ch == '}') {
                        depth--
                        if (depth == 0) {
                            return try { JSONObject(html.substring(start, i + 1)) } catch (e: Exception) { null }
                        }
                    }
                }
                i++
            }
        }
        return null
    }

    /** What a video's watch page says about it: the FULL description (the creator's notes) and the upload time. */
    data class WatchInfo(val description: String, val publishedAt: Long)

    /** Reads [WatchInfo] out of a watch page's HTML (`ytInitialPlayerResponse`). null when the page held nothing readable. */
    fun parseWatchInfo(html: String): WatchInfo? {
        val data = extractJson(html, listOf("var ytInitialPlayerResponse = ", "ytInitialPlayerResponse = ", "window[\"ytInitialPlayerResponse\"] = "))
            ?: return null
        val description = data.optJSONObject("videoDetails")?.optString("shortDescription").orEmpty().trim()
        val micro = data.optJSONObject("microformat")?.optJSONObject("playerMicroformatRenderer")
        val published = StudyRules.parseIsoDate(micro?.optString("publishDate")?.takeIf { it.isNotBlank() } ?: micro?.optString("uploadDate"))
        if (description.isEmpty() && published == 0L) return null
        return WatchInfo(description, published)
    }

    /** Blocking. Costs none of the daily API limit. null on any failure (the panel then simply shows what it already has). */
    fun watchInfo(id: String): WatchInfo? = try {
        if (!StudyWeb.isVideoId(id)) null else parseWatchInfo(fetch("https://www.youtube.com/watch?v=$id&hl=en&gl=IN"))
    } catch (e: Exception) {
        null
    }

    /** Every video found anywhere in [root], in page order, without repeats. Shorts, ads and channels have other names and are skipped. */
    fun parseResults(root: JSONObject, max: Int = 40): List<NativeResult> {
        val out = ArrayList<NativeResult>()
        val seen = HashSet<String>()
        fun add(r: NativeResult?) {
            if (r != null && StudyWeb.isVideoId(r.id) && r.title.isNotBlank() && seen.add(r.id)) out += r
        }
        fun walk(n: Any?, depth: Int) {
            if (depth > 40 || out.size >= max) return
            if (n is JSONObject) {
                val keys = n.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    val v = n.opt(k)
                    when (k) {
                        "videoRenderer", "compactVideoRenderer", "videoWithContextRenderer" -> if (v is JSONObject) add(fromRenderer(v))
                        "lockupViewModel" -> if (v is JSONObject) add(fromLockup(v))
                        else -> walk(v, depth + 1)
                    }
                }
            } else if (n is JSONArray) {
                for (i in 0 until n.length()) walk(n.opt(i), depth + 1)
            }
        }
        walk(root, 0)
        return out
    }

    private fun text(o: JSONObject?): String {
        if (o == null) return ""
        val s = o.optString("simpleText")
        if (s.isNotEmpty()) return s
        val runs = o.optJSONArray("runs") ?: return o.optString("content")
        return (0 until runs.length()).joinToString("") { runs.optJSONObject(it)?.optString("text").orEmpty() }
    }

    private fun fromRenderer(o: JSONObject): NativeResult? {
        val id = o.optString("videoId")
        val title = text(o.optJSONObject("title") ?: o.optJSONObject("headline"))
        var dur = text(o.optJSONObject("lengthText"))
        if (dur.isEmpty()) dur = findDuration(o.optJSONArray("thumbnailOverlays")) ?: ""
        val owner = o.optJSONObject("ownerText") ?: o.optJSONObject("shortBylineText") ?: o.optJSONObject("longBylineText")
        val channelId = owner?.optJSONArray("runs")?.optJSONObject(0)?.optJSONObject("navigationEndpoint")
            ?.optJSONObject("browseEndpoint")?.optString("browseId").orEmpty()
        val extra = listOf(
            text(o.optJSONObject("viewCountText") ?: o.optJSONObject("shortViewCountText")),
            text(o.optJSONObject("publishedTimeText")),
        ).filter { it.isNotBlank() }.joinToString(" ")
        val avatar = findAvatar(o.optJSONObject("channelThumbnailSupportedRenderers"))
        return NativeResult(id, title, channelId, text(owner), dur, extra, avatar)
    }

    private fun fromLockup(o: JSONObject): NativeResult? {
        if (o.optString("contentType") != "LOCKUP_CONTENT_TYPE_VIDEO") return null
        val id = o.optString("contentId")
        val meta = o.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel")
        val title = meta?.optJSONObject("title")?.optString("content").orEmpty()
        val rows = meta?.optJSONObject("metadata")?.optJSONObject("contentMetadataViewModel")?.optJSONArray("metadataRows")
        val parts = ArrayList<String>()
        if (rows != null) {
            for (i in 0 until rows.length()) {
                val ps = rows.optJSONObject(i)?.optJSONArray("metadataParts") ?: continue
                for (j in 0 until ps.length()) {
                    val t = ps.optJSONObject(j)?.optJSONObject("text")?.optString("content").orEmpty()
                    if (t.isNotBlank()) parts += t
                }
            }
        }
        val dur = findDuration(o.optJSONObject("contentImage")) ?: ""
        val channelId = findBrowseId(meta) ?: ""
        return NativeResult(id, title, channelId, parts.firstOrNull().orEmpty(), dur, parts.drop(1).joinToString(" "), findAvatar(meta))
    }

    /**
     * The channel's round picture anywhere inside [n]: the classic `channelThumbnailWithLinkRenderer` (thumbnails list) or the
     * newer `avatarViewModel` (image sources). Read by name, not by layout, like everything else here. "" when there is none.
     */
    private fun findAvatar(n: Any?, depth: Int = 0): String {
        if (depth > 12) return ""
        when (n) {
            is JSONObject -> {
                n.optJSONObject("channelThumbnailWithLinkRenderer")?.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
                    ?.optJSONObject(0)?.optString("url")?.let { StudyRules.imageUrl(it) }?.takeIf { it.isNotEmpty() }?.let { return it }
                n.optJSONObject("avatarViewModel")?.optJSONObject("image")?.optJSONArray("sources")
                    ?.optJSONObject(0)?.optString("url")?.let { StudyRules.imageUrl(it) }?.takeIf { it.isNotEmpty() }?.let { return it }
                val keys = n.keys()
                while (keys.hasNext()) {
                    val found = findAvatar(n.opt(keys.next()), depth + 1)
                    if (found.isNotEmpty()) return found
                }
            }
            is JSONArray -> for (i in 0 until n.length()) {
                val found = findAvatar(n.opt(i), depth + 1)
                if (found.isNotEmpty()) return found
            }
        }
        return ""
    }

    /** The first string anywhere inside [n] that looks like a length ("12:34", "1:02:03"). */
    private fun findDuration(n: Any?, depth: Int = 0): String? {
        if (depth > 12) return null
        when (n) {
            is String -> return if (DURATION.matches(n.trim())) n.trim() else null
            is JSONObject -> {
                val keys = n.keys()
                while (keys.hasNext()) findDuration(n.opt(keys.next()), depth + 1)?.let { return it }
            }
            is JSONArray -> for (i in 0 until n.length()) findDuration(n.opt(i), depth + 1)?.let { return it }
        }
        return null
    }

    /** The first channel id (UC...) anywhere inside [n]. */
    private fun findBrowseId(n: Any?, depth: Int = 0): String? {
        if (depth > 14) return null
        when (n) {
            is JSONObject -> {
                val b = n.optString("browseId")
                if (b.startsWith("UC") && b.length == 24) return b
                val keys = n.keys()
                while (keys.hasNext()) findBrowseId(n.opt(keys.next()), depth + 1)?.let { return it }
            }
            is JSONArray -> for (i in 0 until n.length()) findBrowseId(n.opt(i), depth + 1)?.let { return it }
        }
        return null
    }
}
