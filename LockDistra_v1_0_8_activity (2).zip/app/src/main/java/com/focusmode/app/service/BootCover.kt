package com.focusmode.app.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.content.res.ColorStateList

/**
 * The screen shown for a few seconds after a restart, while LockDistra's protection is still starting.
 *
 * It is a normal "display over other apps" window (the accessibility service, which draws the other overlays, is
 * exactly what is not running yet). The background is blurred where the phone supports it (Android 12+), otherwise
 * a dark scrim; on top sit a small spinner and the text "Setting up LockDistra…". It takes every touch, so Settings
 * underneath cannot be used. [BootCoverService] removes it as soon as protection is running.
 */
class BootCover(context: Context, private val a11y: android.accessibilityservice.AccessibilityService? = null) {

    private val appContext = context.applicationContext
    private val wm = (a11y ?: appContext).getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, appContext.resources.displayMetrics)

    val isShowing: Boolean get() = view != null

    /** True when drawn by the accessibility service (no "Display over other apps" window, no overlay warning). */
    val isAccessibility: Boolean get() = a11y != null

    fun show() {
        if (view != null) return
        val blur = Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled
        val root = FrameLayout(appContext).apply {
            // With real blur a lighter scrim is enough; without it the background must be dark to hide what is behind.
            setBackgroundColor(if (blur) Color.argb(120, 9, 5, 20) else Color.argb(238, 9, 5, 20))
            isClickable = true
            isFocusable = true
            setOnTouchListener { _, _ -> true }
            // Fully visible from the first frame. (A fade-in never runs while the screen is locked / the window
            // is not drawn yet, which left the cover invisible for a moment after unlock.)
        }
        val column = LinearLayout(appContext).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val spinner = ProgressBar(appContext).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(ACCENT)
        }
        column.addView(spinner, LinearLayout.LayoutParams(dp(44f).toInt(), dp(44f).toInt()))
        column.addView(TextView(appContext).apply {
            text = "Setting up LockDistra…"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(20f).toInt()
        })
        column.addView(TextView(appContext).apply {
            text = "Your protection is starting. This takes a few seconds."
            setTextColor(Color.argb(190, 255, 255, 255))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8f).toInt()
            marginStart = dp(32f).toInt()
            marginEnd = dp(32f).toInt()
        })
        root.addView(column, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER
        ))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (a11y != null) WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY else WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or
                (if (blur) WindowManager.LayoutParams.FLAG_BLUR_BEHIND else 0),
            PixelFormat.TRANSLUCENT
        ).apply {
            if (blur) blurBehindRadius = 60
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        }
        try {
            wm.addView(root, lp)
            view = root
        } catch (_: Exception) {
            // No permission or the window can't be added: nothing is shown, nothing is locked.
            view = null
        }
    }

    fun hide() {
        val v = view ?: return
        view = null
        v.animate().alpha(0f).setDuration(250).withEndAction {
            try {
                wm.removeView(v)
            } catch (_: Exception) {
            }
        }.start()
        // If the animation never runs (screen off), make sure the window is gone anyway.
        v.postDelayed({
            try {
                wm.removeView(v)
            } catch (_: Exception) {
            }
        }, 600)
    }

    private companion object {
        val ACCENT = Color.rgb(0xC0, 0x44, 0xFF)
    }
}
