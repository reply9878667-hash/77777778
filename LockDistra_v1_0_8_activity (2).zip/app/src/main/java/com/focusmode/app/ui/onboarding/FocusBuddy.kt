package com.focusmode.app.ui.onboarding

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.clearAndSetSemantics
import com.focusmode.app.data.BuddyMood
import com.focusmode.app.ui.theme.FocusTheme
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * What the mascot is doing with its body. Switching between poses is always smooth: every part of the
 * body glides to its new position, so a screen only has to say which pose it wants.
 *
 *  - [Idle]            smiling, breathing, looking around, blinking
 *  - [Greeting]        waving hello with a happy face and little sparkles
 *  - [GreetingTalking] waving and talking at the same time ("Hey there!")
 *  - [Talking]         mouth moves, free hand gestures, small nods
 *  - [Thinking]        hand on chin, eyes up, one eyebrow raised, thought bubble
 *
 * A pose can be combined with a [BuddyMood] (Part 2C): the pose says what the mascot is doing right
 * now (talking, waving), the mood says how it feels about the question.
 */
enum class BuddyPose(val wave: Boolean, val talk: Boolean, val think: Boolean) {
    Idle(wave = false, talk = false, think = false),
    Greeting(wave = true, talk = false, think = false),
    GreetingTalking(wave = true, talk = true, think = false),
    Talking(wave = false, talk = true, think = false),
    Thinking(wave = false, talk = false, think = true),
}

/**
 * The onboarding mascot: a round violet sprout buddy (the plant of the app, with a face).
 * It is drawn in one Canvas with gradients, a gloss highlight and soft shadows for depth, and it
 * is never a static picture: it breathes, blinks, looks around and sways even in [BuddyPose.Idle].
 *
 * The same character is used on every onboarding screen. It keeps the aspect ratio 360:400 and
 * centres itself inside whatever size it is given.
 *
 * Part 2C adds two optional inputs; with their defaults the mascot is exactly Part 1's:
 *  - [mood]: how it feels (see [BuddyMood]). Changing it glides the face, head and arms to the new
 *    look, with the face leading and the body following a moment later. A mood also gives a short
 *    burst of energy (a wave, raised arm, sparkles) that settles down after about two seconds, so it
 *    never keeps waving forever.
 *  - [reactionTick]: change this number whenever the person does something (picks an option, types)
 *    and the mascot reacts once: a nod, a head tilt or a little hop, picked at random so it is never
 *    the same twice in a row.
 *
 * On top of that it fidgets by itself: now and then it glances somewhere, tilts its head the other
 * way or flicks a brow, at random times.
 */
@Composable
fun FocusBuddy(
    pose: BuddyPose,
    modifier: Modifier = Modifier,
    mood: BuddyMood = BuddyMood.Neutral,
    reactionTick: Int = 0,
) {
    val c = FocusTheme.colors
    val palette = remember(c.gradStart, c.leafLight, c.leafMid, c.leafDeep, c.blossom) {
        BuddyPalette(c.gradStart, c.leafLight, c.leafMid, c.leafDeep, c.blossom)
    }
    val painter = remember(palette) { BuddyPainter(palette) }

    // Pose weights glide with springs / tweens, so changing pose never snaps.
    val glide = spring<Float>(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow)
    val wave = animateFloatAsState(if (pose.wave) 1f else 0f, glide, label = "buddyWave")
    val talk = animateFloatAsState(if (pose.talk) 1f else 0f, tween(280), label = "buddyTalk")
    val think = animateFloatAsState(if (pose.think) 1f else 0f, glide, label = "buddyThink")

    // Natural blinking: random gap, sometimes a quick double blink.
    val blink = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        val random = Random(System.nanoTime())
        while (true) {
            delay(2200L + random.nextLong(2600L))
            blink.animateTo(1f, tween(70, easing = LinearEasing))
            blink.animateTo(0f, tween(110, easing = LinearEasing))
            if (random.nextInt(4) == 0) {
                delay(120)
                blink.animateTo(1f, tween(70, easing = LinearEasing))
                blink.animateTo(0f, tween(110, easing = LinearEasing))
            }
        }
    }

    // ---- Mood (Part 2C) -------------------------------------------------------------------------
    // One animated number per look value. They are only read while drawing.
    val look = remember {
        val start = BuddyLook().toArray()
        Array(BuddyLook.SIZE) { Animatable(start[it]) }
    }
    LaunchedEffect(mood) {
        val target = mood.look().toArray()
        coroutineScope {
            for (i in target.indices) {
                launch {
                    // The face reacts first, the body a moment later.
                    if (i >= BuddyLook.FACE_COUNT) delay(120)
                    look[i].animateTo(target[i], spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow))
                }
            }
        }
    }

    // Energy burst: up fast when a mood starts or the person does something, then calms down.
    val burst = remember { Animatable(0f) }
    LaunchedEffect(mood, reactionTick) {
        if (mood == BuddyMood.Neutral) {
            burst.animateTo(0f, tween(300))
        } else {
            burst.animateTo(1f, tween(220))
            delay(2100)
            burst.animateTo(0f, tween(700))
        }
    }

    // One-off reaction to the person's input: a nod, a tilt or a hop (random each time).
    val bump = remember { Animatable(0f) }
    val dip = remember { mutableFloatStateOf(0f) }
    val tiltKick = remember { mutableFloatStateOf(0f) }
    val hopKick = remember { mutableFloatStateOf(0f) }
    var lastTick by remember { mutableIntStateOf(reactionTick) }
    val reactRandom = remember { Random(System.nanoTime() + 11) }
    LaunchedEffect(reactionTick) {
        if (reactionTick == lastTick) return@LaunchedEffect
        lastTick = reactionTick
        when (reactRandom.nextInt(3)) {
            0 -> { dip.floatValue = 1f; tiltKick.floatValue = 0f; hopKick.floatValue = 0f }
            1 -> { dip.floatValue = 0.4f; tiltKick.floatValue = if (reactRandom.nextBoolean()) 1f else -1f; hopKick.floatValue = 0f }
            else -> { dip.floatValue = 0f; tiltKick.floatValue = 0f; hopKick.floatValue = 1f }
        }
        bump.animateTo(1f, tween(130))
        bump.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMediumLow))
    }

    // Small random fidgets so it never looks like a loop: a glance, a head tilt, a brow flick.
    val fidX = remember { Animatable(0f) }
    val fidY = remember { Animatable(0f) }
    val fidTilt = remember { Animatable(0f) }
    val fidBrow = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        val r = Random(System.nanoTime() + 29)
        while (true) {
            delay(2600L + r.nextLong(3800L))
            when (r.nextInt(3)) {
                0 -> coroutineScope {
                    launch { fidX.animateTo(r.nextFloat() * 10f - 5f, tween(260)) }
                    launch { fidY.animateTo(r.nextFloat() * 6f - 3f, tween(260)) }
                    delay(900L + r.nextLong(900L))
                    launch { fidX.animateTo(0f, tween(380)) }
                    launch { fidY.animateTo(0f, tween(380)) }
                }

                1 -> {
                    fidTilt.animateTo(if (r.nextBoolean()) 3.5f else -3.5f, tween(520))
                    delay(1100L + r.nextLong(900L))
                    fidTilt.animateTo(0f, tween(620))
                }

                else -> {
                    fidBrow.animateTo(1f, tween(140))
                    delay(420L)
                    fidBrow.animateTo(0f, tween(260))
                }
            }
        }
    }

    // ---- Dance (Part 2D) ------------------------------------------------------------------------
    // While the mood is Celebrating the body dances: moves are picked at random, one after the other,
    // and blended into each other (see BuddyDance.kt). The face keeps its own life (blinks, glances).
    val dancing = mood == BuddyMood.Celebrating
    val dance = animateFloatAsState(if (dancing) 1f else 0f, tween(700), label = "buddyDance")
    val moveA = remember { mutableIntStateOf(0) }
    val moveB = remember { mutableIntStateOf(0) }
    val moveBlend = remember { Animatable(1f) }
    LaunchedEffect(dancing) {
        if (!dancing) return@LaunchedEffect
        val r = Random(System.nanoTime() + 5)
        var current = r.nextInt(DanceMoves.COUNT)
        moveA.intValue = current
        moveB.intValue = current
        moveBlend.snapTo(1f)
        while (true) {
            delay(3000L + r.nextLong(1800L))
            var next = r.nextInt(DanceMoves.COUNT - 1)
            if (next >= current) next++
            moveA.intValue = current
            moveB.intValue = next
            moveBlend.snapTo(0f)
            moveBlend.animateTo(1f, tween(520))
            current = next
        }
    }

    // One clock for every periodic movement. It is only read while drawing, so a frame redraws the
    // Canvas but never recomposes anything.
    var timeMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { now -> timeMs = (now - start) / 1_000_000L }
        }
    }

    val inputs = remember {
        BuddyInputs(
            poseWave = wave, talk = talk, poseThink = think, blink = blink.asState(),
            burst = burst.asState(), bump = bump.asState(), dip = dip, tiltKick = tiltKick, hopKick = hopKick,
            fidX = fidX.asState(), fidY = fidY.asState(), fidTilt = fidTilt.asState(), fidBrow = fidBrow.asState(),
            look = look.map { it.asState() },
            dance = dance, moveA = moveA, moveB = moveB, moveBlend = moveBlend.asState(),
        )
    }

    Canvas(modifier.clearAndSetSemantics { }) {
        painter.draw(this, timeMs / 1000f, inputs)
    }
}

/** Everything the painter reads each frame. All of it is animated state, read only while drawing. */
private class BuddyInputs(
    val poseWave: State<Float>,
    val talk: State<Float>,
    val poseThink: State<Float>,
    val blink: State<Float>,
    val burst: State<Float>,
    val bump: State<Float>,
    val dip: State<Float>,
    val tiltKick: State<Float>,
    val hopKick: State<Float>,
    val fidX: State<Float>,
    val fidY: State<Float>,
    val fidTilt: State<Float>,
    val fidBrow: State<Float>,
    val look: List<State<Float>>,
    val dance: State<Float>,
    val moveA: State<Int>,
    val moveB: State<Int>,
    val moveBlend: State<Float>,
)

/** Colours (and the gradients made from them) built once per theme, then reused every frame. */
private class BuddyPalette(
    val mid: Color,
    val leafLight: Color,
    val leafMid: Color,
    val leafDeep: Color,
    blossom: Color,
) {
    val light = lerp(mid, Color.White, 0.45f)
    val deep = lerp(mid, Color(0xFF1B0F40), 0.45f)

    val ink = Color(0xFF1B1033)
    val mouthInk = Color(0xFF4A1356)
    val browInk = Color(0xFF4C1D95).copy(alpha = 0.85f)
    val tongue = Color(0xFFF472B6)
    val handShine = Color.White.copy(alpha = 0.35f)
    val armHighlight = Color.White.copy(alpha = 0.22f)
    val leafRib = Color.White.copy(alpha = 0.35f)
    val sparkle = lerp(blossom, Color.White, 0.5f)
    val bubbleEdge = mid.copy(alpha = 0.35f)

    private val shadowTone = Color(0xFF1A0840)

    val groundShadow = Brush.radialGradient(
        listOf(shadowTone.copy(alpha = 0.34f), shadowTone.copy(alpha = 0f)),
        center = Offset(180f, 386f), radius = 100f
    )
    val neckShadow = Brush.radialGradient(
        listOf(shadowTone.copy(alpha = 0.36f), shadowTone.copy(alpha = 0f)),
        center = Offset(180f, 282f), radius = 68f
    )

    private fun ball(cx: Float, cy: Float, r: Float) = Brush.radialGradient(
        0f to light, 0.5f to mid, 1f to deep, center = Offset(cx, cy), radius = r
    )

    val footLeft = ball(136f, 366f, 34f)
    val footRight = ball(208f, 366f, 34f)
    val body = ball(155f, 290f, 130f)
    val belly = Brush.radialGradient(
        listOf(Color.White.copy(alpha = 0.95f), Color(0xFFE9DDFF).copy(alpha = 0.9f)),
        center = Offset(176f, 322f), radius = 46f
    )
    val head = ball(142f, 120f, 205f)
    val headShade = Brush.verticalGradient(
        0f to shadowTone.copy(alpha = 0f), 1f to shadowTone.copy(alpha = 0.38f),
        startY = 162f, endY = 277f
    )
    val plate = Brush.verticalGradient(
        0f to Color.White, 1f to Color(0xFFECE0FF), startY = 114f, endY = 254f
    )
    val blushLeft = Brush.radialGradient(
        listOf(blossom.copy(alpha = 0.85f), blossom.copy(alpha = 0f)),
        center = Offset(106f, 208f), radius = 20f
    )
    val blushRight = Brush.radialGradient(
        listOf(blossom.copy(alpha = 0.85f), blossom.copy(alpha = 0f)),
        center = Offset(254f, 208f), radius = 20f
    )
    val armLeft = Brush.radialGradient(listOf(light, mid), center = Offset(122f, 298f), radius = 130f)
    val armRight = Brush.radialGradient(listOf(light, mid), center = Offset(238f, 298f), radius = 130f)

    val stem = Brush.verticalGradient(0f to leafMid, 1f to leafDeep, startY = 60f, endY = 110f)
    val leafBig = Brush.radialGradient(
        listOf(leafLight, leafDeep), center = Offset(176f, 47f), radius = 50f
    )
    val leafSmall = Brush.radialGradient(
        listOf(leafLight, leafMid), center = Offset(176f, 53f), radius = 38f
    )
}

private const val W = 360f
private const val H = 400f
private const val TAU = 6.2831855f
private const val PI_F = 3.1415927f
private val EYE_X = floatArrayOf(142f, 218f)

private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t

/** Draws one frame of the mascot in a 360 x 400 design space, scaled to fit the canvas. */
private class BuddyPainter(private val p: BuddyPalette) {

    // Reused every frame: no allocations while animating.
    private val armPath = Path()
    private val leafPath = Path()
    private val browPath = Path()
    private val mouthPath = Path()
    private val headPath = Path().apply { addOval(Rect(68f, 70f, 292f, 274f)) }
    private val starPath = Path()
    private val dropPath = Path()
    private val queryPath = Path()

    private val sparkles = listOf(Offset(46f, 112f), Offset(62f, 58f), Offset(322f, 86f))

    // This frame's values, filled by read().
    private var wave = 0f
    private var talk = 0f
    private var chin = 0f
    private var thinkFace = 0f
    private var thoughts = 0f
    private var blink = 0f
    private var burst = 0f
    private var bump = 0f
    private var smile = 1f
    private var grin = 0f
    private var joy = 0f
    private var browRaise = 0f
    private var worry = 0f
    private var browAsym = 0f
    private var eyeScale = 1f
    private var gazeX = 0f
    private var gazeY = 0f
    private var tiltExtra = 0f
    private var lean = 0f
    private var blush = 1f
    private var hopAmp = 0f
    private var hopRate = 1.4f
    private var cheer = 0f
    private var sparkle = 0f
    private var sweat = 0f
    private var query = 0f
    private var dipK = 0f
    private var tiltK = 0f
    private var hopK = 0f
    private var dn = 0f
    private val danceA = DanceFrame()
    private val danceB = DanceFrame()
    private val df = DanceFrame()

    private fun read(t: Float, i: BuddyInputs) {
        val lk = i.look
        fun l(k: Int) = lk[k].value
        burst = i.burst.value.coerceIn(0f, 1f)
        bump = i.bump.value.coerceIn(-0.4f, 1f)
        val up = max(0f, bump)

        wave = max(i.poseWave.value.coerceIn(0f, 1f), l(BuddyLook.WAVE).coerceIn(0f, 1f) * burst)
        talk = i.talk.value.coerceIn(0f, 1f)
        val poseThink = i.poseThink.value.coerceIn(0f, 1f)
        chin = max(poseThink, l(BuddyLook.CHIN).coerceIn(0f, 1f))
        thinkFace = max(poseThink, l(BuddyLook.THINK_FACE).coerceIn(0f, 1f))
        thoughts = max(poseThink, l(BuddyLook.THOUGHTS).coerceIn(0f, 1f))
        blink = i.blink.value.coerceIn(0f, 1f)

        smile = l(BuddyLook.SMILE)
        grin = l(BuddyLook.GRIN).coerceIn(0f, 1f)
        joy = (l(BuddyLook.JOY) + up * l(BuddyLook.REACT_JOY)).coerceIn(0f, 1f)
        browRaise = l(BuddyLook.BROW_RAISE) + 3f * i.fidBrow.value + 2f * up
        worry = l(BuddyLook.WORRY)
        browAsym = l(BuddyLook.BROW_ASYM)
        eyeScale = l(BuddyLook.EYE_SCALE).coerceIn(0.7f, 1.25f)
        gazeX = l(BuddyLook.GAZE_X) + i.fidX.value
        gazeY = l(BuddyLook.GAZE_Y) + i.fidY.value
        tiltExtra = l(BuddyLook.TILT) + i.fidTilt.value
        lean = l(BuddyLook.LEAN)
        blush = l(BuddyLook.BLUSH).coerceIn(0f, 1.6f)
        hopAmp = l(BuddyLook.HOP)
        hopRate = l(BuddyLook.HOP_RATE)
        cheer = l(BuddyLook.CHEER).coerceIn(0f, 1f) * burst
        // Sparkles only ever come from a wave in Part 1's mascot; moods and reactions add to that.
        sparkle = max(wave, max(l(BuddyLook.SPARKLE) * burst, up * l(BuddyLook.REACT_SPARKLE))).coerceIn(0f, 1f)
        sweat = l(BuddyLook.SWEAT).coerceIn(0f, 1f)
        query = l(BuddyLook.QUERY).coerceIn(0f, 1f)
        dipK = i.dip.value
        tiltK = i.tiltKick.value
        hopK = i.hopKick.value

        // Dance: blend the current and the next move; sparkles stay on while dancing.
        dn = i.dance.value.coerceIn(0f, 1f)
        if (dn > 0.001f) {
            DanceMoves.fill(i.moveA.value, t, danceA)
            DanceMoves.fill(i.moveB.value, t, danceB)
            df.blend(danceA, danceB, i.moveBlend.value.coerceIn(0f, 1f))
            sparkle = max(sparkle, 0.85f * dn)
        }
    }

    fun draw(scope: DrawScope, t: Float, inputs: BuddyInputs) {
        val s = minOf(scope.size.width / W, scope.size.height / H)
        if (s <= 0f) return
        read(t, inputs)
        val ox = (scope.size.width - W * s) / 2f
        val oy = (scope.size.height - H * s) / 2f
        with(scope) {
            withTransform({
                translate(ox, oy)
                scale(s, s, Offset.Zero)
            }) {
                drawBuddy(t)
            }
        }
    }

    private fun DrawScope.drawBuddy(t: Float) {
        val breath = sin(t * TAU * 0.45f)
        val up = max(0f, bump)

        // Hops: a mood's steady hopping (calmer once its burst has passed) plus a one-off reaction hop.
        val act = 0.4f + 0.6f * burst
        val hopLift = abs(sin(t * PI_F * hopRate)) * hopAmp * act + up * hopK * 4f + dn * df.hop

        // Ground shadow: a flat soft ellipse that shrinks a little as the body rises.
        withTransform({ scale(1f - 0.03f * breath - 0.012f * hopLift, 0.13f - 0.004f * hopLift, Offset(180f, 386f)) }) {
            drawCircle(p.groundShadow, radius = 100f, center = Offset(180f, 386f))
        }

        withTransform({
            translate(dn * df.shiftX, -1.5f * breath - hopLift)
            rotate(dn * df.lean, Offset(180f, 382f))
        }) {
            // Feet
            drawOval(p.footLeft, Offset(115f, 358f), Size(58f, 28f))
            drawOval(p.footRight, Offset(187f, 358f), Size(58f, 28f))

            // Body and belly (breathing squash and stretch)
            withTransform({ scale(1f, 1f + 0.012f * breath, Offset(180f, 372f)) }) {
                drawOval(p.body, Offset(114f, 259f), Size(132f, 114f))
                drawOval(p.belly, Offset(140f, 296f), Size(80f, 68f))
            }

            // Free arm (viewer's left): hangs down, gestures while talking, goes up to cheer.
            val gesture = talk * (1f - wave) * (1f - cheer)
            val calmHand = Offset(
                mix(90f, 78f + 6f * sin(t * 9f), gesture),
                mix(350f, 318f + 6f * cos(t * 7f), gesture)
            )
            val cheerHand = Offset(60f + 7f * sin(t * 7f), 172f + 12f * (1f - cos(t * 7f)))
            val cheerMixed = Offset(mix(calmHand.x, cheerHand.x, cheer), mix(calmHand.y, cheerHand.y, cheer))
            val leftHand = Offset(mix(cheerMixed.x, df.lx, dn), mix(cheerMixed.y, df.ly, dn))
            drawArm(
                Offset(122f, 298f), leftHand,
                Offset(
                    mix(mix(mix(-5f, -12f, gesture), -16f, cheer), df.lbx, dn),
                    mix(mix(mix(2f, 8f, gesture), -4f, cheer), df.lby, dn)
                ),
                side = -1f, brush = p.armLeft
            )

            // The head casts a soft shadow on the body.
            withTransform({ scale(1f, 0.2f, Offset(180f, 282f)) }) {
                drawCircle(p.neckShadow, radius = 68f, center = Offset(180f, 282f))
            }

            // ---- Head group: sways, tilts for each mood, nods while talking and when reacting ----
            val sway = 2.2f * sin(t * TAU * 0.22f)
            val tilt = sway * (1f - 0.6f * chin) + 4f * wave - 6f * chin + 1.5f * talk + tiltExtra + bump * tiltK * 5f + dn * df.headTilt
            val nod = 1.6f * talk * sin(t * 6.5f) + bump * dipK * 3.5f
            withTransform({
                translate(lean, nod)
                rotate(tilt, Offset(180f, 268f))
            }) {
                drawSprout(t)
                drawHead()
                drawFace(t)
                if (sweat > 0.01f) drawSweat(t)
            }

            // Waving / thinking arm (viewer's right) is in front of the head.
            val waveHand = Offset(
                308f + 22f * sin(t * 11f),
                204f + 9f * (1f - cos(t * 11f))
            )
            var hand = Offset(mix(270f, waveHand.x, wave), mix(350f, waveHand.y, wave))
            hand = Offset(mix(hand.x, 222f, chin), mix(hand.y, 266f, chin))
            hand = Offset(mix(hand.x, df.rx, dn), mix(hand.y, df.ry, dn))
            val bendX = mix(mix(mix(5f, 12f, wave), 14f, chin), df.rbx, dn)
            val bendY = mix(mix(mix(2f, 12f, wave), 8f, chin), df.rby, dn)
            drawArm(Offset(238f, 298f), hand, Offset(bendX, bendY), side = 1f, brush = p.armRight)
        }

        if (thoughts > 0.01f) drawThoughts(t, thoughts)
        if (query > 0.01f) drawQuery(t, query)
        if (sparkle > 0.01f) drawSparkles(t, sparkle)
    }

    // ---- Pieces ---------------------------------------------------------------------------------

    private fun DrawScope.drawArm(shoulder: Offset, hand: Offset, bend: Offset, side: Float, brush: Brush) {
        // A "rubber hose" arm: one smooth curve from shoulder to hand.
        val cx = (shoulder.x + hand.x) / 2f + bend.x * 2f
        val cy = (shoulder.y + hand.y) / 2f + bend.y * 2f
        armPath.reset()
        armPath.moveTo(shoulder.x, shoulder.y)
        armPath.quadraticTo(cx, cy, hand.x, hand.y)
        drawPath(armPath, brush, style = Stroke(width = 27f, cap = StrokeCap.Round))
        withTransform({ translate(-2f, -2.5f) }) {
            drawPath(armPath, p.armHighlight, style = Stroke(width = 8f, cap = StrokeCap.Round))
        }
        // Mitten hand with a thumb and a little shine.
        drawOval(p.light, Offset(hand.x + side * 14f - 7f, hand.y - 16f), Size(14f, 16f))
        drawOval(p.light, Offset(hand.x - 19f, hand.y - 18f), Size(38f, 36f))
        drawCircle(p.handShine, radius = 9f, center = Offset(hand.x - 6f, hand.y - 7f))
    }

    private fun DrawScope.drawSprout(t: Float) {
        val sprout = 5f * sin(t * TAU * 0.5f + 1f) + 3f * talk * sin(t * 8f) - 4f * chin + 4f * sin(t * 9f) * joy + dn * df.swing
        withTransform({ rotate(sprout, Offset(180f, 76f)) }) {
            drawLine(p.stem, Offset(180f, 100f), Offset(180f, 72f), strokeWidth = 9f, cap = StrokeCap.Round)
            drawLeaf(-42f, 62f, 24f, p.leafBig)
            drawLeaf(42f, 62f, 24f, p.leafBig)
            drawLeaf(0f, 48f, 19f, p.leafSmall)
        }
    }

    private fun DrawScope.drawLeaf(angle: Float, len: Float, wid: Float, brush: Brush) {
        val bx = 180f
        val by = 76f
        withTransform({ rotate(angle, Offset(bx, by)) }) {
            leafPath.reset()
            leafPath.moveTo(bx, by)
            leafPath.cubicTo(bx + wid, by - len * 0.3f, bx + wid * 0.6f, by - len * 0.9f, bx, by - len)
            leafPath.cubicTo(bx - wid * 0.6f, by - len * 0.9f, bx - wid, by - len * 0.3f, bx, by)
            leafPath.close()
            drawPath(leafPath, brush)
            drawLine(
                p.leafRib, Offset(bx, by - len * 0.1f), Offset(bx, by - len * 0.85f),
                strokeWidth = 2.5f, cap = StrokeCap.Round
            )
        }
    }

    private fun DrawScope.drawHead() {
        drawOval(p.head, Offset(68f, 70f), Size(224f, 204f))
        // Darker underside, clipped to the head so nothing leaks out.
        clipPath(headPath) {
            drawRect(p.headShade, Offset(60f, 60f), Size(240f, 224f))
        }
        // Glossy highlight.
        withTransform({ rotate(-28f, Offset(126f, 106f)) }) {
            drawOval(Color.White.copy(alpha = 0.38f), Offset(94f, 91f), Size(64f, 30f))
        }
    }

    private fun DrawScope.drawFace(t: Float) {
        // Face plate and cheeks
        drawOval(p.plate, Offset(92f, 114f), Size(176f, 140f))
        val blushAlpha = (blush + 0.25f * joy).coerceIn(0f, 1f)
        drawOval(p.blushLeft, Offset(88f, 198f), Size(36f, 20f), alpha = blushAlpha)
        drawOval(p.blushRight, Offset(236f, 198f), Size(36f, 20f), alpha = blushAlpha)

        // Eyes: look around when idle, glance up and away when thinking; the mood moves the gaze,
        // widens them (interest) or squints them (joy).
        val gx = mix(2.5f * sin(t * 0.8f), 5f, thinkFace) + gazeX
        val gy = mix(1.5f * sin(t * 0.55f + 1f), -6f, thinkFace) + gazeY
        val eyeH = 22f * eyeScale * (1f - 0.5f * joy) * (1f - blink) + 1.5f
        val shine = (1f - blink * 2f).coerceIn(0f, 1f)
        for (ex in EYE_X) {
            val cx = ex + gx
            val cy = 178f + gy + 2.5f * joy
            drawOval(p.ink, Offset(cx - 17f, cy - eyeH), Size(34f, eyeH * 2f))
            if (shine > 0f) {
                drawCircle(Color.White.copy(alpha = shine), radius = 6f, center = Offset(cx - 5.5f, cy - 8f * (1f - 0.4f * joy)))
                drawCircle(Color.White.copy(alpha = 0.85f * shine), radius = 3f, center = Offset(cx + 5f, cy + 8f * (1f - 0.4f * joy)))
            }
        }

        // Eyebrows: lifted when happy, inner ends up when worried, one higher when curious,
        // one raised when thinking.
        val env = (0.5f + 0.5f * sin(t * 11f)) * (0.6f + 0.4f * sin(t * 4.3f + 1f))
        val lift = 2f * wave + 1.5f * talk * env + browRaise
        drawBrow(142f, 146f, lift + mix(0f, -2f, thinkFace), mix(0f, 3f, thinkFace) + 5f * worry)
        drawBrow(218f, 146f, lift + mix(0f, 6f, thinkFace) + 7f * browAsym, mix(0f, -3f, thinkFace) - 5f * worry)

        // Mouth: a smile (or small frown), an open happy grin, or the talking mouth.
        val open = max(max(talk * env + (1f - talk) * 0.42f * wave, 0.5f * grin), dn * df.mouth)
        val mouthSmile = mix(smile, 0.15f, thinkFace)
        val mx = mix(0f, 10f, thinkFace)
        val openAlpha = ((open - 0.04f) / 0.06f).coerceIn(0f, 1f)
        if (openAlpha < 1f) {
            mouthPath.reset()
            mouthPath.moveTo(160f + mx, 210f - 3f * mouthSmile)
            mouthPath.quadraticTo(180f + mx, 210f + 18f * mouthSmile, 200f + mx, 210f - 3f * mouthSmile)
            drawPath(
                mouthPath, p.mouthInk.copy(alpha = 1f - openAlpha),
                style = Stroke(width = 5f, cap = StrokeCap.Round)
            )
        }
        if (openAlpha > 0f) {
            val d = 8f + 34f * open
            mouthPath.reset()
            mouthPath.moveTo(156f + mx, 208f)
            mouthPath.quadraticTo(180f + mx, 206f, 204f + mx, 208f)
            mouthPath.quadraticTo(180f + mx, 208f + d * 1.25f, 156f + mx, 208f)
            mouthPath.close()
            drawPath(mouthPath, p.mouthInk.copy(alpha = openAlpha))
            val tongueH = minOf(8f, d * 0.22f)
            clipPath(mouthPath) {
                drawOval(
                    p.tongue.copy(alpha = 0.95f * openAlpha),
                    Offset(180f + mx - 13f, 208f + d * 0.72f - tongueH), Size(26f, tongueH * 2f)
                )
            }
        }
    }

    private fun DrawScope.drawBrow(cx: Float, cy: Float, raise: Float, tilt: Float) {
        browPath.reset()
        browPath.moveTo(cx - 15f, cy + tilt)
        browPath.quadraticTo(cx, cy - 7f - raise, cx + 15f, cy - tilt)
        drawPath(browPath, p.browInk, style = Stroke(width = 5f, cap = StrokeCap.Round))
    }

    private fun DrawScope.drawThoughts(t: Float, think: Float) {
        withTransform({ translate(0f, (1f - think) * 12f) }) {
            val fill = Color.White.copy(alpha = 0.92f * think)
            val edge = p.bubbleEdge.copy(alpha = p.bubbleEdge.alpha * think)
            drawCircle(fill, radius = 6f, center = Offset(262f, 100f))
            drawCircle(edge, radius = 6f, center = Offset(262f, 100f), style = Stroke(width = 1.2f))
            drawCircle(fill, radius = 9f, center = Offset(280f, 80f))
            drawCircle(edge, radius = 9f, center = Offset(280f, 80f), style = Stroke(width = 1.2f))
            drawOval(fill, Offset(274f, 22f), Size(52f, 44f))
            drawOval(edge, Offset(274f, 22f), Size(52f, 44f), style = Stroke(width = 1.2f))
            for (k in 0..2) {
                val a = 0.35f + 0.65f * max(0f, sin(t * 4f - k * 0.9f))
                drawCircle(p.mid.copy(alpha = a * think), radius = 3.2f, center = Offset(290f + k * 10f, 44f))
            }
        }
    }

    /** A small worried sweat drop at the temple; it slowly slides down and starts again. */
    private fun DrawScope.drawSweat(t: Float) {
        val phase = (t * 0.45f) % 1f
        val x = 268f
        val y = 128f + 16f * phase
        val a = sweat * (1f - phase * phase)
        dropPath.reset()
        dropPath.moveTo(x, y - 12f)
        dropPath.quadraticTo(x + 9f, y + 2f, x, y + 8f)
        dropPath.quadraticTo(x - 9f, y + 2f, x, y - 12f)
        dropPath.close()
        drawPath(dropPath, Color.White.copy(alpha = 0.9f * a))
        drawPath(dropPath, p.bubbleEdge.copy(alpha = p.bubbleEdge.alpha * a), style = Stroke(width = 1.4f))
    }

    /** A bobbing question mark beside the head (curious). */
    private fun DrawScope.drawQuery(t: Float, a: Float) {
        val x = 300f
        val y = 58f + 3f * sin(t * 3.2f) + (1f - a) * 10f
        val col = p.light.copy(alpha = a)
        queryPath.reset()
        queryPath.moveTo(x - 9f, y - 6f)
        queryPath.cubicTo(x - 9f, y - 22f, x + 9f, y - 22f, x + 9f, y - 8f)
        queryPath.cubicTo(x + 9f, y + 1f, x, y + 3f, x, y + 12f)
        drawPath(queryPath, col, style = Stroke(width = 5f, cap = StrokeCap.Round))
        drawCircle(col, radius = 3.2f, center = Offset(x, y + 23f))
    }

    private fun DrawScope.drawSparkles(t: Float, amount: Float) {
        for (i in sparkles.indices) {
            val pulse = 0.5f + 0.5f * sin(t * 5f + i * 2f)
            val r = 7f + 3f * pulse
            val c = sparkles[i]
            starPath.reset()
            starPath.moveTo(c.x, c.y - r)
            starPath.quadraticTo(c.x, c.y, c.x + r, c.y)
            starPath.quadraticTo(c.x, c.y, c.x, c.y + r)
            starPath.quadraticTo(c.x, c.y, c.x - r, c.y)
            starPath.quadraticTo(c.x, c.y, c.x, c.y - r)
            starPath.close()
            drawPath(starPath, p.sparkle.copy(alpha = amount * (0.45f + 0.55f * pulse)))
        }
    }
}
