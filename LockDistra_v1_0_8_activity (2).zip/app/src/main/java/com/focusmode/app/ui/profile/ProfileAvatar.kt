package com.focusmode.app.ui.profile

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Landscape
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Waves
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.data.profile.ProfileRules
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Look of one preset avatar. The id is what is stored (ProfileRules.AVATAR_IDS); the look lives only here. */
private data class AvatarLook(val icon: ImageVector, val from: Color, val to: Color)

private val avatarLooks: Map<String, AvatarLook> = mapOf(
    "leaf" to AvatarLook(Icons.Rounded.Eco, Color(0xFF4ADE9C), Color(0xFF1FA774)),
    "moon" to AvatarLook(Icons.Rounded.NightsStay, Color(0xFF818CF8), Color(0xFF4F46E5)),
    "bolt" to AvatarLook(Icons.Rounded.Bolt, Color(0xFFFBBF24), Color(0xFFF59E0B)),
    "star" to AvatarLook(Icons.Rounded.Star, Color(0xFFF472B6), Color(0xFFDB2777)),
    "flame" to AvatarLook(Icons.Rounded.LocalFireDepartment, Color(0xFFFB923C), Color(0xFFEF4444)),
    "wave" to AvatarLook(Icons.Rounded.Waves, Color(0xFF38BDF8), Color(0xFF2563EB)),
    "peak" to AvatarLook(Icons.Rounded.Landscape, Color(0xFF2DD4BF), Color(0xFF0D9488)),
    "heart" to AvatarLook(Icons.Rounded.Favorite, Color(0xFFFB7185), Color(0xFFE11D48)),
)

/** Photo if there is one, else the chosen preset avatar, else the person's initials on the app's gradient. */
@Composable
fun ProfileAvatar(
    name: String,
    avatarId: String,
    photoB64: String?,
    size: Dp,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    val bitmap by produceState<ImageBitmap?>(initialValue = null, photoB64) {
        value = if (photoB64.isNullOrEmpty()) null else withContext(Dispatchers.Default) {
            runCatching {
                val bytes = Base64.decode(photoB64, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
            }.getOrNull()
        }
    }
    val ring = Modifier.border(2.dp, c.accent.copy(alpha = 0.55f), CircleShape)
    val photo = bitmap
    val look = avatarLooks[avatarId]
    when {
        photo != null -> Image(
            bitmap = photo,
            contentDescription = "Profile photo",
            contentScale = ContentScale.Crop,
            modifier = modifier.size(size).clip(CircleShape).then(ring),
        )
        look != null -> Box(
            modifier.size(size).clip(CircleShape)
                .background(Brush.linearGradient(listOf(look.from, look.to)))
                .then(ring),
            contentAlignment = Alignment.Center,
        ) {
            Icon(look.icon, contentDescription = "Avatar", tint = Color.White, modifier = Modifier.size(size * 0.52f))
        }
        else -> Box(
            modifier.size(size).clip(CircleShape)
                .background(Brush.linearGradient(listOf(c.gradStart, c.gradMid, c.gradEnd)))
                .then(ring),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                ProfileRules.initials(name),
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.38f).sp,
            )
        }
    }
}
