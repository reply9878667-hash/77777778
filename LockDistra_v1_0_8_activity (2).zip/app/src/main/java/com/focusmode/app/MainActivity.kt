package com.focusmode.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import com.focusmode.app.data.IntentGuard
import com.focusmode.app.data.LectureLink
import com.focusmode.app.data.LockSession
import com.focusmode.app.service.FocusEngine
import com.focusmode.app.ui.AppViewModel
import com.focusmode.app.ui.FocusApp
import com.focusmode.app.ui.Screen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // A fresh open (not a rotation): Home plays its loading shimmer again.
        if (savedInstanceState == null) com.focusmode.app.ui.components.HomeShimmer.reset()
        enableEdgeToEdge()
        // With app lock on, the screen can't be captured and the recents card is blank.
        lifecycleScope.launch {
            viewModel.gateActive.collect { gateOn ->
                if (BLOCK_SCREENSHOTS && gateOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
            }
        }
        setContent { FocusApp(viewModel) }
        // Popups designed in the admin panel are checked in onStart(), every time the app comes to the front.
        if (savedInstanceState == null) handleIntent(intent)
    }

    private var popupJob: kotlinx.coroutines.Job? = null
    private var lastPopupCheck = 0L

    /**
     * Popups designed in the admin panel (update popup and "when the app opens" popups). Runs at every open AND every
     * return from the background (not only a cold start), waits for the app lock to be opened, and reads the settings
     * again when they are older than 45 seconds. A popup that was already shown follows its own repeat / max rules.
     */
    private fun checkAdminPopups() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (popupJob?.isActive == true) return
        if (now - lastPopupCheck < 15_000L) return
        lastPopupCheck = now
        popupJob = lifecycleScope.launch {
            // Wait until the person is really inside the app: app lock opened AND Home on screen (not the splash,
            // onboarding questions, sign-up / login or the permission page). Stops by itself if the app leaves the
            // screen; the next return to the app starts the check again.
            while ((viewModel.gateActive.value && !LockSession.unlocked) || !com.focusmode.app.ui.HomeVisible.value) {
                if (isFinishing || isDestroyed || !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)) return@launch
                kotlinx.coroutines.delay(500L)
            }
            kotlinx.coroutines.delay(1_000L) // let Home finish drawing first
            // The person may have logged out / been logged out during the wait: check again before AND after the download.
            if (!com.focusmode.app.ui.HomeVisible.value) return@launch
            val cfg = com.focusmode.app.data.RemoteConfig.get(applicationContext) ?: return@launch
            if (isFinishing || isDestroyed || !com.focusmode.app.ui.HomeVisible.value) return@launch
            if (viewModel.gateActive.value && !LockSession.unlocked) return@launch
            if (!com.focusmode.app.ui.CustomUpdatePopup.maybeShow(this@MainActivity, cfg.optJSONObject("update"), BuildConfig.VERSION_CODE)) {
                com.focusmode.app.ui.CustomPopups.maybeShow(this@MainActivity, cfg.optJSONArray("popups"), "app")
            }
        }
    }

    override fun onStart() {
        super.onStart()
        checkAdminPopups()
        com.focusmode.app.service.AppVisibility.onStart(applicationContext)
        // Keep both phones' view of the trusted-phone connection in step while the app is on screen.
        viewModel.online.onAppForeground()
        // Back from the background: lock again if the app was away longer than the chosen time.
        val lock = viewModel.lock.value
        LockSession.onReturned(viewModel.gateActive.value, lock.autoLockSeconds)
        // Whenever the lock screen is about to stand in front of the app, an old "Approved"
        // from an earlier visit must not be left over on it.
        if (viewModel.gateActive.value && !LockSession.unlocked) viewModel.online.finishApproved()
    }

    override fun onStop() {
        super.onStop()
        com.focusmode.app.service.AppVisibility.onStop()
        viewModel.online.onAppBackground()
        // A rotation recreates the activity; that is not "leaving the app".
        if (!isChangingConfigurations) LockSession.onLeft()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        // The user may just have granted a permission in system Settings.
        viewModel.refreshPermissions()
        viewModel.refreshApps()
        // Catch up on anything that came due while the process was frozen.
        FocusEngine.process(this)
        // A Pomodoro break whose service was stopped is brought back.
        com.focusmode.app.service.PomodoroEngine.ensureScheduled(this)
        // Adult Content Blocking: make sure its DNS filter is running (app is in front, so this start is allowed).
        runCatching { com.focusmode.app.service.AdultDnsVpnService.sync(this) }
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        // "Share" from another app: the link goes to the start wizard's lecture step. Only plain text is read and
        // nothing starts by itself: the person still goes through every wizard step and presses the last button.
        if (intent.action == Intent.ACTION_SEND) {
            val shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            intent.action = null
            intent.removeExtra(Intent.EXTRA_TEXT)
            if (shared != null && LectureLink.parse(shared) != null) {
                viewModel.screen = Screen.Home
                viewModel.sharedLink = shared.take(2000)
            } else {
                Toast.makeText(this, "No video link found in what was shared.", Toast.LENGTH_LONG).show()
            }
            return
        }
        // MainActivity is exported, so other apps can send it any intent. Only intents that carry
        // LockDistra's own key (from its notifications) may trigger an action; the rest is a launch.
        if (!IntentGuard.isTrusted(this, intent)) {
            intent.action = null
            intent.removeExtra(EXTRA_GROW_TOKEN)
            intent.removeExtra(EXTRA_OPEN_LIMITS)
            intent.removeExtra(EXTRA_OPEN_BLOCKING)
            intent.removeExtra(EXTRA_OPEN_EMERGENCY)
            intent.removeExtra(EXTRA_OPEN_APPROVALS)
            intent.removeExtra(EXTRA_OPEN_STUDY)
            intent.removeExtra(EXTRA_STUDY_VIDEO_ID)
            return
        }
        when {
            intent.action == ACTION_GROW -> {
                // Tapping the reminder itself only opens the app. The question "are you studying?"
                // then waits on screen: any tap answers it and the plant grows on the Plant page.
                intent.action = null
                viewModel.screen = Screen.Plant
            }

            intent.getBooleanExtra(EXTRA_OPEN_LIMITS, false) -> {
                intent.removeExtra(EXTRA_OPEN_LIMITS)
                viewModel.screen = Screen.Limits
            }

            intent.getBooleanExtra(EXTRA_OPEN_BLOCKING, false) -> {
                intent.removeExtra(EXTRA_OPEN_BLOCKING)
                viewModel.screen = Screen.Apps
            }

            intent.getBooleanExtra(EXTRA_OPEN_APPROVALS, false) -> {
                intent.removeExtra(EXTRA_OPEN_APPROVALS)
                // Shown behind the lock screen if one is up, like every other screen.
                viewModel.screen = Screen.Approvals
            }

            intent.getBooleanExtra(EXTRA_OPEN_STUDY, false) -> {
                intent.removeExtra(EXTRA_OPEN_STUDY)
                intent.getStringExtra(EXTRA_STUDY_VIDEO_ID)?.take(20)?.let { com.focusmode.app.data.StudyStore.get(this).armPending(it) }
                intent.removeExtra(EXTRA_STUDY_VIDEO_ID)
                viewModel.screen = Screen.Study
            }

            intent.getBooleanExtra(EXTRA_OPEN_EMERGENCY, false) -> {
                intent.removeExtra(EXTRA_OPEN_EMERGENCY)
                viewModel.screen = Screen.Home
                viewModel.emergencyRequested = true
            }
        }
    }

    companion object {
        /** false = screenshots / screen recording allowed. Set to true to block them again with app lock on. */
        private const val BLOCK_SCREENSHOTS = false

        const val ACTION_GROW = "com.focusmode.app.action.GROW_PLANT"
        const val EXTRA_GROW_TOKEN = "grow_token"
        const val EXTRA_OPEN_EMERGENCY = "open_emergency"
        const val EXTRA_OPEN_LIMITS = "open_limits"
        const val EXTRA_OPEN_BLOCKING = "open_blocking"
        const val EXTRA_OPEN_APPROVALS = "open_approvals"
        const val EXTRA_OPEN_STUDY = "open_study"
        const val EXTRA_STUDY_VIDEO_ID = "study_video_id"
    }
}
