package com.focusmode.app.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.focusmode.app.data.EmergencyStore
import com.focusmode.app.data.FocusControl
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.PomodoroStore
import com.focusmode.app.data.RestartAction
import com.focusmode.app.data.RestartPolicy

/** Entry points used by the UI, receivers and the service to change LockDistra state. */
object FocusController {

    /**
     * [minutes] of 0 means no time limit. While a Pomodoro cycle exists only the Pomodoro itself
     * ([fromPomodoro]) may start a session, so two timers can never run at once. [durationMs] /
     * [elapsedMs] continue a paused round; [newSession] = false keeps Emergency uses from being
     * handed back at every round of the same cycle.
     */
    fun start(
        context: Context,
        minutes: Int,
        durationMs: Long = minutes * 60_000L,
        elapsedMs: Long = 0L,
        fromPomodoro: Boolean = false,
        newSession: Boolean = true,
        lectureTimed: Boolean = false,
    ) {
        val app = context.applicationContext
        if (!fromPomodoro && PomodoroStore.get(app).current().active) return
        FocusStore.get(app).startSession(
            minutes, durationMs = durationMs, elapsedMs = elapsedMs, remember = !fromPomodoro && !lectureTimed,
            lectureTimed = lectureTimed,
        )
        if (newSession) EmergencyStore.get(app).onSessionStart()
        Notifications.ensureChannels(app)
        try {
            ContextCompat.startForegroundService(app, Intent(app, FocusService::class.java))
        } catch (_: Exception) {
            // The session is already saved and the accessibility service enforces it from that state; the
            // alarm below and the next app start bring the status notification back.
        }
        FocusEngine.scheduleNextWakeup(app)
    }

    /** Lecture player -> keeps the safety timer of a lecture session equal to the lecture's real remaining time. */
    fun syncEndToLecture(context: Context, remainingMs: Long) {
        val app = context.applicationContext
        if (FocusStore.get(app).setEndFromLecture(remainingMs)) {
            Notifications.refreshStatus(app)
            FocusEngine.scheduleNextWakeup(app)
        }
    }

    fun stop(context: Context, completed: Boolean = false, fromPomodoro: Boolean = false) {
        val app = context.applicationContext
        // Ending the session by any other way (End focus, restart with restore off) ends the Pomodoro too.
        if (!completed && !fromPomodoro && PomodoroStore.get(app).current().active) {
            PomodoroEngine.endCycle(app)
            return
        }
        FocusStore.get(app).endSession()
        Notifications.cancelReminder(app)
        Notifications.cancelStudyCheckIn(app)
        // A finished Focus round hands over to the Break: the service keeps running for it.
        if (completed && PomodoroEngine.onFocusCompleted(app)) return
        app.stopService(Intent(app, FocusService::class.java))
        FocusEngine.cancelWakeup(app)
        if (completed) Notifications.postSessionComplete(app)
    }

    /**
     * Ends the session because the user asked to. Refused (returns false) while "Allow turning
     * LockDistra OFF" is switched off. A finished timer uses [stop] directly and always works.
     */
    fun requestStop(context: Context): Boolean {
        val app = context.applicationContext
        if (!FocusStore.get(app).current().canTurnOff) return false
        stop(app)
        return true
    }

    /**
     * Opens [pkg] for [minutes] through Emergency access. Returns true if the window opened.
     * It is refused when no session runs, Emergency access is switched off for this session,
     * a window is already open, or [pkg] is not enabled / has no attempts left. One attempt is
     * used up per window and is not given back when the window is ended early.
     */
    fun startEmergency(context: Context, pkg: String, minutes: Int): Boolean {
        val app = context.applicationContext
        val store = FocusStore.get(app)
        val now = System.currentTimeMillis()
        val s = store.current()
        if (!com.focusmode.app.data.EmergencyPolicy.sessionAllows(s, now)) return false
        if (minutes !in 1..10) return false
        if (!EmergencyStore.get(app).consume(pkg)) return false
        store.setEmergency(pkg, now + minutes * 60_000L)
        Notifications.refreshStatus(app)
        FocusEngine.scheduleNextWakeup(app)
        return true
    }

    /** Changes one advanced control. See [FocusStore.setControl] for the rules. */
    fun setControl(context: Context, control: FocusControl, allowed: Boolean): Boolean {
        val app = context.applicationContext
        val ok = FocusStore.get(app).setControl(control, allowed)
        // The status notification only offers Emergency access while it is allowed.
        Notifications.refreshStatus(app)
        return ok
    }

    fun endEmergency(context: Context) {
        val app = context.applicationContext
        FocusStore.get(app).clearEmergency()
        Notifications.refreshStatus(app)
    }

    /**
     * Called after a restart. Brings an unfinished session back, unless the user has switched
     * off "Restore after restart" (then the session ends and the user is told).
     */
    fun restoreAfterBoot(context: Context, genuineBoot: Boolean = true) {
        val app = context.applicationContext
        val s = FocusStore.get(app).current()
        when (RestartPolicy.decide(s, genuineBoot)) {
            RestartAction.NOTHING -> Unit
            RestartAction.END -> {
                stop(app)
                Notifications.postRestartEnded(app)
            }
            RestartAction.RESUME -> {
                resumeIfNeeded(app)
                if (genuineBoot && FocusStore.get(app).current().focusActive) {
                    Notifications.postRestored(app)
                }
            }
        }
        // A Pomodoro break has no session, so the restart check above does not see it. It follows the
        // same "Restore after restart" setting; a quick-boot broadcast (not genuine) never ends anything.
        if (genuineBoot && !s.restoreAfterRestart && PomodoroStore.get(app).current().active) {
            PomodoroEngine.endCycle(app)
        } else {
            PomodoroEngine.resumeIfNeeded(app)
        }
    }

    /** Re-creates the service after a reboot or an app update if a session is still valid. */
    fun resumeIfNeeded(context: Context) {
        val app = context.applicationContext
        val store = FocusStore.get(app)
        val s = store.current()
        if (!s.focusActive) {
            PomodoroEngine.resumeIfNeeded(app)
            return
        }
        val now = System.currentTimeMillis()
        if (s.sessionEnd != 0L && now >= s.sessionEnd) {
            stop(app, completed = true)
            return
        }
        Notifications.ensureChannels(app)
        try {
            ContextCompat.startForegroundService(app, Intent(app, FocusService::class.java))
        } catch (_: Exception) {
            // Android may refuse a background start on some versions; the accessibility service
            // keeps enforcing blocking from persisted state regardless.
        }
        FocusEngine.scheduleNextWakeup(app)
    }
}

/** Time-based transitions: session end, emergency end and plant reminders. Safe to call often. */
object FocusEngine {

    private const val REQ_WAKEUP = 7
    private const val REQ_DISMISS = 8
    private const val WATCHDOG_MS = 5 * 60_000L
    private const val REVIVE_MS = 3_000L

    fun process(context: Context) {
        val store = FocusStore.get(context)
        if (!store.current().focusActive) {
            // No session: a Pomodoro break has its own time check; otherwise nothing is pending.
            if (!PomodoroEngine.process(context)) cancelWakeup(context)
            return
        }
        // If the phone's clock was moved, the session moves with it before anything is compared.
        ClockWatch.check(context)
        val s = store.current()
        val now = System.currentTimeMillis()

        if (s.sessionEnd != 0L && now >= s.sessionEnd) {
            FocusController.stop(context, completed = true)
            return
        }
        if (s.emergencyUntil != 0L && now >= s.emergencyUntil) {
            store.clearEmergency()
            Notifications.refreshStatus(context)
        }
        if (s.reminderMinutes > 0 && s.nextReminderAt != 0L && now >= s.nextReminderAt) {
            store.setNextReminder(now + s.reminderMinutes * 60_000L)
            Notifications.postPlantReminder(context, now)
        }
        // Study Check-In (off unless an interval was chosen in Settings). Never touches the session timer.
        StudyCheckInEngine.process(context, store.current(), now)
        scheduleNextWakeup(context)
    }

    fun scheduleNextWakeup(context: Context) {
        val s = FocusStore.get(context).current()
        if (!s.focusActive) return
        val now = System.currentTimeMillis()
        val candidates = listOf(
            s.sessionEnd,
            if (s.emergencyUntil > now) s.emergencyUntil else 0L,
            if (s.reminderMinutes > 0) s.nextReminderAt else 0L,
            // Study Check-In: the answer deadline while one is waiting, otherwise when the next one is due.
            if (s.studyMin > 0) (if (s.studyDeadline != 0L) s.studyDeadline else s.studyNextAt) else 0L,
        ).filter { it > now }
        // Watchdog: even with nothing due, wake up regularly. If the phone's battery saver stopped
        // the service, FocusAlarmReceiver starts it again within a few minutes.
        val next = (candidates + (now + WATCHDOG_MS)).min()
        arm(context, next)
    }

    /** Wake-up at [at] (the end of a Pomodoro break). */
    fun scheduleAt(context: Context, at: Long) = arm(context, at)

    /** Whether exact alarms are allowed (always before Android 12; a user setting after that). */
    fun canScheduleExact(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    /**
     * The service loop handles timing while the phone is awake; this alarm is the backup for doze.
     * Without a Pomodoro it stays inexact-while-idle (no special permission). While a Pomodoro
     * runs it is exact when the user allows "Alarms & reminders", so a break ends on time with
     * the screen off.
     */
    private fun arm(context: Context, at: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = wakeupIntent(context)
        val focus = FocusStore.get(context).current()
        // Exact while a Pomodoro runs, and while Study Check-Ins are on (the one-minute answer window needs it).
        val needsExact = PomodoroStore.get(context).current().running || (focus.focusActive && focus.studyMin > 0)
        val exact = needsExact && canScheduleExact(context)
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Quick revival (a few seconds) after the service was swiped away or killed mid-session. */
    fun scheduleSoon(context: Context) {
        if (!FocusStore.get(context).current().focusActive &&
            !PomodoroStore.get(context).current().running
        ) return
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + REVIVE_MS, wakeupIntent(context))
    }

    fun cancelWakeup(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(wakeupIntent(context))
    }

    /** Broadcast sent when the status notification is swiped away; it is put back at once. */
    fun dismissIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQ_DISMISS,
            Intent(context, FocusAlarmReceiver::class.java).setAction(FocusAlarmReceiver.ACTION_STATUS_DISMISSED),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun wakeupIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQ_WAKEUP,
            Intent(context, FocusAlarmReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
}

/** Keeps the saved session times right when the user changes the phone's date or time. */
object ClockWatch {
    fun check(context: Context) {
        val app = context.applicationContext
        val jump = FocusStore.get(app).syncClock(
            System.currentTimeMillis(), SystemClock.elapsedRealtime(), bootCount(app)
        )
        if (jump != 0L) {
            // The end time moved, so the notification and the backup alarm must follow.
            Notifications.refreshStatus(app)
            FocusEngine.scheduleNextWakeup(app)
        }
    }

    /** Number of restarts so far; changes on every boot. -1 when the phone does not say. */
    private fun bootCount(context: Context): Int = try {
        Settings.Global.getInt(context.contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) {
        -1
    }
}
