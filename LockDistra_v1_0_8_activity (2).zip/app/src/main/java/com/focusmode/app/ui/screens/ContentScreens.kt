package com.focusmode.app.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.AppRepository
import com.focusmode.app.data.ContentPolicy
import com.focusmode.app.data.ContentState
import com.focusmode.app.data.ContentStore
import com.focusmode.app.data.CustomSection
import com.focusmode.app.data.FeatureCatalog
import com.focusmode.app.data.FocusState
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.components.staggeredEntrance
import com.focusmode.app.ui.theme.FocusTheme

// ---- Inside apps (Task 4) -----------------------------------------------------------------------

/**
 * Switches for the distracting sections inside apps that otherwise stay open during a session
 * (YouTube Shorts / Search / Home feed, Instagram Reels / Explore / Search, and the user's own
 * sections). While a session runs a switch can only be turned ON, and nothing changes at all when
 * "app restriction changes" is locked (see [ContentPolicy]).
 */
@Composable
fun FeaturesScreen(
    state: FocusState,
    content: ContentState,
    apps: List<AppInfo>,
    loaded: Boolean,
    onBack: () -> Unit,
    onToggleShorts: (Boolean) -> Unit,
    onFeatureChange: (String, Boolean) -> Unit,
    onAddCustom: (pkg: String, label: String) -> Boolean,
    onRemoveCustom: (String) -> Unit,
    onOpenEducation: () -> Unit,
) {
    val c = FocusTheme.colors
    val running = state.focusActive
    val frozen = ContentPolicy.frozen(state)
    var showAdd by remember { mutableStateOf(false) }
    var addFailed by remember { mutableStateOf(false) }

    val installed = remember(apps) { apps.map { it.packageName }.toSet() }
    val labels = remember(apps) { apps.associate { it.packageName to it.label } }
    val total = content.activeFeatureCount + if (state.blockShorts) 1 else 0

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .staggeredEntrance(0)
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Column {
                Text("Inside apps", style = MaterialTheme.typography.titleLarge)
                Text(
                    if (total == 0) "Close only the distracting parts of an app"
                    else "$total section${if (total == 1) "" else "s"} blocked, saved automatically",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        if (running) {
            LockedNote(
                if (frozen) "App restrictions are locked right now. Unlock changes, or wait for the session to end, to edit them."
                else "A session is running. You can block more sections, but not unblock any until it ends."
            )
            Spacer(Modifier.height(12.dp))
        }

        FocusCard(padding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, null, tint = c.accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(12.dp))
                Text(
                    "Works while LockDistra is on. The app itself stays open; only the sections you switch on are closed. " +
                        "Android has no switch for this, so LockDistra reads tab names and screen ids through the Accessibility service. " +
                        "It is best effort and an app update can break it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        FeatureCatalog.appPackages.forEach { pkg ->
            if (pkg !in installed && pkg !in FeatureCatalog.alwaysShown) return@forEach
            val appBlocked = pkg in state.blocked
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)) {
                AppIcon(pkg, 28.dp)
                Spacer(Modifier.size(10.dp))
                Text(
                    FeatureCatalog.appTitle(pkg).uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = c.muted
                )
            }
            if (pkg !in installed) {
                Text(
                    "${FeatureCatalog.appTitle(pkg)} isn't installed. These switches apply if you install it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
                )
            }
            if (appBlocked) {
                Text(
                    "${FeatureCatalog.appTitle(pkg)} is blocked as a whole under App blocking, so nothing inside it can be opened.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning,
                    modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (pkg == AppRepository.YOUTUBE) {
                    SectionRow(
                        title = "Shorts",
                        note = if (content.hasShortsExceptions) "Only Shorts from your educational channels can play"
                        else "The Shorts player and the Shorts tab",
                        checked = state.blockShorts || appBlocked,
                        enabled = !frozen && !appBlocked && !(running && state.blockShorts),
                        onToggle = onToggleShorts
                    )
                    TextButton(onClick = onOpenEducation) {
                        Text("Choose educational channels", color = c.accent)
                    }
                }
                FeatureCatalog.forPackage(pkg).forEach { def ->
                    val on = content.featureOn(def.id)
                    SectionRow(
                        title = def.title,
                        note = def.note,
                        checked = on || appBlocked,
                        enabled = !frozen && !appBlocked && !(running && on),
                        onToggle = { onFeatureChange(def.id, it) }
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Your own sections")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            content.customSections.forEach { section ->
                CustomSectionRow(
                    section = section,
                    appLabel = labels[section.pkg] ?: section.pkg,
                    canRemove = ContentPolicy.canRemoveCustom(state),
                    onRemove = { onRemoveCustom(section.id) }
                )
            }
            if (content.customSections.isEmpty()) {
                Text(
                    "Any other app, any tab that highlights when it is open: Spotlight, Marketplace, Trending, Stories, Discover.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
            }
            if (addFailed) {
                Text(
                    "That section couldn't be added. Use a name of at least 2 letters and check that the list isn't full or locked.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
            }
            val canAdd = ContentPolicy.canAddCustom(state)
            SoftChip(
                text = if (canAdd) "Add a section" else "Locked right now",
                selected = canAdd,
                onClick = {
                    addFailed = false
                    if (canAdd) showAdd = true
                }
            )
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("What to expect")
        FocusCard {
            Text(
                "• Blocking tries a gentle exit first (tapping a safe tab), then Back, and only then covers the app.\n" +
                    "• Instagram shows Explore and Search on one tab, so blocking Explore also closes that tab.\n" +
                    "• Facebook, Snapchat and WhatsApp Status presets are experimental. For anything else use your own sections.\n" +
                    "• Text is matched against English tab names. Other languages may need your own section with the local name.\n" +
                    "• Emergency access opens one app fully for a few minutes, sections included.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
        }
        Spacer(Modifier.height(32.dp))
    }

    if (showAdd) {
        AddSectionDialog(
            apps = apps,
            loaded = loaded,
            onDismiss = { showAdd = false },
            onConfirm = { pkg, label ->
                showAdd = false
                addFailed = !onAddCustom(pkg, label)
            }
        )
    }
}

@Composable
private fun SectionRow(
    title: String,
    note: String,
    checked: Boolean,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
) {
    val c = FocusTheme.colors
    FocusCard(
        padding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        highlight = checked
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (checked) "Blocked. $note" else note,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (checked) c.accent else c.muted
                )
            }
            Spacer(Modifier.size(12.dp))
            FocusSwitch(checked = checked, enabled = enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
private fun CustomSectionRow(
    section: CustomSection,
    appLabel: String,
    canRemove: Boolean,
    onRemove: () -> Unit,
) {
    val c = FocusTheme.colors
    FocusCard(padding = PaddingValues(horizontal = 16.dp, vertical = 12.dp), highlight = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(section.pkg, 40.dp)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(section.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text("in $appLabel", style = MaterialTheme.typography.bodySmall, color = c.muted, maxLines = 1)
            }
            if (canRemove) {
                CircleIconButton(Icons.Rounded.Close, "Remove", onClick = onRemove)
            }
        }
    }
}

/** Two steps: choose the app, then type the name of the tab or section to close. */
@Composable
private fun AddSectionDialog(
    apps: List<AppInfo>,
    loaded: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (pkg: String, label: String) -> Unit,
) {
    val c = FocusTheme.colors
    var chosen by remember { mutableStateOf<AppInfo?>(null) }
    var query by remember { mutableStateOf("") }
    var label by remember { mutableStateOf("") }
    val app = chosen

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = {
            Text(if (app == null) "Choose an app" else "Name the section", style = MaterialTheme.typography.titleLarge)
        },
        text = {
            if (app == null) {
                Column {
                    SearchField(value = query, onValueChange = { query = it })
                    Spacer(Modifier.height(10.dp))
                    val q = query.trim()
                    val list = if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
                    if (!loaded || list.isEmpty()) {
                        Text(
                            if (!loaded) "Loading apps…" else "No apps match \"$q\"",
                            style = MaterialTheme.typography.bodyMedium,
                            color = c.muted
                        )
                    } else {
                        LazyColumn(Modifier.heightIn(max = 320.dp)) {
                            items(list, key = { it.packageName }) { item ->
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { chosen = item }
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AppIcon(item.packageName, 36.dp)
                                    Spacer(Modifier.size(12.dp))
                                    Text(item.label, style = MaterialTheme.typography.titleMedium, color = c.text, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Type the name of a tab or section in ${app.label} exactly as the app shows it, for example Spotlight, Marketplace or Trending.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    TextEntryField(
                        value = label,
                        onValueChange = { label = it.take(30) },
                        hint = "Section name",
                        modifier = Modifier.fillMaxWidth(),
                        onDone = { if (label.trim().length >= 2) onConfirm(app.packageName, label) }
                    )
                    Text(
                        "It works for tabs that look highlighted while they are open. It is closed only while LockDistra is on.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        },
        confirmButton = {
            if (app != null) {
                TextButton(
                    enabled = label.trim().length >= 2,
                    onClick = { onConfirm(app.packageName, label) }
                ) { Text("Block it", color = if (label.trim().length >= 2) c.accent else c.muted) }
            }
        },
        dismissButton = {
            TextButton(onClick = { if (app == null) onDismiss() else chosen = null }) {
                Text(if (app == null) "Cancel" else "Back", color = c.muted)
            }
        }
    )
}

// ---- Educational Shorts (Task 3) ----------------------------------------------------------------

/**
 * Chooses which YouTube channels stay watchable in Shorts while the Shorts restriction is on.
 * This never whitelists the YouTube app: everything else in Shorts stays blocked. Adding channels
 * and switching automatic detection ON only work between sessions, because both let more through.
 */
@Composable
fun EducationScreen(
    state: FocusState,
    content: ContentState,
    onBack: () -> Unit,
    onToggleShorts: (Boolean) -> Unit,
    onAutoDetectChange: (Boolean) -> Unit,
    onAddChannel: (String) -> ContentStore.AddResult,
    onRemoveChannel: (String) -> Unit,
    onClearRecent: () -> Unit,
) {
    val c = FocusTheme.colors
    val running = state.focusActive
    val frozen = ContentPolicy.frozen(state)
    val youtubeBlocked = AppRepository.YOUTUBE in state.blocked
    var input by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    fun submit(raw: String) {
        message = when (onAddChannel(raw)) {
            ContentStore.AddResult.ADDED -> {
                input = ""
                null
            }
            ContentStore.AddResult.ALREADY_THERE -> "That channel is already in your list."
            ContentStore.AddResult.INVALID ->
                "Enter a channel name or an @handle (3 to 40 letters or digits). Links that contain /channel/ can't be matched."
            ContentStore.AddResult.LOCKED -> "New channels can only be added between focus sessions."
            ContentStore.AddResult.FULL -> "The list is full (${ContentPolicy.MAX_CHANNELS} channels)."
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .staggeredEntrance(0)
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Column {
                Text("Educational Shorts", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Keep learning channels while Shorts is blocked",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        if (running) {
            LockedNote(
                if (frozen) "App restrictions are locked right now. Unlock changes, or wait for the session to end, to edit them."
                else "A session is running. You can remove channels or switch automatic detection off, but not add channels."
            )
            Spacer(Modifier.height(12.dp))
        }

        // Is it actually doing anything right now?
        val active = state.blockShorts && !youtubeBlocked
        FocusCard(highlight = active) {
            Column {
                Text(
                    when {
                        youtubeBlocked -> "Not active: YouTube is blocked as a whole"
                        !state.blockShorts -> "Not active: the Shorts restriction is off"
                        !content.hasShortsExceptions -> "Active, but nothing is allowed yet"
                        else -> "Active"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = if (active && content.hasShortsExceptions) c.accent else c.text
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    when {
                        youtubeBlocked ->
                            "A fully blocked YouTube can't open at all. Switch YouTube off under App blocking and use the Shorts switch below, so videos you choose stay reachable."
                        else ->
                            "While LockDistra is on, Shorts from the channels below play. Every other Short is blocked. " +
                                "The rest of YouTube is not whitelisted: it follows your other settings."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(c.accentSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.PlayCircle, null, tint = c.accent, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Restrict YouTube Shorts", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (state.blockShorts) "On" else "Off",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (state.blockShorts) c.accent else c.muted
                        )
                    }
                    FocusSwitch(
                        checked = state.blockShorts,
                        enabled = !frozen && !youtubeBlocked && !(running && state.blockShorts),
                        onCheckedChange = onToggleShorts
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Automatic detection")
        FocusCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(c.accentSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.AutoAwesome, null, tint = c.accent, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.size(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Detect educational Shorts", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (content.autoDetect) "On" else "Off",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (content.autoDetect) c.accent else c.muted
                        )
                    }
                    FocusSwitch(
                        checked = content.autoDetect,
                        enabled = !frozen && !(running && !content.autoDetect),
                        onCheckedChange = onAutoDetectChange
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "Reads a Short's caption, hashtags and channel name on your phone and lets it through when it clearly looks educational " +
                        "(for example #physics, #jee, \"explained\"). It is keyword based, not a trained model, and nothing is sent anywhere. " +
                        "It will sometimes allow a Short it shouldn't or block one it should allow, so your channel list is the reliable part.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Allowed channels (${content.channels.size})")
        if (!running) {
            FocusCard(padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextEntryField(
                            value = input,
                            onValueChange = {
                                input = it.take(80)
                                message = null
                            },
                            hint = "Name or @handle",
                            modifier = Modifier.weight(1f),
                            onDone = { submit(input) }
                        )
                        Spacer(Modifier.size(10.dp))
                        SoftChip("Add", selected = input.isNotBlank(), onClick = { submit(input) })
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        message ?: "Type it as YouTube shows it under a Short, like @veritasium or Khan Academy.",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (message != null) c.warning else c.muted
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        if (content.channels.isEmpty()) {
            Text(
                "No channels yet. Until you add some, every Short is blocked.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted,
                modifier = Modifier.padding(horizontal = 6.dp)
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            content.channels.forEach { ch ->
                FocusCard(
                    modifier = Modifier.animateContentSize(),
                    padding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
                    highlight = true
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(ch.display, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            Text("Allowed in Shorts", style = MaterialTheme.typography.bodySmall, color = c.accent)
                        }
                        if (ContentPolicy.canRemoveChannel(state)) {
                            CircleIconButton(Icons.Rounded.Close, "Remove ${ch.display}", onClick = { onRemoveChannel(ch.key) })
                        }
                    }
                }
            }
        }

        if (content.recentBlocked.isNotEmpty()) {
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { SectionLabel("Recently blocked") }
                TextButton(onClick = onClearRecent) { Text("Clear", color = c.muted) }
            }
            FocusCard(padding = PaddingValues(horizontal = 18.dp, vertical = 8.dp)) {
                Column {
                    content.recentBlocked.forEach { handle ->
                        val already = content.channels.any { it.key == com.focusmode.app.data.EducationMatcher.norm(handle) }
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(handle, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f), maxLines = 1)
                            if (!already && !running) SoftChip("Allow", selected = true, onClick = { submit(handle) })
                            if (already) Text("Allowed", style = MaterialTheme.typography.bodySmall, color = c.accent)
                        }
                    }
                    Text(
                        if (running) "You can allow these after the session ends."
                        else "Channels whose Shorts were blocked. Tap Allow to keep one.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Limits you should know")
        FocusCard {
            Text(
                "• YouTube has no official way for another app to filter by channel. LockDistra reads the channel name or @handle that appears on screen through the Accessibility service, which is the closest reliable method.\n" +
                    "• A Short's channel can take a moment to appear, so a Short may play for a second or two before it is judged.\n" +
                    "• If YouTube changes how Shorts looks, matching can stop working until the app is updated. Blocking the whole Shorts player keeps working as before.\n" +
                    "• A Short that never shows its channel is treated as not educational.\n" +
                    "• Only the player is checked. YouTube's other sections follow Inside apps.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
        }
        Spacer(Modifier.height(32.dp))
    }
}

/** Single-line field in the app's rounded style. */
@Composable
private fun TextEntryField(
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    modifier: Modifier = Modifier,
    onDone: () -> Unit = {},
) {
    val c = FocusTheme.colors
    Row(
        modifier
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(c.cardHigh)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) {
                Text(hint, style = MaterialTheme.typography.bodyLarge, color = c.muted, maxLines = 1)
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                textStyle = TextStyle(color = c.text, fontSize = MaterialTheme.typography.bodyLarge.fontSize),
                cursorBrush = SolidColor(c.accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { onDone() }),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}
