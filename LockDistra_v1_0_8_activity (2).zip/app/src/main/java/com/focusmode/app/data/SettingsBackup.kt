package com.focusmode.app.data

import android.content.Context
import com.focusmode.app.data.online.FirebaseGateway
import com.focusmode.app.data.online.OnlineException
import java.security.SecureRandom
import java.util.Random
import org.json.JSONArray
import org.json.JSONObject

/**
 * Settings backup: the person taps "Upload" in Settings and the settings of this phone (blocked apps and games, limits,
 * websites, keywords, bedtime, Focus Profiles, Pomodoro / Auto Focus times, Focus Mode controls, appearance ...) are saved
 * on the server under their account. "Download" on a new or reinstalled phone brings them back and restarts the app.
 *
 * The same text can also be shared with a friend through a short code (see [ShareCode] and [SharedSettingsRemote]).
 * A shared copy leaves out what is personal (the name typed in Focus Mode) and a friend's phone keeps its own.
 *
 * What is NOT in a backup, on purpose:
 *  - anything that belongs to the running moment (an active session, today's usage, emergency windows, check-in timers);
 *  - the App lock PIN / password, the trusted-phone keys and the login (secrets stay out of the settings copy);
 *  - "Prevent changes" and the Focus OFF method (they depend on a PIN / trusted phone that this phone may not have yet);
 *  - "Advanced protection" (it needs the Device admin permission, which must be granted again on a new phone);
 *  - the Daily Task Planner (it is a to-do list, not a setting) and the lecture link of one session;
 *  - the permissions Android itself asks for (Accessibility, Usage access ...), which must be granted again on a new phone.
 */
object SettingsBackupRules {
    const val VERSION = 1

    /** Stays under the 1,000,000-character limit of the database rule. */
    const val MAX_CHARS = 900_000

    /**
     * What one SharedPreferences file contributes to a backup.
     *  - [types]: the keys that are part of it, with the type each must have (s string, b boolean, i int, l long, f float,
     *    ss string set). A downloaded text whose value has another type is refused whole, because a store reading it later
     *    would crash.
     *  - [prefixTypes]: the same for keys that end in a number (Focus Profile slots).
     *  - [all]: every key of the file is part of it (types still checked for the keys listed above).
     *  - [personal]: keys that are saved in a backup but never put into, or taken from, a copy shared with a friend.
     */
    private class Spec(
        val types: Map<String, String> = emptyMap(),
        val prefixTypes: Map<String, String> = emptyMap(),
        val all: Boolean = false,
        val personal: Set<String> = emptySet(),
    ) {
        fun matches(key: String) = all || key in types || prefixTypes.keys.any { key.startsWith(it) }
        fun expected(key: String): String? = types[key] ?: prefixTypes.entries.firstOrNull { key.startsWith(it.key) }?.value
        fun skipped(key: String, shared: Boolean) = shared && key in personal
    }

    /** SharedPreferences file name -> which of its keys are part of the backup. */
    private val SPECS: Map<String, Spec> = mapOf(
        "focus_mode" to Spec(
            types = mapOf(
                "blocked_packages" to "ss", "block_shorts" to "b", "reminder_minutes" to "i", "theme_mode" to "i",
                "last_duration" to "i", "restore_after_restart" to "b", "study_checkin_min" to "i",
                // The five "Advanced control" switches of Focus Mode, and the name shown in the app.
                "ctl_allow_turn_off" to "b", "ctl_allow_settings" to "b", "ctl_allow_emergency" to "b",
                "ctl_allow_app_changes" to "b", "ctl_allow_other_bypass" to "b",
                "user_name" to "s",
            ),
            personal = setOf("user_name"),
        ),
        "usage_limits" to Spec(
            types = mapOf(
                "limits" to "ss", "cat_limits" to "ss", "floating_timer" to "b", "floating_every_min" to "i",
                "floating_over_games" to "b", "floating_style" to "s", "emg_cfg" to "ss",
            )
        ),
        "emergency_access" to Spec(types = mapOf("apps" to "ss", "reset_mode" to "i")),
        "pomodoro" to Spec(types = mapOf("focus_min" to "i", "break_min" to "i")),
        "auto_focus" to Spec(types = mapOf("enabled" to "b", "start_min" to "i", "end_min" to "i", "days" to "i")),
        "website_limits" to Spec(types = mapOf("limits" to "s")),
        "website_blocking" to Spec(types = mapOf("apps_on" to "ss", "rules" to "s")),
        "content_filters" to Spec(
            types = mapOf("edu_channels" to "s", "edu_auto_detect" to "b", "features_on" to "ss", "custom_sections" to "s")
        ),
        "keyword_blocking" to Spec(all = true, types = mapOf("enabled" to "b", "check_pages" to "b", "rules" to "s")),
        "adult_blocking" to Spec(types = mapOf("enabled" to "b", "auto_update" to "b", "custom_entries" to "s")),
        "bedtime" to Spec(
            all = true,
            types = mapOf("enabled" to "b", "start_min" to "i", "end_min" to "i", "apps" to "ss"),
        ),
        "focus_profiles" to Spec(
            all = true,
            types = mapOf("selected" to "i"),
            prefixTypes = mapOf(
                "name_" to "s", "created_" to "l", "updated_" to "l", "blocked_" to "ss", "shorts_" to "b",
                "features_" to "ss", "web_apps_" to "ss", "web_rules_" to "s", "limits_" to "ss", "limit_emg_" to "ss",
            ),
        ),
        "smart_suggest" to Spec(types = mapOf("enabled" to "b")),
    )

    /** True when [key] of the settings file [file] is part of a backup. */
    internal fun covers(file: String, key: String): Boolean = SPECS[file]?.matches(key) == true

    /** True when [key] is kept out of a copy shared with a friend. */
    internal fun isPersonal(file: String, key: String): Boolean = SPECS[file]?.let { key in it.personal } == true

    /**
     * The settings of this phone as one text (JSON). Every file is listed, even an empty one, so a restore also clears what
     * was removed. [forSharing] leaves out the personal keys.
     */
    fun snapshot(context: Context, forSharing: Boolean = false): String {
        val files = JSONObject()
        for ((name, spec) in SPECS) {
            val o = JSONObject()
            for ((key, value) in Storage.prefs(context, name).all) {
                if (spec.matches(key) && !spec.skipped(key, forSharing)) encode(value)?.let { o.put(key, it) }
            }
            files.put(name, o)
        }
        return JSONObject().put("v", VERSION).put("files", files).toString()
    }

    /**
     * Writes a backup text into this phone's settings. Everything is read and checked first; nothing is written when any
     * part is invalid. Returns true when it was applied (the app must be restarted afterwards). With [shared] the text came
     * from a friend: the personal keys of this phone are left as they are.
     */
    fun apply(context: Context, text: String, shared: Boolean = false): Boolean {
        val parsed = parse(text, shared) ?: return false
        for ((name, values) in parsed) {
            val spec = SPECS[name] ?: continue
            val prefs = Storage.prefs(context, name)
            val editor = prefs.edit()
            prefs.all.keys.filter { spec.matches(it) && !spec.skipped(it, shared) }.forEach { editor.remove(it) }
            for ((key, value) in values) {
                when (value) {
                    is String -> editor.putString(key, value)
                    is Boolean -> editor.putBoolean(key, value)
                    is Int -> editor.putInt(key, value)
                    is Long -> editor.putLong(key, value)
                    is Float -> editor.putFloat(key, value)
                    is Set<*> -> editor.putStringSet(key, value.filterIsInstance<String>().toSet())
                }
            }
            if (!editor.commit()) return false
        }
        return true
    }

    /**
     * file -> key -> value, only for known files and keys; null when the text is not a valid backup of this app, or when a
     * value has another type than the app stores under that key.
     */
    internal fun parse(text: String, shared: Boolean = false): Map<String, Map<String, Any>>? {
        val root = try { JSONObject(text) } catch (_: Exception) { return null }
        if (root.optInt("v", -1) !in 1..VERSION) return null
        val files = root.optJSONObject("files") ?: return null
        val result = LinkedHashMap<String, Map<String, Any>>()
        for (name in files.keys()) {
            val spec = SPECS[name] ?: continue
            val o = files.optJSONObject(name) ?: return null
            val values = LinkedHashMap<String, Any>()
            for (key in o.keys()) {
                if (!spec.matches(key) || spec.skipped(key, shared)) continue
                val node = o.optJSONObject(key)
                val expected = spec.expected(key)
                if (expected != null && node?.optString("t") != expected) return null
                values[key] = decode(node) ?: return null
            }
            result[name] = values
        }
        return result
    }

    private fun encode(value: Any?): JSONObject? = when (value) {
        is String -> JSONObject().put("t", "s").put("v", value)
        is Boolean -> JSONObject().put("t", "b").put("v", value)
        is Int -> JSONObject().put("t", "i").put("v", value)
        is Long -> JSONObject().put("t", "l").put("v", value)
        is Float -> JSONObject().put("t", "f").put("v", value.toDouble())
        is Set<*> -> JSONObject().put("t", "ss").put("v", JSONArray(value.filterIsInstance<String>()))
        else -> null
    }

    private fun decode(o: JSONObject?): Any? {
        if (o == null || !o.has("v")) return null
        return when (o.optString("t")) {
            "s" -> o.optString("v")
            "b" -> o.optBoolean("v")
            "i" -> o.optInt("v")
            "l" -> o.optLong("v")
            "f" -> o.optDouble("v").toFloat()
            "ss" -> {
                val arr = o.optJSONArray("v") ?: return null
                (0 until arr.length()).map { arr.optString(it) }.toSet()
            }
            else -> null
        }
    }

    /** Why a download must wait, or null. A download changes blocking rules, so it follows the same locks as every other change. */
    fun downloadBlockedReason(focus: FocusState, pomodoroActive: Boolean): String? = when {
        focus.focusActive -> "Focus Mode is on. Download your settings after the session ends."
        pomodoroActive -> "A Pomodoro is running. Download your settings after it ends."
        focus.changesLocked -> "Prevent changes is on. Unlock changes first, then download."
        else -> null
    }
}

/**
 * The short code a person gives to a friend. Eight characters, written as XXXX-XXXX. The letters and digits that are easy
 * to mix up when read aloud or typed from a voice message (I, L, O, 0, 1) are never used, so a friend cannot mistype them.
 */
object ShareCode {
    const val LENGTH = 8
    internal const val ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"

    fun generate(random: Random = SecureRandom()): String =
        buildString { repeat(LENGTH) { append(ALPHABET[random.nextInt(ALPHABET.length)]) } }

    /** K7P2-9QXM */
    fun display(code: String): String = code.chunked(4).joinToString("-")

    private val INSIDE_TEXT = Regex("(?<![A-Z0-9])[ABCDEFGHJKMNPQRSTUVWXYZ2-9]{4}-[ABCDEFGHJKMNPQRSTUVWXYZ2-9]{4}(?![A-Z0-9])")

    /**
     * What the friend typed or pasted, cleaned up: capital letters, without spaces, dashes or other marks. When the whole
     * message of the friend was pasted, the code written as XXXX-XXXX inside it is taken. Null when there is no code of this
     * app in it.
     */
    fun normalize(input: String): String? {
        val upper = input.uppercase()
        val cleaned = upper.filter { it.isLetterOrDigit() }
        if (cleaned.length == LENGTH) return cleaned.takeIf { text -> text.all { it in ALPHABET } }
        return INSIDE_TEXT.find(upper)?.value?.replace("-", "")
    }
}

/** What the server holds at users/{uid}/settingsBackup or sharedSettings/{code}: one text plus when it was uploaded. */
data class RemoteBackup(val data: String, val updatedAt: Long)

/**
 * Reads and writes users/{uid}/settingsBackup through [FirebaseGateway] (same connection, REST fallback and retries as the
 * profile). Only the owner can read or write it (firebase/database.rules.json). Every call first checks that the Firebase
 * login really is [uid].
 */
class SettingsBackupRemote(context: Context) {

    private val appContext = context.applicationContext

    private suspend fun requireLogin(uid: String) {
        if (FirebaseGateway.uid(appContext) != uid) {
            throw OnlineException(OnlineException.Kind.AUTH, "This account is no longer signed in.")
        }
    }

    suspend fun upload(uid: String, data: String, now: Long = System.currentTimeMillis()) {
        requireLogin(uid)
        if (data.length > SettingsBackupRules.MAX_CHARS) {
            throw OnlineException(OnlineException.Kind.OTHER, "Your settings are too large to back up.")
        }
        FirebaseGateway.setNode(
            appContext, "users/$uid/settingsBackup",
            JSONObject().put("v", SettingsBackupRules.VERSION).put("updatedAt", now).put("data", data)
        )
    }

    /** The saved backup, or null when this account never uploaded one. */
    suspend fun fetch(uid: String): RemoteBackup? {
        requireLogin(uid)
        val node = FirebaseGateway.readNode(appContext, "users/$uid/settingsBackup") ?: return null
        val data = node.optString("data")
        if (data.isEmpty()) return null
        return RemoteBackup(data, node.optLong("updatedAt"))
    }
}

/**
 * Settings shared with a friend at sharedSettings/{code}. Anyone who is logged in and knows the code can read it; nobody can
 * list the codes, change a code that exists, or write over somebody else's (firebase/database.rules.json).
 */
class SharedSettingsRemote(context: Context) {

    private val appContext = context.applicationContext

    private suspend fun requireLogin(uid: String) {
        if (FirebaseGateway.uid(appContext) != uid) {
            throw OnlineException(OnlineException.Kind.AUTH, "This account is no longer signed in.")
        }
    }

    /** Saves [data] under a new code and returns the code (eight characters, without the dash). */
    suspend fun publish(uid: String, data: String, now: Long = System.currentTimeMillis()): String {
        requireLogin(uid)
        if (data.length > SettingsBackupRules.MAX_CHARS) {
            throw OnlineException(OnlineException.Kind.OTHER, "Your settings are too large to share.")
        }
        var refused: OnlineException? = null
        // A code that already exists is refused by the server rule, so a second, different code is tried once.
        repeat(2) {
            val code = ShareCode.generate()
            try {
                FirebaseGateway.setNode(
                    appContext, "sharedSettings/$code",
                    JSONObject().put("v", SettingsBackupRules.VERSION).put("owner", uid).put("createdAt", now).put("data", data)
                )
                return code
            } catch (e: OnlineException) {
                if (e.kind != OnlineException.Kind.PERMISSION) throw e
                refused = e
            }
        }
        throw refused ?: OnlineException(OnlineException.Kind.OTHER, "Could not make a code. Try again.")
    }

    /** The settings behind [code] (any spelling [ShareCode.normalize] accepts), or null when there is no such code. */
    suspend fun fetch(uid: String, code: String): RemoteBackup? {
        val clean = ShareCode.normalize(code) ?: return null
        requireLogin(uid)
        val node = FirebaseGateway.readNode(appContext, "sharedSettings/$clean") ?: return null
        val data = node.optString("data")
        if (data.isEmpty()) return null
        return RemoteBackup(data, node.optLong("createdAt"))
    }
}
