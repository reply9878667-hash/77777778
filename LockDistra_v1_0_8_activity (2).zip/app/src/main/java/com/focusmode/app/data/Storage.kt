package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Build

/**
 * SharedPreferences kept in device-protected storage, which Android makes readable right after
 * a restart, before the first unlock. That is what lets an unfinished focus session and the
 * daily usage numbers be restored as early as Android allows. Existing data is moved over
 * once, automatically.
 */
object Storage {
    fun prefs(context: Context, name: String): SharedPreferences {
        val app = context.applicationContext
        if (Build.VERSION.SDK_INT >= 24) {
            val deviceProtected = app.createDeviceProtectedStorageContext()
            try {
                deviceProtected.moveSharedPreferencesFrom(app, name)
            } catch (_: Exception) {
                // Not available yet (phone still locked); it moves on a later start.
            }
            return deviceProtected.getSharedPreferences(name, Context.MODE_PRIVATE)
        }
        return app.getSharedPreferences(name, Context.MODE_PRIVATE)
    }
}
