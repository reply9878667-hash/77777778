package com.focusmode.app.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One page of search results: the videos that passed the study rules, and the token of the next page (or null). */
data class StudyPage(val videos: List<StudyVideo>, val next: String?)

/**
 * Talks to the official YouTube Data API v3 (no scraping, no extra library). Every call is blocking: run it off the
 * main thread. Costs against the free daily limit (10,000 units): a search is 100, everything else here is 1.
 */
class StudyApi(private val store: StudyStore) {

    /**
     * Calls YouTube with the first key that is not resting. A key whose daily limit is used up rests until the limit
     * resets (midnight Pacific time = 08:01 UTC at the latest); a refused key rests for 5 minutes. The next key then
     * answers the same call, so the person never notices. Only when every key is resting does the limit message show.
     */
    private fun get(endpoint: String, params: Map<String, String>): String {
        val keys = store.apiKeyList
        if (keys.isEmpty()) {
            val none = StudyException(StudyErrorKind.NO_KEY, "This needs a YouTube API key, and none is set in this version of the app.")
            noteFailure(none)
            throw none
        }
        var last: StudyException? = null
        for (key in keys) {
            if (store.isKeyResting(key)) continue
            try {
                val started = System.currentTimeMillis()
                val answer = getWith(key, endpoint, params)
                StudyMonitor.report(StudyMode.API)
                StudySources.tracker.success(StudyMode.API, responseMs = System.currentTimeMillis() - started)
                return answer
            } catch (e: StudyException) {
                when (e.kind) {
                    StudyErrorKind.QUOTA -> store.restKey(key, if (e.dailyLimit) nextQuotaReset() else System.currentTimeMillis() + 60_000L, StudyErrorKind.QUOTA)
                    // A key problem may be a one-off (a 403 while Google is changing something): rest only 5 minutes, then ask again by itself.
                    StudyErrorKind.BAD_KEY -> store.restKey(key, System.currentTimeMillis() + 300_000L, StudyErrorKind.BAD_KEY)
                    else -> { noteFailure(e); throw e } // network / other: not the key's fault, do not try the others
                }
                last = e
            }
        }
        // Only now, when NO key could answer, is it a failure of the API (one key failing while the next answers is not).
        if (last != null) { noteFailure(last); throw last }
        val resting = restingError(keys)
        noteResting(resting)
        throw resting
    }

    /** A real failure of the YouTube API: recorded for source detection (a missing item is not a failure). */
    private fun noteFailure(e: StudyException) {
        SourceClassifier.fromApi(e, System.currentTimeMillis())?.let { StudySources.tracker.failure(StudyMode.API, it) }
    }

    /** Nothing was asked (every key rests): this repeats what an earlier real answer already proved, so it is not counted again. */
    private fun noteResting(e: StudyException) {
        SourceClassifier.fromApi(e, System.currentTimeMillis())?.let { StudySources.tracker.observe(StudyMode.API, it) }
    }

    /**
     * One tiny request (1 unit, a short list of languages) that tells whether the API answers. Used only by the source re-check
     * after a failure, never on a timer. The outcome is recorded by [get]. Returns true when the API answered.
     */
    fun ping(): Boolean = try {
        get("i18nLanguages", mapOf("part" to "snippet", "hl" to "en"))
        true
    } catch (e: StudyException) {
        false
    }

    /**
     * Every key is resting, so nothing was asked. The answer says WHY they rest: refused keys are a key problem, only a used-up
     * limit is "the limit is used up" (before, a refused key was reported as a used-up limit).
     */
    private fun restingError(keys: List<String>): StudyException =
        if (keys.all { store.restReason(it) == StudyErrorKind.BAD_KEY }) {
            StudyException(StudyErrorKind.BAD_KEY, "This key cannot use the YouTube Data API.", reason = SourceReason.KEY_REFUSED)
        } else if (keys.minOf { store.restUntil(it) } - System.currentTimeMillis() > 15L * 60_000L) {
            StudyException(StudyErrorKind.QUOTA, "Today's free YouTube limit is used up. It resets once a day.", reason = SourceReason.DAILY_LIMIT)
        } else {
            // Every key rests only a minute or so: that is the per-minute limit, not "used up for today".
            StudyException(StudyErrorKind.QUOTA, "YouTube is busy for a moment. Try again in a minute.", dailyLimit = false, reason = SourceReason.RATE_LIMIT)
        }

    private fun nextQuotaReset(): Long = SourceClassifier.nextQuotaReset(System.currentTimeMillis())

    private fun getWith(key: String, endpoint: String, params: Map<String, String>): String {
        val query = (params + ("key" to key)).entries.joinToString("&") { it.key + "=" + URLEncoder.encode(it.value, "UTF-8") }
        val c = URL("https://www.googleapis.com/youtube/v3/$endpoint?$query").openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 10000
        if (store.androidCertSha1.isNotEmpty()) {
            c.setRequestProperty("X-Android-Package", store.androidPackage)
            c.setRequestProperty("X-Android-Cert", store.androidCertSha1)
        }
        // The stream is closed (not disconnect()): a disconnected socket is thrown away, a closed stream lets the next call
        // reuse the same HTTPS connection (no new TLS handshake for every request: much faster).
        return try {
            val code = c.responseCode
            if (code == 200) {
                val body = c.inputStream.use { it.bufferedReader().readText() }
                // A 200 that is not JSON (a Wi-Fi login page, a proxy notice) is an unreadable answer, not an empty result.
                if (!StudyRules.isAnswerObject(body)) throw StudyException(StudyErrorKind.BAD_ANSWER, "YouTube's answer could not be read.", source = StudyMode.API)
                body
            } else throw StudyRules.parseError(code, (c.errorStream ?: c.inputStream).use { it.bufferedReader().readText() })
        } catch (e: java.net.SocketTimeoutException) {
            throw StudyException(StudyErrorKind.NETWORK, "No internet, or YouTube could not be reached.", reason = SourceReason.TIMEOUT)
        } catch (e: IOException) {
            throw StudyException(StudyErrorKind.NETWORK, "No internet, or YouTube could not be reached.", reason = SourceReason.UNREACHABLE)
        }
    }

    /**
     * Search suggestions while typing, like YouTube's search box. Uses YouTube's own suggestion service: free, needs no key
     * and costs nothing of the daily limit. Any failure just means no suggestions.
     */
    fun suggest(query: String): List<String> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        cachedSuggest(q)?.let { return it }
        return try {
            val c = URL("https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=" + URLEncoder.encode(q, "UTF-8"))
                .openConnection() as HttpURLConnection
            c.connectTimeout = 2500
            c.readTimeout = 2500
            val list = if (c.responseCode == 200) c.inputStream.use { StudyRules.parseSuggestions(it.bufferedReader(Charsets.UTF_8).readText()) } else emptyList()
            if (list.isNotEmpty()) synchronized(suggestCache) { suggestCache[q.lowercase()] = list }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Suggestions already fetched for exactly this text (memory only), or null. Instant: safe to call on the main thread. */
    fun cachedSuggest(query: String): List<String>? = synchronized(suggestCache) { suggestCache[query.trim().lowercase()] }

    companion object {
        private class Timed<T>(val at: Long, val value: T?)

        private const val CACHE_TTL = 10L * 60 * 1000

        /** Videos YouTube described lately (value null = it returned nothing for that id). Shared by every [StudyApi] in the app. */
        private val videoCache = object : LinkedHashMap<String, Timed<StudyVideo>>(128, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Timed<StudyVideo>>?): Boolean = size > 600
        }

        /** Channels YouTube described lately. */
        private val infoCache = object : LinkedHashMap<String, Timed<StudyChannelInfo>>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Timed<StudyChannelInfo>>?): Boolean = size > 200
        }

        /** Remembers the last 300 typed texts, so typing the same thing again (or backspacing) shows suggestions at once. */
        private val suggestCache = object : LinkedHashMap<String, List<String>>(64, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<String>>?): Boolean = size > 300
        }
    }

    /**
     * Details of [ids] (1 unit per 50), in the same order. A video asked about lately is answered from memory (also one YouTube
     * did not return: private, live or removed), so the same ids are never paid for twice. The memory is shared by the whole app.
     */
    fun details(ids: List<String>): List<StudyVideo> {
        val wanted = ids.filter { it.isNotEmpty() }.distinct()
        val now = System.currentTimeMillis()
        val found = HashMap<String, StudyVideo>()
        val missing = ArrayList<String>()
        synchronized(videoCache) {
            for (id in wanted) {
                val hit = videoCache[id]
                if (hit != null && now - hit.at <= CACHE_TTL) hit.value?.let { found[id] = it } else missing += id
            }
        }
        missing.chunked(50).forEach { chunk ->
            val json = try {
                get("videos", mapOf("part" to "snippet,contentDetails,status", "id" to chunk.joinToString(","), "maxResults" to "50"))
            } catch (e: StudyException) {
                // Part 4/4: the API cannot answer now: what it described EARLIER (any age) is better than a hole in the list, so the
                // same video keeps its title, length and picture while another source takes over. Nothing old at all = the failure stands.
                val old = synchronized(videoCache) { chunk.mapNotNull { videoCache[it]?.value } }
                if (old.isEmpty()) throw e
                old.forEach { found[it.id] = it }
                return@forEach
            }
            val got = StudyRules.parseVideos(json)
            val at = System.currentTimeMillis()
            synchronized(videoCache) {
                got.forEach { videoCache[it.id] = Timed(at, it); found[it.id] = it }
                // "Returned nothing" is remembered only when the same answer did hold other videos (so an odd empty answer is never kept).
                if (got.isNotEmpty()) chunk.forEach { if (it !in found) videoCache[it] = Timed(at, null) }
            }
        }
        return wanted.mapNotNull { found[it] }
    }

    /** Searches Education videos (100 units). [shorts] asks for short clips only. Results are NOT filtered yet. */
    fun searchIds(query: String, shorts: Boolean, pageToken: String? = null): Pair<List<String>, String?> {
        val p = linkedMapOf(
            "part" to "snippet", "type" to "video", "q" to if (shorts) "$query #shorts" else query,
            "maxResults" to "30", "videoEmbeddable" to "true",
            "safeSearch" to "strict",
            // Like YouTube for an Indian viewer: Indian and Hindi results first (a soft preference, not a hard filter).
            "regionCode" to "IN", "relevanceLanguage" to "hi",
        )
        // Long videos stay Education only. Shorts are not limited to that category (explainer creators are filed under Science &
        // Technology or News & Politics): the Study rules ([StudyRules.acceptShort]) pick the categories afterwards.
        if (shorts) p["videoDuration"] = "short" else p["videoCategoryId"] = StudyRules.EDUCATION_CATEGORY
        if (pageToken != null) p["pageToken"] = pageToken
        val json = get("search", p)
        return StudyRules.parseSearchIds(json) to StudyRules.parseNextPage(json)
    }

    /** The newest uploads of a channel (1 unit). */
    fun uploadIds(channelId: String, count: Int = 12): List<String> = uploadPage(channelId, count, null).first

    /** Picture, handle, description and counts of channels (1 unit per 50). A channel asked about lately comes from memory. */
    fun channelInfos(ids: List<String>): List<StudyChannelInfo> {
        val wanted = ids.filter { it.isNotEmpty() }.distinct()
        val now = System.currentTimeMillis()
        val out = ArrayList<StudyChannelInfo>()
        val missing = ArrayList<String>()
        synchronized(infoCache) {
            for (id in wanted) {
                val hit = infoCache[id]
                if (hit != null && now - hit.at <= CACHE_TTL) hit.value?.let { out += it } else missing += id
            }
        }
        missing.chunked(50).forEach { chunk ->
            val got = StudyRules.parseChannelInfos(get("channels", mapOf("part" to "snippet,statistics", "id" to chunk.joinToString(","), "maxResults" to "50")))
            val at = System.currentTimeMillis()
            synchronized(infoCache) { got.forEach { infoCache[it.id] = Timed(at, it) } }
            out += got
        }
        return out
    }

    /** One page of a channel's uploads (1 unit): the video ids and the token of the next page (or null). */
    fun uploadPage(channelId: String, count: Int = 30, pageToken: String? = null): Pair<List<String>, String?> {
        val p = linkedMapOf("part" to "contentDetails", "playlistId" to StudyRules.uploadsPlaylist(channelId), "maxResults" to count.toString())
        if (pageToken != null) p["pageToken"] = pageToken
        val json = try {
            get("playlistItems", p)
        } catch (e: StudyException) {
            // A channel that never uploaded has no uploads playlist: that is an empty channel, not a failure.
            if (e.kind == StudyErrorKind.NOT_FOUND) return emptyList<String>() to null
            throw e
        }
        return StudyRules.parsePlaylistIds(json) to StudyRules.parseNextPage(json)
    }

    /** Looks a pasted channel up (1 unit). Throws when it does not exist. */
    fun channel(ref: ChannelRef): StudyChannel {
        val params = when (ref) {
            is ChannelRef.Handle -> mapOf("part" to "snippet", "forHandle" to "@" + ref.handle)
            is ChannelRef.Id -> mapOf("part" to "snippet", "id" to ref.id)
        }
        return StudyRules.parseChannel(get("channels", params))
            ?: throw StudyException(StudyErrorKind.OTHER, "No channel found for that link or name.")
    }
}
