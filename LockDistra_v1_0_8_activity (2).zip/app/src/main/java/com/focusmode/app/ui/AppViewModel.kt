package com.focusmode.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.AppRepository
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.AppLimit
import com.focusmode.app.data.ChangeGuard
import com.focusmode.app.data.ChangeWindowRules
import com.focusmode.app.data.ContentState
import com.focusmode.app.data.ContentStore
import com.focusmode.app.data.PomodoroState
import com.focusmode.app.data.PomodoroStore
import com.focusmode.app.data.KeywordEdits
import com.focusmode.app.data.KeywordRules
import com.focusmode.app.data.KeywordState
import com.focusmode.app.data.KeywordStore
import com.focusmode.app.data.ContentPolicy
import com.focusmode.app.data.WebsiteLimitRules
import com.focusmode.app.data.WebsiteLimitState
import com.focusmode.app.data.WebsiteLimitStore
import com.focusmode.app.data.WebsiteRules
import com.focusmode.app.data.BedtimeRules
import com.focusmode.app.data.BedtimeState
import com.focusmode.app.data.BedtimeStore
import com.focusmode.app.data.WebsiteState
import com.focusmode.app.data.WebsiteStore
import com.focusmode.app.data.EmergencyState
import com.focusmode.app.data.EmergencyStore
import com.focusmode.app.data.FocusControl
import com.focusmode.app.data.FocusProfileSettings
import com.focusmode.app.data.FocusProfileStore
import com.focusmode.app.data.WebsiteEdits
import com.focusmode.app.data.FocusProfilesState
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.LimitsState
import com.focusmode.app.data.LockSession
import com.focusmode.app.data.LockState
import com.focusmode.app.data.LockStore
import com.focusmode.app.data.LockType
import com.focusmode.app.data.VerifyResult
import com.focusmode.app.data.online.OnlineManager
import com.focusmode.app.data.online.OnlineState
import com.focusmode.app.data.online.UnlockGateRules
import com.focusmode.app.data.online.UnlockMode
import com.focusmode.app.data.UsageLimitStore
import com.focusmode.app.service.BedtimeEngine
import com.focusmode.app.service.FocusController
import com.focusmode.app.service.FocusEngine
import com.focusmode.app.service.PomodoroEngine
import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.service.Notifications
import com.focusmode.app.service.Permissions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen { Home, Apps, Limits, Emergency, Study, Settings, Features, Education, Plant, Session, Approvals, Profile }

class AppViewModel(application: Application) : AndroidViewModel(application), LockController {

    private val store = FocusStore.get(application)
    private val limitStore = UsageLimitStore.get(application)
    private val emergencyStore = EmergencyStore.get(application)
    private val contentStore = ContentStore.get(application)
    private val websiteStore = WebsiteStore.get(application)
    private val websiteLimitStore = WebsiteLimitStore.get(application)
    private val keywordStore = KeywordStore.get(application)
    private val pomodoroStore = PomodoroStore.get(application)
    private val bedtimeStore = BedtimeStore.get(application)
    private val focusProfileStore = FocusProfileStore.get(application)
    private val lockStore = LockStore.get(application)

    val lock: StateFlow<LockState> = lockStore.state

    /** Online Approval unlock (trusted phone). Independent of the PIN / password lock above. */
    val online: OnlineManager = OnlineManager.get(application)
    val onlineState: StateFlow<OnlineState> = online.state

    /**
     * Accounts (Google / email). Created here so the saved login is checked once at every app start; the account
     * screens and Settings use the same instance.
     */
    val auth: com.focusmode.app.data.auth.AuthRepository =
        com.focusmode.app.data.auth.AuthRepository.get(application)

    /**
     * The profile of the logged-in account (name, photo / avatar, onboarding answers). Created here so it follows the
     * login from the first moment: it loads the phone's copy, moves the onboarding answers into a new account and
     * syncs with the server at every start.
     */
    val profile: com.focusmode.app.data.profile.ProfileRepository =
        com.focusmode.app.data.profile.ProfileRepository.get(application)

    /**
     * Whether a lock screen must stand in front of the app: the PIN / password lock as before, or
     * Online approval (which fails closed). With the default "Password" mode this equals the old
     * `lock.enabled`.
     */
    val gateActive: StateFlow<Boolean> = combine(lockStore.state, online.state) { l, o ->
        UnlockGateRules.gateActive(o.mode, l.enabled)
    }.stateIn(
        viewModelScope, SharingStarted.Eagerly,
        UnlockGateRules.gateActive(online.state.value.mode, lockStore.current().enabled)
    )

    val content: StateFlow<ContentState> = contentStore.state

    val websites: StateFlow<WebsiteState> = websiteStore.state
    val websiteLimits: StateFlow<WebsiteLimitState> = websiteLimitStore.state
    val keywords: StateFlow<KeywordState> = keywordStore.state

    val pomodoro: StateFlow<PomodoroState> = pomodoroStore.state

    val bedtime: StateFlow<BedtimeState> = bedtimeStore.state

    /** Saved Focus Profiles (max two). Basic data only; nothing here touches blocking. */
    val focusProfiles: StateFlow<FocusProfilesState> = focusProfileStore.state

    val emergency: StateFlow<EmergencyState> = emergencyStore.state

    val limits: StateFlow<LimitsState> = limitStore.state

    val state: StateFlow<FocusState> = store.state

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps: StateFlow<List<AppInfo>> = _apps

    private val _appsLoaded = MutableStateFlow(false)
    val appsLoaded: StateFlow<Boolean> = _appsLoaded

    private val _permissions = MutableStateFlow(Permissions.read(application))
    val permissions: StateFlow<PermissionStatus> = _permissions

    var screen by mutableStateOf(Screen.Home)

    /** Set when the status notification's "Emergency access" action opens the app. */
    var emergencyRequested by mutableStateOf(false)

    /** A link shared to LockDistra from another app (Share button). FocusApp hands it to the start wizard and sets it back to null. */
    var sharedLink by mutableStateOf<String?>(null)

    init {
        refreshApps()
        // While the app is open, a trusted phone listens live. When it is closed, the Worker's push wakes it.
        viewModelScope.launch {
            online.state.map { it.isApprover }.distinctUntilChanged().collect { approver ->
                // No permanent listener any more: the push or the Unlock requests screen starts it.
                if (!approver) online.stopApproverWatch()
            }
        }
    }

    fun refreshApps() {
        viewModelScope.launch {
            val list = AppRepository.loadLaunchableApps(getApplication())
            if (list != _apps.value) _apps.value = list
            _appsLoaded.value = true
        }
    }

    fun refreshPermissions() {
        val latest = Permissions.read(getApplication())
        if (latest != _permissions.value) _permissions.value = latest
    }

    // ---- Focus session ----------------------------------------------------------------------

    fun startFocus(minutes: Int) = FocusController.start(getApplication(), minutes)
    /** Returns false when "Allow turning LockDistra OFF" is switched off. */
    fun stopFocus(): Boolean = FocusController.requestStop(getApplication())
    /** Chooses how Focus Mode may be turned OFF. False when it can't be changed right now (session running / settings locked). */
    fun setOffMethod(method: com.focusmode.app.data.FocusOffMethod): Boolean = store.setOffMethod(method)
    /** Chooses the Study Check-In interval in minutes (0 = off). False when it can't be changed right now (session running / settings locked). */
    fun setStudyCheckIn(minutes: Int): Boolean = store.setStudyCheckInMinutes(minutes)
    // ---- Pomodoro (cycle logic in PomodoroEngine; it only drives the existing focus session) ---

    fun startPomodoro() = PomodoroEngine.start(getApplication())
    /** False when the running Focus round is locked ("Allow turning LockDistra OFF" is off). */
    fun pausePomodoro(): Boolean = PomodoroEngine.pause(getApplication())
    fun resumePomodoro() = PomodoroEngine.resume(getApplication())
    fun stopPomodoro(): Boolean = PomodoroEngine.stop(getApplication())
    fun setPomodoroDurations(focusMin: Int, breakMin: Int) = pomodoroStore.setDurations(focusMin, breakMin)
    fun canScheduleExactAlarms(): Boolean = FocusEngine.canScheduleExact(getApplication())

    fun startEmergency(pkg: String, minutes: Int): Boolean =
        FocusController.startEmergency(getApplication(), pkg, minutes)
    fun endEmergency() = FocusController.endEmergency(getApplication())

    // ---- Advanced controls and emergency apps -----------------------------------------------

    fun setControl(control: FocusControl, allowed: Boolean): Boolean =
        FocusController.setControl(getApplication(), control, allowed)

    fun setEmergencyEnabled(pkg: String, on: Boolean) = emergencyStore.setEnabled(pkg, on)
    fun setEmergencyLimit(pkg: String, limit: Int) = emergencyStore.setLimit(pkg, limit)
    fun setEmergencyResetMode(mode: Int) = emergencyStore.setResetMode(mode)
    fun resetEmergencyCounts() = emergencyStore.resetCounts()

    // ---- Settings (all saved immediately) ---------------------------------------------------

    fun setBlocked(pkg: String, blocked: Boolean) = store.setBlocked(pkg, blocked)

    // ---- Bedtime Mode (own schedule and app list; blocking is done by AppBlockerService) -------

    fun setBedtimeEnabled(on: Boolean) {
        bedtimeStore.update { it.copy(enabled = on) }
        BedtimeEngine.sync(getApplication())
    }
    /** False (nothing saved) when start and end are the same time. */
    fun setBedtimeTimes(startMin: Int, endMin: Int): Boolean {
        if (!BedtimeRules.validWindow(startMin, endMin)) return false
        bedtimeStore.update { it.copy(startMin = startMin, endMin = endMin) }
        BedtimeEngine.sync(getApplication())
        return true
    }
    fun setBedtimeApps(apps: Set<String>) {
        bedtimeStore.update { it.copy(apps = apps) }
        BedtimeEngine.sync(getApplication())
    }
    // ---- Focus Profiles (names only for now; no blocking settings) -----------------------------

    fun saveFocusProfile(slot: Int, name: String): Boolean = focusProfileStore.save(slot, name)
    fun deleteFocusProfile(slot: Int) = focusProfileStore.delete(slot)
    fun selectFocusProfile(slot: Int) = focusProfileStore.select(slot)

    // What a profile blocks and limits. Same kinds of edits as the global ones above, but written only to
    // that profile's own storage: the global blocked apps, websites, limits and content filters are not touched.
    // A profile is not a running session, so none of the session locks apply to editing it.

    fun updateFocusProfile(slot: Int, change: (FocusProfileSettings) -> FocusProfileSettings) =
        focusProfileStore.updateSettings(slot, change)

    private fun profileWebsites(
        slot: Int,
        edit: (com.focusmode.app.data.WebsiteState) -> WebsiteEdits.Change,
    ): WebsiteRules.Result {
        var result = WebsiteRules.Result.INVALID
        focusProfileStore.updateSettings(slot) { s ->
            val change = edit(s.websites)
            result = change.result
            s.withWebsites(change.state)
        }
        return result
    }

    fun setProfileWebsiteBlocking(slot: Int, pkg: String, on: Boolean) =
        focusProfileStore.updateSettings(slot) { s ->
            s.withWebsites(WebsiteEdits.setAppEnabled(s.websites, pkg, on, canTighten = true, canLoosen = true) ?: s.websites)
        }

    fun addProfileWebsite(slot: Int, pkg: String, raw: String, subdomains: Boolean) =
        profileWebsites(slot) { WebsiteEdits.addSite(it, pkg, raw, subdomains, canTighten = true) }

    fun editProfileWebsite(slot: Int, pkg: String, old: String, raw: String, subdomains: Boolean) =
        profileWebsites(slot) { WebsiteEdits.editSite(it, pkg, old, raw, subdomains, canLoosen = true) }

    fun removeProfileWebsite(slot: Int, pkg: String, domain: String) =
        focusProfileStore.updateSettings(slot) { s ->
            s.withWebsites(WebsiteEdits.removeSite(s.websites, pkg, domain, canLoosen = true) ?: s.websites)
        }

    fun setProfileWebsiteEnabled(slot: Int, pkg: String, domain: String, on: Boolean) =
        focusProfileStore.updateSettings(slot) { s ->
            s.withWebsites(WebsiteEdits.setSiteEnabled(s.websites, pkg, domain, on, canTighten = true, canLoosen = true) ?: s.websites)
        }

    fun setBlockShorts(on: Boolean) = store.setBlockShorts(on)
    fun setReminder(minutes: Int) = store.setReminderMinutes(minutes) // guarded in the store
    fun setUserName(name: String) = store.setUserName(name)
    fun setThemeMode(mode: Int) = store.setThemeMode(mode)

    // ---- Educational Shorts and sections inside apps (rules enforced in ContentStore) -------

    fun setFeature(id: String, on: Boolean) = contentStore.setFeature(id, on)
    fun setAutoDetect(on: Boolean) = contentStore.setAutoDetect(on)
    fun addChannel(raw: String) = contentStore.addChannel(raw)
    fun removeChannel(key: String) = contentStore.removeChannel(key)
    fun clearRecentBlocked() = contentStore.clearRecentBlocked()
    fun addCustomSection(pkg: String, label: String) = contentStore.addCustom(pkg, label)
    fun removeCustomSection(id: String) = contentStore.removeCustom(id)

    // ---- Keyword blocking (rules and session locks enforced in KeywordStore) --------------------
    fun setKeywordBlocking(on: Boolean) = keywordStore.setEnabled(on)
    fun setKeywordCheckPages(on: Boolean) = keywordStore.setCheckPages(on)
    fun addKeywords(raw: String, partial: Boolean): KeywordEdits.Bulk = keywordStore.addMany(raw, partial)
    fun editKeyword(old: String, raw: String, partial: Boolean): KeywordRules.Result = keywordStore.edit(old, raw, partial)
    fun removeKeyword(word: String) = keywordStore.remove(word)
    fun setKeywordEnabled(word: String, on: Boolean) = keywordStore.setRuleEnabled(word, on)

    // ---- Website blocking (rules and session locks enforced in WebsiteStore) -----------------

    fun setWebsiteBlocking(pkg: String, on: Boolean) = websiteStore.setAppEnabled(pkg, on)
    fun addWebsite(pkg: String, raw: String, subdomains: Boolean): WebsiteRules.Result =
        websiteStore.addSite(pkg, raw, subdomains)
    fun addWebsites(pkg: String, raw: String, subdomains: Boolean): WebsiteEdits.Bulk =
        websiteStore.addSites(pkg, raw, subdomains)
    fun editWebsite(pkg: String, old: String, raw: String, subdomains: Boolean): WebsiteRules.Result =
        websiteStore.editSite(pkg, old, raw, subdomains)
    fun removeWebsite(pkg: String, domain: String) = websiteStore.removeSite(pkg, domain)
    fun setWebsiteEnabled(pkg: String, domain: String, on: Boolean) = websiteStore.setSiteEnabled(pkg, domain, on)

    // ---- Website usage limits ---------------------------------------------------------------
    // Daily time limits for websites follow the same lock as app limits ("Allow app restriction changes").

    private fun siteLimitsLocked() = ContentPolicy.frozen(store.current())

    fun addWebsiteLimit(raw: String, minutes: Int): WebsiteLimitRules.Result =
        if (siteLimitsLocked()) WebsiteLimitRules.Result.LOCKED else websiteLimitStore.add(raw, minutes)

    fun editWebsiteLimit(old: String, raw: String, minutes: Int): WebsiteLimitRules.Result =
        if (siteLimitsLocked()) WebsiteLimitRules.Result.LOCKED else websiteLimitStore.edit(old, raw, minutes)

    fun removeWebsiteLimit(domain: String) {
        if (!siteLimitsLocked()) websiteLimitStore.remove(domain)
    }

    fun setWebsiteLimitEnabled(domain: String, on: Boolean) {
        if (!siteLimitsLocked()) websiteLimitStore.setEnabled(domain, on)
    }

    /** Brings today's numbers up to date (a new day clears yesterday's usage) when the list is opened. */
    fun refreshWebsiteLimits() = websiteLimitStore.refresh()

    // ---- Daily app limits -------------------------------------------------------------------

    // Limits are app restrictions, so they follow "Allow app restriction changes".
    fun saveLimit(limit: AppLimit) {
        if (!store.current().canEditApps) return
        val old = limitStore.limitFor(limit.pkg)
        val used = limitStore.usedMs(limit.pkg)
        limitStore.setLimit(limit)
        // A used-up limit was raised: the app opens again. Show the timer at once and tell the
        // person (phone message) how long the app is unlocked.
        if (old != null && used >= old.limitMs && used < limit.limitMs) {
            limitStore.requestPopupNow(limit.pkg)
            val app = getApplication<Application>()
            val label = runCatching {
                app.packageManager.getApplicationLabel(app.packageManager.getApplicationInfo(limit.pkg, 0)).toString()
            }.getOrDefault(limit.pkg)
            val minutesLeft = ((limit.limitMs - used + 59_999L) / 60_000L).toInt()
            runCatching { Notifications.postLimitRaised(app, label, minutesLeft, limit.pkg) }
        }
    }

    fun removeLimit(pkg: String) {
        if (store.current().canEditApps) limitStore.removeLimit(pkg)
    }

    // Daily limits for Shorts / Reels / Status follow the same lock as app limits.
    fun saveCategoryLimit(id: String, minutes: Int) {
        if (store.current().canEditApps) limitStore.setCategoryLimit(id, minutes)
    }

    fun removeCategoryLimit(id: String) {
        if (store.current().canEditApps) limitStore.removeCategoryLimit(id)
    }

    // Emergency access for a limit is part of the limit, so it follows the same lock.
    fun saveLimitEmergency(key: String, enabled: Boolean, attempts: Int, minutes: Int) {
        if (store.current().canEditApps) limitStore.setEmergency(key, enabled, attempts, minutes)
    }

    fun setFloatingTimer(on: Boolean) {
        if (store.current().canChangeSettings) limitStore.setFloatingTimer(on)
    }

    fun setFloatingOverGames(on: Boolean) {
        if (store.current().canChangeSettings) limitStore.setFloatingOverGames(on)
    }

    fun setFloatingStyle(id: String) {
        if (store.current().canChangeSettings) limitStore.setFloatingStyle(id)
    }

    fun setFloatingEvery(min: Int) {
        if (store.current().canChangeSettings) limitStore.setFloatingEveryMin(min)
    }

    // ---- Plant ------------------------------------------------------------------------------

    /** Answers the waiting plant reminder with "yes, I'm studying". Returns true if the plant grew. */
    fun checkIn(): Boolean {
        val s = store.current()
        if (!s.checkInPending) return false
        val grew = store.growFromNotification(s.checkInToken)
        Notifications.cancelReminder(getApplication())
        return grew
    }

    fun resetPlant() = store.resetPlant()

    fun removeAdmin() {
        if (!store.current().canChangeSettings) return
        // Advanced protection can't work without the admin, so it goes off with it.
        store.setAdvancedProtection(false)
        Permissions.removeAdmin(getApplication())
        refreshPermissions()
    }

    fun setRestoreAfterRestart(on: Boolean) = store.setRestoreAfterRestart(on)
    /** "Block the power menu". False when it can't be changed right now (settings locked). */

    fun setAdvancedProtection(on: Boolean) {
        // Never "on" without the device admin it relies on.
        store.setAdvancedProtection(on && Permissions.isAdminActive(getApplication()))
        refreshPermissions()
    }

    // ---- App lock (Task 5) ------------------------------------------------------------------
    // The lock only guards LockDistra's own screens. Blocking, limits and the session keep
    // running with it locked, and nothing here needs the lock to be open.

    override suspend fun verify(secret: String): VerifyResult =
        withContext(Dispatchers.Default) { lockStore.verify(secret) }

    override suspend fun enable(type: LockType, secret: String): String {
        val code = withContext(Dispatchers.Default) { lockStore.enable(type, secret) }
        // The person just set it up from inside the app, so this visit stays open.
        LockSession.unlock()
        return code
    }

    override suspend fun change(type: LockType, secret: String) =
        withContext(Dispatchers.Default) { lockStore.change(type, secret) }

    /** Turning the lock off is a settings change, so "Allow changing LockDistra settings" applies. */
    override fun disable(): Boolean {
        if (!store.current().canChangeSettings) return false
        lockStore.disable()
        online.onPasswordLockTurnedOff()
        // Prevent changes must keep a way to unlock it: without the app lock that is the trusted phone.
        if (store.current().preventChanges && !online.state.value.phoneConnected) {
            store.setPreventChanges(false, force = true)
        }
        return true
    }

    override suspend fun checkRecovery(code: String): VerifyResult =
        withContext(Dispatchers.Default) { lockStore.checkRecovery(code) }

    override suspend fun resetWithRecovery(code: String, type: LockType, secret: String): String? =
        withContext(Dispatchers.Default) { lockStore.resetWithRecovery(code, type, secret) }

    override fun newRecoveryCode(): String = lockStore.newRecoveryCode()

    override fun setBiometric(on: Boolean): Boolean {
        if (!store.current().canChangeSettings) return false
        lockStore.setBiometric(on)
        return true
    }

    override fun setAutoLockSeconds(seconds: Int): Boolean {
        if (!store.current().canChangeSettings) return false
        lockStore.setAutoLockSeconds(seconds)
        return true
    }

    override fun lockoutRemainingMs(): Long = lockStore.lockoutRemainingMs()

    override fun recoveryLockoutRemainingMs(): Long = lockStore.recoveryLockoutRemainingMs()

    override fun unlock() = LockSession.unlock()

    // ---- Prevent changes ------------------------------------------------------------------------
    // While it is on nothing (limits, blocked apps, settings) can be changed until the person is
    // checked: app PIN / password, recovery code or the trusted phone. The check opens a short
    // editing window (see ChangeGuard); the stores enforce it through FocusState.changesLocked.

    /** Error text, or null when the switch was changed. */
    fun setPreventChanges(on: Boolean): String? {
        if (on) {
            ChangeWindowRules.canTurnOn(lockStore.current().enabled, online.state.value.phoneConnected)
                ?.let { return it }
            if (!store.setPreventChanges(true)) return "Couldn't turn it on."
            // Close any open window, then give 10 seconds to undo a switch turned on by mistake; then it locks.
            ChangeGuard.close(getApplication())
            ChangeGuard.startGrace(getApplication())
            return null
        }
        if (!store.setPreventChanges(false)) return "Unlock changes first."
        ChangeGuard.close(getApplication())
        return null
    }

    /** Called after the PIN / password / recovery code was checked by the dialog. */
    fun openChanges() = ChangeGuard.open(getApplication())

    fun lockChangesNow() = ChangeGuard.close(getApplication())

    // ---- Online approval (settings guard) ------------------------------------------------------

    /** Same rule as the other lock settings: "Allow changing LockDistra settings". */
    fun canChangeSettings(): Boolean = store.current().canChangeSettings
}
