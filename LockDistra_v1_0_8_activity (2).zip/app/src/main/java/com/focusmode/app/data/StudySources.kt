package com.focusmode.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.IOException
import java.util.concurrent.atomic.AtomicLong
import java.net.SocketTimeoutException

/*
 * Study section, Part 2/4: Intelligent Source Detection.
 *
 * Three sources, each with its OWN status (StudyMode is the key):
 *   StudyMode.API  = YouTube Data API
 *   StudyMode.PAGE = Direct YouTube (YouTube's own search page data, StudyNative)
 *   StudyMode.WEB  = Web search (WebView, StudyWebSearch)
 *
 * This file only DETECTS and REMEMBERS. It never switches sources: the switching that already existed (StudyRepository /
 * StudyMonitor, the title colour) is untouched. Pure Kotlin (no Android classes), so it is unit tested on the JVM.
 *
 * Rules that keep the detection honest:
 *  - A status changes only on EVIDENCE: a real answer / failure of that very source, a persisted rest of an API key
 *    (earlier real answer), or a local fact that can be read for sure (app installed? WebView present? no network?).
 *  - A failure is recorded on the source that failed, never on another one.
 *  - A failure that can pass (timeout, 5xx, rate limit, no network) is never turned into a permanent state: it stays
 *    TEMPORARILY_FAILED / NETWORK_ERROR and is re-checked after a growing cool-down.
 */

enum class SourceStatus {
    /** Nothing verified yet (app just started). Never shown as a failure. */
    UNKNOWN,
    AVAILABLE,
    /** Verified that the source cannot work here (no API key at all, YouTube app not installed, no WebView on the phone). */
    UNAVAILABLE,
    /** Failed, but it can pass by itself: timeout, 5xx, busy server, YouTube refusing for a moment, unreadable answer. */
    TEMPORARILY_FAILED,
    /** Switched off on purpose (the source's enabled flag) or the YouTube app is disabled in Android. */
    DISABLED,
    /** The API key is invalid or refused. */
    AUTH_ERROR,
    /** The daily YouTube API limit is used up (the per-minute "too many requests" is TEMPORARILY_FAILED instead). */
    QUOTA_EXHAUSTED,
    /** The source could not be reached over the network (no connection, DNS, connection refused). */
    NETWORK_ERROR,
}

/** WHY a source has its status (for the report / later UI). [local] = read from the phone itself, re-read for free, cleared by itself. */
enum class SourceReason(val local: Boolean = false) {
    NONE,

    // YouTube API
    DAILY_LIMIT, RATE_LIMIT, INVALID_KEY, KEY_REFUSED, NO_KEY(true), TIMEOUT, SERVER_ERROR, SERVICE_UNAVAILABLE, UNREADABLE_ANSWER, UNREACHABLE,

    // any source
    NO_INTERNET(true), SWITCHED_OFF(true), UNKNOWN_ERROR,

    // Direct YouTube
    APP_NOT_INSTALLED(true), APP_DISABLED(true), PERMISSION_MISSING(true), PAGE_UNREADABLE, BLOCKED_BY_YOUTUBE,

    // Web
    WEBVIEW_MISSING(true), WEBVIEW_INIT_FAILED, RENDERER_STOPPED,
}

/**
 * The status of one source. [retryAt] is the earliest moment a network re-check is allowed (cool-down); it is
 * [Long.MAX_VALUE] while a LOCAL fact blocks the source (nothing to re-check on the network: the local fact is re-read instead).
 */
data class SourceState(
    val status: SourceStatus = SourceStatus.UNKNOWN,
    val reason: SourceReason = SourceReason.NONE,
    val changedAt: Long = 0L,
    /** Last evidence (success or failure). */
    val verifiedAt: Long = 0L,
    /** Failures in a row (drives the cool-down). */
    val failures: Int = 0,
    val retryAt: Long = 0L,
    /** Last time a network re-check was started (stops two checks running at once). */
    val checkedAt: Long = 0L,
    // ---- Part 4/4: health (all lightweight numbers kept in memory; nothing here starts a request) ----
    /** Last real success of this source (0 = none yet). */
    val lastSuccessAt: Long = 0L,
    /** Last real failure and why. Kept after a recovery, so the report can still say what went wrong before. */
    val lastFailureAt: Long = 0L,
    val lastFailureReason: SourceReason = SourceReason.NONE,
    /** Smoothed answer time of this source in ms (0 = not measured yet). */
    val responseMs: Long = 0L,
    /** When the source last came back from a failure (0 = never failed, or never came back). */
    val recoveredAt: Long = 0L,
    /** How many failures in a row it had before that recovery (a source that fails again right after it came back keeps counting from there). */
    val failuresBeforeRecovery: Int = 0,
) {
    val available: Boolean get() = status == SourceStatus.AVAILABLE
}

/** Where a source is on its way back from a failure. */
enum class RecoveryStatus {
    /** Working, or never failed / not verified yet. */
    HEALTHY,

    /** It failed and has just come back (shown for [SourceTracker.RECOVERED_SHOWN_MS]). */
    RECOVERED,

    /** Failed; waiting for its cool-down to end (or for the quota reset). */
    WAITING,

    /** Failed; the cool-down is over, the next re-check is allowed. */
    RETRY_DUE,

    /** A fact on the phone blocks it (switched off, app missing / disabled, no WebView ...): nothing to re-check on the network. */
    BLOCKED_BY_PHONE,
}

/** One read-only snapshot of the health of a source (Part 4/4): what the report and the switcher can look at without any request. */
data class SourceHealth(
    val mode: StudyMode,
    val status: SourceStatus,
    val available: Boolean,
    val lastSuccessAt: Long,
    val lastFailureAt: Long,
    val lastFailureReason: SourceReason,
    val responseMs: Long,
    val consecutiveFailures: Int,
    val recovery: RecoveryStatus,
    /** Milliseconds until the next re-check is allowed (0 = now, or nothing to wait for). */
    val retryInMs: Long,
)

/** What a failure means for the status. [retryAtMs] = 0 means "use the cool-down schedule". */
data class SourceFailure(val status: SourceStatus, val reason: SourceReason, val retryAtMs: Long = 0L)

/** Thrown by [StudyNative] for a page that answered with a non-200 code (still an [IOException], so old catches keep working). */
class HttpStatusException(val code: Int) : IOException("YouTube answered $code")

object SourceClassifier {

    /**
     * Direct YouTube is the integration the Study section has with YouTube itself. The person asked for it to be judged by
     * the YouTube APP being installed and enabled, so that is what decides here. NOTE: the page-data search itself needs only
     * internet, not the app; set this to false to keep Direct YouTube AVAILABLE on a phone without the app.
     */
    const val DIRECT_REQUIRES_APP = true

    const val RATE_LIMIT_WAIT_MS = 60_000L
    private const val DAILY_LIMIT_MIN_REST_MS = 15L * 60_000L

    /** Midnight Pacific time = 08:01 UTC at the latest: when the free daily limit resets. */
    fun nextQuotaReset(now: Long): Long {
        val c = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
            timeInMillis = now
            set(java.util.Calendar.HOUR_OF_DAY, 8); set(java.util.Calendar.MINUTE, 1)
            set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }
        return if (c.timeInMillis > now) c.timeInMillis else c.timeInMillis + 86_400_000L
    }

    // ---- YouTube API: what a real answer / failure means -----------------------------------------------------

    /** Null = this error says nothing about the API's health (a missing channel is the API answering correctly). */
    fun fromApi(e: StudyException, now: Long): SourceFailure? = when (e.kind) {
        StudyErrorKind.QUOTA ->
            if (e.dailyLimit) SourceFailure(SourceStatus.QUOTA_EXHAUSTED, SourceReason.DAILY_LIMIT, nextQuotaReset(now))
            else SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.RATE_LIMIT, now + RATE_LIMIT_WAIT_MS)
        StudyErrorKind.BAD_KEY ->
            SourceFailure(SourceStatus.AUTH_ERROR, if (e.reason == SourceReason.INVALID_KEY) SourceReason.INVALID_KEY else SourceReason.KEY_REFUSED)
        StudyErrorKind.NO_KEY -> SourceFailure(SourceStatus.UNAVAILABLE, SourceReason.NO_KEY)
        StudyErrorKind.NETWORK ->
            if (e.reason == SourceReason.TIMEOUT) SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT)
            else SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE)
        StudyErrorKind.BAD_ANSWER -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.UNREADABLE_ANSWER)
        StudyErrorKind.NOT_FOUND -> null
        StudyErrorKind.OTHER -> SourceFailure(
            SourceStatus.TEMPORARILY_FAILED,
            if (e.reason == SourceReason.NONE) SourceReason.UNKNOWN_ERROR else e.reason,
        )
    }

    /**
     * Every key of the API is resting (saved on the phone after a REAL answer earlier, so it is evidence, not a guess).
     * [reasons] and [restUntil] are parallel lists, one entry per key. Null when at least one key can still be asked.
     */
    fun fromResting(reasons: List<StudyErrorKind>, restUntil: List<Long>, now: Long): SourceFailure? {
        if (reasons.isEmpty() || reasons.size != restUntil.size) return null
        if (restUntil.any { it <= now }) return null
        val soonest = restUntil.min()
        return when {
            reasons.all { it == StudyErrorKind.BAD_KEY } -> SourceFailure(SourceStatus.AUTH_ERROR, SourceReason.KEY_REFUSED, soonest)
            // A key rests a whole day only for the daily limit; a short rest is the per-minute limit and must not look like "used up".
            soonest - now > DAILY_LIMIT_MIN_REST_MS -> SourceFailure(SourceStatus.QUOTA_EXHAUSTED, SourceReason.DAILY_LIMIT, soonest)
            else -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.RATE_LIMIT, soonest)
        }
    }

    // ---- Direct YouTube ---------------------------------------------------------------------------------------

    /** A failed page-data request. Only a refusal / unreadable page / timeout / 5xx: all of them pass, none is "disabled". */
    fun fromPage(t: Throwable?): SourceFailure = when {
        t is NoDataException -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.PAGE_UNREADABLE)
        t is SocketTimeoutException -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT)
        t is HttpStatusException -> httpFailure(t.code, SourceReason.BLOCKED_BY_YOUTUBE)
        t is IOException -> SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE)
        else -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.UNKNOWN_ERROR)
    }

    /** An HTTP answer that was not a success. 403 / 429 = YouTube refusing for now; 5xx = its server; both pass. */
    fun httpFailure(code: Int, refusedReason: SourceReason = SourceReason.BLOCKED_BY_YOUTUBE): SourceFailure = when {
        code == 429 || code == 403 -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, refusedReason)
        code in 500..599 -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.SERVER_ERROR)
        else -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.UNKNOWN_ERROR)
    }

    // ---- Web (WebView) ----------------------------------------------------------------------------------------

    /** A WebView main-frame error: [timeout] / [network] are decided by the caller from the WebView error code. */
    fun fromWebError(timeout: Boolean, network: Boolean): SourceFailure = when {
        timeout -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.TIMEOUT)
        network -> SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.UNREACHABLE)
        else -> SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.UNKNOWN_ERROR)
    }

    fun webRendererStopped(): SourceFailure = SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.RENDERER_STOPPED)

    /** Creating a WebView threw (a provider that is updating or broken). It can pass, so it is temporary. */
    fun webInitFailed(): SourceFailure = SourceFailure(SourceStatus.TEMPORARILY_FAILED, SourceReason.WEBVIEW_INIT_FAILED)

    // ---- local facts (read from the phone, no network). Null = nothing wrong, OR not known (unknown is never a failure) ----

    /** [offline]: true = no network for sure, false = there is one, null = cannot tell. */
    fun apiLocal(enabled: Boolean, keyCount: Int, offline: Boolean?): SourceFailure? = when {
        !enabled -> SourceFailure(SourceStatus.DISABLED, SourceReason.SWITCHED_OFF)
        keyCount == 0 -> SourceFailure(SourceStatus.UNAVAILABLE, SourceReason.NO_KEY)
        offline == true -> SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.NO_INTERNET)
        else -> null
    }

    /** Each argument: true / false = verified, null = could not be read (never counts against the source). */
    fun directLocal(
        enabled: Boolean,
        appInstalled: Boolean?,
        appEnabled: Boolean?,
        permissionsOk: Boolean?,
        offline: Boolean?,
        requiresApp: Boolean = DIRECT_REQUIRES_APP,
    ): SourceFailure? = when {
        !enabled -> SourceFailure(SourceStatus.DISABLED, SourceReason.SWITCHED_OFF)
        requiresApp && appInstalled == false -> SourceFailure(SourceStatus.UNAVAILABLE, SourceReason.APP_NOT_INSTALLED)
        requiresApp && appInstalled == true && appEnabled == false -> SourceFailure(SourceStatus.DISABLED, SourceReason.APP_DISABLED)
        permissionsOk == false -> SourceFailure(SourceStatus.UNAVAILABLE, SourceReason.PERMISSION_MISSING)
        offline == true -> SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.NO_INTERNET)
        else -> null
    }

    fun webLocal(enabled: Boolean, webViewPresent: Boolean?, offline: Boolean?): SourceFailure? = when {
        !enabled -> SourceFailure(SourceStatus.DISABLED, SourceReason.SWITCHED_OFF)
        webViewPresent == false -> SourceFailure(SourceStatus.UNAVAILABLE, SourceReason.WEBVIEW_MISSING)
        offline == true -> SourceFailure(SourceStatus.NETWORK_ERROR, SourceReason.NO_INTERNET)
        else -> null
    }
}

/**
 * Keeps one [SourceState] per source. Thread safe; the clock is a parameter so tests need no waiting.
 * There is NO timer and NO polling in here: it only changes when something reports evidence.
 */
class SourceTracker {
    private val lock = Any()
    private val flow = MutableStateFlow(
        mapOf(StudyMode.API to SourceState(), StudyMode.PAGE to SourceState(), StudyMode.WEB to SourceState()),
    )

    /** Observe from the screen if the status should ever be shown. */
    val states: StateFlow<Map<StudyMode, SourceState>> = flow

    fun state(mode: StudyMode): SourceState = flow.value.getValue(mode)

    private fun update(mode: StudyMode, f: (SourceState) -> SourceState) {
        synchronized(lock) { flow.value = flow.value + (mode to f(flow.value.getValue(mode))) }
    }

    /**
     * Bumped every time something came back (a source recovered, the phone is online again, a switch was turned on again).
     * The switcher compares it with the moment a failed request was remembered: after a recovery the old "this request just
     * failed" memory is stale and must not keep the request from using the recovered source.
     */
    private val epoch = AtomicLong(0L)
    val recoveryEpoch: Long get() = epoch.get()

    /**
     * A real answer of THIS source worked. A switch-off / missing app / missing WebView is not contradicted by it and stays.
     * [responseMs] = how long the answer took (0 = not measured); it only feeds the health numbers.
     */
    fun success(mode: StudyMode, now: Long = System.currentTimeMillis(), responseMs: Long = 0L) {
        var recovered = false
        update(mode) { cur ->
            val rt = smooth(cur.responseMs, responseMs)
            if (cur.status == SourceStatus.DISABLED || (cur.reason.local && cur.reason != SourceReason.NO_INTERNET)) {
                cur.copy(verifiedAt = now, lastSuccessAt = now, responseMs = rt)
            } else {
                val wasDown = cur.status != SourceStatus.AVAILABLE && cur.status != SourceStatus.UNKNOWN
                if (wasDown) recovered = true
                cur.copy(
                    status = SourceStatus.AVAILABLE,
                    reason = SourceReason.NONE,
                    changedAt = if (cur.available) cur.changedAt else now,
                    verifiedAt = now,
                    failures = 0,
                    retryAt = 0L,
                    lastSuccessAt = now,
                    responseMs = rt,
                    recoveredAt = if (wasDown) now else cur.recoveredAt,
                    failuresBeforeRecovery = if (wasDown) cur.failures else cur.failuresBeforeRecovery,
                )
            }
        }
        if (recovered) epoch.incrementAndGet()
    }

    /**
     * A real failure of THIS source. Counts toward the cool-down. A source that fails AGAIN soon after it came back keeps counting
     * from where it was (it does not start over at 30 s), so a source that flips between working and failing cannot cause a loop of
     * switches back and forth.
     */
    fun failure(mode: StudyMode, f: SourceFailure, now: Long = System.currentTimeMillis()) = update(mode) { cur ->
        if (cur.status == SourceStatus.DISABLED) return@update cur
        val flapping = cur.status == SourceStatus.AVAILABLE && cur.recoveredAt > 0L && now - cur.recoveredAt < FLAP_WINDOW_MS
        val n = when {
            flapping -> cur.failuresBeforeRecovery + 1
            cur.status == SourceStatus.AVAILABLE || cur.status == SourceStatus.UNKNOWN -> 1
            else -> cur.failures + 1
        }.coerceIn(1, MAX_FAILURES)
        cur.copy(
            status = f.status,
            reason = f.reason,
            changedAt = if (cur.status == f.status && cur.reason == f.reason) cur.changedAt else now,
            verifiedAt = now,
            failures = n,
            retryAt = if (f.retryAtMs > 0L) f.retryAtMs else now + cooldown(f.status, n),
            lastFailureAt = now,
            lastFailureReason = f.reason,
        )
    }

    private fun smooth(old: Long, new: Long): Long = when {
        new <= 0L -> old
        old <= 0L -> new
        else -> (old * 3 + new) / 4
    }

    /**
     * Evidence that was ALREADY known (a key that rests, saved after a real answer): the same state again changes nothing, so
     * reading it over and over does not count as new failures.
     */
    fun observe(mode: StudyMode, f: SourceFailure, now: Long = System.currentTimeMillis()) {
        val cur = state(mode)
        if (cur.status == f.status && cur.reason == f.reason) return
        failure(mode, f, now)
    }

    /**
     * A fact read from the phone itself. [f] null = nothing wrong: a state that came from an earlier local fact is cleared (back
     * to UNKNOWN = "not verified again yet", so one re-check is allowed); real evidence states are never cleared by it.
     */
    fun applyLocal(mode: StudyMode, f: SourceFailure?, now: Long = System.currentTimeMillis()) = update(mode) { cur ->
        if (f == null) {
            if (cur.reason.local) {
                epoch.incrementAndGet() // the phone fact that blocked this source is gone (online again, switched on again ...)
                cur.copy(
                    status = SourceStatus.UNKNOWN, reason = SourceReason.NONE, changedAt = now, verifiedAt = now,
                    failures = 0, retryAt = 0L,
                )
            } else cur
        } else if (!canOverride(cur, f)) {
            cur
        } else if (cur.status == f.status && cur.reason == f.reason) {
            cur.copy(verifiedAt = now)
        } else {
            // Blocked by a local fact: no network re-check until the fact itself is gone.
            cur.copy(
                status = f.status, reason = f.reason, changedAt = now, verifiedAt = now, failures = 0, retryAt = Long.MAX_VALUE,
                lastFailureAt = now, lastFailureReason = f.reason,
            )
        }
    }

    private fun canOverride(cur: SourceState, f: SourceFailure): Boolean = when {
        f.status == SourceStatus.DISABLED -> true
        cur.status == SourceStatus.DISABLED -> false
        // "No internet" never hides a limit / key problem that was really verified (that state still holds when the phone is back online).
        f.reason == SourceReason.NO_INTERNET && (cur.status == SourceStatus.QUOTA_EXHAUSTED || cur.status == SourceStatus.AUTH_ERROR) -> false
        else -> true
    }

    /**
     * Is a network re-check allowed for [mode] now? Never for a working source, never for a switched-off one, never while a
     * local fact blocks it, never before its cool-down ended, and not twice in a short time. A source that was never used
     * (UNKNOWN from the start) is not probed: its first real use verifies it for free.
     */
    fun due(mode: StudyMode, now: Long = System.currentTimeMillis()): Boolean {
        val s = state(mode)
        return when (s.status) {
            SourceStatus.AVAILABLE, SourceStatus.DISABLED -> false
            SourceStatus.UNKNOWN -> s.changedAt > 0L && now >= s.retryAt && now - s.checkedAt >= MIN_CHECK_GAP_MS
            else -> now >= s.retryAt && now - s.checkedAt >= MIN_CHECK_GAP_MS
        }
    }

    /**
     * The phone has a network again (Part 4/4). Failures that were only about reaching the network (no connection, unreachable,
     * timeout) end their cool-down NOW and start counting from one again, so the next re-check / request may use the source at
     * once. A used-up daily limit, a refused key, a missing app or a switch-off are facts about the source, not about the network:
     * they stay exactly as they were. Nothing is requested here; it only makes sources due.
     */
    fun networkRestored(now: Long = System.currentTimeMillis()) {
        for (mode in StudyMode.values()) {
            update(mode) { cur ->
                val networkOnly = cur.status == SourceStatus.NETWORK_ERROR ||
                    (cur.status == SourceStatus.TEMPORARILY_FAILED && (cur.reason == SourceReason.TIMEOUT || cur.reason == SourceReason.UNREACHABLE))
                if (networkOnly && cur.retryAt != Long.MAX_VALUE) {
                    cur.copy(retryAt = 0L, failures = 0)
                } else cur
            }
        }
        epoch.incrementAndGet() // an old "this request just failed" memory was made when there was no network
    }

    /** Health snapshot of one source: what was last seen, no request is made. */
    fun health(mode: StudyMode, now: Long = System.currentTimeMillis()): SourceHealth {
        val s = state(mode)
        val blocked = s.status == SourceStatus.DISABLED || s.retryAt == Long.MAX_VALUE ||
            (s.status == SourceStatus.UNAVAILABLE && s.reason.local)
        val recovery = when {
            s.status == SourceStatus.AVAILABLE ->
                if (s.recoveredAt > 0L && now - s.recoveredAt < RECOVERED_SHOWN_MS) RecoveryStatus.RECOVERED else RecoveryStatus.HEALTHY
            s.status == SourceStatus.UNKNOWN -> RecoveryStatus.HEALTHY
            blocked -> RecoveryStatus.BLOCKED_BY_PHONE
            now >= s.retryAt -> RecoveryStatus.RETRY_DUE
            else -> RecoveryStatus.WAITING
        }
        val wait = if (recovery == RecoveryStatus.WAITING) (s.retryAt - now).coerceAtLeast(0L) else 0L
        return SourceHealth(
            mode, s.status, s.available, s.lastSuccessAt, s.lastFailureAt, s.lastFailureReason, s.responseMs,
            if (s.available || s.status == SourceStatus.UNKNOWN) 0 else s.failures, recovery, wait,
        )
    }

    fun healthAll(now: Long = System.currentTimeMillis()): List<SourceHealth> = StudyMode.values().map { health(it, now) }

    /** Evidence that cancels exactly one earlier finding (a WebView that failed to start has now started): back to "not verified". */
    fun clearReason(mode: StudyMode, reason: SourceReason, now: Long = System.currentTimeMillis()) = update(mode) { cur ->
        if (cur.reason == reason) {
            epoch.incrementAndGet()
            cur.copy(status = SourceStatus.UNKNOWN, reason = SourceReason.NONE, changedAt = now, verifiedAt = now, failures = 0, retryAt = 0L)
        } else cur
    }

    /** A re-check starts now (so [due] says no to a second one for a moment). */
    fun markChecked(mode: StudyMode, now: Long = System.currentTimeMillis()) = update(mode) { it.copy(checkedAt = now) }

    /** Tests only. */
    fun reset() {
        synchronized(lock) {
            flow.value = mapOf(StudyMode.API to SourceState(), StudyMode.PAGE to SourceState(), StudyMode.WEB to SourceState())
        }
    }

    companion object {
        const val MIN_CHECK_GAP_MS = 10_000L

        /** A source that fails again within this time after it came back keeps its failure count (no flip-flopping). */
        const val FLAP_WINDOW_MS = 2L * 60_000L

        /** How long a source is reported as "just recovered". */
        const val RECOVERED_SHOWN_MS = 60_000L
        private const val MAX_FAILURES = 10
        private const val BASE_COOLDOWN_MS = 30_000L
        private const val MAX_COOLDOWN_MS = 10L * 60_000L

        /** How long to wait before re-checking after the [n]th failure in a row (30 s, 1 min, 2 min ... at most 10 min). */
        fun cooldown(status: SourceStatus, n: Int): Long = when (status) {
            SourceStatus.TEMPORARILY_FAILED, SourceStatus.NETWORK_ERROR ->
                minOf(BASE_COOLDOWN_MS shl (n - 1).coerceIn(0, 10), MAX_COOLDOWN_MS)
            SourceStatus.AUTH_ERROR -> 15L * 60_000L
            SourceStatus.QUOTA_EXHAUSTED -> 60L * 60_000L
            else -> 10L * 60_000L
        }
    }
}

/** The one tracker of the app (like [StudyMonitor]). */
object StudySources {
    val tracker = SourceTracker()
}
