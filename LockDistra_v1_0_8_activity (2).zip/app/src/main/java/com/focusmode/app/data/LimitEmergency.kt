package com.focusmode.app.data

/**
 * Emergency access for a daily limit (an app limit, or a Shorts / Reels / Status limit): a few
 * minutes of extra use, a few times a day. It is set together with the limit itself, and it is
 * offered on the block screen when the limit is reached.
 *
 * [key] is the app's package for an app limit and the [ShortForm.id] for a Shorts / Reels / Status
 * limit. Free of Android classes so the rules can be unit tested.
 */
data class LimitEmergency(
    val enabled: Boolean = LimitEmergencyRules.DEFAULT_ENABLED,
    /** How many times a day Emergency access may be used for this limit. */
    val attempts: Int = LimitEmergencyRules.DEFAULT_ATTEMPTS,
    /** How long one use lasts. */
    val minutes: Int = LimitEmergencyRules.DEFAULT_MINUTES,
    /** Attempts already used today. */
    val used: Int = 0,
    /** Wall-clock time (ms) when the running emergency window ends; 0 or in the past = none running. */
    val activeUntil: Long = 0L,
) {
    val remaining: Int get() = if (enabled) (attempts - used).coerceAtLeast(0) else 0
    val available: Boolean get() = remaining > 0
    fun leftMs(now: Long): Long = if (activeUntil > now) activeUntil - now else 0L
    fun isActive(now: Long): Boolean = leftMs(now) > 0L
}

/** What the person chose in the limit editor. */
data class EmergencyDraft(val enabled: Boolean, val attempts: Int, val minutes: Int)

object LimitEmergencyRules {
    const val MAX_ATTEMPTS = 5
    const val MAX_MINUTES = 5
    const val DEFAULT_ENABLED = true
    const val DEFAULT_ATTEMPTS = 2
    const val DEFAULT_MINUTES = 2

    fun clampAttempts(n: Int) = n.coerceIn(1, MAX_ATTEMPTS)
    fun clampMinutes(n: Int) = n.coerceIn(1, MAX_MINUTES)

    /**
     * Uses one attempt and opens the window. Returns null when it is off, no attempts are left, or a
     * window is already running. An attempt is never given back, even if the app is closed early.
     */
    fun start(e: LimitEmergency, now: Long): LimitEmergency? {
        if (!e.available || e.isActive(now)) return null
        return e.copy(used = e.used + 1, activeUntil = now + clampMinutes(e.minutes) * 60_000L)
    }
}
