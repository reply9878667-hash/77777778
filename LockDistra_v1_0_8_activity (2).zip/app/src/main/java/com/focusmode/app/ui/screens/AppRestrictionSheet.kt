package com.focusmode.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.AppLimit
import com.focusmode.app.data.EMERGENCY_DEFAULT_LIMIT
import com.focusmode.app.data.EMERGENCY_MAX_LIMIT
import com.focusmode.app.data.EmergencyApp
import com.focusmode.app.data.WebsiteRule
import com.focusmode.app.data.WebsiteRules
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.formatMinutes
import com.focusmode.app.ui.theme.FocusTheme

/**
 * The slide-up panel for one app. It opens when an app is tapped or switched on in Apps and holds
 * everything about that app in one place: complete blocking, the daily usage limit, the app's own
 * Shorts switch (YouTube) and Emergency access. It can be dragged to full height.
 *
 * Emergency here is the existing per-app Emergency access (which apps may be opened for a few
 * minutes during a focus session, and how many times). Emergency for a usage limit lives in the
 * limit editor that "Usage limit" opens.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRestrictionSheet(
    app: AppInfo,
    blocked: Boolean,
    limit: AppLimit?,
    emergency: EmergencyApp?,
    /** App restriction changes are locked right now (session option or Prevent changes). */
    frozen: Boolean,
    /** A focus session is running: an app already blocked can't be unblocked, limits only tighten. */
    running: Boolean,
    /** YouTube only: the Shorts switch (null for every other app). */
    shortsChecked: Boolean?,
    shortsEnabled: Boolean,
    /** Website blocking for this app (shown only for apps that have a website). */
    websiteOffered: Boolean,
    websiteOn: Boolean,
    websiteRules: List<WebsiteRule>,
    canTighten: Boolean,
    canLoosen: Boolean,
    onWebsiteBlocking: (Boolean) -> Unit,
    onAddWebsite: (raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onEditWebsite: (old: String, raw: String, subdomains: Boolean) -> WebsiteRules.Result,
    onRemoveWebsite: (String) -> Unit,
    onWebsiteEnabled: (domain: String, on: Boolean) -> Unit,
    onBlockedChange: (Boolean) -> Unit,
    onShortsChange: (Boolean) -> Unit,
    onEditLimit: () -> Unit,
    onEmergencyEnabled: (Boolean) -> Unit,
    onEmergencyAttempts: (Int) -> Unit,
    onDismiss: () -> Unit,
    /** False inside a Focus Profile: per-app Emergency access is a phone-wide setting. */
    showEmergency: Boolean = true,
) {
    val c = FocusTheme.colors
    val emergencyOn = emergency?.enabled == true
    val attempts = emergency?.limit ?: EMERGENCY_DEFAULT_LIMIT
    // Same rules as the Emergency settings always had: while a session runs an app can be
    // switched off but not on, and the number of uses can only go down.
    val emergencyLocked = running && frozen

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppIcon(app.packageName, 56.dp)
            Spacer(Modifier.height(10.dp))
            Text(app.label, style = MaterialTheme.typography.titleLarge)
            Text("Restrictions", style = MaterialTheme.typography.bodySmall, color = c.muted)
            Spacer(Modifier.height(18.dp))

            if (frozen) {
                Text(
                    "App restrictions are locked right now. Unlock changes, or wait for the session to end, to edit them.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SheetBlock {
                    SwitchLine(
                        title = "Complete ${app.label} blocking",
                        note = if (blocked) "Blocked during every focus session" else "Allowed",
                        checked = blocked,
                        enabled = !frozen && !(running && blocked),
                        onChange = onBlockedChange
                    )
                }

                SheetBlock {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${app.label} usage limit", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (limit == null) "No daily limit"
                                else "${formatMinutes(limit.limitMin)} a day",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (limit == null) c.muted else c.accent
                            )
                        }
                        TextButton(onClick = onEditLimit, enabled = !frozen) {
                            Text(if (limit == null) "Set limit" else "Edit", color = if (frozen) c.muted else c.accent)
                        }
                    }
                }

                if (shortsChecked != null) {
                    SheetBlock {
                        SwitchLine(
                            title = "${app.label} Shorts blocking",
                            note = if (blocked) "Included while ${app.label} is blocked"
                            else "Keep ${app.label}, block only the Shorts player",
                            checked = shortsChecked || blocked,
                            enabled = shortsEnabled && !blocked,
                            onChange = onShortsChange
                        )
                    }
                }

                if (websiteOffered) {
                    SheetBlock {
                        WebsiteBlockingBlock(
                            appLabel = app.label,
                            on = websiteOn,
                            rules = websiteRules,
                            canTighten = canTighten,
                            canLoosen = canLoosen,
                            onOnChange = onWebsiteBlocking,
                            onAdd = onAddWebsite,
                            onEdit = onEditWebsite,
                            onRemove = onRemoveWebsite,
                            onRuleEnabled = onWebsiteEnabled,
                        )
                    }
                }

                if (showEmergency) SheetBlock {
                    SwitchLine(
                        title = "Emergency access",
                        note = if (emergencyOn) "Can be opened for a few minutes in a real emergency"
                        else "Off: this app stays closed for the whole session",
                        checked = emergencyOn,
                        enabled = !emergencyLocked && !(running && !emergencyOn),
                        onChange = onEmergencyEnabled
                    )
                    if (emergencyOn) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Emergency uses", style = MaterialTheme.typography.labelMedium, color = c.muted)
                                Text(
                                    "How many times it can be opened",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = c.muted
                                )
                            }
                            CircleIconButton(
                                Icons.Rounded.Remove, "Fewer",
                                onClick = { if (!emergencyLocked && attempts > 1) onEmergencyAttempts(attempts - 1) }
                            )
                            Text(
                                "$attempts",
                                style = MaterialTheme.typography.titleLarge,
                                color = c.text,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 14.dp)
                            )
                            CircleIconButton(
                                Icons.Rounded.Add, "More",
                                onClick = {
                                    if (!running && !emergencyLocked && attempts < EMERGENCY_MAX_LIMIT) {
                                        onEmergencyAttempts(attempts + 1)
                                    }
                                }
                            )
                        }
                        if (running) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "A session is running: uses can only be lowered until it ends.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.warning
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            TextButton(onClick = onDismiss) { Text("Done", color = c.accent) }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
internal fun SheetBlock(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(FocusTheme.colors.card)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) { content() }
}

@Composable
internal fun SwitchLine(
    title: String,
    note: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    val c = FocusTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(note, style = MaterialTheme.typography.bodySmall, color = c.muted)
        }
        Spacer(Modifier.size(12.dp))
        FocusSwitch(checked = checked, enabled = enabled, onCheckedChange = onChange)
    }
}
