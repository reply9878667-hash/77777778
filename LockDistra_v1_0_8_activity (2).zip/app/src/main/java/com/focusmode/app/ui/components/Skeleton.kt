package com.focusmode.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.focusmode.app.ui.theme.FocusTheme

// ---- YouTube-style skeleton loading + search spinner ----------------------------------------
//
// Skeleton: grey placeholder shapes (video picture, channel logo, title lines) with a light band sliding from LEFT to
// RIGHT over all of them in step, like YouTube's loading state. The shapes copy the real card layout, so when the real
// content appears nothing jumps.
// Search: a centred circular spinner with a short "Searching" label.

/** Time of one left-to-right sweep. */
private const val SHIMMER_SWEEP_MS = 1300

/** One shared 0..1 sweep position; give the SAME state to every placeholder of a list so they shine in step. */
@Composable
fun rememberShimmerShift(): State<Float> {
    val transition = rememberInfiniteTransition(label = "ytShimmer")
    return transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(SHIMMER_SWEEP_MS, easing = LinearEasing)),
        label = "ytShimmerShift"
    )
}

/**
 * Fills this element with the placeholder grey and a light band travelling left to right. The band is positioned on the
 * whole screen width (not on each shape), so a wide picture and a thin text line are lit by the same moving band.
 * Only the draw step reads the animation, so nothing is recomposed while it runs.
 */
fun Modifier.shimmerFill(shift: State<Float>, shape: Shape = RoundedCornerShape(6.dp)): Modifier = composed {
    val c = FocusTheme.colors
    val base = c.cardHigh
    val highlight = lerp(base, Color.White, if (c.isDark) 0.14f else 0.6f)
    val screenW = with(LocalDensity.current) { LocalConfiguration.current.screenWidthDp.dp.toPx() }
    var left by remember { mutableFloatStateOf(0f) }
    this
        .clip(shape)
        .onGloballyPositioned { left = it.positionInWindow().x }
        .drawBehind {
            val band = screenW * 0.55f
            val x = -band + (screenW + band) * shift.value - left
            drawRect(Brush.horizontalGradient(listOf(base, highlight, base), startX = x, endX = x + band))
        }
}

/** A shimmering fill for a picture that is still being downloaded (own animation; sized by the caller). */
@Composable
fun ShimmerFill(modifier: Modifier = Modifier, shape: Shape = RectangleShape) {
    Box(modifier.shimmerFill(rememberShimmerShift(), shape))
}

/** A normal video card as a placeholder: 16:9 picture, channel logo, two title lines. Same layout as the real card. */
@Composable
fun VideoSkeletonItem(shift: State<Float>) {
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).shimmerFill(shift, RectangleShape))
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 16.dp),
            verticalAlignment = Alignment.Top
        ) {
            Box(Modifier.size(38.dp).shimmerFill(shift, CircleShape))
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Box(Modifier.fillMaxWidth(0.92f).height(14.dp).shimmerFill(shift))
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth(0.58f).height(12.dp).shimmerFill(shift))
            }
        }
    }
}

/** A Short card as a placeholder: tall picture and two lines. */
@Composable
fun ShortSkeletonItem(shift: State<Float>) {
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().aspectRatio(9f / 16f).shimmerFill(shift, RoundedCornerShape(18.dp)))
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(0.9f).height(12.dp).shimmerFill(shift))
        Spacer(Modifier.height(6.dp))
        Box(Modifier.fillMaxWidth(0.5f).height(10.dp).shimmerFill(shift))
    }
}

/** The list placeholder for videos (fills the space, does not scroll). */
@Composable
fun VideoSkeletonList(modifier: Modifier = Modifier, count: Int = 4) {
    val shift = rememberShimmerShift()
    LazyColumn(
        modifier = modifier.fillMaxSize().semantics { contentDescription = "Loading videos" },
        userScrollEnabled = false,
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        items(count) { VideoSkeletonItem(shift) }
    }
}

/** The grid placeholder for Shorts (fills the space, does not scroll). */
@Composable
fun ShortSkeletonGrid(modifier: Modifier = Modifier, count: Int = 6) {
    val shift = rememberShimmerShift()
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier.fillMaxSize().semantics { contentDescription = "Loading Shorts" },
        userScrollEnabled = false,
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        gridItems((0 until count).toList()) { ShortSkeletonItem(shift) }
    }
}

/** A single placeholder text line (for example the channel numbers that arrive a moment after the page opens). */
@Composable
fun SkeletonLine(widthFraction: Float, height: androidx.compose.ui.unit.Dp = 12.dp, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth(widthFraction).height(height).shimmerFill(rememberShimmerShift()))
}

/**
 * What a search shows while it runs: a smooth circular spinner in the middle of the results area. It leaves by itself
 * when the screen switches to the results (or to the error message).
 */
@Composable
fun SearchLoading(query: String, modifier: Modifier = Modifier) {
    val c = FocusTheme.colors
    Column(
        modifier.fillMaxSize().padding(horizontal = 32.dp).semantics { contentDescription = "Searching" },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(46.dp),
            color = c.accent,
            trackColor = c.accentSoft,
            strokeWidth = 4.dp
        )
        Spacer(Modifier.height(18.dp))
        Text("Searching", style = MaterialTheme.typography.titleSmall, color = c.text, textAlign = TextAlign.Center)
        if (query.isNotBlank()) {
            Spacer(Modifier.height(2.dp))
            Text(
                query, style = MaterialTheme.typography.bodySmall, color = c.muted,
                maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
            )
        }
    }
}
