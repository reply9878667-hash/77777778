package com.focusmode.app.ui

import java.util.Locale

/** 83_000 -> "1:23", 3_723_000 -> "1:02:03". */
fun formatClock(ms: Long): String {
    val total = (ms.coerceAtLeast(0L) + 999L) / 1000L
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

/** 85 -> "1 h 25 min", 45 -> "45 min". */
fun formatMinutes(min: Int): String {
    val h = min / 60
    val m = min % 60
    return when {
        h == 0 -> "$m min"
        m == 0 -> "$h h"
        else -> "$h h $m min"
    }
}

fun plantStage(growth: Int): String = when {
    growth < 4 -> "Seed"
    growth < 12 -> "Sprout"
    growth < 22 -> "Sapling"
    growth < 34 -> "Young tree"
    growth < 40 -> "Growing tree"
    else -> "In full bloom"
}
