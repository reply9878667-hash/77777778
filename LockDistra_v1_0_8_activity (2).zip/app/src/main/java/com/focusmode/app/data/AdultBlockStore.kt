package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** One public list the bundled / downloaded domains were compiled from. Shown in the app as attribution. */
data class AdultSource(
    val name: String,
    val homepage: String,
    val license: String,
    val retrieved: String,
    val entries: Int,
)

/** What the person sees about the list in use. */
data class AdultState(
    val enabled: Boolean = false,
    val autoUpdate: Boolean = true,
    /** Monotonic list version (yyyymmdd of the build, or a number); 0 = nothing installed yet. */
    val version: Long = 0,
    val count: Int = 0,
    val builtAt: String = "",
    /** "bundled" or "downloaded". */
    val origin: String = "",
    val sources: List<AdultSource> = emptyList(),
    val lastCheckAt: Long = 0,
    val lastUpdateAt: Long = 0,
    /** Plain-language result of the last update attempt ("" = none yet). */
    val lastMessage: String = "",
    /** The person's own blocked links and words. */
    val custom: List<CustomEntry> = emptyList(),
)

/**
 * Adult-website protection: the on/off switch, the local domain database and its updates.
 *
 * The database is a sorted domain file ([SortedDomainIndex]) in device-protected storage, so it is
 * readable straight after a restart, offline, and without any network. It is first copied from the
 * app's bundled asset (`assets/adult_blocklist/`). An update only ever replaces it after it has been
 * fully downloaded, hash-checked, format-checked and size-checked ([AdultListUpdater]); a failed or
 * partial update leaves the working list untouched.
 *
 * Switching protection ON / OFF follows the same lock rules as the other restrictions
 * ([ContentPolicy.canSetFeature]): while a session runs or settings are locked it can be tightened
 * but not loosened.
 */
class AdultBlockStore private constructor(private val context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "adult_blocking")
    private val dir: File = adultDir(context)
    private val listFile = File(dir, LIST_NAME)

    private val lock = Any()
    @Volatile private var index = SortedDomainIndex(listFile)

    private val cache = object : LinkedHashMap<String, Boolean>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?) = size > 96
    }

    private val _state = MutableStateFlow(read())
    val state: StateFlow<AdultState> = _state.asStateFlow()

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> _state.value = read() }

    init {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun current(): AdultState = read()

    private fun focus(): FocusState = FocusStore.get(context).current()

    private fun read(): AdultState {
        val sources = ListCodec.decode(prefs.getString(K_SOURCES, null)).mapNotNull { raw ->
            val p = raw.split('\u001E')
            if (p.size != 5) null else AdultSource(p[0], p[1], p[2], p[3], p[4].toIntOrNull() ?: 0)
        }
        return AdultState(
            enabled = prefs.getBoolean(K_ON, false),
            autoUpdate = prefs.getBoolean(K_AUTO, true),
            version = prefs.getLong(K_VERSION, 0),
            count = prefs.getInt(K_COUNT, 0),
            builtAt = prefs.getString(K_BUILT, "").orEmpty(),
            origin = prefs.getString(K_ORIGIN, "").orEmpty(),
            sources = sources,
            lastCheckAt = prefs.getLong(K_CHECK_AT, 0),
            lastUpdateAt = prefs.getLong(K_UPDATE_AT, 0),
            lastMessage = prefs.getString(K_MSG, "").orEmpty(),
            custom = AdultCustom.decode(prefs.getString(K_CUSTOM, null)),
        )
    }

    // ---- Switch -------------------------------------------------------------------------------

    /** Turns Adult Content Blocking on or off. False when a session / lock does not allow that change right now. */
    @Synchronized
    fun setEnabled(on: Boolean): Boolean {
        val cur = prefs.getBoolean(K_ON, false)
        if (!ContentPolicy.canSetFeature(focus(), cur, on)) return false
        prefs.edit().putBoolean(K_ON, on).commit()
        // The database is installed off the main thread (app start, accessibility service, the card's switch).
        return true
    }

    fun canTighten() = ContentPolicy.canSetFeature(focus(), false, true)
    fun canLoosen() = ContentPolicy.canSetFeature(focus(), true, false)

    /** Automatic update checking is a convenience, not a restriction: no lock applies. */
    fun setAutoUpdate(on: Boolean) {
        prefs.edit().putBoolean(K_AUTO, on).apply()
    }

    // ---- Matching -----------------------------------------------------------------------------

    /**
     * True when protection is on and [rawHost] is an adult website in the local database. Works fully
     * offline. Cheap enough to call from the accessibility event path (a disk binary search, cached).
     */
    fun blocks(rawHost: String): Boolean {
        val host = WebsiteRules.normalize(rawHost) ?: return false
        synchronized(cache) { cache[host]?.let { return it } }
        // The person's own links count whether or not the built-in list switch is on.
        var hit = AdultCustom.domainHit(host, customDomains())
        if (!hit && prefs.getBoolean(K_ON, false)) {
            hit = try {
                AdultBlocklist.matches(host, index)
            } catch (_: Exception) {
                false
            }
        }
        synchronized(cache) { cache[host] = hit }
        return hit
    }

    /**
     * For the DNS filter: [name] is blocked by the list, by the adult-looking name rules, by one of the person's own
     * links, or contains one of the person's own words.
     */
    fun dnsBlocks(name: String): Boolean {
        if (blocks(name)) return true
        val words = customKeywords()
        return words.isNotEmpty() && AdultCustom.keywordHit(name, words) != null
    }

    /** The person's own word found in [addressBarText], or null. Works with the whole address bar text, not only the host. */
    fun blockedWord(addressBarText: String): String? =
        AdultCustom.keywordHit(addressBarText, customKeywords())

    private fun customEntries(): List<CustomEntry> = AdultCustom.decode(prefs.getString(K_CUSTOM, null))
    private fun customDomains(): List<String> = customEntries().filter { it.kind == CustomKind.DOMAIN }.map { it.value }
    private fun customKeywords(): List<String> = customEntries().filter { it.kind == CustomKind.KEYWORD }.map { it.value }

    /** The built-in list switch. */
    fun isOn(): Boolean = prefs.getBoolean(K_ON, false)

    /** Something is being blocked: the built-in list is on, or the person added their own links / words. */
    fun isActive(): Boolean = isOn() || prefs.getString(K_CUSTOM, null).orEmpty().isNotEmpty()

    // ---- The person's own links and words -----------------------------------------------------

    /**
     * Adds what was typed or pasted: a link / website becomes a blocked site, anything else a blocked word.
     * Adding tightens, so it follows the same lock as switching protection on.
     */
    @Synchronized
    fun addCustom(raw: String): AdultCustom.Result {
        val entry = AdultCustom.parse(raw) ?: return AdultCustom.Result.INVALID
        if (AdultCustom.isAccidentalBigSite(raw, entry)) return AdultCustom.Result.TOO_COMMON
        if (!canTighten()) return AdultCustom.Result.LOCKED
        val list = customEntries()
        if (list.any { it == entry }) return AdultCustom.Result.ALREADY_THERE
        if (list.size >= AdultCustom.MAX) return AdultCustom.Result.FULL
        prefs.edit().putString(K_CUSTOM, AdultCustom.encode(list + entry)).commit()
        synchronized(cache) { cache.clear() }
        return AdultCustom.Result.OK
    }

    /** Removing loosens, so a running session or lock refuses it. */
    @Synchronized
    fun removeCustom(entry: CustomEntry): Boolean {
        if (!canLoosen()) return false
        prefs.edit().putString(K_CUSTOM, AdultCustom.encode(customEntries().filterNot { it == entry })).commit()
        synchronized(cache) { cache.clear() }
        return true
    }

    // ---- Installing the bundled list ----------------------------------------------------------

    /**
     * Makes sure a valid local database exists. Copies the bundled asset when nothing is installed,
     * when the installed file fails verification, or when the app brought a newer bundled version.
     * Safe to call repeatedly and from any thread.
     */
    fun ensureInstalled(): Boolean = synchronized(lock) {
        val s = read()
        val bundled = try { readBundledManifest() } catch (_: Exception) { null }
        val installedOk = listFile.isFile && listFile.length() > 0 && s.count > 0
        // Also re-seed when the app brings a bigger bundled list with the same version (a rebuilt list on the same day),
        // but never over a list that was downloaded.
        val needsSeed = !installedOk || (bundled != null && (bundled.version > s.version ||
            (bundled.version == s.version && bundled.count > s.count && s.origin != ORIGIN_DOWNLOADED)))
        if (!needsSeed) return@synchronized true
        if (bundled == null) return@synchronized installedOk
        try {
            dir.mkdirs()
            val tmp = File(dir, "$LIST_NAME.seed")
            context.assets.open("$ASSET_DIR/$LIST_NAME").use { input ->
                FileOutputStream(tmp).use { out -> input.copyTo(out); out.fd.sync() }
            }
            val n = AdultBlocklist.verifyFile(tmp)
            if (n != bundled.count) throw IllegalStateException("bundled count mismatch $n != ${bundled.count}")
            swapIn(tmp)
            saveInstalled(bundled, ORIGIN_BUNDLED, "Using the list that came with the app.")
            true
        } catch (e: Exception) {
            prefs.edit().putString(K_MSG, "Could not install the built-in list: ${e.message}").apply()
            false
        }
    }

    internal data class Manifest(
        val version: Long,
        val count: Int,
        val builtAt: String,
        val sha256: String,
        val listUrl: String,
        val sources: List<AdultSource>,
    )

    private fun readBundledManifest(): Manifest =
        parseManifest(context.assets.open("$ASSET_DIR/manifest.json").bufferedReader().use { it.readText() })

    // ---- Used by the updater ------------------------------------------------------------------

    internal fun installedCount(): Int = if (listFile.isFile) read().count else 0
    internal fun installedVersion(): Long = read().version
    internal fun stagingFile(): File = File(dir.also { it.mkdirs() }, "$LIST_NAME.next")

    internal fun noteCheck(message: String) {
        prefs.edit().putLong(K_CHECK_AT, System.currentTimeMillis()).putString(K_MSG, message).apply()
    }

    /** Atomically replaces the live database with the verified [staged] file and records its details. */
    internal fun installDownloaded(staged: File, manifest: Manifest): Unit = synchronized(lock) {
        swapIn(staged)
        saveInstalled(manifest, ORIGIN_DOWNLOADED, "Updated to list version ${manifest.version}.")
        prefs.edit().putLong(K_UPDATE_AT, System.currentTimeMillis()).apply()
    }

    private fun swapIn(staged: File) {
        index.close()
        try {
            Files.move(staged.toPath(), listFile.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } catch (_: AtomicMoveNotSupportedException) {
            Files.move(staged.toPath(), listFile.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
        index = SortedDomainIndex(listFile)
        synchronized(cache) { cache.clear() }
    }

    private fun saveInstalled(m: Manifest, origin: String, message: String) {
        val encoded = ListCodec.encode(m.sources.map {
            listOf(it.name, it.homepage, it.license, it.retrieved, it.entries.toString()).joinToString("\u001E")
        })
        prefs.edit()
            .putLong(K_VERSION, m.version)
            .putInt(K_COUNT, m.count)
            .putString(K_BUILT, m.builtAt)
            .putString(K_ORIGIN, origin)
            .putString(K_SOURCES, encoded)
            .putLong(K_CHECK_AT, System.currentTimeMillis())
            .putString(K_MSG, message)
            .commit()
    }

    companion object {
        const val ASSET_DIR = "adult_blocklist"
        const val LIST_NAME = "adult_domains.txt"
        const val ORIGIN_BUNDLED = "bundled"
        const val ORIGIN_DOWNLOADED = "downloaded"

        private const val K_ON = "enabled"
        private const val K_AUTO = "auto_update"
        private const val K_VERSION = "version"
        private const val K_COUNT = "count"
        private const val K_BUILT = "built_at"
        private const val K_ORIGIN = "origin"
        private const val K_SOURCES = "sources"
        private const val K_CHECK_AT = "last_check_at"
        private const val K_UPDATE_AT = "last_update_at"
        private const val K_MSG = "last_message"
        private const val K_CUSTOM = "custom_entries"

        /** Device-protected app storage, so the list is there right after a restart, before unlock. */
        fun adultDir(context: Context): File {
            val app = context.applicationContext
            val base = if (android.os.Build.VERSION.SDK_INT >= 24) app.createDeviceProtectedStorageContext() else app
            return File(base.filesDir, "adult_blocklist")
        }

        internal fun parseManifest(json: String): Manifest {
            val o = JSONObject(json)
            val srcs = ArrayList<AdultSource>()
            val arr = o.optJSONArray("sources")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONObject(i)
                    srcs.add(
                        AdultSource(
                            name = s.getString("name"),
                            homepage = s.optString("homepage"),
                            license = s.optString("license"),
                            retrieved = s.optString("retrieved"),
                            entries = s.optInt("entries", 0),
                        )
                    )
                }
            }
            return Manifest(
                version = o.getLong("version"),
                count = o.getInt("count"),
                builtAt = o.optString("built_at"),
                sha256 = o.optString("sha256").lowercase(),
                listUrl = o.optString("list_url"),
                sources = srcs,
            )
        }

        @Volatile
        private var instance: AdultBlockStore? = null

        fun get(context: Context): AdultBlockStore =
            instance ?: synchronized(this) {
                instance ?: AdultBlockStore(context.applicationContext).also { instance = it }
            }
    }
}
