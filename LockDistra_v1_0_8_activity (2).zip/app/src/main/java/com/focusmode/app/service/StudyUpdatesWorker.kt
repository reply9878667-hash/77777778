package com.focusmode.app.service

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.NetworkType
import androidx.work.Constraints
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.focusmode.app.data.ChannelAlerts
import com.focusmode.app.data.StudyApi
import com.focusmode.app.data.StudyErrorKind
import com.focusmode.app.data.StudyException
import com.focusmode.app.data.StudyRules
import com.focusmode.app.data.StudyStore
import com.focusmode.app.data.StudyUpdates
import com.focusmode.app.data.StudyVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Every few hours: looks at the newest uploads of the channels the person follows (1 unit of the free YouTube limit per
 * channel) and shows a LockDistra notification, with the video's picture, for each new study video.
 * A channel's first look is silent. Nothing here touches Focus Mode or blocking.
 */
class StudyUpdatesWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext
        val store = StudyStore.get(app)
        val now = System.currentTimeMillis()
        if (!store.alertsOn || store.channels.isEmpty()) {
            store.lastCheckAt = now; store.lastCheckNote = "No subscribed channels"
            return@withContext Result.success()
        }
        if (store.apiKey.isEmpty()) {
            store.lastCheckAt = now; store.lastCheckNote = "No YouTube key in this build"
            return@withContext Result.success()
        }

        val api = StudyApi(store)
        val trusted = store.channels.map { it.id }.toSet()
        val seen = store.seenIds.toMutableList()
        val seenSet = seen.toHashSet()
        val announce = ArrayList<StudyVideo>()
        var note = ""

        val subjects = store.selected.ifEmpty { store.subjects }
        // Channels set to "None" are not looked at at all (no notification, no bell entry, no YouTube quota used).
        val watched = store.channels.filter { store.alertMode(it.id) != ChannelAlerts.NONE }
        for (ch in watched.take(StudyUpdates.MAX_CHANNELS)) {
            try {
                val latest = api.uploadIds(ch.id, 6)
                val fresh = StudyUpdates.unseen(latest, seenSet)
                val mode = store.alertMode(ch.id)
                if (!store.isSeeded(ch.id)) {
                    // First look at this channel: old videos stay quiet, but anything uploaded since the Subscribe tap is announced
                    // (before, the whole first look was silent, so a video uploaded before it ran was lost for good).
                    val cutoff = StudyUpdates.firstLookCutoff(store.followedAt(ch.id), now)
                    if (fresh.isNotEmpty()) {
                        announce += api.details(fresh).filter {
                            StudyUpdates.isNewSince(it, cutoff) && StudyRules.accept(it, trusted) && StudyUpdates.wants(mode, it, subjects)
                        }
                    }
                    seen += fresh; seenSet += fresh
                    store.markSeeded(ch.id)
                } else if (fresh.isNotEmpty()) {
                    announce += api.details(fresh)
                        .filter { StudyRules.accept(it, trusted) && StudyUpdates.wants(mode, it, subjects) }
                    seen += fresh; seenSet += fresh
                }
            } catch (e: StudyException) {
                // No key / bad key / daily limit used up: stop now and try again at the next check.
                if (e.kind == StudyErrorKind.QUOTA || e.kind == StudyErrorKind.BAD_KEY || e.kind == StudyErrorKind.NO_KEY) {
                    note = when (e.kind) {
                        StudyErrorKind.QUOTA -> "YouTube's daily limit is used up, will try again later"
                        else -> "YouTube refused the key"
                    }
                    break
                }
                note = "Could not reach YouTube for some channels"
            } catch (e: Exception) {
                // One channel failing must not stop the others.
                note = "Could not reach YouTube for some channels"
            }
        }

        store.seenIds = StudyUpdates.trimSeen(seen)
        // The bell keeps every new video (even when the phone's notification is off or limited to a few).
        announce.reversed().forEach { store.addToInbox(it) }
        StudyUpdates.notifyOrder(announce).forEach { Notifications.postNewStudyVideo(app, it) }
        store.lastCheckAt = System.currentTimeMillis()
        store.lastCheckNote = when {
            note.isNotEmpty() -> note
            announce.isEmpty() -> "No new videos"
            else -> "${announce.size} new video" + if (announce.size == 1) "" else "s"
        }
        Result.success()
    }

    companion object {
        private const val NAME = "study_new_videos"

        /** Safe to call at every app start: the same schedule is kept, never doubled. */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<StudyUpdatesWorker>(StudyUpdates.CHECK_HOURS, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            val wm = WorkManager.getInstance(context.applicationContext)
            // UPDATE (not KEEP): an install of this version replaces the older 4-hour schedule with the new one.
            wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
            // The phone may hold a periodic job back for hours (battery saver, app standby): opening the app after a
            // while without a check runs one at once.
            val last = StudyStore.get(context.applicationContext).lastCheckAt
            if (System.currentTimeMillis() - last > STALE_MS) checkNow(context)
        }

        private const val NOW_NAME = "study_new_videos_now"
        private const val STALE_MS = 60 * 60 * 1000L

        /** One check right now (needs internet). Used when the app opens after a long time and by "Check now". */
        fun checkNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<StudyUpdatesWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(context.applicationContext)
                .enqueueUniqueWork(NOW_NAME, ExistingWorkPolicy.KEEP, request)
        }
    }
}
