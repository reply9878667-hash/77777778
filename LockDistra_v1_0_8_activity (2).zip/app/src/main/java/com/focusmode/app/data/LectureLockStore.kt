package com.focusmode.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The lecture link (any platform) the person chose for the coming (or running) Focus session, or null when they skipped
 * the step. Kept in SharedPreferences so the Accessibility service can read it too (`LectureLockStore.get(context).target`).
 * It is cleared when the session ends or the start is cancelled.
 */
class LectureLockStore private constructor(context: Context) {
    private val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private val _url = MutableStateFlow(prefs.getString(KEY, null))
    val urlFlow: StateFlow<String?> = _url.asStateFlow()

    val url: String? get() = _url.value

    /** The chosen lecture, or null when none is set. */
    val target: LectureTarget? get() = _url.value?.let { LectureLink.parse(it) }

    fun set(url: String?) {
        if (url == null) clear() else {
            prefs.edit().putString(KEY, url).putBoolean(KEY_DONE, false).apply()
            _url.value = url
        }
    }

    fun clear() {
        prefs.edit().remove(KEY_AUTO_END).remove(KEY_DONE).apply()
        if (_url.value == null) return
        prefs.edit().remove(KEY).apply()
        _url.value = null
    }

    /** True when the person chose "turn Focus Mode off by itself when this lecture ends". Belongs to the chosen lecture only. */
    val autoEnd: Boolean get() = _url.value != null && prefs.getBoolean(KEY_AUTO_END, false)

    fun setAutoEnd(on: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_END, on && _url.value != null).apply()
    }

    /** The lecture of this session was watched to its end: from then on the session timer runs normally (no longer tied to the player). */
    val isDone: Boolean get() = _url.value != null && prefs.getBoolean(KEY_DONE, false)

    fun setDone(on: Boolean) {
        prefs.edit().putBoolean(KEY_DONE, on).apply()
    }

    /** Seconds already watched of the lecture [key] (video id or link); 0 = start from the beginning. */
    fun position(key: String): Int = prefs.getInt(POS_PREFIX + key.hashCode(), 0)

    fun savePosition(key: String, seconds: Int) {
        prefs.edit().putInt(POS_PREFIX + key.hashCode(), seconds.coerceAtLeast(0)).apply()
    }

    /** The parts of the lecture [key] that were really watched (see [LectureWatch]); empty = nothing counted yet. */
    fun watched(key: String): java.util.BitSet = LectureWatch.fromHex(prefs.getString(WATCH_PREFIX + key.hashCode(), null))

    fun saveWatched(key: String, watch: LectureWatch) {
        prefs.edit().putString(WATCH_PREFIX + key.hashCode(), watch.toHex()).apply()
    }

    /** The lecture counted as finished: the next time it is chosen it has to be watched again. */
    fun clearWatched(key: String) {
        prefs.edit().remove(WATCH_PREFIX + key.hashCode()).apply()
    }

    /** Shape (width / height) already found for the video [key]; 0 = not known yet. */
    fun ratio(key: String): Float = prefs.getFloat(RATIO_PREFIX + key.hashCode(), 0f)

    fun saveRatio(key: String, ratio: Float) {
        prefs.edit().putFloat(RATIO_PREFIX + key.hashCode(), ratio).apply()
    }

    /** Per-video switches of the player menu ("pip" = background play in a floating window, "rep" = repeat). Off unless turned on. */
    fun option(key: String, name: String): Boolean = prefs.getBoolean("opt_" + name + "_" + key.hashCode(), false)

    fun setOption(key: String, name: String, on: Boolean) {
        prefs.edit().putBoolean("opt_" + name + "_" + key.hashCode(), on).apply()
    }

    companion object {
        private const val RATIO_PREFIX = "ratio_"
        private const val POS_PREFIX = "pos_"
        private const val WATCH_PREFIX = "watched_"
        private const val FILE = "lecture_lock"
        private const val KEY = "lecture_url"
        private const val KEY_AUTO_END = "end_after_lecture"
        private const val KEY_DONE = "lecture_done"

        @Volatile private var instance: LectureLockStore? = null

        fun get(context: Context): LectureLockStore =
            instance ?: synchronized(this) {
                instance ?: LectureLockStore(context.applicationContext).also { instance = it }
            }
    }
}
