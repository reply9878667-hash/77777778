package com.focusmode.app.data

/**
 * Onboarding Part 2A: the seven questions and the answers to them.
 *
 * Plain Kotlin, no Android types, so everything here is unit tested on the JVM
 * (see OnboardingQuestionsTest). The screens only read [OnboardingQuestions.all] and edit an
 * [OnboardingAnswers] value, so a question can be added or reworded here without touching any UI.
 *
 * Answers are kept in memory for the duration of the flow (and survive rotation). Nothing is written
 * to disk and nothing leaves the phone in this part; Part 2B decides what to do with them.
 */

enum class QuestionType { Text, SingleChoice, MultiChoice }

/** [id] is stable (safe to store or send later); [label] is what the person sees. */
data class OnboardingOption(val id: String, val label: String)

data class OnboardingQuestion(
    val id: String,
    val prompt: String,
    val type: QuestionType,
    val options: List<OnboardingOption> = emptyList(),
    /** An optional question lets the person continue without answering. */
    val optional: Boolean = false,
    /** Small line under the question, e.g. "Select all that apply". */
    val hint: String? = null,
)

object OnboardingQuestions {

    // Question ids. Part 2B can use these to read answers from [OnboardingAnswers].
    const val NAME = "name"
    const val GOAL = "goal"
    const val DISTRACTIONS = "distractions"
    const val PHONE_TIME = "phone_time"
    const val SESSION_LENGTH = "session_length"
    const val DAILY_GOAL = "daily_goal"
    const val SOURCE = "source"

    const val NAME_MAX_LENGTH = 30

    /** Not a question: the number of minutes typed when the daily goal answer is [DAILY_GOAL_CUSTOM_OPTION]. */
    const val DAILY_GOAL_CUSTOM_MINUTES = "daily_goal_custom_min"
    const val DAILY_GOAL_CUSTOM_OPTION = "custom"
    const val CUSTOM_GOAL_MIN = 10
    const val CUSTOM_GOAL_MAX = 960

    private fun opt(id: String, label: String) = OnboardingOption(id, label)

    val all: List<OnboardingQuestion> = listOf(
        OnboardingQuestion(
            id = NAME,
            prompt = "What's your name?",
            type = QuestionType.Text,
        ),
        OnboardingQuestion(
            id = GOAL,
            prompt = "What's your main goal?",
            type = QuestionType.SingleChoice,
            options = listOf(
                opt("study_better", "Study better"),
                opt("improve_productivity", "Improve productivity"),
                opt("reduce_phone_addiction", "Reduce phone addiction"),
                opt("focus_on_work", "Focus on work"),
                opt("build_better_habits", "Build better habits"),
                opt("all_of_these", "All of these"),
            ),
        ),
        OnboardingQuestion(
            id = DISTRACTIONS,
            prompt = "What distracts you the most?",
            type = QuestionType.MultiChoice,
            hint = "Select all that apply",
            options = listOf(
                opt("social_media", "Social Media"),
                opt("youtube_shorts", "YouTube and Shorts"),
                opt("gaming", "Gaming"),
                opt("reels_short_videos", "Reels and short videos"),
                opt("messaging_apps", "Messaging applications"),
                opt("other_apps", "Other applications"),
            ),
        ),
        OnboardingQuestion(
            id = PHONE_TIME,
            prompt = "How much time do you spend on your phone daily?",
            type = QuestionType.SingleChoice,
            options = listOf(
                opt("lt_2h", "Less than 2 hours"),
                opt("2_4h", "2\u20134 hours"),
                opt("4_6h", "4\u20136 hours"),
                opt("6_8h", "6\u20138 hours"),
                opt("gt_8h", "More than 8 hours"),
                opt("not_sure", "Not sure"),
            ),
        ),
        OnboardingQuestion(
            id = SESSION_LENGTH,
            prompt = "How long would you like to focus in one session?",
            type = QuestionType.SingleChoice,
            options = listOf(
                opt("min_15", "15 minutes"),
                opt("min_25", "25 minutes"),
                opt("min_30", "30 minutes"),
                opt("min_45", "45 minutes"),
                opt("min_60", "60 minutes"),
                opt("min_90", "90 minutes"),
            ),
        ),
        OnboardingQuestion(
            id = DAILY_GOAL,
            prompt = "What's your daily focus goal?",
            type = QuestionType.SingleChoice,
            options = listOf(
                opt("h_1", "1 hour"),
                opt("h_2", "2 hours"),
                opt("h_3", "3 hours"),
                opt("h_4", "4 hours"),
                opt("h_5_plus", "5+ hours"),
                // Picking this shows a small minutes field under the options (QuestionsScreen); the number is
                // kept next to the choice (DAILY_GOAL_CUSTOM_MINUTES) and saved with the other answers.
                opt(DAILY_GOAL_CUSTOM_OPTION, "Set my own goal"),
            ),
        ),
        OnboardingQuestion(
            id = SOURCE,
            prompt = "Where did you hear about this application?",
            type = QuestionType.SingleChoice,
            optional = true,
            hint = "Optional \u2013 you can skip this one",
            options = listOf(
                opt("youtube", "YouTube"),
                opt("instagram", "Instagram"),
                opt("facebook", "Facebook"),
                opt("friends_family", "Friends or family"),
                opt("google_search", "Google Search"),
                opt("other", "Other"),
            ),
        ),
    )

    val count: Int get() = all.size
}

/**
 * Everything the person has answered so far. Immutable: every change returns a new value, so it can
 * live in Compose state and be compared cheaply.
 *
 * Choice answers hold option ids (see [OnboardingQuestions]); the name holds the typed text.
 */
data class OnboardingAnswers(private val values: Map<String, List<String>> = emptyMap()) {

    /** The text of a [QuestionType.Text] question exactly as typed (may have spaces at the ends). */
    fun text(questionId: String): String = values[questionId]?.firstOrNull().orEmpty()

    /** The chosen option ids of a choice question, in the order they were picked. */
    fun selected(questionId: String): List<String> = values[questionId].orEmpty()

    fun withText(questionId: String, raw: String): OnboardingAnswers {
        // Control characters are dropped so a name can never break the saved-state encoding.
        var clean = raw.filter { !it.isISOControl() }
        if (questionId == OnboardingQuestions.NAME) clean = clean.take(OnboardingQuestions.NAME_MAX_LENGTH)
        return put(questionId, if (clean.isEmpty()) emptyList() else listOf(clean))
    }

    fun withSingle(questionId: String, optionId: String): OnboardingAnswers =
        put(questionId, listOf(optionId))

    fun withToggled(questionId: String, optionId: String): OnboardingAnswers {
        val now = selected(questionId)
        return put(questionId, if (optionId in now) now - optionId else now + optionId)
    }

    /** Whether Next may be pressed on [question]. Optional questions always allow it. */
    fun canContinue(question: OnboardingQuestion): Boolean = question.optional || (when (question.type) {
        QuestionType.Text -> text(question.id).isNotBlank()
        QuestionType.SingleChoice, QuestionType.MultiChoice -> selected(question.id).isNotEmpty()
    } && customGoalIsValid(question))

    /** "Set my own goal" needs a sensible number of minutes before Next works. Other questions: always true. */
    private fun customGoalIsValid(question: OnboardingQuestion): Boolean =
        question.id != OnboardingQuestions.DAILY_GOAL ||
            dailyGoal != OnboardingQuestions.DAILY_GOAL_CUSTOM_OPTION ||
            dailyGoalMinutes != null

    /** The typed minutes exactly as stored (digits only, may be empty or out of range while typing). */
    val customGoalText: String get() = text(OnboardingQuestions.DAILY_GOAL_CUSTOM_MINUTES)

    fun withCustomGoalText(raw: String): OnboardingAnswers {
        val digits = raw.filter { it in '0'..'9' }.take(4)
        return put(OnboardingQuestions.DAILY_GOAL_CUSTOM_MINUTES, if (digits.isEmpty()) emptyList() else listOf(digits))
    }

    // ---- Typed readers for Part 2B -------------------------------------------------------------

    val name: String get() = text(OnboardingQuestions.NAME).trim()
    val goal: String? get() = selected(OnboardingQuestions.GOAL).firstOrNull()
    val distractions: List<String> get() = selected(OnboardingQuestions.DISTRACTIONS)
    val phoneTime: String? get() = selected(OnboardingQuestions.PHONE_TIME).firstOrNull()
    val sessionLength: String? get() = selected(OnboardingQuestions.SESSION_LENGTH).firstOrNull()
    val dailyGoal: String? get() = selected(OnboardingQuestions.DAILY_GOAL).firstOrNull()

    /** null when the optional last question was skipped. */
    val source: String? get() = selected(OnboardingQuestions.SOURCE).firstOrNull()

    /**
     * The daily goal in minutes, only for "Set my own goal" and only when the typed number is in range
     * ([OnboardingQuestions.CUSTOM_GOAL_MIN]..[OnboardingQuestions.CUSTOM_GOAL_MAX]); null otherwise.
     */
    val dailyGoalMinutes: Int?
        get() = if (dailyGoal == OnboardingQuestions.DAILY_GOAL_CUSTOM_OPTION) {
            customGoalText.toIntOrNull()?.takeIf {
                it in OnboardingQuestions.CUSTOM_GOAL_MIN..OnboardingQuestions.CUSTOM_GOAL_MAX
            }
        } else null

    /** true when nothing at all was answered. */
    val isEmpty: Boolean get() = values.values.all { it.isEmpty() }

    // ---- Saved-state encoding (rotation / process death) ---------------------------------------

    /** One string per answered question: `id SEP value SEP value ...`. */
    fun encode(): List<String> =
        values.filterValues { it.isNotEmpty() }.map { (id, list) -> (listOf(id) + list).joinToString(SEP.toString()) }

    private fun put(questionId: String, list: List<String>): OnboardingAnswers =
        OnboardingAnswers(if (list.isEmpty()) values - questionId else values + (questionId to list))

    companion object {
        private const val SEP = '\u0001'

        fun decode(encoded: List<String>): OnboardingAnswers {
            val map = LinkedHashMap<String, List<String>>()
            for (line in encoded) {
                val parts = line.split(SEP)
                val id = parts.firstOrNull().orEmpty()
                val list = parts.drop(1).filter { it.isNotEmpty() }
                if (id.isNotEmpty() && list.isNotEmpty()) map[id] = list
            }
            return OnboardingAnswers(map)
        }
    }
}
