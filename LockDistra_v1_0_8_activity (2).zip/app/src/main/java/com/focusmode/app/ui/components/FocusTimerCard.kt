package com.focusmode.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.ui.theme.FocusTheme
import com.focusmode.app.ui.theme.PoppinsFamily

// The hero is always drawn on the dark night scene, so these colours do not follow the light theme.
private val GlassTop = Color(0xF21A1138)
private val GlassBottom = Color(0xF50B061A)
private val Lavender = Color(0xFFC9C2E6)
private val Violet = Color(0xFFC044FF)
private val Pink = Color(0xFFE84393)
private val Amber = Color(0xFFFFC107)

/**
 * The large glass "Focus Timer" card of the home screen: status pill, big time, progress bar while a
 * session runs, and the Start / End button.
 *
 * @param progress share of the session still remaining, 0..1 (use 1 for no time limit).
 * @param idleText time shown while no session runs (the last chosen length, for example 25:00).
 */
@Composable
fun FocusTimerCard(
    active: Boolean,
    paused: Boolean,
    progress: Float,
    timeText: String,
    caption: String,
    idleText: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(30.dp)
    val transition = rememberInfiniteTransition(label = "timerPulse")
    val pulse by transition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val barProgress by animateFloatAsState(
        targetValue = if (active) progress.coerceIn(0f, 1f) else 0f,
        animationSpec = tween(if (active) 1000 else 500, easing = LinearEasing),
        label = "timerBar"
    )
    val dot by animateColorAsState(
        when {
            paused -> Amber
            active -> Pink
            else -> Violet
        },
        tween(350), label = "timerDot"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .shadow(18.dp, shape, ambientColor = Violet.copy(alpha = 0.45f), spotColor = Color(0x99000000))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(GlassTop, GlassBottom)))
            .border(
                BorderStroke(
                    1.2.dp,
                    Brush.verticalGradient(
                        listOf(Color(0xCCFFFFFF), Color(0x88C044FF), Color(0x227C3AED), Color(0x0DFFFFFF))
                    )
                ),
                shape
            )
            .padding(horizontal = 22.dp, vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Status pill
        Row(
            Modifier
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.verticalGradient(listOf(Color(0x73291854), Color(0x551B0D38))))
                .border(1.dp, Violet.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(if (active) dot else dot.copy(alpha = pulse))
            )
            Text(
                when {
                    paused -> "Paused for a moment"
                    active -> "Focus in progress"
                    else -> "Time to focus"
                },
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = Lavender
            )
        }

        Spacer(Modifier.height(14.dp))
        Text(
            "Focus Timer",
            style = MaterialTheme.typography.titleMedium.copy(letterSpacing = 0.5.sp),
            color = Lavender
        )
        Text(
            if (active) timeText else idleText,
            style = TextStyle(
                fontFamily = PoppinsFamily,
                fontWeight = FontWeight.Bold,
                fontSize = if ((if (active) timeText else idleText).length > 5) 46.sp else 60.sp,
                letterSpacing = 1.sp,
                fontFeatureSettings = "tnum"
            ),
            color = Color.White,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
        Text(
            if (active) caption else "Tap start, your blocked apps go quiet",
            style = MaterialTheme.typography.bodySmall,
            color = Lavender.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )

        if (active) {
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(CircleShape)
                    .background(Color(0x33FFFFFF))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(barProgress)
                        .height(6.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(if (paused) Amber else Color(0xFF7C3AED), if (paused) Amber else Color(0xFFEC4899))
                            )
                        )
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        PrimaryButton(
            text = if (active) "End Focus" else "Start Focus",
            onClick = onClick,
            icon = if (active) Icons.Rounded.Stop else Icons.Rounded.PlayArrow
        )
    }
}

/**
 * Night scene for the home hero, drawn in code (no image file): sky, stars, moon, two mountain
 * ridges, a lake with the moon's reflection and a few pines.
 */
@Composable
fun NightScenery(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val horizon = h * 0.56f

        drawRect(
            Brush.verticalGradient(
                listOf(Color(0xFF150B34), Color(0xFF2B1760), Color(0xFF4A2A86)),
                startY = 0f, endY = horizon
            ),
            size = Size(w, horizon)
        )

        // Stars
        val stars = listOf(
            0.08f to 0.06f, 0.2f to 0.14f, 0.33f to 0.05f, 0.46f to 0.12f, 0.58f to 0.04f,
            0.66f to 0.17f, 0.9f to 0.08f, 0.14f to 0.26f, 0.52f to 0.22f, 0.94f to 0.24f
        )
        stars.forEachIndexed { i, (x, y) ->
            drawCircle(Color.White.copy(alpha = if (i % 2 == 0) 0.7f else 0.4f), radius = 1.4.dp.toPx(), center = Offset(w * x, h * y))
        }

        // Moon with halo
        val moon = Offset(w * 0.8f, h * 0.3f)
        val moonR = w * 0.075f
        drawCircle(
            Brush.radialGradient(listOf(Color(0x55FFC98A), Color.Transparent), center = moon, radius = moonR * 3.2f),
            radius = moonR * 3.2f, center = moon
        )
        drawCircle(Color(0xFFF8DDA8), radius = moonR, center = moon)
        drawCircle(Color(0x22C58A4A), radius = moonR * 0.28f, center = moon + Offset(-moonR * 0.3f, moonR * 0.1f))

        // Far ridge
        val far = Path().apply {
            moveTo(0f, horizon)
            lineTo(0f, h * 0.44f)
            lineTo(w * 0.16f, h * 0.38f)
            lineTo(w * 0.3f, h * 0.46f)
            lineTo(w * 0.48f, h * 0.35f)
            lineTo(w * 0.66f, h * 0.47f)
            lineTo(w * 0.84f, h * 0.4f)
            lineTo(w, h * 0.46f)
            lineTo(w, horizon)
            close()
        }
        drawPath(far, Color(0xFF2E1A62))

        // Near ridge
        val near = Path().apply {
            moveTo(0f, horizon)
            lineTo(0f, h * 0.5f)
            lineTo(w * 0.2f, h * 0.45f)
            lineTo(w * 0.38f, h * 0.52f)
            lineTo(w * 0.6f, h * 0.47f)
            lineTo(w * 0.82f, h * 0.53f)
            lineTo(w, h * 0.49f)
            lineTo(w, horizon)
            close()
        }
        drawPath(near, Color(0xFF1D1045))

        // Lake
        drawRect(
            Brush.verticalGradient(
                listOf(Color(0xFF30307F), Color(0xFF1A1146), Color(0xFF0E0824)),
                startY = horizon, endY = h
            ),
            topLeft = Offset(0f, horizon),
            size = Size(w, h - horizon)
        )
        // Moon reflection
        val refl = Offset(moon.x, horizon + (h - horizon) * 0.22f)
        drawRoundRect(
            Brush.verticalGradient(
                listOf(Color(0x66FFC98A), Color.Transparent),
                startY = horizon, endY = horizon + (h - horizon) * 0.6f
            ),
            topLeft = Offset(refl.x - moonR * 0.7f, horizon + 4.dp.toPx()),
            size = Size(moonR * 1.4f, (h - horizon) * 0.55f),
            cornerRadius = CornerRadius(moonR, moonR)
        )

        // Pines (left and right shore)
        fun pine(x: Float, base: Float, ph: Float) {
            val pw = ph * 0.42f
            val p = Path().apply {
                moveTo(x, base - ph)
                lineTo(x + pw / 2, base)
                lineTo(x - pw / 2, base)
                close()
            }
            drawPath(p, Color(0xFF0B0620))
        }
        pine(w * 0.05f, horizon + 6.dp.toPx(), h * 0.2f)
        pine(w * 0.12f, horizon + 4.dp.toPx(), h * 0.14f)
        pine(w * 0.93f, horizon + 6.dp.toPx(), h * 0.19f)
        pine(w * 0.87f, horizon + 4.dp.toPx(), h * 0.13f)
    }
}
