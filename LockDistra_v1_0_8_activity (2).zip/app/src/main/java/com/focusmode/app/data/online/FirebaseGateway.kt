package com.focusmode.app.data.online

import android.content.Context
import android.os.Build
import android.os.UserManager
import com.focusmode.app.BuildConfig
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.Query
import com.google.firebase.database.ServerValue
import com.google.firebase.database.ValueEventListener
import java.net.HttpURLConnection
import java.net.URLEncoder
import org.json.JSONObject
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/** Build-time Firebase settings (BuildConfig). Empty values mean "this build has no Online Approval". */
object OnlineConfig {
    val configured: Boolean
        get() = BuildConfig.FB_API_KEY.isNotBlank() &&
            BuildConfig.FB_APP_ID.isNotBlank() &&
            BuildConfig.FB_PROJECT_ID.isNotBlank() &&
            BuildConfig.FB_DATABASE_URL.startsWith("https://")

    /** Push needs an ANDROID app id (1:...:android:...). A web app id can't get an FCM token on a phone. */
    val appIdIsAndroid: Boolean
        get() = BuildConfig.FB_APP_ID.contains(":android:")

    /** Cloudflare Worker that sends the push to the trusted phone. Empty = no push, in-app only. */
    val workerUrl: String
        get() = BuildConfig.APPROVAL_WORKER_URL.trim().takeIf { it.startsWith("https://") } ?: ""
}

class OnlineException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { NOT_CONFIGURED, OFFLINE, AUTH, PERMISSION, TIMEOUT, OTHER }
}

data class Invite(val ownerUid: String, val createdAt: Long?, val deviceName: String?)
data class Claim(val claimerUid: String, val deviceName: String, val decision: String?)

/** What the server holds at links/{ownerUid}: who the trusted phone is. Null snapshot = no link (disconnected). */
data class LinkSnapshot(val approverUid: String)

/** The server copy of a connection, used to bring it back after logout / reinstall. [pairKey] is null for a link made before backups existed. */
data class LinkBackup(val approverUid: String, val approverName: String, val pairKey: String?)

/** One entry of approverLinks/{approverUid}: a phone that named this phone as its trusted phone. */
data class OwnerRef(val ownerUid: String, val ownerName: String)
data class PendingRequest(val id: String, val snap: RequestSnapshot, val mac: String?, val deviceName: String?)

/** What a "more time in one app" request carries besides the normal fields. */
data class AppRequestInfo(val pkg: String, val appName: String, val reason: Int)

/**
 * The only class that talks to Firebase. Firebase is started by hand from BuildConfig values (no
 * google-services.json in the repo). Phones sign in anonymously; what a phone may read or write
 * is decided by database.rules.json, and on top of that every answer carries a proof made with
 * the shared pair key (see ApprovalProtocol), so the rules are a second wall, not the only one.
 */
object FirebaseGateway {

    private const val OP_TIMEOUT_MS = 15_000L
    private const val CONNECT_WAIT_MS = 20_000L

    private val _connected = MutableStateFlow(false)
    val connected: StateFlow<Boolean> = _connected.asStateFlow()

    @Volatile private var offsetMs = 0L
    @Volatile private var watching = false

    /** Server clock, so a changed phone clock can't stretch a request's life. */
    fun serverNow(): Long = System.currentTimeMillis() + offsetMs

    // ---- Start-up ----------------------------------------------------------------------------------

    fun init(context: Context) {
        runCatching { app(context) }
    }

    fun app(context: Context): FirebaseApp? {
        FirebaseApp.getApps(context.applicationContext).firstOrNull()?.let { return it }
        if (!OnlineConfig.configured) return null
        // Firebase keeps its data in credential-protected storage, so wait for the first unlock.
        if (Build.VERSION.SDK_INT >= 24) {
            val um = context.getSystemService(UserManager::class.java)
            if (um != null && !um.isUserUnlocked) return null
        }
        val options = FirebaseOptions.Builder()
            .setApiKey(BuildConfig.FB_API_KEY)
            .setApplicationId(BuildConfig.FB_APP_ID)
            .setProjectId(BuildConfig.FB_PROJECT_ID)
            .setDatabaseUrl(BuildConfig.FB_DATABASE_URL)
            .apply { if (BuildConfig.FB_SENDER_ID.isNotBlank()) setGcmSenderId(BuildConfig.FB_SENDER_ID) }
            .build()
        return try {
            FirebaseApp.initializeApp(context.applicationContext, options)
        } catch (_: IllegalStateException) {
            FirebaseApp.getInstance()
        }
    }

    private fun requireApp(context: Context): FirebaseApp =
        app(context) ?: throw OnlineException(
            OnlineException.Kind.NOT_CONFIGURED,
            "Online approval isn't set up in this build."
        )

    private fun db(context: Context): FirebaseDatabase = FirebaseDatabase.getInstance(requireApp(context))

    /** Starts watching the connection and the server clock. Safe to call again and again. */
    fun start(context: Context) {
        if (watching) return
        val app = app(context) ?: return
        watching = true
        val database = FirebaseDatabase.getInstance(app)
        database.getReference(".info/connected").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _connected.value = snapshot.getValue(Boolean::class.java) == true
            }
            override fun onCancelled(error: DatabaseError) {
                _connected.value = false
            }
        })
        database.getReference(".info/serverTimeOffset").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                offsetMs = (snapshot.value as? Number)?.toLong() ?: 0L
            }
            override fun onCancelled(error: DatabaseError) = Unit
        })
    }

    // ---- Sign-in -----------------------------------------------------------------------------------

    /** Signs in (if needed) and retries a few times when the network or the server is slow to answer. */
    suspend fun uid(context: Context): String = net(context) { signedIn(context) }

    private suspend fun signedIn(context: Context): String = guard {
        val auth = FirebaseAuth.getInstance(requireApp(context))
        auth.currentUser?.uid ?: run {
            val result = withTimeout(OP_TIMEOUT_MS) { auth.signInAnonymously().await() }
            result.user?.uid ?: throw OnlineException(OnlineException.Kind.AUTH, "Sign-in failed.")
        }
    }

    private suspend fun idToken(context: Context): String = guard {
        val user = FirebaseAuth.getInstance(requireApp(context)).currentUser
            ?: throw OnlineException(OnlineException.Kind.AUTH, "Not signed in.")
        withTimeout(OP_TIMEOUT_MS) { user.getIdToken(false).await() }.token
            ?: throw OnlineException(OnlineException.Kind.AUTH, "No sign-in token.")
    }

    /** Old name, kept so nothing else breaks. Gives the live connection a moment; never fails by itself. */
    suspend fun awaitOnline(context: Context) {
        live(context)
    }

    private const val SOFT_CONNECT_MS = 2_500L
    private const val POLL_MS = 3_000L
    private const val POLL_GRACE_MS = 3_000L
    private const val POLL_MAX_MS = 20_000L
    @Volatile private var liveFailedAt = 0L

    private suspend fun live(context: Context): Boolean {
        start(context)
        if (_connected.value) return true
        if (System.currentTimeMillis() - liveFailedAt < 30_000L) return false
        runCatching { db(context).goOnline() }
        val up = try {
            withTimeout(SOFT_CONNECT_MS) { connected.first { it } }
            true
        } catch (_: TimeoutCancellationException) {
            false
        }
        if (!up) liveFailedAt = System.currentTimeMillis()
        return up
    }

    private suspend fun <T> viaSocketOrRest(
        context: Context,
        socket: suspend () -> T,
        plain: suspend () -> T,
    ): T {
        if (live(context)) {
            try {
                return guard { socket() }
            } catch (e: OnlineException) {
                if (e.kind != OnlineException.Kind.OFFLINE && e.kind != OnlineException.Kind.TIMEOUT) throw e
            }
        }
        return plain()
    }

    private suspend fun <T> net(context: Context, block: suspend () -> T): T {
        var attempt = 0
        while (true) {
            try {
                return block()
            } catch (e: OnlineException) {
                attempt++
                val transient = e.kind == OnlineException.Kind.OFFLINE ||
                    e.kind == OnlineException.Kind.TIMEOUT ||
                    e.kind == OnlineException.Kind.PERMISSION ||
                    (e.kind == OnlineException.Kind.AUTH && e.message == SIGN_IN_FAILED)
                if (!transient || attempt >= 3) throw e
                if (e.kind == OnlineException.Kind.PERMISSION) reconnect(context)
                delay(500L * attempt)
            }
        }
    }

    private fun reconnect(context: Context) {
        runCatching {
            val d = db(context)
            d.goOffline()
            d.goOnline()
            _connected.value = false
        }
    }

    private const val SIGN_IN_FAILED = "Sign-in failed."

    private fun stamp(): JSONObject = JSONObject().put(".sv", "timestamp")

    private fun JSONObject.str(key: String): String? = if (has(key) && !isNull(key)) optString(key) else null

    private fun JSONObject.lng(key: String): Long? = if (has(key) && !isNull(key)) optLong(key) else null

    private suspend fun restCall(
        context: Context, method: String, path: String, body: String? = null, patch: Boolean = false,
    ): String {
        val token = idToken(context)
        val dbUrl = BuildConfig.FB_DATABASE_URL.trim().trimEnd('/')
        var url = dbUrl + "/" + path + ".json?auth=" + URLEncoder.encode(token, "UTF-8")
        if (patch) url += "&x-http-method-override=PATCH"
        return withContext(Dispatchers.IO) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                try {
                    conn.requestMethod = method
                    conn.connectTimeout = 8_000
                    conn.readTimeout = 10_000
                    conn.setRequestProperty("Accept", "application/json")
                    if (patch) conn.setRequestProperty("X-HTTP-Method-Override", "PATCH")
                    if (body != null) {
                        conn.doOutput = true
                        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    if (code in 200..299) {
                        val serverDate = conn.date
                        if (serverDate > 0L && !_connected.value) offsetMs = serverDate - System.currentTimeMillis()
                        text
                    } else if (code == 401 || code == 403) {
                        throw OnlineException(OnlineException.Kind.PERMISSION, "The server refused this (permission denied).")
                    } else if (code >= 500) {
                        throw OnlineException(OnlineException.Kind.TIMEOUT, "The server took too long to answer.")
                    } else {
                        throw OnlineException(OnlineException.Kind.OTHER, "Something went wrong. Try again.")
                    }
                } finally {
                    conn.disconnect()
                }
            } catch (e: OnlineException) {
                throw e
            } catch (e: java.io.IOException) {
                throw OnlineException(OnlineException.Kind.OFFLINE, "No internet connection.")
            }
        }
    }

    private suspend fun restObject(context: Context, path: String): JSONObject? {
        val text = restCall(context, "GET", path).trim()
        if (text.isEmpty() || text == "null") return null
        return try {
            JSONObject(text)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Fallback only, for networks that block the live connection. While the live connection is up this does
     * nothing at all (no timer, no download). When it is down it asks every few seconds, slower each time, and
     * stops the moment the connection is back.
     */
    private fun pollObject(context: Context, path: String): Flow<JSONObject?> = flow<JSONObject?> {
        while (true) {
            connected.first { !it }          // sleeps here while the live connection works
            delay(POLL_GRACE_MS)             // give the live connection a moment to come up first
            var wait = POLL_MS
            while (!_connected.value) {
                try {
                    emit(restObject(context, path))
                } catch (_: OnlineException) {
                    // try again later
                }
                delay(wait)
                wait = minOf(wait * 2, POLL_MAX_MS)
            }
        }
    }

    private fun inviteOf(owner: String?, createdAt: Long?, deviceName: String?): Invite? =
        if (owner == null) null else Invite(owner, createdAt, deviceName)

    private fun claimOfJson(o: JSONObject?): Claim? {
        if (o == null) return null
        val claimer = o.str("claimerUid") ?: return null
        return Claim(claimerUid = claimer, deviceName = o.str("deviceName") ?: "Phone", decision = o.str("decision"))
    }

    private fun snapshotOfJson(o: JSONObject) = RequestSnapshot(
        status = o.str("status"),
        createdAt = o.lng("createdAt"),
        decidedAt = o.lng("decidedAt"),
        decidedBy = o.str("decidedBy"),
        proof = o.str("proof"),
        nonce = o.str("nonce"),
        deviceId = o.str("deviceId"),
        kind = o.str("kind"),
        pkg = o.str("pkg"),
        appName = o.str("appName"),
        reason = o.lng("reason")?.toInt(),
        minutes = o.lng("minutes"),
    )

    private fun pendingFromJson(o: JSONObject?): List<PendingRequest> {
        if (o == null) return emptyList()
        val out = ArrayList<PendingRequest>()
        val keys = o.keys()
        while (keys.hasNext()) {
            val id = keys.next()
            val child = o.optJSONObject(id) ?: continue
            if (child.str("status") != "pending") continue
            out.add(
                PendingRequest(
                    id = id,
                    snap = snapshotOfJson(child),
                    mac = child.str("mac"),
                    deviceName = child.str("deviceName"),
                )
            )
        }
        return out.sortedBy { it.snap.createdAt ?: 0L }.takeLast(10)
    }

    // ---- Pairing -------------------------------------------------------------------------------------

    suspend fun createInvite(context: Context, inviteId: String, deviceName: String): Unit = net(context) {
        val uid = signedIn(context)
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) {
                    db(context).getReference("pairInvites/$inviteId").setValue(
                        mapOf("ownerUid" to uid, "createdAt" to ServerValue.TIMESTAMP, "deviceName" to deviceName)
                    ).await()
                }
                Unit
            },
            plain = {
                val body = JSONObject().put("ownerUid", uid).put("createdAt", stamp()).put("deviceName", deviceName)
                restCall(context, "PUT", "pairInvites/$inviteId", body.toString())
                Unit
            },
        )
    }

    suspend fun readInvite(context: Context, inviteId: String): Invite? = net<Invite?>(context) {
        signedIn(context)
        viaSocketOrRest<Invite?>(
            context,
            socket = {
                val snap = withTimeout(OP_TIMEOUT_MS) { db(context).getReference("pairInvites/$inviteId").get().await() }
                if (!snap.exists()) {
                    null
                } else {
                    inviteOf(
                        snap.child("ownerUid").value as? String,
                        (snap.child("createdAt").value as? Number)?.toLong(),
                        snap.child("deviceName").value as? String,
                    )
                }
            },
            plain = {
                val o = restObject(context, "pairInvites/$inviteId")
                if (o == null) null else inviteOf(o.str("ownerUid"), o.lng("createdAt"), o.str("deviceName"))
            },
        )
    }

    suspend fun submitClaim(context: Context, inviteId: String, deviceName: String): Unit = net(context) {
        val uid = signedIn(context)
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) {
                    db(context).getReference("pairClaims/$inviteId").setValue(
                        mapOf("claimerUid" to uid, "deviceName" to deviceName, "createdAt" to ServerValue.TIMESTAMP)
                    ).await()
                }
                Unit
            },
            plain = {
                val body = JSONObject().put("claimerUid", uid).put("deviceName", deviceName).put("createdAt", stamp())
                restCall(context, "PUT", "pairClaims/$inviteId", body.toString())
                Unit
            },
        )
    }

    fun observeClaim(context: Context, inviteId: String): Flow<Claim?> {
        val path = "pairClaims/$inviteId"
        val socket: Flow<Claim?> = observe(db(context).getReference(path)).mapSnap { s ->
            if (!s.exists()) null else claimOfSnapshot(s)
        }
        val poll: Flow<Claim?> = pollObject(context, path).map { o -> claimOfJson(o) }
        return merge(socket, poll)
    }

    private fun claimOfSnapshot(s: DataSnapshot): Claim? {
        val claimer = s.child("claimerUid").value as? String ?: return null
        return Claim(
            claimerUid = claimer,
            deviceName = s.child("deviceName").value as? String ?: "Phone",
            decision = s.child("decision").value as? String,
        )
    }

    suspend fun setClaimDecision(context: Context, inviteId: String, confirmed: Boolean): Unit = net(context) {
        signedIn(context)
        val value = if (confirmed) "confirmed" else "rejected"
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) {
                    db(context).getReference("pairClaims/$inviteId/decision").setValue(value).await()
                }
                Unit
            },
            plain = {
                restCall(context, "PUT", "pairClaims/$inviteId/decision", JSONObject.quote(value))
                Unit
            },
        )
    }

    suspend fun createLink(
        context: Context, ownerUid: String, inviteId: String, approverUid: String, approverName: String,
        pairKey: String? = null,
    ): Unit = net(context) {
        signedIn(context)
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) {
                    val values = mutableMapOf<String, Any>(
                        "approverUid" to approverUid,
                        "approverName" to approverName,
                        "inviteId" to inviteId,
                        "createdAt" to ServerValue.TIMESTAMP,
                    )
                    if (pairKey != null) values["pairKey"] = pairKey
                    db(context).getReference("links/$ownerUid").setValue(values).await()
                }
                Unit
            },
            plain = {
                val body = JSONObject()
                    .put("approverUid", approverUid)
                    .put("approverName", approverName)
                    .put("inviteId", inviteId)
                    .put("createdAt", stamp())
                if (pairKey != null) body.put("pairKey", pairKey)
                restCall(context, "PUT", "links/$ownerUid", body.toString())
                Unit
            },
        )
    }

    // ---- Connection backup: lets a connection survive logout / reinstall -------------------------------

    /** The server copy of this account's link (links/{ownerUid}), or null when there is none. */
    suspend fun readLinkBackup(context: Context, ownerUid: String): LinkBackup? = net<LinkBackup?>(context) {
        signedIn(context)
        viaSocketOrRest<LinkBackup?>(
            context,
            socket = {
                val snap = withTimeout(OP_TIMEOUT_MS) { db(context).getReference("links/$ownerUid").get().await() }
                val approver = snap.child("approverUid").value as? String
                if (!snap.exists() || approver == null) null
                else LinkBackup(
                    approver,
                    (snap.child("approverName").value as? String) ?: "Trusted phone",
                    snap.child("pairKey").value as? String,
                )
            },
            plain = {
                val o = restObject(context, "links/$ownerUid")
                val approver = o?.str("approverUid")
                if (o == null || approver == null) null
                else LinkBackup(approver, o.str("approverName") ?: "Trusted phone", o.str("pairKey"))
            },
        )
    }

    /**
     * Locked phone: makes sure the server holds the pair key (older links were made without it) and the entry that lets
     * the trusted phone find this phone again. Safe to repeat. True when the server now holds the complete link.
     */
    suspend fun backupLink(
        context: Context, ownerUid: String, approverUid: String, ownerName: String, pairKey: String,
    ): Boolean = net<Boolean>(context) {
        signedIn(context)
        val existing = readLinkBackup(context, ownerUid)
        // Only back up the link that is really on the server; a different trusted phone there means this copy is stale.
        if (existing == null || existing.approverUid != approverUid) return@net false
        if (existing.pairKey == null) {
            viaSocketOrRest<Unit>(
                context,
                socket = {
                    withTimeout(OP_TIMEOUT_MS) { db(context).getReference("links/$ownerUid/pairKey").setValue(pairKey).await() }
                    Unit
                },
                plain = {
                    restCall(context, "PUT", "links/$ownerUid/pairKey", JSONObject.quote(pairKey))
                    Unit
                },
            )
        }
        writeApproverIndex(context, approverUid, ownerUid, ownerName)
        true
    }

    private suspend fun writeApproverIndex(context: Context, approverUid: String, ownerUid: String, ownerName: String) {
        val name = ownerName.take(40).ifBlank { "Phone" }
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) {
                    db(context).getReference("approverLinks/$approverUid/$ownerUid").setValue(
                        mapOf("ownerName" to name, "createdAt" to ServerValue.TIMESTAMP)
                    ).await()
                }
                Unit
            },
            plain = {
                val body = JSONObject().put("ownerName", name).put("createdAt", stamp())
                restCall(context, "PUT", "approverLinks/$approverUid/$ownerUid", body.toString())
                Unit
            },
        )
    }

    /** Trusted phone: the phones that named this account as their trusted phone. */
    suspend fun readOwnersOf(context: Context, approverUid: String): List<OwnerRef> = net<List<OwnerRef>>(context) {
        signedIn(context)
        viaSocketOrRest<List<OwnerRef>>(
            context,
            socket = {
                val snap = withTimeout(OP_TIMEOUT_MS) { db(context).getReference("approverLinks/$approverUid").get().await() }
                snap.children.mapNotNull { c ->
                    val key = c.key ?: return@mapNotNull null
                    OwnerRef(key, (c.child("ownerName").value as? String) ?: "Phone")
                }
            },
            plain = {
                val o = restObject(context, "approverLinks/$approverUid")
                if (o == null) emptyList()
                else o.keys().asSequence().mapNotNull { k ->
                    val child = o.optJSONObject(k) ?: return@mapNotNull null
                    OwnerRef(k, child.str("ownerName") ?: "Phone")
                }.toList()
            },
        )
    }

    suspend fun deleteApproverIndex(context: Context, approverUid: String, ownerUid: String) {
        signedIn(context)
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference("approverLinks/$approverUid/$ownerUid").removeValue().await() }
                Unit
            },
            plain = {
                restCall(context, "DELETE", "approverLinks/$approverUid/$ownerUid")
                Unit
            },
        )
    }

    suspend fun deleteLink(context: Context, ownerUid: String) {
        signedIn(context)
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference("links/$ownerUid").removeValue().await() }
                Unit
            },
            plain = {
                restCall(context, "DELETE", "links/$ownerUid")
                Unit
            },
        )
    }

    /**
     * Live view of the connection between a locked phone and its trusted phone. Emits [LinkSnapshot] while the
     * link exists and null when it is gone (either phone disconnected). Push based: the server tells us when it
     * changes, nothing is downloaded again and again. (The REST poll only runs while the live socket is down.)
     * Both the owner and the approver may read this path (see database.rules.json).
     */
    fun observeLink(context: Context, ownerUid: String): Flow<LinkSnapshot?> {
        val path = "links/$ownerUid"
        val socket: Flow<LinkSnapshot?> = observe(db(context).getReference(path)).mapSnap { s ->
            val approver = s.child("approverUid").value as? String
            if (!s.exists() || approver == null) null else LinkSnapshot(approver)
        }
        val poll: Flow<LinkSnapshot?> = pollObject(context, path).map { o ->
            o?.str("approverUid")?.let { LinkSnapshot(it) }
        }
        return merge(socket, poll)
    }

    suspend fun linkExists(context: Context, ownerUid: String): Boolean = net<Boolean>(context) {
        signedIn(context)
        viaSocketOrRest<Boolean>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference("links/$ownerUid").get().await() }.exists()
            },
            plain = {
                restObject(context, "links/$ownerUid") != null
            },
        )
    }

    suspend fun cleanupPairing(context: Context, inviteId: String, deleteClaim: Boolean) {
        runCatching {
            if (_connected.value) {
                val d = db(context)
                withTimeout(OP_TIMEOUT_MS) {
                    if (deleteClaim) d.getReference("pairClaims/$inviteId").removeValue().await()
                    d.getReference("pairInvites/$inviteId").removeValue().await()
                }
            } else {
                if (deleteClaim) restCall(context, "DELETE", "pairClaims/$inviteId")
                restCall(context, "DELETE", "pairInvites/$inviteId")
            }
        }
    }

    suspend fun createRequest(
        context: Context, ownerUid: String, requestId: String,
        nonce: String, deviceId: String, deviceName: String, mac: String,
        app: AppRequestInfo? = null,
    ): Unit = net(context) {
        signedIn(context)
        val fields = mutableMapOf<String, Any>(
            "status" to "pending",
            "createdAt" to ServerValue.TIMESTAMP,
            "nonce" to nonce,
            "deviceId" to deviceId,
            "deviceName" to deviceName,
            "mac" to mac,
        )
        if (app != null) {
            fields["kind"] = ApprovalProtocol.KIND_APP
            fields["pkg"] = app.pkg
            fields["appName"] = app.appName
            fields["reason"] = app.reason
        }
        val path = "unlockRequests/$ownerUid/$requestId"
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference(path).setValue(fields).await() }
                Unit
            },
            plain = {
                val body = JSONObject()
                for ((k, v) in fields) {
                    if (k == "createdAt") body.put(k, stamp()) else body.put(k, v)
                }
                try {
                    restCall(context, "PUT", path, body.toString())
                } catch (e: OnlineException) {
                    if (e.kind != OnlineException.Kind.PERMISSION) throw e
                    val there = restObject(context, path)
                    if (there == null || there.str("nonce") != nonce) throw e
                }
                Unit
            },
        )
    }

    fun newRequestId(context: Context, ownerUid: String): String =
        db(context).getReference("unlockRequests/$ownerUid").push().key
            ?: throw OnlineException(OnlineException.Kind.OTHER, "Could not make a request id.")

    fun observeRequest(context: Context, ownerUid: String, requestId: String): Flow<RequestSnapshot?> {
        val path = "unlockRequests/$ownerUid/$requestId"
        val socket: Flow<RequestSnapshot?> = observe(db(context).getReference(path)).mapSnap { s ->
            if (!s.exists()) null else snapshotOf(s)
        }
        val poll: Flow<RequestSnapshot?> = pollObject(context, path).map { o ->
            if (o == null) null else snapshotOfJson(o)
        }
        return merge(socket, poll)
    }

    fun observePending(context: Context, ownerUid: String): Flow<List<PendingRequest>> {
        val path = "unlockRequests/$ownerUid"
        val socket: Flow<List<PendingRequest>> =
            observe(db(context).getReference(path).orderByChild("status").equalTo("pending").limitToLast(10))
                .mapSnap { s ->
                    s.children.mapNotNull { child ->
                        val id = child.key ?: return@mapNotNull null
                        PendingRequest(
                            id = id,
                            snap = snapshotOf(child),
                            mac = child.child("mac").value as? String,
                            deviceName = child.child("deviceName").value as? String,
                        )
                    }
                }
        val poll: Flow<List<PendingRequest>> = pollObject(context, path).map { o -> pendingFromJson(o) }
        return merge(socket, poll)
    }

    suspend fun decide(
        context: Context, ownerUid: String, requestId: String, decision: Decision, proof: String,
        minutes: Int? = null,
    ) {
        val uid = uid(context)
        val path = "unlockRequests/$ownerUid/$requestId"
        viaSocketOrRest<Unit>(
            context,
            socket = {
                val fields = mutableMapOf<String, Any>(
                    "status" to decision.wire,
                    "decidedAt" to ServerValue.TIMESTAMP,
                    "decidedBy" to uid,
                    "proof" to proof,
                )
                if (minutes != null) fields["minutes"] = minutes
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference(path).updateChildren(fields).await() }
                Unit
            },
            plain = {
                val body = JSONObject()
                    .put("status", decision.wire)
                    .put("decidedAt", stamp())
                    .put("decidedBy", uid)
                    .put("proof", proof)
                if (minutes != null) body.put("minutes", minutes)
                restCall(context, "POST", path, body.toString(), patch = true)
                Unit
            },
        )
    }

    suspend fun removeRequest(context: Context, ownerUid: String, requestId: String) {
        runCatching {
            val path = "unlockRequests/$ownerUid/$requestId"
            if (_connected.value) {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference(path).removeValue().await() }
            } else {
                restCall(context, "DELETE", path)
            }
        }
    }

    suspend fun purgeOldRequests(context: Context, ownerUid: String, olderThanMs: Long = 180_000L) {
        if (!_connected.value) return
        runCatching {
            val snap = withTimeout(OP_TIMEOUT_MS) {
                db(context).getReference("unlockRequests/$ownerUid")
                    .orderByChild("createdAt").limitToFirst(20).get().await()
            }
            val now = serverNow()
            for (child in snap.children) {
                val created = (child.child("createdAt").value as? Number)?.toLong() ?: 0L
                if (now - created > olderThanMs) {
                    withTimeout(OP_TIMEOUT_MS) { child.ref.removeValue().await() }
                }
            }
        }
    }

    suspend fun consume(context: Context, ownerUid: String, requestId: String) {
        val path = "unlockRequests/$ownerUid/$requestId/status"
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference(path).setValue("consumed").await() }
                Unit
            },
            plain = {
                restCall(context, "PUT", path, JSONObject.quote("consumed"))
                Unit
            },
        )
    }

    suspend fun cancel(context: Context, ownerUid: String, requestId: String) {
        runCatching {
            val path = "unlockRequests/$ownerUid/$requestId/status"
            if (_connected.value) {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference(path).setValue("cancelled").await() }
            } else {
                restCall(context, "PUT", path, JSONObject.quote("cancelled"))
            }
        }
    }

    // ---- Generic node access (used by the profile system, data/profile) ---------------------------
    // Same transport as everything above: live socket when connected, plain HTTPS otherwise, same retries,
    // same error kinds. What a phone may read or write is still decided by database.rules.json.

    /** The JSON object stored at [path], or null when nothing is there. */
    suspend fun readNode(context: Context, path: String): JSONObject? = net<JSONObject?>(context) {
        signedIn(context)
        viaSocketOrRest<JSONObject?>(
            context,
            socket = {
                val snap = withTimeout(OP_TIMEOUT_MS) { db(context).getReference(path).get().await() }
                (snap.value as? Map<*, *>)?.let { JSONObject(it) }
            },
            plain = { restObject(context, path) },
        )
    }

    /** Replaces the value at [path] with [value] (a flat [JSONObject] or a String); null removes it. */
    suspend fun setNode(context: Context, path: String, value: Any?): Unit = net(context) {
        signedIn(context)
        viaSocketOrRest<Unit>(
            context,
            socket = {
                val ref = db(context).getReference(path)
                withTimeout(OP_TIMEOUT_MS) {
                    when (value) {
                        null -> ref.removeValue().await()
                        is JSONObject -> ref.setValue(value.keys().asSequence().associateWith { k -> value.get(k) }).await()
                        else -> ref.setValue(value.toString()).await()
                    }
                }
                Unit
            },
            plain = {
                when (value) {
                    null -> restCall(context, "DELETE", path)
                    is JSONObject -> restCall(context, "PUT", path, value.toString())
                    else -> restCall(context, "PUT", path, JSONObject.quote(value.toString()))
                }
                Unit
            },
        )
    }

    suspend fun registerToken(context: Context, token: String) {
        val uid = uid(context)
        viaSocketOrRest<Unit>(
            context,
            socket = {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference("deviceTokens/$uid").setValue(token).await() }
                Unit
            },
            plain = {
                restCall(context, "PUT", "deviceTokens/$uid", JSONObject.quote(token))
                Unit
            },
        )
    }

    suspend fun removeToken(context: Context) {
        runCatching {
            val uid = uid(context)
            if (_connected.value) {
                withTimeout(OP_TIMEOUT_MS) { db(context).getReference("deviceTokens/$uid").removeValue().await() }
            } else {
                restCall(context, "DELETE", "deviceTokens/$uid")
            }
        }
    }

    /**
     * Asks the Worker to push the request to the trusted phone. The Worker checks our Firebase login
     * itself; this phone holds no push secret. False means "no push went out" (the request is still
     * in the database and shows up on the trusted phone as soon as its app is open).
     */
    suspend fun notifyApprover(context: Context, requestId: String, requestType: String? = null): Boolean {
        val url = OnlineConfig.workerUrl
        if (url.isEmpty()) return false
        val token = runCatching { idToken(context) }.getOrNull() ?: return false
        // One quick retry for a network blip or a 5xx. Not for 4xx (rate limit, no trusted phone, ...).
        repeat(2) { attempt ->
            val code = withContext(Dispatchers.IO) {
                runCatching {
                    val conn = URL(url.trimEnd('/') + "/notify").openConnection() as HttpURLConnection
                    try {
                        conn.requestMethod = "POST"
                        conn.connectTimeout = 10_000
                        conn.readTimeout = 10_000
                        conn.doOutput = true
                        conn.setRequestProperty("Content-Type", "application/json")
                        conn.setRequestProperty("Authorization", "Bearer $token")
                        // [requestType] (only "checkin_missed" today) is for the Study Check-In alert; the unlock flow sends none.
                        val payload = if (requestType == null) """{"requestId":"$requestId"}"""
                        else """{"request_id":"$requestId","request_type":"$requestType"}"""
                        conn.outputStream.use { it.write(payload.toByteArray()) }
                        conn.responseCode
                    } finally {
                        conn.disconnect()
                    }
                }.getOrDefault(-1)
            }
            if (code in 200..299) return true
            val retryable = code == -1 || code >= 500
            if (!retryable || attempt == 1) return false
            kotlinx.coroutines.delay(1_500L)
        }
        return false
    }

    /**
     * Tells the Worker "this account was just created" (the Worker then notifies the admin). True = finished
     * (sent, or nothing to do); false = try again at the next app start (offline, token, rate limit, 5xx).
     */
    suspend fun reportNewUser(context: Context, expectedUid: String): Boolean {
        val url = OnlineConfig.workerUrl
        if (url.isEmpty()) return true // this build has no Worker: nothing to report
        val current = runCatching { FirebaseAuth.getInstance(requireApp(context)).currentUser?.uid }.getOrNull() ?: return false
        if (current != expectedUid) return true // another account is signed in now: drop it
        val token = runCatching { idToken(context) }.getOrNull() ?: return false
        val code = withContext(Dispatchers.IO) {
            runCatching {
                val conn = URL(url.trimEnd('/') + "/api/v1/users/new").openConnection() as HttpURLConnection
                try {
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 10_000
                    conn.readTimeout = 10_000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json")
                    conn.setRequestProperty("Authorization", "Bearer $token")
                    conn.outputStream.use { it.write("{}".toByteArray()) }
                    conn.responseCode
                } finally {
                    conn.disconnect()
                }
            }.getOrDefault(-1)
        }
        return code in 200..299 || (code in 400..499 && code != 401 && code != 429)
    }

    private fun counter(by: Int): JSONObject = JSONObject().put(".sv", JSONObject().put("increment", by))

    /**
     * "This account opened the app on [day]". ONE small request to read our own last day, then ONE atomic write that
     * moves this person from their old day to today in the admin counters (stats/seen/dNNNNN, +1 today, -1 before).
     * True = done (or nothing to do); false = try again at the next app start.
     */
    suspend fun reportSeen(context: Context, expectedUid: String, day: Long): Boolean {
        val current = runCatching { FirebaseAuth.getInstance(requireApp(context)).currentUser?.uid }.getOrNull() ?: return false
        if (current != expectedUid) return true // another account is signed in now: drop it
        return try {
            val old = restCall(context, "GET", "users/$expectedUid/seenDay").trim().toLongOrNull()
            if (old != null && old >= day) return true
            fun body(withOld: Boolean) = JSONObject().apply {
                put("users/$expectedUid/seenDay", day)
                put("stats/seen/d$day", counter(1))
                if (old == null) put("stats/measured", counter(1)) else if (withOld) put("stats/seen/d$old", counter(-1))
            }.toString()
            try {
                restCall(context, "POST", "", body(true), patch = true)
            } catch (e: OnlineException) {
                // Only if the old day counter was removed by hand: still record today, never get stuck.
                if (e.kind != OnlineException.Kind.PERMISSION || old == null) throw e
                restCall(context, "POST", "", body(false), patch = true)
            }
            true
        } catch (e: OnlineException) {
            false
        }
    }

    /**
     * Joins the "all" push topic once per install, so a message sent from the admin panel reaches this phone.
     * The Firebase library keeps the subscription and retries it by itself; safe to call at every start.
     */
    fun subscribeBroadcast(context: Context) {
        runCatching {
            if (app(context) == null) return
            val prefs = context.applicationContext.getSharedPreferences("rewire_broadcast", Context.MODE_PRIVATE)
            // Joining again is harmless (same topic); doing it daily repairs a lost or never-finished subscription.
            val last = prefs.getLong("joined_all_at", 0L)
            val now = System.currentTimeMillis()
            if (last > 0L && now - last in 0..86_400_000L) return
            com.google.firebase.messaging.FirebaseMessaging.getInstance().subscribeToTopic("all")
                .addOnSuccessListener { prefs.edit().putLong("joined_all_at", System.currentTimeMillis()).apply() }
        }
    }

    /** The settings text the admin panel saved (config/main/data), or null when there is none. Read-only. */
    suspend fun readAdminConfig(context: Context): String? = net<String?>(context) {
        signedIn(context)
        restObject(context, "config/main")?.str("data")
    }

    // ---- Helpers ---------------------------------------------------------------------------------------------

    private fun snapshotOf(s: DataSnapshot) = RequestSnapshot(
        status = s.child("status").value as? String,
        createdAt = (s.child("createdAt").value as? Number)?.toLong(),
        decidedAt = (s.child("decidedAt").value as? Number)?.toLong(),
        decidedBy = s.child("decidedBy").value as? String,
        proof = s.child("proof").value as? String,
        nonce = s.child("nonce").value as? String,
        deviceId = s.child("deviceId").value as? String,
        kind = s.child("kind").value as? String,
        pkg = s.child("pkg").value as? String,
        appName = s.child("appName").value as? String,
        reason = (s.child("reason").value as? Number)?.toInt(),
        minutes = (s.child("minutes").value as? Number)?.toLong(),
    )

    private fun observe(query: Query): Flow<DataSnapshot> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                trySend(snapshot)
            }
            override fun onCancelled(error: DatabaseError) {
                close(OnlineException(
                    if (error.code == DatabaseError.PERMISSION_DENIED) OnlineException.Kind.PERMISSION
                    else OnlineException.Kind.OTHER,
                    error.message
                ))
            }
        }
        query.addValueEventListener(listener)
        awaitClose { query.removeEventListener(listener) }
    }.retryWhen { cause, attempt ->
        // Right after a fresh sign-in the server may still treat the listener as signed out and
        // refuse it once. A moment later the same listener is accepted.
        if (cause is OnlineException && attempt < 3) {
            delay(800L * (attempt + 1))
            true
        } else {
            false
        }
    }

    private fun <T> Flow<DataSnapshot>.mapSnap(transform: (DataSnapshot) -> T): Flow<T> =
        this.map { transform(it) }

    /** Turns Firebase / timeout errors into one OnlineException with a plain-language message. */
    private suspend fun <T> guard(block: suspend () -> T): T = try {
        block()
    } catch (e: OnlineException) {
        throw e
    } catch (e: TimeoutCancellationException) {
        throw OnlineException(OnlineException.Kind.TIMEOUT, "The server took too long to answer.")
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (e: FirebaseNetworkException) {
        throw OnlineException(OnlineException.Kind.OFFLINE, "No internet connection.")
    } catch (e: FirebaseAuthException) {
        val off = e.errorCode == "ERROR_OPERATION_NOT_ALLOWED" || e.errorCode == "ERROR_ADMIN_RESTRICTED_OPERATION"
        throw OnlineException(
            OnlineException.Kind.AUTH,
            if (off) "Anonymous sign-in is turned off in Firebase Authentication." else "Sign-in failed."
        )
    } catch (e: Exception) {
        val m = e.message.orEmpty()
        throw when {
            m.contains("Permission denied", ignoreCase = true) ->
                OnlineException(OnlineException.Kind.PERMISSION, "The server refused this (permission denied).")
            m.contains("network", ignoreCase = true) || m.contains("offline", ignoreCase = true) ->
                OnlineException(OnlineException.Kind.OFFLINE, "No internet connection.")
            else -> OnlineException(OnlineException.Kind.OTHER, "Something went wrong. Try again.")
        }
    }
}
