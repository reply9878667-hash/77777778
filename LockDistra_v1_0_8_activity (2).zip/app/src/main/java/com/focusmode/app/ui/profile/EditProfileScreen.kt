package com.focusmode.app.ui.profile

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.LockSession
import com.focusmode.app.data.profile.PhotoChange
import com.focusmode.app.data.profile.ProfilePhotos
import com.focusmode.app.data.profile.ProfileResult
import com.focusmode.app.data.profile.ProfileRules
import com.focusmode.app.data.profile.UserProfile
import com.focusmode.app.ui.auth.AuthMessage
import com.focusmode.app.ui.auth.AuthTextField
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SecondaryButton
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.launch

/**
 * Edit profile: name, photo from the gallery, or one of the preset avatars. The email is shown but cannot be
 * changed here (changing it needs the person to verify the new address, which is a different feature).
 * Nothing is saved until Save; Cancel and Back throw the changes away.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditProfileScreen(
    profile: UserProfile,
    onCancel: () -> Unit,
    onSave: suspend (name: String, avatarId: String, photo: PhotoChange) -> ProfileResult,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    var name by rememberSaveable { mutableStateOf(profile.displayName) }
    var avatarId by rememberSaveable { mutableStateOf(profile.avatarId) }
    var photo by rememberSaveable { mutableStateOf(profile.photoB64) }
    var nameError by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }
    var loadingPhoto by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                loadingPhoto = true
                val b64 = ProfilePhotos.process(context, uri)
                loadingPhoto = false
                if (b64 == null) message = "That picture couldn't be used. Try another one." else {
                    photo = b64
                    message = null
                }
            }
        }
    }

    fun save() {
        if (saving || loadingPhoto) return
        focus.clearFocus()
        val clean = ProfileRules.cleanName(name)
        nameError = ProfileRules.nameError(clean)
        if (nameError != null) return
        val change = when {
            photo == profile.photoB64 -> PhotoChange.Keep
            photo == null -> PhotoChange.Remove
            else -> PhotoChange.Set(photo!!)
        }
        saving = true
        message = null
        scope.launch {
            val result = onSave(clean, avatarId, change)
            // On success the parent closes this screen; only a failure comes back here.
            saving = false
            when (result) {
                is ProfileResult.Invalid -> message = result.message
                ProfileResult.NotSignedIn -> message = "You're not logged in any more."
                is ProfileResult.Saved -> Unit
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .statusBarsPadding()
            .imePadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onCancel)
            Spacer(Modifier.size(14.dp))
            Text("Edit profile", style = MaterialTheme.typography.titleLarge)
        }

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(8.dp))
            ProfileAvatar(name, avatarId, photo, size = 112.dp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(
                    enabled = !saving && !loadingPhoto,
                    onClick = {
                        LockSession.markOwnLaunch() // the gallery is another screen; don't ask for the PIN on return
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                ) {
                    androidx.compose.material3.Icon(Icons.Rounded.PhotoCamera, null, tint = c.accent, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text(if (loadingPhoto) "Loading..." else "Choose photo", color = c.accent)
                }
                if (photo != null) {
                    TextButton(enabled = !saving, onClick = { photo = null }) { Text("Remove photo", color = c.muted) }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        SectionLabel("Or pick an avatar")
        FlowRow(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AvatarChoice(selected = photo == null && avatarId.isEmpty(), enabled = !saving, onClick = { avatarId = ""; photo = null }) {
                ProfileAvatar(name, "", null, size = 52.dp)
            }
            for (id in ProfileRules.AVATAR_IDS) {
                AvatarChoice(selected = photo == null && avatarId == id, enabled = !saving, onClick = { avatarId = id; photo = null }) {
                    ProfileAvatar(name, id, null, size = 52.dp)
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Your details")
        AuthTextField(
            value = name,
            onValueChange = { name = it.take(60); nameError = null },
            label = "Full name",
            error = nameError,
            enabled = !saving,
            last = true,
            onDone = { save() },
        )
        Spacer(Modifier.height(12.dp))
        AuthTextField(
            value = profile.email.ifBlank { "Not available" },
            onValueChange = {},
            label = "Email",
            error = null,
            enabled = false,
            keyboardType = KeyboardType.Email,
            hint = "Your sign-in email can't be changed here.",
        )

        message?.let {
            Spacer(Modifier.height(16.dp))
            AuthMessage(it, isError = true)
        }

        Spacer(Modifier.height(24.dp))
        PrimaryButton(
            text = if (saving) "Saving..." else "Save changes",
            onClick = { save() },
            enabled = !saving && !loadingPhoto,
            loading = saving,
        )
        Spacer(Modifier.height(10.dp))
        SecondaryButton("Cancel", onClick = { if (!saving) onCancel() })
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun AvatarChoice(selected: Boolean, enabled: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    val c = FocusTheme.colors
    Box(
        Modifier
            .size(62.dp)
            .border(if (selected) 3.dp else 1.dp, if (selected) c.accent else c.stroke, CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(5.dp),
        contentAlignment = Alignment.Center,
    ) { content() }
}
