package com.focusmode.app.ui

import com.focusmode.app.data.LockType
import com.focusmode.app.data.VerifyResult

/** What the lock screen and the Settings section may do. Implemented by [AppViewModel]. */
interface LockController {
    /** Checks the current PIN / password. Counts wrong tries. */
    suspend fun verify(secret: String): VerifyResult

    /** Turns the lock on and returns the one-time recovery code. */
    suspend fun enable(type: LockType, secret: String): String

    suspend fun change(type: LockType, secret: String)

    /** False when "Allow changing LockDistra settings" is off for the running session. */
    fun disable(): Boolean

    suspend fun checkRecovery(code: String): VerifyResult

    /** Sets a new PIN / password with a valid recovery code. Returns the replacement code, or null. */
    suspend fun resetWithRecovery(code: String, type: LockType, secret: String): String?

    fun newRecoveryCode(): String

    fun setBiometric(on: Boolean): Boolean

    fun setAutoLockSeconds(seconds: Int): Boolean

    fun lockoutRemainingMs(): Long

    fun recoveryLockoutRemainingMs(): Long

    fun unlock()
}
