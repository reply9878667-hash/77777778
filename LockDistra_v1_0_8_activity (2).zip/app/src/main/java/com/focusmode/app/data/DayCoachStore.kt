package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Saved Day Coach settings (file "day_coach", device-protected storage like the other stores): on / off, the day start
 * and the sleep time. It shares nothing with the Daily Tasks list, Focus Profile or Bedtime Mode.
 */
class DayCoachStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "day_coach")

    private val _state = MutableStateFlow(read())
    val state: StateFlow<CoachSettings> = _state.asStateFlow()

    fun current(): CoachSettings = read()

    private fun read() = CoachSettings(
        enabled = prefs.getBoolean(K_ENABLED, false),
        dayStartMin = DayCoachRules.clampMin(prefs.getInt(K_DAY_START, DayCoachRules.DEFAULT_DAY_START)),
        sleepMin = DayCoachRules.clampMin(prefs.getInt(K_SLEEP, DayCoachRules.DEFAULT_SLEEP)),
    )

    @Synchronized
    private fun write(next: CoachSettings) {
        prefs.edit()
            .putBoolean(K_ENABLED, next.enabled)
            .putInt(K_DAY_START, DayCoachRules.clampMin(next.dayStartMin))
            .putInt(K_SLEEP, DayCoachRules.clampMin(next.sleepMin))
            .remove(K_OLD_PLANS) // the block plans of the old Day Coach are gone
            .commit()
        _state.value = next
    }

    @Synchronized
    private fun change(edit: (CoachSettings) -> CoachSettings) = write(edit(read()))

    fun setEnabled(on: Boolean) = change { it.copy(enabled = on) }

    fun setDayStart(min: Int) = change { it.copy(dayStartMin = DayCoachRules.clampMin(min)) }

    fun setSleep(min: Int) = change { it.copy(sleepMin = DayCoachRules.clampMin(min)) }

    companion object {
        private const val K_ENABLED = "enabled"
        private const val K_DAY_START = "day_start_min"
        private const val K_SLEEP = "sleep_min"
        private const val K_OLD_PLANS = "days"

        @Volatile
        private var instance: DayCoachStore? = null

        fun get(context: Context): DayCoachStore =
            instance ?: synchronized(this) {
                instance ?: DayCoachStore(context.applicationContext).also { instance = it }
            }
    }
}
