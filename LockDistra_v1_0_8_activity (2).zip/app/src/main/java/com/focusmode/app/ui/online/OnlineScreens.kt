package com.focusmode.app.ui.online

import com.focusmode.app.data.auth.AuthRepository
import com.focusmode.app.data.auth.AuthResult
import com.focusmode.app.data.auth.AuthSession
import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PersistableBundle
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.LockSession
import com.focusmode.app.service.ApprovalNotifications
import com.focusmode.app.ui.screens.PermissionIntents
import com.focusmode.app.data.LockRules
import com.focusmode.app.data.LockState
import com.focusmode.app.data.VerifyResult
import com.focusmode.app.data.online.ApprovalItem
import com.focusmode.app.data.online.ApprovalProtocol
import com.focusmode.app.data.online.AppUnlockRules
import com.focusmode.app.data.online.JoinUi
import com.focusmode.app.data.online.OnlineManager
import com.focusmode.app.data.online.OnlineState
import com.focusmode.app.data.online.PairingUi
import com.focusmode.app.data.online.UnlockGateRules
import com.focusmode.app.data.online.UnlockMode
import com.focusmode.app.data.online.UnlockUi
import com.focusmode.app.ui.AppViewModel
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SecondaryButton
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.screens.LockScreen
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// =================================================================================================
// Small helpers
// =================================================================================================

private fun mmss(ms: Long): String {
    val total = ((ms + 999) / 1000).coerceAtLeast(0)
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
internal fun fieldColors() = FocusTheme.colors.let { c ->
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = c.text,
        unfocusedTextColor = c.text,
        focusedBorderColor = c.accent,
        unfocusedBorderColor = c.stroke,
        cursorColor = c.accent,
        focusedLabelColor = c.accent,
        unfocusedLabelColor = c.muted,
    )
}

internal fun verifyText(r: VerifyResult): String? = when (r) {
    VerifyResult.Ok -> null
    is VerifyResult.Wrong ->
        if (r.lockedForMs > 0) "Wrong. Too many tries, wait ${LockRules.formatWait(r.lockedForMs)}."
        else "Wrong. ${LockRules.triesLeftBeforePause(r.failures)} tries left before a pause."
    is VerifyResult.LockedOut -> "Too many tries. Try again in ${LockRules.formatWait(r.remainingMs)}."
    VerifyResult.Unreadable -> "That can't be checked on this phone any more."
}

@Composable
private fun ConnectionLine(manager: OnlineManager) {
    val c = FocusTheme.colors
    val connected by manager.connected.collectAsStateWithLifecycle()
    val (text, color) = when {
        !manager.configured -> "Online approval isn't set up in this build" to c.warning
        connected -> "Connected" to c.accent
        else -> "Connecting to the server..." to c.warning
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.size(8.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = color)
    }
}

/**
 * Trusted phone: makes sure an unlock-request push can really be shown, and says why not when it
 * can't (notifications off, channel off, no Android app id, token not registered). On Android 13+
 * the permission is asked once automatically, then by button.
 */
@Composable
private fun PushReadiness(manager: OnlineManager) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    var canShow by remember { mutableStateOf(ApprovalNotifications.canShow(context)) }
    var asked by remember { mutableStateOf(false) }
    val problem by manager.pushProblem.collectAsStateWithLifecycle()

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        canShow = ApprovalNotifications.canShow(context)
    }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { canShow = ApprovalNotifications.canShow(context) }

    fun allow() {
        LockSession.markOwnLaunch()
        if (Build.VERSION.SDK_INT >= 33 && !asked) {
            asked = true
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            runCatching { context.startActivity(PermissionIntents.appNotifications(context.packageName)) }
        }
    }

    LaunchedEffect(Unit) {
        if (!canShow && Build.VERSION.SDK_INT >= 33 && !asked) allow()
    }

    if (!canShow) {
        FocusCard(highlight = true) {
            Column(Modifier.fillMaxWidth()) {
                Text("Allow notifications", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Without this, unlock requests from the other phone can't pop up here. You would only see them while this app is open.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(10.dp))
                PrimaryButton("Allow notifications", onClick = { allow() }, modifier = Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(12.dp))
    }
    problem?.let {
        Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
        Spacer(Modifier.height(12.dp))
    }
}

// ---- Connector code: copy, share, paste ---------------------------------------------------------------------

private val PAIR_CODE_REGEX = Regex("([A-Za-z0-9]{5}-){3}[A-Za-z0-9]{5}")

/** Finds the connector code inside whatever was pasted (a bare code or a whole chat message). */
private fun extractPairCode(text: String): String =
    PAIR_CODE_REGEX.find(text)?.value?.uppercase() ?: text.take(30)

private fun copyCode(context: Context, code: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Connector code", code)
    if (Build.VERSION.SDK_INT >= 33) {
        // Keeps the code out of the clipboard preview Android shows on screen.
        clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
    }
    cm.setPrimaryClip(clip)
    Toast.makeText(context, "Key copied", Toast.LENGTH_SHORT).show()
}

private fun readClipboard(context: Context): String {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = cm.primaryClip ?: return ""
    if (clip.itemCount == 0) return ""
    return clip.getItemAt(0).coerceToText(context)?.toString().orEmpty()
}

private fun shareCode(context: Context, code: String) {
    // Going to the share sheet on purpose must not make the app lock ask again at once.
    LockSession.markOwnLaunch()
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(
            Intent.EXTRA_TEXT,
            "My LockDistra connector code: $code\n" +
                "Open LockDistra > Settings > Paste connector code. It works once, for 10 minutes."
        )
    }
    runCatching {
        context.startActivity(Intent.createChooser(send, "Send key").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

// =================================================================================================
// Account (Settings). Sign up, log in, Google and password reset are in ui/auth (AuthFlow).
// =================================================================================================

/** Settings > Account: who is logged in, Log out, or the button that opens the account screens. */
@Composable
fun AccountSection(manager: OnlineManager, onOpenAuth: () -> Unit = {}, onOpenProfile: (() -> Unit)? = null) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val auth = remember { AuthRepository.get(context) }
    val session by auth.session.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var confirmLogout by remember { mutableStateOf(false) }
    var loggingOut by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val onlineState by manager.state.collectAsStateWithLifecycle()

    FocusCard {
        Column(Modifier.fillMaxWidth()) {
            val current = session
            when {
                !manager.configured -> Text(
                    "Accounts aren't set up in this build.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.muted
                )
                current is AuthSession.SignedIn -> {
                    Text(current.user.name, style = MaterialTheme.typography.titleMedium)
                    if (current.user.email.isNotBlank()) {
                        Text(current.user.email, style = MaterialTheme.typography.bodySmall, color = c.muted)
                    }
                    Text(
                        "Logged in with ${current.user.provider.label}",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Your trusted phone shows this name on your unlock requests.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                    Spacer(Modifier.height(10.dp))
                    if (onOpenProfile != null) {
                        PrimaryButton("View profile", onClick = onOpenProfile, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                    }
                    SecondaryButton(
                        if (loggingOut) "Logging out..." else "Log out",
                        onClick = { if (!loggingOut) { message = null; confirmLogout = true } },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                else -> {
                    Text("Not logged in", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Log in so your trusted phone shows your name instead of a phone model.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                    Spacer(Modifier.height(10.dp))
                    PrimaryButton("Log in or create account", onClick = { message = null; onOpenAuth() }, modifier = Modifier.fillMaxWidth())
                }
            }
            message?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
        }
    }

    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = { Text("Log out?") },
            text = {
                Text(
                    if (onlineState.phoneConnected || onlineState.isApprover)
                        "You can log in again any time. Blocking and limits keep working. Your trusted phone connection stays saved on the server and comes back when you log in with this account again."
                    else "You can log in again any time. Blocking and limits keep working."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmLogout = false
                    loggingOut = true
                    scope.launch {
                        val result = auth.signOut()
                        loggingOut = false
                        if (result is AuthResult.Failure) message = result.message
                    }
                }) { Text("Log out", color = c.accent) }
            },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text("Cancel", color = c.muted) } },
            containerColor = c.card,
        )
    }
}

// =================================================================================================
// Lock screen pieces
// =================================================================================================

/** The screen in front of the app. Chooses what to offer from the unlock method. */
@Composable
fun GateScreen(vm: AppViewModel, lock: LockState, online: OnlineState) {
    val methods = UnlockGateRules.methods(online.mode, lock.enabled)
    when {
        methods.password && methods.online -> LockScreen(
            controller = vm,
            lock = lock,
            onUnlocked = {},
            extraContent = {
                OrDivider()
                OnlineUnlockPanel(manager = vm.online, online = online, showRecovery = false)
            },
        )
        methods.online -> OnlineLockScreen(manager = vm.online, online = online)
        else -> LockScreen(controller = vm, lock = lock, onUnlocked = {})
    }
}

@Composable
private fun OrDivider() {
    val c = FocusTheme.colors
    Row(
        Modifier.fillMaxWidth().padding(vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(Modifier.weight(1f).height(1.dp).background(c.stroke))
        Text("  or  ", style = MaterialTheme.typography.labelSmall, color = c.muted)
        Box(Modifier.weight(1f).height(1.dp).background(c.stroke))
    }
}

/** Full screen for "Online approval" only. */
@Composable
fun OnlineLockScreen(manager: OnlineManager, online: OnlineState) {
    val c = FocusTheme.colors
    Column(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.focusmode.app.R.drawable.ic_lockdistra_logo),
            contentDescription = "LockDistra",
            modifier = Modifier.size(96.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp))
        )
        Spacer(Modifier.height(20.dp))
        Text("LockDistra is locked", style = MaterialTheme.typography.titleLarge, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "Ask your trusted phone to unlock it",
            style = MaterialTheme.typography.bodyMedium,
            color = c.muted
        )
        Text(
            "Powered by Re Arena  \u00B7  By Prince Yadav",
            style = MaterialTheme.typography.labelSmall,
            color = c.muted.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 4.dp)
        )
        Spacer(Modifier.height(28.dp))
        OnlineUnlockPanel(manager = manager, online = online, showRecovery = true)
        Spacer(Modifier.height(24.dp))
    }
}

/**
 * The "Request to Unlock" button and everything that follows it: sending, waiting with a countdown,
 * approved, rejected, expired and errors. Approval opens the app by itself (OnlineManager unlocks).
 */
@Composable
fun OnlineUnlockPanel(
    manager: OnlineManager,
    online: OnlineState,
    showRecovery: Boolean,
    /** True when the request is for "Prevent changes" instead of the lock screen. */
    forChanges: Boolean = false,
    /** True when the request is to turn Focus Mode OFF. */
    forFocusOff: Boolean = false,
) {
    val c = FocusTheme.colors
    val ui by manager.unlockUi.collectAsStateWithLifecycle()
    val connected by manager.connected.collectAsStateWithLifecycle()
    var showRecoveryDialog by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(manager.serverNow()) }

    DisposableEffect(Unit) {
        manager.start()
        onDispose {}
    }
    LaunchedEffect(ui) {
        while (ui is UnlockUi.Waiting) {
            now = manager.serverNow()
            delay(500)
        }
    }

    // The approval itself opens the app (OnlineManager does it) and clears "Approved" by itself.
    // This screen must NOT act on a leftover "Approved": after the app opened, this screen left
    // the composition before it could clear it, so the next lock screen used to open by itself.

    val phone = online.approverName ?: "your trusted phone"
    val busy = ui is UnlockUi.Sending || ui is UnlockUi.Waiting || ui is UnlockUi.Approved

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        FocusCard(
            modifier = Modifier.fillMaxWidth(),
            highlight = ui is UnlockUi.Waiting || ui is UnlockUi.Approved,
        ) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape).background(c.accentSoft),
                    contentAlignment = Alignment.Center
                ) {
                    when (ui) {
                        is UnlockUi.Sending, is UnlockUi.Waiting ->
                            CircularProgressIndicator(color = c.accent, strokeWidth = 3.dp, modifier = Modifier.size(28.dp))
                        is UnlockUi.Approved -> Icon(Icons.Rounded.Check, null, tint = c.accent, modifier = Modifier.size(30.dp))
                        is UnlockUi.Rejected, is UnlockUi.Failed, is UnlockUi.Expired ->
                            Icon(Icons.Rounded.Close, null, tint = c.warning, modifier = Modifier.size(30.dp))
                        else -> Icon(Icons.Rounded.PhoneAndroid, null, tint = c.accent, modifier = Modifier.size(28.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    when (ui) {
                        UnlockUi.Idle -> "Online approval"
                        UnlockUi.Sending -> "Sending request..."
                        is UnlockUi.Waiting -> "Waiting for approval"
                        UnlockUi.Approved -> "Approved"
                        UnlockUi.Rejected -> "Request rejected"
                        UnlockUi.Expired -> "Request expired"
                        is UnlockUi.Failed -> "Couldn't unlock"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    color = c.text
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    when (val s = ui) {
                        UnlockUi.Idle ->
                            if (!online.phoneConnected) "No trusted phone is connected on this phone."
                            else if (forFocusOff) "Send a request to $phone. Approve it there to turn Focus Mode OFF."
                            else if (forChanges) "Send a request to $phone. Approve it there and changes open for 5 minutes."
                            else "Send a request to $phone. Approve it there and LockDistra opens."
                        UnlockUi.Sending -> "Contacting the server."
                        is UnlockUi.Waiting -> "Open LockDistra on $phone and tap Approve.  ${mmss(s.expiresAt - now)} left"
                        UnlockUi.Approved -> if (forFocusOff) "Approved. Turning Focus Mode OFF..." else if (forChanges) "Changes are open." else "Opening LockDistra..."
                        UnlockUi.Rejected -> "$phone rejected this request. ${if (forFocusOff) "Focus Mode stays ON." else if (forChanges) "Changes stay locked." else "LockDistra stays locked."}"
                        UnlockUi.Expired -> "Nobody answered in time. ${if (forFocusOff) "Focus Mode stays ON." else if (forChanges) "Changes stay locked." else "LockDistra stays locked."}"
                        is UnlockUi.Failed -> s.message
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (ui is UnlockUi.Rejected || ui is UnlockUi.Failed || ui is UnlockUi.Expired) c.warning else c.muted,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(10.dp))
                ConnectionLine(manager)
            }
        }
        Spacer(Modifier.height(14.dp))
        PrimaryButton(
            text = when (ui) {
                UnlockUi.Sending -> "Sending..."
                is UnlockUi.Waiting -> "Waiting..."
                UnlockUi.Approved -> if (forFocusOff) "Approved" else if (forChanges) "Done" else "Opening..."
                UnlockUi.Rejected, UnlockUi.Expired, is UnlockUi.Failed -> "Request again"
                UnlockUi.Idle -> if (forChanges || forFocusOff) "Ask trusted phone" else "Request to Unlock"
            },
            onClick = {
                manager.resetUnlock()
                manager.requestUnlock(forChanges, forFocusOff)
            },
            enabled = !busy && online.phoneConnected && manager.configured,
            icon = Icons.Rounded.PhoneAndroid,
        )
        if (ui is UnlockUi.Waiting) {
            TextButton(onClick = { manager.cancelUnlock() }) { Text("Cancel request", color = c.muted) }
        }
        if (showRecovery) {
            TextButton(onClick = { showRecoveryDialog = true }) {
                Text("Trusted phone not available? Use recovery code", color = c.muted)
            }
        }
        if (!connected && manager.configured && ui is UnlockUi.Idle) {
            Text(
                "Slow connection. The request will still be sent.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted,
                textAlign = TextAlign.Center
            )
        }
    }

    if (showRecoveryDialog) OnlineRecoveryDialog(manager) { showRecoveryDialog = false }
}

/** Opens the app with the offline recovery code made when the trusted phone was connected. */
@Composable
private fun OnlineRecoveryDialog(manager: OnlineManager, onDismiss: () -> Unit) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var waitMs by remember { mutableLongStateOf(manager.recoveryLockoutRemainingMs()) }

    LaunchedEffect(waitMs > 0) {
        while (waitMs > 0) {
            delay(500)
            waitMs = manager.recoveryLockoutRemainingMs()
        }
    }

    fun submit() {
        if (busy || waitMs > 0 || code.isBlank()) return
        busy = true
        scope.launch {
            val r = manager.unlockWithRecovery(code)
            busy = false
            code = ""
            if (r == VerifyResult.Ok) onDismiss()
            else {
                waitMs = manager.recoveryLockoutRemainingMs()
                error = verifyText(r)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Recovery code", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Type the recovery code you saved when you connected the trusted phone.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.take(24); error = null },
                    label = { Text("XXXX-XXXX-XXXX-XXXX") },
                    singleLine = true,
                    enabled = !busy && waitMs == 0L,
                    colors = fieldColors(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                val message = if (waitMs > 0) "Too many tries. Try again in ${LockRules.formatWait(waitMs)}." else error
                message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && waitMs == 0L, onClick = { submit() }) {
                Text(if (busy) "Checking..." else "Unlock", color = c.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}

// =================================================================================================
// Settings: unlock method + trusted phones
// =================================================================================================

/**
 * "Unlock method" card (Password / Online approval / Both) plus the trusted-phone cards.
 * Lowering protection (leaving Online approval, disconnecting the trusted phone) asks for the
 * recovery code or the current PIN / password first, like turning the app lock off does.
 */
@Composable
fun UnlockModeSection(
    manager: OnlineManager,
    lock: LockState,
    settingsLocked: Boolean,
    canChangeSettings: () -> Boolean,
    onOpenApprovals: () -> Unit,
) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    val online by manager.state.collectAsStateWithLifecycle()

    var note by remember { mutableStateOf<String?>(null) }
    var pendingMode by remember { mutableStateOf<UnlockMode?>(null) }
    var askDisconnect by remember { mutableStateOf(false) }
    var authFor by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showPairing by remember { mutableStateOf(false) }
    var showJoin by remember { mutableStateOf(false) }
    var confirmDisconnectApprover by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { manager.start() }

    fun choose(m: UnlockMode) {
        note = null
        if (m == online.mode) return
        if (!canChangeSettings()) { note = "Locked right now (focus session or Prevent changes)."; return }
        if (manager.isWeakening(m)) {
            pendingMode = m
            authFor = { note = manager.setMode(m); pendingMode = null }
            return
        }
        note = manager.setMode(m)
    }

    FocusCard {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PhoneAndroid, null, tint = c.accent, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Unlock method", style = MaterialTheme.typography.titleMedium)
                    Text(
                        when (online.mode) {
                            UnlockMode.PASSWORD -> "Password only"
                            UnlockMode.ONLINE -> "Online approval only"
                            UnlockMode.BOTH -> "Password or online approval"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = c.accent
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SoftChip("Password", online.mode == UnlockMode.PASSWORD, { choose(UnlockMode.PASSWORD) })
                SoftChip("Online", online.mode == UnlockMode.ONLINE, { choose(UnlockMode.ONLINE) })
                SoftChip("Both", online.mode == UnlockMode.BOTH, { choose(UnlockMode.BOTH) })
            }
            Spacer(Modifier.height(12.dp))
            Text(
                when (online.mode) {
                    UnlockMode.PASSWORD -> "LockDistra opens with your PIN or password (App lock above), as before."
                    UnlockMode.ONLINE -> "LockDistra opens only when your trusted phone approves a request. The recovery code is the backup."
                    UnlockMode.BOTH -> "Either way opens LockDistra: your PIN or password, or an approval from your trusted phone."
                },
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            if (settingsLocked) {
                Spacer(Modifier.height(8.dp))
                Text("Locked right now (focus session or Prevent changes).", style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
            note?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
            Spacer(Modifier.height(12.dp))
            ConnectionLine(manager)
            if (manager.configured && !manager.pushConfigured) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Push alerts are off (no Worker URL in this build): the trusted phone sees requests only while LockDistra is open on it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }
    }

    Spacer(Modifier.height(12.dp))
    SectionLabel("Trusted phone")
    FocusCard {
        Column {
            if (online.phoneConnected) {
                Text("Connected: ${online.approverName ?: "Trusted phone"}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Only this phone can approve or reject unlock requests for this phone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SoftChip("Disconnect", false, {
                        note = null
                        if (!canChangeSettings()) { note = "Locked right now (focus session or Prevent changes)."; return@SoftChip }
                        manager.disconnectBlockedReason()?.let { note = it; return@SoftChip }
                        if (online.mode.usesOnline) {
                            authFor = { scope.launch { manager.disconnectTrustedPhone() } }
                            pendingMode = UnlockMode.PASSWORD
                        } else {
                            askDisconnect = true
                        }
                    })
                    SoftChip("New connecting key", false, {
                        note = null
                        if (!canChangeSettings()) note = "Locked right now (focus session or Prevent changes)." else showPairing = true
                    })
                }
            } else {
                Text("No trusted phone connected", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Make a private key here, send it to your second phone and paste it there. Only that phone can then approve your unlock requests.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton(
                    text = "Generate my private connecting key",
                    onClick = {
                        note = null
                        if (!canChangeSettings()) note = "Locked right now (focus session or Prevent changes)."
                        else if (!manager.configured) note = "Online approval isn't set up in this build."
                        else showPairing = true
                    },
                    icon = Icons.Rounded.PhoneAndroid,
                )
            }
        }
    }

    Spacer(Modifier.height(12.dp))
    FocusCard {
        Column {
            if (online.isApprover) {
                Text("This phone is a trusted phone", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "It approves or rejects unlock requests from ${online.ownerName ?: "the other phone"}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SoftChip("Open requests", true, onOpenApprovals)
                    SoftChip("Stop", false, { confirmDisconnectApprover = true })
                }
            } else {
                Text("Use this phone as a trusted phone", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Paste the connector code you got from the other phone. This phone will then approve its unlock requests.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(12.dp))
                SecondaryButton("Paste connector code", onClick = {
                    if (manager.configured) showJoin = true else note = "Online approval isn't set up in this build."
                })
            }
        }
    }

    // ---- Dialogs ----
    if (pendingMode != null && authFor != null) {
        AuthorizeDialog(
            manager = manager,
            onAuthorized = {
                val go = authFor
                authFor = null
                pendingMode = null
                go?.invoke()
            },
            onDismiss = { authFor = null; pendingMode = null },
        )
    }

    if (askDisconnect) {
        ConfirmDialog(
            title = "Disconnect trusted phone?",
            text = "This phone will no longer send unlock requests to it.",
            confirm = "Disconnect",
            onConfirm = { askDisconnect = false; scope.launch { manager.disconnectTrustedPhone() } },
            onDismiss = { askDisconnect = false },
        )
    }

    if (confirmDisconnectApprover) {
        ConfirmDialog(
            title = "Stop approving?",
            text = "The other phone will have to be connected to a trusted phone again.",
            confirm = "Stop",
            onConfirm = { confirmDisconnectApprover = false; scope.launch { manager.disconnectAsApprover() } },
            onDismiss = { confirmDisconnectApprover = false },
        )
    }

    if (showPairing) PairingDialog(manager) { showPairing = false }
    if (showJoin) JoinDialog(manager) { showJoin = false }
}

@Composable
private fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = FocusTheme.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = { Text(text, style = MaterialTheme.typography.bodyMedium) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = c.accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}

/** Recovery code, or the PIN / password, before protection is lowered. */
@Composable
private fun AuthorizeDialog(manager: OnlineManager, onAuthorized: () -> Unit, onDismiss: () -> Unit) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun submit() {
        if (busy || input.isBlank()) return
        busy = true
        scope.launch {
            val r = manager.authorizeChange(input)
            busy = false
            input = ""
            if (r == VerifyResult.Ok) onAuthorized() else error = verifyText(r)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Confirm it's you", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "This lowers protection. Enter your recovery code, or your PIN / password if the App lock is on.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(40); error = null },
                    label = { Text("Recovery code or PIN / password") },
                    singleLine = true,
                    enabled = !busy,
                    colors = fieldColors(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = { submit() }) {
                Text(if (busy) "Checking..." else "Confirm", color = c.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}

// =================================================================================================
// Pairing dialogs
// =================================================================================================

/**
 * The "Connect this phone?" question, shown on any screen while a second phone is waiting to be
 * accepted. Yes finishes the connection; No turns that phone down.
 */
@Composable
fun PairingConfirmHost(manager: OnlineManager) {
    val c = FocusTheme.colors
    val ui by manager.pairingUi.collectAsStateWithLifecycle()
    val s = ui as? PairingUi.ConfirmPhone ?: return
    AlertDialog(
        onDismissRequest = {},
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Connect this phone?", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    "\"${s.deviceName}\" entered your connector code.",
                    style = MaterialTheme.typography.titleMedium,
                    color = c.text
                )
                Text(
                    "Make it your trusted phone? Only say yes if you just typed the code on it yourself.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { manager.confirmPairing(true) }) { Text("Yes, connect", color = c.accent) }
        },
        dismissButton = {
            TextButton(onClick = { manager.confirmPairing(false) }) { Text("No", color = c.muted) }
        }
    )
}

/** Locked phone: shows the code, waits for the trusted phone, asks "Connect it?", shows the recovery code. */
@Composable
private fun PairingDialog(manager: OnlineManager, onClose: () -> Unit) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val ui by manager.pairingUi.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { manager.startPairing() }
    // The question itself is asked by PairingConfirmHost. If the answer is No, this dialog ends too.
    var wasAsking by remember { mutableStateOf(false) }
    LaunchedEffect(ui) {
        if (ui is PairingUi.ConfirmPhone) wasAsking = true
        else if (wasAsking) {
            wasAsking = false
            if (ui is PairingUi.Idle) onClose()
        }
    }

    fun close() {
        manager.cancelPairing()
        manager.clearPairingResult()
        onClose()
    }

    // While the question is up (PairingConfirmHost), this dialog steps aside so there is only one.
    if (ui is PairingUi.ConfirmPhone) return

    val done = ui as? PairingUi.Done
    if (done != null) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Trusted phone connected", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "Your recovery code. If the trusted phone is lost or offline, this code opens LockDistra. It is shown only once.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    FocusCard(padding = PaddingValues(16.dp)) {
                        Text(
                            done.recoveryCode,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = c.text,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Text(
                        "Write it on paper and keep it away from this phone. LockDistra only keeps a scrambled version. Now choose \"Online\" or \"Both\" under Unlock method.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { manager.clearPairingResult(); onClose() }) {
                    Text("I wrote it down", color = c.accent)
                }
            },
        )
        return
    }

    AlertDialog(
        onDismissRequest = { if (ui !is PairingUi.Linking) close() },
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("My private connecting key", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                when (val s = ui) {
                    PairingUi.Idle, PairingUi.Creating -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(color = c.accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.size(12.dp))
                            Text("Making your key...", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    is PairingUi.WaitingForPhone -> {
                        Text(
                            "Send this key to your second phone. There, open LockDistra > Settings > \"Paste connector code\" and paste it. You can leave the app: a notification will ask you to accept when the second phone connects.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        FocusCard(padding = PaddingValues(16.dp), highlight = true) {
                            Text(
                                s.code,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = c.text,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SecondaryButton("Copy key", onClick = { copyCode(context, s.code) }, modifier = Modifier.weight(1f))
                            SecondaryButton("Share", onClick = { shareCode(context, s.code) }, modifier = Modifier.weight(1f))
                        }
                        Text(
                            "The key works once and for 10 minutes. Send it only to the phone you want approving your unlocks.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        ConnectionLine(manager)
                    }
                    is PairingUi.ConfirmPhone -> {
                        Text(
                            "\"${s.deviceName}\" entered your code.",
                            style = MaterialTheme.typography.titleMedium,
                            color = c.text
                        )
                        Text(
                            "Make it your trusted phone? Only say yes if you just typed the code on it yourself.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    PairingUi.Linking -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = c.accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.size(12.dp))
                        Text("Connecting...", style = MaterialTheme.typography.bodyMedium)
                    }
                    is PairingUi.Failed -> Text(s.message, style = MaterialTheme.typography.bodyMedium, color = c.warning)
                    is PairingUi.Done -> Unit
                }
            }
        },
        confirmButton = {
            when (ui) {
                is PairingUi.ConfirmPhone -> TextButton(onClick = { manager.confirmPairing(true) }) {
                    Text("Yes, connect", color = c.accent)
                }
                is PairingUi.Failed -> TextButton(onClick = { manager.clearPairingResult(); manager.startPairing() }) {
                    Text("Try again", color = c.accent)
                }
                else -> Unit
            }
        },
        dismissButton = {
            when (ui) {
                is PairingUi.ConfirmPhone -> TextButton(onClick = { manager.confirmPairing(false); close() }) {
                    Text("No", color = c.muted)
                }
                PairingUi.Linking -> Unit
                else -> TextButton(onClick = { close() }) { Text("Cancel", color = c.muted) }
            }
        }
    )
}

/** Trusted phone: types the code shown on the locked phone. */
@Composable
private fun JoinDialog(manager: OnlineManager, onClose: () -> Unit) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val ui by manager.joinUi.collectAsStateWithLifecycle()
    var code by remember { mutableStateOf("") }

    fun close() {
        manager.cancelJoin()
        manager.clearJoinResult()
        onClose()
    }

    AlertDialog(
        onDismissRequest = { if (ui !is JoinUi.Working) close() },
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Connector code", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (val s = ui) {
                    is JoinUi.Done -> {
                        Text(
                            "Done. This phone now approves unlock requests from ${s.ownerName}.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        PushReadiness(manager)
                    }
                    is JoinUi.Working -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = c.accent, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.size(12.dp))
                        Text(s.message, style = MaterialTheme.typography.bodyMedium)
                    }
                    else -> {
                        Text(
                            "Paste the connector code you got from the other phone (or type it).",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        SecondaryButton(
                            "Paste connector code",
                            onClick = {
                                val pasted = readClipboard(context)
                                if (pasted.isNotBlank()) code = extractPairCode(pasted)
                                else Toast.makeText(context, "Nothing copied yet", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = extractPairCode(it) },
                            label = { Text("XXXXX-XXXXX-XXXXX-XXXXX") },
                            singleLine = true,
                            colors = fieldColors(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        (s as? JoinUi.Failed)?.let {
                            Text(it.message, style = MaterialTheme.typography.bodySmall, color = c.warning)
                        }
                    }
                }
            }
        },
        confirmButton = {
            when (ui) {
                is JoinUi.Done -> TextButton(onClick = { close() }) { Text("OK", color = c.accent) }
                is JoinUi.Working -> Unit
                else -> TextButton(onClick = { manager.clearJoinResult(); manager.joinPairing(code) }) {
                    Text("Connect", color = c.accent)
                }
            }
        },
        dismissButton = {
            if (ui !is JoinUi.Done) TextButton(onClick = { close() }) { Text("Cancel", color = c.muted) }
        }
    )
}

// =================================================================================================
// Trusted phone: requests
// =================================================================================================

/** The trusted phone's list of open unlock requests with Approve and Reject. */
@Composable
fun ApprovalsScreen(manager: OnlineManager, onBack: () -> Unit) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    val online by manager.state.collectAsStateWithLifecycle()
    val items by manager.approvals.collectAsStateWithLifecycle()
    val error by manager.approverError.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(manager.serverNow()) }
    var message by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)
    LaunchedEffect(online.isApprover) { manager.start() }
    // Listen only while this screen is open (and for the push window); let go when it closes.
    DisposableEffect(Unit) {
        manager.openApproverScreen()
        onDispose { manager.closeApproverScreen() }
    }
    LaunchedEffect(Unit) {
        while (true) {
            now = manager.serverNow()
            delay(500)
        }
    }

    val open = items.filter { it.expiresAt > now }

    Column(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Text("Unlock requests", style = MaterialTheme.typography.titleLarge)
        }

        if (!online.isApprover) {
            FocusCard {
                Text(
                    "This phone is not a trusted phone. Connect it under Settings > Trusted phone.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.muted
                )
            }
            return@Column
        }

        ConnectionLine(manager)
        Spacer(Modifier.height(12.dp))
        PushReadiness(manager)
        (error ?: message)?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            Spacer(Modifier.height(12.dp))
        }

        if (open.isEmpty()) {
            FocusCard {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.PhoneAndroid, null, tint = c.muted, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("No requests right now", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "When ${online.ownerName ?: "the other phone"} asks to unlock, it shows up here at once.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        open.forEach { item ->
            ApprovalCard(
                item = item,
                left = item.expiresAt - now,
                busy = working == item.id,
                onAnswer = { approve, minutes ->
                    message = null
                    working = item.id
                    scope.launch {
                        message = manager.answer(item, approve, minutes)
                        working = null
                    }
                }
            )
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** [onAnswer] gets (approve, minutes). Minutes only matter for "more time in one app" requests. */
@Composable
private fun ApprovalCard(item: ApprovalItem, left: Long, busy: Boolean, onAnswer: (Boolean, Int) -> Unit) {
    val c = FocusTheme.colors
    // "More time in one app": the trusted phone types how long. Quick picks fill the box.
    var minutesText by remember(item.id) { mutableStateOf("15") }
    val minutes = AppUnlockRules.parseMinutes(minutesText)
    FocusCard(highlight = true) {
        Column(Modifier.fillMaxWidth()) {
            if (item.isApp) {
                val app = item.appName?.ifBlank { null } ?: "an app"
                Text("${item.deviceName} wants more time in $app", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "$app is closed because ${AppUnlockRules.reasonText(item.reason)}. " +
                        "Type how long to open it for, then approve. Expires in ${mmss(left)}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(5, 15, 30, 60).forEach { m ->
                        SoftChip(AppUnlockRules.describe(m), selected = minutes == m, onClick = { minutesText = m.toString() })
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = minutesText,
                    onValueChange = { minutesText = it.filter { ch -> ch.isDigit() }.take(3) },
                    label = { Text("Minutes (1 to ${ApprovalProtocol.MAX_GRANT_MIN})") },
                    singleLine = true,
                    enabled = !busy,
                    colors = fieldColors(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                if (minutes == null && minutesText.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Use a whole number from ${ApprovalProtocol.MIN_GRANT_MIN} to ${ApprovalProtocol.MAX_GRANT_MIN}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.warning
                    )
                }
            } else {
                Text("${item.deviceName} wants to unlock LockDistra", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Approve only if this is you or someone you trust. Expires in ${mmss(left)}.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                SecondaryButton("Reject", onClick = { if (!busy) onAnswer(false, 0) }, modifier = Modifier.weight(1f))
                PrimaryButton(
                    text = when {
                        busy -> "Sending..."
                        item.isApp && minutes != null -> "Approve ${AppUnlockRules.describe(minutes)}"
                        else -> "Approve"
                    },
                    onClick = { onAnswer(true, minutes ?: 0) },
                    enabled = !busy && (!item.isApp || minutes != null),
                    modifier = Modifier.weight(1f),
                    icon = Icons.Rounded.Check,
                )
            }
        }
    }
}
