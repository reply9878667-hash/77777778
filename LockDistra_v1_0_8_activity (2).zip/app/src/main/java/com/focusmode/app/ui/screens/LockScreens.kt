package com.focusmode.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.CancellationSignal
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Backspace
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.data.LockRules
import com.focusmode.app.data.LockState
import com.focusmode.app.data.LockType
import com.focusmode.app.data.VerifyResult
import com.focusmode.app.ui.Biometrics
import com.focusmode.app.ui.LockController
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// =================================================================================================
// Shared pieces
// =================================================================================================

internal fun Context.findActivity(): Activity? {
    var ctx: Context? = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

private fun typeNoun(type: LockType) = if (type == LockType.PIN) "PIN" else "password"

@Composable
private fun fieldColors() = FocusTheme.colors.let { c ->
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = c.text,
        unfocusedTextColor = c.text,
        focusedBorderColor = c.accent,
        unfocusedBorderColor = c.stroke,
        cursorColor = c.accent,
        focusedLabelColor = c.accent,
        unfocusedLabelColor = c.muted,
        focusedPlaceholderColor = c.muted,
        unfocusedPlaceholderColor = c.muted,
    )
}

/** One PIN or password entry box. A PIN only takes digits. */
@Composable
private fun SecretField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    type: LockType,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Done,
    onDone: () -> Unit = {},
    enabled: Boolean = true,
) {
    val c = FocusTheme.colors
    var visible by rememberSaveable { mutableStateOf(false) }
    val max = if (type == LockType.PIN) LockRules.PIN_MAX else LockRules.PASSWORD_MAX
    OutlinedTextField(
        value = value,
        onValueChange = { raw ->
            val cleaned = if (type == LockType.PIN) raw.filter { it in '0'..'9' } else raw
            onChange(cleaned.take(max))
        },
        label = { Text(label) },
        singleLine = true,
        enabled = enabled,
        modifier = modifier.fillMaxWidth(),
        colors = fieldColors(),
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(
            keyboardType = if (type == LockType.PIN) KeyboardType.NumberPassword else KeyboardType.Password,
            imeAction = imeAction,
        ),
        keyboardActions = KeyboardActions(onDone = { onDone() }, onNext = { onDone() }),
        trailingIcon = {
            IconButton(onClick = { visible = !visible }) {
                Icon(
                    if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                    if (visible) "Hide" else "Show",
                    tint = c.muted
                )
            }
        },
    )
}

/** Holds what the person typed while choosing a new PIN or password. */
@Stable
class SecretDraft(initial: LockType) {
    var type by mutableStateOf(initial)
    var first by mutableStateOf("")
    var second by mutableStateOf("")
    var error by mutableStateOf<String?>(null)

    fun switchTo(newType: LockType) {
        if (newType == type) return
        type = newType
        first = ""
        second = ""
        error = null
    }

    /** True when the two entries match and follow the rules. Sets [error] otherwise. */
    fun validate(): Boolean {
        val problem = LockRules.validate(type, first)
            ?: if (first != second) "The two entries don't match." else null
        error = problem
        return problem == null
    }
}

@Composable
private fun rememberSecretDraft(initial: LockType = LockType.PIN) = remember { SecretDraft(initial) }

@Composable
private fun NewSecretFields(draft: SecretDraft, allowTypeChoice: Boolean = true) {
    val c = FocusTheme.colors
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (allowTypeChoice) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SoftChip("PIN", draft.type == LockType.PIN, { draft.switchTo(LockType.PIN) })
                SoftChip("Password", draft.type == LockType.PASSWORD, { draft.switchTo(LockType.PASSWORD) })
            }
        }
        Text(
            if (draft.type == LockType.PIN)
                "${LockRules.PIN_MIN} to ${LockRules.PIN_MAX} digits."
            else
                "${LockRules.PASSWORD_MIN} to ${LockRules.PASSWORD_MAX} characters.",
            style = MaterialTheme.typography.bodySmall,
            color = c.muted
        )
        SecretField(
            value = draft.first,
            onChange = { draft.first = it; draft.error = null },
            label = "New ${typeNoun(draft.type)}",
            type = draft.type,
            imeAction = ImeAction.Next,
        )
        SecretField(
            value = draft.second,
            onChange = { draft.second = it; draft.error = null },
            label = "Repeat ${typeNoun(draft.type)}",
            type = draft.type,
        )
        draft.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
    }
}

private fun verifyMessage(r: VerifyResult, noun: String): String? = when (r) {
    VerifyResult.Ok -> null
    is VerifyResult.Wrong ->
        if (r.lockedForMs > 0) "Wrong $noun. Too many tries, wait ${LockRules.formatWait(r.lockedForMs)}."
        else {
            val left = LockRules.triesLeftBeforePause(r.failures)
            "Wrong $noun. " + if (left > 0) "$left ${if (left == 1) "try" else "tries"} left before a pause." else ""
        }
    is VerifyResult.LockedOut -> "Too many tries. Try again in ${LockRules.formatWait(r.remainingMs)}."
    VerifyResult.Unreadable -> "The saved $noun can't be read. Use \"Forgot\" on the lock screen."
}

// =================================================================================================
// Lock screen
// =================================================================================================

/**
 * Covers everything in LockDistra until the PIN / password (or fingerprint) is right. It sits in
 * front of the dashboard, settings and emergency limits, whichever way the app was opened.
 */
@Composable
fun LockScreen(
    controller: LockController,
    lock: LockState,
    onUnlocked: () -> Unit,
    /** Extra block under the buttons (used for "Online approval" when both methods are on). */
    extraContent: @Composable () -> Unit = {},
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var waitMs by remember { mutableLongStateOf(controller.lockoutRemainingMs()) }
    var showForgot by rememberSaveable { mutableStateOf(false) }
    val noun = typeNoun(lock.type)

    // Counts a pause down on screen; it also survives closing the app (see LockStore).
    LaunchedEffect(waitMs > 0) {
        while (waitMs > 0) {
            delay(500)
            waitMs = controller.lockoutRemainingMs()
            if (waitMs == 0L) error = null
        }
    }

    fun submit() {
        if (busy || entry.isEmpty() || waitMs > 0) return
        busy = true
        val secret = entry
        scope.launch {
            val r = controller.verify(secret)
            busy = false
            entry = ""
            when (r) {
                VerifyResult.Ok -> {
                    controller.unlock()
                    onUnlocked()
                }
                is VerifyResult.Wrong -> {
                    waitMs = controller.lockoutRemainingMs()
                    error = if (waitMs > 0) null else verifyMessage(r, noun)
                }
                is VerifyResult.LockedOut -> {
                    waitMs = r.remainingMs
                    error = null
                }
                VerifyResult.Unreadable -> error = verifyMessage(r, noun)
            }
        }
    }

    // Fingerprint / biometric, offered as soon as the lock screen shows.
    val activity = context.findActivity()
    val bioAvailable = remember { Biometrics.isAvailable(context) }
    val bioReady = lock.biometric && activity != null && bioAvailable
    var signal by remember { mutableStateOf<CancellationSignal?>(null) }
    fun askBiometric() {
        val a = activity ?: return
        signal?.cancel()
        signal = Biometrics.prompt(
            activity = a,
            title = "Unlock LockDistra",
            subtitle = "Use your fingerprint",
            cancelText = "Use $noun",
            onSuccess = {
                controller.unlock()
                onUnlocked()
            },
            onFailure = {},
        )
    }
    LaunchedEffect(bioReady) {
        if (bioReady) {
            delay(300)
            askBiometric()
        }
    }
    DisposableEffect(Unit) { onDispose { signal?.cancel() } }

    Column(
        Modifier
            .fillMaxSize()
            .background(c.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        androidx.compose.foundation.Image(
            painter = androidx.compose.ui.res.painterResource(com.focusmode.app.R.drawable.ic_lockdistra_logo),
            contentDescription = "LockDistra",
            modifier = Modifier.size(96.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp))
        )
        Spacer(Modifier.height(20.dp))
        Text("LockDistra is locked", style = MaterialTheme.typography.titleLarge, color = c.text)
        Spacer(Modifier.height(6.dp))
        Text(
            "Enter your $noun to continue",
            style = MaterialTheme.typography.bodyMedium,
            color = c.muted
        )
        Text(
            "Powered by Re Arena  \u00B7  By Prince Yadav",
            style = MaterialTheme.typography.labelSmall,
            color = c.muted.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 4.dp)
        )
        Spacer(Modifier.height(24.dp))

        if (lock.type == LockType.PIN) {
            PinDots(count = entry.length)
        } else {
            SecretField(
                value = entry,
                onChange = { entry = it; error = null },
                label = "Password",
                type = LockType.PASSWORD,
                onDone = { submit() },
                enabled = waitMs == 0L && !busy,
            )
        }

        Spacer(Modifier.height(14.dp))
        val status = when {
            waitMs > 0 -> "Too many wrong tries. Try again in ${LockRules.formatWait(waitMs)}."
            else -> error
        }
        Text(
            status ?: " ",
            style = MaterialTheme.typography.bodySmall,
            color = c.warning,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().height(36.dp)
        )

        if (lock.type == LockType.PIN) {
            PinPad(
                enabled = waitMs == 0L && !busy,
                onDigit = { if (entry.length < LockRules.PIN_MAX) { entry += it; error = null } },
                onBackspace = { if (entry.isNotEmpty()) entry = entry.dropLast(1) },
            )
            Spacer(Modifier.height(16.dp))
        }

        PrimaryButton(
            text = if (busy) "Checking..." else "Unlock",
            onClick = { submit() },
            enabled = entry.length >= (if (lock.type == LockType.PIN) LockRules.PIN_MIN else 1) &&
                waitMs == 0L && !busy,
        )

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { showForgot = true }) {
                Text("Forgot $noun?", color = c.muted)
            }
            if (bioReady) {
                TextButton(onClick = { askBiometric() }) {
                    Icon(Icons.Rounded.Fingerprint, null, tint = c.accent, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Fingerprint", color = c.accent)
                }
            }
        }
        extraContent()
        Spacer(Modifier.height(24.dp))
    }

    if (showForgot) {
        ForgotFlow(
            controller = controller,
            lock = lock,
            onFinished = {
                controller.unlock()
                showForgot = false
                onUnlocked()
            },
            onDismiss = { showForgot = false },
        )
    }
}

@Composable
private fun PinDots(count: Int) {
    val c = FocusTheme.colors
    Row(
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.height(24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(maxOf(LockRules.PIN_MIN, count)) { i ->
            Box(
                Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(if (i < count) c.accent else c.ringTrack)
            )
        }
    }
}

@Composable
private fun PinPad(enabled: Boolean, onDigit: (String) -> Unit, onBackspace: () -> Unit) {
    val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                row.forEach { d -> PadKey(label = d, icon = null, enabled = enabled) { onDigit(d) } }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Spacer(Modifier.size(70.dp))
            PadKey(label = "0", icon = null, enabled = enabled) { onDigit("0") }
            PadKey(label = null, icon = Icons.AutoMirrored.Rounded.Backspace, enabled = enabled, onClick = onBackspace)
        }
    }
}

@Composable
private fun PadKey(label: String?, icon: ImageVector?, enabled: Boolean, onClick: () -> Unit) {
    val c = FocusTheme.colors
    Box(
        Modifier
            .size(70.dp)
            .clip(CircleShape)
            .background(c.card)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (label != null) {
            Text(
                label,
                fontSize = 26.sp,
                fontWeight = FontWeight.Medium,
                color = if (enabled) c.text else c.muted
            )
        }
        if (icon != null) {
            Icon(icon, "Delete", tint = if (enabled) c.text else c.muted, modifier = Modifier.size(24.dp))
        }
    }
}

// =================================================================================================
// Forgot PIN / password
// =================================================================================================

private enum class ForgotStep { Menu, Code, NewSecret }

/**
 * One way back in, fully offline: the recovery code that was shown once when the lock was turned
 * on. The phone's own screen lock (PIN / pattern / fingerprint of the device) deliberately does NOT
 * work here: this lock is separate from the phone's, so only the PIN / password the person set in
 * LockDistra, or its recovery code, can open it. The old PIN is never shown; the code only lets
 * the person choose a NEW one.
 */
@Composable
private fun ForgotFlow(
    controller: LockController,
    lock: LockState,
    onFinished: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var step by rememberSaveable { mutableStateOf(ForgotStep.Menu) }
    var verifiedCode by remember { mutableStateOf("") }
    var codeInput by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var newRecovery by remember { mutableStateOf<String?>(null) }
    val draft = rememberSecretDraft(lock.type)

    // After a recovery code was used, the new code must be seen before the app opens.
    val freshCode = newRecovery
    if (freshCode != null) {
        RecoveryCodeDialog(code = freshCode, onDone = { newRecovery = null; onFinished() })
        return
    }

    when (step) {
        ForgotStep.Menu -> AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Forgot your ${typeNoun(lock.type)}?", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "You can't see the old one, but you can choose a new one with your recovery code.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (lock.hasRecovery) {
                        PrimaryButton("Use my recovery code", onClick = { message = null; step = ForgotStep.Code })
                    }
                    if (!lock.hasRecovery) {
                        Text(
                            "No recovery code is saved for this lock, and the phone's own screen lock can't open it. Clearing LockDistra's data in Android's App info is the only way left.",
                            style = MaterialTheme.typography.bodySmall,
                            color = c.warning
                        )
                    }
                    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
        )

        ForgotStep.Code -> AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Recovery code", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Type the 16-character code you saved when you turned the lock on. Dashes and capitals don't matter.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it.take(24); message = null },
                        singleLine = true,
                        label = { Text("XXXX-XXXX-XXXX-XXXX") },
                        colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    )
                    message?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busy && recoveryShapeOk(codeInput),
                    onClick = {
                        busy = true
                        scope.launch {
                            val r = controller.checkRecovery(codeInput)
                            busy = false
                            if (r == VerifyResult.Ok) {
                                verifiedCode = codeInput
                                step = ForgotStep.NewSecret
                            } else {
                                message = when (r) {
                                    is VerifyResult.LockedOut ->
                                        "Too many tries. Try again in ${LockRules.formatWait(r.remainingMs)}."
                                    is VerifyResult.Wrong ->
                                        if (r.lockedForMs > 0) "Wrong code. Wait ${LockRules.formatWait(r.lockedForMs)}."
                                        else "That code isn't right."
                                    else -> "Recovery isn't available for this lock."
                                }
                            }
                        }
                    }
                ) { Text(if (busy) "Checking..." else "Continue", color = c.accent) }
            },
            dismissButton = { TextButton(onClick = { step = ForgotStep.Menu }) { Text("Back", color = c.muted) } }
        )

        ForgotStep.NewSecret -> AlertDialog(
            onDismissRequest = {},
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Choose a new lock", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    NewSecretFields(draft)
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busy,
                    onClick = {
                        if (!draft.validate()) return@TextButton
                        busy = true
                        scope.launch {
                            val fresh = controller.resetWithRecovery(verifiedCode, draft.type, draft.first)
                            busy = false
                            if (fresh == null) {
                                draft.error = "That didn't work. Start again."
                                step = ForgotStep.Menu
                            } else {
                                newRecovery = fresh
                            }
                        }
                    }
                ) { Text(if (busy) "Saving..." else "Save and unlock", color = c.accent) }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
        )
    }
}

private fun recoveryShapeOk(input: String) =
    com.focusmode.app.data.Credentials.isRecoveryShapeValid(input)

// =================================================================================================
// Recovery code dialog
// =================================================================================================

/** Shows the recovery code. Can't be dismissed by accident; it is not shown again. */
@Composable
fun RecoveryCodeDialog(code: String, onDone: () -> Unit) {
    val c = FocusTheme.colors
    AlertDialog(
        onDismissRequest = {},
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Your recovery code", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "If you forget your PIN or password, this code lets you choose a new one. It is shown only once.",
                    style = MaterialTheme.typography.bodyMedium
                )
                FocusCard(padding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
                    Text(
                        code,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = c.text,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    "Write it on paper and keep it away from this phone. It is not copied anywhere, and LockDistra only keeps a scrambled version that can't be turned back into the code. Using it once makes a new code.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = { TextButton(onClick = onDone) { Text("I wrote it down", color = c.accent) } },
    )
}

// =================================================================================================
// Settings section
// =================================================================================================

private fun autoLockLabel(sec: Int) = when {
    sec == 0 -> "At once"
    sec < 60 -> "$sec s"
    else -> "${sec / 60} min"
}

/**
 * "Lock again after leaving the app". Works for every unlock method (PIN / password, Online
 * approval, Both): once the app has been out of sight for this long, coming back shows the lock
 * screen and asks for the PIN / password or an approval from the trusted phone.
 */
@Composable
fun AutoLockSection(
    lock: LockState,
    controller: LockController,
    settingsLocked: Boolean,
) {
    val c = FocusTheme.colors
    var note by remember { mutableStateOf<String?>(null) }
    FocusCard {
        Column {
            Text("Lock again after leaving the app", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(
                "How long LockDistra may stay in the background before it locks. After that, opening it needs your PIN / password or an approval from your trusted phone.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            Spacer(Modifier.height(12.dp))
            LockRules.AUTO_LOCK_CHOICES.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { sec ->
                        SoftChip(
                            autoLockLabel(sec),
                            selected = lock.autoLockSeconds == sec,
                            onClick = {
                                note = null
                                if (!controller.setAutoLockSeconds(sec)) {
                                    note = "Locked right now (focus session or Prevent changes)."
                                }
                            }
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            if (settingsLocked && note == null) {
                Text(
                    "Locked right now (focus session or Prevent changes).",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning
                )
            }
            note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
        }
    }
}

private enum class LockDialog { None, Setup, VerifyChange, Change, VerifyDisable, VerifyRecovery, ShowRecovery }

/**
 * "App lock" card for Settings. Turning it off, changing the PIN and seeing a new recovery code
 * all ask for the current PIN / password first.
 */
@Composable
fun AppLockSection(
    lock: LockState,
    controller: LockController,
    settingsLocked: Boolean,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var dialog by remember { mutableStateOf(LockDialog.None) }
    var recoveryCode by remember { mutableStateOf("") }
    var note by remember { mutableStateOf<String?>(null) }
    val bioAvailable = remember { Biometrics.isAvailable(context) }

    FocusCard {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Lock, null, tint = c.accent, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("App lock", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (lock.enabled) "On, with a ${typeNoun(lock.type)}" else "Off",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (lock.enabled) c.accent else c.muted
                    )
                }
                FocusSwitch(
                    checked = lock.enabled,
                    enabled = !(lock.enabled && settingsLocked),
                    onCheckedChange = { on ->
                        note = null
                        dialog = if (on) LockDialog.Setup else LockDialog.VerifyDisable
                    }
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (lock.enabled && settingsLocked)
                    "Turning the lock off is locked right now (focus session or Prevent changes)."
                else
                    "Asks for a PIN or password every time LockDistra opens, also after a restart. It guards the dashboard, settings and emergency limits. Blocking keeps working while the app is locked.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )

            if (lock.enabled) {
                // "Lock again after leaving the app" has its own card (AutoLockSection) now,
                // because it also applies to Online approval, not only to the PIN / password.

                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Fingerprint", style = MaterialTheme.typography.titleMedium)
                        Text(
                            when {
                                !bioAvailable -> "Not available. Needs Android 10 and a fingerprint saved in phone settings."
                                lock.biometric -> "On"
                                else -> "Off"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (lock.biometric && bioAvailable) c.accent else c.muted
                        )
                    }
                    FocusSwitch(
                        checked = lock.biometric && bioAvailable,
                        enabled = bioAvailable && !settingsLocked,
                        onCheckedChange = { on ->
                            if (!on) {
                                controller.setBiometric(false)
                            } else {
                                val a = context.findActivity()
                                if (a != null) {
                                    // One real fingerprint check proves it works before it is switched on.
                                    Biometrics.prompt(
                                        activity = a,
                                        title = "Turn on fingerprint unlock",
                                        subtitle = "Touch the sensor to confirm",
                                        cancelText = "Cancel",
                                        onSuccess = { controller.setBiometric(true) },
                                        onFailure = {},
                                    )
                                }
                            }
                        }
                    )
                }

                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SoftChip("Change ${typeNoun(lock.type)}", false, { note = null; dialog = LockDialog.VerifyChange })
                    SoftChip("New recovery code", false, { note = null; dialog = LockDialog.VerifyRecovery })
                }
            }
            note?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
        }
    }

    // ---- Dialogs ----
    when (dialog) {
        LockDialog.None -> Unit

        LockDialog.Setup -> {
            val draft = rememberSecretDraft(LockType.PIN)
            var busy by remember { mutableStateOf(false) }
            AlertDialog(
                onDismissRequest = { dialog = LockDialog.None },
                containerColor = c.card,
                titleContentColor = c.text,
                textContentColor = c.muted,
                title = { Text("Turn on app lock", style = MaterialTheme.typography.titleLarge) },
                text = { Column(Modifier.verticalScroll(rememberScrollState())) { NewSecretFields(draft) } },
                confirmButton = {
                    TextButton(enabled = !busy, onClick = {
                        if (!draft.validate()) return@TextButton
                        busy = true
                        scope.launch {
                            recoveryCode = controller.enable(draft.type, draft.first)
                            busy = false
                            dialog = LockDialog.ShowRecovery
                        }
                    }) { Text(if (busy) "Saving..." else "Turn on", color = c.accent) }
                },
                dismissButton = { TextButton(onClick = { dialog = LockDialog.None }) { Text("Cancel", color = c.muted) } }
            )
        }

        LockDialog.ShowRecovery -> RecoveryCodeDialog(code = recoveryCode, onDone = {
            recoveryCode = ""
            dialog = LockDialog.None
        })

        LockDialog.VerifyChange -> VerifyDialog(
            title = "Change ${typeNoun(lock.type)}",
            text = "Enter your current ${typeNoun(lock.type)} first.",
            lock = lock,
            controller = controller,
            onVerified = { dialog = LockDialog.Change },
            onDismiss = { dialog = LockDialog.None },
        )

        LockDialog.Change -> {
            val draft = rememberSecretDraft(lock.type)
            var busy by remember { mutableStateOf(false) }
            AlertDialog(
                onDismissRequest = { dialog = LockDialog.None },
                containerColor = c.card,
                titleContentColor = c.text,
                textContentColor = c.muted,
                title = { Text("New lock", style = MaterialTheme.typography.titleLarge) },
                text = { Column(Modifier.verticalScroll(rememberScrollState())) { NewSecretFields(draft) } },
                confirmButton = {
                    TextButton(enabled = !busy, onClick = {
                        if (!draft.validate()) return@TextButton
                        busy = true
                        scope.launch {
                            controller.change(draft.type, draft.first)
                            busy = false
                            dialog = LockDialog.None
                            note = "Saved. Your recovery code still works."
                        }
                    }) { Text(if (busy) "Saving..." else "Save", color = c.accent) }
                },
                dismissButton = { TextButton(onClick = { dialog = LockDialog.None }) { Text("Cancel", color = c.muted) } }
            )
        }

        LockDialog.VerifyDisable -> VerifyDialog(
            title = "Turn off app lock",
            text = "Enter your current ${typeNoun(lock.type)} to turn the lock off.",
            lock = lock,
            controller = controller,
            onVerified = {
                dialog = LockDialog.None
                if (!controller.disable()) note = "Turning the lock off is locked right now (focus session or Prevent changes)."
            },
            onDismiss = { dialog = LockDialog.None },
        )

        LockDialog.VerifyRecovery -> VerifyDialog(
            title = "New recovery code",
            text = "Enter your current ${typeNoun(lock.type)}. The old recovery code stops working.",
            lock = lock,
            controller = controller,
            onVerified = {
                recoveryCode = controller.newRecoveryCode()
                dialog = LockDialog.ShowRecovery
            },
            onDismiss = { dialog = LockDialog.None },
        )
    }
}

/** Asks for the current PIN / password before a sensitive change. */
@Composable
internal fun VerifyDialog(
    title: String,
    text: String,
    lock: LockState,
    controller: LockController,
    onVerified: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    var entry by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val noun = typeNoun(lock.type)

    fun submit() {
        if (busy || entry.isEmpty()) return
        busy = true
        val secret = entry
        scope.launch {
            val r = controller.verify(secret)
            busy = false
            if (r == VerifyResult.Ok) {
                onVerified()
            } else {
                entry = ""
                error = verifyMessage(r, noun)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text, style = MaterialTheme.typography.bodyMedium)
                SecretField(
                    value = entry,
                    onChange = { entry = it; error = null },
                    label = "Current $noun",
                    type = lock.type,
                    onDone = { submit() },
                )
                error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && entry.isNotEmpty(), onClick = { submit() }) {
                Text(if (busy) "Checking..." else "Confirm", color = c.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}
