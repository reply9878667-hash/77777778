package com.focusmode.app.ui.screens

import android.app.Activity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AutoFocusSchedule
import com.focusmode.app.data.FocusControl
import com.focusmode.app.data.FocusState
import com.focusmode.app.ui.autofocus.AutoFocusCard
import com.focusmode.app.data.LockSession
import com.focusmode.app.data.LockState
import com.focusmode.app.ui.LockController
import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.service.Permissions
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.theme.FocusTheme

@Composable
fun SettingsScreen(
    permissions: PermissionStatus,
    focusActive: Boolean,
    themeMode: Int,
    onBack: () -> Unit,
    onThemeChange: (Int) -> Unit,
    onGrantAccessibility: () -> Unit,
    onGrantNotifications: () -> Unit,
    onGrantUsage: () -> Unit,
    onProtectionActivated: () -> Unit,
    onProtectionOff: () -> Unit,
    advancedProtection: Boolean,
    onAdvancedChange: (Boolean) -> Unit,
    onGrantBattery: () -> Unit,
    restoreAfterRestart: Boolean,
    onRestoreChange: (Boolean) -> Unit,
    onGrantOverlay: () -> Unit = {},
    focusState: FocusState,
    onControlChange: (FocusControl, Boolean) -> Unit,
    lock: LockState,
    lockController: LockController,
    online: com.focusmode.app.data.online.OnlineManager,
    canChangeSettings: () -> Boolean,
    onOpenApprovals: () -> Unit,
    onSetPreventChanges: (Boolean) -> String?,
    onAuthorizeChanges: () -> Unit,
    onLockChangesNow: () -> Unit,
    onOpenAuth: () -> Unit = {},
    onOpenProfile: () -> Unit = {},
    onOffMethodChange: (com.focusmode.app.data.FocusOffMethod) -> Boolean = { false },
    onStudyCheckInChange: (Int) -> Boolean = { false },
    autoFocus: AutoFocusSchedule = AutoFocusSchedule(),
    onAutoFocusChange: (AutoFocusSchedule) -> Unit = {},
    tipsEnabled: Boolean = true,
    onTipsEnabledChange: (Boolean) -> Unit = {},
    onTipsReset: () -> Unit = {},
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    // "Allow changing LockDistra settings" is off for the running session.
    val settingsLocked = !focusState.canChangeSettings

    var showExplanation by remember { mutableStateOf(false) }
    var showAdvancedExplanation by remember { mutableStateOf(false) }
    var showAdvancedOff by remember { mutableStateOf(false) }
    var showBatteryInfo by remember { mutableStateOf(false) }

    // Advanced protection only counts while the device admin it relies on is active.
    val advancedOn = advancedProtection && permissions.deviceAdmin

    val adminLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        // Whether or not the user accepted, re-read the real state.
        onProtectionActivated()
    }

    // Used by the advanced toggle: once the admin is granted, switch advanced protection on.
    val advancedAdminLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        onProtectionActivated()
        if (Permissions.isAdminActive(context)) onAdvancedChange(true)
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Text("Settings", style = MaterialTheme.typography.titleLarge)
        }

        if (settingsLocked) {
            LockedNote(
                if (focusState.changesLocked)
                    "Prevent changes is on, so settings are locked. Use \"Unlock changes\" below. Appearance and Focus Mode settings can still change."
                else
                    "Changing LockDistra settings is locked for this session. Appearance can still change."
            )
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.height(8.dp))
        SectionLabel("Appearance")
        FocusCard {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "System", 1 to "Light", 2 to "Dark").forEach { (mode, label) ->
                    SoftChip(label, selected = themeMode == mode, onClick = { onThemeChange(mode) })
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Account")
        com.focusmode.app.ui.online.AccountSection(manager = online, onOpenAuth = onOpenAuth, onOpenProfile = onOpenProfile)

        Spacer(Modifier.height(24.dp))
        SectionLabel("Backup")
        BackupCard()

        Spacer(Modifier.height(24.dp))
        SectionLabel("Security")
        SettingsSubLabel("App lock")
        AppLockSection(lock = lock, controller = lockController, settingsLocked = settingsLocked)

        // "Lock again after leaving the app" applies to PIN / password AND Online approval.
        val onlineNow by online.state.collectAsStateWithLifecycle()
        if (com.focusmode.app.data.online.UnlockGateRules.gateActive(onlineNow.mode, lock.enabled)) {
            Spacer(Modifier.height(12.dp))
            AutoLockSection(lock = lock, controller = lockController, settingsLocked = settingsLocked)
        }

        Spacer(Modifier.height(16.dp))
        SettingsSubLabel("Unlock method")
        com.focusmode.app.ui.online.UnlockModeSection(
            manager = online,
            lock = lock,
            settingsLocked = settingsLocked,
            canChangeSettings = canChangeSettings,
            onOpenApprovals = onOpenApprovals,
        )

        Spacer(Modifier.height(16.dp))
        SettingsSubLabel("Prevent changes")
        com.focusmode.app.ui.online.PreventChangesSection(
            state = focusState,
            lock = lock,
            manager = online,
            controller = lockController,
            onSet = onSetPreventChanges,
            onAuthorized = onAuthorizeChanges,
            onLockNow = onLockChangesNow,
        )

        if (com.focusmode.app.data.SafetyConfig.UNINSTALL_PROTECTION) {
        Spacer(Modifier.height(16.dp))
        SettingsSubLabel("Uninstall protection")
        FocusCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Shield, null, tint = c.accent, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.size(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Device admin protection", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (permissions.deviceAdmin) "On" else "Off",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (permissions.deviceAdmin) c.accent else c.muted
                        )
                    }
                    FocusSwitch(
                        checked = permissions.deviceAdmin,
                        enabled = !advancedOn && !(focusActive && permissions.deviceAdmin) && !settingsLocked,
                        onCheckedChange = { on ->
                            if (on) showExplanation = true else onProtectionOff()
                        }
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    if (advancedOn)
                        "Managed by Advanced protection below. Switch that off first to change this."
                    else if (focusActive && permissions.deviceAdmin)
                        "Locked while a focus session is running. You can switch it off when the session ends."
                    else
                        "Stops LockDistra from being uninstalled the normal way until you switch this off here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        FocusCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Lock, null, tint = c.accent, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.size(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Advanced protection", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (advancedOn) "On" else "Off",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (advancedOn) c.accent else c.muted
                        )
                    }
                    FocusSwitch(
                        checked = advancedOn,
                        enabled = !(focusActive && advancedOn) && !settingsLocked,
                        onCheckedChange = { on ->
                            if (on) showAdvancedExplanation = true else showAdvancedOff = true
                        }
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    if (focusActive && advancedOn)
                        "Locked while a focus session is running. You can switch it off when the session ends."
                    else
                        "Also guards the uninstall, App info and device admin screens between focus sessions, not only during them. You can switch it off here any time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Focus")
        SettingsSubLabel("Auto Focus")
        AutoFocusCard(
            schedule = autoFocus,
            onChange = onAutoFocusChange,
            editable = focusState.canChangeFocusSettings,
            accessibilityOn = permissions.accessibility,
            onGrantAccessibility = onGrantAccessibility,
        )

        Spacer(Modifier.height(16.dp))
        SettingsSubLabel("Feature tips")
        FocusCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Show feature tips", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (tipsEnabled) "On" else "Off",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (tipsEnabled) c.accent else c.muted
                        )
                    }
                    FocusSwitch(checked = tipsEnabled, enabled = true, onCheckedChange = onTipsEnabledChange)
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    "As you use LockDistra, short hints point out features you haven't tried yet, one at a time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(12.dp))
                SoftChip("Show all tips again", false, onTipsReset)
            }
        }

        Spacer(Modifier.height(16.dp))
        SettingsSubLabel("Default controls")
        FocusControlDefaultsCard(state = focusState, onChange = onControlChange)

        Spacer(Modifier.height(16.dp))
        SettingsSubLabel("After a restart")
        FocusCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Restore session after restart", style = MaterialTheme.typography.titleMedium)
                        Text(
                            if (restoreAfterRestart) "On" else "Off",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (restoreAfterRestart) c.accent else c.muted
                        )
                    }
                    FocusSwitch(
                        checked = restoreAfterRestart,
                        enabled = !focusActive,
                        onCheckedChange = onRestoreChange
                    )
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    if (focusActive)
                        "Locked while a focus session is running. You can change it when the session ends."
                    else
                        "If the phone restarts during a focus session, the session and your app limits come back as soon as Android allows, and you get a notification. Turn this off if you would rather a restart ended the session.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        SettingsSubLabel("After restart")
        FocusCard(padding = PaddingValues(vertical = 8.dp, horizontal = 20.dp)) {
            Column {
                PermissionLine(
                    "Cover screen after restart",
                    "Needs \"Display over other apps\"",
                    permissions.overlay,
                    onGrantOverlay
                )
                val missingForCover = com.focusmode.app.service.BootCoverService.missing(
                    permissions.overlay, permissions.deviceAdmin, permissions.accessibility, advancedProtection
                )
                var previewNote by remember { mutableStateOf<String?>(null) }
                val lastCoverLog = remember { com.focusmode.app.service.BootCoverService.lastLog(context) }
                Text(
                    "When the phone restarts, LockDistra's protection needs a few seconds to start. Until then LockDistra shows " +
                        "a blurred screen with \"Setting up LockDistra…\", so Settings can't be opened in that gap. It goes " +
                        "away by itself as soon as protection is running (never later than 90 seconds after unlock).",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Text(
                    if (missingForCover.isEmpty()) "Ready: the cover will show after every restart."
                    else "Still needed: " + missingForCover.joinToString(", ") + ".",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (missingForCover.isEmpty()) c.accent else c.warning,
                    modifier = Modifier.padding(top = 8.dp)
                )
                val restartTrace = remember { com.focusmode.app.service.BootCoverService.traceLog(context) }
                if (restartTrace.isNotBlank()) {
                    Text(
                        "Restart details (seconds since restart):\n$restartTrace",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                if (lastCoverLog.isNotBlank()) {
                    Text(
                        "Last restart: $lastCoverLog",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                TextButton(onClick = {
                    previewNote = if (com.focusmode.app.service.BootCoverService.preview(context)) null
                    else "Allow \"Display over other apps\" first."
                }) { Text("Test cover (5 seconds)", color = c.accent) }
                if (previewNote != null) {
                    Text(previewNote!!, style = MaterialTheme.typography.bodySmall, color = c.warning)
                }
                Text(
                    "Xiaomi / Oppo / vivo phones: also allow Autostart and \"Display pop-up windows while running in the background\" for LockDistra.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("Permissions")
        FocusCard(padding = PaddingValues(vertical = 8.dp, horizontal = 20.dp)) {
            Column {
                PermissionLine("Accessibility service", "Needed to detect and cover blocked apps", permissions.accessibility, onGrantAccessibility)
                PermissionLine("Notifications", "Status notification and plant chime", permissions.notifications, onGrantNotifications)
                PermissionLine("Usage access", "Backup app detection and accurate daily limits", permissions.usageAccess, onGrantUsage)
                PermissionLine(
                    "Battery optimization",
                    "Keeps blocking and limits running when the phone sleeps",
                    permissions.batteryUnrestricted,
                    onGrant = { showBatteryInfo = true }
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        SectionLabel("About")
        FocusCard {
            Text(
                "LockDistra has no ads, no accounts and no internet access. Everything you set here stays on this phone.\n\n" +
                    "It never reads, records or sends what is on your screen. It only checks which app is in front, and, inside apps you chose, whether a section such as Shorts is open. " +
                    "Games are left alone: nothing is read or tapped inside them. You can remove LockDistra like any other app, at any time.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
        }
        Spacer(Modifier.height(20.dp))
        com.focusmode.app.ui.components.BrandMark(
            modifier = Modifier.fillMaxWidth(),
            centered = true
        )
        Spacer(Modifier.height(32.dp))
    }

    if (showBatteryInfo) {
        AlertDialog(
            onDismissRequest = { showBatteryInfo = false },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Keep LockDistra running", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text(
                        "Why: many phones stop background apps to save battery. When that happens, blocking and daily limits can stop working until you open the app again.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "What happens: Android will ask whether LockDistra may ignore battery optimization. LockDistra only works while a session or a limit needs it, so the extra battery use is small.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Permissions.oemBatteryHint()?.let { hint ->
                        Text(hint, style = MaterialTheme.typography.bodyMedium)
                    }
                    Text(
                        "You can change this at any time in your phone's battery settings.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showBatteryInfo = false
                    onGrantBattery()
                }) { Text("Continue", color = c.accent) }
            },
            dismissButton = {
                TextButton(onClick = { showBatteryInfo = false }) { Text("Not now", color = c.muted) }
            }
        )
    }

    if (showAdvancedExplanation) {
        val needsAccessibility = !permissions.accessibility
        val needsAdmin = !permissions.deviceAdmin
        AlertDialog(
            onDismissRequest = { showAdvancedExplanation = false },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Advanced protection", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text(
                        "What it does: when someone opens LockDistra's uninstall dialog, App info page or device admin screen, LockDistra shows a short \"Protected\" screen instead. This works all the time, not only during a focus session.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text("Permissions it needs:", style = MaterialTheme.typography.titleMedium, color = c.text)
                    Text(
                        (if (needsAccessibility) "• Accessibility service: not allowed yet. It is used only to see which Settings or installer screen is open. Nothing is stored or sent."
                        else "✓ Accessibility service: allowed"),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        (if (needsAdmin) "• Device admin: not allowed yet. Android will ask you next. It only lets Android refuse a normal uninstall. It cannot read your data, erase the phone or change your password."
                        else "✓ Device admin: allowed"),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        "You stay in control: switch it off here any time outside a focus session. It never blocks emergency calls, shutting down or restarting the phone, and the rest of Settings keeps working. It is a strong guard against accidental or hasty removal, not a lock that nobody can open.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showAdvancedExplanation = false
                    when {
                        needsAccessibility -> onGrantAccessibility()
                        needsAdmin -> { LockSession.markOwnLaunch(); advancedAdminLauncher.launch(adminRequestIntent(context)) }
                        else -> onAdvancedChange(true)
                    }
                }) {
                    Text(
                        when {
                            needsAccessibility -> "Allow accessibility"
                            needsAdmin -> "Continue"
                            else -> "Turn on"
                        },
                        color = c.accent
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdvancedExplanation = false }) { Text("Not now", color = c.muted) }
            }
        )
    }

    if (showAdvancedOff) {
        AlertDialog(
            onDismissRequest = { showAdvancedOff = false },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Turn off advanced protection?", style = MaterialTheme.typography.titleLarge) },
            text = {
                Text(
                    "LockDistra's uninstall and App info screens will only be guarded during focus sessions again. Device admin protection stays as it is.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showAdvancedOff = false
                    onAdvancedChange(false)
                }) { Text("Turn off", color = c.accent) }
            },
            dismissButton = {
                TextButton(onClick = { showAdvancedOff = false }) { Text("Keep on", color = c.muted) }
            }
        )
    }

    if (showExplanation) {
        AlertDialog(
            onDismissRequest = { showExplanation = false },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Before you turn this on", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    Text("Android will ask you to make LockDistra a device administrator.", style = MaterialTheme.typography.bodyMedium)
                    Text("What it does: while this is on, Android will not let LockDistra be uninstalled until protection is switched off here.", style = MaterialTheme.typography.bodyMedium)
                    Text("What Android shows: the admin is listed as able to lock the screen. LockDistra never uses that. It cannot read your data, erase the phone or change your password.", style = MaterialTheme.typography.bodyMedium)
                    Text("Limits: during a focus session, protection can't be turned off and LockDistra's Settings pages are kept out of reach. Outside a session you can switch it off at any time, and anyone who does that can then uninstall the app.", style = MaterialTheme.typography.bodyMedium)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showExplanation = false
                    run { LockSession.markOwnLaunch(); adminLauncher.launch(adminRequestIntent(context)) }
                }) { Text("Continue", color = c.accent) }
            },
            dismissButton = {
                TextButton(onClick = { showExplanation = false }) { Text("Not now", color = c.muted) }
            }
        )
    }
}

private fun adminRequestIntent(context: android.content.Context) =
    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, Permissions.adminComponent(context))
        putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Prevents LockDistra from being uninstalled the normal way while protection is on."
        )
    }

@Composable
private fun PermissionLine(title: String, subtitle: String, granted: Boolean, onGrant: () -> Unit) {
    val c = FocusTheme.colors
    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = c.muted)
        }
        if (granted) {
            Icon(Icons.Rounded.CheckCircle, "Granted", tint = c.accent, modifier = Modifier.size(24.dp))
        } else {
            SoftChip("Allow", selected = true, onClick = onGrant)
        }
    }
}

/** Intents for the system screens where each permission is granted. */
object PermissionIntents {
    fun accessibility() = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun usageAccess(packageName: String) =
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

    /** Direct yes/no prompt for this app only. */
    fun batteryRequest(packageName: String) =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
            data = Uri.parse("package:$packageName")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

    /** Fallback: the system list of battery-optimized apps. */
    fun batteryList() =
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun appNotifications(packageName: String) =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}

/** Small heading for a group of cards inside one Settings section (e.g. Security > App lock). */
@Composable
private fun SettingsSubLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = FocusTheme.colors.muted,
        modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
    )
}
