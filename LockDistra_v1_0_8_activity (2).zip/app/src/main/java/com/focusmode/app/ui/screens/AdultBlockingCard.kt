package com.focusmode.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AdultBlockStore
import com.focusmode.app.data.AdultCustom
import com.focusmode.app.data.AdultListUpdater
import com.focusmode.app.data.CustomEntry
import com.focusmode.app.data.CustomKind
import com.focusmode.app.data.WebsiteBrowsers
import com.focusmode.app.service.AdultDnsVpnService
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat

/**
 * Adult Content Blocking: one switch. When on, every site in the built-in list (and its subdomains)
 * is closed in supported browsers, with no setup and no internet needed. The card also shows which
 * list is in use, where it came from, and offers an optional update check.
 */
@Composable
internal fun AdultBlockingCard(modifier: Modifier = Modifier) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val store = remember { AdultBlockStore.get(context) }
    val state by store.state.collectAsState()
    val scope = rememberCoroutineScope()

    var refused by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    var showSources by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf(false) }
    val canUpdate = com.focusmode.app.BuildConfig.ADULT_LIST_MANIFEST_URL.isNotBlank()
    val n = NumberFormat.getIntegerInstance()
    val running by AdultDnsVpnService.running.collectAsState()
    var vpnDenied by remember { mutableStateOf(false) }
    val privateDnsBlocks = remember(running, state.enabled) { AdultDnsVpnService.privateDnsBypassesFilter(context) }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) {
            vpnDenied = false
            AdultDnsVpnService.sync(context)
        } else vpnDenied = true
    }
    // Asks for the one-time VPN permission (the DNS filter), or starts the filter when it is already allowed.
    fun enableFilter() {
        val ask = AdultDnsVpnService.permissionIntent(context)
        if (ask == null) AdultDnsVpnService.sync(context) else vpnLauncher.launch(ask)
    }

    FocusCard(modifier = modifier, padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), highlight = state.enabled) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable { open = !open }) {
                    Text("Adult Content Protection", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (state.enabled) "ON • ${n.format(state.count)} adult sites blocked" +
                            (if (state.count < 5_000) " (starter list - limited protection)" else "")
                        else "Block adult websites automatically",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.enabled) c.accent else c.muted
                    )
                }
                Icon(
                    if (open) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown,
                    if (open) "Hide details" else "Show details",
                    tint = c.muted,
                    modifier = Modifier.clickable { open = !open }
                )
                Spacer(Modifier.size(8.dp))
                FocusSwitch(
                    checked = state.enabled,
                    onCheckedChange = { on ->
                        refused = false
                        if (!store.setEnabled(on)) refused = true
                        else if (on) {
                            scope.launch(Dispatchers.IO) { store.ensureInstalled() }
                            enableFilter()
                        } else AdultDnsVpnService.sync(context)
                    }
                )
            }
            if (state.enabled) {
                Spacer(Modifier.height(6.dp))
                if (running) {
                    Text(
                        "Active in every browser and app (DNS filter running).",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.accent
                    )
                } else {
                    Text(
                        if (vpnDenied) "Permission was not given, so only the browser address bar is checked. Allow the VPN for full protection."
                        else "Full protection needs a one-time VPN permission. Only DNS is filtered; your other traffic is not touched.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.warning
                    )
                    TextButton(onClick = { enableFilter() }) { Text("Turn on full protection", color = c.accent) }
                }
                if (privateDnsBlocks) {
                    Text(
                        "Android's Private DNS is set to a custom provider, which skips the filter. Set Settings > Network > Private DNS to Off or Automatic.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.warning
                    )
                }
            }
            AdultCustomSection(store, state.custom)
            if (open || refused) {
            Text(
                if (refused) "This can't be changed right now (a focus session or lock is active)."
                else "Blocks adult websites in every browser and app with a DNS filter (needs a one-time VPN permission), " +
                    "using the list on this phone, adult-looking names and a family-safe DNS with SafeSearch. " +
                    "The address bar of ${WebsiteBrowsers.supportedNames} is also checked and shows the block screen.",
                style = MaterialTheme.typography.bodySmall,
                color = if (refused) c.warning else c.muted,
                modifier = Modifier.padding(top = 8.dp)
            )


            if (state.enabled) {
                Spacer(Modifier.height(8.dp))
                Text(
                    buildString {
                        if (state.version > 0) {
                            append("List version ${state.version}")
                            if (state.builtAt.isNotBlank()) append(" • built ${state.builtAt}")
                            append(if (state.origin == AdultBlockStore.ORIGIN_DOWNLOADED) " • downloaded" else " • built into the app")
                        } else append("Setting up the built-in list…")
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                if (state.lastMessage.isNotBlank()) {
                    Text(state.lastMessage, style = MaterialTheme.typography.bodySmall, color = c.muted)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (canUpdate) {
                        TextButton(
                            enabled = !checking,
                            onClick = {
                                checking = true
                                scope.launch {
                                    withContext(Dispatchers.IO) { AdultListUpdater.update(store) }
                                    checking = false
                                }
                            }
                        ) { Text(if (checking) "Checking…" else "Check for update") }
                    }
                    TextButton(onClick = { showSources = !showSources }) {
                        Text(if (showSources) "Hide sources" else "List sources")
                    }
                }
                if (canUpdate) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Check for updates automatically",
                            style = MaterialTheme.typography.bodySmall,
                            color = c.muted,
                            modifier = Modifier.weight(1f)
                        )
                        FocusSwitch(checked = state.autoUpdate, onCheckedChange = { store.setAutoUpdate(it) })
                    }
                }
                if (showSources) {
                    Spacer(Modifier.height(6.dp))
                    if (state.sources.isEmpty()) {
                        Text("No source details recorded yet.", style = MaterialTheme.typography.bodySmall, color = c.muted)
                    }
                    state.sources.forEach { src ->
                        Text(
                            "${src.name} • ${src.license}" +
                                (if (src.retrieved.isNotBlank()) " • retrieved ${src.retrieved}" else "") +
                                (if (src.entries > 0) " • ${n.format(src.entries)} entries" else ""),
                            style = MaterialTheme.typography.bodySmall,
                            color = c.muted
                        )
                        if (src.homepage.isNotBlank()) {
                            Text(src.homepage, style = MaterialTheme.typography.labelSmall, color = c.muted)
                        }
                    }
                    Text(
                        "Encrypted DNS set by hand in Android (Private DNS with a provider name) can skip the filter.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
            }
        }
    }
}

/**
 * "Add keyword": the person's own blocked websites and words, shown as tags. Tap "Add keyword", type a website name
 * ("pornhub"), a link ("https://example.com/page") or a few words; LockDistra works out which it is. Each tag has an x to
 * remove it. Works even when the built-in list switch is off.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdultCustomSection(store: AdultBlockStore, entries: List<CustomEntry>) {
    val c = FocusTheme.colors
    var showDialog by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var removeRefused by remember { mutableStateOf(false) }

    fun submit() {
        message = when (store.addCustom(text)) {
            AdultCustom.Result.OK -> { text = ""; showDialog = false; null }
            AdultCustom.Result.INVALID -> "Enter a website name, a link or a word of 3 to 40 letters."
            AdultCustom.Result.TOO_COMMON -> "That link is on a big everyday site. Type only the site name (example.com) to block the whole site."
            AdultCustom.Result.ALREADY_THERE -> "Already in your list."
            AdultCustom.Result.FULL -> "The list is full (${AdultCustom.MAX})."
            AdultCustom.Result.LOCKED -> "This can't be changed right now (a focus session or lock is active)."
        }
    }

    Spacer(Modifier.height(10.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Your blocked keywords & websites", style = MaterialTheme.typography.titleSmall)
            Text(
                if (entries.isEmpty()) "Add a website name or link. It is blocked in ${WebsiteBrowsers.supportedNames}."
                else "${entries.size} added. Blocked in ${WebsiteBrowsers.supportedNames}.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
        }
        TextButton(onClick = { message = null; showDialog = true }) {
            Icon(Icons.Rounded.Add, null, tint = c.accent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.size(4.dp))
            Text("Add keyword", color = c.accent)
        }
    }
    if (entries.isNotEmpty()) {
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 6.dp)
        ) {
            entries.forEach { e ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(c.accentSoft, RoundedCornerShape(50))
                        .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
                ) {
                    Text(
                        (if (e.kind == CustomKind.DOMAIN) "\uD83C\uDF10 " else "# ") + e.value,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    IconButton(onClick = { removeRefused = !store.removeCustom(e) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, "Remove ${e.value}", tint = c.muted, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
    if (removeRefused) {
        Text(
            "This can't be changed right now (a focus session or lock is active).",
            style = MaterialTheme.typography.bodySmall,
            color = c.warning,
            modifier = Modifier.padding(top = 4.dp)
        )
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false; text = ""; message = null },
            title = { Text("Add keyword") },
            text = {
                Column {
                    Text(
                        "Type a website name (pornhub), paste a link (https://example.com) or a word. " +
                            "A website is closed with all its pages; a word closes any browser page whose address contains it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.take(300); message = null },
                        singleLine = true,
                        placeholder = { Text("website name, link or word") },
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                    )
                    if (message != null) {
                        Text(message!!, style = MaterialTheme.typography.bodySmall, color = c.warning, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            },
            confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { submit() }) { Text("Add", color = c.accent) } },
            dismissButton = { TextButton(onClick = { showDialog = false; text = ""; message = null }) { Text("Cancel", color = c.muted) } },
        )
    }
}
