package com.focusmode.app.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.LockSession
import com.focusmode.app.data.SafetyConfig
import com.focusmode.app.service.RequiredPermission
import com.focusmode.app.ui.AppViewModel
import com.focusmode.app.ui.components.FocusBackground
import com.focusmode.app.ui.components.SecondaryButton
import com.focusmode.app.ui.theme.FocusTheme

/**
 * Shown by AppEntry after the account / onboarding screens and before Home. It lists every permission LockDistra needs
 * and has no way past it: when the last one is allowed, the permission state flips and AppEntry opens Home by itself.
 * The same screen comes back if a permission is switched off later, so a feature can never run on a missing permission.
 */
@Composable
fun PermissionGateScreen(vm: AppViewModel, onSkip: () -> Unit) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val permissions by vm.permissions.collectAsStateWithLifecycle()
    var askedNotifications by rememberSaveable { mutableStateOf(false) }

    // Coming back from a system Settings page: look again right away.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshPermissions() }

    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshPermissions()
    }

    fun open(intent: Intent, fallback: Intent? = null) {
        // A deliberate trip to system Settings must not make the app lock ask again at once.
        LockSession.markOwnLaunch()
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            if (fallback != null) runCatching { context.startActivity(fallback) }
        }
    }

    val missing = permissions.missingRequired().toSet()
    // Android before 12 has no exact-alarm setting, so that row only exists on 12+.
    val shown = RequiredPermission.entries.filter { it != RequiredPermission.EXACT_ALARMS || Build.VERSION.SDK_INT >= 31 }
    val total = shown.size
    val allowed = shown.count { it !in missing }

    Box(Modifier.fillMaxSize()) {
        FocusBackground(Modifier.matchParentSize())
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp)
        ) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Spacer(Modifier.height(28.dp))
            Text("Allow permissions to continue", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "LockDistra needs these to block apps and keep your timers reliable. The app opens as soon as every one is allowed. Not ready? You can skip.",
                style = MaterialTheme.typography.bodyMedium,
                color = c.muted
            )
            Spacer(Modifier.height(8.dp))
            Text("$allowed of $total allowed", style = MaterialTheme.typography.labelLarge, color = c.accent)
            Spacer(Modifier.height(16.dp))

            if (RequiredPermission.ACCESSIBILITY in shown) {
                PermissionRow(
                    title = "Accessibility service",
                    tag = "Required",
                    granted = RequiredPermission.ACCESSIBILITY !in missing,
                    body = "Lets LockDistra see which app is on screen while a session is running, so it can cover blocked apps with the stay-focused screen. Screen text is only compared on the phone. Nothing is recorded or shared.",
                    hint = "Settings > Accessibility > Installed apps > LockDistra > turn on.",
                    onGrant = { open(PermissionIntents.accessibility()) }
                )
                Spacer(Modifier.height(12.dp))
            }
            PermissionRow(
                title = "Usage access",
                tag = "Required",
                granted = RequiredPermission.USAGE_ACCESS !in missing,
                body = "A backup way to find the app in front, so blocking stays reliable on phones that limit accessibility. It only reads which app was opened last.",
                hint = "Settings > Usage access > LockDistra > allow.",
                onGrant = {
                    open(
                        PermissionIntents.usageAccess(context.packageName),
                        PermissionIntents.usageAccess(context.packageName).apply { data = null }
                    )
                }
            )
            Spacer(Modifier.height(12.dp))
            PermissionRow(
                title = "Notifications",
                tag = "Required",
                granted = RequiredPermission.NOTIFICATIONS !in missing,
                body = "Shows the status notification during a session and plays the plant reminder and study check-in prompts.",
                hint = null,
                onGrant = {
                    if (Build.VERSION.SDK_INT >= 33 && !askedNotifications) {
                        askedNotifications = true
                        LockSession.markOwnLaunch()
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        open(PermissionIntents.appNotifications(context.packageName))
                    }
                }
            )
            Spacer(Modifier.height(12.dp))
            PermissionRow(
                title = "Unrestricted battery",
                tag = "Required",
                granted = RequiredPermission.BATTERY !in missing,
                body = "Stops Android from putting LockDistra to sleep, so blocking, timers and reminders keep working with the screen off.",
                hint = if (SafetyConfig.PLAY_STORE_BUILD) "Find LockDistra in the list and choose Unrestricted / Don't optimize." else "Tap Allow on the prompt.",
                onGrant = {
                    if (SafetyConfig.PLAY_STORE_BUILD) {
                        open(PermissionIntents.batteryList())
                    } else {
                        open(PermissionIntents.batteryRequest(context.packageName), PermissionIntents.batteryList())
                    }
                }
            )
            if (RequiredPermission.EXACT_ALARMS in shown) {
                Spacer(Modifier.height(12.dp))
                PermissionRow(
                    title = "Alarms & reminders",
                    tag = "Required",
                    granted = RequiredPermission.EXACT_ALARMS !in missing,
                    body = "Lets timers, Pomodoro breaks and study check-ins fire at the exact second, even when the phone is idle.",
                    hint = "Settings > Alarms & reminders > LockDistra > allow.",
                    onGrant = {
                        open(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                .setData(Uri.parse("package:${context.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            PermissionIntents.appNotifications(context.packageName)
                        )
                    }
                )
            }
            Spacer(Modifier.height(16.dp))
        }
            // Always visible, whatever the screen size: leave this page without allowing everything.
            Text(
                "Skipped permissions can be allowed later in Settings. Features that need one will ask first.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 10.dp)
            )
            SecondaryButton(text = "Skip for now", onClick = onSkip)
            Spacer(Modifier.height(16.dp))
        }
    }
}
