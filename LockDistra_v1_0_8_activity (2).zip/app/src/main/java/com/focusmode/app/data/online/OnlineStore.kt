package com.focusmode.app.data.online

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.focusmode.app.data.Credentials
import com.focusmode.app.data.LockRules
import com.focusmode.app.data.VerifyResult
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** What the UI may know. Never contains the pair key or the recovery code. */
data class OnlineState(
    val mode: UnlockMode = UnlockMode.PASSWORD,
    /** This phone is paired with a trusted phone that can approve its unlocks. */
    val phoneConnected: Boolean = false,
    val approverName: String? = null,
    /** This phone is the trusted approver of another phone. */
    val isApprover: Boolean = false,
    val ownerName: String? = null,
    val hasRecovery: Boolean = false,
    /** Optional login: the name the trusted phone shows on this phone's requests. */
    val accountName: String? = null,
    val accountEmail: String? = null,
    /** True once the first-run login screen was answered (logged in or skipped). */
    val loginAsked: Boolean = false,
)

data class RequesterLink(val approverUid: String, val approverName: String, val pairKey: ByteArray)
data class ApproverLink(val ownerUid: String, val ownerName: String, val pairKey: ByteArray)

/**
 * Local side of Online Approval. Same care as the PIN lock (LockStore):
 *  - the pair key is encrypted with a non-exportable Android Keystore key and is never stored in
 *    the clear (if the Keystore is unusable, pairing is refused instead of storing it plain);
 *  - the offline recovery code is kept only as a salted PBKDF2 hash;
 *  - nothing here goes into backups (allowBackup is off) and no server secret lives here.
 * It never touches the PIN / password data.
 */
class OnlineStore private constructor(context: Context) {

    private val appContext = context.applicationContext
    private val prefs: SharedPreferences = appContext.getSharedPreferences("online_unlock", Context.MODE_PRIVATE)
    private val lock = Any()

    private val _state = MutableStateFlow(read())
    val state: StateFlow<OnlineState> = _state.asStateFlow()

    private fun read() = OnlineState(
        mode = UnlockMode.fromId(prefs.getString(K_MODE, null)),
        phoneConnected = prefs.contains(K_REQ_UID) && prefs.contains(K_REQ_KEY),
        approverName = prefs.getString(K_REQ_NAME, null),
        isApprover = prefs.contains(K_APR_UID) && prefs.contains(K_APR_KEY),
        ownerName = prefs.getString(K_APR_NAME, null),
        hasRecovery = prefs.contains(K_REC_HASH),
        accountName = prefs.getString(K_ACC_NAME, null),
        accountEmail = prefs.getString(K_ACC_EMAIL, null),
        loginAsked = prefs.getBoolean(K_LOGIN_ASKED, false),
    )

    private fun publish() {
        _state.value = read()
    }

    fun current(): OnlineState = read()

    // ---- Mode ------------------------------------------------------------------------------------

    fun mode(): UnlockMode = UnlockMode.fromId(prefs.getString(K_MODE, null))

    fun setMode(mode: UnlockMode) {
        prefs.edit().putString(K_MODE, mode.id).apply()
        publish()
    }

    // ---- This device ------------------------------------------------------------------------------

    /** Random id made once on this phone. Part of every request, so a request is bound to it. */
    fun deviceId(): String = synchronized(lock) {
        prefs.getString(K_DEVICE, null) ?: ApprovalProtocol.newDeviceId().also {
            prefs.edit().putString(K_DEVICE, it).commit()
        }
    }

    fun deviceName(): String {
        // A logged-in name wins, so the trusted phone shows "Prince Yadav" instead of a phone model.
        prefs.getString(K_ACC_NAME, null)?.trim()?.takeIf { it.isNotEmpty() }?.let { return it.take(40) }
        val model = (Build.MODEL ?: "Android phone").trim().take(30)
        return model.ifBlank { "Android phone" }
    }

    // ---- Optional account (only a display name and the email, no password is stored) ----------------

    fun saveAccount(name: String, email: String) {
        prefs.edit().putString(K_ACC_NAME, name).putString(K_ACC_EMAIL, email).putBoolean(K_LOGIN_ASKED, true).apply()
        publish()
    }

    fun clearAccount() {
        prefs.edit().remove(K_ACC_NAME).remove(K_ACC_EMAIL).apply()
        publish()
    }

    fun markLoginAsked() {
        prefs.edit().putBoolean(K_LOGIN_ASKED, true).apply()
        publish()
    }

    // ---- Link to the trusted phone (this phone is the one that gets locked) ---------------------

    fun requesterLink(): RequesterLink? = synchronized(lock) {
        val uid = prefs.getString(K_REQ_UID, null) ?: return null
        val name = prefs.getString(K_REQ_NAME, null) ?: "Trusted phone"
        val key = SecretBox.unwrap(prefs.getString(K_REQ_KEY, null) ?: return null) ?: return null
        RequesterLink(uid, name, key)
    }

    /** False when the key could not be stored safely. */
    fun saveRequesterLink(approverUid: String, approverName: String, pairKey: ByteArray): Boolean = synchronized(lock) {
        val wrapped = SecretBox.wrap(pairKey) ?: return false
        prefs.edit()
            .putString(K_REQ_UID, approverUid)
            .putString(K_REQ_NAME, approverName.take(40))
            .putString(K_REQ_KEY, wrapped)
            .putBoolean(K_BACKED_UP, false)
            .apply()
        publish()
        true
    }

    fun clearRequesterLink() = synchronized(lock) {
        prefs.edit().remove(K_REQ_UID).remove(K_REQ_NAME).remove(K_REQ_KEY).remove(K_REC_SALT).remove(K_REC_HASH)
            .putBoolean(K_BACKED_UP, false).apply()
        publish()
    }

    /** Logout: forgets the link on this phone only. The recovery code stays, because the server link stays and comes back at the next login. */
    fun clearRequesterLinkLocalOnly() = synchronized(lock) {
        prefs.edit().remove(K_REQ_UID).remove(K_REQ_NAME).remove(K_REQ_KEY).putBoolean(K_BACKED_UP, false).apply()
        publish()
    }

    // ---- Server backup of the connection (see OnlineManager.syncConnectionBackup) --------------------

    /** The server is known to hold everything needed to bring this phone's connection back (after logout / reinstall). */
    fun isBackedUp(): Boolean = prefs.getBoolean(K_BACKED_UP, false)

    fun setBackedUp(on: Boolean) = prefs.edit().putBoolean(K_BACKED_UP, on).apply()

    /** A disconnect that could not reach the server yet: "owner uid|approver uid" of the link still to be deleted there. */
    fun pendingUnlink(): Pair<String, String>? =
        prefs.getString(K_PENDING_UNLINK, null)?.split('|')?.takeIf { it.size == 2 && it[0].isNotEmpty() }?.let { it[0] to it[1] }

    fun setPendingUnlink(ownerUid: String, approverUid: String) =
        prefs.edit().putString(K_PENDING_UNLINK, "$ownerUid|$approverUid").apply()

    fun clearPendingUnlink() = prefs.edit().remove(K_PENDING_UNLINK).apply()

    // ---- Link to the locked phone (this phone is the trusted approver) --------------------------

    fun approverLink(): ApproverLink? = synchronized(lock) {
        val uid = prefs.getString(K_APR_UID, null) ?: return null
        val name = prefs.getString(K_APR_NAME, null) ?: "Phone"
        val key = SecretBox.unwrap(prefs.getString(K_APR_KEY, null) ?: return null) ?: return null
        ApproverLink(uid, name, key)
    }

    fun saveApproverLink(ownerUid: String, ownerName: String, pairKey: ByteArray): Boolean = synchronized(lock) {
        val wrapped = SecretBox.wrap(pairKey) ?: return false
        prefs.edit()
            .putString(K_APR_UID, ownerUid)
            .putString(K_APR_NAME, ownerName.take(40))
            .putString(K_APR_KEY, wrapped)
            .putBoolean(K_BACKED_UP, false)
            .apply()
        publish()
        true
    }

    fun clearApproverLink() = synchronized(lock) {
        prefs.edit().remove(K_APR_UID).remove(K_APR_NAME).remove(K_APR_KEY).putBoolean(K_BACKED_UP, false).apply()
        publish()
    }

    // ---- Offline recovery code (for when the trusted phone can't be reached) ----------------------

    /** Makes a new code, stores only its hash, returns the code to show once. */
    fun newRecoveryCode(): String = synchronized(lock) {
        val code = Credentials.newRecoveryCode()
        val salt = Credentials.newSalt()
        val hash = Credentials.hash(Credentials.normalizeRecovery(code), salt)
        prefs.edit()
            .putString(K_REC_SALT, Credentials.b64(salt))
            .putString(K_REC_HASH, Credentials.b64(hash))
            .apply()
        clearFailures()
        publish()
        code
    }

    fun recoveryLockoutRemainingMs(): Long = remaining()

    /** Slow on purpose (PBKDF2): call off the main thread. Wrong tries are paused like the PIN's. */
    fun checkRecovery(code: String): VerifyResult = synchronized(lock) {
        val wait = remaining()
        if (wait > 0) return VerifyResult.LockedOut(wait)
        val saltText = prefs.getString(K_REC_SALT, null) ?: return VerifyResult.Unreadable
        val hashText = prefs.getString(K_REC_HASH, null) ?: return VerifyResult.Unreadable
        val normalized = Credentials.normalizeRecovery(code)
        if (normalized.length != Credentials.RECOVERY_LENGTH) return registerFailure()
        val expected = runCatching { Credentials.unb64(hashText) }.getOrNull() ?: return VerifyResult.Unreadable
        val salt = runCatching { Credentials.unb64(saltText) }.getOrNull() ?: return VerifyResult.Unreadable
        if (Credentials.equal(Credentials.hash(normalized, salt), expected)) {
            clearFailures()
            VerifyResult.Ok
        } else {
            registerFailure()
        }
    }

    // ---- Single use: a request id that was spent is never accepted again -----------------------

    fun isUsed(requestId: String): Boolean =
        (prefs.getString(K_USED, "") ?: "").split(',').contains(requestId)

    fun markUsed(requestId: String) = synchronized(lock) {
        val ids = (prefs.getString(K_USED, "") ?: "").split(',').filter { it.isNotBlank() }
        val next = (ids + requestId).takeLast(MAX_USED_IDS).joinToString(",")
        prefs.edit().putString(K_USED, next).commit()
    }

    // ---- Push token waiting to be sent (trusted phone) ------------------------------------------

    fun savePendingToken(token: String) = prefs.edit().putString(K_TOKEN, token).apply()
    fun pendingToken(): String? = prefs.getString(K_TOKEN, null)
    fun clearPendingToken() = prefs.edit().remove(K_TOKEN).apply()

    // The token the Worker already has, so the same token is not sent again on every app start.
    fun registeredToken(): String? = prefs.getString("push_registered_token", null)
    fun registeredAt(): Long = prefs.getLong("push_registered_at", 0L)
    fun saveRegistered(token: String, at: Long) =
        prefs.edit().putString("push_registered_token", token).putLong("push_registered_at", at).apply()
    fun clearRegistered() = prefs.edit().remove("push_registered_token").remove("push_registered_at").apply()

    // ---- Wrong-try counting that survives restarts (same idea as LockStore) -----------------------

    private fun bootCount(): Int =
        runCatching { Settings.Global.getInt(appContext.contentResolver, Settings.Global.BOOT_COUNT, -1) }
            .getOrDefault(-1)

    private fun registerFailure(): VerifyResult.Wrong {
        val failures = prefs.getInt(K_FAILS, 0) + 1
        val pause = LockRules.lockoutMs(failures)
        val editor = prefs.edit().putInt(K_FAILS, failures)
        if (pause > 0) {
            editor.putLong(K_UNTIL_WALL, System.currentTimeMillis() + pause)
                .putLong(K_UNTIL_ELAPSED, SystemClock.elapsedRealtime() + pause)
                .putInt(K_BOOT, bootCount())
        }
        editor.apply()
        return VerifyResult.Wrong(failures, pause)
    }

    private fun clearFailures() {
        prefs.edit().remove(K_FAILS).remove(K_UNTIL_WALL).remove(K_UNTIL_ELAPSED).remove(K_BOOT).apply()
    }

    private fun remaining(): Long {
        val wall = prefs.getLong(K_UNTIL_WALL, 0L)
        if (wall == 0L) return 0L
        val sameBoot = prefs.getInt(K_BOOT, -2) == bootCount() && bootCount() != -1
        val left = if (sameBoot) {
            prefs.getLong(K_UNTIL_ELAPSED, 0L) - SystemClock.elapsedRealtime()
        } else {
            wall - System.currentTimeMillis()
        }
        return left.coerceIn(0L, LockRules.MAX_LOCKOUT_MS)
    }

    // ---- Keystore wrapping --------------------------------------------------------------------------

    /** AES-GCM with a non-exportable Keystore key. Unlike LockStore there is NO plain fallback. */
    private object SecretBox {
        private const val ALIAS = "focusmode_online_v1"
        private const val PROVIDER = "AndroidKeyStore"

        private fun key(): SecretKey {
            val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
            (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
            gen.init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            return gen.generateKey()
        }

        fun wrap(plain: ByteArray): String? = try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key())
            val ct = cipher.doFinal(plain)
            "k:" + Credentials.b64(cipher.iv) + ":" + Credentials.b64(ct)
        } catch (_: Exception) {
            null
        }

        fun unwrap(text: String): ByteArray? = try {
            if (!text.startsWith("k:")) {
                null
            } else {
                val parts = text.removePrefix("k:").split(':')
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Credentials.unb64(parts[0])))
                cipher.doFinal(Credentials.unb64(parts[1]))
            }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private const val K_ACC_NAME = "acc_name"
        private const val K_ACC_EMAIL = "acc_email"
        private const val K_LOGIN_ASKED = "login_asked"
        private const val K_MODE = "mode"
        private const val K_DEVICE = "device_id"
        private const val K_REQ_UID = "req_approver_uid"
        private const val K_REQ_NAME = "req_approver_name"
        private const val K_REQ_KEY = "req_pair_key"
        private const val K_APR_UID = "apr_owner_uid"
        private const val K_APR_NAME = "apr_owner_name"
        private const val K_APR_KEY = "apr_pair_key"
        private const val K_REC_SALT = "rec_salt"
        private const val K_REC_HASH = "rec_hash"
        private const val K_BACKED_UP = "link_backed_up"
        private const val K_PENDING_UNLINK = "pending_unlink"
        private const val K_USED = "used_requests"
        private const val K_TOKEN = "pending_token"
        private const val K_FAILS = "rec.fails"
        private const val K_UNTIL_WALL = "rec.untilWall"
        private const val K_UNTIL_ELAPSED = "rec.untilElapsed"
        private const val K_BOOT = "rec.boot"
        private const val MAX_USED_IDS = 50

        @Volatile private var instance: OnlineStore? = null

        fun get(context: Context): OnlineStore =
            instance ?: synchronized(this) {
                instance ?: OnlineStore(context).also { instance = it }
            }
    }
}
