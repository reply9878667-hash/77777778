package com.focusmode.app.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.focusmode.app.R
import com.focusmode.app.data.FocusProfileRules
import com.focusmode.app.data.FocusProfilesState
import com.focusmode.app.ui.auth.AuthTextField
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusBackground
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusTabBar
import com.focusmode.app.ui.components.NightScenery
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SecondaryButton
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.TabBarItem
import com.focusmode.app.ui.components.staggeredEntrance
import com.focusmode.app.ui.theme.FocusTheme

private val profileTabs = listOf(
    TabBarItem("Profile", Icons.Outlined.Shield, Icons.Filled.Shield),
    TabBarItem("Blocking", Icons.Outlined.Block, Icons.Filled.Block),
)
private const val TAB_PROFILE = 0
private const val TAB_BLOCKING = 1

/**
 * Create / Edit Focus Profile, laid out like the main LockDistra screens: the same header (logo tile, back button),
 * night-scene hero card, FocusCards, buttons and glass bottom bar. There is no Settings tab or section here.
 * Only the title differs: "Create Focus Profile" while the slot is empty, "Edit Focus Profile" once it is saved.
 *
 * Tab "Profile": pick Profile #1 or #2 (that is also how the profile in use is chosen) and name it.
 * Tab "Blocking": the existing Blocking screen, shown on this profile's own data through [settingsScreen].
 * Saving, editing, deleting and selecting go through the same callbacks as before.
 */
@Composable
fun FocusProfileScreen(
    profiles: FocusProfilesState,
    onBack: () -> Unit,
    onSave: (slot: Int, name: String) -> Boolean,
    onDelete: (slot: Int) -> Unit,
    onSelect: (slot: Int) -> Unit,
    /** The existing Blocking screen for the profile in [slot]; call the second argument to close it. */
    settingsScreen: @Composable (slot: Int, onBack: () -> Unit) -> Unit,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val focus = LocalFocusManager.current

    // Start on the profile in use, otherwise on the first empty slot.
    var slot by rememberSaveable {
        mutableStateOf(
            profiles.selectedSlot.takeIf { it > 0 }
                ?: FocusProfileRules.SLOTS.firstOrNull { profiles.get(it) == null }
                ?: 1
        )
    }
    val saved = profiles.get(slot)
    val isEdit = saved != null

    // The text box restarts from the saved name whenever another slot is picked or this one is deleted.
    var name by rememberSaveable(slot, isEdit) { mutableStateOf(saved?.name.orEmpty()) }
    var nameError by remember(slot) { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(TAB_PROFILE) }
    // A new profile was just saved for the Blocking screen: open it once the saved profile has arrived.
    var openAfterSave by remember { mutableStateOf(false) }
    LaunchedEffect(openAfterSave, isEdit) {
        if (openAfterSave && isEdit) {
            openAfterSave = false
            tab = TAB_BLOCKING
        }
    }

    BackHandler(enabled = tab == TAB_BLOCKING) { tab = TAB_PROFILE }

    // The slot was deleted or another empty slot was picked while on the Blocking tab: back to the Profile tab.
    LaunchedEffect(isEdit, openAfterSave) {
        if (!isEdit && !openAfterSave && tab == TAB_BLOCKING) tab = TAB_PROFILE
    }

    /** Saves the name; false when it is not valid. */
    fun saveName(): Boolean {
        focus.clearFocus()
        nameError = FocusProfileRules.nameError(name)
        if (nameError != null) return false
        if (!onSave(slot, name)) return false
        name = FocusProfileRules.cleanName(name)
        return true
    }

    fun save() {
        if (saveName()) Toast.makeText(context, "Profile saved", Toast.LENGTH_SHORT).show()
    }

    val title = if (isEdit) "Edit Focus Profile" else "Create Focus Profile"
    val keyboardOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    // Opaque, so the Home screen underneath never shows through while the screen expands.
    Box(Modifier.fillMaxSize()) {
        FocusBackground(Modifier.matchParentSize())
        Column(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    // The tab bar below takes the navigation inset, so the content above must not add it twice.
                    .then(if (!keyboardOpen) Modifier.consumeWindowInsets(WindowInsets.navigationBars) else Modifier)
            ) {
                if (tab == TAB_BLOCKING && isEdit) {
                    // The existing Blocking screen, on this profile's settings.
                    settingsScreen(slot) { tab = TAB_PROFILE }
                } else {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .imePadding()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 20.dp)
                    ) {
                        Box(Modifier.staggeredEntrance(0)) { ProfileHeader(title = title, onBack = onBack) }
                        Spacer(Modifier.height(12.dp))

                        Box(Modifier.fillMaxWidth().staggeredEntrance(1)) {
                            ProfileHero(
                                slotLabel = FocusProfileRules.defaultName(slot),
                                name = saved?.name,
                                inUse = profiles.selectedSlot == slot && isEdit,
                                summary = saved?.settings?.summary(),
                            )
                        }

                        Spacer(Modifier.height(20.dp))
                        SectionLabel("Your profiles (up to ${FocusProfileRules.MAX_PROFILES})")
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FocusProfileRules.SLOTS.forEach { s ->
                                SlotCard(
                                    slot = s,
                                    name = profiles.get(s)?.name,
                                    inUse = profiles.selectedSlot == s,
                                    picked = slot == s,
                                    onClick = { focus.clearFocus(); slot = s },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(Modifier.height(20.dp))
                        SectionLabel("Profile name")
                        AuthTextField(
                            value = name,
                            onValueChange = { name = it.take(FocusProfileRules.MAX_NAME); nameError = null },
                            label = "Name",
                            error = nameError,
                            enabled = true,
                            last = true,
                            hint = "For example: Study, Work or Night.",
                            onDone = { save() },
                        )

                        Spacer(Modifier.height(20.dp))
                        SectionLabel("What this profile blocks")
                        FocusCard(
                            // A new profile is saved first (it needs a slot to keep its settings in).
                            onClick = { if (isEdit) tab = TAB_BLOCKING else if (saveName()) openAfterSave = true },
                            padding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                            highlight = isEdit,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconTile(Icons.Outlined.Block)
                                Spacer(Modifier.size(14.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Blocking & limits", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        saved?.settings?.summary() ?: "Apps, games, Shorts/Reels, websites and app limits. Saves the profile first.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isEdit) c.accent else c.muted,
                                    )
                                }
                                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = c.muted)
                            }
                        }

                        Spacer(Modifier.height(20.dp))
                        PrimaryButton("Save Profile", onClick = { save() })

                        if (saved != null && profiles.selectedSlot != slot) {
                            Spacer(Modifier.height(12.dp))
                            SecondaryButton("Use this profile", onClick = { onSelect(slot) })
                        }

                        if (saved != null) {
                            Spacer(Modifier.height(4.dp))
                            TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Delete Profile", color = c.warning)
                            }
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }

            // Same glass bar as the main screens, with only the two profile tabs (no Settings).
            if (!keyboardOpen) {
                FocusTabBar(
                    items = profileTabs,
                    selectedIndex = tab,
                    onSelect = { i ->
                        focus.clearFocus()
                        when {
                            i == TAB_PROFILE -> tab = TAB_PROFILE
                            isEdit -> tab = TAB_BLOCKING
                            // A new profile is saved first, then the Blocking tab opens on it.
                            saveName() -> openAfterSave = true
                        }
                    },
                )
            }
        }
    }

    if (confirmDelete && saved != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Delete this profile?", style = MaterialTheme.typography.titleLarge) },
            text = { Text("\"${saved.name}\" (${FocusProfileRules.defaultName(saved.slot)}) will be removed from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(saved.slot)
                }) { Text("Delete", color = c.warning) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Keep", color = c.accent) }
            }
        )
    }
}

/** Same header as the Home screen (logo tile + name), with the screen title instead of the greeting line. */
@Composable
private fun ProfileHeader(title: String, onBack: () -> Unit) {
    val c = FocusTheme.colors
    val tile = RoundedCornerShape(14.dp)
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
        Spacer(Modifier.size(14.dp))
        Image(
            painterResource(R.drawable.ic_lockdistra_logo),
            contentDescription = "LockDistra",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(48.dp)
                .shadow(10.dp, tile, ambientColor = c.glow, spotColor = c.glow)
                .clip(tile)
                .border(1.2.dp, Color.White.copy(alpha = 0.35f), tile)
        )
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = c.text, maxLines = 1)
            Row {
                Text("Lock", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = c.text)
                Text("Distra", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = c.accent)
            }
        }
    }
}

/** Night-scene card like the Home hero, showing the profile being worked on. */
@Composable
private fun ProfileHero(slotLabel: String, name: String?, inUse: Boolean, summary: String?) {
    val c = FocusTheme.colors
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxWidth().clip(shape).border(1.dp, c.stroke, shape)) {
        NightScenery(Modifier.matchParentSize())
        Column(Modifier.padding(horizontal = 20.dp, vertical = 20.dp)) {
            Text(
                name ?: slotLabel,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 24.sp),
                color = Color.White,
                maxLines = 1,
            )
            Text(
                when {
                    inUse -> "$slotLabel \u2022 In use"
                    name != null -> slotLabel
                    else -> "$slotLabel \u2022 Not saved yet"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFC9C2E6),
            )
            Spacer(Modifier.height(40.dp))
            Text(
                summary ?: "Name it, then choose what it blocks.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFC9C2E6),
            )
        }
    }
}

@Composable
private fun IconTile(icon: ImageVector) {
    val c = FocusTheme.colors
    Box(Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = c.accent, modifier = Modifier.size(24.dp))
    }
}

@Composable
private fun SlotCard(
    slot: Int,
    name: String?,
    inUse: Boolean,
    picked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    FocusCard(
        modifier = modifier,
        onClick = onClick,
        highlight = picked,
        padding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            IconTile(Icons.Outlined.Shield)
            Spacer(Modifier.height(8.dp))
            Text(FocusProfileRules.defaultName(slot), style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(2.dp))
            Text(
                name ?: "Empty",
                style = MaterialTheme.typography.bodySmall,
                color = if (name == null) c.muted else c.text,
                maxLines = 1,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                when {
                    inUse -> "In use"
                    name == null -> "Tap to create"
                    else -> "Tap to edit"
                },
                style = MaterialTheme.typography.labelSmall,
                color = if (inUse) c.accent else c.muted,
            )
        }
    }
}
