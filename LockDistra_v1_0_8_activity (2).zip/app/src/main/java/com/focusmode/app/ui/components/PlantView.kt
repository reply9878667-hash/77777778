package com.focusmode.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import com.focusmode.app.data.PLANT_MAX_GROWTH
import com.focusmode.app.ui.theme.FocusTheme
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private const val BRANCHES = 7
private const val LEAVES_PER_BRANCH = 4

private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

/**
 * A procedurally drawn plant. [growth] is 0..[PLANT_MAX_GROWTH]; every unit makes it a little
 * taller and leafier. It sways gently while [active] and sparkles whenever [growth] increases.
 */
@Composable
fun PlantView(
    growth: Int,
    active: Boolean,
    modifier: Modifier = Modifier,
    /**
     * Optional continuous growth, 0..1 (used by the Focus screen, where the plant follows the
     * session clock). When set it overrides [growth] and glides smoothly between updates.
     */
    progress: Float? = null,
) {
    val c = FocusTheme.colors

    val animatedGrowth by animateFloatAsState(
        targetValue = progress?.let { it.coerceIn(0f, 1f) * PLANT_MAX_GROWTH } ?: growth.toFloat(),
        animationSpec = if (progress != null) tween(1100, easing = LinearEasing)
        else tween(1600, easing = FastOutSlowInEasing),
        label = "plantGrowth"
    )

    val transition = rememberInfiniteTransition(label = "plantLoop")
    val sway by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(5600, easing = LinearEasing)),
        label = "sway"
    )
    val glow by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )

    // 0 -> 1 burst of sparkles, played each time the plant grows. 1 = at rest.
    val burst = remember { Animatable(1f) }
    val steps = progress?.let { (it.coerceIn(0f, 1f) * PLANT_MAX_GROWTH).toInt() } ?: growth
    var previous by remember { mutableIntStateOf(steps) }
    LaunchedEffect(steps) {
        if (steps > previous) {
            burst.snapTo(0f)
            burst.animateTo(1f, tween(1500, easing = LinearOutSlowInEasing))
        }
        previous = steps
    }

    val rnd = remember { List(64) { Random(it * 7919 + 13).nextFloat() } }

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val dp = density
        val g = animatedGrowth
        val p = (g / PLANT_MAX_GROWTH).coerceIn(0f, 1f)
        val ease = 1f - (1f - p) * (1f - p)
        val b = burst.value

        val baseX = w / 2f
        val baseY = h * 0.88f
        val trunkH = h * (0.10f + 0.62f * ease)
        val swayAmount = if (active) 1f else 0.35f
        val swing = sin(sway) * swayAmount * w * 0.02f

        fun trunkPoint(f: Float): Offset {
            val curve = sin(f * 2.6f) * w * 0.02f * p
            return Offset(baseX + curve + swing * f * f, baseY - trunkH * f)
        }

        val top = trunkPoint(1f)

        scale(scale = 1f + 0.045f * sin(b * PI.toFloat()), pivot = Offset(baseX, baseY)) {

            // Soft glow behind the plant.
            val glowStrength = (if (active) 0.22f else 0.10f) * (if (active) glow else 0.8f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c.leafMid.copy(alpha = glowStrength), Color.Transparent),
                    center = Offset(baseX, baseY - trunkH * 0.65f),
                    radius = h * 0.62f
                ),
                radius = h * 0.62f,
                center = Offset(baseX, baseY - trunkH * 0.65f)
            )

            // Ground.
            drawOval(
                color = c.soil,
                topLeft = Offset(w * 0.22f, baseY - h * 0.025f),
                size = Size(w * 0.56f, h * 0.075f)
            )
            drawOval(
                color = c.soil.copy(alpha = 0.55f),
                topLeft = Offset(w * 0.34f, baseY - h * 0.045f),
                size = Size(w * 0.32f, h * 0.05f)
            )

            // Soft canopy that appears as the tree matures.
            val canopy = ((p - 0.35f) / 0.65f).coerceIn(0f, 1f)
            if (canopy > 0f) {
                val r = h * 0.17f * canopy
                val tint = c.leafMid.copy(alpha = 0.16f)
                drawCircle(tint, r, Offset(top.x - h * 0.11f * canopy, top.y + h * 0.04f))
                drawCircle(tint, r, Offset(top.x + h * 0.11f * canopy, top.y + h * 0.04f))
                drawCircle(tint, r * 1.05f, Offset(top.x, top.y - h * 0.03f))
            }

            // Trunk, tapered.
            val wBase = (3f + 9f * ease) * dp
            val wTop = wBase * 0.35f
            val steps = 22
            var prev = trunkPoint(0f)
            for (i in 1..steps) {
                val f = i / steps.toFloat()
                val next = trunkPoint(f)
                drawLine(
                    color = c.trunk,
                    start = prev,
                    end = next,
                    strokeWidth = lerp(wBase, wTop, f),
                    cap = StrokeCap.Round
                )
                prev = next
            }

            // Branches with leaves.
            for (i in 0 until BRANCHES) {
                val threshold = 0.10f + i * 0.09f
                val raw = ((p - threshold) / 0.28f).coerceIn(0f, 1f)
                if (raw <= 0f) continue
                val bp = 1f - (1f - raw) * (1f - raw)

                val attach = (0.30f + 0.08f * i).coerceAtMost(0.85f)
                val side = if (i % 2 == 0) -1f else 1f
                val start = trunkPoint(attach)
                val length = trunkH * 0.42f * (1f - 0.06f * i) * bp
                val aRad = Math.toRadians((35f + 5f * i).toDouble()).toFloat()
                val dirX = side * cos(aRad)
                val dirY = -sin(aRad)
                val end = Offset(
                    start.x + dirX * length + swing * 0.5f * attach,
                    start.y + dirY * length
                )
                val ctrl = Offset(
                    start.x + dirX * length * 0.5f,
                    start.y + dirY * length * 0.5f - length * 0.12f
                )

                val path = Path().apply {
                    moveTo(start.x, start.y)
                    quadraticTo(ctrl.x, ctrl.y, end.x, end.y)
                }
                drawPath(
                    path, c.trunk,
                    style = Stroke(width = (1.2f + 2.6f * bp) * dp, cap = StrokeCap.Round)
                )

                val baseAngle = Math.toDegrees(atan2(dirY, dirX).toDouble()).toFloat()
                for (k in 0..LEAVES_PER_BRANCH) {
                    val t = if (k == LEAVES_PER_BRANCH) 1f else 0.30f + 0.17f * k
                    val inv = 1f - t
                    val x = inv * inv * start.x + 2 * inv * t * ctrl.x + t * t * end.x
                    val y = inv * inv * start.y + 2 * inv * t * ctrl.y + t * t * end.y
                    val r = rnd[(i * 5 + k) % rnd.size]
                    val offsetAngle = if (k == LEAVES_PER_BRANCH) 0f else if (k % 2 == 0) -55f else 55f
                    val wobble = sin(sway * 1.3f + i + k) * 6f * swayAmount
                    val leafLen = (7f + 6f * r) * dp * bp * (0.7f + 0.5f * ease)
                    val color = when ((i + k) % 3) {
                        0 -> c.leafLight
                        1 -> c.leafMid
                        else -> c.leafDeep
                    }
                    drawLeaf(x, y, baseAngle + offsetAngle + wobble, leafLen, color)
                }
            }

            // Crown: two seed leaves at first, a full fan of leaves later on.
            val crownCount = lerp(2f, 22f, p).toInt().coerceAtLeast(2)
            val spread = lerp(100f, 320f, p)
            val crownLen = h * (0.085f + 0.05f * ease)
            for (j in 0 until crownCount) {
                val step = if (crownCount > 1) spread / (crownCount - 1) else 0f
                val angle = -90f + (j - (crownCount - 1) / 2f) * step +
                    sin(sway + j) * 5f * swayAmount
                val r = rnd[(j * 3 + 11) % rnd.size]
                val len = crownLen * (0.8f + 0.4f * r)
                val color = when (j % 3) {
                    0 -> c.leafMid
                    1 -> c.leafLight
                    else -> c.leafDeep
                }
                drawLeaf(top.x, top.y, angle, len, color)
            }

            // Blossoms once the tree is nearly fully grown.
            val bloom = ((p - 0.85f) / 0.15f).coerceIn(0f, 1f)
            if (bloom > 0f) {
                for (j in 0 until 9) {
                    val r1 = rnd[(j * 2 + 20) % rnd.size]
                    val r2 = rnd[(j * 2 + 21) % rnd.size]
                    val ang = (r1 * 2f * PI).toFloat()
                    val dist = h * (0.05f + 0.13f * r2) * canopy
                    drawCircle(
                        color = c.blossom,
                        radius = 3.6f * dp * bloom * (0.7f + 0.5f * r1),
                        center = Offset(top.x + cos(ang) * dist * 1.25f, top.y + sin(ang) * dist * 0.8f)
                    )
                }
            }

            // Growth burst.
            if (b < 1f) {
                val ringR = lerp(0f, h * 0.42f, b)
                val fade = 1f - b
                drawCircle(
                    color = c.leafLight.copy(alpha = 0.55f * fade),
                    radius = ringR,
                    center = top,
                    style = Stroke(width = 2f * dp)
                )
                for (j in 0 until 12) {
                    val ang = (j / 12f * 2f * PI).toFloat()
                    val d = lerp(0f, h * 0.36f, b) * (0.7f + 0.3f * rnd[j])
                    drawCircle(
                        color = c.leafLight.copy(alpha = fade),
                        radius = (1.2f + 2.6f * fade) * dp,
                        center = Offset(top.x + cos(ang) * d, top.y + sin(ang) * d)
                    )
                }
            }
        }
    }
}

/** Leaf pointing along [angleDeg] (0 = right, -90 = up), starting at (x, y). */
private fun DrawScope.drawLeaf(x: Float, y: Float, angleDeg: Float, len: Float, color: Color) {
    if (len <= 0.5f) return
    val path = Path().apply {
        moveTo(0f, 0f)
        quadraticTo(len * 0.5f, -len * 0.42f, len, 0f)
        quadraticTo(len * 0.5f, len * 0.42f, 0f, 0f)
        close()
    }
    withTransform({
        translate(x, y)
        rotate(angleDeg, Offset.Zero)
    }) {
        drawPath(path, color)
    }
}
