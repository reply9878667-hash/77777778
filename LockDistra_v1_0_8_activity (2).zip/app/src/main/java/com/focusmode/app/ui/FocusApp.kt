package com.focusmode.app.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.widget.Toast
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import com.focusmode.app.ui.components.BottomBarScreens
import com.focusmode.app.ui.components.FocusBottomBar
import com.focusmode.app.ui.components.FocusBackground
import com.focusmode.app.ui.components.FloatingFocusButton
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.data.AppRepository
import com.focusmode.app.data.FocusOffMethod
import com.focusmode.app.data.FocusOffRules
import com.focusmode.app.data.StartPreviewRules
import com.focusmode.app.data.LockSession
import com.focusmode.app.service.RequiredPermission
import com.focusmode.app.data.ContentPolicy
import com.focusmode.app.ui.screens.AppsScreen
import com.focusmode.app.ui.screens.KeywordActions
import com.focusmode.app.ui.screens.WebsiteLimitActions
import com.focusmode.app.data.WebsiteLimitRules
import com.focusmode.app.ui.screens.ConfirmStopDialog
import com.focusmode.app.ui.screens.FocusOffOnlineDialog
import com.focusmode.app.ui.screens.FocusOffPasswordDialog
import com.focusmode.app.ui.screens.LockedStopDialog
import com.focusmode.app.ui.screens.DashboardScreen
import com.focusmode.app.ui.screens.DurationSheet
import com.focusmode.app.ui.screens.EmergencyAppsScreen
import com.focusmode.app.ui.screens.EmergencyChoice
import com.focusmode.app.ui.screens.EducationScreen
import com.focusmode.app.ui.screens.EmergencySheet
import com.focusmode.app.ui.screens.FeaturesScreen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.graphics.TransformOrigin
import com.focusmode.app.ui.screens.FocusProfileBlockingScreen
import com.focusmode.app.ui.screens.FocusProfileScreen
import com.focusmode.app.ui.screens.LimitsScreen
import com.focusmode.app.ui.online.ApprovalsScreen
import com.focusmode.app.ui.auth.AuthFlow
import com.focusmode.app.ui.profile.ProfileScreen
import com.focusmode.app.data.auth.AuthSession
import com.focusmode.app.ui.auth.AuthScreen
import com.focusmode.app.ui.online.ChangesLockedBar
import com.focusmode.app.ui.online.GateScreen
import com.focusmode.app.ui.online.UnlockChangesDialog
import com.focusmode.app.ui.screens.PermissionIntents
import com.focusmode.app.ui.screens.PermissionSheet
import com.focusmode.app.ui.screens.ProfileDialog
import com.focusmode.app.ui.screens.CheckInOverlay
import com.focusmode.app.ui.screens.PlantScreen
import com.focusmode.app.ui.screens.SettingsScreen
import com.focusmode.app.ui.screens.SessionScreen
import com.focusmode.app.ui.screens.StartWizard
import com.focusmode.app.data.FocusControl
import com.focusmode.app.data.AutoFocusStore
import com.focusmode.app.data.LectureLockStore
import com.focusmode.app.ui.autofocus.AutoFocusChip
import com.focusmode.app.ui.autofocus.AutoFocusDialog
import com.focusmode.app.ui.autofocus.AutoFocusHost
import com.focusmode.app.ui.tips.FeatureTips
import com.focusmode.app.ui.tips.FeatureTipsHost
import com.focusmode.app.ui.suggest.SmartSuggestHost
import com.focusmode.app.data.SmartSuggest
import com.focusmode.app.data.SmartSuggestStore
import com.focusmode.app.ui.tips.FeatureTipsStore
import com.focusmode.app.ui.tips.tipTarget
import com.focusmode.app.ui.screens.SplashState
import com.focusmode.app.ui.theme.FocusModeTheme
import com.focusmode.app.ui.theme.FocusTheme

/**
 * Entry point. With app lock on, nothing of LockDistra's own UI (dashboard, settings, emergency
 * limits ...) is composed until the PIN / password or fingerprint is right. The lock screen comes
 * back after a restart, after the app was closed, and after it was in the background longer than
 * the chosen time. Blocking and limits run in services and don't depend on it.
 *
 * Behind the lock, [AppEntry] (Task 3) chooses between the onboarding, the account screens and Home.
 */
@Composable
fun FocusApp(vm: AppViewModel) {
    val lock by vm.lock.collectAsStateWithLifecycle()
    val online by vm.onlineState.collectAsStateWithLifecycle()
    val gateActive by vm.gateActive.collectAsStateWithLifecycle()
    if (gateActive && !LockSession.unlocked) {
        val state by vm.state.collectAsStateWithLifecycle()
        // The lock screen carries its own branding, so the splash is skipped this launch.
        SideEffect { SplashState.shown = true }
        FocusModeTheme(state.themeMode) {
            val view = LocalView.current
            val darkTheme = FocusTheme.colors.isDark
            SideEffect {
                val window = (view.context as? Activity)?.window
                if (window != null) {
                    val controller = WindowCompat.getInsetsController(window, view)
                    controller.isAppearanceLightStatusBars = !darkTheme
                    controller.isAppearanceLightNavigationBars = !darkTheme
                }
            }
            GateScreen(vm = vm, lock = lock, online = online)
        }
    } else {
        AppEntry(vm)
    }
}

/** Screens that edit limits, blocked apps or emergency apps: they show the "Changes are locked" bar. */
private val CHANGE_SCREENS = setOf(Screen.Apps, Screen.Limits, Screen.Emergency, Screen.Features, Screen.Education)

/**
 * Home and everything behind it (Settings, Profile, limits ...). Only composed by [AppEntry] while someone is logged in
 * (or when accounts are not set up in this build), so nothing here has to check for a login itself.
 */
@Composable
internal fun FocusAppContent(vm: AppViewModel, showSplash: Boolean) {
    val state by vm.state.collectAsStateWithLifecycle()
    val permissions by vm.permissions.collectAsStateWithLifecycle()
    val apps by vm.apps.collectAsStateWithLifecycle()
    val appsLoaded by vm.appsLoaded.collectAsStateWithLifecycle()
    val limitsState by vm.limits.collectAsStateWithLifecycle()
    val emergencyState by vm.emergency.collectAsStateWithLifecycle()
    val contentState by vm.content.collectAsStateWithLifecycle()
    val websiteState by vm.websites.collectAsStateWithLifecycle()
    val keywordState by vm.keywords.collectAsStateWithLifecycle()
    val websiteLimitState by vm.websiteLimits.collectAsStateWithLifecycle()
    val bedtimeState by vm.bedtime.collectAsStateWithLifecycle()
    val pomodoroState by vm.pomodoro.collectAsStateWithLifecycle()
    val lockState by vm.lock.collectAsStateWithLifecycle()
    val accountState by vm.onlineState.collectAsStateWithLifecycle()
    val authSession by vm.auth.session.collectAsStateWithLifecycle()
    // Home's first-open shimmer starts once the splash screen is gone.
    LaunchedEffect(showSplash) { if (!showSplash) com.focusmode.app.ui.components.HomeShimmer.armed = true }

    FocusModeTheme(state.themeMode) {
        val context = LocalContext.current

        // Auto Focus (schedule) and the gradual feature hints. Both live on this phone only.
        val autoFocusStore = remember { AutoFocusStore.get(context) }
        val autoFocus by autoFocusStore.schedule.collectAsStateWithLifecycle()
        val tipsStore = remember { FeatureTipsStore.get(context) }
        val tipsState by tipsStore.state.collectAsStateWithLifecycle()
        var showAutoFocus by remember { mutableStateOf(false) }

        // Usage that the hints are paced by: one app launch, and every Focus session that begins while the app is open.
        LaunchedEffect(Unit) { tipsStore.recordOpen() }
        // Smart Feature Suggestions: counts app openings and remembers what was suggested / dismissed / used.
        val suggestStore = remember { SmartSuggestStore.get(context) }
        LaunchedEffect(Unit) { suggestStore.recordOpen() }

        // Lecture Lock: the video chosen in the start wizard (null = skipped). Cleared when the session ends or the start is cancelled.
        val lectureStore = remember { LectureLockStore.get(context) }
        // Opens the chosen lecture in LockDistra's own player (any platform) the moment the session begins.
        val openLecture = {
            lectureStore.url?.let { url ->
                LockSession.markOwnLaunch()
                runCatching { context.startActivity(com.focusmode.app.LectureActivity.launchIntent(context, url)) }
            }
            Unit
        }

        var wasFocusActive by remember { mutableStateOf(state.focusActive) }
        LaunchedEffect(state.focusActive) {
            if (state.focusActive && !wasFocusActive) {
                tipsStore.recordSessionStart()
                openLecture()
            }
            wasFocusActive = state.focusActive
        }
        var wasPomodoroActive by remember { mutableStateOf(pomodoroState.active) }
        LaunchedEffect(pomodoroState.active) {
            if (pomodoroState.active && !wasPomodoroActive) { openLecture(); suggestStore.markUsed(SmartSuggest.POMODORO) }
            wasPomodoroActive = pomodoroState.active
        }

        // A trusted phone jumps to "Unlock requests" the moment a verified request arrives.
        val approvals by vm.online.approvals.collectAsStateWithLifecycle()
        LaunchedEffect(approvals.map { it.id }) {
            if (approvals.isNotEmpty() && vm.screen != Screen.Approvals) vm.screen = Screen.Approvals
        }

        // "Connect this phone?" appears on whatever screen is open the moment the second phone
        // enters the connector code (outside the app, a notification brings the person here).
        com.focusmode.app.ui.online.PairingConfirmHost(vm.online)

        var showDuration by remember { mutableStateOf(false) }
        var showPermissions by remember { mutableStateOf(false) }
        var showEmergency by remember { mutableStateOf(false) }
        var showStop by remember { mutableStateOf(false) }
        var showLockedStop by remember { mutableStateOf(false) }
        // An "end Focus" action waiting for the chosen OFF method (Password / Online Approval) to be satisfied.
        var pendingOff by remember { mutableStateOf<(() -> Boolean)?>(null) }
        var pomodoroAfterPermissions by remember { mutableStateOf(false) }
        var showProfile by remember { mutableStateOf(false) }
        // Focus Profile screen (overlay, expands from the centre) and the "no profile yet" warning.
        var focusProfileOpen by rememberSaveable { mutableStateOf(false) }
        // The start wizard (profile / what is blocked / info / switches): "focus" or "pomodoro", null = closed.
        var wizardFor by remember { mutableStateOf<String?>(null) }
        // After leaving the plant screen while a session runs, the floating button is highlighted with a hint.
        var showGrowthHint by remember { mutableStateOf(false) }
        var lastScreen by remember { mutableStateOf(vm.screen) }
        val focusProfiles by vm.focusProfiles.collectAsStateWithLifecycle()
        // Where the Profile screen's back arrow returns to (Home or Settings, whichever opened it).
        var profileReturn by rememberSaveable { mutableStateOf(Screen.Home) }
        // "Unlock changes" (Prevent changes): asked from the bar on the locked screens.
        var showUnlockChanges by remember { mutableStateOf(false) }
        var sessionAutoOpened by rememberSaveable { mutableStateOf(false) }
        var askedNotifications by remember { mutableStateOf(false) }
        // A feature was about to be switched on while the permission it needs is off (permission page was skipped).
        var permissionNeeded by remember { mutableStateOf<RequiredPermission?>(null) }
        // Account screens opened on demand (Settings > Account, Profile) while Home is open. The mandatory login and the
        // first-run sign-up are not here any more: AppEntry shows them before Home exists.
        var authOpen by rememberSaveable { mutableStateOf(false) }

        // Keep status / navigation bar icons readable: light icons on the dark splash and dark
        // theme, dark icons on the light theme.
        val view = LocalView.current
        val darkTheme = FocusTheme.colors.isDark
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                val lightBars = !darkTheme && !showSplash && vm.screen != Screen.Session
                controller.isAppearanceLightStatusBars = lightBars
                controller.isAppearanceLightNavigationBars = lightBars
            }
        }

        // The status notification's "Emergency access" action opens the picker directly.
        LaunchedEffect(vm.emergencyRequested) {
            if (vm.emergencyRequested) {
                // The notification shortcut follows the same rules as everything else.
                if (state.canUseEmergency && !state.emergencyActive(System.currentTimeMillis())) {
                    showEmergency = true
                }
                vm.emergencyRequested = false
            }
        }

        val notificationLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { vm.refreshPermissions() }

        fun openSettingsIntent(intent: Intent, fallback: Intent? = null) {
            // Going to a system page on purpose must not make the lock ask again at once.
            LockSession.markOwnLaunch()
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
                if (fallback != null) runCatching { context.startActivity(fallback) }
            }
        }

        val grantAccessibility = { openSettingsIntent(PermissionIntents.accessibility()) }
        val grantUsage = {
            openSettingsIntent(
                PermissionIntents.usageAccess(context.packageName),
                PermissionIntents.usageAccess(context.packageName).apply { data = null }
            )
        }
        val grantBattery = {
            if (com.focusmode.app.data.SafetyConfig.PLAY_STORE_BUILD) {
                openSettingsIntent(PermissionIntents.batteryList())
            } else {
                openSettingsIntent(
                    PermissionIntents.batteryRequest(context.packageName),
                    PermissionIntents.batteryList()
                )
            }
        }
        val grantOverlay = {
            openSettingsIntent(
                Intent(
                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    android.net.Uri.parse("package:" + context.packageName)
                ),
                Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            )
        }
        val grantNotifications = {
            if (Build.VERSION.SDK_INT >= 33 && !askedNotifications) {
                askedNotifications = true
                LockSession.markOwnLaunch()
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                openSettingsIntent(PermissionIntents.appNotifications(context.packageName))
            }
        }

        // Blocking features (Bedtime, website / Shorts / section blocking) work through the Accessibility service. Turning one ON
        // without it would look enabled but block nothing, so it asks for the permission instead. Turning OFF is always allowed.
        val allowEnable: (Boolean) -> Boolean = { on ->
            if (on && !permissions.accessibility) {
                permissionNeeded = RequiredPermission.ACCESSIBILITY
                false
            } else true
        }

        BackHandler(enabled = vm.screen != Screen.Home) {
            vm.screen = if (vm.screen == Screen.Profile) profileReturn else Screen.Home
        }

        BackHandler(enabled = focusProfileOpen) { focusProfileOpen = false }

        // How Focus Mode may be turned OFF (Settings > Focus). A method that lost its setup falls back to the normal button.
        val offError = FocusOffRules.setupError(
            state.offMethod, lockState.enabled, accountState.phoneConnected, accountState.hasRecovery, vm.online.configured,
        )
        val offMethodNow = FocusOffRules.effective(state.offMethod, offError)
        // Runs [action] (an existing stop / pause call) once the chosen method is satisfied. Locked sessions still say so.
        val requestOff: (() -> Boolean) -> Unit = { action ->
            if (offMethodNow == FocusOffMethod.NORMAL || !state.canTurnOff) {
                if (!action()) showLockedStop = true
            } else {
                pendingOff = action
            }
        }

        // Starting Focus Mode: the start wizard always comes first (profile check, what is blocked, info, switches).
        val beginSession = { wizardFor = "focus" }

        // Share to LockDistra: the clean lecture link waiting for the start wizard (null = the wizard was not opened by a share).
        var sharedForWizard by remember { mutableStateOf<String?>(null) }
        val sharedIn = vm.sharedLink
        LaunchedEffect(sharedIn) {
            val raw = sharedIn ?: return@LaunchedEffect
            vm.sharedLink = null
            val url = com.focusmode.app.data.LectureLink.parse(raw)?.url
            when {
                url == null ->
                    Toast.makeText(context, "No video link found in what was shared.", Toast.LENGTH_LONG).show()
                state.focusActive || pomodoroState.active ->
                    Toast.makeText(context, "A session is already running. Share the link again after it ends.", Toast.LENGTH_LONG).show()
                else -> {
                    vm.screen = Screen.Home
                    sharedForWizard = url
                    if (!permissions.accessibility) showPermissions = true else beginSession()
                }
            }
        }

        // Study tab > "Start Focus Mode": the same path as a shared link. The start wizard opens with this video as the lecture,
        // and the locked lecture player opens it once Focus Mode is on. A Short is told to the player as vertical (9:16).
        val startStudyVideo: (com.focusmode.app.data.StudyVideo) -> Unit = { video ->
            when {
                state.focusActive || pomodoroState.active ->
                    Toast.makeText(context, "A session is already running. Start the video after it ends.", Toast.LENGTH_LONG).show()
                else -> {
                    if (video.isShort) lectureStore.saveRatio(video.id, 9f / 16f)
                    vm.screen = Screen.Home
                    sharedForWizard = video.watchUrl
                    if (!permissions.accessibility) showPermissions = true else beginSession()
                }
            }
        }

        // Study: while a session runs, tapping a video swaps the lecture (the locked player opens with the new video).
        val switchLecture: (com.focusmode.app.data.StudyVideo) -> Unit = { video ->
            if (video.isShort) lectureStore.saveRatio(video.id, 9f / 16f)
            lectureStore.set(video.watchUrl)
            openLecture()
        }

        // The video player's "Start Focus Mode": when the app is back in front, the start wizard opens with that video.
        val startStudyNow by androidx.compose.runtime.rememberUpdatedState(startStudyVideo)
        val resumeOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
        androidx.compose.runtime.DisposableEffect(resumeOwner) {
            val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                    com.focusmode.app.data.StudyStore.get(context).takeFocusStart()?.let { startStudyNow(it) }
                }
            }
            resumeOwner.lifecycle.addObserver(observer)
            onDispose { resumeOwner.lifecycle.removeObserver(observer) }
        }

        // Coming back from the plant screen while the session still runs: point at the floating button.
        LaunchedEffect(vm.screen, state.focusActive) {
            if (lastScreen == Screen.Session && vm.screen == Screen.Home && state.focusActive) {
                showGrowthHint = true
            } else if (!state.focusActive || vm.screen != Screen.Home) {
                showGrowthHint = false
            }
            lastScreen = vm.screen
        }

        // Starts the Pomodoro itself (after the wizard). Notifications are optional: ask once (Android 13+), start either way.
        val launchPomodoro = {
            if (Build.VERSION.SDK_INT >= 33 && !permissions.notifications && !askedNotifications) {
                askedNotifications = true
                LockSession.markOwnLaunch()
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            vm.startPomodoro()
        }

        // No session, no wizard, no duration sheet open: nothing can still need the lecture link, so forget it.
        // (The short wait covers the moment between "wizard closed" and "session state updated".)
        val anySessionRunning = state.focusActive || pomodoroState.active
        LaunchedEffect(anySessionRunning, wizardFor, showDuration) {
            if (!anySessionRunning && wizardFor == null && !showDuration) {
                kotlinx.coroutines.delay(1500)
                lectureStore.clear()
            }
        }

        // Auto Focus: starts Focus Mode at the chosen time for exactly the time left, so it ends at the chosen end time.
        AutoFocusHost(
            store = autoFocusStore,
            focusActive = state.focusActive,
            pomodoroActive = pomodoroState.active,
            accessibilityOn = permissions.accessibility,
        )

        // A session that is already running when the app opens lands on the plant page; when a
        // session ends, the plant page closes by itself.
        LaunchedEffect(state.focusActive) {
            if (state.focusActive && !sessionAutoOpened && vm.screen == Screen.Home) {
                vm.screen = Screen.Session
            }
            if (!state.focusActive && vm.screen == Screen.Session) {
                vm.screen = Screen.Home
            }
            sessionAutoOpened = true
        }

        val installed = remember(apps) { apps.map { it.packageName }.toSet() }
        val blockedCount = if (appsLoaded) {
            state.blocked.count { it in installed } +
                if (state.blockShorts && AppRepository.YOUTUBE !in state.blocked) 1 else 0
        } else state.blocked.size

        val labels = remember(apps) { apps.associate { it.packageName to it.label } }
        val emergencyChoices = remember(emergencyState, labels) {
            emergencyState.apps.values
                .filter { it.enabled && labels.containsKey(it.pkg) }
                .sortedBy { labels[it.pkg]?.lowercase() ?: it.pkg }
                .map { EmergencyChoice(it.pkg, labels[it.pkg] ?: it.pkg, it.remaining, it.limit) }
        }

        // Bottom bar on the four main screens. Hidden under the splash and the full-screen prompts.
        val showBar = vm.screen in BottomBarScreens && !showSplash && !state.checkInPending && !authOpen && !focusProfileOpen

        // One full-screen background behind everything (status bar to navigation bar, edge to edge).
        Box(Modifier.fillMaxSize()) {
        FocusBackground(Modifier.matchParentSize(), immersive = vm.screen == Screen.Session)
        Column(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                // The bar below takes the system navigation inset, so the screens above must not add it twice.
                .then(if (showBar) Modifier.consumeWindowInsets(WindowInsets.navigationBars) else Modifier)
        ) {
            AnimatedContent(
                targetState = vm.screen,
                transitionSpec = {
                    val forward = targetState.ordinal > initialState.ordinal
                    val spec = tween<androidx.compose.ui.unit.IntOffset>(340, easing = FastOutSlowInEasing)
                    if (forward) {
                        (slideInHorizontally(spec) { it / 4 } + fadeIn(tween(300))) togetherWith
                            (slideOutHorizontally(spec) { -it / 6 } + fadeOut(tween(200)))
                    } else {
                        (slideInHorizontally(spec) { -it / 6 } + fadeIn(tween(300))) togetherWith
                            (slideOutHorizontally(spec) { it / 4 } + fadeOut(tween(200)))
                    }
                },
                label = "screens"
            ) { screen ->
                when (screen) {
                    Screen.Home -> DashboardScreen(
                        state = state,
                        permissions = permissions,
                        blockedCount = blockedCount,
                        onRingClick = {
                            when {
                                // One timer at a time: a Pomodoro break or pause blocks a plain session.
                                pomodoroState.active && !state.focusActive ->
                                    Toast.makeText(context, "Pomodoro is running. Stop it first to start a normal session.", Toast.LENGTH_SHORT).show()
                                state.focusActive ->
                                    if (!state.canTurnOff) showLockedStop = true
                                    else if (offMethodNow == FocusOffMethod.NORMAL) showStop = true
                                    else requestOff { vm.stopFocus() }
                                !permissions.accessibility -> showPermissions = true
                                else -> beginSession()
                            }
                        },
                        onEndEmergency = vm::endEmergency,
                        onOpenSettings = { vm.screen = Screen.Settings },
                        // Logged in: the full profile screen. Not logged in: the small name dialog, as before.
                        onOpenProfile = {
                            if (authSession is AuthSession.SignedIn) {
                                profileReturn = Screen.Home
                                vm.screen = Screen.Profile
                            } else {
                                showProfile = true
                            }
                        },
                        onFinishSetup = { showPermissions = true },
                        focusProfileName = focusProfiles.selected?.name,
                        onOpenFocusProfile = { focusProfileOpen = true },
                        emergencyLabel = labels[state.emergencyPkg].orEmpty(),
                        onControlChange = { control, allowed -> vm.setControl(control, allowed) },
                        pomodoro = pomodoroState,
                        exactAlarmsMissing = Build.VERSION.SDK_INT >= 31 && pomodoroState.active && !vm.canScheduleExactAlarms(),
                        onPomodoroStart = {
                            if (!permissions.accessibility) { pomodoroAfterPermissions = true; showPermissions = true }
                            else wizardFor = "pomodoro"
                        },
                        onPomodoroPause = {
                            if (FocusOffRules.gatesPomodoroAction(state.focusActive, pomodoroState.active)) requestOff { vm.pausePomodoro() }
                            else if (!vm.pausePomodoro()) showLockedStop = true
                        },
                        onPomodoroResume = vm::resumePomodoro,
                        onPomodoroStop = {
                            if (FocusOffRules.gatesPomodoroAction(state.focusActive, pomodoroState.active)) requestOff { vm.stopPomodoro() }
                            else if (!vm.stopPomodoro()) showLockedStop = true
                        },
                        onPomodoroDurations = { f, b -> vm.setPomodoroDurations(f, b) },
                        onGrantExactAlarms = {
                            openSettingsIntent(
                                Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                                    .setData(android.net.Uri.parse("package:${context.packageName}")),
                                PermissionIntents.appNotifications(context.packageName)
                            )
                        },
                    )

                    Screen.Session -> SessionScreen(
                        state = state,
                        // Back only leaves the screen: the session keeps running.
                        onBack = { vm.screen = Screen.Home },
                    )

                    Screen.Plant -> PlantScreen(
                        state = state,
                        onBack = { vm.screen = Screen.Home },
                        onReminderChange = vm::setReminder,
                        onResetPlant = vm::resetPlant,
                    )

                    Screen.Apps -> AppsScreen(
                        state = state,
                        apps = apps,
                        loaded = appsLoaded,
                        onBack = { vm.screen = Screen.Home },
                        limits = limitsState,
                        emergency = emergencyState,
                        content = contentState,
                        websites = websiteState,
                        bedtime = bedtimeState,
                        permissions = permissions,
                        onBedtimeEnabled = { on -> if (allowEnable(on)) vm.setBedtimeEnabled(on) },
                        onBedtimeTimes = vm::setBedtimeTimes,
                        onBedtimeApps = vm::setBedtimeApps,
                        onWebsiteBlocking = { pkg, on -> if (allowEnable(on)) vm.setWebsiteBlocking(pkg, on) },
                        onAddWebsite = vm::addWebsite,
                        onAddWebsites = vm::addWebsites,
                        keywords = keywordState,
                        keywordActions = KeywordActions(
                            canTighten = ContentPolicy.canSetFeature(state, false, true),
                            canLoosen = ContentPolicy.canSetFeature(state, true, false),
                            onEnabled = vm::setKeywordBlocking,
                            onCheckPages = vm::setKeywordCheckPages,
                            onAdd = vm::addKeywords,
                            onEdit = vm::editKeyword,
                            onRemove = vm::removeKeyword,
                            onRuleEnabled = vm::setKeywordEnabled,
                        ),
                        websiteLimits = websiteLimitState,
                        websiteLimitActions = WebsiteLimitActions(
                            locked = ContentPolicy.frozen(state),
                            // Website limits work through the Accessibility service, like the other blocking features.
                            onAdd = { raw, min ->
                                if (allowEnable(true)) vm.addWebsiteLimit(raw, min) else WebsiteLimitRules.Result.NO_ACCESS
                            },
                            onEdit = vm::editWebsiteLimit,
                            onRemove = vm::removeWebsiteLimit,
                            onEnabled = { domain, on -> if (allowEnable(on)) vm.setWebsiteLimitEnabled(domain, on) },
                            onRefresh = vm::refreshWebsiteLimits,
                        ),
                        onEditWebsite = vm::editWebsite,
                        onRemoveWebsite = vm::removeWebsite,
                        onWebsiteEnabled = vm::setWebsiteEnabled,
                        onToggleApp = vm::setBlocked,
                        onToggleShorts = { on -> if (allowEnable(on)) vm.setBlockShorts(on) },
                        onSaveLimit = vm::saveLimit,
                        onRemoveLimit = vm::removeLimit,
                        onSaveLimitEmergency = vm::saveLimitEmergency,
                        onEmergencyEnabled = { pkg, on -> vm.setEmergencyEnabled(pkg, on) },
                        onEmergencyAttempts = { pkg, n -> vm.setEmergencyLimit(pkg, n) },
                        onFeatureChange = { id, on -> if (allowEnable(on)) vm.setFeature(id, on) },
                        onOpenFeatures = { vm.screen = Screen.Features },
                        onOpenEducation = { vm.screen = Screen.Education },
                    )

                    Screen.Limits -> LimitsScreen(
                        limits = limitsState,
                        apps = apps,
                        appsLoaded = appsLoaded,
                        onBack = { vm.screen = Screen.Home },
                        onSave = vm::saveLimit,
                        onRemove = vm::removeLimit,
                        onSaveCategory = vm::saveCategoryLimit,
                        onRemoveCategory = vm::removeCategoryLimit,
                        onSaveEmergency = vm::saveLimitEmergency,
                        onFloatingChange = vm::setFloatingTimer,
                        onFloatingEveryChange = vm::setFloatingEvery,
                        onFloatingOverGamesChange = vm::setFloatingOverGames,
                        onFloatingStyleChange = vm::setFloatingStyle,
                        locked = !state.canEditApps,
                    )

                    Screen.Emergency -> EmergencyAppsScreen(
                        state = state,
                        emergency = emergencyState,
                        apps = apps,
                        loaded = appsLoaded,
                        onBack = { vm.screen = Screen.Home },
                        onEnabledChange = { pkg, on -> vm.setEmergencyEnabled(pkg, on) },
                        onLimitChange = { pkg, limit -> vm.setEmergencyLimit(pkg, limit) },
                        onResetModeChange = { vm.setEmergencyResetMode(it) },
                        onResetCounts = { vm.resetEmergencyCounts() },
                    )

                    Screen.Features -> FeaturesScreen(
                        state = state,
                        content = contentState,
                        apps = apps,
                        loaded = appsLoaded,
                        onBack = { vm.screen = Screen.Apps },
                        onToggleShorts = { on -> if (allowEnable(on)) vm.setBlockShorts(on) },
                        onFeatureChange = { id, on -> if (allowEnable(on)) vm.setFeature(id, on) },
                        onAddCustom = { pkg, label -> vm.addCustomSection(pkg, label) },
                        onRemoveCustom = { vm.removeCustomSection(it) },
                        onOpenEducation = { vm.screen = Screen.Education },
                    )

                    Screen.Education -> EducationScreen(
                        state = state,
                        content = contentState,
                        onBack = { vm.screen = Screen.Apps },
                        onToggleShorts = { on -> if (allowEnable(on)) vm.setBlockShorts(on) },
                        onAutoDetectChange = { vm.setAutoDetect(it) },
                        onAddChannel = { vm.addChannel(it) },
                        onRemoveChannel = { vm.removeChannel(it) },
                        onClearRecent = vm::clearRecentBlocked,
                    )

                    Screen.Study -> com.focusmode.app.ui.screens.StudyScreen(
                        sessionActive = state.focusActive || pomodoroState.active,
                        lectureBound = lectureStore.urlFlow.collectAsStateWithLifecycle().value != null,
                        onSwitchLecture = switchLecture,
                    )

                    Screen.Settings -> SettingsScreen(
                        permissions = permissions,
                        focusActive = state.focusActive,
                        themeMode = state.themeMode,
                        onBack = { vm.screen = Screen.Home },
                        onThemeChange = vm::setThemeMode,
                        onGrantAccessibility = { grantAccessibility() },
                        onGrantNotifications = { grantNotifications() },
                        onGrantUsage = { grantUsage() },
                        onProtectionActivated = vm::refreshPermissions,
                        onProtectionOff = vm::removeAdmin,
                        advancedProtection = state.advancedProtection,
                        onAdvancedChange = vm::setAdvancedProtection,
                        onGrantBattery = { grantBattery() },
                        restoreAfterRestart = state.restoreAfterRestart,
                        onRestoreChange = vm::setRestoreAfterRestart,
                        onGrantOverlay = { grantOverlay() },
                        focusState = state,
                        onControlChange = { control, allowed -> vm.setControl(control, allowed) },
                        lock = lockState,
                        lockController = vm,
                        online = vm.online,
                        canChangeSettings = vm::canChangeSettings,
                        onOpenApprovals = { vm.screen = Screen.Approvals },
                        onSetPreventChanges = vm::setPreventChanges,
                        onAuthorizeChanges = vm::openChanges,
                        onLockChangesNow = vm::lockChangesNow,
                        onOpenAuth = { authOpen = true },
                        onOpenProfile = {
                            profileReturn = Screen.Settings
                            vm.screen = Screen.Profile
                        },
                        onOffMethodChange = vm::setOffMethod,
                        autoFocus = autoFocus,
                        onAutoFocusChange = autoFocusStore::save,
                        tipsEnabled = tipsState.enabled,
                        onTipsEnabledChange = tipsStore::setEnabled,
                        onTipsReset = tipsStore::reset,
                        onStudyCheckInChange = { minutes ->
                            // The check-in prompt is a notification: without notifications it would never be seen.
                            if (minutes > 0 && !permissions.notifications) {
                                permissionNeeded = RequiredPermission.NOTIFICATIONS
                                false
                            } else vm.setStudyCheckIn(minutes)
                        },
                    )

                    Screen.Profile -> ProfileScreen(
                        onBack = { vm.screen = profileReturn },
                        onOpenAuth = { authOpen = true },
                        onNameChanged = vm::setUserName,
                    )

                    Screen.Approvals -> ApprovalsScreen(
                        manager = vm.online,
                        onBack = { vm.screen = Screen.Settings },
                    )
                }
            }

            // While LockDistra runs and Home is showing: a floating icon that reopens the running
            // Focus screen (same timer, same plant). It never starts a new session.
            androidx.compose.animation.AnimatedVisibility(
                visible = vm.screen == Screen.Home && state.focusActive && !showSplash,
                enter = fadeIn(tween(250)) + scaleIn(tween(250)),
                exit = fadeOut(tween(150)) + scaleOut(tween(150)),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 12.dp, bottom = 12.dp)
            ) {
                FloatingFocusButton(
                    onClick = { showGrowthHint = false; vm.screen = Screen.Session },
                    hint = showGrowthHint,
                )
            }

            // "Watch lecture": while a session runs and a lecture is set, one tap reopens the player (it resumes
            // where the video stopped). Bottom-left on Home (the Focus icon is bottom-right), top-right on the Focus screen.
            val lectureUrl by lectureStore.urlFlow.collectAsStateWithLifecycle()
            val onSessionScreen = vm.screen == Screen.Session
            androidx.compose.animation.AnimatedVisibility(
                visible = (vm.screen == Screen.Home || onSessionScreen) && lectureUrl != null &&
                    (state.focusActive || pomodoroState.active) && !showSplash,
                enter = fadeIn(tween(250)),
                exit = fadeOut(tween(150)),
                modifier = Modifier
                    .align(if (onSessionScreen) Alignment.TopEnd else Alignment.BottomStart)
                    .then(
                        if (onSessionScreen) Modifier.statusBarsPadding().padding(top = 12.dp, end = 16.dp)
                        else Modifier.padding(start = 12.dp, bottom = 12.dp)
                    )
            ) {
                com.focusmode.app.ui.components.WatchLecturePill(onClick = { openLecture() })
            }

            // "Auto" button on Home: opens the Auto Focus schedule (start time, end time, days).
            androidx.compose.animation.AnimatedVisibility(
                visible = vm.screen == Screen.Home && !state.focusActive && !showSplash,
                enter = fadeIn(tween(250)) + scaleIn(tween(250)),
                exit = fadeOut(tween(150)) + scaleOut(tween(150)),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 12.dp, bottom = 12.dp)
            ) {
                AutoFocusChip(
                    on = autoFocus.enabled,
                    onClick = { showAutoFocus = true },
                    modifier = Modifier.tipTarget("auto_chip"),
                )
            }

            // Prevent changes was just switched on: 10 seconds to undo a mistake, shown on every screen.
            if (state.preventChanges && !state.changesLocked && com.focusmode.app.data.ChangeGuard.isGraceOpen() && !showSplash) {
                com.focusmode.app.ui.online.SettingsLockCountdownBar(
                    remainingMs = { com.focusmode.app.data.ChangeGuard.graceRemainingMs() },
                    onLockNow = { vm.lockChangesNow() },
                    modifier = Modifier.align(Alignment.TopCenter),
                )
            }

            // Prevent changes: the screens that edit limits / blocked apps say so and offer the unlock.
            // (Settings has its own "Unlock changes" button in the Prevent changes card.)
            if (state.changesLocked && vm.screen in CHANGE_SCREENS && !showSplash) {
                ChangesLockedBar(
                    onUnlock = { showUnlockChanges = true },
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }

            // "Are you studying?" waits here while the app is open. One tap anywhere answers it.
            if (state.checkInPending && !showSplash) {
                CheckInOverlay(onTap = {
                    if (vm.checkIn()) {
                        Toast.makeText(context, "Nice focus. Your plant grew.", Toast.LENGTH_SHORT).show()
                    }
                })
            }

            // Account screens on demand (only reachable while accounts are optional: Settings > Account / Profile
            // show "Log in" only to a logged-out person, and a logged-out person never reaches Home when accounts
            // are mandatory). Opens on Log in, closes with Back or X.
            if (authOpen && !showSplash) {
                AuthFlow(
                    startScreen = AuthScreen.Login,
                    onFinished = { authOpen = false },
                    onSkip = null,
                    onClose = { authOpen = false },
                )
            }
        }
            androidx.compose.animation.AnimatedVisibility(
                visible = showBar,
                // Fades only: the bar no longer slides up from the bottom when the app opens.
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(150))
            ) {
                FocusBottomBar(selected = vm.screen, onSelect = { vm.screen = it })
            }
        }

        // Focus Profile: opens from the centre and grows outward to fill the screen; closing reverses it.
        AnimatedVisibility(
            visible = focusProfileOpen && !showSplash,
            enter = scaleIn(
                animationSpec = tween(420, easing = FastOutSlowInEasing),
                initialScale = 0.05f,
                transformOrigin = TransformOrigin.Center,
            ) + fadeIn(tween(260)),
            exit = scaleOut(
                animationSpec = tween(320, easing = FastOutSlowInEasing),
                targetScale = 0.05f,
                transformOrigin = TransformOrigin.Center,
            ) + fadeOut(tween(220)),
        ) {
            FocusProfileScreen(
                profiles = focusProfiles,
                onBack = { focusProfileOpen = false },
                onSave = vm::saveFocusProfile,
                onDelete = vm::deleteFocusProfile,
                onSelect = vm::selectFocusProfile,
                settingsScreen = { slot, back ->
                    FocusProfileBlockingScreen(
                        profile = focusProfiles.get(slot),
                        apps = apps,
                        loaded = appsLoaded,
                        vm = vm,
                        onBack = back,
                    )
                },
            )
        }

        // Feature hints: spotlight + tooltip, drawn over everything, only on a quiet screen (no dialog, no session).
        FeatureTipsHost(
            store = tipsStore,
            screen = vm.screen.name,
            enabled = !showSplash && !state.focusActive && !state.checkInPending && !authOpen && !focusProfileOpen &&
                wizardFor == null && !showDuration && !showPermissions && !showEmergency && !showStop &&
                !showLockedStop && !showUnlockChanges && !showProfile && !showAutoFocus &&
                pendingOff == null && permissionNeeded == null,
            onAction = { id ->
                when (id) {
                    "auto_focus" -> showAutoFocus = true
                    "focus_profile" -> focusProfileOpen = true
                    "limits" -> vm.screen = Screen.Limits
                }
            },
        )

        // Smart Feature Suggestions: one clean card on Home for a feature that is not in use yet.
        run {
            val inUse = buildSet {
                if (bedtimeState.enabled) add(SmartSuggest.BEDTIME)
                if (focusProfiles.hasAny) add(SmartSuggest.FOCUS_PROFILE)
                if (websiteState.enabledApps.isNotEmpty()) add(SmartSuggest.WEBSITE_BLOCKING)
                if (autoFocus.enabled) add(SmartSuggest.AUTO_FOCUS)
                if (com.focusmode.app.data.AdultBlockStore.get(context).isActive()) add(SmartSuggest.ADULT_BLOCKING)
                if (limitsState.limits.isNotEmpty()) add(SmartSuggest.LIMITS)
                if (lockState.enabled) add(SmartSuggest.APP_LOCK)
                if (lectureStore.url != null) add(SmartSuggest.LECTURE)
                if (pomodoroState.active) add(SmartSuggest.POMODORO)
            }
            // A feature seen in use counts as used for good, so it is never suggested later even if it is switched off.
            LaunchedEffect(inUse) { inUse.forEach { suggestStore.markUsed(it) } }
            // Never together with the older spotlight hints: not while one is due, and not for a while after one was shown.
            val nowMs = System.currentTimeMillis()
            val tipPending = FeatureTips.pick(tipsState, vm.screen.name, nowMs) != null || nowMs - tipsState.lastShownAt < 120_000L
            SmartSuggestHost(
                store = suggestStore,
                enabled = vm.screen == Screen.Home && !tipPending && !showSplash && !state.focusActive && !state.checkInPending &&
                    !authOpen && !focusProfileOpen && wizardFor == null && !showDuration && !showPermissions && !showEmergency &&
                    !showStop && !showLockedStop && !showUnlockChanges && !showProfile && !showAutoFocus &&
                    pendingOff == null && permissionNeeded == null,
                inUse = inUse,
                onAction = { id ->
                    when (id) {
                        SmartSuggest.LECTURE -> wizardFor = "focus"
                        SmartSuggest.AUTO_FOCUS -> showAutoFocus = true
                        SmartSuggest.FOCUS_PROFILE -> focusProfileOpen = true
                        SmartSuggest.WEBSITE_BLOCKING, SmartSuggest.BEDTIME, SmartSuggest.ADULT_BLOCKING -> vm.screen = Screen.Apps
                        SmartSuggest.LIMITS -> vm.screen = Screen.Limits
                        SmartSuggest.APP_LOCK -> vm.screen = Screen.Settings
                        SmartSuggest.POMODORO -> vm.screen = Screen.Home
                    }
                },
            )
        }
        }

        if (showAutoFocus) {
            AutoFocusDialog(
                schedule = autoFocus,
                onChange = autoFocusStore::save,
                editable = state.canChangeFocusSettings,
                accessibilityOn = permissions.accessibility,
                onGrantAccessibility = { grantAccessibility() },
                onDismiss = { showAutoFocus = false },
            )
        }

        if (showUnlockChanges) {
            UnlockChangesDialog(
                lock = lockState,
                manager = vm.online,
                online = accountState,
                controller = vm,
                changesLocked = state.changesLocked,
                onAuthorized = vm::openChanges,
                onUnlocked = { showUnlockChanges = false },
                onDismiss = { showUnlockChanges = false },
            )
        }

        if (showPermissions) {
            PermissionSheet(
                permissions = permissions,
                onGrantAccessibility = { grantAccessibility() },
                onGrantNotifications = { grantNotifications() },
                onGrantUsage = { grantUsage() },
                onContinue = {
                    showPermissions = false
                    // Coming from "Start Pomodoro": start it now that blocking is allowed.
                    if (pomodoroAfterPermissions) {
                        pomodoroAfterPermissions = false
                        if (permissions.accessibility) wizardFor = "pomodoro"
                    } else {
                        beginSession()
                    }
                },
                onDismiss = { showPermissions = false; sharedForWizard = null }
            )
        }

        permissionNeeded?.let { needed ->
            val accessibilityNeeded = needed == RequiredPermission.ACCESSIBILITY
            AlertDialog(
                onDismissRequest = { permissionNeeded = null },
                containerColor = FocusTheme.colors.card,
                titleContentColor = FocusTheme.colors.text,
                textContentColor = FocusTheme.colors.muted,
                title = { Text("Permission needed", style = MaterialTheme.typography.titleLarge) },
                text = {
                    Text(
                        if (accessibilityNeeded) "This needs LockDistra's Accessibility access, otherwise it would look on but block nothing. Allow it, then turn this on again."
                        else "Study Check-In asks you with a notification, so notifications must be allowed. Allow them, then choose the interval again."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        permissionNeeded = null
                        if (accessibilityNeeded) grantAccessibility() else grantNotifications()
                    }) { Text("Allow", color = FocusTheme.colors.accent) }
                },
                dismissButton = {
                    TextButton(onClick = { permissionNeeded = null }) { Text("Not now", color = FocusTheme.colors.muted) }
                }
            )
        }

        if (showDuration) {
            val nothingBlocked = blockedCount == 0
            DurationSheet(
                initialMinutes = state.lastDurationMin,
                hint = if (nothingBlocked) "No apps are selected yet. Choose them under Blocking." else null,
                timeLimitRequired = !state.allowTurnOff,
                onStart = { minutes ->
                    showDuration = false
                    vm.startFocus(minutes)
                    vm.screen = Screen.Session
                },
                onDismiss = { showDuration = false }
            )
        }

        wizardFor?.let { kind ->
            val isFocus = kind == "focus"
            // What the session will block: the selected Focus Profile, or the phone-wide lists when there is none
            // (the same choice FocusProfileRuntime makes once the session runs).
            val chosenProfile = focusProfiles.selected
            val preview = StartPreviewRules.build(
                blocked = chosenProfile?.settings?.blocked ?: state.blocked,
                isGame = { pkg -> com.focusmode.app.service.GameApps.isGame(context, pkg) },
                label = { pkg -> labels[pkg] },
                sites = StartPreviewRules.siteDomains(chosenProfile?.settings?.websites ?: websiteState),
            )
            StartWizard(
                title = if (isFocus) "Focus Mode" else "Pomodoro",
                hasProfile = focusProfiles.hasAny,
                profileName = chosenProfile?.name,
                preview = preview,
                limits = chosenProfile?.settings?.limits ?: limitsState.limits,
                labelOf = { pkg -> labels[pkg] },
                shortsBlocked = chosenProfile?.settings?.blockShorts ?: state.blockShorts,
                sectionCount = chosenProfile?.settings?.features?.size ?: 0,
                infoLines = if (isFocus) listOf(
                    "You will choose how long to focus next.",
                    "Blocked apps stay closed until the timer ends or you turn Focus Mode off."
                ) else listOf(
                    "${pomodoroState.focusMin} min focus, then ${pomodoroState.breakMin} min break.",
                    "It repeats until you stop it.",
                    "During each break your blocked apps open again."
                ),
                offMethod = state.offMethod,
                offErrorFor = { m ->
                    FocusOffRules.setupError(m, lockState.enabled, accountState.phoneConnected, accountState.hasRecovery, vm.online.configured)
                },
                onSelectOffMethod = { m -> vm.setOffMethod(m) },
                onSelectStudy = { minutes ->
                    // The check-in prompt is a notification: without notifications it would never be seen.
                    if (minutes > 0 && !permissions.notifications) {
                        permissionNeeded = RequiredPermission.NOTIFICATIONS
                        false
                    } else vm.setStudyCheckIn(minutes)
                },
                state = state,
                noEndSession = false,
                startLabel = if (isFocus) "Choose time" else "Start Pomodoro",
                startLabelWhenAutoEnd = if (isFocus) "Start Focus" else null,
                onControlChange = { control, allowed -> vm.setControl(control, allowed) },
                onCreateProfile = { wizardFor = null; sharedForWizard = null; focusProfileOpen = true },
                onFinish = {
                    wizardFor = null
                    sharedForWizard = null
                    if (isFocus) {
                        // "Turn OFF when the lecture ends" is on: the lecture decides when Focus Mode ends, so there is no
                        // duration to pick, also when "Allow turning LockDistra OFF" is switched off. Then the session gets a
                        // 4 h safety timer (so it can never become a trap) that the lecture player shortens to the real
                        // remaining lecture time as soon as it knows it.
                        if (lectureStore.autoEnd) {
                            if (state.allowTurnOff) vm.startFocus(0)
                            else com.focusmode.app.service.FocusController.start(context, 240, lectureTimed = true)
                            vm.screen = Screen.Session
                        } else {
                            showDuration = true
                        }
                    } else {
                        launchPomodoro()
                    }
                },
                onDismiss = { wizardFor = null; sharedForWizard = null },
                onLectureChosen = { url -> lectureStore.set(url); if (url != null) suggestStore.markUsed(SmartSuggest.LECTURE) },
                onAutoEndChosen = { on -> lectureStore.setAutoEnd(on) },
                initialLink = sharedForWizard,
            )
        }

        if (showEmergency) {
            EmergencySheet(
                choices = emergencyChoices,
                onPick = { pkg, minutes ->
                    showEmergency = false
                    vm.startEmergency(pkg, minutes)
                },
                onManage = {
                    showEmergency = false
                    vm.screen = Screen.Emergency
                },
                onDismiss = { showEmergency = false }
            )
        }

        if (showStop) {
            ConfirmStopDialog(
                onConfirm = {
                    showStop = false
                    if (!vm.stopFocus()) showLockedStop = true
                },
                onDismiss = { showStop = false }
            )
        }

        pendingOff?.let { action ->
            val done = {
                pendingOff = null
                if (!action()) showLockedStop = true
            }
            when (offMethodNow) {
                FocusOffMethod.PASSWORD -> FocusOffPasswordDialog(
                    lock = lockState,
                    controller = vm,
                    onApproved = done,
                    onDismiss = { pendingOff = null },
                )
                FocusOffMethod.ONLINE -> FocusOffOnlineDialog(
                    manager = vm.online,
                    online = accountState,
                    onApproved = done,
                    onDismiss = { pendingOff = null },
                )
                FocusOffMethod.NORMAL -> { pendingOff = null }
            }
            Unit
        }

        if (showLockedStop) {
            LockedStopDialog(
                endsInMs = (state.sessionEnd - System.currentTimeMillis()).coerceAtLeast(0L),
                onDismiss = { showLockedStop = false }
            )
        }

        if (showProfile) {
            ProfileDialog(
                currentName = state.userName,
                onSave = {
                    vm.setUserName(it)
                    showProfile = false
                },
                onDismiss = { showProfile = false }
            )
        }
    }
}
