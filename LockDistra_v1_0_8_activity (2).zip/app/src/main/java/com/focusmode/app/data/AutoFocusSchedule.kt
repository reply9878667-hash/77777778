package com.focusmode.app.data

import java.util.Calendar
import java.util.Locale

/** One concrete run of the schedule: Focus turns ON at [startMs] and OFF at [endMs]. */
data class AutoFocusWindow(val startMs: Long, val endMs: Long)

/**
 * "Auto Focus": the person picks a start time, an end time and the days. Focus Mode then turns ON by itself at the start
 * time and OFF at the end time.
 *
 * - [days] is a bit mask, Monday = bit 0 ... Sunday = bit 6. A window belongs to the day it STARTS on.
 * - An end time earlier than the start time means the window runs past midnight (22:00 -> 06:00).
 * - Start == end is not allowed (it would be unclear whether that means 0 or 24 hours).
 *
 * Pure logic, no Android classes, so it can be unit tested on the JVM.
 */
data class AutoFocusSchedule(
    val enabled: Boolean = false,
    val startMin: Int = 9 * 60,
    val endMin: Int = 17 * 60,
    val days: Int = WEEKDAYS,
) {
    val isValid: Boolean get() = startMin != endMin && days != 0 &&
        startMin in 0 until MINUTES_PER_DAY && endMin in 0 until MINUTES_PER_DAY

    /** True when the window runs past midnight into the next day. */
    val endsNextDay: Boolean get() = endMin < startMin

    fun hasDay(index: Int): Boolean = days and (1 shl index) != 0

    fun toggleDay(index: Int): AutoFocusSchedule = copy(days = days xor (1 shl index))

    /** The window that is running at [now], or null. Checks today's window and yesterday's overnight one. */
    fun currentWindow(now: Long): AutoFocusWindow? {
        if (!enabled || !isValid) return null
        for (offset in intArrayOf(0, -1)) {
            val w = windowStartingOn(now, offset) ?: continue
            if (now >= w.startMs && now < w.endMs) return w
        }
        return null
    }

    /** The first window that starts after [now] (looks a week ahead), or null when nothing is scheduled. */
    fun nextWindow(now: Long): AutoFocusWindow? {
        if (!enabled || !isValid) return null
        for (offset in 0..7) {
            val w = windowStartingOn(now, offset) ?: continue
            if (w.startMs > now) return w
        }
        return null
    }

    /** Window that starts on the day [dayOffset] days from the day of [reference], if that weekday is selected. */
    private fun windowStartingOn(reference: Long, dayOffset: Int): AutoFocusWindow? {
        val day = Calendar.getInstance().apply {
            timeInMillis = reference
            add(Calendar.DAY_OF_YEAR, dayOffset)
        }
        // Calendar: Sunday = 1 ... Saturday = 7  ->  Monday = 0 ... Sunday = 6
        val index = (day.get(Calendar.DAY_OF_WEEK) + 5) % 7
        if (!hasDay(index)) return null
        val start = atMinute(day, startMin, 0)
        val end = atMinute(day, endMin, if (endsNextDay) 1 else 0)
        return AutoFocusWindow(start, end)
    }

    private fun atMinute(day: Calendar, minuteOfDay: Int, plusDays: Int): Long {
        val c = day.clone() as Calendar
        c.add(Calendar.DAY_OF_YEAR, plusDays)
        c.set(Calendar.HOUR_OF_DAY, minuteOfDay / 60)
        c.set(Calendar.MINUTE, minuteOfDay % 60)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    companion object {
        const val MINUTES_PER_DAY = 24 * 60
        const val WEEKDAYS = 0b0011111
        const val WEEKEND = 0b1100000
        const val EVERY_DAY = 0b1111111
        val DAY_NAMES = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
    }
}

object AutoFocusFormat {
    /** Minutes left of [window] at [now], rounded up, never below 1 (what `startFocus(minutes)` needs). */
    fun remainingMinutes(window: AutoFocusWindow, now: Long): Int =
        (((window.endMs - now) + 59_999L) / 60_000L).toInt().coerceAtLeast(1)

    fun time(minuteOfDay: Int, is24Hour: Boolean): String {
        val h = minuteOfDay / 60
        val m = minuteOfDay % 60
        if (is24Hour) return String.format(Locale.US, "%02d:%02d", h, m)
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format(Locale.US, "%d:%02d %s", h12, m, if (h < 12) "AM" else "PM")
    }

    fun timeOf(ms: Long, is24Hour: Boolean): String {
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        return time(c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE), is24Hour)
    }

    fun days(days: Int): String = when (days) {
        AutoFocusSchedule.EVERY_DAY -> "Every day"
        AutoFocusSchedule.WEEKDAYS -> "Mon–Fri"
        AutoFocusSchedule.WEEKEND -> "Sat–Sun"
        else -> AutoFocusSchedule.DAY_NAMES.filterIndexed { i, _ -> days and (1 shl i) != 0 }.joinToString(", ")
    }

    /** "Today", "Tomorrow" or the weekday name for [ms], seen from [now]. */
    fun dayLabel(ms: Long, now: Long): String {
        val a = Calendar.getInstance().apply { timeInMillis = now }
        val b = Calendar.getInstance().apply { timeInMillis = ms }
        fun key(c: Calendar) = c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
        a.add(Calendar.DAY_OF_YEAR, 1)
        val tomorrow = key(a)
        a.add(Calendar.DAY_OF_YEAR, -1)
        return when (key(b)) {
            key(a) -> "Today"
            tomorrow -> "Tomorrow"
            else -> AutoFocusSchedule.DAY_NAMES[(b.get(Calendar.DAY_OF_WEEK) + 5) % 7]
        }
    }
}
