package com.focusmode.app.data.auth

import android.content.Context
import com.focusmode.app.data.online.FirebaseGateway
import kotlinx.coroutines.CancellationException

/**
 * Tells the admin panel "this person still uses ReWire", at most ONCE A DAY and only when the app is opened.
 * Event driven: no timer, no background work, nothing is downloaded except one tiny number (the day we last
 * reported). The panel never reads a user list; it reads a few counters, so the cost stays flat as users grow.
 * If the phone is offline the day is not marked as done, so the next app start tries again.
 */
object ActivityPing {
    private const val PREFS = "rewire_activity_ping"
    private const val KEY = "last"
    const val DAY_MS = 86_400_000L

    /** Whole days since 1970 (UTC). One bucket per day in the database. */
    fun dayOf(ms: Long): Long = Math.floorDiv(ms, DAY_MS)

    /** "d20401": five digits for the next ~270 years, so keys sort by date. */
    fun dayKey(day: Long): String = "d$day"

    /** Reports today's open for [uid] unless it was already reported today. Never throws. */
    suspend fun flush(context: Context, uid: String) {
        try {
            val app = context.applicationContext
            val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val day = dayOf(FirebaseGateway.serverNow())
            val mark = "$uid|$day"
            if (prefs.getString(KEY, null) == mark) return
            if (FirebaseGateway.reportSeen(app, uid, day)) prefs.edit().putString(KEY, mark).apply()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // Not important enough to bother the person; the next start tries again.
        }
    }
}
