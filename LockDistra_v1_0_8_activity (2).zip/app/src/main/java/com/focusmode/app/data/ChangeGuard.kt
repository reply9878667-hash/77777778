package com.focusmode.app.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/**
 * The editing window of "Prevent changes". It opens only after the person proved who they are
 * (app PIN / password, recovery code, or an approval from the trusted phone) and closes by
 * itself after [ChangeWindowRules.WINDOW_MS]. It lives in memory on purpose: closing the app,
 * Android killing the process or a restart always brings the lock back.
 *
 * FocusStore reads [isOpen] every time it builds its state, so the stores and screens all see the
 * same answer. The rules (times) are in [ChangeWindowRules] and unit tested without Android.
 */
object ChangeGuard {

    @Volatile private var openedAt = 0L
    @Volatile private var graceAt = 0L
    private var expiry: Runnable? = null
    private var graceExpiry: Runnable? = null

    fun isOpen(): Boolean = ChangeWindowRules.isOpen(openedAt, SystemClock.elapsedRealtime())

    /** The short "undo" window that starts when Prevent changes is switched on ([ChangeWindowRules.GRACE_MS]). */
    fun isGraceOpen(): Boolean = ChangeWindowRules.isGraceOpen(graceAt, SystemClock.elapsedRealtime())

    fun graceRemainingMs(): Long = ChangeWindowRules.graceRemainingMs(graceAt, SystemClock.elapsedRealtime())

    @Synchronized
    fun startGrace(context: Context) {
        val app = context.applicationContext
        graceAt = SystemClock.elapsedRealtime()
        cancelGraceExpiry()
        val r = Runnable { FocusStore.get(app).refresh() }
        graceExpiry = r
        Handler(Looper.getMainLooper()).postDelayed(r, ChangeWindowRules.GRACE_MS + 250L)
        FocusStore.get(app).refresh()
    }

    fun remainingMs(): Long = ChangeWindowRules.remainingMs(openedAt, SystemClock.elapsedRealtime())

    @Synchronized
    fun open(context: Context) {
        val app = context.applicationContext
        openedAt = SystemClock.elapsedRealtime()
        FocusStore.get(app).refresh()
        scheduleExpiry(app)
    }

    @Synchronized
    fun close(context: Context) {
        val app = context.applicationContext
        openedAt = 0L
        graceAt = 0L
        cancelExpiry()
        cancelGraceExpiry()
        FocusStore.get(app).refresh()
    }

    private fun scheduleExpiry(app: Context) {
        cancelExpiry()
        // Enforcement never depends on this timer (every check compares the clock); it only
        // makes the screens notice that the window has ended.
        val r = Runnable { FocusStore.get(app).refresh() }
        expiry = r
        Handler(Looper.getMainLooper()).postDelayed(r, ChangeWindowRules.WINDOW_MS + 250L)
    }

    private fun cancelGraceExpiry() {
        graceExpiry?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        graceExpiry = null
    }

    private fun cancelExpiry() {
        expiry?.let { Handler(Looper.getMainLooper()).removeCallbacks(it) }
        expiry = null
    }
}
