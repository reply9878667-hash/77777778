package com.focusmode.app.data

/*
 * Anti-bypass rules that need no Android classes (unit tested in GuardRulesTest.kt).
 *
 * 1. Which phone-maker (OEM) system packages count as "guarded" screens (battery / power / permission / security pages),
 *    so a Vivo / iQOO / Xiaomi / OPPO ... page is guarded without having to list every package name by hand.
 * 2. The extra texts that mark LockDistra's OWN battery / background / overlay page.
 * 3. Which activity classes the "Accessibility lost" fallback guard closes while the accessibility service is not running.
 */
object GuardRules {

    /** A system package whose name contains one of these may be a battery / permission / security page. */
    private val OEM_KEYWORDS = listOf(
        "settings", "secur", "power", "batter", "abe", "perm", "install", "appdetail", "care", "optimi",
        "manager", "safe", "guard", "vivo", "iqoo", "bbk", "miui", "xiaomi", "oplus", "coloros", "oppo",
        "heytap", "samsung", "huawei", "hihonor", "realme", "oneplus", "transsion", "lool",
    )

    /** ...but never these (launchers, keyboards, system UI, browsers, media, phone). */
    private val NEVER_GUARD = listOf(
        "launcher", "systemui", "inputmethod", "keyboard", "browser", "camera", "gallery", "dialer",
        "contacts", "mms", "messag", "telecom", "calendar", "music", "video", "chrome", "youtube", "maps",
        "wallpaper", "clock",
    )

    fun looksLikeOemGuardPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        if (NEVER_GUARD.any { p.contains(it) }) return false
        return OEM_KEYWORDS.any { p.contains(it) }
    }

    /**
     * Texts of LockDistra's battery / background / overlay / auto-start pages (English UI, case-insensitive substring).
     * They are only used when "LockDistra" is also shown near the TOP of the same screen (the app header of a detail
     * page), so a long list of apps that merely contains LockDistra is not closed.
     */
    val BROAD_ACTIONS = listOf(
        "background power",
        "power consumption",
        "power usage",
        "background activity",
        "background usage",
        "background running",
        "run in background",
        "allow background",
        "restrict background",
        "battery optimi",
        "battery usage",
        "battery saver",
        "high background",
        "autostart",
        "auto-start",
        "auto start",
        "auto-launch",
        "display over other apps",
        "appear on top",
        "draw over",
        "show over other",
        "over other apps",
        "screen overlay",
        "sleeping apps",
        "deep sleep",
    )

    /** Share of the screen height (from the top) in which the app header of a detail page lives. */
    const val HEADER_ZONE_PERCENT = 35

    fun isInHeaderZone(top: Int, screenHeight: Int): Boolean =
        top >= 0 && screenHeight > 0 && top < screenHeight * HEADER_ZONE_PERCENT / 100

    /** Activity class names that uninstall, deactivate the admin or open an app's info page. */
    private val DANGEROUS_CLASSES = listOf(
        "uninstalleractivity",
        "uninstallappprogress",
        "deviceadminadd",
        "deviceadminsettings",
        "deviceadminlist",
        "installedappdetails",
        "appinfodashboard",
        "appdetailsactivity",
        "appdetail",
        "uninstall",
    )

    private val DANGEROUS_PACKAGE_PARTS = listOf("packageinstaller", "appdetail", "permissioncontroller")

    /** Used only while the accessibility service is NOT running (it cannot read the page then, only the class name). */
    fun isDangerousWhileBlind(pkg: String, className: String?): Boolean {
        val c = className?.lowercase().orEmpty()
        if (c.isNotEmpty() && DANGEROUS_CLASSES.any { c.contains(it) }) return true
        val p = pkg.lowercase()
        return DANGEROUS_PACKAGE_PARTS.any { p.contains(it) } && c.contains("overlay")
    }
}
