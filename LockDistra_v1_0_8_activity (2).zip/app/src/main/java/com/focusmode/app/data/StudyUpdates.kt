package com.focusmode.app.data

/** What a subscribed channel may notify about: every new video, only the ones matching the person's subjects, or nothing. */
enum class ChannelAlerts(val key: String) {
    ALL("all"), PERSONALIZED("personalized"), NONE("none");

    companion object {
        /** Anything unknown (or never chosen) is [ALL]: that is how followed channels always behaved. */
        fun fromKey(key: String?): ChannelAlerts = values().firstOrNull { it.key == key } ?: ALL
    }
}

/** Rules for "new video" notifications. No Android classes, so it is unit tested on the JVM. */
object StudyUpdates {
    const val MAX_SEEN = 400
    /** Most notifications one check may post (the rest are still marked seen, so nothing floods the phone). */
    const val MAX_NOTIFY = 4
    /** Channels looked at per check: 1 unit each of the free daily YouTube limit. */
    const val MAX_CHANNELS = 12
    const val CHECK_HOURS = 3L
    /** A channel followed before this update has no recorded follow time: its uploads of the last day count as new. */
    const val UNKNOWN_FOLLOW_WINDOW_MS = 24L * 60 * 60 * 1000

    /**
     * Where "new" starts for a channel looked at for the first time: the moment it was followed (so a video uploaded
     * after the Subscribe tap is never swallowed by the first check), or one day back when that moment is not known.
     */
    fun firstLookCutoff(followedAt: Long, now: Long): Long = if (followedAt > 0L) followedAt else now - UNKNOWN_FOLLOW_WINDOW_MS

    /** True when [video] was uploaded at or after [cutoff]; a video with no known upload time is never counted as new. */
    fun isNewSince(video: StudyVideo, cutoff: Long): Boolean = video.publishedAt > 0L && video.publishedAt >= cutoff

    /** Ids from [latest] that were not seen before, in the same order. */
    fun unseen(latest: List<String>, seen: Set<String>): List<String> = latest.filter { it !in seen }

    /** Keeps the newest [max] ids (the list is oldest first). */
    fun trimSeen(seen: List<String>, max: Int = MAX_SEEN): List<String> = seen.distinct().takeLast(max)

    /** Newest uploads come first from YouTube; the oldest of the new ones is announced first, so the phone ends on the newest. */
    fun notifyOrder(fresh: List<StudyVideo>): List<StudyVideo> = fresh.take(MAX_NOTIFY).reversed()

    /**
     * Whether a new [video] of a channel set to [mode] is announced. Personalized = its title mentions one of the
     * [subjects] the person studies (whole words, any case); a video that matches none stays quiet.
     */
    fun wants(mode: ChannelAlerts, video: StudyVideo, subjects: List<String>): Boolean = when (mode) {
        ChannelAlerts.ALL -> true
        ChannelAlerts.NONE -> false
        ChannelAlerts.PERSONALIZED -> {
            val title = words(video.title)
            subjects.map { words(it).trim() }.filter { it.isNotEmpty() }.any { title.contains(" $it ") }
        }
    }

    private fun words(text: String): String =
        " " + text.lowercase().map { if (it.isLetterOrDigit() || it == '+') it else ' ' }.joinToString("").replace(Regex("\\s+"), " ").trim() + " "
}
