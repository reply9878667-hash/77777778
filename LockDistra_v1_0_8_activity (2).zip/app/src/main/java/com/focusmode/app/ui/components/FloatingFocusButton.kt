package com.focusmode.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Eco
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.focusmode.app.ui.theme.FocusTheme

/**
 * Round Focus icon shown on the home screen while a session is running. Tapping it reopens the
 * running Focus screen (same timer, same plant); it never starts a new session.
 * [hint] draws a brighter, stronger pulsing ring around it (used once, right after leaving the plant screen).
 */
@Composable
fun FloatingFocusButton(onClick: () -> Unit, modifier: Modifier = Modifier, hint: Boolean = false) {
    val c = FocusTheme.colors
    val transition = rememberInfiniteTransition(label = "floatingFocus")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "floatingPulse"
    )
    Box(modifier.size(76.dp), contentAlignment = Alignment.Center) {
        if (hint) {
            Box(
                Modifier
                    .size(72.dp)
                    .scale(pulse)
                    .clip(CircleShape)
                    .border(2.dp, c.accent, CircleShape)
            )
        }
        Box(
            Modifier
                .size(60.dp)
                .scale(pulse)
                .clip(CircleShape)
                .background(c.glow.copy(alpha = if (hint) 0.45f else 0.22f))
        )
        Box(
            Modifier
                .size(56.dp)
                .shadow(14.dp, CircleShape, ambientColor = c.glow, spotColor = c.glow)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(c.gradStart, c.gradMid)))
                .border(1.2.dp, Color.White.copy(alpha = 0.55f), CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    role = Role.Button,
                    onClickLabel = "Open LockDistra",
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Eco, contentDescription = "Open running Focus session", tint = Color.White, modifier = Modifier.size(28.dp))
        }
    }
}
