package com.focusmode.app.service

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focusmode.app.MainActivity
import com.focusmode.app.R
import com.focusmode.app.data.IntentGuard
import com.focusmode.app.data.StudyCheckInRules
import com.focusmode.app.data.online.AppUnlockRules
import com.focusmode.app.data.online.ApprovalProtocol
import com.focusmode.app.data.online.OnlineManager
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/**
 * Receives the push that tells the trusted phone "an unlock request is waiting".
 * The push carries no secret and decides nothing: the notification only opens the Unlock requests
 * screen, which reads the request from the database and checks its MAC before showing Approve.
 */
class ApproverMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        OnlineManager.get(this).onNewToken(token)
    }

    override fun onMessageReceived(message: RemoteMessage) {
        // A message the admin sent to every phone (shown to everyone; it opens the app, nothing else).
        if (message.data["type"] == "admin_message") {
            AdminMessageNotifications.show(this, message.data["title"].orEmpty(), message.data["body"].orEmpty())
            return
        }
        // Study Check-In missed: only a phone that really is a trusted phone shows it. It is an alert to look
        // into, with fixed wording written here; nothing from the push is shown or trusted beyond its id.
        if (message.data["type"] == "checkin_missed") {
            if (!OnlineManager.get(this).state.value.isApprover) return
            StudyCheckInAlertNotifications.show(this, message.data["requestId"].orEmpty())
            return
        }
        if (message.data["type"] != "unlock_request") return
        // Only a phone that really is a trusted phone shows anything.
        if (!OnlineManager.get(this).state.value.isApprover) return
        // "More time in one app" pushes name the app. The name is only shown (the screen the
        // notification opens re-reads the request and checks it), so it is cut short and cleaned.
        val appName = if (message.data["kind"] == ApprovalProtocol.KIND_APP) {
            AppUnlockRules.cleanName(message.data["appName"].orEmpty(), "an app")
        } else null
        ApprovalNotifications.show(this, appName)
        // Trigger: listen live for this one request only (about two minutes), then go idle again.
        OnlineManager.get(this).onPushSignal()
    }
}

/**
 * A message from the admin panel to all phones. Plain text only; it just opens the app.
 * The channel is HIGH importance (v2: an existing channel's importance can never be raised, so a new id), which is what
 * makes Android slide it down over the home screen with sound and vibration like any other messaging app. The same
 * channel id is named in the push itself (Worker) so the system can show it with the app closed.
 */
object AdminMessageNotifications {
    const val CHANNEL = "admin_messages_v2"
    private const val OLD_CHANNEL = "admin_messages_v1"
    private val control = Regex("[\\u0000-\\u001f\\u007f]")
    private val VIBRATION = longArrayOf(0, 300, 150, 300)

    private fun clean(s: String, max: Int) = s.replace(control, " ").trim().take(max)

    /** Safe to call at every start. Creates the loud channel before any push can need it. */
    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        runCatching { nm.deleteNotificationChannel(OLD_CHANNEL) }
        // An older install still has the old channel name: it is updated (createNotificationChannel only renames, the person's sound / importance choices stay).
        if (nm.getNotificationChannel(CHANNEL)?.name?.toString() == "Messages from LockDistra") return
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Messages from LockDistra", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "News and announcements from the LockDistra team."
                enableVibration(true)
                vibrationPattern = VIBRATION
                enableLights(true)
                setShowBadge(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setSound(
                    android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun show(context: Context, title: String, body: String) {
        val text = clean(body, 300)
        if (text.isEmpty()) return
        ensureChannel(context)
        val open = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(context))
        }
        val id = (System.currentTimeMillis() and 0x7fffffffL).toInt()
        val pending = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(clean(title, 60).ifEmpty { "LockDistra" })
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setSubText("LockDistra")
            // Older Android (before 8) has no channels: priority + defaults give the same heads-up, sound and buzz.
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(id, n)
        } catch (_: SecurityException) {
            // Notification permission not granted on this phone: nothing to show.
        }
    }
}

object ApprovalNotifications {
    private const val CHANNEL = "unlock_requests_v1"
    private const val ID = 1010

    private fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "LockDistra unlock requests", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Asks you to approve or reject an unlock request from your other phone."
                setShowBadge(true)
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
        )
    }

    /**
     * True when an unlock-request notification would really be shown: notifications are allowed for
     * the app (Android 13+ asks at runtime) and the "Unlock requests" channel was not switched off.
     */
    fun canShow(context: Context): Boolean {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false
        ensureChannel(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = nm.getNotificationChannel(CHANNEL) ?: return true
        return ch.importance != NotificationManager.IMPORTANCE_NONE
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(ID)
    }

    @SuppressLint("MissingPermission")
    fun show(context: Context, appName: String? = null, fromName: String? = null) {
        ensureChannel(context)
        val open = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(context))
            putExtra(MainActivity.EXTRA_OPEN_APPROVALS, true)
        }
        val pending = PendingIntent.getActivity(
            context, ID, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // The sender is the person's own name (from their login) when the request carries one.
        val who = fromName?.let { AppUnlockRules.cleanName(it, "") }?.takeIf { it.isNotEmpty() }
        val text = when {
            appName != null && who != null -> "$who wants more time in $appName. Tap to choose how long."
            appName != null -> "Your other phone wants more time in $appName. Tap to choose how long."
            who != null -> "$who wants to unlock LockDistra. Tap to approve or reject."
            else -> "Your other phone wants to unlock LockDistra. Tap to approve or reject."
        }
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(if (appName != null) "More time requested" else "Unlock request")
            .setContentText(text)
            .setSubText("LockDistra")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setOnlyAlertOnce(false)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setTimeoutAfter(120_000L)
            .setContentIntent(pending)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(ID, n)
        } catch (_: SecurityException) {
            // Notification permission not granted: the request is still visible inside the app.
        }
    }
}

/** The "Study Check-In Missed" alert on the trusted phone. Separate channel so it can be tuned on its own. */
object StudyCheckInAlertNotifications {
    private const val CHANNEL = "study_checkin_alert_v1"
    private const val ID = 1011

    private fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Study check-in alerts", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Tells you when the person you look after did not answer a study check-in."
                setShowBadge(true)
                enableVibration(true)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
        )
    }

    @SuppressLint("MissingPermission")
    fun show(context: Context, requestId: String) {
        ensureChannel(context)
        val open = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(context))
        }
        val pending = PendingIntent.getActivity(
            context, ID, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // One notification per missed check-in: a push delivered twice replaces itself instead of piling up.
        val tag = requestId.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(40).ifEmpty { "checkin" }
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(StudyCheckInRules.ALERT_TITLE)
            .setContentText(StudyCheckInRules.ALERT_TEXT)
            .setStyle(NotificationCompat.BigTextStyle().bigText(StudyCheckInRules.ALERT_TEXT))
            .setSubText("LockDistra")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(pending)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(tag, ID, n)
        } catch (_: SecurityException) {
            // Notification permission not granted on this phone: nothing to show.
        }
    }
}
