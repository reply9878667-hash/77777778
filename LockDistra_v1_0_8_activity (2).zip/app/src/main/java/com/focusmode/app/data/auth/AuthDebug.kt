package com.focusmode.app.data.auth

/**
 * A short trail of the steps of the last Google sign-in ("sheet opened > account chosen > Firebase ..."). Debug builds
 * show it in the error box, so a sign-in that "does nothing" says exactly where it stopped. Holds no tokens or secrets.
 */
object AuthDebug {
    private val steps = ArrayList<String>()

    @Synchronized
    fun reset() {
        steps.clear()
    }

    @Synchronized
    fun note(step: String) {
        if (steps.size < 12) steps.add(step.take(220))
    }

    @Synchronized
    fun trail(): String = steps.joinToString("\n")
}
