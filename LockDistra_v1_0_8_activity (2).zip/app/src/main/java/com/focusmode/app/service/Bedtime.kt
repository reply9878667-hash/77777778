package com.focusmode.app.service

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focusmode.app.MainActivity
import com.focusmode.app.R
import com.focusmode.app.data.BedtimeRules
import com.focusmode.app.data.BedtimeStore
import com.focusmode.app.data.IntentGuard
import com.focusmode.app.data.Storage

/**
 * Bedtime Mode scheduling and notifications.
 *
 * Blocking itself does not depend on any alarm: [AppBlockerService] asks [BedtimeStore] "is this app
 * blocked right now?" from the phone's clock, so the right answer survives restarts, time changes
 * and a killed process. The one alarm below only exists to announce the start and the end, and it is
 * always re-armed for the next boundary. One fixed PendingIntent (same request code) means arming it
 * again replaces it, so there are never duplicate jobs.
 */
object BedtimeEngine {

    private const val REQ_BOUNDARY = 31
    const val CH_BEDTIME = "bedtime_v1"
    const val ID_BEDTIME = 1006
    private const val PREFS = "bedtime_runtime"
    private const val K_ANNOUNCED = "announced_on"

    /** Alarms never fire before the minute changes, so aim a moment after the boundary. */
    private const val CUSHION_MS = 1_500L

    /**
     * Brings notifications and the alarm in line with the saved schedule. Safe to call at any time
     * and as often as needed: after a settings change, an alarm, a restart, a time or time-zone change,
     * an app update or an app start.
     */
    @Synchronized
    fun sync(context: Context) {
        val app = context.applicationContext
        val store = BedtimeStore.get(app)
        val s = store.current()
        val active = store.isActive()
        val prefs = Storage.prefs(app, PREFS)
        val announced = prefs.getBoolean(K_ANNOUNCED, false)
        if (active != announced) {
            prefs.edit().putBoolean(K_ANNOUNCED, active).commit()
            // Only announce a change the person can act on: switching it off while it was never
            // announced as on (and the reverse) stays quiet.
            post(app, active)
        }
        if (!s.armed) {
            cancel(app)
            return
        }
        val now = System.currentTimeMillis()
        val wait = BedtimeRules.msToNextBoundary(s, BedtimeStore.minuteOfDay(now), BedtimeStore.msIntoMinute(now))
        arm(app, now + wait + CUSHION_MS)
    }

    @Synchronized
    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(boundaryIntent(context))
    }

    private fun arm(context: Context, at: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = boundaryIntent(context)
        try {
            // Exact when the person allows "Alarms & reminders"; otherwise Android may delay it a few
            // minutes in deep sleep. Blocking itself is unaffected (it follows the clock).
            if (FocusEngine.canScheduleExact(context)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun boundaryIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context, REQ_BOUNDARY,
            Intent(context, BedtimeReceiver::class.java).setAction(BedtimeReceiver.ACTION_BOUNDARY),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun ensureChannel(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_BEDTIME, "Bedtime Mode", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Tells you when Bedtime Mode starts and ends."
                setShowBadge(false)
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun post(context: Context, on: Boolean) {
        val nmc = NotificationManagerCompat.from(context)
        // Without notification permission the schedule still works; there is just nothing to show.
        if (!nmc.areNotificationsEnabled()) return
        ensureChannel(context)
        val text = if (on) BedtimeRules.startedText() else BedtimeRules.endedText()
        val open = PendingIntent.getActivity(
            context, 303,
            Intent(context, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(IntentGuard.EXTRA_KEY, IntentGuard.key(context)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CH_BEDTIME)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(if (on) BedtimeRules.startedTitle() else BedtimeRules.endedTitle())
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(open)
            .build()
        // One id: the "OFF" message replaces the "ON" one instead of piling up.
        nmc.notify(ID_BEDTIME, n)
    }
}

/**
 * Wakes Bedtime Mode up: at its own start / end alarm, after a restart or app update, and when the
 * phone's time or time zone changes. Not exported, except for the system broadcasts it lists.
 */
class BedtimeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_BOUNDARY,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> BedtimeEngine.sync(context)

            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_BOOT_COMPLETED -> {
                BedtimeEngine.sync(context)
                // The restart can switch Accessibility off; without it nothing can be blocked.
                if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
                    BedtimeStore.get(context).current().armed &&
                    !Permissions.isAccessibilityEnabled(context)
                ) Notifications.postNeedsAccessibility(context)
            }
        }
    }

    companion object {
        const val ACTION_BOUNDARY = "com.focusmode.app.action.BEDTIME_BOUNDARY"
    }
}
