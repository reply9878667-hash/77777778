package com.focusmode.app.data

/*
 * Rules and matching for "Educational Shorts" and "Inside apps" restrictions. Everything here is
 * free of Android classes so it can be unit tested on a plain JVM (see app/src/test). The
 * accessibility service only turns the screen into [NodeSnap]s and acts on the answers.
 */

// ---- Data -------------------------------------------------------------------------------------

/** A flattened, read-only copy of one on-screen accessibility node. */
data class NodeSnap(
    val id: String = "",
    val text: String = "",
    val desc: String = "",
    val cls: String = "",
    val selected: Boolean = false,
    val visible: Boolean = true,
)

/** A YouTube channel the user marked as educational. [key] is what the screen is matched against. */
data class EduChannel(val key: String, val display: String)

/** A tab or section of any app the user chose to block by its on-screen label. */
data class CustomSection(val pkg: String, val label: String) {
    val id: String get() = "custom:$pkg:${EducationMatcher.norm(label)}"
}

/**
 * How to recognise a section on screen. All lists are alternatives; one hit is enough.
 *  - [viewIds]: a visible node with this resource id.
 *  - [selectedIds]: a visible, selected node with this resource id (a highlighted tab).
 *  - [selectedLabels]: a visible, selected node whose text or description starts with the label.
 *  - [editHints]: a visible text field whose hint or text contains this text.
 */
data class Selector(
    val viewIds: List<String> = emptyList(),
    val selectedIds: List<String> = emptyList(),
    val selectedLabels: List<String> = emptyList(),
    val editHints: List<String> = emptyList(),
    /** Part of the foreground window's class name (for example a full-screen status viewer). */
    val windowClasses: List<String> = emptyList(),
)

/**
 * One blockable section of one app. [redirectLabels] are tabs the service may tap to leave the
 * section gracefully before falling back to Back and finally the block screen.
 */
data class FeatureDef(
    val id: String,
    val pkg: String,
    val title: String,
    val note: String,
    val selector: Selector,
    val redirectLabels: List<String> = emptyList(),
)

data class ContentState(
    val channels: List<EduChannel> = emptyList(),
    val autoDetect: Boolean = false,
    /** Channels whose Shorts were blocked recently, newest first (shown so they can be allowed). */
    val recentBlocked: List<String> = emptyList(),
    val enabledFeatures: Set<String> = emptySet(),
    val customSections: List<CustomSection> = emptyList(),
) {
    fun featureOn(id: String) = id in enabledFeatures

    /** True when Shorts from some channels may play (a list, or automatic detection). */
    val hasShortsExceptions: Boolean get() = channels.isNotEmpty() || autoDetect

    /** Every section currently being blocked inside [pkg], presets first, then the user's own. */
    fun activeDefs(pkg: String): List<FeatureDef> {
        val presets = FeatureCatalog.forPackage(pkg).filter { it.id in enabledFeatures }
        val custom = customSections.filter { it.pkg == pkg }.map { FeatureCatalog.customDef(it) }
        return presets + custom
    }

    fun watches(pkg: String): Boolean =
        FeatureCatalog.forPackage(pkg).any { it.id in enabledFeatures } || customSections.any { it.pkg == pkg }

    val activeFeatureCount: Int
        get() = enabledFeatures.count { FeatureCatalog.byId(it) != null } + customSections.size
}

// ---- Catalog of known sections ----------------------------------------------------------------

/**
 * Sections that can be switched on by name. Android has no API for "block Reels"; these are
 * best-effort screen signatures (resource ids and tab labels) that apps are free to change in any
 * update. The user's own sections ([CustomSection]) cover anything not listed here.
 */
object FeatureCatalog {

    const val YOUTUBE = "com.google.android.youtube"
    const val INSTAGRAM = "com.instagram.android"
    const val FACEBOOK = "com.facebook.katana"
    const val SNAPCHAT = "com.snapchat.android"
    const val WHATSAPP = "com.whatsapp"
    const val WHATSAPP_BIZ = "com.whatsapp.w4b"

    const val YT_SEARCH = "yt_search"
    const val YT_HOME = "yt_home"
    const val IG_REELS = "ig_reels"
    const val IG_EXPLORE = "ig_explore"
    const val IG_SEARCH = "ig_search"
    const val FB_REELS = "fb_reels"
    const val FB_VIDEO = "fb_video"
    const val FB_MARKETPLACE = "fb_marketplace"
    const val SC_SPOTLIGHT = "sc_spotlight"
    const val SC_DISCOVER = "sc_discover"
    const val WA_STATUS = "wa_status"
    const val WA_BIZ_STATUS = "wa_biz_status"

    /** Apps with presets, in display order. YouTube Shorts has its own switch (FocusState.blockShorts). */
    val appPackages = listOf(YOUTUBE, INSTAGRAM, FACEBOOK, SNAPCHAT, WHATSAPP, WHATSAPP_BIZ)

    /** Apps shown even when they are not installed. None: only installed apps get switches. */
    val alwaysShown: Set<String> = emptySet()

    fun appTitle(pkg: String): String = when (pkg) {
        YOUTUBE -> "YouTube"
        INSTAGRAM -> "Instagram"
        FACEBOOK -> "Facebook"
        SNAPCHAT -> "Snapchat"
        WHATSAPP -> "WhatsApp"
        WHATSAPP_BIZ -> "WhatsApp Business"
        else -> pkg
    }

    val all: List<FeatureDef> = listOf(
        FeatureDef(
            YT_SEARCH, YOUTUBE, "Search",
            "Search box and search results",
            Selector(
                viewIds = listOf(
                    "com.google.android.youtube:id/search_edit_text",
                    "com.google.android.youtube:id/search_query",
                ),
                editHints = listOf("Search YouTube"),
            ),
        ),
        FeatureDef(
            YT_HOME, YOUTUBE, "Recommended videos",
            "The Home feed. YouTube opens on Subscriptions instead",
            Selector(selectedLabels = listOf("Home")),
            redirectLabels = listOf("Subscriptions", "You"),
        ),
        FeatureDef(
            IG_REELS, INSTAGRAM, "Reels",
            "The Reels tab and the full-screen Reels player",
            Selector(
                selectedIds = listOf("com.instagram.android:id/clips_tab"),
                selectedLabels = listOf("Reels"),
                viewIds = listOf("com.instagram.android:id/clips_viewer_view_pager"),
            ),
            redirectLabels = listOf("Home"),
        ),
        FeatureDef(
            IG_EXPLORE, INSTAGRAM, "Explore",
            "The Search and explore tab (Instagram shows Explore and Search on one tab)",
            Selector(
                selectedIds = listOf("com.instagram.android:id/search_tab"),
                selectedLabels = listOf("Search and explore", "Explore"),
            ),
            redirectLabels = listOf("Home"),
        ),
        FeatureDef(
            IG_SEARCH, INSTAGRAM, "Search",
            "The search box, wherever it opens",
            Selector(viewIds = listOf("com.instagram.android:id/action_bar_search_edit_text")),
        ),
        FeatureDef(
            FB_REELS, FACEBOOK, "Reels", "The Reels tab (experimental)",
            Selector(selectedLabels = listOf("Reels")),
            redirectLabels = listOf("Home"),
        ),
        FeatureDef(
            FB_VIDEO, FACEBOOK, "Video", "The Video / Watch tab (experimental)",
            Selector(selectedLabels = listOf("Video", "Watch")),
            redirectLabels = listOf("Home"),
        ),
        FeatureDef(
            FB_MARKETPLACE, FACEBOOK, "Marketplace", "The Marketplace tab (experimental)",
            Selector(selectedLabels = listOf("Marketplace")),
            redirectLabels = listOf("Home"),
        ),
        FeatureDef(
            SC_SPOTLIGHT, SNAPCHAT, "Spotlight", "The Spotlight tab (experimental)",
            Selector(selectedLabels = listOf("Spotlight")),
            redirectLabels = listOf("Chat"),
        ),
        FeatureDef(
            SC_DISCOVER, SNAPCHAT, "Discover", "The Discover feed (experimental)",
            Selector(selectedLabels = listOf("Discover")),
            redirectLabels = listOf("Chat"),
        ),
        FeatureDef(
            WA_STATUS, WHATSAPP, "Status", "Status viewer and the Updates / Status tab (experimental)",
            Selector(
                windowClasses = listOf("StatusPlayback"),
                selectedLabels = listOf("Updates", "Status"),
            ),
            redirectLabels = listOf("Chats"),
        ),
        FeatureDef(
            WA_BIZ_STATUS, WHATSAPP_BIZ, "Status", "Status viewer and the Updates / Status tab (experimental)",
            Selector(
                windowClasses = listOf("StatusPlayback"),
                selectedLabels = listOf("Updates", "Status"),
            ),
            redirectLabels = listOf("Chats"),
        ),
    )

    /** YouTube Shorts has no selector (it is found by [isShortsVisible]); this is only for leaving it. */
    val youtubeShortsExit = FeatureDef(
        ShortFormCatalog.YT_SHORTS, YOUTUBE, "Shorts", "The Shorts player",
        Selector(), redirectLabels = listOf("Home", "Subscriptions"),
    )

    private val byId = all.associateBy { it.id }
    private val byPackage = all.groupBy { it.pkg }

    fun byId(id: String): FeatureDef? = byId[id]
    fun forPackage(pkg: String): List<FeatureDef> = byPackage[pkg].orEmpty()

    /** A user-defined section behaves like a preset with a "selected tab" selector. */
    fun customDef(c: CustomSection) = FeatureDef(
        id = c.id,
        pkg = c.pkg,
        title = c.label,
        note = "Your own section",
        selector = Selector(selectedLabels = listOf(c.label)),
    )
}

// ---- Shorts, Reels and Status --------------------------------------------------------------

/**
 * One kind of short-form content inside one app. [id] is also the key for its own daily limit.
 * [featureId] is the matching [FeatureCatalog] entry used to recognise it on screen
 * (null for YouTube Shorts, which has its own detector).
 */
data class ShortForm(
    val id: String,
    val pkg: String,
    val appName: String,
    val title: String,
    val featureId: String?,
) {
    val displayName: String get() = "$appName $title"
}

object ShortFormCatalog {
    const val YT_SHORTS = "yt_shorts"

    val all: List<ShortForm> = listOf(
        ShortForm(YT_SHORTS, FeatureCatalog.YOUTUBE, "YouTube", "Shorts", null),
        ShortForm(FeatureCatalog.IG_REELS, FeatureCatalog.INSTAGRAM, "Instagram", "Reels", FeatureCatalog.IG_REELS),
        ShortForm(FeatureCatalog.FB_REELS, FeatureCatalog.FACEBOOK, "Facebook", "Reels", FeatureCatalog.FB_REELS),
        ShortForm(FeatureCatalog.WA_STATUS, FeatureCatalog.WHATSAPP, "WhatsApp", "Status", FeatureCatalog.WA_STATUS),
        ShortForm(FeatureCatalog.WA_BIZ_STATUS, FeatureCatalog.WHATSAPP_BIZ, "WhatsApp Business", "Status", FeatureCatalog.WA_BIZ_STATUS),
        ShortForm(FeatureCatalog.SC_SPOTLIGHT, FeatureCatalog.SNAPCHAT, "Snapchat", "Spotlight", FeatureCatalog.SC_SPOTLIGHT),
    )

    private val byId = all.associateBy { it.id }

    fun byId(id: String): ShortForm? = byId[id]

    fun forPackage(pkg: String): List<ShortForm> = all.filter { it.pkg == pkg }

    /** Only the content kinds whose app is really installed. Nothing is shown for other apps. */
    fun installed(installedPackages: Set<String>): List<ShortForm> = all.filter { it.pkg in installedPackages }

    /** The exit definition used when a daily limit closes this content. */
    fun exitDef(form: ShortForm): FeatureDef? =
        if (form.id == YT_SHORTS) FeatureCatalog.youtubeShortsExit else form.featureId?.let { FeatureCatalog.byId(it) }
}

// ---- Screen matching --------------------------------------------------------------------------

object FeatureMatcher {

    /** True when [label] is the start of [candidate] at a word boundary ("Reels, tab 2 of 5"). */
    fun labelMatches(label: String, candidate: String): Boolean {
        val l = EducationMatcher.norm(label)
        val c = EducationMatcher.norm(candidate)
        if (l.isEmpty() || c.length < l.length || !c.startsWith(l)) return false
        return c.length == l.length || !c[l.length].isLetterOrDigit()
    }

    fun matches(sel: Selector, nodes: List<NodeSnap>, windowClass: String = ""): Boolean {
        if (windowClass.isNotEmpty() && sel.windowClasses.any { windowClass.contains(it, ignoreCase = true) }) return true
        for (n in nodes) {
            if (!n.visible) continue
            if (n.id.isNotEmpty()) {
                if (n.id in sel.viewIds) return true
                if (n.selected && n.id in sel.selectedIds) return true
            }
            if (n.selected && sel.selectedLabels.any { labelMatches(it, n.text) || labelMatches(it, n.desc) }) return true
            if (sel.editHints.isNotEmpty() && n.cls.endsWith("EditText")) {
                val t = EducationMatcher.norm(n.text)
                if (sel.editHints.any { t.contains(EducationMatcher.norm(it)) }) return true
            }
        }
        return false
    }
}

// ---- YouTube Shorts detection -----------------------------------------------------------------

/**
 * Recognises the YouTube Shorts player from a screen snapshot. YouTube renames its view ids in
 * almost every release, so this does not rely on one id: either of these is enough.
 *  - a visible view whose id contains "reel_" or "shorts_" (the Shorts player is built from "reel"
 *    views), unless it belongs to the Shorts shelf shown inside Home / Subscriptions,
 *  - the bottom "Shorts" tab being selected.
 * A visible "Shorts" label alone is NOT enough: the tab is on screen on every YouTube page.
 */
object ShortsDetector {

    private val idHints = listOf("reel_", "shorts_")

    /** Ids that contain the hint words but belong to the Shorts shelf in normal feeds. */
    private val shelfHints = listOf("shelf", "lockup", "carousel", "thumbnail", "reel_item", "shorts_item", "tab")

    fun isShortsScreen(nodes: List<NodeSnap>): Boolean {
        for (n in nodes) {
            if (!n.visible) continue
            val id = n.id.substringAfter(":id/", n.id).lowercase()
            if (id.isNotEmpty() && idHints.any { id.contains(it) } && shelfHints.none { id.contains(it) }) return true
            if (n.selected && (FeatureMatcher.labelMatches("Shorts", n.text) || FeatureMatcher.labelMatches("Shorts", n.desc))) return true
        }
        return false
    }
}

/** Which of a package's limited Shorts / Reels / Status content is open, and how much time is left. */
data class CategoryStatus(val id: String, val remainingMs: Long)

object CategoryTimer {
    /** Time left for a limited kind of content; never negative. */
    fun remaining(limitMs: Long, usedMs: Long, pendingMs: Long): Long = (limitMs - usedMs - pendingMs).coerceAtLeast(0L)

    /** When both an app limit and a Shorts limit apply, the timer shows whichever runs out first. */
    fun pick(appRemainingMs: Long?, categoryRemainingMs: Long?): Boolean =
        categoryRemainingMs != null && (appRemainingMs == null || categoryRemainingMs <= appRemainingMs)
}

// ---- Educational Shorts -----------------------------------------------------------------------

sealed class ShortsVerdict {
    /** The Short may play. [by] says why ("channel" or "auto"). */
    data class Allow(val by: String) : ShortsVerdict()

    /** Not enough on screen yet to decide; look again shortly. */
    object Wait : ShortsVerdict()

    /** Block it. [channel] is the handle or name that was recognised, if any. */
    data class Block(val channel: String?) : ShortsVerdict()
}

object EducationMatcher {

    private val handleRegex = Regex("@[\\p{L}\\p{N}._\\-]{3,30}")
    private val tokenRegex = Regex("[\\p{L}\\p{N}]+")
    private val channelishId = listOf("channel", "owner", "byline", "author", "creator")

    /** Lower-case, no leading @, single spaces. Used for every comparison. */
    fun norm(s: String): String =
        s.replace("​", "").replace(" ", " ").trim().lowercase()
            .removePrefix("@").replace(Regex("\\s+"), " ")

    private fun squash(s: String) = norm(s).replace(" ", "")

    /**
     * Turns what the user typed into a channel entry, or null if it can't be matched on screen.
     * Accepts a name, an @handle, or a youtube.com/@handle link. Channel-id links (/channel/UC…)
     * are refused because YouTube never shows that id inside the Shorts player.
     */
    fun parseChannelInput(raw: String): EduChannel? {
        var t = raw.trim()
        if (t.contains("youtube.com/", ignoreCase = true) || t.contains("youtu.be/", ignoreCase = true)) {
            val m = handleRegex.find(t) ?: return null
            t = m.value
        }
        t = t.replace(Regex("\\s+"), " ")
        if (t.length > 40) return null
        val key = norm(t)
        if (key.length < 3) return null
        if (!key.all { it.isLetterOrDigit() || it in " ._-'&" }) return null
        return EduChannel(key = key, display = t)
    }

    fun extractHandles(nodes: List<NodeSnap>): List<String> {
        val out = LinkedHashSet<String>()
        for (n in nodes) {
            if (!n.visible) continue
            handleRegex.findAll(n.text).forEach { out += it.value }
            handleRegex.findAll(n.desc).forEach { out += it.value }
        }
        return out.toList()
    }

    /** The handle most likely to be the current Short's channel, or null if none is on screen. */
    fun guessChannel(nodes: List<NodeSnap>): String? {
        for (n in nodes) {
            if (!n.visible || channelishId.none { n.id.contains(it, ignoreCase = true) }) continue
            handleRegex.find(n.text)?.let { return it.value }
            handleRegex.find(n.desc)?.let { return it.value }
        }
        return extractHandles(nodes).firstOrNull()
    }

    /** The whitelist entry that matches what is on screen, or null. */
    fun matchChannel(nodes: List<NodeSnap>, channels: List<EduChannel>): EduChannel? {
        if (channels.isEmpty()) return null
        val visible = nodes.filter { it.visible }
        val handles = extractHandles(visible).map { squash(it) }.toSet()
        val exact = HashSet<String>()
        for (n in visible) {
            if (n.text.isNotBlank()) exact += squash(n.text)
            if (n.desc.isNotBlank()) exact += squash(n.desc)
        }
        val channelish = visible
            .filter { n -> n.id.isNotEmpty() && channelishId.any { n.id.contains(it, ignoreCase = true) } }
            .flatMap { listOf(norm(it.text), norm(it.desc)) }
            .filter { it.isNotEmpty() }
        for (ch in channels) {
            val k = squash(ch.key)
            if (k in handles || k in exact) return ch
            val plain = norm(ch.key)
            if (plain.length >= 4 && channelish.any { it.contains(plain) }) return ch
        }
        return null
    }

    // Keyword scoring. Approximate by design: it reads the caption, hashtags and channel name.
    private val strongTerms = setOf(
        "education", "educational", "learn", "learning", "study", "studying", "science", "physics",
        "chemistry", "biology", "maths", "math", "mathematics", "history", "geography", "economics",
        "tutorial", "lecture", "lesson", "explained", "explanation", "revision", "syllabus", "ncert",
        "cbse", "jee", "neet", "upsc", "ssc", "coding", "programming", "python", "algorithm",
        "grammar", "vocabulary", "ielts", "formula", "theorem", "polity", "padhai", "shiksha",
    )
    private val weakTerms = setOf(
        "facts", "knowledge", "tips", "exam", "class", "school", "college", "university", "student",
        "teacher", "english", "hindi", "language", "skills", "career", "gk",
    )
    private val weakPhrases = listOf("how to", "current affairs", "general knowledge")
    private val negativeTerms = setOf(
        "funny", "prank", "meme", "memes", "comedy", "dance", "challenge", "reaction", "roast",
        "viral", "asmr", "fyp", "satisfying", "gossip", "drama", "couple",
    )
    private val noiseRegex = Regex("learn more|learn about|sponsored|shop now|install now")

    const val AUTO_THRESHOLD = 4

    fun educationScore(nodes: List<NodeSnap>): Int {
        val text = nodes.filter { it.visible }
            .joinToString(" ") { it.text + " " + it.desc }
            .lowercase()
            .replace(noiseRegex, " ")
        val tokens = tokenRegex.findAll(text).map { it.value }.toSet()
        var score = 0
        score += 2 * strongTerms.count { it in tokens }
        score += weakTerms.count { it in tokens }
        score += weakPhrases.count { text.contains(it) }
        score -= 3 * negativeTerms.count { it in tokens }
        return score
    }

    fun looksEducational(nodes: List<NodeSnap>): Boolean = educationScore(nodes) >= AUTO_THRESHOLD

    /**
     * Decides what to do with the Short that is on screen.
     *
     * With no list and no automatic detection every Short is blocked at once (the original
     * "block Shorts" behaviour). Otherwise a listed channel always plays; automatic detection
     * may let others through; anything else is blocked as soon as its channel is known, or after
     * the grace period if the screen never shows one ([graceOver]).
     */
    fun judge(nodes: List<NodeSnap>, channels: List<EduChannel>, autoDetect: Boolean, graceOver: Boolean): ShortsVerdict {
        if (channels.isEmpty() && !autoDetect) return ShortsVerdict.Block(null)
        if (matchChannel(nodes, channels) != null) return ShortsVerdict.Allow("channel")
        if (autoDetect && looksEducational(nodes)) return ShortsVerdict.Allow("auto")
        val who = guessChannel(nodes)
        // Captions often load a moment after the channel, so automatic detection also waits.
        val ready = who != null && !autoDetect
        return if (ready || graceOver) ShortsVerdict.Block(who) else ShortsVerdict.Wait
    }
}

// ---- Editing rules ----------------------------------------------------------------------------

object ContentPolicy {

    const val MAX_CHANNELS = 100
    const val MAX_CUSTOM = 30
    const val MAX_RECENT = 12

    /** Everything in these screens is an app restriction, so "app restriction changes" governs it. */
    fun frozen(s: FocusState) = s.changesLocked || (s.focusActive && !s.canEditApps)

    /**
     * Switching a restriction ON tightens things; switching it OFF loosens them. While a session
     * runs only tightening is possible, and only if app changes are allowed.
     */
    fun canSetFeature(s: FocusState, current: Boolean, on: Boolean): Boolean {
        if (current == on) return true
        if (s.changesLocked) return false
        if (!s.focusActive) return true
        return s.canEditApps && on
    }

    /** Automatic detection lets more Shorts through, so it is the opposite: only OFF while running. */
    fun canSetAutoDetect(s: FocusState, current: Boolean, on: Boolean): Boolean {
        if (current == on) return true
        if (s.changesLocked) return false
        if (!s.focusActive) return true
        return s.canEditApps && !on
    }

    /** A new allowed channel loosens the rules: only between sessions. */
    fun canAddChannel(s: FocusState) = !s.focusActive && !s.changesLocked

    fun canRemoveChannel(s: FocusState) = !s.changesLocked && (!s.focusActive || s.canEditApps)

    fun canAddCustom(s: FocusState) = !s.changesLocked && (!s.focusActive || s.canEditApps)

    fun canRemoveCustom(s: FocusState) = !s.focusActive && !s.changesLocked
}

/** Plain-string list storage for SharedPreferences (order kept, no JSON dependency). */
object ListCodec {
    private const val SEP = '\u001F'

    fun encode(parts: List<String>): String = parts.joinToString(SEP.toString())

    fun decode(raw: String?): List<String> =
        if (raw.isNullOrEmpty()) emptyList() else raw.split(SEP)

    fun pair(a: String, b: String) = a + "\u001E" + b

    fun unpair(raw: String): Pair<String, String>? {
        val i = raw.indexOf('\u001E')
        return if (i <= 0) null else raw.substring(0, i) to raw.substring(i + 1)
    }
}
