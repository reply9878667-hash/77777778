package com.focusmode.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle

/**
 * Restarts the whole app. It runs in its own process (see the manifest), so it can start LockDistra again after LockDistra's
 * process is gone. Used after a settings download, because every store reads its settings once at start-up.
 */
class RestartActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        val target = intent.getParcelableExtra<Intent>(EXTRA_TARGET)
        if (target != null) {
            try {
                startActivity(target)
            } catch (_: Exception) {
                // Nothing more to do: the person opens LockDistra again by hand.
            }
        }
        finish()
        Runtime.getRuntime().exit(0)
    }

    companion object {
        private const val EXTRA_TARGET = "target"

        /** Closes the app and opens it again. Call from the foreground. */
        fun restart(context: Context) {
            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName) ?: return
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            context.startActivity(
                Intent(context, RestartActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(EXTRA_TARGET, launch)
            )
            Runtime.getRuntime().exit(0)
        }
    }
}
