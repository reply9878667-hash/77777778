package com.focusmode.app.data

import java.util.BitSet

/**
 * Which parts of the lecture were REALLY watched (Lecture Lock, "turn Focus Mode off when the lecture ends").
 *
 * Why: someone who wants to leave Focus Mode could drag the seek bar to the very end and the lecture would count as
 * finished. The seek bar stays free to use (rewind, skip a boring minute, 2x speed: nothing about the player changes),
 * but only seconds that played at a natural pace are counted. Focus Mode ends after the lecture only when at least
 * [REQUIRED] of it was watched. If not, the player offers to continue at the first part that was skipped.
 *
 * Plain Kotlin (no Android types), so it is unit tested on the JVM.
 */
class LectureWatch(initial: BitSet = BitSet()) {

    private val bits: BitSet = initial.clone() as BitSet
    private var lastPos = -1.0
    private var lastAtMs = 0L

    /** Furthest video position reported in this run (seconds); -1 = none yet. */
    private var maxPos = -1.0

    /**
     * One progress report from the player: video position [pos] (seconds), the video's [dur], the chosen playback
     * [speed], and the clock [nowMs]. Returns true when new seconds were counted as watched.
     * A jump (seek bar, +10 s button, double tap) is not counted; it only moves the "last position".
     */
    @Synchronized
    fun report(pos: Double, dur: Double, speed: Double, nowMs: Long): Boolean {
        if (pos.isNaN() || dur.isNaN() || dur <= 0.0) return false
        if (pos > maxPos) maxPos = pos
        var changed = false
        if (lastPos >= 0.0 && isNaturalStep(lastPos, pos, (nowMs - lastAtMs) / 1000.0, speed)) {
            changed = mark(lastPos, pos, dur)
        }
        lastPos = pos
        lastAtMs = nowMs
        return changed
    }

    private fun mark(from: Double, to: Double, dur: Double): Boolean {
        val last = segments(dur) - 1
        val a = (from / SEG).toInt().coerceIn(0, last)
        val b = (to / SEG).toInt().coerceIn(0, last)
        var changed = false
        for (i in a..b) if (!bits.get(i)) { bits.set(i); changed = true }
        return changed
    }

    /** Seconds of the video counted as watched (each part counted once, however often it was played). */
    @Synchronized
    fun watchedSeconds(dur: Double): Double = (bits.get(0, segments(dur)).cardinality() * SEG).toDouble().coerceAtMost(dur)

    /** 0.0 .. 1.0 */
    @Synchronized
    fun coverage(dur: Double): Double = if (dur <= 0.0) 0.0 else (watchedSeconds(dur) / dur).coerceIn(0.0, 1.0)

    /** True when enough of the lecture was watched for it to count as finished. */
    fun enough(dur: Double): Boolean = coverage(dur) >= REQUIRED

    /** Start (in seconds) of the first part that was not watched, a couple of seconds earlier so the sentence is not cut; 0 when nothing was watched. */
    @Synchronized
    fun firstGap(dur: Double): Int {
        val n = segments(dur)
        val i = bits.nextClearBit(0)
        return if (i >= n) 0 else ((i * SEG) - 2).coerceAtLeast(0)
    }

    /**
     * The SKIPPED parts, as (start, end) seconds: seconds that were not watched but lie BEFORE the furthest point reached, so the
     * not-yet-played rest of the video is never listed. Runs shorter than [minLen] seconds (the first moments before the first
     * report, a tiny seek) are left out. In page order.
     */
    @Synchronized
    fun skippedRanges(dur: Double, minLen: Int = MIN_SKIPPED): List<Pair<Int, Int>> {
        if (dur <= 0.0) return emptyList()
        val n = segments(dur)
        var limit = bits.length() // one past the last watched second
        if (maxPos >= 0.0) limit = maxOf(limit, (maxPos / SEG).toInt())
        limit = limit.coerceAtMost(n)
        val out = ArrayList<Pair<Int, Int>>()
        var i = 0
        while (i < limit) {
            if (bits.get(i)) { i++; continue }
            var j = i
            while (j < limit && !bits.get(j)) j++
            if (j - i >= minLen) out += (i * SEG) to (j * SEG)
            i = j
        }
        return out
    }

    /**
     * [skippedRanges] as `[[from,to],...]` with fractions of the video (0..1) for the player's seek bar, e.g. `[[0.1,0.25]]`.
     * Always a dot as the decimal sign (never a comma), at most [MAX_RANGES] ranges.
     */
    fun skippedJson(dur: Double): String {
        if (dur <= 0.0) return "[]"
        return skippedRanges(dur).take(MAX_RANGES).joinToString(",", "[", "]") {
            String.format(java.util.Locale.US, "[%.4f,%.4f]", (it.first / dur).coerceIn(0.0, 1.0), (it.second / dur).coerceIn(0.0, 1.0))
        }
    }

    /** For saving between screens / app restarts. */
    @Synchronized
    fun toHex(): String = bits.toByteArray().joinToString("") { "%02x".format(it.toInt() and 0xff) }

    @Synchronized
    fun isEmpty(): Boolean = bits.isEmpty

    companion object {
        /** One flag per second of video. */
        const val SEG = 1

        /** Share of the lecture that has to be watched (the rest may be skipped: intro, a break, a short rewind and forward). */
        const val REQUIRED = 0.90

        /** Skipped runs shorter than this many seconds are not shown on the seek bar. */
        const val MIN_SKIPPED = 5

        /** Most red marks drawn on the seek bar. */
        const val MAX_RANGES = 80

        private const val MAX_STEP_WINDOW = 10.0

        private fun segments(dur: Double): Int = kotlin.math.ceil(dur / SEG).toInt().coerceAtLeast(1)

        /**
         * A report counts as "playing normally" when the position moved forward by about what the clock and the speed allow:
         * (real seconds, at most 10) x speed x 1.3 + 1 s. A seek of a few seconds is inside that; a real skip never is.
         */
        fun isNaturalStep(prevPos: Double, pos: Double, realSeconds: Double, speed: Double): Boolean {
            val dv = pos - prevPos
            if (dv <= 0.0 || realSeconds <= 0.0) return false
            val sp = if (speed.isNaN() || speed < 0.25) 1.0 else speed.coerceAtMost(4.0)
            return dv <= realSeconds.coerceAtMost(MAX_STEP_WINDOW) * sp * 1.3 + 1.0
        }

        fun fromHex(hex: String?): BitSet {
            if (hex.isNullOrEmpty() || hex.length % 2 != 0) return BitSet()
            return try {
                BitSet.valueOf(ByteArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toInt(16).toByte() })
            } catch (_: NumberFormatException) {
                BitSet()
            }
        }
    }
}
