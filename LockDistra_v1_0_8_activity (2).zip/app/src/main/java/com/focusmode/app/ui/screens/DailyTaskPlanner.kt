package com.focusmode.app.ui.screens

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.focusmode.app.data.DailyTask
import com.focusmode.app.data.DailyTaskRules
import com.focusmode.app.data.TaskStore
import com.focusmode.app.data.TaskTag
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.online.fieldColors
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

/**
 * Daily Task Planner: sits on the Home screen next to the Focus controls. Add tasks, long-press to select (with a
 * short vibration), tag the selection Today or Tomorrow, tick tasks off with the checkbox on the right.
 * Self-contained: it reads and writes only [TaskStore] and never touches Focus Mode, Focus Profile, blocking or Pomodoro.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DailyTaskPlanner(modifier: Modifier = Modifier) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val store = remember { TaskStore.get(context) }
    val board by store.state.collectAsState()

    var selectedRaw by remember { mutableStateOf(setOf<Long>()) }
    var adding by remember { mutableStateOf(false) }

    // Selection only ever holds tasks that still exist.
    val selected = remember(selectedRaw, board.tasks) {
        val ids = board.tasks.mapTo(HashSet()) { it.id }
        selectedRaw.filterTo(HashSet()) { it in ids }
    }
    val selecting = selected.isNotEmpty()

    // ---- Date changes: coming back to the app, midnight while it is open, clock / time zone changes ----
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { store.refreshDate() }
    LaunchedEffect(Unit) {
        while (true) {
            store.refreshDate()
            delay(TaskStore.msUntilMidnight() + 500L)
        }
    }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) = store.refreshDate()
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_DATE_CHANGED)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        ContextCompat.registerReceiver(context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }

    // Back closes the selection first.
    BackHandler(enabled = selecting) { selectedRaw = emptySet() }

    fun toggleSelect(id: Long) {
        if (id in selected) {
            selectedRaw = selected - id
        } else {
            selectedRaw = selected + id
            buzz(context)
        }
    }

    FocusCard(modifier = modifier.fillMaxWidth(), padding = PaddingValues(16.dp)) {
        Column(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Daily Tasks", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                SoftChip(text = "+ Add Task", selected = true, onClick = { adding = true })
            }

            // Selection bar: assign a tag, or clear the selection.
            if (selecting) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${selected.size} selected", style = MaterialTheme.typography.bodyMedium, color = c.muted, modifier = Modifier.weight(1f))
                    SoftChip(text = "Today", selected = false, onClick = {
                        store.assign(selected, TaskTag.TODAY); selectedRaw = emptySet()
                    })
                    SoftChip(text = "Tomorrow", selected = false, onClick = {
                        store.assign(selected, TaskTag.TOMORROW); selectedRaw = emptySet()
                    })
                    CircleIconButton(Icons.Outlined.Close, "Clear selection", { selectedRaw = emptySet() })
                }
            }

            if (board.tasks.isEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("No tasks yet. Tap Add Task to plan your day.", style = MaterialTheme.typography.bodySmall, color = c.muted)
            } else {
                if (!selecting) {
                    Spacer(Modifier.height(6.dp))
                    Text("Long-press a task to select it.", style = MaterialTheme.typography.bodySmall, color = c.muted)
                }
                TaskGroup("Today Tasks", DailyTaskRules.inTag(board, TaskTag.TODAY), selected, selecting, store, ::toggleSelect, showEmpty = true)
                TaskGroup("Tomorrow Tasks", DailyTaskRules.inTag(board, TaskTag.TOMORROW), selected, selecting, store, ::toggleSelect, showEmpty = true)
                TaskGroup("Unassigned", DailyTaskRules.inTag(board, TaskTag.NONE), selected, selecting, store, ::toggleSelect, showEmpty = false)
            }
        }
    }

    if (adding) {
        AddTaskDialog(
            onDismiss = { adding = false },
            onAdd = { text -> store.addTask(text); adding = false },
        )
    }
}

@Composable
private fun TaskGroup(
    title: String,
    tasks: List<DailyTask>,
    selected: Set<Long>,
    selecting: Boolean,
    store: TaskStore,
    onToggleSelect: (Long) -> Unit,
    showEmpty: Boolean,
) {
    if (tasks.isEmpty() && !showEmpty) return
    val c = FocusTheme.colors
    Spacer(Modifier.height(14.dp))
    Text(title, style = MaterialTheme.typography.titleSmall, color = c.accent)
    Spacer(Modifier.height(6.dp))
    if (tasks.isEmpty()) {
        Text("No tasks", style = MaterialTheme.typography.bodySmall, color = c.muted)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        tasks.forEach { task ->
            key(task.id) {
                TaskRow(
                    task = task,
                    selected = task.id in selected,
                    selecting = selecting,
                    onTap = { onToggleSelect(task.id) },
                    onLongPress = { onToggleSelect(task.id) },
                    onCheck = { store.setDone(task.id, it) },
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TaskRow(
    task: DailyTask,
    selected: Boolean,
    selecting: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    onCheck: (Boolean) -> Unit,
) {
    val c = FocusTheme.colors
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) c.accentSoft else c.cardHigh)
            .border(1.dp, if (selected) c.accent else Color.Transparent, shape)
            .combinedClickable(
                onClick = { if (selecting) onTap() },
                onLongClick = onLongPress,
            )
            .padding(start = 14.dp, top = 2.dp, bottom = 2.dp, end = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            task.text,
            style = MaterialTheme.typography.bodyMedium,
            color = if (task.done) c.muted else c.text,
            textDecoration = if (task.done) TextDecoration.LineThrough else TextDecoration.None,
            modifier = Modifier.weight(1f).padding(vertical = 8.dp)
        )
        Checkbox(
            checked = task.done,
            onCheckedChange = onCheck,
            colors = CheckboxDefaults.colors(
                checkedColor = c.accent,
                uncheckedColor = c.muted,
                checkmarkColor = c.onAccent,
            ),
            modifier = Modifier.size(44.dp)
        )
    }
}

@Composable
private fun AddTaskDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    val c = FocusTheme.colors
    var text by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val valid = DailyTaskRules.cleanText(text) != null
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Add Task", style = MaterialTheme.typography.titleLarge) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(DailyTaskRules.MAX_TEXT) },
                label = { Text("e.g. Read Physics Chapter 1") },
                singleLine = true,
                colors = fieldColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { if (valid) onAdd(text) }),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onAdd(text) }) {
                Text("Add", color = if (valid) c.accent else c.muted)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}

/** One short vibration (selection feedback). Silent if the phone has no vibrator. */
private fun buzz(context: Context) {
    try {
        val effect = VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE)
        if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)
                ?.defaultVibrator?.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(effect)
        }
    } catch (_: Exception) {
    }
}
