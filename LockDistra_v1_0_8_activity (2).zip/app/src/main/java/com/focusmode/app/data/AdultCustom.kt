package com.focusmode.app.data

enum class CustomKind { DOMAIN, KEYWORD }

/** One thing the person added to Adult Content Protection: a website (link) or a word. */
data class CustomEntry(val kind: CustomKind, val value: String)

/**
 * The person's own blocked links and words for Adult Content Protection. No Android classes, so it is unit tested.
 *
 * The person types or pastes anything into one box and [parse] decides what it is:
 *  - a link or website ("https://example.com/page", "www.example.com", "example.com") -> the site (and its subdomains);
 *  - anything else (a word or a few words, 3 to 40 characters) -> a word that closes a browser page whose address
 *    bar contains it ("pornhub", "sex video").
 */
object AdultCustom {

    const val MAX = 100
    const val MIN_KEYWORD = 3
    const val MAX_KEYWORD = 40

    enum class Result { OK, INVALID, TOO_COMMON, ALREADY_THERE, LOCKED, FULL }

    /** The entry [raw] stands for, or null when it is neither a usable link nor a usable word. */
    fun parse(raw: String): CustomEntry? {
        val s = raw.trim()
        if (s.isEmpty() || s.length > 2048) return null
        val domain = WebsiteRules.normalize(s)
        if (domain != null) return CustomEntry(CustomKind.DOMAIN, domain)
        val k = cleanKeyword(s)
        return if (k.length in MIN_KEYWORD..MAX_KEYWORD) CustomEntry(CustomKind.KEYWORD, k) else null
    }

    /**
     * A pasted link with a path or a search ("https://google.com/search?q=...") must not close the whole site of a
     * big platform by accident; typing just "google.com" still does, because that is deliberate.
     */
    fun isAccidentalBigSite(raw: String, entry: CustomEntry): Boolean {
        if (entry.kind != CustomKind.DOMAIN) return false
        val s = raw.trim().replace(Regex("^[a-zA-Z][a-zA-Z0-9+.-]*://"), "")
        val hasPath = s.indexOfFirst { it == '/' || it == '?' || it == '#' }.let { it >= 0 && it < s.length - 1 }
        return hasPath && AdultBlocklist.isProtected(entry.value)
    }

    fun cleanKeyword(raw: String): String = raw.trim().lowercase().replace(Regex("\\s+"), " ")

    /** Address bars write spaces as + or %20, and sites as - or _; compare with all of them as plain spaces. */
    private fun squash(t: String): String =
        t.replace("%20", " ").replace('+', ' ').replace('_', ' ').replace('-', ' ')

    /** The first of [keywords] found in [text] (the address bar), or null. */
    fun keywordHit(text: String, keywords: Collection<String>): String? {
        if (keywords.isEmpty() || text.isBlank()) return null
        val a = text.lowercase()
        val b = squash(a)
        for (k in keywords) {
            if (a.contains(k) || b.contains(squash(k))) return k
        }
        return null
    }

    /** True when [host] is one of [domains] or a subdomain of one. */
    fun domainHit(host: String, domains: Collection<String>): Boolean =
        domains.any { WebsiteRules.matches(host, WebsiteRule(it, enabled = true, subdomains = true)) }

    fun encode(entries: List<CustomEntry>): String =
        ListCodec.encode(entries.map { (if (it.kind == CustomKind.DOMAIN) "d:" else "k:") + it.value })

    fun decode(raw: String?): List<CustomEntry> =
        ListCodec.decode(raw).mapNotNull {
            when {
                it.startsWith("d:") && it.length > 2 -> CustomEntry(CustomKind.DOMAIN, it.substring(2))
                it.startsWith("k:") && it.length > 2 -> CustomEntry(CustomKind.KEYWORD, it.substring(2))
                else -> null
            }
        }
}
