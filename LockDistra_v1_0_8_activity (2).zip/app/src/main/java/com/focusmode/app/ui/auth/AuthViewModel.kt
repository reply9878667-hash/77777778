package com.focusmode.app.ui.auth

import android.app.Activity
import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.focusmode.app.data.auth.AuthConfig
import com.focusmode.app.data.auth.AuthDebug
import com.focusmode.app.data.auth.AuthErrorKind
import com.focusmode.app.data.auth.AuthRepository
import com.focusmode.app.data.auth.AuthResult
import com.focusmode.app.data.auth.AuthSession
import com.focusmode.app.data.auth.AuthValidation
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/** What is running right now. Anything but None disables every button, so nothing can be submitted twice. */
enum class AuthBusy { None, Email, Google, Reset }

data class AuthSuccess(val name: String, val isNewAccount: Boolean)

data class AuthFormState(
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val confirm: String = "",
    val nameError: String? = null,
    val emailError: String? = null,
    val passwordError: String? = null,
    val confirmError: String? = null,
    /** Error that belongs to no single field (wrong password, no internet, ...). */
    val banner: String? = null,
    /** Good news (the reset mail was sent). */
    val info: String? = null,
    val busy: AuthBusy = AuthBusy.None,
    /** Seconds until "Send again" works. */
    val resetCooldown: Int = 0,
    val success: AuthSuccess? = null,
)

/**
 * State and actions of the account screens. Survives rotation (the typed text stays); the passwords live only
 * in memory here and are cleared as soon as an attempt succeeds or the person changes screen.
 */
class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AuthRepository.get(application)

    var form by mutableStateOf(AuthFormState())
        private set

    val session: StateFlow<AuthSession> = repo.session

    private var cooldownJob: Job? = null

    private inline fun update(change: (AuthFormState) -> AuthFormState) {
        form = change(form)
    }

    // ---- Typing ----------------------------------------------------------------------------------

    fun onName(v: String) = update { it.copy(name = v.take(AuthConfig.MAX_NAME), nameError = null, banner = null) }
    fun onEmail(v: String) = update { it.copy(email = v.take(AuthConfig.MAX_EMAIL), emailError = null, banner = null, info = null) }
    fun onPassword(v: String) = update { it.copy(password = v.take(AuthConfig.MAX_PASSWORD), passwordError = null, banner = null) }
    fun onConfirm(v: String) = update { it.copy(confirm = v.take(AuthConfig.MAX_PASSWORD), confirmError = null, banner = null) }

    /** Moving between Sign up / Log in / Forgot: old errors and passwords go, the email stays. */
    fun onScreenChanged() = update {
        it.copy(
            password = "", confirm = "",
            nameError = null, emailError = null, passwordError = null, confirmError = null,
            banner = null, info = null,
        )
    }

    /** Shows the reason the person was sent here (for example "Your session has expired"), once. */
    fun showPendingNotice() {
        val notice = repo.takeNotice() ?: return
        update { it.copy(banner = notice) }
    }

    /** Back to a blank form. Called when the account screens close. */
    fun reset() {
        cooldownJob?.cancel()
        form = AuthFormState()
    }

    // ---- Actions ---------------------------------------------------------------------------------

    fun submitSignUp() {
        val f = form
        if (f.busy != AuthBusy.None) return
        val nameErr = AuthValidation.nameError(f.name)
        val emailErr = AuthValidation.emailError(f.email)
        val passErr = AuthValidation.newPasswordError(f.password)
        val confirmErr = AuthValidation.confirmError(f.password, f.confirm)
        if (nameErr != null || emailErr != null || passErr != null || confirmErr != null) {
            update {
                it.copy(nameError = nameErr, emailError = emailErr, passwordError = passErr, confirmError = confirmErr, banner = null)
            }
            return
        }
        launchAction(AuthBusy.Email) { repo.signUpWithEmail(f.name, f.email, f.password) }
    }

    fun submitLogin() {
        val f = form
        if (f.busy != AuthBusy.None) return
        val emailErr = AuthValidation.emailError(f.email)
        val passErr = AuthValidation.loginPasswordError(f.password)
        if (emailErr != null || passErr != null) {
            update { it.copy(emailError = emailErr, passwordError = passErr, banner = null) }
            return
        }
        launchAction(AuthBusy.Email) { repo.signInWithEmail(f.email, f.password) }
    }

    fun submitReset() {
        val f = form
        if (f.busy != AuthBusy.None || f.resetCooldown > 0) return
        val emailErr = AuthValidation.emailError(f.email)
        if (emailErr != null) {
            update { it.copy(emailError = emailErr, banner = null, info = null) }
            return
        }
        launchAction(AuthBusy.Reset) { repo.sendPasswordReset(f.email) }
    }

    fun submitGoogle(activity: Activity?) {
        if (form.busy != AuthBusy.None) return
        if (activity == null) {
            update { it.copy(banner = "Google sign-in couldn't start. Close and reopen the app, then try again.") }
            return
        }
        launchAction(AuthBusy.Google) { repo.signInWithGoogle(activity) }
    }

    private fun launchAction(kind: AuthBusy, action: suspend () -> AuthResult) {
        update { it.copy(busy = kind, banner = null, info = null) }
        viewModelScope.launch {
            val result = action()
            handle(result, kind)
        }
    }

    private fun handle(result: AuthResult, kind: AuthBusy) {
        // Debug builds: a Google attempt that did not end in a login always says where it stopped.
        if (kind == AuthBusy.Google && com.focusmode.app.BuildConfig.DEBUG && result !is AuthResult.Success) {
            val msg = (result as? AuthResult.Failure)?.message
            update {
                it.copy(
                    busy = AuthBusy.None,
                    banner = listOfNotNull(msg, "Google debug:\n" + AuthDebug.trail()).joinToString("\n\n"),
                )
            }
            return
        }
        when (result) {
            is AuthResult.Success -> update {
                it.copy(
                    busy = AuthBusy.None, password = "", confirm = "",
                    success = AuthSuccess(result.user.name, result.isNewAccount),
                )
            }

            is AuthResult.Failure -> update {
                val base = it.copy(busy = AuthBusy.None)
                when (result.kind) {
                    AuthErrorKind.INVALID_EMAIL -> base.copy(emailError = result.message)
                    AuthErrorKind.EMAIL_IN_USE -> base.copy(emailError = result.message)
                    AuthErrorKind.WEAK_PASSWORD -> base.copy(passwordError = result.message)
                    else -> base.copy(banner = result.message)
                }
            }

            AuthResult.Cancelled -> update { it.copy(busy = AuthBusy.None) }

            AuthResult.Done -> {
                // Only the password reset ends this way.
                update {
                    it.copy(
                        busy = AuthBusy.None,
                        // Never says whether the account exists (so the form can't be used to probe accounts).
                        info = "Email sent \u2705 Check your inbox at ${AuthValidation.cleanEmail(it.email)} " +
                            "\u2709\uFE0F It can take 1\u20132 minutes to arrive. " +
                            "Can't see it? Look in Spam or Promotions \uD83D\uDCEC",
                    )
                }
                if (kind == AuthBusy.Reset) startCooldown()
            }
        }
    }

    private fun startCooldown() {
        cooldownJob?.cancel()
        update { it.copy(resetCooldown = AuthConfig.RESET_COOLDOWN_SECONDS) }
        cooldownJob = viewModelScope.launch {
            while (form.resetCooldown > 0) {
                delay(1_000)
                update { it.copy(resetCooldown = (it.resetCooldown - 1).coerceAtLeast(0)) }
            }
        }
    }
}
