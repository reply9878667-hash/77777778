package com.focusmode.app.data

import com.focusmode.app.BuildConfig

/**
 * Two builds come from the same code:
 *  - the normal build has every feature, including uninstall protection;
 *  - the Play-safe build (-PlayBuild=true) leaves uninstall protection out, because Google Play does
 *    not allow an app to prevent its own removal outside parental-control / enterprise use.
 */
object SafetyConfig {
    /** Uninstall protection: device admin and guarding the Settings / installer / Play Store screens. */
    val UNINSTALL_PROTECTION: Boolean = !BuildConfig.PLAY_STORE_BUILD

    /** True in the Play-safe build: uses the plain battery list instead of the one-tap request. */
    val PLAY_STORE_BUILD: Boolean = BuildConfig.PLAY_STORE_BUILD

    /**
     * Google Play Protect warning screens ("harmful app", "Play Protect") are never covered, so
     * the person can always uninstall LockDistra from a Play Protect warning if they want to.
     */
    const val ALLOW_PLAY_PROTECT_SCREENS = true
}
