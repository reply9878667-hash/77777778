package com.focusmode.app.data

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Whether LockDistra's own screens are unlocked right now. It lives only in memory on purpose:
 * a restart, or Android closing the app, always brings the lock screen back.
 */
object LockSession {

    /** Compose reads this, so the lock screen appears the moment it becomes false. */
    var unlocked by mutableStateOf(false)
        private set

    private var leftAt = 0L
    private var leftViaOwnLaunch = false
    private var ownLaunchAt = 0L

    fun unlock() {
        unlocked = true
        // The unlock may arrive while the app is in the background (the trusted phone answered
        // late). Forget that departure, otherwise coming back would lock the app again at once
        // and the screen would stay on "Opening..." forever.
        leftAt = 0L
        leftViaOwnLaunch = false
    }

    fun lockNow() {
        unlocked = false
    }

    /** Call right before the app opens a system screen itself (permission pages, device admin). */
    fun markOwnLaunch() {
        ownLaunchAt = SystemClock.elapsedRealtime()
    }

    /** Activity.onStop (not for rotation). */
    fun onLeft() {
        val now = SystemClock.elapsedRealtime()
        leftAt = now
        leftViaOwnLaunch = ownLaunchAt != 0L && now - ownLaunchAt <= LockRules.INTERNAL_LAUNCH_WINDOW_MS
    }

    /** Activity.onStart. Locks again when the app was away long enough. */
    fun onReturned(enabled: Boolean, graceSeconds: Int) {
        if (!unlocked || leftAt == 0L) return
        val away = SystemClock.elapsedRealtime() - leftAt
        if (LockRules.shouldRelock(enabled, unlocked, away, graceSeconds, leftViaOwnLaunch)) {
            unlocked = false
        }
        leftAt = 0L
        leftViaOwnLaunch = false
    }
}
