package com.focusmode.app.data.auth

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Local copy of "who is logged in", so the UI knows at once and offline. Firebase Auth keeps the real
 * session (and its tokens) in its own storage; this holds only uid, name, email and provider. No password
 * and no token is ever written here. allowBackup is off, so none of it leaves the phone through a backup.
 */
class AuthStore private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("auth_session", Context.MODE_PRIVATE)

    private val _session = MutableStateFlow(read())
    val session: StateFlow<AuthSession> = _session.asStateFlow()

    private fun read(): AuthSession {
        val uid = prefs.getString(K_UID, null)?.takeIf { it.isNotBlank() } ?: return AuthSession.SignedOut
        return AuthSession.SignedIn(
            AuthUser(
                uid = uid,
                name = prefs.getString(K_NAME, null).orEmpty(),
                email = prefs.getString(K_EMAIL, null).orEmpty(),
                provider = AuthProvider.fromId(prefs.getString(K_PROVIDER, null)),
                emailVerified = prefs.getBoolean(K_VERIFIED, false),
            )
        )
    }

    fun save(user: AuthUser) {
        prefs.edit()
            .putString(K_UID, user.uid)
            .putString(K_NAME, user.name)
            .putString(K_EMAIL, user.email)
            .putString(K_PROVIDER, user.provider.name)
            .putBoolean(K_VERIFIED, user.emailVerified)
            .commit()
        _session.value = read()
    }

    fun clear() {
        prefs.edit().clear().commit()
        _session.value = AuthSession.SignedOut
    }

    companion object {
        private const val K_UID = "uid"
        private const val K_NAME = "name"
        private const val K_EMAIL = "email"
        private const val K_PROVIDER = "provider"
        private const val K_VERIFIED = "verified"

        @Volatile private var instance: AuthStore? = null

        fun get(context: Context): AuthStore =
            instance ?: synchronized(this) {
                instance ?: AuthStore(context.applicationContext).also { instance = it }
            }
    }
}
