package com.focusmode.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/** One result card read from YouTube's own search page (what the page shows, nothing more). */
data class WebCard(val id: String, val title: String, val text: String, val durationLabel: String) {
    /** Length in seconds from a label like "12:34" or "1:02:03"; 0 when there is none (a live stream has none). */
    val seconds: Int get() = StudyWeb.parseDurationLabel(durationLabel)
}

/** The answer for a batch of cards: ids to show and ids to hide. */
data class WebVerdict(val allowed: List<String>, val denied: List<String>)

/**
 * Web search backup of the Study section. When the free daily YouTube limit is used up, a search is read from YouTube's own mobile search page inside LockDistra, and every result
 * still has to pass the Study rules before it is shown. No Android classes, so it is unit tested on the JVM.
 *
 *  - With the API available the result is checked exactly like a normal search (Education category, trusted channels,
 *    distraction words, not a Short). That costs 1 unit per 50 videos, a search costs 100.
 *  - Without the API (limit used up) only what the page shows is known, so a card must also look like study content.
 */
object StudyWeb {
    /** "Video" filter of YouTube's search (no channels, playlists or movies). */
    private const val VIDEOS_ONLY = "EgIQAQ%253D%253D"

    /** Words added to a search that has no study word of its own, so YouTube ranks lessons first ("newton" -> "newton lecture explained"). */
    private const val STUDY_BIAS = " lecture explained"

    /** What is really asked from YouTube: the typed text, plus lesson words when it has none (the box still shows what was typed). */
    fun biasedQuery(query: String): String {
        val q = query.trim()
        return if (q.isEmpty() || hasStudySignal(q)) q else q + STUDY_BIAS
    }

    fun searchUrl(query: String): String =
        "https://m.youtube.com/results?search_query=" + URLEncoder.encode(biasedQuery(query), "UTF-8") + "&sp=" + VIDEOS_ONLY + "&hl=en&gl=IN"

    /** The 11 character id of a /watch?v=... address (relative or full), or "" when it is not one. */
    fun videoIdFromUrl(url: String?): String {
        if (url.isNullOrBlank()) return ""
        val m = Regex("[?&]v=([A-Za-z0-9_-]{11})(?:[&#]|$)").find(url) ?: return ""
        return if (url.contains("/watch")) m.groupValues[1] else ""
    }

    fun isVideoId(id: String?): Boolean = id != null && Regex("^[A-Za-z0-9_-]{11}$").matches(id)

    /** Hosts the page may use besides the search itself (cookie / consent screens). */
    private fun isConsentHost(host: String): Boolean =
        host.startsWith("consent.") && (host.endsWith("youtube.com") || host.endsWith("google.com"))

    /**
     * True for an address the web search may show: YouTube's search results page and its consent screen. Everything
     * else (home, channels, Shorts, a video page, other sites) is refused, so the person can never wander off.
     */
    fun isAllowedPage(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val m = Regex("^https://([^/?#:]+)(/[^?#]*)?").find(url) ?: return false
        val host = m.groupValues[1].lowercase()
        val path = m.groupValues[2]
        if (isConsentHost(host)) return true
        val yt = host == "m.youtube.com" || host == "www.youtube.com" || host == "youtube.com"
        return yt && (path == "/results" || path == "/results/")
    }

    /** "12:34" -> 754, "1:02:03" -> 3723, anything else -> 0. */
    fun parseDurationLabel(label: String?): Int {
        val m = Regex("^(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})$").matchEntire(label?.trim().orEmpty()) ?: return 0
        val h = m.groupValues[1].toIntOrNull() ?: 0
        return h * 3600 + m.groupValues[2].toInt() * 60 + m.groupValues[3].toInt()
    }

    /** The batch the page sends: `[{"id","title","text","dur"}]`. Bad ids and repeats are dropped, sizes are capped. */
    fun parseCards(json: String?, max: Int = 60): List<WebCard> = try {
        val arr = JSONArray(json ?: "[]")
        val seen = HashSet<String>()
        (0 until minOf(arr.length(), max)).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val id = o.optString("id")
            if (!isVideoId(id) || !seen.add(id)) null
            else WebCard(id, o.optString("title").take(200), o.optString("text").take(400), o.optString("dur").take(12))
        }
    } catch (e: Exception) {
        emptyList()
    }

    /** `{"ok":[...],"no":[...]}` for the page script. Ids are validated, so the text is safe to put in a script. */
    fun verdictJson(v: WebVerdict): String =
        JSONObject().put("ok", JSONArray(v.allowed.filter { isVideoId(it) })).put("no", JSONArray(v.denied.filter { isVideoId(it) })).toString()

    // ---- study signals (used only when the API cannot confirm the category) ----

    private val STUDY_WORDS = listOf(
        "class", "chapter", "lecture", "lesson", "tutorial", "explained", "explanation", "ncert", "cbse", "icse", "notes",
        "formula", "formulas", "solution", "solutions", "revision", "concept", "concepts", "basics", "exam", "exams", "board",
        "jee", "neet", "ssc", "upsc", "syllabus", "full course", "one shot", "oneshot", "mcq", "pyq", "theorem", "numerical",
        "numericals", "derivation", "grammar", "vocabulary", "science", "maths", "math", "mathematics", "physics", "chemistry",
        "biology", "history", "geography", "civics", "economics", "polity", "hindi", "english", "sanskrit", "computer",
        "coding", "programming", "python", "algebra", "geometry", "trigonometry", "calculus", "equation", "equations",
        "lecture series", "course", "study", "learn", "learning", "topic", "unit",
    )

    /** Hindi study words, matched inside the raw text (Hindi letters carry marks that a word split would cut). */
    private val STUDY_WORDS_HI = listOf(
        "कक्षा", "अध्याय", "पाठ", "गणित", "विज्ञान", "भौतिक", "रसायन", "जीव विज्ञान", "इतिहास", "भूगोल", "नागरिक", "अर्थशास्त्र", "हिंदी",
        "हिन्दी", "अंग्रेजी", "व्याकरण", "परीक्षा", "नोट्स", "सूत्र",
    )

    private fun latinWords(text: String): String =
        " " + text.lowercase().map { if (it in 'a'..'z' || it in '0'..'9' || it == '+') it else ' ' }.joinToString("").replace(Regex("\\s+"), " ").trim() + " "

    /** True when [text] has a typical study word (English or Hindi). */
    fun hasStudySignal(text: String): Boolean {
        val w = latinWords(text)
        if (STUDY_WORDS.any { w.contains(" $it ") }) return true
        val raw = text.lowercase()
        return STUDY_WORDS_HI.any { raw.contains(it) }
    }

    /** A search that is itself about studying (a subject chip, "ohm's law class 10"): its results are mostly study. */
    fun isStudyQuery(query: String, subjects: List<String>): Boolean {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return false
        if (subjects.any { it.trim().equals(q, ignoreCase = true) }) return true
        return hasStudySignal(q)
    }

    /** True when the card title has a real word (4+ letters, or Hindi) of the search, so the result is about what was asked. */
    fun sharesQueryWord(title: String, query: String): Boolean {
        val low = title.lowercase()
        val generic = setOf("class", "video", "videos", "chapter", "lecture", "lesson", "full", "complete", "with", "from", "that", "this", "what", "your")
        return query.lowercase().split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).any { t ->
            val hindi = t.any { it.code > 0x7F }
            (if (hindi) t.length >= 2 else t.length >= 4 && t !in generic) && low.contains(t)
        }
    }

    /**
     * The decision when the API could not be asked: never a "never" word, never a Short, and either a trusted channel's
     * name is on the card, or there is no distraction word and the card is about studying. A card with no study word of its
     * own passes only when the search itself is a study search AND the card's title has a word of that search ([query]; with
     * no query given, a study search is enough).
     */
    fun looseAccept(card: WebCard, queryIsStudy: Boolean, trustedNames: List<String>, query: String = ""): Boolean {
        val all = card.title + " " + card.text
        if (StudyRules.hasNeverWord(all)) return false
        if (card.seconds in 1..StudyRules.SHORT_MAX_SECONDS) return false
        val low = all.lowercase()
        if (trustedNames.any { it.length >= 3 && low.contains(it.lowercase()) }) return true
        if (StudyRules.hasDistractionWord(all)) return false
        if (hasStudySignal(all)) return true
        return queryIsStudy && (query.isBlank() || sharesQueryWord(card.title, query))
    }

    /**
     * Decides every card. [details] holds what the API knew about them ([apiWorked] = it could be asked at all): then the
     * normal rules decide, and a video the API does not know (private, removed) is hidden. Otherwise [looseAccept].
     */
    fun judge(
        cards: List<WebCard>,
        details: Map<String, StudyVideo>,
        apiWorked: Boolean,
        trusted: Set<String>,
        watched: Set<String>,
        trustedNames: List<String>,
        queryIsStudy: Boolean,
        query: String = "",
    ): WebVerdict {
        val ok = ArrayList<String>()
        val no = ArrayList<String>()
        for (c in cards) {
            val pass = if (apiWorked) {
                val v = details[c.id]
                v != null && !v.isShort && StudyRules.accept(v, trusted, watched)
            } else {
                looseAccept(c, queryIsStudy, trustedNames, query)
            }
            if (pass) ok += c.id else no += c.id
        }
        return WebVerdict(ok, no)
    }

    /** A video to play when the API never described it: only what the page showed. */
    fun minimalVideo(id: String, title: String, durationLabel: String): StudyVideo =
        StudyVideo(
            id = id, title = title.ifBlank { "Study video" }, channelId = "", channelTitle = "",
            thumbUrl = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
            seconds = parseDurationLabel(durationLabel), categoryId = "", embeddable = true,
        )
}
