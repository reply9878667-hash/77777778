package com.focusmode.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.core.app.NotificationManagerCompat
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.FocusControl
import com.focusmode.app.data.FocusOffMethod
import com.focusmode.app.data.FocusOffRules
import com.focusmode.app.data.LockState
import com.focusmode.app.data.StudyCheckInRules
import com.focusmode.app.data.online.OnlineState
import com.focusmode.app.data.FocusState
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.theme.FocusTheme

private data class ControlInfo(
    val control: FocusControl,
    val title: String,
    /** Shown while the action is allowed. */
    val allowedText: String,
    /** Shown once it is switched off. */
    val blockedText: String,
)

private val controlInfos = listOf(
    ControlInfo(
        FocusControl.TURN_OFF,
        "Allow turning LockDistra OFF",
        "You can end the session early",
        "Ends only when the timer finishes"
    ),
    ControlInfo(
        FocusControl.SETTINGS,
        "Allow changing LockDistra settings",
        "Reminders and protection switches can change",
        "Settings are frozen until the session ends"
    ),
    ControlInfo(
        FocusControl.EMERGENCY,
        "Allow Emergency access",
        "Emergency apps can be opened within their limits",
        "Emergency access is off, including its notification shortcut"
    ),
    ControlInfo(
        FocusControl.APP_CHANGES,
        "Allow app restriction changes",
        "Blocked apps, limits and emergency apps can change",
        "Blocked apps, limits and emergency apps are frozen"
    ),
    ControlInfo(
        FocusControl.OTHER_BYPASS,
        "Allow other bypass methods",
        "App info, uninstall, device admin and Accessibility pages stay open",
        "Those system screens are guarded during the session"
    ),
)

private val visibleControls: List<ControlInfo>
    get() = controlInfos.filter {
        it.control != FocusControl.OTHER_BYPASS || com.focusmode.app.data.SafetyConfig.UNINSTALL_PROTECTION
    }

private fun FocusState.allowed(control: FocusControl): Boolean = when (control) {
    FocusControl.TURN_OFF -> allowTurnOff
    FocusControl.SETTINGS -> allowSettingsChange
    FocusControl.EMERGENCY -> allowEmergency
    FocusControl.APP_CHANGES -> allowAppChanges
    FocusControl.OTHER_BYPASS -> allowOtherBypass
}

/**
 * The settings section shown right under the LockDistra ring while a session runs.
 *
 * Each switch means "this is allowed". During a session a switch can only be turned off:
 * once something is locked it stays locked until the session ends, and after "changing
 * settings" is switched off nothing here can change at all.
 */
@Composable
fun FocusControlsCard(
    state: FocusState,
    onChange: (FocusControl, Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    var expanded by remember { mutableStateOf(true) }
    var pending by remember { mutableStateOf<ControlInfo?>(null) }

    FocusCard(
        modifier = modifier.animateContentSize(),
        padding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Column {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                    .clickable { expanded = !expanded },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Tune, null, tint = c.accent, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Focus controls", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "What stays possible during this session",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
                Icon(
                    if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    if (expanded) "Hide" else "Show",
                    tint = c.muted
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column {
                    Spacer(Modifier.height(8.dp))
                    visibleControls.forEach { info ->
                        val allowed = state.allowed(info.control)
                        // Only "allowed -> not allowed" is possible, and only while settings are open.
                        val noEndToLock = info.control == FocusControl.TURN_OFF && state.sessionEnd == 0L
                        val canSwitchOff = allowed && state.allowSettingsChange && !noEndToLock
                        ControlRow(
                            title = info.title,
                            subtitle = when {
                                noEndToLock -> "A session with no time limit can always be ended"
                                allowed -> info.allowedText
                                else -> info.blockedText
                            },
                            allowed = allowed,
                            enabled = canSwitchOff,
                            onToggle = { pending = info }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "A switch that is turned off stays off until the session ends. These locks cover LockDistra and the system screens it can guard. Android itself still allows powering off or restarting the phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
            }
        }
    }

    pending?.let { info ->
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Switch this off?", style = MaterialTheme.typography.titleLarge) },
            text = {
                Text(
                    "${info.title}: ${info.blockedText.replaceFirstChar { it.lowercase() }}. " +
                        "You won't be able to switch it back on until this session ends."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onChange(info.control, false)
                    pending = null
                }) { Text("Switch off", color = c.warning) }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text("Keep allowed", color = c.accent) }
            }
        )
    }
}

/**
 * The same five switches as free defaults, shown in Settings between sessions. They are
 * applied from the next session on; during a session use the card under the ring.
 */
@Composable
fun FocusControlDefaultsCard(
    state: FocusState,
    onChange: (FocusControl, Boolean) -> Unit,
) {
    val c = FocusTheme.colors
    FocusCard(padding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)) {
        Column {
            visibleControls.forEach { info ->
                val allowed = state.allowed(info.control)
                ControlRow(
                    title = info.title,
                    subtitle = if (allowed) info.allowedText else info.blockedText,
                    allowed = allowed,
                    enabled = !state.focusActive,
                    onToggle = { onChange(info.control, !allowed) }
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                if (state.focusActive) "Locked while a session is running. Use Focus controls on the home screen to lock more."
                else "Used for every new session. A session with no time limit can always be ended, so it ignores the first switch.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
        }
    }
}

/**
 * The same five switches inside the start wizard (before a session begins). They are the free defaults, so a
 * switch can be changed here; a session with no time limit can always be ended, so that first switch is fixed.
 */
@Composable
fun FocusControlSwitches(
    state: FocusState,
    noEndSession: Boolean,
    onChange: (FocusControl, Boolean) -> Unit,
) {
    Column {
        visibleControls.forEach { info ->
            val allowed = state.allowed(info.control)
            val noEndToLock = info.control == FocusControl.TURN_OFF && noEndSession
            ControlRow(
                title = info.title,
                subtitle = when {
                    noEndToLock -> "A session with no time limit can always be ended"
                    allowed -> info.allowedText
                    else -> info.blockedText
                },
                allowed = allowed,
                enabled = !state.focusActive && !noEndToLock,
                onToggle = { onChange(info.control, !allowed) }
            )
        }
    }
}

/**
 * Settings > Focus: how Focus Mode may be turned OFF. Normal Button (default), Password (the existing App lock)
 * or Online Approval (the existing trusted phone). A method that is not set up yet is not selected; the note
 * says what to set up, using the existing sections of this screen. Locked while a session runs.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FocusOffMethodCard(
    state: FocusState,
    lock: LockState,
    online: OnlineState,
    onlineConfigured: Boolean,
    onSelect: (FocusOffMethod) -> Boolean,
) {
    val c = FocusTheme.colors
    var note by remember { mutableStateOf<String?>(null) }

    fun errorFor(m: FocusOffMethod) =
        FocusOffRules.setupError(m, lock.enabled, online.phoneConnected, online.hasRecovery, onlineConfigured)

    val canChange = FocusOffRules.canChange(state.focusActive, state.canChangeFocusSettings)
    val chosenError = errorFor(state.offMethod)

    FocusCard(padding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)) {
        Column {
            Text("Turn OFF method", style = MaterialTheme.typography.titleMedium)
            Text(
                "How Focus Mode can be turned OFF",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            Spacer(Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FocusOffMethod.entries.forEach { m ->
                    SoftChip(m.label, state.offMethod == m, {
                        note = null
                        when {
                            m == state.offMethod -> Unit
                            !canChange -> note = "Locked while a focus session is running."
                            else -> {
                                val error = errorFor(m)
                                if (error != null) note = error
                                else if (!onSelect(m)) note = "Couldn't change it right now."
                            }
                        }
                    })
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                when (state.offMethod) {
                    FocusOffMethod.NORMAL -> "Focus Mode turns OFF with the normal End button."
                    FocusOffMethod.PASSWORD -> "Focus Mode turns OFF only after you enter your PIN / password (App lock)."
                    FocusOffMethod.ONLINE -> "Focus Mode turns OFF only after your trusted phone approves the request."
                },
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            if (chosenError != null) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "$chosenError Until then Focus Mode cannot be started with this method.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.warning
                )
            }
            note?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
        }
    }
}

@Composable
private fun ControlRow(
    title: String,
    subtitle: String,
    allowed: Boolean,
    enabled: Boolean,
    onToggle: () -> Unit,
) {
    val c = FocusTheme.colors
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = if (allowed) c.muted else c.warning
            )
        }
        FocusSwitch(
            checked = allowed,
            enabled = enabled,
            onCheckedChange = { onToggle() }
        )
    }
}

/**
 * Settings > Focus: Study Check-In Interval. While Focus Mode is ON, LockDistra asks "Are You Still Studying?" at this
 * interval. Off by default. Locked while a session runs, like the OFF method, so it cannot be switched off mid-session.
 * [onlineOffActive] = Online Approval is how Focus Mode turns OFF right now (only then is the trusted phone alerted).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudyCheckInCard(
    state: FocusState,
    onlineOffActive: Boolean,
    onSelect: (Int) -> Boolean,
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    var note by remember { mutableStateOf<String?>(null) }
    var customOpen by remember { mutableStateOf(false) }
    var customValue by remember(state.studyMin) {
        mutableStateOf(if (StudyCheckInRules.isCustom(state.studyMin)) state.studyMin else 20)
    }
    val canChange = StudyCheckInRules.canChange(state.focusActive, state.canChangeFocusSettings)
    val customSelected = customOpen || StudyCheckInRules.isCustom(state.studyMin)

    fun choose(minutes: Int) {
        note = null
        when {
            !canChange -> note = "Locked while a focus session is running."
            !onSelect(minutes) -> note = "Couldn't change it right now."
        }
    }

    FocusCard(padding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)) {
        Column {
            Text("Study Check-In Interval", style = MaterialTheme.typography.titleMedium)
            Text(
                "How often LockDistra asks \"Are You Still Studying?\" while Focus Mode is ON",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            Spacer(Modifier.height(12.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SoftChip("Off", state.studyMin == 0 && !customOpen, { customOpen = false; choose(StudyCheckInRules.OFF) })
                StudyCheckInRules.PRESETS.forEach { m ->
                    SoftChip("Every $m minutes", state.studyMin == m && !customOpen, { customOpen = false; choose(m) })
                }
                SoftChip("Custom", customSelected, {
                    note = null
                    if (!canChange) note = "Locked while a focus session is running."
                    else customOpen = true
                })
            }
            if (customSelected && canChange) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SoftChip("-5", false, { customValue = StudyCheckInRules.clamp(customValue - 5).coerceAtLeast(StudyCheckInRules.MIN_CUSTOM) })
                    SoftChip("-1", false, { customValue = StudyCheckInRules.clamp(customValue - 1).coerceAtLeast(StudyCheckInRules.MIN_CUSTOM) })
                    Text("$customValue min", style = MaterialTheme.typography.titleMedium)
                    SoftChip("+1", false, { customValue = StudyCheckInRules.clamp(customValue + 1) })
                    SoftChip("+5", false, { customValue = StudyCheckInRules.clamp(customValue + 5) })
                    SoftChip("Set", state.studyMin == customValue, { choose(customValue); customOpen = false })
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                if (state.studyMin == 0) {
                    "No check-ins. Choose an interval to be asked while you study."
                } else {
                    "Every ${state.studyMin} minutes LockDistra asks \"Are You Still Studying?\" on top of whatever you are doing. " +
                        "You have 1 minute to tap \"I'm Studying\"."
                },
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            if (state.studyMin > 0) {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (onlineOffActive) {
                        "If you do not answer in time, your trusted phone gets an alert to check on you. Focus Mode stays ON."
                    } else {
                        "Your trusted phone is only alerted when the Turn OFF method is Online Approval."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Notifications are off for LockDistra, so check-ins cannot be shown. Turn them on in the phone's settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.warning
                    )
                }
            }
            note?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
        }
    }
}
