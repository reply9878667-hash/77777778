package com.focusmode.app.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/** The notification the person gets when Auto Focus turns Focus Mode on by itself (or could not). */
object AutoFocusNotifier {
    private const val CHANNEL = "auto_focus"
    private const val ID_STARTED = 7101
    private const val ID_FAILED = 7102

    fun started(context: Context, endText: String) =
        post(context, ID_STARTED, "Auto Focus started", "Focus Mode is on until $endText.")

    fun couldNotStart(context: Context) =
        post(context, ID_FAILED, "Auto Focus couldn't start", "Allow LockDistra's Accessibility access, then it works from the next window.")

    private fun post(context: Context, id: Int, title: String, text: String) {
        val nm = NotificationManagerCompat.from(context)
        // Without the notification permission there is nothing to show; the in-app toast still appears.
        if (!nm.areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Auto Focus", NotificationManager.IMPORTANCE_DEFAULT)
            context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val open = context.packageManager.getLaunchIntentForPackage(context.packageName)?.let {
            PendingIntent.getActivity(context, id, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(context.applicationInfo.icon)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            nm.notify(id, n)
        } catch (_: SecurityException) {
            // Notification permission was revoked between the check and the call: ignore.
        }
    }
}
