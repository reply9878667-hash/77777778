package com.focusmode.app.service

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.animation.ValueAnimator
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.focusmode.app.data.TimerLock
import com.focusmode.app.data.TimerStyle
import com.focusmode.app.data.UsageLimitStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Floating timer for a limited app. It is an accessibility overlay window owned by
 * [AppBlockerService], so it needs no extra permission.
 *
 * Two modes, chosen in Usage limits:
 *  - ALWAYS ([show]): the pill stays on screen for as long as the limited app is in front. It is
 *    re-attached by itself if Android ever removes the window, so it cannot silently vanish.
 *    It can be dragged, and shrunk to a small circle by tapping it or dragging it to an edge.
 *  - EVERY N MIN ([popup]): the service counts active use of the app and calls [popup] each time
 *    N minutes are used up. The pill slides in from the screen edge, stays a few seconds and
 *    slides out again. Nothing is on screen in between, and nothing needs to be tapped.
 *
 * The overlay never decides *when* a popup is due: [AppBlockerService] owns that counter, so
 * recreating or hiding the window (switching apps, screen off) cannot reset or skip a schedule.
 */
class TimerOverlay(private val context: Context) {

    private enum class Mode { NONE, ALWAYS, PERIODIC }

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = context.getSharedPreferences("timer_overlay", Context.MODE_PRIVATE)
    private val handler = Handler(Looper.getMainLooper())
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    private var root: LinearLayout? = null
    private var icon: ImageView? = null
    private var text: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var shownFor: String? = null
    private var mode = Mode.NONE

    // Layout state (remembered between launches).
    /** What the person chose for ALWAYS mode (pill or circle). Periodic popups are always a pill. */
    private var alwaysCircle = prefs.getBoolean(K_CIRCLE, false)
    private var circle = alwaysCircle

    // Position, exactly as the person left it. Nothing but a manual drag ever changes these.
    //  - hasPos:    false only until the very first drag (then the pill starts centred at the top).
    //  - edgeRight: which side of the screen the window is measured from (the half it was dropped in),
    //               so a pill whose text gets longer or shorter grows away from that edge instead of
    //               being pushed back on screen.
    //  - gapX:      distance in px from that screen edge to the window.
    //  - topY:      distance in px from the top of the screen to the window.
    private var hasPos = prefs.getBoolean(K_HAS_POS, false)
    private var edgeRight = prefs.getBoolean(K_EDGE_RIGHT, false)
    private var gapX = prefs.getInt(K_GAP_X, 0)
    private var topY = prefs.getInt(K_TOP_Y, dp(44))

    // Look chosen in Usage limits, and the anti-accidental-move lock. A timer that was never placed
    // starts unlocked (so it can be put where the person wants); after that it starts locked.
    private var style = TimerStyle.CLASSIC
    private var shownStyle: TimerStyle? = null
    private lateinit var lock: TimerLock
    private var lockedMoveSeen = false

    private var lastMs = 0L
    private var shownLabel = ""
    private var dragging = false
    private var animating = false
    private var slideAnim: ValueAnimator? = null

    init {
        // Older versions saved anchor / x / y. Keep a position the person had set there.
        if (!hasPos && prefs.contains(K_ANCHOR)) {
            when (prefs.getInt(K_ANCHOR, CENTER)) {
                LEFT -> { hasPos = true; edgeRight = false; gapX = if (alwaysCircle) 0 else dp(8) }
                RIGHT -> { hasPos = true; edgeRight = true; gapX = if (alwaysCircle) 0 else dp(8) }
                FREE -> { hasPos = true; edgeRight = false; gapX = prefs.getInt(K_X, 0).coerceAtLeast(0) }
            }
            if (hasPos) {
                topY = prefs.getInt(K_Y, dp(44)).coerceAtLeast(0)
                save()
            }
        }
    }

    private fun ensureLock(): TimerLock {
        if (!::lock.isInitialized) lock = TimerLock(prefs.getBoolean(K_LOCKED, hasPos))
        return lock
    }

    private val lockRunnable = Runnable {
        val l = ensureLock()
        if (!l.locked && !dragging && !animating) {
            l.lockNow()
            saveLock()
        }
    }

    /** Locks the timer after 5 s without a touch. Called whenever it appears or a finger leaves it. */
    private fun scheduleLock() {
        handler.removeCallbacks(lockRunnable)
        if (!ensureLock().locked) handler.postDelayed(lockRunnable, TimerLock.IDLE_LOCK_MS)
    }

    private fun saveLock() {
        prefs.edit().putBoolean(K_LOCKED, ensureLock().locked).apply()
        writePerApp()
    }

    // ---- One position per app ---------------------------------------------------------------
    // Every limited app remembers its own place, size (pill / circle) and lock. An app that was never placed starts
    // where the last placed one was (the global values), and from its first drag on it has its own.

    private fun appKey(pkg: String) = "pos_$pkg"

    /** Loads the saved layout of [pkg] into the working fields. Called each time the timer is built for an app. */
    private fun loadPositionFor(pkg: String) {
        val parts = prefs.getString(appKey(pkg), null)?.split(",")
        if (parts != null && parts.size >= 6) {
            hasPos = parts[0] == "1"
            edgeRight = parts[1] == "1"
            gapX = parts[2].toIntOrNull() ?: 0
            topY = parts[3].toIntOrNull() ?: dp(44)
            alwaysCircle = parts[4] == "1"
            lock = TimerLock(parts[5] == "1")
        } else {
            // Never placed in this app: the shared default (last placed position), unlocked until it is placed.
            hasPos = prefs.getBoolean(K_HAS_POS, false)
            edgeRight = prefs.getBoolean(K_EDGE_RIGHT, false)
            gapX = prefs.getInt(K_GAP_X, 0)
            topY = prefs.getInt(K_TOP_Y, dp(44))
            alwaysCircle = prefs.getBoolean(K_CIRCLE, false)
            lock = TimerLock(prefs.getBoolean(K_LOCKED, hasPos))
        }
    }

    private fun writePerApp() {
        val pkg = shownFor ?: return
        val v = listOf(hasPos, edgeRight, gapX, topY, alwaysCircle, ensureLock().locked).map {
            when (it) { true -> "1"; false -> "0"; else -> it.toString() }
        }.joinToString(",")
        prefs.edit().putString(appKey(pkg), v).apply()
    }

    /** No on-screen text any more (no hints/suggestions); only a short vibration when asked. */
    private fun feedback(buzz: Boolean = false) {
        if (!buzz) return
        try {
            @Suppress("DEPRECATION")
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            v?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    private val dismissRunnable = Runnable { if (mode == Mode.PERIODIC && !dragging) slideOutAndHide() }

    private fun dp(v: Int) = (v * context.resources.displayMetrics.density).toInt()
    private fun screenW() = context.resources.displayMetrics.widthPixels
    private fun screenH() = context.resources.displayMetrics.heightPixels

    /** True while a timer window is attached to the screen. */
    fun isShowing(): Boolean = root?.isAttachedToWindow == true

    /** ALWAYS mode. Safe to call every second: it creates, re-attaches and refreshes as needed. */
    fun show(pkg: String, label: String, remainingMs: Long) {
        lastMs = remainingMs
        shownLabel = label
        if (mode == Mode.PERIODIC) hide()
        val view = root
        val wantedStyle = TimerStyle.fromId(UsageLimitStore.get(context).floatingStyleId())
        val healthy = view != null && shownFor == pkg && mode == Mode.ALWAYS && view.isAttachedToWindow &&
            shownStyle == wantedStyle
        if (!healthy) {
            // Not there, wrong app, a new design was chosen, or Android dropped the window: build it again.
            val brandNew = view == null || shownFor != pkg || mode != Mode.ALWAYS || shownStyle != wantedStyle
            if (view != null && !brandNew && !view.isAttachedToWindow && System.nanoTime() - createdAt < ATTACH_GRACE_NS) {
                return // just added; the window needs a moment to attach
            }
            hide()
            mode = Mode.ALWAYS
            loadPositionFor(pkg)
            circle = alwaysCircle
            if (!create(pkg, slideIn = false)) mode = Mode.NONE
            return
        }
        refreshText()
    }

    /** Periodic mode: slide the pill in now, and slide it out again after a few seconds. */
    fun popup(pkg: String, label: String, remainingMs: Long) {
        lastMs = remainingMs
        shownLabel = label
        hide()
        mode = Mode.PERIODIC
        loadPositionFor(pkg)
        circle = false
        if (!create(pkg, slideIn = true)) {
            mode = Mode.NONE
            return
        }
        handler.postDelayed(dismissRunnable, PEEK_MS)
    }

    /** Called while the periodic mode is selected: a leftover always-on pill must not stay. */
    fun ensurePeriodic() {
        if (mode == Mode.ALWAYS) hide()
    }

    /** Keeps the time on a popup that is currently on screen up to date. */
    fun update(remainingMs: Long) {
        lastMs = remainingMs
        if (mode == Mode.PERIODIC && root != null) refreshText()
    }

    fun hide() {
        // If the window disappears mid-drag (app switch, screen off), keep where it was dropped.
        if (dragging) {
            val dv = root
            val dlp = params
            if (dv != null && dlp != null && !animating) {
                capturePosition(dv, dlp)
                save()
            }
        }
        handler.removeCallbacks(dismissRunnable)
        handler.removeCallbacks(lockRunnable)
        slideAnim?.cancel()
        slideAnim = null
        animating = false
        shownStyle = null
        val view = root
        root = null
        icon = null
        text = null
        params = null
        shownFor = null
        mode = Mode.NONE
        dragging = false
        if (view != null) {
            try {
                wm.removeViewImmediate(view)
            } catch (_: Exception) {
            }
        }
    }

    private var createdAt = 0L

    // ---- Creation -------------------------------------------------------------------------

    private fun create(pkg: String, slideIn: Boolean): Boolean {
        style = TimerStyle.fromId(UsageLimitStore.get(context).floatingStyleId())
        val iconView = ImageView(context).apply {
            runCatching { setImageDrawable(context.packageManager.getApplicationIcon(pkg)) }
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) }
        }
        val textView = TextView(context).apply {
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            maxLines = 1
        }
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            elevation = dp(6).toFloat()
            addView(iconView)
            addView(textView)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        container.setOnTouchListener(touchListener())
        styleFor(container, iconView, textView)
        textView.text = if (circle) compactText(lastMs) else pillText(lastMs, shownLabel)
        place(container, lp)
        val targetX = lp.x
        val targetY = lp.y
        if (slideIn) offscreen(container, lp)
        try {
            wm.addView(container, lp)
        } catch (_: Exception) {
            return false
        }
        root = container
        icon = iconView
        text = textView
        params = lp
        shownFor = pkg
        shownStyle = style
        createdAt = System.nanoTime()
        scheduleLock()
        if (slideIn) slide(container, lp, targetX, targetY, entering = true)
        return true
    }

    // ---- Slide animation ------------------------------------------------------------------

    /** Moves the window itself (a view cannot slide outside its own window), edge -> resting place. */
    private fun slideSide() = when {
        !hasPos -> 1 // never moved: slides down from the top, as before
        edgeRight -> 2
        else -> 0
    }

    /** Puts the window just outside the screen edge it will slide in from. */
    private fun offscreen(v: View, lp: WindowManager.LayoutParams) {
        when (slideSide()) {
            0 -> lp.x = -v.measuredWidth
            1 -> lp.y = -v.measuredHeight
            else -> lp.x = screenW()
        }
    }

    private fun slide(
        v: View,
        lp: WindowManager.LayoutParams,
        tx: Int,
        ty: Int,
        entering: Boolean,
        onEnd: (() -> Unit)? = null,
    ) {
        slideAnim?.cancel()
        val w = v.measuredWidth
        val h = v.measuredHeight
        val sw = screenW()
        val from = slideSide()
        animating = true
        val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (entering) SLIDE_IN_MS else SLIDE_OUT_MS
            interpolator = if (entering) DecelerateInterpolator(1.6f) else AccelerateInterpolator(1.4f)
            addUpdateListener {
                val raw = it.animatedValue as Float
                val t = if (entering) raw else 1f - raw // t = 1 is "fully in"
                when (from) {
                    0 -> lp.x = (-w + (tx + w) * t).toInt()
                    1 -> lp.y = (-h + (ty + h) * t).toInt()
                    else -> lp.x = (sw + (tx - sw) * t).toInt()
                }
                if (root === v) {
                    try {
                        wm.updateViewLayout(v, lp)
                    } catch (_: Exception) {
                    }
                }
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: android.animation.Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (slideAnim === animation) slideAnim = null
                    if (cancelled) return
                    animating = false
                    if (entering) {
                        lp.x = tx
                        lp.y = ty
                        if (root === v) {
                            try {
                                wm.updateViewLayout(v, lp)
                            } catch (_: Exception) {
                            }
                        }
                    }
                    onEnd?.invoke()
                }
            })
        }
        slideAnim = anim
        anim.start()
    }

    private fun slideOutAndHide() {
        val v = root ?: return
        val lp = params ?: return
        handler.removeCallbacks(dismissRunnable)
        place(v, lp)
        slide(v, lp, lp.x, lp.y, entering = false) { if (root === v) hide() }
    }

    // ---- Look -----------------------------------------------------------------------------

    private fun styleFor(container: LinearLayout, iconView: ImageView, textView: TextView) {
        val low = lastMs in 1..59_999L
        if (circle) {
            container.orientation = LinearLayout.HORIZONTAL
            container.background = GradientDrawable().apply {
                cornerRadius = dp(23).toFloat()
                setColor(Color.parseColor("#E61A1138"))
                setStroke(dp(if (low) 2 else 1), if (low) Color.parseColor("#FFB35E") else Color.parseColor("#66C044FF"))
            }
            iconView.visibility = View.GONE
            textView.textSize = 11f
            textView.setShadowLayer(0f, 0f, 0f, 0)
            container.setPadding(0, 0, 0, 0)
            container.minimumWidth = dp(46)
            container.minimumHeight = dp(46)
        } else {
            val st = style
            container.orientation = if (st.stacked) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            container.background = if (st.hasBox) GradientDrawable().apply {
                cornerRadius = dp(if (st.stacked) 16 else 20).toFloat()
                setColor(Color.parseColor("#D91A1138"))
                setStroke(dp(1), Color.parseColor("#4033225F"))
            } else null
            iconView.visibility = if (st.showsIcon) View.VISIBLE else View.GONE
            (iconView.layoutParams as? LinearLayout.LayoutParams)?.apply {
                width = dp(if (st.stacked) 24 else 18)
                height = dp(if (st.stacked) 24 else 18)
                rightMargin = if (st.stacked) 0 else dp(8)
                bottomMargin = if (st.stacked) dp(3) else 0
            }
            textView.textSize = if (st.hasBox) 13f else 16f
            if (st.hasBox) textView.setShadowLayer(0f, 0f, 0f, 0)
            else textView.setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.BLACK)
            if (st.hasBox) container.setPadding(dp(12), dp(if (st.stacked) 8 else 7), dp(if (st.stacked) 12 else 14), dp(if (st.stacked) 8 else 7))
            else container.setPadding(dp(6), dp(4), dp(6), dp(4))
            container.minimumWidth = 0
            container.minimumHeight = 0
        }
    }

    private fun refreshText() {
        val v = root ?: return
        val t = text ?: return
        val i = icon ?: return
        val lp = params ?: return
        val low = lastMs < 60_000L
        t.text = if (circle) compactText(lastMs) else pillText(lastMs, shownLabel)
        t.setTextColor(if (low) Color.parseColor("#FFB35E") else Color.WHITE)
        if (dragging || animating) return // never move the view while a finger is on it or it slides
        if (circle) styleFor(v, i, t) // refreshes the amber ring when under a minute
        // Width can change with the text; keep the anchor.
        place(v, lp)
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    private fun pillText(ms: Long, label: String) = style.text(label, remainingText(ms))

    /** [oldHeight] > 0 means the shape just changed: keep the window's vertical centre where it was. */
    private fun applyMode(oldHeight: Int = -1) {
        val v = root ?: return
        val i = icon ?: return
        val t = text ?: return
        val lp = params ?: return
        styleFor(v, i, t)
        t.text = if (circle) compactText(lastMs) else pillText(lastMs, shownLabel)
        if (oldHeight > 0) {
            v.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            topY = (topY + (oldHeight - v.measuredHeight) / 2).coerceAtLeast(0)
        }
        place(v, lp)
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    // ---- Position -------------------------------------------------------------------------

    private fun place(v: View, lp: WindowManager.LayoutParams) {
        v.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = v.measuredWidth
        val h = v.measuredHeight
        val sw = screenW()
        val sh = screenH()
        val maxX = (sw - w).coerceAtLeast(0)
        lp.y = topY.coerceIn(0, (sh - h).coerceAtLeast(0))
        lp.x = when {
            !hasPos -> maxX / 2 // first start only; after the first drag this is never used again
            edgeRight -> sw - w - gapX
            else -> gapX
        }.coerceIn(0, maxX)
    }

    /** Remembers where the window is right now. Only ever called from a manual drag or tap. */
    private fun capturePosition(v: View, lp: WindowManager.LayoutParams) {
        val w = if (v.width > 0) v.width else v.measuredWidth
        val sw = screenW()
        edgeRight = lp.x + w / 2 >= sw / 2
        gapX = if (edgeRight) (sw - lp.x - w).coerceAtLeast(0) else lp.x.coerceAtLeast(0)
        topY = lp.y.coerceAtLeast(0)
        hasPos = true
    }

    /** Written straight to disk so the position survives the app being closed or the phone restarting. */
    private fun save() {
        prefs.edit()
            .putBoolean(K_CIRCLE, alwaysCircle)
            .putBoolean(K_HAS_POS, hasPos)
            .putBoolean(K_EDGE_RIGHT, edgeRight)
            .putInt(K_GAP_X, gapX)
            .putInt(K_TOP_Y, topY)
            .commit()
        writePerApp()
    }

    // ---- Touch ----------------------------------------------------------------------------

    private fun touchListener(): View.OnTouchListener {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        return View.OnTouchListener { v, event ->
            val lp = params ?: return@OnTouchListener false
            if (animating) return@OnTouchListener true
            val l = ensureLock()
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = false
                    lockedMoveSeen = false
                    downX = event.rawX
                    downY = event.rawY
                    startX = lp.x
                    startY = lp.y
                    handler.removeCallbacks(dismissRunnable)
                    // A finger on an unlocked timer keeps it unlocked.
                    handler.removeCallbacks(lockRunnable)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downX
                    val dy = event.rawY - downY
                    val moved = abs(dx) > touchSlop || abs(dy) > touchSlop
                    if (l.locked) {
                        // Locked: the timer stays where it is. A drag also breaks a run of taps.
                        if (moved && !lockedMoveSeen) {
                            lockedMoveSeen = true
                            l.onDragAttempt()
                        }
                        return@OnTouchListener true
                    }
                    if (!dragging && moved) dragging = true
                    if (dragging) {
                        val maxX = (screenW() - v.width).coerceAtLeast(0)
                        val maxY = (screenH() - v.height).coerceAtLeast(0)
                        lp.x = (startX + dx).toInt().coerceIn(0, maxX)
                        lp.y = (startY + dy).toInt().coerceIn(0, maxY)
                        try {
                            wm.updateViewLayout(v, lp)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (l.locked) {
                        if (!lockedMoveSeen) onLockedTap(l)
                    } else if (dragging) onDropped(v, lp) else onTap()
                    dragging = false
                    rescheduleDismiss()
                    scheduleLock()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (!l.locked && dragging) onDropped(v, lp)
                    dragging = false
                    rescheduleDismiss()
                    scheduleLock()
                    true
                }
                else -> false
            }
        }
    }

    /** A tap while locked: counts toward the 5 taps that unlock the timer. It never closes or resizes it. */
    private fun onLockedTap(l: TimerLock) {
        if (l.onTap(android.os.SystemClock.elapsedRealtime())) {
            saveLock()
            feedback(buzz = true)
        }
    }

    private fun onTap() {
        if (mode == Mode.PERIODIC) {
            // A tap on a popup sends it away.
            slideOutAndHide()
            return
        }
        val v = root ?: return
        val lp = params ?: return
        // Shrinking / expanding keeps the window on the same screen edge, at the same gap and height.
        capturePosition(v, lp)
        val oldH = v.height
        alwaysCircle = !circle
        circle = alwaysCircle
        applyMode(oldH)
        save()
    }

    private fun onDropped(v: View, lp: WindowManager.LayoutParams) {
        val nearLeft = lp.x <= dp(10)
        val nearRight = lp.x + v.width >= screenW() - dp(10)
        val oldH = v.height
        // Stays exactly where the finger let go: no docking, no centring, no snapping.
        capturePosition(v, lp)
        if (mode == Mode.ALWAYS && !circle && (nearLeft || nearRight)) {
            // Slid to an edge: becomes a circle there, still at the same gap from that edge.
            alwaysCircle = true
            circle = true
            applyMode(oldH)
        } else {
            applyMode()
        }
        save()
    }

    private fun rescheduleDismiss() {
        if (mode == Mode.PERIODIC && root != null) {
            handler.removeCallbacks(dismissRunnable)
            handler.postDelayed(dismissRunnable, PEEK_MS)
        }
    }

    companion object {
        private const val K_CIRCLE = "circle"
        private const val K_LOCKED = "locked"
        // Position keys (v2.3+).
        private const val K_HAS_POS = "has_pos"
        private const val K_EDGE_RIGHT = "edge_right"
        private const val K_GAP_X = "gap_x"
        private const val K_TOP_Y = "top_y"

        // Older position keys, read once to carry a saved position over.
        private const val K_ANCHOR = "anchor"
        private const val K_X = "x"
        private const val K_Y = "y"
        private const val CENTER = 0
        private const val LEFT = 1
        private const val RIGHT = 2
        private const val FREE = 3
        private const val PEEK_MS = 6_000L
        private const val SLIDE_IN_MS = 380L
        private const val SLIDE_OUT_MS = 280L
        private const val ATTACH_GRACE_NS = 1_500_000_000L

        /** "25 min left", "1 h 5 min left", "40 sec left". */
        fun remainingText(ms: Long): String {
            val secs = (ms.coerceAtLeast(0L) + 999L) / 1000L
            return when {
                secs >= 3600 -> {
                    val h = secs / 3600
                    val m = (secs % 3600 + 59) / 60
                    if (m == 0L || m == 60L) "${h + if (m == 60L) 1 else 0} h left" else "$h h $m min left"
                }
                secs >= 60 -> "${(secs + 59) / 60} min left"
                else -> "$secs sec left"
            }
        }

        /** Short form for the circle: "1h05", "25m", "40s". */
        fun compactText(ms: Long): String {
            val secs = (ms.coerceAtLeast(0L) + 999L) / 1000L
            return when {
                secs >= 3600 -> {
                    val h = secs / 3600
                    val m = (secs % 3600) / 60
                    if (m == 0L) "${h}h" else "${h}h${m.toString().padStart(2, '0')}"
                }
                secs >= 60 -> "${(secs + 59) / 60}m"
                else -> "${secs}s"
            }
        }
    }
}
