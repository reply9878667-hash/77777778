package com.focusmode.app.data.auth

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.focusmode.app.R

/**
 * The welcome message LockDistra sends to the phone when someone gets in: "Welcome to LockDistra" for a NEW account (sign-up or
 * first Google sign-in) and "Welcome back" for every later sign-in.
 */
object WelcomeNotifier {
    // A new channel id: a channel's importance cannot be raised after it was created, and the welcome should pop up.
    private const val CHANNEL = "welcome_v2"
    private const val ID = 7201

    private const val PREFS = "rewire_welcome"
    private const val KEY_PENDING = "pending_name"
    private const val KEY_PENDING_BACK = "pending_back"

    /**
     * Called when a new account is created. At that moment the notification permission is usually NOT allowed yet (the
     * permission page comes right after sign-up), so the message is kept and shown by [showPending] as soon as
     * notifications are allowed. It is shown once.
     */
    fun show(context: Context, name: String) = queue(context, name, back = false)

    /** Called when someone signs in to an account that already exists: a warm "Welcome back" message. */
    fun showWelcomeBack(context: Context, name: String) = queue(context, name, back = true)

    private fun queue(context: Context, name: String, back: Boolean) {
        val app = context.applicationContext
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_PENDING, name.trim().ifEmpty { "friend" })
            .putBoolean(KEY_PENDING_BACK, back)
            .apply()
        showPending(app)
    }

    /** Shows the waiting welcome message if there is one and notifications are allowed. Safe to call any time. */
    fun showPending(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val name = prefs.getString(KEY_PENDING, null) ?: return
        val back = prefs.getBoolean(KEY_PENDING_BACK, false)
        if (post(app, name, back)) prefs.edit().remove(KEY_PENDING).remove(KEY_PENDING_BACK).apply()
    }

    /** @return true when the notification was handed to Android. */
    private fun post(context: Context, name: String, back: Boolean): Boolean {
        val nm = NotificationManagerCompat.from(context)
        if (!nm.areNotificationsEnabled()) return false
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Welcome", NotificationManager.IMPORTANCE_HIGH)
            context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
        val first = name.trim().ifEmpty { "friend" }
        val title: String
        val text: String
        if (back) {
            val (t, body) = backMessage(first)
            title = t
            text = body
        } else {
            title = "Welcome to LockDistra, $first! \uD83C\uDF89"
            text = "Your account is ready \u2728 Block distractions, grow your focus plant \uD83C\uDF31 and make every " +
                "study minute count \uD83D\uDCAA\uD83D\uDCDA We're so happy you're here \uD83D\uDC9C"
        }
        val open = context.packageManager.getLaunchIntentForPackage(context.packageName)?.let {
            PendingIntent.getActivity(context, ID, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setCategory(NotificationCompat.CATEGORY_SOCIAL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .build()
        return try {
            nm.notify(ID, n)
            true
        } catch (_: SecurityException) {
            // Notification permission was revoked between the check and the call: keep it for later.
            false
        }
    }

    /** The "Welcome back" wording: it changes with the time of day, so it does not feel copy-pasted. */
    internal fun backMessage(first: String, hour: Int = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)): Pair<String, String> {
        val (wave, greeting) = when (hour) {
            in 5..11 -> "\u2600\uFE0F" to "Good morning"
            in 12..16 -> "\uD83C\uDF24\uFE0F" to "Good afternoon"
            in 17..21 -> "\uD83C\uDF06" to "Good evening"
            else -> "\uD83C\uDF19" to "Hey, night owl"
        }
        val title = "Welcome back, $first! \uD83D\uDC4B$wave"
        val text = "$greeting! Great to see you again \uD83D\uDC9A Your focus plant \uD83C\uDF31 is waiting for you. " +
            "Let's make today count \uD83D\uDCAA\uD83D\uDCDA\u2728"
        return title to text
    }
}
