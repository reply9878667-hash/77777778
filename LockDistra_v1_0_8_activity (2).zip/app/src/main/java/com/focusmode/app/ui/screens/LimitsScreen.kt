package com.focusmode.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.AppLimit
import com.focusmode.app.data.EmergencyDraft
import com.focusmode.app.data.LimitEmergency
import com.focusmode.app.data.LimitEmergencyRules
import com.focusmode.app.data.LimitsState
import com.focusmode.app.data.ShortForm
import com.focusmode.app.data.ShortFormCatalog
import com.focusmode.app.data.TimerStyle
import com.focusmode.app.ui.components.AppIcon
import com.focusmode.app.ui.components.AppListSkeleton
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.formatMinutes
import com.focusmode.app.ui.theme.FocusTheme

private val reminderPresets = listOf(0 to "Off", 5 to "5 min", 10 to "10 min")

private val floatingEveryPresets = listOf(0 to "Always", 1 to "1 min", 2 to "2 min", 5 to "5 min", 10 to "10 min")

private val categoryPresets = listOf(10, 15, 20, 30, 60)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LimitsScreen(
    limits: LimitsState,
    apps: List<AppInfo>,
    appsLoaded: Boolean,
    onBack: () -> Unit,
    onSave: (AppLimit) -> Unit,
    onRemove: (String) -> Unit,
    onSaveCategory: (id: String, minutes: Int) -> Unit,
    onRemoveCategory: (String) -> Unit,
    onSaveEmergency: (key: String, enabled: Boolean, attempts: Int, minutes: Int) -> Unit,
    onFloatingChange: (Boolean) -> Unit,
    onFloatingEveryChange: (Int) -> Unit,
    onFloatingOverGamesChange: (Boolean) -> Unit,
    onFloatingStyleChange: (String) -> Unit,
    /** True while a session has "Allow app restriction changes" switched off. */
    locked: Boolean = false,
) {
    val c = FocusTheme.colors
    var picking by remember { mutableStateOf(false) }
    // Floating timer options (design, when it shows) are secondary, so they stay folded until opened.
    var floatingOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<AppLimit?>(null) }
    var editingIsNew by remember { mutableStateOf(false) }
    var editingCategory by remember { mutableStateOf<ShortForm?>(null) }
    val labels = remember(apps) { apps.associate { it.packageName to it.label } }
    // Only content that exists in an installed app is offered.
    val forms = remember(apps) { ShortFormCatalog.installed(apps.map { it.packageName }.toSet()) }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Column {
                Text("Usage limits", style = MaterialTheme.typography.titleLarge)
                Text(
                    if (limits.limits.isEmpty()) "Daily time per app"
                    else "${limits.limits.size} app${if (limits.limits.size == 1) "" else "s"} limited",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (locked) {
                item { LockedNote("Changing app restrictions is locked right now (focus session or Prevent changes).") }
            }
            item { SectionLabel("App limits", Modifier.padding(top = 2.dp)) }
            if (limits.limits.isEmpty()) {
                item {
                    FocusCard {
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(
                                Modifier.size(56.dp).clip(CircleShape).background(c.accentSoft),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.Timer, null, tint = c.accent, modifier = Modifier.size(28.dp))
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("No limits yet", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Pick an app and choose how long you can use it each day. When time is up, it stays closed until tomorrow.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(limits.limits, key = { it.pkg }) { limit ->
                    LimitRow(
                        limit = limit,
                        label = labels[limit.pkg] ?: limit.pkg,
                        usedMs = limits.usedMs[limit.pkg] ?: 0L,
                        onClick = { if (!locked) { editing = limit; editingIsNew = false } }
                    )
                }
            }
            item { SectionLabel("Shorts, Reels & Status", Modifier.padding(top = 10.dp)) }
            if (forms.isEmpty()) {
                item {
                    Text(
                        "None of the supported apps (YouTube, Instagram, Facebook, WhatsApp, Snapchat) are installed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                }
            } else {
                item {
                    Text(
                        "A separate daily time for each one. Time is counted only while that content is on screen, and it closes when the time is up. It resets every midnight.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                }
                items(forms, key = { "cat_" + it.id }) { form ->
                    val limit = limits.categoryLimits.firstOrNull { it.pkg == form.id }
                    CategoryRow(
                        form = form,
                        limit = limit,
                        usedMs = limits.categoryUsedMs[form.id] ?: 0L,
                        onClick = { if (!locked) editingCategory = form }
                    )
                }
            }

            item { SectionLabel("Display", Modifier.padding(top = 10.dp)) }
            item {
                FocusCard(
                    onClick = { floatingOpen = !floatingOpen },
                    padding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Floating timer", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Shows the time left on top of every app that has a limit.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted
                            )
                        }
                        Icon(
                            if (floatingOpen) Icons.Rounded.KeyboardArrowUp
                            else Icons.Rounded.KeyboardArrowDown,
                            if (floatingOpen) "Hide timer options" else "Show timer options",
                            tint = c.muted
                        )
                        Spacer(Modifier.size(8.dp))
                        FocusSwitch(
                            checked = limits.floatingTimer,
                            enabled = !locked,
                            onCheckedChange = onFloatingChange
                        )
                    }
                }
            }
            if (limits.floatingTimer && floatingOpen) {
                item {
                    FocusCard(padding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)) {
                        Column {
                            Text("Timer design", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "How the floating timer looks. The small circle (tap the timer or drag it to the screen edge) stays the same.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted
                            )
                            Spacer(Modifier.height(12.dp))
                            TimerPreview(TimerStyle.fromId(limits.floatingStyle))
                            Spacer(Modifier.height(12.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                TimerStyle.values().forEach { st ->
                                    SoftChip(
                                        text = st.title,
                                        selected = limits.floatingStyle == st.id,
                                        onClick = { if (!locked) onFloatingStyleChange(st.id) }
                                    )
                                }
                            }
                        }
                    }
                }
                item {
                    FocusCard(padding = PaddingValues(horizontal = 20.dp, vertical = 16.dp)) {
                        Column {
                            Text("Show timer", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Always keeps it on screen. With 1, 2, 5 or 10 minutes it stays hidden and slides in by itself after that many minutes of using the app, then slides away.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted
                            )
                            Spacer(Modifier.height(12.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                floatingEveryPresets.forEach { (min, label) ->
                                    SoftChip(
                                        text = label,
                                        selected = limits.floatingEveryMin == min,
                                        onClick = { if (!locked) onFloatingEveryChange(min) }
                                    )
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("Also over games", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "On: the timer shows in every app with a limit, games included. Turn off only if a game dislikes on-screen overlays; the limit still counts and still closes it.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = c.muted
                                    )
                                }
                                FocusSwitch(
                                    checked = limits.floatingOverGames,
                                    enabled = !locked,
                                    onCheckedChange = onFloatingOverGamesChange
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(
                                "Move the timer by dragging it anywhere. If you leave it alone for 5 seconds it locks in place. To move it again, tap it 5 times in a row (it says when it is unlocked), then drag it. In Always mode a tap on an unlocked timer shrinks it into a circle; a sliding popup goes away by itself, or when you tap it.",
                                style = MaterialTheme.typography.bodySmall,
                                color = c.muted
                            )
                        }
                    }
                }
            }

        }

        Box(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            PrimaryButton(
                text = "Add app limit",
                icon = Icons.Rounded.Add,
                enabled = !locked,
                onClick = { picking = true }
            )
        }
    }

    if (picking) {
        AppPickerSheet(
            apps = apps,
            loaded = appsLoaded,
            alreadyLimited = limits.limits.map { it.pkg }.toSet(),
            onPick = { pkg ->
                picking = false
                editing = AppLimit(pkg, limitMin = 30, remindMin = 5)
                editingIsNew = true
            },
            onDismiss = { picking = false }
        )
    }

    editingCategory?.let { form ->
        CategoryEditorSheet(
            form = form,
            current = limits.categoryLimits.firstOrNull { it.pkg == form.id },
            emergency = limits.emergency[form.id] ?: LimitEmergency(),
            onSave = { total, e ->
                onSaveCategory(form.id, total)
                onSaveEmergency(form.id, e.enabled, e.attempts, e.minutes)
                editingCategory = null
            },
            onRemove = { onRemoveCategory(form.id); editingCategory = null },
            onDismiss = { editingCategory = null }
        )
    }

    editing?.let { limit ->
        LimitEditorSheet(
            limit = limit,
            label = labels[limit.pkg] ?: limit.pkg,
            isNew = editingIsNew,
            emergency = limits.emergency[limit.pkg] ?: LimitEmergency(),
            onSave = { saved, e ->
                onSave(saved)
                onSaveEmergency(saved.pkg, e.enabled, e.attempts, e.minutes)
                editing = null
            },
            onRemove = { onRemove(limit.pkg); editing = null },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun CategoryRow(form: ShortForm, limit: AppLimit?, usedMs: Long, onClick: () -> Unit) {
    val c = FocusTheme.colors
    FocusCard(onClick = onClick, padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(form.pkg, 44.dp)
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(form.displayName, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(
                        if (limit == null) "No daily limit"
                        else "${formatMinutes((usedMs / 60_000L).toInt())} of ${formatMinutes(limit.limitMin)} used",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
                if (limit == null) {
                    Text("Set", style = MaterialTheme.typography.labelMedium, color = c.accent)
                } else {
                    val reached = usedMs >= limit.limitMs
                    Text(
                        if (reached) "Limit reached"
                        else "${formatMinutes(((limit.limitMs - usedMs + 59_999L) / 60_000L).toInt())} left",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (reached) c.warning else c.accent
                    )
                }
            }
            if (limit != null) {
                val reached = usedMs >= limit.limitMs
                val target = (usedMs.toFloat() / limit.limitMs.toFloat()).coerceIn(0f, 1f)
                val fraction by animateFloatAsState(target, tween(500), label = "categoryProgress")
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(c.ringTrack)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(fraction)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (reached || limit.limitMs - usedMs <= 5 * 60_000L) c.warning else c.accent)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun CategoryEditorSheet(
    form: ShortForm,
    current: AppLimit?,
    emergency: LimitEmergency,
    onSave: (Int, EmergencyDraft) -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var emgOn by remember { mutableStateOf(emergency.enabled) }
    var emgAttempts by remember { mutableIntStateOf(emergency.attempts) }
    var emgMinutes by remember { mutableIntStateOf(emergency.minutes) }
    val start = current?.limitMin ?: 30
    var hours by remember { mutableIntStateOf(start / 60) }
    var minutes by remember { mutableIntStateOf(start % 60) }
    val total = hours * 60 + minutes
    val sliderColors = SliderDefaults.colors(
        thumbColor = c.accent,
        activeTrackColor = c.accent,
        inactiveTrackColor = c.ringTrack,
        activeTickColor = c.accent,
        inactiveTickColor = c.ringTrack,
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppIcon(form.pkg, 56.dp)
            Spacer(Modifier.height(10.dp))
            Text(form.displayName, style = MaterialTheme.typography.titleLarge)
            Text("Daily limit", style = MaterialTheme.typography.bodySmall, color = c.muted)
            Spacer(Modifier.height(10.dp))
            Text(
                if (total == 0) "Set a time" else formatMinutes(total),
                style = MaterialTheme.typography.displayMedium,
                color = c.accent
            )
            Spacer(Modifier.height(16.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                categoryPresets.forEach { preset ->
                    SoftChip(
                        text = formatMinutes(preset),
                        selected = total == preset,
                        onClick = { hours = preset / 60; minutes = preset % 60 }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Hours", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Stepper(
                    value = hours,
                    onMinus = { if (hours > 0) hours-- },
                    onPlus = { if (hours < 23) hours++ }
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Minutes", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text("$minutes", style = MaterialTheme.typography.titleMedium, color = c.accent)
            }
            Slider(
                value = minutes.toFloat(),
                onValueChange = { minutes = it.toInt() },
                valueRange = 0f..59f,
                steps = 58,
                colors = sliderColors
            )
            Text(
                "Only the time spent in ${form.title} counts. The rest of ${form.appName} stays open.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted,
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
            Spacer(Modifier.height(16.dp))
            EmergencySection(
                enabled = emgOn,
                attempts = emgAttempts,
                minutes = emgMinutes,
                onEnabled = { emgOn = it },
                onAttempts = { emgAttempts = it },
                onMinutes = { emgMinutes = it },
            )
            Spacer(Modifier.height(24.dp))
            PrimaryButton(
                text = if (current == null) "Set limit" else "Save changes",
                enabled = total > 0,
                onClick = { onSave(total, EmergencyDraft(emgOn, emgAttempts, emgMinutes)) }
            )
            if (current != null) {
                TextButton(onClick = onRemove) { Text("Remove limit", color = c.warning) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LimitRow(limit: AppLimit, label: String, usedMs: Long, onClick: () -> Unit) {
    val c = FocusTheme.colors
    val reached = usedMs >= limit.limitMs
    val target = (usedMs.toFloat() / limit.limitMs.toFloat()).coerceIn(0f, 1f)
    val fraction by animateFloatAsState(target, tween(500), label = "limitProgress")
    val nearEnd = !reached && limit.limitMs - usedMs <= 5 * 60_000L
    val barColor = if (reached || nearEnd) c.warning else c.accent

    FocusCard(onClick = onClick, padding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(limit.pkg, 44.dp)
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                    Text(
                        "${formatMinutes((usedMs / 60_000L).toInt())} of ${formatMinutes(limit.limitMin)} used",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
                Text(
                    if (reached) "Limit reached" else "${formatMinutes(((limit.limitMs - usedMs + 59_999L) / 60_000L).toInt())} left",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (reached || nearEnd) c.warning else c.accent
                )
            }
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(c.ringTrack)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(fraction)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(3.dp))
                        .background(barColor)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppPickerSheet(
    apps: List<AppInfo>,
    loaded: Boolean,
    alreadyLimited: Set<String>,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var query by remember { mutableStateOf("") }
    val q = query.trim()
    val shown = apps.filter {
        !it.isSettings && it.packageName !in alreadyLimited && (q.isEmpty() || it.label.contains(q, ignoreCase = true))
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().height(560.dp)) {
            Text(
                "Choose an app",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
            Spacer(Modifier.height(14.dp))
            SearchField(value = query, onValueChange = { query = it }, modifier = Modifier.padding(horizontal = 20.dp))
            if (!loaded) {
                AppListSkeleton(rows = 8)
            } else if (shown.isEmpty()) {
                Text(
                    "No apps to show",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.muted,
                    modifier = Modifier.padding(24.dp)
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shown, key = { it.packageName }) { app ->
                        FocusCard(
                            onClick = { onPick(app.packageName) },
                            padding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                AppIcon(app.packageName, 44.dp)
                                Spacer(Modifier.size(14.dp))
                                Text(app.label, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
internal fun LimitEditorSheet(
    limit: AppLimit,
    label: String,
    isNew: Boolean,
    emergency: LimitEmergency,
    onSave: (AppLimit, EmergencyDraft) -> Unit,
    onRemove: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    var emgOn by remember { mutableStateOf(emergency.enabled) }
    var emgAttempts by remember { mutableIntStateOf(emergency.attempts) }
    var emgMinutes by remember { mutableIntStateOf(emergency.minutes) }
    var hours by remember { mutableIntStateOf(limit.limitMin / 60) }
    var minutes by remember { mutableIntStateOf(limit.limitMin % 60) }
    var remind by remember { mutableIntStateOf(limit.remindMin) }
    var custom by remember { mutableStateOf(limit.remindMin > 0 && reminderPresets.none { it.first == limit.remindMin }) }

    val total = hours * 60 + minutes
    val sliderColors = SliderDefaults.colors(
        thumbColor = c.accent,
        activeTrackColor = c.accent,
        inactiveTrackColor = c.ringTrack,
        activeTickColor = c.accent,
        inactiveTickColor = c.ringTrack,
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = c.background,
        contentColor = c.text,
    ) {
        Column(
            Modifier
                .padding(horizontal = 24.dp)
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AppIcon(limit.pkg, 56.dp)
            Spacer(Modifier.height(10.dp))
            Text(label, style = MaterialTheme.typography.titleLarge)
            Text("Daily limit", style = MaterialTheme.typography.bodySmall, color = c.muted)
            Spacer(Modifier.height(10.dp))
            Text(
                if (total == 0) "Set a time" else formatMinutes(total),
                style = MaterialTheme.typography.displayMedium,
                color = c.accent
            )
            Spacer(Modifier.height(16.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(15, 30, 60, 120, 180).forEach { preset ->
                    SoftChip(
                        text = formatMinutes(preset),
                        selected = total == preset,
                        onClick = { hours = preset / 60; minutes = preset % 60 }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Hours", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Stepper(
                    value = hours,
                    onMinus = { if (hours > 0) hours-- },
                    onPlus = { if (hours < 23) hours++ }
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Minutes", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                Text("$minutes", style = MaterialTheme.typography.titleMedium, color = c.accent)
            }
            Slider(
                value = minutes.toFloat(),
                onValueChange = { minutes = it.toInt() },
                valueRange = 0f..59f,
                steps = 58,
                colors = sliderColors
            )

            Spacer(Modifier.height(8.dp))
            Text(
                "Remind me before time runs out",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                reminderPresets.forEach { (value, text) ->
                    SoftChip(
                        text = text,
                        selected = !custom && remind == value,
                        onClick = { custom = false; remind = value }
                    )
                }
                SoftChip(
                    text = if (custom) "Custom: $remind min" else "Custom",
                    selected = custom,
                    onClick = {
                        custom = true
                        if (remind == 0 || reminderPresets.any { it.first == remind }) remind = 15
                    }
                )
            }
            if (custom) {
                Slider(
                    value = remind.toFloat(),
                    onValueChange = { remind = it.toInt().coerceAtLeast(1) },
                    valueRange = 1f..60f,
                    steps = 58,
                    colors = sliderColors
                )
            }
            if (remind > 0 && total in 1..remind) {
                Text(
                    "The reminder will be shortened so it comes before the limit ends.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted,
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                )
            }

            Spacer(Modifier.height(16.dp))
            EmergencySection(
                enabled = emgOn,
                attempts = emgAttempts,
                minutes = emgMinutes,
                onEnabled = { emgOn = it },
                onAttempts = { emgAttempts = it },
                onMinutes = { emgMinutes = it },
            )
            Spacer(Modifier.height(24.dp))
            PrimaryButton(
                text = if (isNew) "Set limit" else "Save changes",
                enabled = total > 0,
                onClick = {
                    val safeRemind = if (remind <= 0) 0 else remind.coerceAtMost((total - 1).coerceAtLeast(0))
                    onSave(AppLimit(limit.pkg, total, safeRemind), EmergencyDraft(emgOn, emgAttempts, emgMinutes))
                }
            )
            if (!isNew) {
                TextButton(onClick = onRemove) { Text("Remove limit", color = c.warning) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
internal fun Stepper(value: Int, onMinus: () -> Unit, onPlus: () -> Unit) {
    val c = FocusTheme.colors
    Row(verticalAlignment = Alignment.CenterVertically) {
        StepButton(Icons.Rounded.Remove, "Less", onMinus)
        Text(
            "$value",
            style = MaterialTheme.typography.titleLarge,
            color = c.accent,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 18.dp)
        )
        StepButton(Icons.Rounded.Add, "More", onPlus)
    }
}

@Composable
private fun StepButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    val c = FocusTheme.colors
    Box(
        Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(c.cardHigh)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, description, tint = c.text, modifier = Modifier.size(20.dp))
    }
}


/** A mock-up of the floating timer in the chosen design (sample text only). */
@Composable
private fun TimerPreview(style: TimerStyle) {
    val c = FocusTheme.colors
    val shell = if (style.hasBox) {
        Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xD91A1138))
            .padding(horizontal = 12.dp, vertical = 7.dp)
    } else {
        Modifier
    }
    val textColor = if (style.hasBox) Color.White else c.text
    val words = style.text("YouTube", "25 min left")
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(c.cardHigh)
            .padding(vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        if (style.stacked) {
            Column(shell, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(22.dp).clip(CircleShape).background(c.accent))
                Spacer(Modifier.height(3.dp))
                Text(words, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = textColor)
            }
        } else {
            Row(shell, verticalAlignment = Alignment.CenterVertically) {
                if (style.showsIcon) {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(c.accent))
                    Spacer(Modifier.size(8.dp))
                }
                Text(words, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = textColor)
            }
        }
    }
}


/**
 * Emergency access for one limit: when the time is up, the block screen offers a few extra minutes,
 * a few times a day. Shown at the bottom of every limit editor.
 */
@Composable
private fun EmergencySection(
    enabled: Boolean,
    attempts: Int,
    minutes: Int,
    onEnabled: (Boolean) -> Unit,
    onAttempts: (Int) -> Unit,
    onMinutes: (Int) -> Unit,
) {
    val c = FocusTheme.colors
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(c.card)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Emergency access", style = MaterialTheme.typography.titleMedium)
                Text(
                    if (enabled) "When time is up, the block screen offers a few extra minutes."
                    else "Off: when time is up, the app stays closed until tomorrow.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
            }
            FocusSwitch(checked = enabled, onCheckedChange = onEnabled)
        }
        if (enabled) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Attempts per day", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Stepper(
                    value = attempts,
                    onMinus = { onAttempts(LimitEmergencyRules.clampAttempts(attempts - 1)) },
                    onPlus = { onAttempts(LimitEmergencyRules.clampAttempts(attempts + 1)) }
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Minutes each time", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Stepper(
                    value = minutes,
                    onMinus = { onMinutes(LimitEmergencyRules.clampMinutes(minutes - 1)) },
                    onPlus = { onMinutes(LimitEmergencyRules.clampMinutes(minutes + 1)) }
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "Up to ${LimitEmergencyRules.MAX_ATTEMPTS} attempts of up to ${LimitEmergencyRules.MAX_MINUTES} minutes. " +
                    "An attempt is used when you start it and is not given back. Attempts come back every midnight.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
        }
    }
}
