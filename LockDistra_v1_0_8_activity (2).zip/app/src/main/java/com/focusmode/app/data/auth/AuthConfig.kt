package com.focusmode.app.data.auth

import com.focusmode.app.BuildConfig
import com.focusmode.app.data.online.OnlineConfig

/**
 * Every tunable of the account system in one place. Nothing here is a secret: the Firebase values and the
 * Google *web* client id are read at build time from firebase.properties / FOCUSMODE_* environment variables
 * (see AUTH_TASK1.md), exactly like the existing Online Approval values.
 */
object AuthConfig {
    /**
     * First-run "Skip for now". Task 3 made the account mandatory (see [REQUIRE_LOGIN]), so the account screen has
     * no Skip button any more. Kept as a constant so the screens' optional `onSkip` stays one switch.
     */
    const val ALLOW_SKIP = false

    /**
     * Task 3: nobody reaches Home without being logged in. Only enforced when Firebase is configured in this build
     * ([authRequired]); without Firebase an account cannot exist, and locking the person out of their own blocker
     * would be worse than leaving it open. Blocking and limits never depend on this: they run in services.
     */
    const val REQUIRE_LOGIN = true

    const val MIN_NAME = 2
    const val MAX_NAME = 30
    const val MIN_PASSWORD = 8
    const val MAX_PASSWORD = 64
    const val MAX_EMAIL = 254

    /** Every network step gives up after this long and says so instead of spinning forever. */
    const val OP_TIMEOUT_MS = 20_000L

    /** After a reset mail was sent, "Send again" waits this many seconds. */
    const val RESET_COOLDOWN_SECONDS = 30

    /** Firebase Authentication is available in this build (same condition as Online Approval). */
    val firebaseReady: Boolean get() = OnlineConfig.configured

    /** OAuth *web* client id used to request the Google ID token. Blank = Google sign-in not set up. */
    val webClientId: String get() = BuildConfig.GOOGLE_WEB_CLIENT_ID.trim()

    val googleReady: Boolean get() = firebaseReady && webClientId.isNotEmpty()

    /** Debug builds say WHICH value is missing; release builds keep the plain text. Null when Google is ready. */
    val googleSetupProblem: String?
        get() = when {
            googleReady -> null
            !BuildConfig.DEBUG -> null
            !firebaseReady -> "Firebase isn't set up in this build (apiKey / appId / projectId / databaseUrl are empty)."
            else -> "Google sign-in isn't set up in this build: googleWebClientId is empty in firebase.properties " +
                "(or the FOCUSMODE_GOOGLE_WEB_CLIENT_ID secret)."
        }

    /** Home is closed to logged-out people (Task 3). False when accounts are not set up in this build. */
    val authRequired: Boolean get() = REQUIRE_LOGIN && firebaseReady
}
