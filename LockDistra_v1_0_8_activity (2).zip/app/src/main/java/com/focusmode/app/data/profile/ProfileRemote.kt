package com.focusmode.app.data.profile

import android.content.Context
import com.focusmode.app.data.auth.AuthProvider
import com.focusmode.app.data.online.FirebaseGateway
import com.focusmode.app.data.online.OnlineException
import org.json.JSONObject

data class RemoteProfile(
    val displayName: String,
    val email: String,
    val provider: AuthProvider,
    val avatar: String,
    val createdAt: Long,
    val updatedAt: Long,
)

data class RemoteUserData(
    val profile: RemoteProfile?,
    val onboarding: ProfileOnboarding?,
)

/**
 * Reads and writes `users/{uid}` in the Firebase Realtime Database (the database Online Approval already uses),
 * through [FirebaseGateway] (same connection, REST fallback, retries and error kinds). Every call first checks
 * that the Firebase login really is [uid]: the data of account A can never be written while B is signed in.
 * The database rules (firebase/database.rules.json) are the second wall: only the owner may read or write.
 *
 * Only what is really needed lives on the server (small, so little data is ever sent):
 *          users/{uid}/profile    displayName, email, provider, avatar?, createdAt, updatedAt
 *          users/{uid}/onboarding name + completedAt only ("this account finished onboarding", written once)
 * Everything else stays on the phone: the profile photo and the onboarding answers. The app's settings (blocked apps,
 * limits ...) are uploaded only when the person taps "Upload" in Settings > Backup (see SettingsBackupRemote, stored at
 * users/{uid}/settingsBackup).
 */
class ProfileRemote(context: Context) {

    private val appContext = context.applicationContext

    private suspend fun requireLogin(uid: String) {
        if (FirebaseGateway.uid(appContext) != uid) {
            throw OnlineException(OnlineException.Kind.AUTH, "This account is no longer signed in.")
        }
    }

    suspend fun fetch(uid: String): RemoteUserData {
        requireLogin(uid)
        // Two small reads instead of the whole users/{uid} node, so nothing else stored there is ever downloaded.
        val profileNode = FirebaseGateway.readNode(appContext, "users/$uid/profile")
        val onboardingNode = FirebaseGateway.readNode(appContext, "users/$uid/onboarding")
        val p = profileNode?.let { j ->
            RemoteProfile(
                displayName = j.optString("displayName"),
                email = j.optString("email"),
                provider = AuthProvider.fromId(j.optString("provider")),
                avatar = j.optString("avatar"),
                createdAt = j.optLong("createdAt"),
                updatedAt = j.optLong("updatedAt"),
            )
        }
        val ob = onboardingNode?.let { j ->
            ProfileOnboarding(
                name = j.optString("name"),
                goal = j.str("goal"),
                distractions = ProfileRules.decodeIds(j.str("distractions")),
                phoneTime = j.str("phoneTime"),
                sessionLength = j.str("sessionLength"),
                dailyGoal = j.str("dailyGoal"),
                dailyGoalMinutes = if (j.has("dailyGoalMinutes")) j.optInt("dailyGoalMinutes") else null,
                source = j.str("source"),
                completedAt = j.optLong("completedAt"),
            )
        }
        return RemoteUserData(p, ob)
    }

    suspend fun writeProfile(uid: String, p: UserProfile) {
        requireLogin(uid)
        val j = JSONObject()
            .put("displayName", p.displayName)
            .put("email", p.email)
            .put("provider", p.provider.name)
            .put("createdAt", p.createdAt)
            .put("updatedAt", p.updatedAt)
        if (p.avatarId.isNotEmpty()) j.put("avatar", p.avatarId)
        FirebaseGateway.setNode(appContext, "users/$uid/profile", j)
    }

    /**
     * Create-once on the server (the rules refuse a second write). Callers fetch first and only write when absent.
     * Only the name and the finish time go up: just enough for a second phone to know that onboarding is done.
     * The answers themselves (goal, distractions ...) stay on the phone.
     */
    suspend fun writeOnboarding(uid: String, b: ProfileOnboarding) {
        requireLogin(uid)
        val j = JSONObject().put("name", b.name).put("completedAt", b.completedAt)
        FirebaseGateway.setNode(appContext, "users/$uid/onboarding", j)
    }

    private fun JSONObject.str(k: String): String? =
        if (has(k) && !isNull(k)) optString(k).takeIf { it.isNotEmpty() } else null
}
