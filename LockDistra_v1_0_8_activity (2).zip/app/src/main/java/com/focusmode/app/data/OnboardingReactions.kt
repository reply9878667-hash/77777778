package com.focusmode.app.data

/**
 * Onboarding Part 2C: which mood the mascot is in on each question.
 *
 * Plain Kotlin (no Android or Compose types) so the rules are unit tested on the JVM. The mascot
 * itself (ui/onboarding/FocusBuddy.kt + BuddyLook.kt) decides what each mood looks like.
 */
enum class BuddyMood {
    /** Part 1's mascot exactly as it was (welcome screen). */
    Neutral,

    /** Q1 before a name: warm smile, a hello wave. */
    Friendly,

    /** Q1 once a name is typed: beaming, waving, sparkles. */
    Happy,

    /** Q2: leaning in, head tilted, one brow up, watching the options. */
    Interested,

    /** Q3: hand on chin, worried brows, small frown, a sweat drop. */
    Concerned,

    /** Q4 before an answer: hand on chin, looking up, thought bubble. */
    Thoughtful,

    /** Q4, light phone use: pleased and impressed. */
    Pleased,

    /** Q4, heavy phone use: worried but caring. */
    Worried,

    /** Q5: warm and motivating, a little fist pump. */
    Encouraging,

    /** Q6: big grin, both arms up, hopping. */
    Excited,

    /** Q7: head tilted, wide eyes, a question mark. */
    Curious,

    /** Part 2D, the final screen: beaming face, sparkles and the dance. Never used by a question. */
    Celebrating,
}

/** The words of the final celebration screen (Part 2D). */
object OnboardingCelebration {
    const val BODY = "Thanks for telling me about yourself. Your focus journey is about to begin!"

    /** The name as shown: trimmed, with runs of spaces collapsed. */
    fun displayName(raw: String): String = raw.trim().replace(Regex("\\s+"), " ")

    /** "Awesome, Rahul! 🎉" with the real name; plain "Awesome! 🎉" if there is somehow none. */
    fun headline(name: String): String {
        val n = displayName(name)
        return if (n.isEmpty()) "Awesome! \uD83C\uDF89" else "Awesome, $n! \uD83C\uDF89"
    }
}

object OnboardingReactions {

    /** The mood for [questionId] given what has been answered so far. */
    fun moodFor(questionId: String, answers: OnboardingAnswers): BuddyMood = when (questionId) {
        OnboardingQuestions.NAME ->
            if (answers.text(OnboardingQuestions.NAME).isBlank()) BuddyMood.Friendly else BuddyMood.Happy

        OnboardingQuestions.GOAL -> BuddyMood.Interested
        OnboardingQuestions.DISTRACTIONS -> BuddyMood.Concerned
        OnboardingQuestions.PHONE_TIME -> when (answers.phoneTime) {
            "lt_2h", "2_4h" -> BuddyMood.Pleased
            "6_8h", "gt_8h" -> BuddyMood.Worried
            // Nothing chosen yet, 4-6 hours, or "Not sure": think about it.
            else -> BuddyMood.Thoughtful
        }

        OnboardingQuestions.SESSION_LENGTH -> BuddyMood.Encouraging
        OnboardingQuestions.DAILY_GOAL -> BuddyMood.Excited
        OnboardingQuestions.SOURCE -> BuddyMood.Curious
        else -> BuddyMood.Neutral
    }

    /**
     * A number that changes whenever the mascot should react to the person's input on [questionId]
     * (an option picked or changed, or a few more letters of the name), and stays the same otherwise.
     * Typing a name reacts every third letter, not on every key, so it never looks jittery.
     */
    fun signature(questionId: String, answers: OnboardingAnswers): Int =
        if (questionId == OnboardingQuestions.NAME) {
            val len = answers.text(questionId).trim().length
            if (len == 0) 0 else 1 + len / 3
        } else {
            answers.selected(questionId).hashCode()
        }
}
