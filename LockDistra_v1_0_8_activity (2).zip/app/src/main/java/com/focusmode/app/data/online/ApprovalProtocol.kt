package com.focusmode.app.data.online

import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/*
 * Online approval protocol. No Android classes, so it runs in plain JVM unit tests.
 *
 * Trust does NOT rest on the database alone. When two phones are paired they share a secret
 * (the "pair key") that only exists on those two phones. Every unlock request carries a MAC made
 * with it, and every approval / rejection carries a proof made with it. The locked phone only
 * unlocks when the proof checks out, so even a wrong database rule or a stolen Firebase login
 * can't open the app. Requests are also time-limited and can be used once.
 */

/** What the trusted phone decided. */
enum class Decision(val wire: String) { APPROVED("approved"), REJECTED("rejected") }

/** What the locked phone concludes about its own request. */
sealed interface RequestOutcome {
    object Pending : RequestOutcome
    object Approved : RequestOutcome
    object Rejected : RequestOutcome

    /** Only for "more time in one app" requests: approved, for this many minutes. */
    data class GrantedFor(val minutes: Int) : RequestOutcome
    object Expired : RequestOutcome
    data class Invalid(val reason: String) : RequestOutcome
}

/** One unlock request as read from the database. Times are server milliseconds. */
data class RequestSnapshot(
    val status: String?,
    val createdAt: Long?,
    val decidedAt: Long?,
    val decidedBy: String?,
    val proof: String?,
    val nonce: String?,
    val deviceId: String?,
    /** "app" for a "more time in one app" request, null for the normal lock-screen request. */
    val kind: String? = null,
    val pkg: String? = null,
    val appName: String? = null,
    /** Why the app was closed (see [AppUnlockRules]). */
    val reason: Int? = null,
    /** Minutes the trusted phone granted ("app" requests only). */
    val minutes: Long? = null,
)

/** What the locked phone remembers about the request it made. */
data class ExpectedRequest(
    val ownerUid: String,
    val requestId: String,
    val nonce: String,
    val deviceId: String,
    val approverUid: String,
    val pairKey: ByteArray,
    /** Set only for a "more time in one app" request: the app and why it was closed. */
    val pkg: String? = null,
    val reason: Int = 0,
)

object ApprovalProtocol {

    /** The trusted phone has this long to answer. */
    const val REQUEST_TTL_MS = 120_000L

    /** After an approval the locked phone must use it within this time. */
    const val CONSUME_WINDOW_MS = 30_000L

    /** Request kind written to the database for "more time in one app". */
    const val KIND_APP = "app"

    /** The trusted phone may grant between these many minutes. */
    const val MIN_GRANT_MIN = 1
    const val MAX_GRANT_MIN = 240

    /** A pairing code is valid for this long. */
    const val INVITE_TTL_MS = 10 * 60_000L

    /** 20 characters from a 32 letter alphabet = 100 bits, shown as XXXXX-XXXXX-XXXXX-XXXXX. */
    const val PAIR_CODE_LENGTH = 20

    // No 0/O/1/I so a code read off a screen can't be mistyped.
    const val PAIR_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

    private val random = SecureRandom()

    // ---- Pairing code -------------------------------------------------------------------------

    fun newPairCode(rng: SecureRandom = random): String {
        val raw = buildString {
            repeat(PAIR_CODE_LENGTH) { append(PAIR_ALPHABET[rng.nextInt(PAIR_ALPHABET.length)]) }
        }
        return formatPairCode(raw)
    }

    fun formatPairCode(raw: String): String = raw.chunked(5).joinToString("-")

    /** Upper case, spaces and dashes removed. */
    fun normalizePairCode(input: String): String = input.uppercase().filter { it in PAIR_ALPHABET }

    fun isPairCodeShapeValid(input: String): Boolean = normalizePairCode(input).length == PAIR_CODE_LENGTH

    /** Public name of the invite in the database. Reveals nothing usable about the code. */
    fun inviteId(code: String): String =
        hex(MessageDigest.getInstance("SHA-256").digest("focusmode.pair.id.v1|${normalizePairCode(code)}".toByteArray()))

    /** The shared secret. It is never sent anywhere; both phones derive it from the code. */
    fun pairKey(code: String): ByteArray =
        hmac("focusmode.pair.key.v1".toByteArray(), normalizePairCode(code).toByteArray())

    // ---- Request ids ---------------------------------------------------------------------------

    fun newNonce(rng: SecureRandom = random): String =
        ByteArray(16).also { rng.nextBytes(it) }.let { hex(it) }

    fun newDeviceId(rng: SecureRandom = random): String =
        ByteArray(16).also { rng.nextBytes(it) }.let { hex(it) }

    // ---- MAC / proof ---------------------------------------------------------------------------

    /** Made by the locked phone. The trusted phone ignores any request without a valid one. */
    fun requestMac(key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String): String =
        mac(key, "req", ownerUid, requestId, nonce, deviceId)

    fun requestMacValid(
        key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String, given: String?,
    ): Boolean = same(requestMac(key, ownerUid, requestId, nonce, deviceId), given)

    /** Made by the trusted phone. Bound to this request, this device and this decision. */
    fun decisionProof(
        key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String, decision: Decision,
    ): String = mac(key, "dec", ownerUid, requestId, nonce, deviceId, decision.wire)

    fun decisionProofValid(
        key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String,
        decision: Decision, given: String?,
    ): Boolean = same(decisionProof(key, ownerUid, requestId, nonce, deviceId, decision), given)

    // ---- "More time in one app" requests -----------------------------------------------------------
    // Same idea as above, with the app, its name, the reason and (for the answer) the minutes inside
    // the signed text. The locked phone can't pass off one app as another, and the trusted phone
    // can't be tricked into a longer time than it typed. The tags differ ("reqapp" / "decapp"), so
    // an ordinary unlock request or answer can never be turned into one of these.

    fun appRequestMac(
        key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String,
        pkg: String, appName: String, reason: Int,
    ): String = mac(key, "reqapp", ownerUid, requestId, nonce, deviceId, pkg, appName, reason.toString())

    fun appRequestMacValid(
        key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String,
        pkg: String, appName: String, reason: Int, given: String?,
    ): Boolean = same(appRequestMac(key, ownerUid, requestId, nonce, deviceId, pkg, appName, reason), given)

    /** [minutes] is 0 for a rejection. */
    fun appDecisionProof(
        key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String,
        pkg: String, reason: Int, decision: Decision, minutes: Int,
    ): String = mac(key, "decapp", ownerUid, requestId, nonce, deviceId, pkg, reason.toString(), decision.wire, minutes.toString())

    fun appDecisionProofValid(
        key: ByteArray, ownerUid: String, requestId: String, nonce: String, deviceId: String,
        pkg: String, reason: Int, decision: Decision, minutes: Int, given: String?,
    ): Boolean = same(appDecisionProof(key, ownerUid, requestId, nonce, deviceId, pkg, reason, decision, minutes), given)

    /** An Android package name: letters, digits, underscores, at least one dot. */
    fun isValidPackageName(pkg: String): Boolean =
        pkg.length in 3..200 && PACKAGE_NAME.matches(pkg)

    private val PACKAGE_NAME = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    // ---- Judging a request -----------------------------------------------------------------------

    /**
     * What the locked phone should do with [snap]. [serverNowMs] comes from Firebase's server
     * clock, so changing the date on the phone doesn't stretch a request's life.
     * [alreadyUsed] is true once this request id was spent (single use).
     */
    fun evaluate(
        snap: RequestSnapshot?,
        expected: ExpectedRequest,
        serverNowMs: Long,
        alreadyUsed: Boolean,
    ): RequestOutcome {
        if (alreadyUsed) return RequestOutcome.Invalid("This request was already used.")
        if (snap == null) return RequestOutcome.Pending // not written yet / being deleted
        if (snap.nonce != expected.nonce || snap.deviceId != expected.deviceId) {
            return RequestOutcome.Invalid("The request was changed.")
        }
        // The kind is part of what was asked: a lock-screen request never turns into an app
        // request (or the other way round), and an app request keeps its app and reason.
        val appPkg = expected.pkg
        if (appPkg != null) {
            if (snap.kind != KIND_APP || snap.pkg != appPkg || snap.reason != expected.reason) {
                return RequestOutcome.Invalid("The request was changed.")
            }
        } else if (snap.kind != null) {
            return RequestOutcome.Invalid("The request was changed.")
        }
        val created = snap.createdAt ?: return RequestOutcome.Pending // server time not resolved yet
        val expiresAt = created + REQUEST_TTL_MS

        return when (snap.status) {
            "pending" ->
                if (serverNowMs > expiresAt) RequestOutcome.Expired else RequestOutcome.Pending

            "approved", "rejected" -> {
                val decision = if (snap.status == "approved") Decision.APPROVED else Decision.REJECTED
                val decidedAt = snap.decidedAt ?: return RequestOutcome.Invalid("The answer has no time.")
                if (snap.decidedBy != expected.approverUid) {
                    return RequestOutcome.Invalid("The answer is not from your trusted phone.")
                }
                var grantMinutes = 0
                val proofOk = if (appPkg != null) {
                    if (decision == Decision.APPROVED) {
                        val m = snap.minutes
                        if (m == null || m < MIN_GRANT_MIN || m > MAX_GRANT_MIN) {
                            return RequestOutcome.Invalid("The answer has no valid time.")
                        }
                        grantMinutes = m.toInt()
                    }
                    appDecisionProofValid(
                        expected.pairKey, expected.ownerUid, expected.requestId,
                        expected.nonce, expected.deviceId, appPkg, expected.reason,
                        decision, grantMinutes, snap.proof,
                    )
                } else {
                    decisionProofValid(
                        expected.pairKey, expected.ownerUid, expected.requestId,
                        expected.nonce, expected.deviceId, decision, snap.proof,
                    )
                }
                if (!proofOk) return RequestOutcome.Invalid("The answer could not be verified.")
                if (decidedAt < created || decidedAt > expiresAt) return RequestOutcome.Expired
                if (decision == Decision.REJECTED) return RequestOutcome.Rejected
                if (serverNowMs > decidedAt + CONSUME_WINDOW_MS) RequestOutcome.Expired
                else if (appPkg != null) RequestOutcome.GrantedFor(grantMinutes)
                else RequestOutcome.Approved
            }

            // consumed / cancelled / anything else is never a way in
            else -> RequestOutcome.Invalid("This request is closed.")
        }
    }

    /** The trusted phone's check before it shows or answers a request. */
    fun approverMayAnswer(
        snap: RequestSnapshot?,
        ownerUid: String,
        requestId: String,
        mac: String?,
        key: ByteArray,
        serverNowMs: Long,
    ): Boolean {
        snap ?: return false
        if (snap.status != "pending") return false
        val created = snap.createdAt ?: return false
        if (serverNowMs > created + REQUEST_TTL_MS) return false
        val nonce = snap.nonce ?: return false
        val device = snap.deviceId ?: return false
        // Remote values may hold odd characters; that is simply "not valid", never a crash.
        return runCatching {
            when (snap.kind) {
                null -> requestMacValid(key, ownerUid, requestId, nonce, device, mac)
                KIND_APP -> {
                    val pkg = snap.pkg ?: return@runCatching false
                    val name = snap.appName ?: return@runCatching false
                    val reason = snap.reason ?: return@runCatching false
                    isValidPackageName(pkg) &&
                        appRequestMacValid(key, ownerUid, requestId, nonce, device, pkg, name, reason, mac)
                }
                else -> false
            }
        }.getOrDefault(false)
    }

    // ---- Helpers ---------------------------------------------------------------------------------

    private fun mac(key: ByteArray, vararg parts: String): String {
        // '|' separates the parts, so a part can't contain one (no way to shift fields around).
        require(parts.none { '|' in it }) { "bad field" }
        return hex(hmac(key, parts.joinToString("|").toByteArray()))
    }

    private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    private fun same(expected: String, given: String?): Boolean =
        given != null && MessageDigest.isEqual(expected.toByteArray(), given.toByteArray())

    fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    fun unhex(text: String): ByteArray {
        require(text.length % 2 == 0) { "bad hex" }
        return ByteArray(text.length / 2) { text.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }
}
