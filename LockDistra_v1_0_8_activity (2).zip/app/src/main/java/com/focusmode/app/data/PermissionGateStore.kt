package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Remembers that the person pressed "Skip for now" on the permission page, so it is not shown again at every start.
 * Permissions can still be allowed later in Settings, and features that need one ask for it when they are turned on.
 * Own prefs file ("permission_gate"), per phone.
 */
class PermissionGateStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "permission_gate")

    private val _skipped = MutableStateFlow(prefs.getBoolean(K_SKIPPED, false))
    val skipped: StateFlow<Boolean> = _skipped.asStateFlow()

    @Synchronized
    fun skip() {
        prefs.edit().putBoolean(K_SKIPPED, true).commit()
        _skipped.value = true
    }

    companion object {
        private const val K_SKIPPED = "skipped"

        @Volatile
        private var instance: PermissionGateStore? = null

        fun get(context: Context): PermissionGateStore =
            instance ?: synchronized(this) {
                instance ?: PermissionGateStore(context.applicationContext).also { instance = it }
            }
    }
}
