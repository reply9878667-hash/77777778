package com.focusmode.app.service

import android.app.admin.DeviceAdminReceiver
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.focusmode.app.R
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.PomodoroStore
import com.focusmode.app.data.UsageLimitStore

/** Restores an unfinished focus session after a reboot or an app update. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            // Runs right after the restart (before unlock on supported phones) and again once
            // the phone is unlocked. Both are safe to repeat.
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON" -> {
                // Only Android itself can send the first two. The vendor "quick boot" actions can
                // be sent by any app, so they may bring a session back but never end one.
                val genuine = intent.action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
                    intent.action == Intent.ACTION_BOOT_COMPLETED
                // The cover comes FIRST, before anything else: every ms spent restoring sessions etc. is a ms
                // in which Settings can still be opened. Starting it twice (locked boot + boot) is harmless.
                runCatching { BootCoverService.trace(context, "received ${intent.action?.substringAfterLast('.')}") }
                if (genuine) runCatching { BootCoverService.startIfNeeded(context, "restart signal") }
                // If the maker's software does not bring the accessibility service back, this keeps the uninstall /
                // device-admin screens closed until it is on again (stops by itself once accessibility runs).
                if (genuine) runCatching { LostGuardService.startIfNeeded(context) }
                // One failing step must never stop the others (or the cover), so each is isolated.
                runCatching { FocusController.restoreAfterBoot(context, genuineBoot = genuine) }
                if (intent.action != Intent.ACTION_LOCKED_BOOT_COMPLETED) {
                    runCatching {
                        AutoFocusEngine.process(context)
                        AutoFocusEngine.schedule(context)
                    }
                }
                if (intent.action != Intent.ACTION_LOCKED_BOOT_COMPLETED) {
                    // Adult Content Blocking: the DNS filter does not survive a restart on its own.
                    runCatching { AdultDnsVpnService.sync(context) }
                }
                if (intent.action != Intent.ACTION_LOCKED_BOOT_COMPLETED) {
                    runCatching {
                        FocusEngine.process(context)
                        val needsBlocking = FocusStore.get(context).current().focusActive ||
                            UsageLimitStore.get(context).hasLimits()
                        if (needsBlocking && !Permissions.isAccessibilityEnabled(context)) {
                            Notifications.postNeedsAccessibility(context)
                        }
                    }
                }
            }
            // An app update is not a restart: keep the session as it is.
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                FocusController.resumeIfNeeded(context)
                AutoFocusEngine.schedule(context)
                runCatching { AdultDnsVpnService.sync(context) }
            }
        }
    }
}

/** Backup wake-up (doze-safe) for session end, emergency end and plant reminders. */
class FocusAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        FocusEngine.process(context)
        PomodoroEngine.ensureScheduled(context)
        if (FocusStore.get(context).current().focusActive || PomodoroStore.get(context).current().running) {
            // Swiping the status notification away must not hide that LockDistra is on.
            if (intent.action == ACTION_STATUS_DISMISSED) Notifications.refreshStatus(context)
            // If the system stopped the service, try to bring it back.
            try {
                ContextCompat.startForegroundService(
                    context, Intent(context, FocusService::class.java)
                )
            } catch (_: Exception) {
            }
        }
    }

    companion object {
        const val ACTION_STATUS_DISMISSED = "com.focusmode.app.action.STATUS_DISMISSED"
    }
}

/** Device admin: while active, the app cannot be uninstalled until protection is switched off. */
class FocusAdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        context.getString(R.string.admin_disable_warning)

    override fun onEnabled(context: Context, intent: Intent) {
        BootCoverService.rememberAdmin(context, true)
    }

    /** Advanced protection depends on the admin, so it switches itself off with it. */
    override fun onDisabled(context: Context, intent: Intent) {
        BootCoverService.rememberAdmin(context, false)
        FocusStore.get(context).setAdvancedProtection(false, force = true)
    }
}

/**
 * The "Yes, I'm studying" button of the plant reminder. Works without opening the app. It is not
 * exported, so only LockDistra's own notification can reach it, and the store only accepts the
 * reminder that was really posted (see GrowPolicy).
 */
class CheckInReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val store = FocusStore.get(context)
        if (store.current().focusActive) {
            store.growFromNotification(intent.getLongExtra(EXTRA_TOKEN, 0L))
        }
        Notifications.cancelReminder(context)
    }

    companion object {
        const val EXTRA_TOKEN = "check_in_token"
    }
}

/**
 * The "I'm Studying" button of the study check-in. Works without opening the app. It is not exported and the
 * store only accepts the check-in that is really waiting (see StudyCheckInRules.acceptsConfirm).
 */
class StudyCheckInReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        StudyCheckInEngine.confirm(context, intent.getLongExtra(EXTRA_SEQ, 0L))
    }

    companion object {
        const val EXTRA_SEQ = "study_checkin_seq"
    }
}
