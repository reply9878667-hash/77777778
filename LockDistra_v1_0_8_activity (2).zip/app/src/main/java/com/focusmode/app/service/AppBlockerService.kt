package com.focusmode.app.service

import android.accessibilityservice.AccessibilityService
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import com.focusmode.app.BlockActivity
import com.focusmode.app.data.AppRepository
import com.focusmode.app.data.ContentState
import com.focusmode.app.data.ContentStore
import com.focusmode.app.data.EducationMatcher
import com.focusmode.app.data.FeatureCatalog
import com.focusmode.app.data.FeatureDef
import com.focusmode.app.data.CategoryStatus
import com.focusmode.app.data.CategoryTimer
import com.focusmode.app.data.ShortFormCatalog
import com.focusmode.app.data.ShortsDetector
import com.focusmode.app.data.FeatureMatcher
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.NodeSnap
import com.focusmode.app.LectureActivity
import com.focusmode.app.data.KeywordRules
import com.focusmode.app.data.KeywordState
import com.focusmode.app.data.KeywordStore
import com.focusmode.app.data.LectureLink
import com.focusmode.app.data.LectureLockStore
import com.focusmode.app.data.LectureTarget
import com.focusmode.app.data.PomodoroStore
import com.focusmode.app.data.ShortsVerdict
import com.focusmode.app.data.FocusProfile
import com.focusmode.app.data.FocusProfileRuntime
import com.focusmode.app.data.FocusProfileStore
import com.focusmode.app.data.FocusProfilesState
import com.focusmode.app.data.AppLimit
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.PopupSchedule
import com.focusmode.app.data.SafetyConfig
import com.focusmode.app.data.ListCodec
import com.focusmode.app.data.UsageLimitStore
import com.focusmode.app.data.BedtimeStore
import com.focusmode.app.data.AdultBlockStore
import com.focusmode.app.data.AdultListUpdater
import com.focusmode.app.data.WebsiteBrowsers
import com.focusmode.app.data.WebsiteLimitRules
import com.focusmode.app.data.WebsiteLimitStore
import com.focusmode.app.data.WebsitePolicy
import com.focusmode.app.data.WebsiteRules
import com.focusmode.app.data.WebsiteState
import com.focusmode.app.data.WebsiteStore
import com.focusmode.app.data.online.AppGrantStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

/**
 * Detects which app is in front while LockDistra is on and covers blocked apps with
 * [BlockActivity].
 *
 * What it reads: the package name of the foreground window. Inside YouTube it also checks
 * whether the Shorts player is on screen (and, if the user listed educational channels, which
 * channel it belongs to). For the apps and sections the user chose under "Inside apps" it looks
 * at tab labels and view ids to see which section is open, and while uninstall protection is on
 * it checks whether a Settings / installer screen is showing this app. Screen text is only
 * compared in memory and thrown away. Nothing is sent anywhere (the app has no internet
 * permission); the only thing remembered is the handle of a blocked Shorts channel, so it can be
 * allowed later.
 *
 * Usage Access (if the user grants it) is only a fallback for finding the foreground app
 * when the window content is unavailable.
 */
/** Keyword Blocking looks at page titles / headings at most this often, and walks at most this many nodes each time. */
private const val PAGE_SCAN_GAP_MS = 1_500L
private const val PAGE_SCAN_MAX_NODES = 200

class AppBlockerService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var pollJob: Job? = null
    private lateinit var store: FocusStore

    private lateinit var limits: UsageLimitStore

    // Extra time the trusted phone gave in one app ("Request to unlock" on the block screen).
    private lateinit var grants: AppGrantStore
    private lateinit var content: ContentStore
    private var contentState = ContentState()
    private lateinit var bedtime: BedtimeStore
    private lateinit var websiteStore: WebsiteStore
    private lateinit var adult: AdultBlockStore
    private var websiteState = WebsiteState()
    private lateinit var keywordStore: KeywordStore
    private var keywordState = KeywordState()
    private var lastPageScanAt = 0L
    // Saved Focus Profiles: while a session runs, the selected one supplies the Focus restrictions (see FocusProfileRuntime).
    private lateinit var profileStore: FocusProfileStore
    private var profilesState = FocusProfilesState()
    private var lastWebsiteCheckAt = 0L
    private var overlay: TimerOverlay? = null

    // Website Usage Limits: time on a site in a supported browser. The host comes from the browser's address bar (see
    // enforceWebsite / noteSite); siteTrackLoop turns "this site is on screen" into seconds, and the limit is checked there.
    private lateinit var siteLimits: WebsiteLimitStore
    private var siteJob: Job? = null
    private var siteJobPkg: String? = null
    private var siteHost: String? = null
    private var siteReadAt = 0L
    private val pendingSiteMs = HashMap<String, Long>()

    // Lecture Lock: the one video (any platform) allowed during the session. It plays in LectureActivity; the platform's
    // own app and site are closed meanwhile, so no other video of that platform can play.
    private lateinit var lecture: LectureLockStore
    private var lectureKey: String? = null
    private var lectureSeenAt = 0L
    private var lectureOpened = false
    private var lastLectureRedirectAt = 0L

    // Educational Shorts: when the current Short's channel first showed up (or didn't).
    private var shortsSig: String? = null
    private var shortsSigSince = 0L

    // "Inside apps" sections: gentle exit first, then Back, then the block screen.
    private var featureId: String? = null
    private var featureAttempts = 0
    private var featureLastSeen = 0L
    private var featureSettleUntil = 0L

    private var lastBlockAt = 0L
    private var lastContentCheckAt = 0L

    // Daily usage tracking (see trackLoop).
    private var currentFg: String? = null
    private var trackJob: Job? = null
    private var trackedPkg: String? = null
    private var screenIsOn = true
    private var receiverRegistered = false
    private var lastReconcileAt = 0L
    private var settingsPkg = "com.android.settings"
    private var lastWindowClass: String? = null
    private var pendingUsageMs = 0L

    /** True once the "Unlocked" countdown was shown, so its end can be noticed. */
    private var grantWasShown = false
    private var imePackages: Set<String> = emptySet()

    // Window class of the app screen that is really in front (ignores keyboards and system UI).
    private var fgWindowPkg: String? = null
    private var fgWindowClass: String? = null

    // Time spent on limited Shorts / Reels / Status that is not saved yet (content id -> ms).
    private val pendingCatMs = HashMap<String, Long>()

    // Floating timer for Shorts / Reels / Status limits: when the content was last seen on screen
    // (so one missed read does not make the timer blink) and the popup counter for it.
    private var catShownId: String? = null
    private var catLastSeenAt = 0L
    private val catSinceMs = HashMap<String, Long>()
    private var watchdogJob: Job? = null

    // ---- Direct boot -----------------------------------------------------------------------------
    // This service is direct-boot aware: Android binds it right after a restart, BEFORE the first unlock, so the
    // uninstall guard is already running when the person unlocks (no gap). Until unlock only device-protected
    // storage exists, so that first phase ("locked guard") touches nothing else. Everything else starts in
    // fullInit() the moment the phone is unlocked (or at once, when the service starts on an unlocked phone).

    @Volatile private var fullyReady = false
    private var upgrading = false
    private var lastUpgradeTryAt = 0L
    private var unlockReceiver: BroadcastReceiver? = null
    private var lastLockedGuardAt = 0L

    private fun isUserUnlockedNow(): Boolean =
        Build.VERSION.SDK_INT < 24 ||
            (getSystemService(Context.USER_SERVICE) as android.os.UserManager).isUserUnlocked

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val unlocked = isUserUnlockedNow()
        BootCoverService.trace(this, "accessibility connected " + if (unlocked) "AFTER unlock (late)" else "BEFORE unlock (good)")
        if (unlocked) {
            fullInit()
            return
        }
        // Phone restarted and is still locked: minimal, crash-proof protection only.
        try {
            store = FocusStore.get(this)
            settingsPkg = AppRepository.settingsPackage(this)
            val r = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    upgradeToFull()
                }
            }
            ContextCompat.registerReceiver(
                this, r, IntentFilter(Intent.ACTION_USER_UNLOCKED), ContextCompat.RECEIVER_NOT_EXPORTED
            )
            unlockReceiver = r
            // Protection is running (the after-restart cover can go).
            connected = true
            BootCoverService.rememberAccessibility(this, true)
        } catch (_: Exception) {
            // Could not even start the light guard: stay as before (the cover keeps covering until unlock).
        }
    }

    /** Runs the full start-up once the phone is unlocked. A failure leaves the locked guard running. */
    private fun upgradeToFull() {
        if (fullyReady || upgrading) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastUpgradeTryAt < 3_000L) return
        lastUpgradeTryAt = now
        upgrading = true
        try {
            fullInit()
            BootCoverService.trace(this, "full start-up done after unlock")
        } catch (e: Exception) {
            BootCoverService.trace(this, "full start-up FAILED: ${e.javaClass.simpleName}")
            // Stay in the locked guard; the next event / broadcast tries again.
        } finally {
            upgrading = false
        }
    }

    /**
     * Before the full start-up has finished: close only the screens that can remove LockDistra (same rule as normal),
     * by going Home. Never throws.
     */
    private fun lockedGuardEvent(event: AccessibilityEvent) {
        try {
            if (!::store.isInitialized || !SafetyConfig.UNINSTALL_PROTECTION) return
            if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            ) return
            val pkg = event.packageName?.toString() ?: return
            if (pkg == packageName) return
            val s = store.current()
            if (!(isGuardedPkg(pkg) || (pkg == PLAY_STORE && s.advancedProtection))) return
            if (!isProtectedScreen(pkg, s)) return
            val now = SystemClock.elapsedRealtime()
            if (now - lastLockedGuardAt < 250) return
            lastLockedGuardAt = now
            performGlobalAction(GLOBAL_ACTION_HOME)
            BootCoverService.trace(this, "locked guard closed $pkg")
        } catch (_: Exception) {
        }
    }

    private fun fullInit() {
        store = FocusStore.get(this)
        limits = UsageLimitStore.get(this)
        grants = AppGrantStore.get(this)
        content = ContentStore.get(this)
        contentState = content.state.value
        scope.launch { content.state.collect { contentState = it } }
        bedtime = BedtimeStore.get(this)
        runCatching { BedtimeEngine.sync(this) }
        websiteStore = WebsiteStore.get(this)
        websiteState = websiteStore.state.value
        siteLimits = WebsiteLimitStore.get(this)
        // A website limit added, switched on / off or removed while a browser is in front starts / stops the counting.
        scope.launch { siteLimits.state.map { it.limits }.distinctUntilChanged().collect { ensureTracking() } }
        adult = AdultBlockStore.get(this)
        // Install the bundled adult-site database (disk work, off the main thread) and, if due, check for a newer one.
        scope.launch(Dispatchers.IO) {
            runCatching { adult.ensureInstalled() }
            runCatching { if (AdultListUpdater.due(adult.current())) AdultListUpdater.update(adult) }
        }
        scope.launch { websiteStore.state.collect { websiteState = it } }
        keywordStore = KeywordStore.get(this)
        keywordState = keywordStore.state.value
        scope.launch { keywordStore.state.collect { keywordState = it } }
        lecture = LectureLockStore.get(this)
        // The lecture belongs to one session: forget it the moment the session (Focus or Pomodoro) is over.
        val pomodoroStore = PomodoroStore.get(this)
        scope.launch {
            var wasRunning = false
            combine(store.state.map { it.focusActive }, pomodoroStore.state.map { it.active }) { f, p -> f || p }
                .distinctUntilChanged()
                .collect { running ->
                    if (!running && wasRunning) lecture.clear()
                    if (!running) {
                        lectureKey = null
                        lectureOpened = false
                    }
                    wasRunning = running
                }
        }
        profileStore = FocusProfileStore.get(this)
        profilesState = profileStore.state.value
        // A profile switch, edit or delete (or a session start / end) changes which limits apply: re-check what to count.
        scope.launch {
            combine(profileStore.state, store.state.map { it.focusActive }.distinctUntilChanged()) { p, _ -> p }
                .collect { profilesState = it; ensureTracking() }
        }
        overlay = TimerOverlay(this)
        Notifications.ensureChannels(this)
        imePackages = loadImePackages()
        settingsPkg = AppRepository.settingsPackage(this)
        screenIsOn = (getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
        registerSystemReceiver()
        // Run the safety-net poll only while a session is active.
        scope.launch {
            store.state.map { it.focusActive }.distinctUntilChanged().collect { active ->
                pollJob?.cancel()
                if (active) pollJob = launch { pollLoop() }
            }
        }
        // After a reboot the accessibility service is restored by Android; make sure the
        // foreground service and alarms follow.
        FocusController.resumeIfNeeded(this)
        // After a restart the foreground app may already be a limited one.
        foregroundPackage()?.let { if (it !in ignoredForeground && it !in imePackages) setForeground(it) }
        reconcileUsage(force = true)
        startWatchdog()
        // Tells the after-restart cover (BootCoverService) that protection is running now.
        fullyReady = true
        fullyConnected = true
        unlockReceiver?.let { r ->
            try { unregisterReceiver(r) } catch (_: Exception) {}
            unlockReceiver = null
        }
        connected = true
        BootCoverService.rememberAccessibility(this, true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (!::store.isInitialized) return
        if (!fullyReady) {
            // Missed the unlock broadcast? The first event after unlock finishes the start-up.
            if (isUserUnlockedNow()) upgradeToFull()
            if (!fullyReady) {
                lockedGuardEvent(event)
                return
            }
        }
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) {
            // Our own screens (block screen, main app) mean the limited app is no longer in front.
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
                event.className?.toString()?.endsWith("Activity") == true
            ) setForeground(pkg)
            return
        }
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            lastWindowClass = event.className?.toString()
            if (pkg !in ignoredForeground && pkg !in imePackages) {
                fgWindowPkg = pkg
                fgWindowClass = event.className?.toString()
                setForeground(pkg)
            }
        }

        val s = store.current()
        // Website blocking: only browsers, and only while some site rule is actually in force.
        if (WebsiteBrowsers.isSupported(pkg) &&
            (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) &&
            enforceWebsite(pkg, s)
        ) return
        // Outside a focus session only two things are enforced: a daily app limit, and the
        // advanced uninstall protection for the few system screens that can remove this app.
        if (!s.focusActive) {
            val limited = limitFor(pkg) != null || limits.hasCategoryLimit(pkg) || bedtimeBlocks(pkg)
            val guarded = SafetyConfig.UNINSTALL_PROTECTION && s.advancedProtection &&
                (isGuardedPkg(pkg) || pkg == PLAY_STORE)
            if (!limited && !guarded) return
        }

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                handleForeground(pkg, s)
                // The page's texts ("LockDistra", "Uninstall") are often drawn a moment AFTER the window opens, so the
                // first look can miss them: look again a few times within the first two seconds.
                if (isGuardCandidate(pkg, s)) scheduleGuardRecheck(pkg)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                // Content events are very frequent, so only look at the few packages we care
                // about and at most a couple of times per second.
                val relevant = pkg == AppRepository.YOUTUBE ||
                    (SafetyConfig.UNINSTALL_PROTECTION &&
                        (isGuardedPkg(pkg) || (pkg == PLAY_STORE && s.advancedProtection))) ||
                    FocusProfileRuntime.content(contentState, activeProfile(s)).watches(pkg) || limits.hasCategoryLimit(pkg)
                if (!relevant) return
                // A background app's late content event is not "the person is in that app".
                if (otherAppInFront(pkg)) return
                val now = SystemClock.elapsedRealtime()
                val gap = if (isGuardCandidate(pkg, s)) GUARD_CONTENT_GAP_MS else 500L
                if (now - lastContentCheckAt < gap) return
                lastContentCheckAt = now
                handleForeground(pkg, s)
            }
        }
    }

    // ---- Focus Profile: which settings the session uses ---------------------------------------

    /** The selected Focus Profile while a session runs; null in a Pomodoro Break, outside a session or without a profile. */
    private fun activeProfile(s: FocusState): FocusProfile? =
        if (::profileStore.isInitialized) FocusProfileRuntime.active(s, profilesState) else null

    /** The daily limit in force for [pkg]: normal limit, the profile's limit, or the stricter of the two. */
    private fun limitFor(pkg: String): AppLimit? =
        FocusProfileRuntime.limitFor(limits.limitFor(pkg), activeProfile(store.current()), pkg)

    private fun limitReached(pkg: String): Boolean =
        limitFor(pkg)?.let { limits.usedMs(pkg) >= it.limitMs } ?: false

    private fun handleForeground(pkg: String, s: FocusState) {
        // Uninstall protection: keep the user out of Settings/installer pages for this app.
        // Basic protection covers focus sessions; advanced protection also covers the time
        // between sessions (see isProtectedScreen).
        if (isProtectedScreen(pkg, s)) {
            BootCoverService.trace(this, "guard closed $pkg")
            block(pkg, BlockActivity.REASON_PROTECTION)
            return
        }

        // Bedtime Mode: its own schedule and its own app list, checked from the clock. It does not
        // depend on a focus session, and extra time or Emergency access for the other rules does not open it.
        if (bedtimeBlocks(pkg)) {
            block(pkg, BlockActivity.REASON_BEDTIME)
            return
        }

        // Extra time from the trusted phone ("Request to unlock"): while it runs, this one app is
        // not closed for its focus block or its daily limits. Uninstall protection above and the
        // rules inside the app (Shorts / Reels sections) are not affected.
        val granted = grants.isActive(pkg)

        // Daily app limit: once today's time is used up, the app stays closed until tomorrow
        // or until the limit is changed (or the trusted phone gives extra time).
        // An Emergency window (a few minutes, started from the block screen) lets the app stay open;
        // the time keeps counting and the app closes again when the window ends.
        if (limitReached(pkg) && !granted && !limits.emergencyActive(pkg)) {
            block(pkg, BlockActivity.REASON_LIMIT)
            return
        }

        // Daily limit for Shorts / Reels / Status: if today's time is already used up, close that
        // content the moment it appears. Like the app limit above, an emergency window does not
        // lift it; the focus-session Emergency only opens apps that LockDistra itself is blocking.
        // (A limit has its own Emergency window, handled in categoryTick.)
        if (limits.hasCategoryLimit(pkg) && !granted) categoryTick(pkg, 0L)  // enforce only

        if (!s.focusActive) return
        // An emergency window opens only the app it was started for; everything else stays blocked.
        if (s.emergencyCovers(pkg, System.currentTimeMillis())) return

        // Lecture Lock: the lecture's platform (its app) stays closed, so no other video of it can play.
        // The lecture itself plays in LockDistra's own player.
        if (!granted) {
            val lt = activeLecture()
            if (lt != null && lt.blocksApp(pkg)) {
                redirectToLecture(lt, pkg)
                return
            }
        }

        val profile = activeProfile(s)
        if (pkg in FocusProfileRuntime.blocked(s, profile)) {
            if (pkg == settingsPkg) {
                // Settings is never closed as a whole (Wi-Fi, display, other apps' App info ... keep working in a
                // session, just like outside one). Only LockDistra's own App info / uninstall / device-admin /
                // Accessibility screens are closed, by isProtectedScreen() above.
                return
            }
            if (granted) return
            block(pkg, BlockActivity.REASON_APP)
        } else {
            enforceInsideApp(pkg, s)
        }
    }

    /**
     * Whether Bedtime Mode closes [pkg] right now. LockDistra itself and the Settings app are never
     * closed by it, so the person can always reach the way out (and calls / emergency stay untouched:
     * those apps are not offered for selection either).
     */
    private fun bedtimeBlocks(pkg: String): Boolean =
        ::bedtime.isInitialized && pkg != packageName && pkg != settingsPkg &&
            AppRepository.isBlockable(pkg, packageName) && bedtime.blocks(pkg)

    // ---- Website blocking -------------------------------------------------------------------

    /** Site rules in force right now, as (rules, owner app): see [FocusProfileRuntime.websiteRules]. */
    private fun enforcingRules(s: FocusState): List<Pair<WebsiteState, String>> {
        val now = System.currentTimeMillis()
        return FocusProfileRuntime.websiteRules(
            global = websiteState,
            profile = activeProfile(s),
            focusActive = s.focusActive,
            sessionOpensOwner = { owner -> s.emergencyCovers(owner, now) },
            limitBlocks = { owner -> limitReached(owner) && !limits.emergencyActive(owner) },
            extraTime = { owner -> grants.isActive(owner) },
        )
    }

    /**
     * Reads the address bar of the browser in front and, if it shows a blocked site, covers the
     * browser with the block screen. Only the address bar text is read, only in the listed
     * browsers, and only while a site rule is in force. Returns true when it blocked.
     */
    @Suppress("DEPRECATION")
    private fun enforceWebsite(pkg: String, s: FocusState): Boolean {
        if (!::websiteStore.isInitialized) return false
        // Adult-site protection is always on while its switch is on: no session or limit is needed.
        val adultOn = ::adult.isInitialized && adult.isActive()
        val rules = enforcingRules(s)
        // Lecture Lock: the lecture's site is closed in the browsers (the lecture itself plays in LockDistra's player).
        val lectureSites = activeLecture()?.blockedHosts.orEmpty()
        // Keyword Blocking: always on while its switch is on and a keyword is on (no session needed), like Adult protection.
        val keywordsOn = ::keywordStore.isInitialized && keywordState.isActive
        // Website Usage Limits: the address bar is read to know which site is on screen (time) and to close a site whose limit is used up.
        val siteLimitsOn = ::siteLimits.isInitialized && siteLimits.hasEnabled()
        if (rules.isEmpty() && !adultOn && lectureSites.isEmpty() && !keywordsOn && !siteLimitsOn) return false
        val now = SystemClock.elapsedRealtime()
        // When only a website limit needs the address bar, look less often (battery): usage is counted per second anyway.
        val onlyLimits = rules.isEmpty() && !adultOn && lectureSites.isEmpty() && !keywordsOn
        if (now - lastWebsiteCheckAt < (if (onlyLimits) SITE_LIMIT_READ_GAP_MS else 350L)) return false
        lastWebsiteCheckAt = now
        val root = rootInActiveWindow ?: return false
        try {
            if (root.packageName?.toString() != pkg) return false
            val raw = readAddressBar(root, pkg) ?: return false
            if (siteLimitsOn) noteSite(WebsiteRules.normalize(raw))
            if (adultOn) {
                // The person's own words: anything in the address bar (a typed search too) that contains one.
                val word = adult.blockedWord(raw)
                if (word != null) {
                    block(pkg, BlockActivity.REASON_ADULT, detail = word)
                    return true
                }
            }
            if (keywordsOn) {
                // 1) The address bar: the link or the search text (cheap: one string, a few words to compare).
                val hit = KeywordRules.firstHit(keywordState, raw)
                if (hit != null) {
                    block(pkg, BlockActivity.REASON_KEYWORD, detail = hit.word)
                    return true
                }
                // 2) The page title and headings the browser exposes: a small, rate-limited look (best effort).
                if (keywordState.checkPages && now - lastPageScanAt >= PAGE_SCAN_GAP_MS) {
                    lastPageScanAt = now
                    for (text in readPageInfo(root)) {
                        val h = KeywordRules.firstHit(keywordState, text) ?: continue
                        block(pkg, BlockActivity.REASON_KEYWORD, detail = h.word)
                        return true
                    }
                }
            }
            val host = WebsiteRules.normalize(raw) ?: return false
            if (adultOn && adult.blocks(host)) {
                block(pkg, BlockActivity.REASON_ADULT, detail = host)
                return true
            }
            if (lectureSites.isNotEmpty() && LectureLink.hostMatchesAny(host, lectureSites)) {
                activeLecture()?.let { redirectToLecture(it, pkg) }
                return true
            }
            if (siteLimitsOn) {
                // Daily limit of this site used up: the site stays closed until tomorrow (or until the limit is changed).
                val limit = siteLimits.limitFor(host)
                if (limit != null && siteLimits.isReached(limit.domain)) {
                    block(pkg, BlockActivity.REASON_WEBSITE_LIMIT, detail = limit.domain)
                    return true
                }
            }
            if (rules.isEmpty()) return false
            val (owner, rule) = FocusProfileRuntime.firstMatch(rules, host) ?: return false
            block(pkg, BlockActivity.REASON_WEBSITE, detail = ListCodec.pair(owner, rule.domain))
            return true
        } finally {
            root.recycle()
        }
    }

    /**
     * Remembers which site the address bar showed just now ([host] is null when it showed something that is not a site,
     * such as text being typed or a new tab) and when. Usage is only counted while this is recent (see [WebsiteLimitRules.countsNow]).
     */
    private fun noteSite(host: String?) {
        siteHost = host
        siteReadAt = SystemClock.elapsedRealtime()
    }

    /**
     * The page information a supported browser makes available to accessibility: the window (page) title and the
     * visible headings. It never reads the whole page: at most [PAGE_SCAN_MAX_NODES] nodes are visited, and only
     * headings are collected. What a browser exposes depends on the browser and the page; a page that exposes nothing
     * is simply not checked here (the address bar check still applies).
     */
    @Suppress("DEPRECATION")
    private fun readPageInfo(root: AccessibilityNodeInfo): List<String> {
        val out = ArrayList<String>(8)
        try {
            val window = root.window
            window?.title?.toString()?.takeIf { it.isNotBlank() }?.let { out += it.take(200) }
            if (Build.VERSION.SDK_INT < 33) window?.recycle()
        } catch (_: Exception) {
        }
        var visited = 0
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (visited++ > PAGE_SCAN_MAX_NODES || depth > 20 || out.size >= 12) return
            if (Build.VERSION.SDK_INT >= 28 && n.isHeading && n.isVisibleToUser) {
                val t = (n.text ?: n.contentDescription)?.toString()
                if (!t.isNullOrBlank()) out += t.take(200)
            }
            for (i in 0 until n.childCount) {
                val child = n.getChild(i) ?: continue
                walk(child, depth + 1)
                if (Build.VERSION.SDK_INT < 33) child.recycle()
            }
        }
        walk(root, 0)
        return out
    }

    @Suppress("DEPRECATION")
    private fun readAddressBar(root: AccessibilityNodeInfo, pkg: String): String? {
        for (id in WebsiteBrowsers.urlBarIds(pkg)) {
            val nodes = try {
                root.findAccessibilityNodeInfosByViewId(id)
            } catch (_: Exception) {
                emptyList<AccessibilityNodeInfo>()
            }
            for (n in nodes) {
                val t = n.text?.toString()
                if (!t.isNullOrBlank() && n.isVisibleToUser) return t
            }
        }
        // Fallback for versions that renamed the view: a visible text field near the top of the
        // screen. Bounded walk, and only ever done inside the listed browsers.
        var found: String? = null
        var visited = 0
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (found != null || visited++ > 120 || depth > 14) return
            val isField = n.className?.toString()?.endsWith("EditText") == true ||
                n.viewIdResourceName?.contains("url", ignoreCase = true) == true
            if (isField && n.isVisibleToUser) {
                val t = n.text?.toString()
                if (!t.isNullOrBlank() && WebsiteRules.normalize(t) != null) {
                    found = t
                    return
                }
            }
            for (i in 0 until n.childCount) {
                val child = n.getChild(i) ?: continue
                walk(child, depth + 1)
                if (Build.VERSION.SDK_INT < 33) child.recycle()
            }
        }
        walk(root, 0)
        return found
    }

    // ---- Inside apps: sections and educational Shorts ---------------------------------------

    /**
     * Looks inside an app that is allowed during the session. Works from one snapshot of the
     * screen so the tree is walked once per check: first the sections the user switched off
     * (Reels, Search, Home feed, own sections), then YouTube Shorts.
     */
    @Suppress("DEPRECATION")
    private fun enforceInsideApp(pkg: String, s: FocusState) {
        // Games are never inspected or tapped: no screen reading, no injected Back / click.
        if (GameApps.isGame(this, pkg)) return
        val profile = activeProfile(s)
        val checkShorts = pkg == AppRepository.YOUTUBE && FocusProfileRuntime.blockShorts(s, profile)
        val defs = FocusProfileRuntime.content(contentState, profile).activeDefs(pkg)
        if (!checkShorts && defs.isEmpty()) return

        val root = rootInActiveWindow ?: return
        try {
            if (root.packageName?.toString() != pkg) return
            val nodes = snapshot(root)

            val windowClass = if (fgWindowPkg == pkg) fgWindowClass.orEmpty() else ""
            val hit = defs.firstOrNull { FeatureMatcher.matches(it.selector, nodes, windowClass) }
            if (hit != null) {
                resetShortsTracking()
                handleSectionHit(pkg, hit, root)
                return
            }

            if (checkShorts && isShortsVisible(root)) handleShorts(pkg, nodes) else resetShortsTracking()
        } finally {
            root.recycle()
        }
    }

    // ---- Lecture Lock ---------------------------------------------------------------------------

    /** The lecture of the running Focus session, or null when there is none. */
    private fun activeLecture(): LectureTarget? =
        if (::lecture.isInitialized && store.current().focusActive) lecture.target else null

    /** Opens the lecture in LockDistra's own player (it plays only that one video). */
    private fun openLecture() {
        val url = lecture.url ?: return
        try {
            startActivity(LectureActivity.launchIntent(this, url))
        } catch (_: Exception) {
        }
    }

    /** The platform's app (or site) came to the front: bring the person back to the lecture. */
    private fun redirectToLecture(lt: LectureTarget, pkg: String) {
        // The platform's app is not really in front (a background event of it): do not drag LockDistra to the screen.
        if (otherAppInFront(pkg)) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastLectureRedirectAt < 1_500) return
        lastLectureRedirectAt = now
        toast("Only your lecture video can play")
        openLecture()
    }

    /**
     * Makes sure the lecture really opens the moment the session begins. The app itself opens it too; this is the
     * backup that does not depend on LockDistra being on screen: if the player is not showing a few seconds into the
     * session, it is opened here.
     */
    private fun ensureLectureOpen(s: FocusState) {
        if (!::lecture.isInitialized) return
        if (lecture.target == null) return
        val now = SystemClock.elapsedRealtime()
        // The time the timer stood still is taken out, so the key changes only when a new session starts.
        val key = "${s.sessionStart - s.lectureShiftMs}:${lecture.url}"
        if (key != lectureKey) {
            lectureKey = key
            lectureSeenAt = now
            lectureOpened = false
        }
        if (lectureOpened) return
        if (LectureActivity.visible) {
            lectureOpened = true
        } else if (now - lectureSeenAt >= LECTURE_OPEN_WAIT_MS) {
            lectureOpened = true
            openLecture()
        }
    }

    private fun handleShorts(pkg: String, nodes: List<NodeSnap>) {
        val cs = contentState
        if (!cs.hasShortsExceptions) {
            block(pkg, BlockActivity.REASON_SHORTS)
            return
        }
        val now = SystemClock.elapsedRealtime()
        // A new Short (different channel on screen) restarts the short wait for its details.
        val sig = EducationMatcher.guessChannel(nodes) ?: ""
        if (sig != shortsSig || shortsSigSince == 0L) {
            shortsSig = sig
            shortsSigSince = now
        }
        val graceOver = now - shortsSigSince >= SHORTS_GRACE_MS
        when (val v = EducationMatcher.judge(nodes, cs.channels, cs.autoDetect, graceOver)) {
            is ShortsVerdict.Allow -> Unit
            ShortsVerdict.Wait -> Unit // the 1.2 s safety poll looks again
            is ShortsVerdict.Block -> {
                v.channel?.let { content.noteBlockedChannel(it) }
                block(pkg, BlockActivity.REASON_SHORTS, detail = v.channel.orEmpty())
                resetShortsTracking()
            }
        }
    }

    private fun resetShortsTracking() {
        shortsSig = null
        shortsSigSince = 0L
    }

    /**
     * A blocked section is open. Android gives no "block this section" call, so this escalates:
     * tap a safe tab, then press Back, then cover the app with the block screen. Each step waits
     * for the previous one to settle so a transition can't trigger the next step by mistake.
     */
    private fun handleSectionHit(
        pkg: String,
        def: FeatureDef,
        root: AccessibilityNodeInfo,
        limitCategoryId: String? = null,
    ) {
        val now = SystemClock.elapsedRealtime()
        if (featureId != def.id || now - featureLastSeen > FEATURE_FORGET_MS) featureAttempts = 0
        featureId = def.id
        featureLastSeen = now
        if (now < featureSettleUntil) return

        featureAttempts++
        featureSettleUntil = now + FEATURE_SETTLE_MS
        val appName = labelFor(pkg)
        val message = if (limitCategoryId != null) "Today's ${def.title} limit is used up"
        else "${def.title} is blocked while LockDistra is on"
        when {
            featureAttempts == 1 && tapSafeTab(root, def) -> toast(message)
            featureAttempts <= 2 -> {
                performGlobalAction(GLOBAL_ACTION_BACK)
                toast(message)
            }
            else -> {
                featureAttempts = 0
                if (limitCategoryId != null) block(pkg, BlockActivity.REASON_CATEGORY, detail = limitCategoryId)
                else block(pkg, BlockActivity.REASON_FEATURE, detail = "${def.title} in $appName")
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun tapSafeTab(root: AccessibilityNodeInfo, def: FeatureDef): Boolean {
        for (label in def.redirectLabels) {
            val candidates = try {
                root.findAccessibilityNodeInfosByText(label)
            } catch (_: Exception) {
                emptyList<AccessibilityNodeInfo>()
            }
            for (node in candidates) {
                val matches = node.isVisibleToUser && !node.isSelected &&
                    (FeatureMatcher.labelMatches(label, node.text?.toString().orEmpty()) ||
                        FeatureMatcher.labelMatches(label, node.contentDescription?.toString().orEmpty()))
                if (!matches) continue
                var target: AccessibilityNodeInfo? = node
                var hops = 0
                while (target != null && !target.isClickable && hops < 4) {
                    target = target.parent
                    hops++
                }
                if (target != null && target.isClickable && target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
        }
        return false
    }

    private fun toast(text: String) {
        try {
            Toast.makeText(applicationContext, text, Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
        }
    }

    /** A bounded, read-only copy of what is on screen. Invisible subtrees are skipped. */
    @Suppress("DEPRECATION")
    private fun snapshot(root: AccessibilityNodeInfo): List<NodeSnap> {
        val out = ArrayList<NodeSnap>(96)
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (out.size >= SNAPSHOT_MAX_NODES) return
            val visible = n.isVisibleToUser
            val text = n.text?.toString().orEmpty().ifEmpty { n.hintText?.toString().orEmpty() }
            out.add(
                NodeSnap(
                    id = n.viewIdResourceName.orEmpty(),
                    text = text.take(SNAPSHOT_MAX_TEXT),
                    desc = n.contentDescription?.toString().orEmpty().take(SNAPSHOT_MAX_TEXT),
                    cls = n.className?.toString().orEmpty(),
                    selected = n.isSelected,
                    visible = visible,
                )
            )
            if (depth >= SNAPSHOT_MAX_DEPTH || (!visible && depth > 0)) return
            for (i in 0 until n.childCount) {
                val child = n.getChild(i) ?: continue
                walk(child, depth + 1)
                if (Build.VERSION.SDK_INT < 33) child.recycle()
            }
        }
        walk(root, 0)
        return out
    }

    /**
     * True when Android clearly shows a DIFFERENT app than [pkg] in front right now (LockDistra's own lecture player or
     * another app). Late events of a background app (a playing video, a floating window, a stale foreground guess) must
     * never pull LockDistra's focus / block screen over the app the person is really using. When the front window cannot
     * be read (null, system UI, keyboard) this says false, so a genuine block is not skipped.
     */
    @Suppress("DEPRECATION")
    private fun otherAppInFront(pkg: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val front = try {
            root.packageName?.toString()
        } finally {
            root.recycle()
        }
        return front != null && front != pkg && front !in ignoredForeground && front !in imePackages
    }

    // ---- "Continue to <app>" ------------------------------------------------------------------
    // The block screen of a blocked Shorts / section / website offers "Continue to YouTube / Chrome".
    // The person stays INSIDE the app: for a short while, whenever that same blocked content is found again,
    // it is closed with Back instead of covering the app, until the app shows something that is allowed.

    private var continuePkg: String? = null
    private var continueUntil = 0L
    private var continueBacks = 0
    private var lastContinueBackAt = 0L

    /** Called by the block screen when the person chose to carry on in [pkg]. */
    fun continueInApp(pkg: String) {
        continuePkg = pkg
        continueUntil = SystemClock.elapsedRealtime() + CONTINUE_WINDOW_MS
        continueBacks = 0
        lastContinueBackAt = 0L
        // The cover is closing right now; look at the app again a moment later.
        scope.launch {
            delay(CONTINUE_FIRST_LOOK_MS)
            try {
                if (pkg != continuePkg) return@launch
                val s = store.current()
                if (WebsiteBrowsers.isSupported(pkg)) enforceWebsite(pkg, s) else enforceInsideApp(pkg, s)
            } catch (_: Exception) {
            }
        }
    }

    /** True when [reason] on [pkg] was just handled by "Continue" (Back pressed, or nothing left to do). */
    private fun handledByContinue(pkg: String, reason: Int): Boolean {
        if (pkg != continuePkg || !BlockActivity.canContinue(reason)) return false
        val now = SystemClock.elapsedRealtime()
        if (now >= continueUntil || continueBacks >= CONTINUE_MAX_BACKS) {
            // Back did not get away from it: show the cover again rather than let blocked content through.
            continuePkg = null
            return false
        }
        if (now - lastContinueBackAt >= CONTINUE_BACK_GAP_MS) {
            lastContinueBackAt = now
            continueBacks++
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
        return true
    }

    private fun block(pkg: String, reason: Int, detail: String = "") {
        if (otherAppInFront(pkg)) return
        if (handledByContinue(pkg, reason)) return
        val now = SystemClock.elapsedRealtime()
        val guard = reason == BlockActivity.REASON_PROTECTION
        if (now - lastBlockAt < (if (guard) 250L else 700L)) return
        lastBlockAt = now
        // Uninstall / Settings guard: leave that screen at once (Home), the block screen follows right behind it.
        // Waiting for the block screen to open first is what left time to tap "Uninstall".
        if (guard) performGlobalAction(GLOBAL_ACTION_HOME)
        val intent = Intent(this, BlockActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            )
            putExtra(BlockActivity.EXTRA_PACKAGE, pkg)
            putExtra(BlockActivity.EXTRA_REASON, reason)
            putExtra(BlockActivity.EXTRA_DETAIL, detail)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            // If Android refuses to start the screen, at least leave the blocked app.
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
    }

    // ---- Daily usage tracking ---------------------------------------------------------------

    private fun setForeground(pkg: String) {
        if (pkg != currentFg) {
            flushUsage()
            currentFg = pkg
        }
        ensureTracking()
    }

    /** Starts or stops the one-second counter so it only runs when it has something to count. */
    private fun ensureTracking() {
        ensureSiteTracking()
        val pkg = currentFg
        val shouldTrack = pkg != null && pkg != packageName && screenIsOn &&
            (limitFor(pkg) != null || limits.hasCategoryLimit(pkg) || grants.isActive(pkg))
        if (!shouldTrack || pkg == null) {
            trackJob?.cancel()
            trackJob = null
            trackedPkg = null
            overlay?.hide()
            return
        }
        if (trackJob?.isActive == true && trackedPkg == pkg) return
        trackJob?.cancel()
        overlay?.hide()
        trackedPkg = pkg
        reconcileUsage()
        trackJob = scope.launch { trackLoop(pkg) }
    }

    /**
     * Starts or stops the website counter. It runs only while a supported browser is in front, the screen is on and at
     * least one website limit is ON, so it costs nothing the rest of the time.
     */
    private fun ensureSiteTracking() {
        val pkg = currentFg
        val should = ::siteLimits.isInitialized && pkg != null && pkg != packageName && screenIsOn &&
            WebsiteBrowsers.isSupported(pkg) && siteLimits.hasEnabled()
        if (!should || pkg == null) {
            if (siteJob != null) {
                flushSiteUsage()
                siteJob?.cancel()
                siteJob = null
                siteJobPkg = null
            }
            // Leaving the browser forgets the site: coming back counts again only after the address bar was read.
            siteHost = null
            return
        }
        if (siteJob?.isActive == true && siteJobPkg == pkg) return
        siteJob?.cancel()
        siteJobPkg = pkg
        siteJob = scope.launch { siteTrackLoop(pkg) }
    }

    private fun flushSiteUsage() {
        if (pendingSiteMs.isEmpty() || !::siteLimits.isInitialized) return
        for ((domain, ms) in pendingSiteMs) if (ms > 0L) siteLimits.addUsage(domain, ms)
        pendingSiteMs.clear()
    }

    /**
     * Counts time on the site that is on screen in the browser [pkg], one second at a time, and closes the site when
     * its daily limit is used up. Saves every few seconds. The site comes from the address bar ([noteSite]); when the
     * browser hides its bar (scrolling) the last site keeps counting for a few minutes, then counting pauses until the
     * bar can be read again. Nothing is counted for a browser in the background, a site in another tab, or while the
     * screen is off.
     */
    private suspend fun siteTrackLoop(pkg: String) {
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        var last = SystemClock.elapsedRealtime()
        var ticks = 0
        try {
            while (currentCoroutineContext().isActive) {
                delay(1_000)
                val now = SystemClock.elapsedRealtime()
                val delta = WebsiteLimitRules.tickDelta(now - last)
                last = now
                try {
                    if (!siteLimits.hasEnabled()) return
                    if (!power.isInteractive) continue
                    val host = siteHost ?: continue
                    if (!WebsiteLimitRules.countsNow(true, true, now - siteReadAt)) continue
                    val limit = siteLimits.limitFor(host) ?: continue
                    val pending = (pendingSiteMs[limit.domain] ?: 0L) + delta
                    pendingSiteMs[limit.domain] = pending
                    if (limit.enabled && siteLimits.usedMs(limit.domain) + pending >= limit.limitMs) {
                        flushSiteUsage()
                        block(pkg, BlockActivity.REASON_WEBSITE_LIMIT, detail = limit.domain)
                    }
                    if (++ticks % 5 == 0) flushSiteUsage()
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    // One bad tick must not end the counter.
                }
            }
        } finally {
            flushSiteUsage()
        }
    }

    /**
     * If Usage Access is granted, makes sure today's count is never lower than Android's own
     * figure. This repairs gaps from a restart or from the system stopping this service.
     */
    private fun reconcileUsage(force: Boolean = false) {
        val nowMs = System.currentTimeMillis()
        if (!force && nowMs - lastReconcileAt < 120_000L) return
        lastReconcileAt = nowMs
        if (!Permissions.hasUsageAccess(this)) return
        flushUsage()
        val tracked = FocusProfileRuntime.limitedPackages(
            limits.state.value.limits.map { it.pkg }, activeProfile(store.current()),
        )
        if (tracked.isEmpty()) return
        scope.launch(Dispatchers.Default) {
            try {
                val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                val startOfDay = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
                val stats = usm.queryAndAggregateUsageStats(startOfDay, System.currentTimeMillis())
                for (pkg in tracked) {
                    val systemMs = stats[pkg]?.totalTimeInForeground ?: continue
                    limits.raiseUsageTo(pkg, systemMs)
                }
            } catch (_: Exception) {
            }
        }
    }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                // Save what we have and stop counting while the screen is off or the phone shuts down.
                Intent.ACTION_SCREEN_OFF, Intent.ACTION_SHUTDOWN -> {
                    flushUsage()
                    screenIsOn = false
                    ensureTracking()
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenIsOn = true
                    ensureTracking()
                }
            }
        }
    }

    private fun registerSystemReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SHUTDOWN)
        }
        ContextCompat.registerReceiver(this, systemReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    private fun flushCategoryUsage() {
        if (pendingCatMs.isEmpty()) return
        for ((id, ms) in pendingCatMs) if (ms > 0L) limits.addCategoryUsage(id, ms)
        pendingCatMs.clear()
    }

    private fun flushUsage(pkg: String? = currentFg) {
        flushCategoryUsage()
        flushSiteUsage()
        if (pendingUsageMs <= 0L || pkg == null) return
        limits.addUsage(pkg, pendingUsageMs)
        pendingUsageMs = 0L
    }

    /**
     * Runs only while a limited app (or an app with a Shorts / Reels / Status limit) is in front.
     * Counts one second at a time while the screen is on, saves every few seconds, drives the
     * floating timer, sends the reminder and closes the app or the content when its limit is
     * reached. Sleeps (no counting) while the screen is off.
     *
     * The popup schedule ("every N min") lives here, not in the overlay: [sinceMs] is active use
     * since the last popup, saved per app, so switching apps or recreating the window never
     * resets or skips it.
     */
    private suspend fun trackLoop(pkg: String) {
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        val label = labelFor(pkg)
        var last = SystemClock.elapsedRealtime()
        var ticks = 0
        var sinceMs = limits.sincePopupMs(pkg)
        try {
            while (currentCoroutineContext().isActive) {
                delay(1_000)
                val now = SystemClock.elapsedRealtime()
                val delta = (now - last).coerceIn(0L, 5_000L)
                last = now
                try {
                    val appLimit = limitFor(pkg)
                    val hasCategories = limits.hasCategoryLimit(pkg)
                    // Extra time from the trusted phone is running: the timer shows how long is left.
                    val grantLeft = grants.remainingMs(pkg)
                    val grantTimer = grantLeft > 0L
                    if (appLimit == null && !hasCategories && !grantTimer) {
                        overlay?.hide()
                        if (grantWasShown) {
                            // The time given for an app without a limit is over: check the app again now.
                            grantWasShown = false
                            handleForeground(pkg, store.current())
                        }
                        return
                    }
                    if (!power.isInteractive) {
                        overlay?.hide()
                        continue
                    }

                    // Shorts / Reels / Status limit: count the time, close the content when it is
                    // used up, and show its own floating timer while that content is on screen.
                    var catOwnsTimer = false
                    if (!grantTimer && appLimit != null) grantWasShown = false
                    if (grantTimer) {
                        grantWasShown = true
                        val allowed = limits.floatingTimer() &&
                            (limits.floatingOverGames() || !GameApps.isGame(this, pkg))
                        if (allowed) overlay?.show(pkg, "Unlocked", grantLeft) else overlay?.hide()
                    } else if (hasCategories) {
                        val catStatus = if (grants.isActive(pkg)) null else categoryTick(pkg, delta)
                        catOwnsTimer = showCategoryTimer(pkg, catStatus, appLimit, delta)
                    }

                    if (appLimit != null) {
                        pendingUsageMs += delta
                        val used = limits.usedMs(pkg) + pendingUsageMs
                        val remaining = appLimit.limitMs - used

                        val granted = grants.isActive(pkg)
                        val emergencyLeft = if (remaining <= 0L && !granted) limits.emergencyLeftMs(pkg) else 0L
                        if (remaining <= 0L && !granted && emergencyLeft <= 0L) {
                            flushUsage(pkg)
                            overlay?.hide()
                            block(pkg, BlockActivity.REASON_LIMIT)
                            return
                        }

                        if (remaining <= 0L) {
                            // Extra time (trusted phone) or an Emergency window: keep counting. An
                            // Emergency window shows its own countdown; extra time shows no timer.
                            // When it ends, the next tick closes the app.
                            if (grantTimer) {
                                // The "Unlocked" countdown above stays on screen.
                            } else if (emergencyLeft > 0L && limits.floatingTimer() && !catOwnsTimer) {
                                overlay?.show(pkg, "Emergency", emergencyLeft)
                            } else if (!catOwnsTimer) {
                                overlay?.hide()
                            }
                        } else {
                            if (appLimit.remindMin > 0 && remaining <= appLimit.remindMin * 60_000L && !limits.wasReminded(pkg)) {
                                limits.markReminded(pkg)
                                Notifications.postLimitReminder(this, pkg, label, ((remaining + 59_999L) / 60_000L).toInt())
                            }

                            // The timer shows over EVERY app that has a limit, games included
                            // ("Also over games" is on by default). Only a person who switched it off
                            // for games gets no overlay there; the limit still counts and still
                            // closes the app either way.
                            val overlayAllowed = limits.floatingTimer() &&
                                (limits.floatingOverGames() || !GameApps.isGame(this, pkg))
                            val every = limits.floatingEveryMin()
                            sinceMs += delta
                            if (grantTimer) {
                                // The "Unlocked" countdown above stays on screen.
                            } else if (catOwnsTimer) {
                                // The Shorts / Reels timer is showing; it runs out before the app limit.
                            } else if (!overlayAllowed) {
                                overlay?.hide()
                            } else if (every <= 0) {
                                // Always: show() creates, re-attaches and refreshes it every second.
                                overlay?.show(pkg, label, remaining)
                            } else {
                                overlay?.ensurePeriodic()
                                if (PopupSchedule.isDue(sinceMs, every)) {
                                    sinceMs = 0L
                                    overlay?.popup(pkg, label, remaining)
                                } else {
                                    overlay?.update(remaining)
                                }
                            }
                        }
                    }


                    if (++ticks % 5 == 0) {
                        flushUsage(pkg)
                        limits.setSincePopupMs(pkg, sinceMs)
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    // One bad tick (a window that vanished mid-read, say) must not end the counter.
                }
            }
        } finally {
            // Also saves the seconds counted since the last save when the limit stops applying (a profile's session ended).
            flushUsage(pkg)
            limits.setSincePopupMs(pkg, sinceMs)
        }
    }

    /**
     * Shorts / Reels / Status with a daily limit: finds which of them is on screen, adds
     * [deltaMs] to that content's own counter and, once today's time is used up, closes it
     * (tap a safe tab, then Back, then the block screen). With [deltaMs] = 0 it only enforces.
     * Returns the content that is on screen with its remaining time, or null when none is.
     */
    @Suppress("DEPRECATION")
    private fun categoryTick(pkg: String, deltaMs: Long): CategoryStatus? {
        val ids = limits.categoryIdsFor(pkg)
        if (ids.isEmpty() || GameApps.isGame(this, pkg)) return null
        val root = rootInActiveWindow ?: return null
        try {
            if (root.packageName?.toString() != pkg) return null
            val nodes = snapshot(root)
            val windowClass = if (fgWindowPkg == pkg) fgWindowClass.orEmpty() else ""
            val id = ids.firstOrNull { categoryVisible(it, root, nodes, windowClass) } ?: return null
            if (deltaMs > 0L) pendingCatMs[id] = (pendingCatMs[id] ?: 0L) + deltaMs
            val limit = limits.categoryLimit(id) ?: return null
            val left = CategoryTimer.remaining(limit.limitMs, limits.categoryUsedMs(id), pendingCatMs[id] ?: 0L)
            if (left > 0L) return CategoryStatus(id, left)
            // Emergency window for this limit: let it stay open and count down the window.
            val emergencyLeft = limits.emergencyLeftMs(id)
            if (emergencyLeft > 0L) return CategoryStatus(id, emergencyLeft)
            flushCategoryUsage()
            val def = ShortFormCatalog.byId(id)?.let { ShortFormCatalog.exitDef(it) } ?: return null
            handleSectionHit(pkg, def, root, limitCategoryId = id)
            return CategoryStatus(id, 0L)
        } finally {
            root.recycle()
        }
    }

    /**
     * Drives the floating timer for Shorts / Reels / Status limits, following the same "always"
     * or "every N min" setting as the app timer. It shows while the limited content is open (it
     * stays for a moment if one screen read misses it) and goes away when the person leaves it.
     */
    private fun showCategoryTimer(pkg: String, status: CategoryStatus?, appLimit: com.focusmode.app.data.AppLimit?, delta: Long): Boolean {
        val o = overlay ?: return false
        val now = SystemClock.elapsedRealtime()
        if (status != null) {
            catShownId = status.id
            catLastSeenAt = now
        }
        val id = catShownId
        val visible = id != null && now - catLastSeenAt <= CATEGORY_TIMER_HOLD_MS
        if (!visible || id == null) {
            catShownId = null
            // Nothing from the Shorts limit on screen: the app's own timer (if any) is handled above.
            if (appLimit == null) o.hide()
            return false
        }
        val form = ShortFormCatalog.byId(id)
        val inEmergency = limits.emergencyActive(id) &&
            limits.categoryUsedMs(id) + (pendingCatMs[id] ?: 0L) >= (limits.categoryLimit(id)?.limitMs ?: Long.MAX_VALUE)
        val label = if (inEmergency) "Emergency" else form?.displayName ?: labelFor(pkg)
        val catLeft = status?.remainingMs ?: CategoryTimer.remaining(
            limits.categoryLimit(id)?.limitMs ?: 0L, limits.categoryUsedMs(id), pendingCatMs[id] ?: 0L,
        )
        val appLeft = appLimit?.let { it.limitMs - (limits.usedMs(pkg) + pendingUsageMs) }
        if (!CategoryTimer.pick(appLeft, catLeft)) return false // the app timer runs out sooner: leave it
        if (catLeft <= 0L) { o.hide(); return true }
        val overlayAllowed = limits.floatingTimer() && (limits.floatingOverGames() || !GameApps.isGame(this, pkg))
        if (!overlayAllowed) { o.hide(); return true }
        val every = limits.floatingEveryMin()
        if (every <= 0) {
            o.show(pkg, label, catLeft)
        } else {
            o.ensurePeriodic()
            val since = (catSinceMs[id] ?: limits.sincePopupMs(id)) + delta
            if (PopupSchedule.isDue(since, every)) {
                catSinceMs[id] = 0L
                limits.setSincePopupMs(id, 0L)
                o.popup(pkg, label, catLeft)
            } else {
                catSinceMs[id] = since
                if (since % 5_000L < 1_000L) limits.setSincePopupMs(id, since)
                o.update(catLeft)
            }
        }
        return true
    }

    private fun categoryVisible(id: String, root: AccessibilityNodeInfo, nodes: List<NodeSnap>, windowClass: String): Boolean {
        if (id == ShortFormCatalog.YT_SHORTS) return isShortsVisible(root) || ShortsDetector.isShortsScreen(nodes)
        val def = ShortFormCatalog.byId(id)?.featureId?.let { FeatureCatalog.byId(it) } ?: return false
        return FeatureMatcher.matches(def.selector, nodes, windowClass)
    }

    /**
     * Once a second, checks which app is really in front. A dialog from another app can cover a
     * limited app and close again without Android sending any new event for the app itself;
     * without this the counter and the floating timer would stay stopped after that.
     */
    private fun startWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = scope.launch {
            while (isActive) {
                delay(1_000)
                try {
                    // Bedtime starts while an app is already open: no window event fires then, so look.
                    val bedtimeOn = bedtime.isActive()
                    val adultOn = ::adult.isInitialized && adult.isActive()
                    val keywordsOn = ::keywordStore.isInitialized && keywordState.isActive
                    val siteLimitsOn = ::siteLimits.isInitialized && siteLimits.hasEnabled()
                    if (!screenIsOn || (!limits.hasAnyLimit() && !FocusProfileRuntime.hasProfileLimits(activeProfile(store.current())) && !bedtimeOn && !adultOn && !keywordsOn && !siteLimitsOn)) continue
                    val p = foregroundPackage() ?: continue
                    if (p in ignoredForeground || p in imePackages) continue
                    if (bedtimeOn && bedtimeBlocks(p) && activeWindowPackage() == p) {
                        block(p, BlockActivity.REASON_BEDTIME)
                        continue
                    }
                    if (p != currentFg) setForeground(p) else ensureTracking()
                    if (WebsiteBrowsers.isSupported(p)) enforceWebsite(p, store.current())
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun labelFor(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) {
        pkg
    }

    private fun loadImePackages(): Set<String> = try {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.enabledInputMethodList.map { it.packageName }.toSet()
    } catch (_: Exception) {
        emptySet()
    }

    // ---- Detection helpers ------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun isShortsVisible(root: AccessibilityNodeInfo): Boolean {
        if (root.packageName?.toString() != AppRepository.YOUTUBE) return false
        for (id in shortsViewIds) {
            val found = root.findAccessibilityNodeInfosByViewId(id)
            if (found.any { it.isVisibleToUser }) return true
        }
        // Fallback: the bottom "Shorts" tab is the selected one.
        if (root.findAccessibilityNodeInfosByText("Shorts").any { it.isSelected && it.isVisibleToUser }) return true
        // Last resort: read the screen and look for the Shorts player's own views (ids change often).
        return ShortsDetector.isShortsScreen(snapshot(root))
    }

    /** Settings / installer (and the Play Store with Advanced protection) can show screens that remove LockDistra. */
    private val guardPkgCache = HashMap<String, Boolean>()

    /**
     * Guarded screens: the listed packages, plus any phone-maker SYSTEM package that looks like a battery / power /
     * permission / security page (Vivo, iQOO, Xiaomi, OPPO ... change these names), decided by [GuardRules].
     */
    private fun isGuardedPkg(pkg: String): Boolean {
        if (pkg in guardedPackages) return true
        if (pkg == packageName || pkg in ignoredForeground || pkg in imePackages) return false
        return guardPkgCache.getOrPut(pkg) {
            try {
                val flags = packageManager.getApplicationInfo(pkg, 0).flags
                val system = (flags and (android.content.pm.ApplicationInfo.FLAG_SYSTEM or
                    android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
                system && com.focusmode.app.data.GuardRules.looksLikeOemGuardPackage(pkg)
            } catch (_: Exception) {
                false
            }
        }
    }

    private fun isGuardCandidate(pkg: String, s: FocusState): Boolean =
        SafetyConfig.UNINSTALL_PROTECTION &&
            (isGuardedPkg(pkg) || (pkg == PLAY_STORE && s.advancedProtection))

    private var guardRecheckJob: Job? = null

    /** Looks at the guarded screen again after 60 / 150 / 300 / 500 / 800 / 1200 / 2000 ms; stops once it is closed or left. */
    private fun scheduleGuardRecheck(pkg: String) {
        guardRecheckJob?.cancel()
        guardRecheckJob = scope.launch {
            var prev = 0L
            for (t in GUARD_RECHECK_AT_MS) {
                delay(t - prev)
                prev = t
                try {
                    val front = activeWindowPackage()
                    if (front != null && front != pkg) return@launch
                    if (isProtectedScreen(pkg, store.current())) {
                        block(pkg, BlockActivity.REASON_PROTECTION)
                        return@launch
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * True when [pkg] is showing a screen that could uninstall, force-stop or deactivate this app.
     *
     * The same narrow rule is used during a focus session and between sessions (advanced protection):
     * only the installer's uninstall dialog, or a Settings / Play Store screen that shows "LockDistra"
     * together with an uninstall, force-stop, device-admin or "turn off LockDistra" action, is closed.
     * Everything else in Settings (Wi-Fi, Bluetooth, display, the app list, other apps' pages ...)
     * keeps working normally, also while Focus Mode is on.
     *
     * Needs the device admin to be active, so protection never exists without it.
     */
    @Suppress("DEPRECATION")
    private fun isProtectedScreen(pkg: String, s: FocusState): Boolean {
        if (!SafetyConfig.UNINSTALL_PROTECTION) return false
        val guardedHere = isGuardedPkg(pkg) || (pkg == PLAY_STORE && s.advancedProtection)
        if (!guardedHere) return false
        // During a session the guard follows "Allow other bypass methods"; advanced protection
        // is its own switch and also works between sessions.
        if (!s.sessionGuardOn && !s.advancedProtection) return false
        // Right after a restart the system's answer can be late or empty: the remembered one counts too.
        if (!(Permissions.isAdminActive(this) || BootCoverService.rememberedAdmin(this))) return false

        val root = rootInActiveWindow ?: return false
        try {
            // Make sure the window we inspect really belongs to this package.
            if (root.packageName?.toString() != pkg) return false
            // A Play Protect warning about this app must always stay usable (so it can be removed).
            if (SafetyConfig.ALLOW_PLAY_PROTECT_SCREENS &&
                playProtectTexts.any { root.findAccessibilityNodeInfosByText(it).isNotEmpty() }
            ) return false
            // Android's "Screen overlay detected ... Open settings" warning, in the first minutes after a restart: it
            // only leads to switching the after-restart cover off, so it is closed like the uninstall screens.
            if (SystemClock.elapsedRealtime() < OVERLAY_WARNING_WINDOW_MS &&
                overlayWarningTexts.any { root.findAccessibilityNodeInfosByText(it).isNotEmpty() }
            ) return true
            // Not LockDistra's own page: leave the screen alone.
            val labelNodes = root.findAccessibilityNodeInfosByText(APP_LABEL)
            if (labelNodes.isEmpty()) return false
            if (pkg in installerPackages || pkg in extraInstallerPackages) return true
            if (dangerousActions.any { root.findAccessibilityNodeInfosByText(it).isNotEmpty() }) return true
            // Battery / background power / auto-start / "display over other apps" pages of LockDistra: these differ
            // between phone makers, so they only count when "LockDistra" is the app header at the top of the page.
            val screenH = resources.displayMetrics.heightPixels
            val r = android.graphics.Rect()
            val header = labelNodes.any { n ->
                n.getBoundsInScreen(r)
                com.focusmode.app.data.GuardRules.isInHeaderZone(r.top, screenH)
            }
            if (!header) return false
            return com.focusmode.app.data.GuardRules.BROAD_ACTIONS.any { root.findAccessibilityNodeInfosByText(it).isNotEmpty() }
        } finally {
            root.recycle()
        }
    }

    @Suppress("DEPRECATION")
    private fun foregroundPackage(): String? {
        val root = rootInActiveWindow
        if (root != null) {
            val p = root.packageName?.toString()
            root.recycle()
            if (p != null) return p
        }
        return usageForegroundPackage()
    }

    @Suppress("DEPRECATION")
    private fun activeWindowPackage(): String? {
        val root = rootInActiveWindow ?: return null
        return try {
            root.packageName?.toString()
        } finally {
            root.recycle()
        }
    }

    private fun usageForegroundPackage(): String? {
        if (!Permissions.hasUsageAccess(this)) return null
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(end - 10 * 60_000L, end)
        val e = UsageEvents.Event()
        val resumed = if (Build.VERSION.SDK_INT >= 29) UsageEvents.Event.ACTIVITY_RESUMED
        else UsageEvents.Event.MOVE_TO_FOREGROUND
        val paused = if (Build.VERSION.SDK_INT >= 29) UsageEvents.Event.ACTIVITY_PAUSED
        else UsageEvents.Event.MOVE_TO_BACKGROUND
        var last: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == resumed) last = e.packageName
            else if (e.eventType == paused && e.packageName == last) last = null
        }
        return last
    }

    /**
     * Safety net: also catches the case where emergency access just ended while a blocked app
     * is still on screen (no new window event fires in that case).
     */
    private suspend fun pollLoop() {
        val power = getSystemService(Context.POWER_SERVICE) as PowerManager
        var rounds = 0
        while (currentCoroutineContext().isActive) {
            delay(1_200)
            // About once a minute: keep the clock check running and bring the foreground service
            // back if the system stopped it, even when the service's own alarm was missed.
            if (++rounds % 50 == 0 && store.current().focusActive) {
                ClockWatch.check(this)
                FocusController.resumeIfNeeded(this)
            }
            // Auto Focus works with the app closed: this service keeps running, so it also starts the window.
            if (rounds % 12 == 0) {
                AutoFocusEngine.process(this)
                // Day Coach: second chance for a block / reminder whose alarm Android delayed.
                runCatching { DayCoachEngine.poll(this) }
            }
            // The Focus timer is tied to the lecture: it stands still while the lecture is not playing (also with the screen off).
            LectureTimerGuard.tick(this)
            // Screen off: nothing to cover, so check much less often to save battery.
            if (!power.isInteractive) {
                delay(5_000)
                continue
            }
            val s = store.current()
            if (!s.focusActive) continue
            // Only what Android's active window says counts here. The usage-stats guess of foregroundPackage() can be
            // minutes old and would close / open screens over an app the person already left.
            val fg = activeWindowPackage()
            ensureLectureOpen(s)
            val pkg = fg ?: continue
            if (pkg == packageName || pkg in ignoredForeground || pkg in imePackages) continue
            handleForeground(pkg, s)
            if (WebsiteBrowsers.isSupported(pkg)) enforceWebsite(pkg, s)
        }
    }

    override fun onInterrupt() {
        if (fullyReady) flushUsage()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        connected = false
        fullyConnected = false
        // Only a real "switched off by the person" matters; a restart kills the process without calling this.
        BootCoverService.rememberAccessibility(this, false)
        // Accessibility is gone: the fallback guard takes over until it is back.
        runCatching { LostGuardService.startIfNeeded(this) }
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        connected = false
        fullyConnected = false
        unlockReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        unlockReceiver = null
        if (fullyReady) flushUsage()
        watchdogJob?.cancel()
        overlay?.hide()
        if (receiverRegistered) {
            try {
                unregisterReceiver(systemReceiver)
            } catch (_: Exception) {
            }
            receiverRegistered = false
        }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        /** The running service, so the block screen can ask it for "Continue to <app>". Null when it is not connected. */
        @Volatile
        var instance: AppBlockerService? = null

        /** "Continue to <app>" window: how long, how many Back presses, how far apart, and the first look after the cover closes. */
        private const val CONTINUE_WINDOW_MS = 8_000L
        private const val CONTINUE_MAX_BACKS = 4
        private const val CONTINUE_BACK_GAP_MS = 650L
        private const val CONTINUE_FIRST_LOOK_MS = 450L

        /** True while this accessibility service is connected and ready (false right after a restart). */
        @Volatile
        var connected = false

        /** True only once the FULL start-up has finished (after unlock). The after-restart cover waits for this. */
        @Volatile
        var fullyConnected = false

        private val shortsViewIds = listOf(
            "com.google.android.youtube:id/reel_player_page_container",
            "com.google.android.youtube:id/reel_recycler",
            "com.google.android.youtube:id/reel_watch_player",
            "com.google.android.youtube:id/shorts_player_container",
        )

        /** How long to wait for a Short's channel / caption to appear before deciding. */
        private const val SHORTS_GRACE_MS = 1_500L
        /** The app gets this long to open the lecture itself before the service opens it. */
        private const val LECTURE_OPEN_WAIT_MS = 3_000L

        /** Least time between two address-bar reads when only a website limit needs them. */
        private const val SITE_LIMIT_READ_GAP_MS = 1_500L

        /** The Shorts / Reels timer stays this long after the content was last seen on screen. */
        private const val CATEGORY_TIMER_HOLD_MS = 2_500L

        /** Pause after tapping / pressing Back so the transition can finish before the next step. */
        private const val FEATURE_SETTLE_MS = 900L

        /** A section not seen for this long counts as left; the next visit starts over. */
        private const val FEATURE_FORGET_MS = 4_000L

        private const val SNAPSHOT_MAX_NODES = 400
        private const val SNAPSHOT_MAX_DEPTH = 24
        private const val SNAPSHOT_MAX_TEXT = 200

        /** Windows that appear on top of an app without meaning the user left it. */
        private val ignoredForeground = setOf("com.android.systemui", "android")


        private const val APP_LABEL = "LockDistra"
        private val playProtectTexts = listOf("Play Protect", "harmful app", "unsafe app")
        private const val PLAY_STORE = "com.android.vending"

        private val installerPackages = setOf(
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.samsung.android.packageinstaller",
        )

        /** Phone makers' own installers / permission screens. */
        private val extraInstallerPackages = setOf(
            "com.miui.packageinstaller",
            "com.oplus.appdetail",
            "com.coloros.packageinstaller",
            "com.vivo.packageinstaller",
        )

        /** Where Android shows the "Screen overlay detected" warning. */
        private val permissionPackages = setOf(
            "com.google.android.permissioncontroller",
            "com.android.permissioncontroller",
        )

        private val overlayWarningTexts = listOf(
            "screen overlay detected",
            "turn off the screen overlay",
            "स्क्रीन ओवरले",
        )

        private const val OVERLAY_WARNING_WINDOW_MS = 10 * 60_000L

        /** Least time between two looks at a guarded (Settings / installer) screen, and the quick re-checks after it opens. */
        private const val GUARD_CONTENT_GAP_MS = 120L
        private val GUARD_RECHECK_AT_MS = longArrayOf(60, 150, 300, 500, 800, 1200, 2000)

        /**
         * Phone makers' own battery / device-care screens. On Samsung (and some other phones) LockDistra's
         * "Battery usage details" page has a "Stop running in background" button that would switch the blocker off.
         * These packages are only ever closed when the page shows "LockDistra" together with one of the
         * [dangerousActions] texts, so every other app's battery page keeps working normally.
         */
        private val batteryPackages = setOf(
            "com.samsung.android.lool",
            "com.samsung.android.sm",
            "com.samsung.android.sm.devicesecurity",
            "com.miui.powerkeeper",
            "com.oplus.battery",
            "com.coloros.oppoguardelf",
            // vivo / iQOO ("Background power control", "Battery usage details")
            "com.vivo.abe",
            "com.iqoo.powersaving",
            "com.iqoo.secure",
            "com.vivo.permissionmanager",
            "com.vivo.settings",
            // Xiaomi / OPPO / realme / OnePlus security centres
            "com.miui.securitycenter",
            "com.miui.permcenter",
            "com.coloros.safecenter",
            "com.oplus.battery",
            "com.oplus.athena",
        )

        private val guardedPackages = setOf("com.android.settings") + installerPackages + extraInstallerPackages + permissionPackages + batteryPackages

        /**
         * Texts (English UI) that mark a screen as an uninstall / stop / deactivate screen.
         * Matching is case-insensitive and by substring.
         */
        private val dangerousActions = listOf(
            "uninstall",
            "force stop",
            "deactivate",
            "device admin",
            "clear data",
            "clear storage",
            // Switching LockDistra's accessibility service off ("Use LockDistra" switch, "Stop LockDistra?" dialog).
            "use lockdistra",
            "stop lockdistra",
            // LockDistra's battery page ("Battery usage details" > "Stop running in background" / "Background power control").
            "stop running in background",
            "background power control",
            "battery usage details",
            // Hindi
            "अनइंस्टॉल",
            "फ़ोर्स स्टॉप",
            "फोर्स स्टॉप",
            "ज़बरदस्ती रोकें",
            "जबरदस्ती रोकें",
            "डिवाइस एडमिन",
            "निष्क्रिय",
            "डेटा साफ़",
            "डेटा हटाएं",
            "स्टोरेज साफ़",
        )
    }
}
