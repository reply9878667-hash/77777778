package com.focusmode.app.ui.online

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import com.focusmode.app.data.ChangeWindowRules
import com.focusmode.app.data.Credentials
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.LockState
import com.focusmode.app.data.VerifyResult
import com.focusmode.app.data.online.OnlineManager
import com.focusmode.app.data.online.OnlineState
import com.focusmode.app.ui.LockController
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.FocusSwitch
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.launch

// =================================================================================================
// "Prevent changes": Settings card, unlock dialog and the bar shown on locked screens
// =================================================================================================

/**
 * Settings card for "Prevent changes". With it on, no limit, blocked app or setting can be
 * changed until the person is checked (app PIN / password, recovery code or the trusted phone).
 * The check opens a [ChangeWindowRules.WINDOW_MS] editing window, then everything locks again.
 */
@Composable
fun PreventChangesSection(
    state: FocusState,
    lock: LockState,
    manager: OnlineManager,
    controller: LockController,
    /** Switches it on / off. Returns an error text, or null when it worked. */
    onSet: (Boolean) -> String?,
    /** The dialog checked a PIN / password / recovery code: open the editing window. */
    onAuthorized: () -> Unit,
    onLockNow: () -> Unit,
) {
    val c = FocusTheme.colors
    val online by manager.state.collectAsStateWithLifecycle()
    var note by remember { mutableStateOf<String?>(null) }
    var askUnlock by remember { mutableStateOf(false) }
    var turnOffAfter by remember { mutableStateOf(false) }

    FocusCard {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(c.accentSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Lock, null, tint = c.accent, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.size(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Prevent changes", style = MaterialTheme.typography.titleMedium)
                    Text(
                        when {
                            !state.preventChanges -> "Off"
                            state.changesLocked -> "On, everything is locked"
                            else -> "On, open for editing right now (locks soon)"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.preventChanges) c.accent else c.muted
                    )
                }
                FocusSwitch(
                    checked = state.preventChanges,
                    onCheckedChange = { on ->
                        note = null
                        when {
                            on -> note = onSet(true)
                            state.changesLocked -> {
                                // Turning it off is a change, so the person is checked first.
                                turnOffAfter = true
                                askUnlock = true
                            }
                            else -> note = onSet(false)
                        }
                    }
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "With this on, no limit, blocked app or setting can be changed. To change anything you need the app's PIN / password, your recovery code, or an approval from your trusted phone. Changes then stay open for ${ChangeWindowRules.WINDOW_MS / 60_000} minutes and lock again by themselves. Right after you switch it on, you get ${ChangeWindowRules.GRACE_MS / 1000} seconds to undo anything switched on by mistake.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            if (state.preventChanges) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (state.changesLocked) {
                        SoftChip("Unlock changes", true, {
                            note = null
                            turnOffAfter = false
                            askUnlock = true
                        })
                    } else {
                        SoftChip("Lock now", false, { note = null; onLockNow() })
                    }
                }
            }
            note?.let {
                Spacer(Modifier.height(10.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
        }
    }

    if (askUnlock) {
        UnlockChangesDialog(
            lock = lock,
            manager = manager,
            online = online,
            controller = controller,
            changesLocked = state.changesLocked,
            onAuthorized = onAuthorized,
            onUnlocked = {
                askUnlock = false
                if (turnOffAfter) {
                    turnOffAfter = false
                    note = onSet(false)
                }
            },
            onDismiss = { askUnlock = false; turnOffAfter = false },
        )
    }
}

/**
 * Asks who is there: the app's PIN / password or a recovery code typed here, or an approval from
 * the trusted phone. Either one opens the editing window; the dialog closes itself as soon as the
 * window is open ([changesLocked] turns false).
 */
@Composable
fun UnlockChangesDialog(
    lock: LockState,
    manager: OnlineManager,
    online: OnlineState,
    controller: LockController,
    changesLocked: Boolean,
    onAuthorized: () -> Unit,
    onUnlocked: () -> Unit,
    onDismiss: () -> Unit,
) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val phoneOk = online.phoneConnected && manager.configured

    // Opened by the trusted phone's approval or by the code typed below.
    LaunchedEffect(changesLocked) { if (!changesLocked) onUnlocked() }

    // Leaving the dialog withdraws a request that is still waiting for the trusted phone.
    DisposableEffect(Unit) { onDispose { manager.cancelUnlock() } }

    fun submit() {
        if (busy || input.isBlank()) return
        busy = true
        val typed = input
        scope.launch {
            // authorizeChange: the trusted-phone recovery code, or the PIN / password.
            var r = manager.authorizeChange(typed)
            // The App lock's own recovery code works too.
            if (r != VerifyResult.Ok && lock.enabled && Credentials.isRecoveryShapeValid(typed)) {
                val r2 = controller.checkRecovery(typed)
                if (r2 == VerifyResult.Ok) r = r2
            }
            busy = false
            input = ""
            if (r == VerifyResult.Ok) onAuthorized() else error = verifyText(r)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        titleContentColor = c.text,
        textContentColor = c.muted,
        title = { Text("Unlock changes", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    "Prevent changes is on. Prove it's you to edit limits, blocked apps and settings for ${ChangeWindowRules.WINDOW_MS / 60_000} minutes.",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it.take(40); error = null },
                    label = { Text(if (lock.enabled) "Recovery code or PIN / password" else "Recovery code") },
                    singleLine = true,
                    enabled = !busy,
                    colors = fieldColors(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning) }
                if (phoneOk) {
                    Text(
                        "or",
                        style = MaterialTheme.typography.labelSmall,
                        color = c.muted,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    OnlineUnlockPanel(manager = manager, online = online, showRecovery = false, forChanges = true)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && input.isNotBlank(), onClick = { submit() }) {
                Text(if (busy) "Checking..." else "Unlock", color = c.accent)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.muted) } }
    )
}

/**
 * Top banner for the first seconds after "Prevent changes" was switched on: "Settings lock in 7s". Until it
 * reaches 0 every switch can still be changed (undo a mistake); then everything locks until Prevent changes is off.
 */
@Composable
fun SettingsLockCountdownBar(
    remainingMs: () -> Long,
    onLockNow: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    var left by remember { mutableLongStateOf(remainingMs()) }
    LaunchedEffect(Unit) {
        while (true) {
            left = remainingMs()
            if (left <= 0L) break
            delay(200)
        }
    }
    if (left <= 0L) return
    val seconds = ((left + 999L) / 1000L).toInt()
    Box(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        FocusCard(padding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Lock, null, tint = c.warning, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Settings lock in ${seconds}s", style = MaterialTheme.typography.bodyMedium, color = c.text)
                    Text(
                        "Turn off anything switched on by mistake now.",
                        style = MaterialTheme.typography.bodySmall,
                        color = c.muted
                    )
                }
                TextButton(onClick = onLockNow) { Text("Lock now", color = c.accent) }
            }
        }
    }
}

/** Thin bar at the bottom of the screens whose controls are locked by "Prevent changes". */
@Composable
fun ChangesLockedBar(onUnlock: () -> Unit, modifier: Modifier = Modifier) {
    val c = FocusTheme.colors
    Box(
        modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        FocusCard(padding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Lock, null, tint = c.warning, modifier = Modifier.size(20.dp))
                Spacer(Modifier.size(12.dp))
                Text(
                    "Changes are locked",
                    style = MaterialTheme.typography.bodyMedium,
                    color = c.text,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onUnlock) { Text("Unlock", color = c.accent) }
            }
        }
    }
}
