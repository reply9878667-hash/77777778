package com.focusmode.app.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.focusmode.app.data.AppInfo
import com.focusmode.app.data.BedtimeState
import com.focusmode.app.data.ContentState
import com.focusmode.app.data.EmergencyDraft
import com.focusmode.app.data.EmergencyState
import com.focusmode.app.data.FocusProfile
import com.focusmode.app.data.FocusState
import com.focusmode.app.data.LimitEmergency
import com.focusmode.app.data.LimitsState
import com.focusmode.app.service.PermissionStatus
import com.focusmode.app.ui.AppViewModel
import com.focusmode.app.ui.components.FocusBackground

/**
 * The existing Blocking screen ([AppsScreen]), opened on one Focus Profile's own settings.
 *
 * Nothing is rebuilt: the screen, the per-app panel (blocking, usage limit, Shorts, websites) and the limit editor are
 * the ones the Blocking tab uses. This only hands them the profile's saved data and sends their changes to the profile's
 * storage instead of the phone-wide stores, so the normal App Limits and global blocking settings stay untouched.
 *
 * The state given to the screen is a plain "no session running" state, so none of the session locks apply while
 * editing a profile.
 */
@Composable
fun FocusProfileBlockingScreen(
    profile: FocusProfile?,
    apps: List<AppInfo>,
    loaded: Boolean,
    vm: AppViewModel,
    onBack: () -> Unit,
) {
    // The profile was deleted somewhere else: nothing to edit.
    if (profile == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    val slot = profile.slot
    val s = profile.settings

    val state = remember(s.blocked, s.blockShorts) { FocusState(blocked = s.blocked, blockShorts = s.blockShorts) }
    val content = remember(s.features) { ContentState(enabledFeatures = s.features) }
    val limits = remember(s.limits, s.limitEmergency) {
        LimitsState(
            limits = s.limits,
            emergency = s.limitEmergency.mapValues { (_, d) ->
                LimitEmergency(enabled = d.enabled, attempts = d.attempts, minutes = d.minutes)
            },
        )
    }

    Box(Modifier.fillMaxSize()) {
        FocusBackground(Modifier.matchParentSize())
        Box(Modifier.fillMaxSize().navigationBarsPadding()) {
            AppsScreen(
                state = state,
                apps = apps,
                loaded = loaded,
                limits = limits,
                emergency = EmergencyState(),
                content = content,
                websites = s.websites,
                bedtime = BedtimeState(),
                permissions = PermissionStatus(),
                // Global-only cards (Bedtime, Adult content) are not shown for a profile, so these never fire.
                onBedtimeEnabled = {},
                onBedtimeTimes = { _, _ -> false },
                onBedtimeApps = {},
                onWebsiteBlocking = { pkg, on -> vm.setProfileWebsiteBlocking(slot, pkg, on) },
                onAddWebsite = { pkg, raw, sub -> vm.addProfileWebsite(slot, pkg, raw, sub) },
                onEditWebsite = { pkg, old, raw, sub -> vm.editProfileWebsite(slot, pkg, old, raw, sub) },
                onRemoveWebsite = { pkg, domain -> vm.removeProfileWebsite(slot, pkg, domain) },
                onWebsiteEnabled = { pkg, domain, on -> vm.setProfileWebsiteEnabled(slot, pkg, domain, on) },
                onBack = onBack,
                onToggleApp = { pkg, on -> vm.updateFocusProfile(slot) { it.withBlocked(pkg, on) } },
                onToggleShorts = { on -> vm.updateFocusProfile(slot) { it.withShorts(on) } },
                onSaveLimit = { limit -> vm.updateFocusProfile(slot) { it.withLimit(limit) } },
                onRemoveLimit = { pkg -> vm.updateFocusProfile(slot) { it.withoutLimit(pkg) } },
                onSaveLimitEmergency = { pkg, enabled, attempts, minutes ->
                    vm.updateFocusProfile(slot) { it.withLimitEmergency(pkg, EmergencyDraft(enabled, attempts, minutes)) }
                },
                // Emergency access of an app is phone-wide (hidden in a profile).
                onEmergencyEnabled = { _, _ -> },
                onEmergencyAttempts = { _, _ -> },
                onFeatureChange = { id, on -> vm.updateFocusProfile(slot) { it.withFeature(id, on) } },
                // "Inside apps" and educational channels are phone-wide (hidden in a profile).
                onOpenFeatures = {},
                onOpenEducation = {},
                profileName = profile.name,
            )
        }
    }
}
