package com.focusmode.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class AppInfo(
    val packageName: String,
    val label: String,
    val popular: Boolean,
    /** The Android Settings app: blockable during a focus session, with safeguards. */
    val isSettings: Boolean = false,
)

object AppRepository {

    const val YOUTUBE = "com.google.android.youtube"

    /** Well-known apps people commonly want to silence while studying. */
    private val popularDistractions = setOf(
        YOUTUBE,
        "com.instagram.android",
        "com.facebook.katana",
        "com.zhiliaoapp.musically",
        "com.ss.android.ugc.trill",
        "com.snapchat.android",
        "com.twitter.android",
        "com.reddit.frontpage",
        "com.netflix.mediaclient",
        "com.pinterest",
        "com.whatsapp",
        "org.telegram.messenger",
        "com.discord",
        "tv.twitch.android.app",
        "com.amazon.avod.thirdpartyclient",
        "in.mohalla.sharechat",
        "com.next.innovation.takatak",
    )

    /** Package of the system Settings app on this phone (differs on some manufacturers). */
    fun settingsPackage(context: Context): String =
        context.packageManager.resolveActivity(
            Intent(android.provider.Settings.ACTION_SETTINGS),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName ?: "com.android.settings"

    /** Never offered for blocking, so the user cannot lock themselves out of the phone. */
    private val neverBlock = setOf(
        "com.android.systemui",
        "com.android.phone",
        "com.android.dialer",
        "com.google.android.dialer",
        "com.android.emergency",
        "com.google.android.apps.safetyhub",
    )

    suspend fun loadLaunchableApps(context: Context): List<AppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val settingsPkg = settingsPackage(context)
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val homePackage = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName

        pm.queryIntentActivities(launcherIntent, 0)
            .asSequence()
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { (pkg, _) ->
                pkg != context.packageName &&
                    pkg != homePackage &&
                    pkg !in neverBlock &&
                    !pkg.contains("dialer", ignoreCase = true)
            }
            .map { (pkg, label) -> AppInfo(pkg, label, pkg in popularDistractions, isSettings = pkg == settingsPkg) }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    fun isBlockable(pkg: String, ownPackage: String) = pkg != ownPackage && pkg !in neverBlock
}
