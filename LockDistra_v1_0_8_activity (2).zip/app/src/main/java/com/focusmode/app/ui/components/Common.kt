package com.focusmode.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.LruCache
import android.content.Context

/** Rounded card used across the app. [highlight] softly tints the card and its border. */
@Composable
fun FocusCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: PaddingValues = PaddingValues(20.dp),
    highlight: Boolean = false,
    content: @Composable () -> Unit,
) {
    val c = FocusTheme.colors
    val shape = RoundedCornerShape(24.dp)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && onClick != null) 0.98f else 1f, spring(), label = "cardPress")
    val fill by animateColorAsState(
        if (highlight) lerp(c.card, c.accentSoft, 0.5f) else c.card, tween(280), label = "cardFill"
    )
    val edge by animateColorAsState(
        if (highlight) c.accent.copy(alpha = 0.5f) else c.stroke, tween(280), label = "cardEdge"
    )
    val base = modifier
        .scale(scale)
        .clip(shape)
        .background(Brush.verticalGradient(listOf(fill, lerp(fill, c.background, if (c.isDark) 0.35f else 0f))))
        .border(BorderStroke(1.dp, edge), shape)
    val clickable = if (onClick != null) {
        base.clickable(interactionSource = interaction, indication = null, onClick = onClick)
    } else base
    Box(clickable.padding(padding)) { content() }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelSmall,
        color = FocusTheme.colors.muted,
        modifier = modifier.padding(start = 6.dp, bottom = 8.dp)
    )
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    /** Shows a spinner before the text. The button should be disabled by the caller while this is true. */
    loading: Boolean = false,
) {
    val c = FocusTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, spring(), label = "btnPress")
    val shape = RoundedCornerShape(28.dp)
    val fill = if (enabled) {
        Brush.verticalGradient(listOf(lerp(c.gradMid, Color.White, 0.22f), c.gradMid, c.gradStart))
    } else {
        Brush.verticalGradient(listOf(c.cardHigh, c.cardHigh))
    }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .scale(scale)
            .then(
                if (enabled) Modifier.shadow(12.dp, shape, ambientColor = c.glow, spotColor = c.gradMid)
                else Modifier
            )
            .clip(shape)
            .background(fill)
            .then(
                if (enabled) Modifier.border(
                    1.dp,
                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.7f), Color.White.copy(alpha = 0.12f))),
                    shape
                ) else Modifier
            )
            .clickable(
                interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick
            ),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (loading) {
            androidx.compose.material3.CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = if (enabled) Color.White else c.muted,
            )
            Spacer(Modifier.size(10.dp))
        } else if (icon != null) {
            Icon(icon, null, tint = if (enabled) Color.White else c.muted, modifier = Modifier.size(22.dp))
            Spacer(Modifier.size(8.dp))
        }
        Text(
            text,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, fontSize = 16.sp),
            color = if (enabled) Color.White else c.muted,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, spring(), label = "secondaryPress")
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .scale(scale)
            .clip(RoundedCornerShape(28.dp))
            .background(c.card)
            .border(BorderStroke(1.dp, c.accent.copy(alpha = 0.45f)), RoundedCornerShape(28.dp))
            .clickable(interactionSource = interaction, indication = LocalIndication.current, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = c.text)
    }
}

@Composable
fun SoftChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(), label = "chipPress")
    val bg by animateColorAsState(if (selected) c.gradMid else c.cardHigh, tween(220), label = "chipBg")
    val fg by animateColorAsState(if (selected) Color.White else c.text, tween(220), label = "chipFg")
    Box(
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(interactionSource = interaction, indication = LocalIndication.current, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, color = fg)
    }
}

@Composable
fun CircleIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = FocusTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, spring(dampingRatio = 0.55f), label = "circlePress")
    Box(
        modifier = modifier
            .size(44.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(c.card)
            .border(BorderStroke(1.dp, c.stroke), CircleShape)
            .clickable(interactionSource = interaction, indication = LocalIndication.current, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription, tint = c.text, modifier = Modifier.size(22.dp))
    }
}

// ---- App icons ------------------------------------------------------------------------------

private object IconCache {
    private val cache = LruCache<String, ImageBitmap>(160)

    suspend fun get(context: Context, pkg: String): ImageBitmap? {
        cache[pkg]?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                context.packageManager.getApplicationIcon(pkg).toBitmap(112, 112).asImageBitmap()
            }.getOrNull()?.also { cache.put(pkg, it) }
        }
    }
}

private val tileColors = listOf(
    Color(0xFF4ADE9C), Color(0xFF60A5FA), Color(0xFFF472B6), Color(0xFFFBBF24),
    Color(0xFFA78BFA), Color(0xFFF87171), Color(0xFF2DD4BF), Color(0xFFFB923C),
)

private fun tintFor(pkg: String): Color = tileColors[(pkg.hashCode() and 0x7fffffff) % tileColors.size]

/**
 * App icon in a circle. The icon fills the whole circle, so the real icon of the app is easy to see.
 * The colour comes from the package name, so every app keeps its own colour, and the circle doubles as
 * a colourful placeholder while the icon loads.
 */
@Composable
fun AppIcon(packageName: String, size: Dp = 44.dp) {
    val context = LocalContext.current
    val bitmap by produceState<ImageBitmap?>(null, packageName) {
        value = IconCache.get(context, packageName)
    }
    val tint = tintFor(packageName)
    val shape = CircleShape
    Box(
        Modifier
            .size(size)
            .shadow(3.dp, shape, clip = false, ambientColor = tint, spotColor = tint)
            .clip(shape)
            .background(Brush.linearGradient(listOf(tint.copy(alpha = 0.34f), tint.copy(alpha = 0.12f)))),
        contentAlignment = Alignment.Center
    ) {
        Crossfade(targetState = bitmap, animationSpec = tween(260), label = "appIcon") { bmp ->
            if (bmp != null) {
                Image(bmp, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                val letter = packageName.substringAfterLast('.').firstOrNull()?.uppercase() ?: "?"
                Text(
                    letter,
                    style = MaterialTheme.typography.titleMedium,
                    color = tint
                )
            }
        }
    }
}


/** Small company watermark: "Powered by Re Arena · By Prince Yadav". */
@Composable
fun BrandMark(modifier: Modifier = Modifier, centered: Boolean = false) {
    val c = FocusTheme.colors
    Text(
        text = "Powered by Re Arena  \u00B7  By Prince Yadav",
        style = MaterialTheme.typography.labelSmall,
        color = c.muted,
        textAlign = if (centered) TextAlign.Center else TextAlign.Start,
        modifier = modifier,
    )
}
