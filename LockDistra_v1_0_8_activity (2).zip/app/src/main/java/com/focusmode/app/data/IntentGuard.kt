package com.focusmode.app.data

import android.content.Context
import android.content.Intent
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * MainActivity has to be exported (it is the launcher), so any app could send it the special
 * intents used by notifications (grow plant, open Emergency access, open limits). Those intents
 * carry a random key made on this phone; an intent without the right key is treated as a plain
 * launch. The key never leaves the phone and is not part of any backup.
 */
object IntentGuard {
    const val EXTRA_KEY = "com.focusmode.app.extra.KEY"
    private const val FILE = "intent_guard"
    private const val K = "key"

    @Volatile
    private var cached: String? = null

    @Synchronized
    fun key(context: Context): String {
        cached?.let { return it }
        val prefs = Storage.prefs(context, FILE)
        var k = prefs.getString(K, null)
        if (k.isNullOrEmpty()) {
            val bytes = ByteArray(16)
            SecureRandom().nextBytes(bytes)
            k = bytes.joinToString("") { "%02x".format(it) }
            prefs.edit().putString(K, k).commit()
        }
        cached = k
        return k
    }

    fun isTrusted(context: Context, intent: Intent?): Boolean {
        val given = intent?.getStringExtra(EXTRA_KEY) ?: return false
        return MessageDigest.isEqual(given.toByteArray(), key(context).toByteArray())
    }
}
