package com.focusmode.app.data

/*
 * The rules for Focus controls and Emergency access, kept free of Android classes so they can
 * be unit tested on a plain JVM (see app/src/test). The stores call these before every change.
 */

object FocusPolicy {

    fun isAllowed(s: FocusState, control: FocusControl): Boolean = when (control) {
        FocusControl.TURN_OFF -> s.allowTurnOff
        FocusControl.SETTINGS -> s.allowSettingsChange
        FocusControl.EMERGENCY -> s.allowEmergency
        FocusControl.APP_CHANGES -> s.allowAppChanges
        FocusControl.OTHER_BYPASS -> s.allowOtherBypass
    }

    /**
     * Whether [control] may be set to [allowed] right now.
     *
     * Outside a session the controls are free defaults. While a session runs:
     *  - nothing can change once "changing settings" is off;
     *  - a control can only go from allowed to not allowed, never back;
     *  - "turning OFF" cannot be locked on a session that has no end time.
     */
    fun canSetControl(s: FocusState, control: FocusControl, allowed: Boolean): Boolean {
        if (isAllowed(s, control) == allowed) return true
        // "Prevent changes" does not apply here: Focus Mode's controls are separate from the phone-wide settings it locks.
        if (!s.focusActive) return true
        if (!s.allowSettingsChange) return false
        if (allowed) return false
        if (control == FocusControl.TURN_OFF && s.sessionEnd == 0L) return false
        return true
    }
}

object EmergencyPolicy {

    /** No edits at all while a running session has app changes or settings locked. */
    fun editsLocked(s: FocusState): Boolean =
        s.changesLocked || (s.focusActive && (!s.allowAppChanges || !s.allowSettingsChange))

    /** Turning an app on is only possible between sessions; turning it off is possible unless locked. */
    fun canSetEnabled(s: FocusState, enabled: Boolean): Boolean {
        if (s.changesLocked) return false
        if (!s.focusActive) return true
        return !editsLocked(s) && !enabled
    }

    /** Limits can be raised only between sessions; during one they can only go down (unless locked). */
    fun canSetLimit(s: FocusState, currentLimit: Int, newLimit: Int): Boolean {
        if (s.changesLocked) return false
        if (!s.focusActive) return true
        return !editsLocked(s) && newLimit <= currentLimit
    }

    /** Whether Emergency access may open an app right now, apart from the app's own attempts. */
    fun sessionAllows(s: FocusState, now: Long): Boolean =
        s.canUseEmergency && !s.emergencyActive(now)

    /** Uses one attempt. Returns the updated app, or null if it is off or has no attempts left. */
    fun consume(app: EmergencyApp?): EmergencyApp? {
        if (app == null || !app.available) return null
        return app.copy(used = app.used + 1)
    }
}

/** What to do with a running session after a restart signal. */
enum class RestartAction { NOTHING, RESUME, END }

object RestartPolicy {
    /**
     * [genuineBoot] is true only for broadcasts that only Android itself can send (locked boot,
     * boot completed). Vendor "quick boot" broadcasts can be sent by any app, so they may bring a
     * session back but never end one.
     */
    fun decide(s: FocusState, genuineBoot: Boolean): RestartAction = when {
        !s.focusActive -> RestartAction.NOTHING
        // A restart must not be a way out of a session locked with "Allow turning OFF" off.
        genuineBoot && !s.restoreAfterRestart && s.allowTurnOff -> RestartAction.END
        else -> RestartAction.RESUME
    }
}

object GrowPolicy {
    /**
     * A plant-growth tap counts only for the reminder that was really posted ([posted]) and only
     * once ([applied]). A forged intent with any other number does nothing.
     */
    fun accepts(token: Long, posted: Long, applied: Long): Boolean =
        token > 0L && token == posted && token > applied
}
