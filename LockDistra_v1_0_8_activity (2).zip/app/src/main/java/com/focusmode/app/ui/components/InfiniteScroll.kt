package com.focusmode.app.ui.components

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState

/**
 * Infinite scroll, like YouTube's: calls [onNearEnd] when the last few rows of the list come into view (or when the whole
 * list fits on the screen). It is asked again whenever [recheck] changes (a page arrived, a request ended), so a list that
 * is still short after a page keeps filling by itself. [onNearEnd] must itself refuse while a request runs or nothing is left.
 */
@Composable
fun NearEndEffect(state: LazyListState, recheck: Any?, buffer: Int = 3, onNearEnd: () -> Unit) {
    val near by remember(state, buffer) {
        derivedStateOf {
            val info = state.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 1 - buffer
        }
    }
    val callback by rememberUpdatedState(onNearEnd)
    LaunchedEffect(near, recheck) { if (near) callback() }
}

/** Same for a grid (two columns, so a larger [buffer] by default). */
@Composable
fun NearEndEffect(state: LazyGridState, recheck: Any?, buffer: Int = 4, onNearEnd: () -> Unit) {
    val near by remember(state, buffer) {
        derivedStateOf {
            val info = state.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: -1
            info.totalItemsCount > 0 && last >= info.totalItemsCount - 1 - buffer
        }
    }
    val callback by rememberUpdatedState(onNearEnd)
    LaunchedEffect(near, recheck) { if (near) callback() }
}
