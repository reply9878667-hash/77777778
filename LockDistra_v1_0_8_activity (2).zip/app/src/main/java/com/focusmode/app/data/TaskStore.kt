package com.focusmode.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Saved Daily Task Planner data, in device-protected storage like the other stores. Separate file ("daily_tasks"):
 * it shares nothing with the focus session, Focus Profile, blocking or Pomodoro.
 *
 * Every change first settles the date (unfinished Tomorrow tasks move to Today on a new local day), so the lists
 * are right after an app restart, after midnight, and after a time zone or clock change.
 */
class TaskStore private constructor(context: Context) {

    private val prefs: SharedPreferences = Storage.prefs(context, "daily_tasks")

    private val _state = MutableStateFlow(settle(read()))
    val state: StateFlow<TaskBoard> = _state.asStateFlow()

    private fun read() = TaskBoard(
        tasks = DailyTaskRules.decode(prefs.getString(K_TASKS, null)),
        lastDay = prefs.getInt(K_DAY, 0),
    )

    private fun settle(board: TaskBoard, now: Long = System.currentTimeMillis()): TaskBoard {
        val next = DailyTaskRules.rollover(board, DailyTaskRules.dayKey(now))
        if (next != board) write(next)
        return next
    }

    private fun write(board: TaskBoard) {
        prefs.edit()
            .putString(K_TASKS, DailyTaskRules.encode(board.tasks))
            .putInt(K_DAY, board.lastDay)
            .commit()
    }

    /** Call when the app comes back to the screen or the date may have changed. Cheap when nothing changed. */
    @Synchronized
    fun refreshDate(now: Long = System.currentTimeMillis()) {
        _state.value = settle(_state.value, now)
    }

    @Synchronized
    private fun change(now: Long = System.currentTimeMillis(), edit: (TaskBoard) -> TaskBoard) {
        val next = edit(settle(_state.value, now))
        if (next != _state.value) write(next)
        _state.value = next
    }

    fun addTask(text: String) = change { DailyTaskRules.add(it, text) }

    fun setDone(id: Long, done: Boolean) = change { DailyTaskRules.setDone(it, id, done) }

    fun assign(ids: Set<Long>, tag: TaskTag) = change { DailyTaskRules.assign(it, ids, tag) }

    companion object {
        private const val K_TASKS = "tasks"
        private const val K_DAY = "last_day"

        @Volatile
        private var instance: TaskStore? = null

        fun get(context: Context): TaskStore =
            instance ?: synchronized(this) {
                instance ?: TaskStore(context.applicationContext).also { instance = it }
            }

        /** Milliseconds from [now] to the next local midnight (at least 1 s). */
        fun msUntilMidnight(now: Long = System.currentTimeMillis()): Long {
            val zone = java.time.ZoneId.systemDefault()
            val next = java.time.Instant.ofEpochMilli(now).atZone(zone).toLocalDate().plusDays(1)
                .atStartOfDay(zone).toInstant().toEpochMilli()
            return (next - now).coerceAtLeast(1_000L)
        }
    }
}
