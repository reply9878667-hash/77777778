package com.focusmode.app.ui.onboarding

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Onboarding Part 2D: the mascot's dance, as plain maths (no Android or Compose types, so it is unit
 * tested on the JVM).
 *
 * A dance is a handful of short moves. Each move says, for any time t (seconds), how high the
 * mascot hops, how it sways, where its two hands are and how the head tilts, in the mascot's own
 * 360 x 400 drawing space. FocusBuddy picks the moves one after another at random (never the same
 * one twice in a row) and blends from one to the next over half a second, so the dance flows and
 * never loops in an obvious pattern. The face (smile, blinking, glances) is not part of this: it
 * keeps running on its own while the body dances.
 */
internal class DanceFrame {
    var hop = 0f        // jump height
    var shiftX = 0f     // whole body moves sideways
    var lean = 0f       // whole body leans (degrees, around the feet)
    var headTilt = 0f   // extra head tilt (degrees)
    var lx = 90f; var ly = 350f   // free hand (viewer's left)
    var rx = 270f; var ry = 350f  // other hand
    var lbx = -5f; var lby = 2f   // how much each arm bows outwards
    var rbx = 5f; var rby = 2f
    var swing = 0f      // the sprout on top lags behind and swings
    var mouth = 0f      // how open the happy mouth is (singing along)

    /** this = a -> b by [w] (0 = a, 1 = b). */
    fun blend(a: DanceFrame, b: DanceFrame, w: Float) {
        hop = lerp(a.hop, b.hop, w); shiftX = lerp(a.shiftX, b.shiftX, w)
        lean = lerp(a.lean, b.lean, w); headTilt = lerp(a.headTilt, b.headTilt, w)
        lx = lerp(a.lx, b.lx, w); ly = lerp(a.ly, b.ly, w)
        rx = lerp(a.rx, b.rx, w); ry = lerp(a.ry, b.ry, w)
        lbx = lerp(a.lbx, b.lbx, w); lby = lerp(a.lby, b.lby, w)
        rbx = lerp(a.rbx, b.rbx, w); rby = lerp(a.rby, b.rby, w)
        swing = lerp(a.swing, b.swing, w); mouth = lerp(a.mouth, b.mouth, w)
    }

    private fun lerp(a: Float, b: Float, w: Float) = a + (b - a) * w
}

internal object DanceMoves {
    const val COUNT = 5

    private const val TAU = 6.2831855f
    private const val PI_F = 3.1415927f

    /** Fills [o] with move number [move] at time [t]. */
    fun fill(move: Int, t: Float, o: DanceFrame) {
        // Shared by every move: the sprout lags behind the body, the mouth sings along.
        o.swing = 9f * sin(t * TAU * 1.6f - 0.9f)
        o.mouth = 0.3f + 0.2f * sin(t * TAU * 1.6f)
        o.shiftX = 0f
        o.lean = 0f

        when (((move % COUNT) + COUNT) % COUNT) {
            // 0: bounce on every beat and punch the arms up, one after the other.
            0 -> {
                val pump = sin(t * TAU * 1.6f)
                o.hop = 16f * abs(sin(t * PI_F * 1.6f))
                o.lx = 64f; o.ly = 200f + 48f * pump
                o.rx = 296f; o.ry = 200f - 48f * pump
                o.lbx = -14f; o.lby = -2f; o.rbx = 14f; o.rby = -2f
                o.lean = 3f * sin(t * TAU * 0.8f)
                o.headTilt = 5f * sin(t * TAU * 0.8f)
            }

            // 1: slow sway from side to side, both hands sweeping high above the head.
            1 -> {
                val s = sin(t * TAU * 0.5f)
                o.hop = 5f * abs(sin(t * PI_F))
                o.shiftX = 16f * s
                o.lean = 6f * s
                o.lx = 78f + 26f * s; o.ly = 140f + 20f * cos(t * TAU)
                o.rx = 282f + 26f * s; o.ry = 140f + 20f * cos(t * TAU + 1f)
                o.lbx = -10f; o.lby = -6f; o.rbx = 10f; o.rby = -6f
                o.headTilt = -9f * s
            }

            // 2: a quick wiggle with the arms held out wide.
            2 -> {
                val w = sin(t * TAU * 3f)
                o.hop = 6f * abs(sin(t * PI_F * 3f))
                o.lean = 5f * w
                o.lx = 38f + 6f * sin(t * TAU * 3f + 1f); o.ly = 255f + 14f * w
                o.rx = 322f + 6f * sin(t * TAU * 3f); o.ry = 255f - 14f * w
                o.lbx = -4f; o.lby = 10f; o.rbx = 4f; o.rby = 10f
                o.headTilt = 6f * w
            }

            // 3: disco point: one hand on the hip, the other pumping toward the sky.
            3 -> {
                o.hop = 8f * abs(sin(t * PI_F * 1.6f))
                o.shiftX = 8f * sin(t * TAU * 0.8f)
                o.lean = 6f * sin(t * TAU * 0.8f)
                o.rx = 290f; o.ry = 120f + 18f * sin(t * TAU * 1.6f)
                o.rbx = 12f; o.rby = -4f
                o.lx = 92f; o.ly = 316f
                o.lbx = -22f; o.lby = 6f
                o.headTilt = -6f + 3f * sin(t * TAU * 1.6f)
            }

            // 4: big jumps with both hands up, waving.
            else -> {
                val w = sin(t * TAU * 2.6f)
                o.hop = 26f * abs(sin(t * PI_F * 1.3f))
                o.lx = 74f + 6f * w; o.ly = 128f + 14f * sin(t * TAU * 2.6f + 1.5f)
                o.rx = 286f - 6f * w; o.ry = 128f + 14f * sin(t * TAU * 2.6f)
                o.lbx = -12f; o.lby = -6f; o.rbx = 12f; o.rby = -6f
                o.headTilt = 4f * sin(t * TAU * 1.3f)
            }
        }
    }
}
