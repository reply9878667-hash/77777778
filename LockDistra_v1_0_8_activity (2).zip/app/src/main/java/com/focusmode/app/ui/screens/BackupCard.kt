package com.focusmode.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.RestartActivity
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.PomodoroStore
import com.focusmode.app.data.RemoteBackup
import com.focusmode.app.data.SettingsBackupRemote
import com.focusmode.app.data.SettingsBackupRules
import com.focusmode.app.data.ShareCode
import com.focusmode.app.data.SharedSettingsRemote
import com.focusmode.app.data.auth.AuthRepository
import com.focusmode.app.data.auth.AuthSession
import com.focusmode.app.data.online.OnlineException
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SecondaryButton
import com.focusmode.app.ui.online.fieldColors
import com.focusmode.app.ui.theme.FocusTheme
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.launch

/**
 * Settings > Backup. "Upload" saves this phone's settings on the server (under the logged-in account); "Download" brings
 * them back on a new or reinstalled phone and restarts the app. Needs a login, because the backup belongs to the account.
 *
 * "Share your settings with a friend" makes a short code for a copy of the same settings (without the personal name);
 * "Paste your friend's code" takes such a code, shows what will happen, and on Apply writes the settings and restarts the app.
 */
@Composable
fun BackupCard() {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val auth = remember { AuthRepository.get(context) }
    val remote = remember { SettingsBackupRemote(context) }
    val shared = remember { SharedSettingsRemote(context) }
    val session by auth.session.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()

    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<RemoteBackup?>(null) }

    // Sharing with a friend.
    var myCode by remember { mutableStateOf<String?>(null) }
    var enterCode by remember { mutableStateOf(false) }
    var codeText by remember { mutableStateOf("") }
    var codeError by remember { mutableStateOf<String?>(null) }
    var pendingShared by remember { mutableStateOf<RemoteBackup?>(null) }

    val user = (session as? AuthSession.SignedIn)?.user

    fun friendly(e: Exception): String =
        if (e is OnlineException) (e.message ?: "Something went wrong. Try again.") else "Something went wrong. Try again."

    fun blockedReason(): String? = SettingsBackupRules.downloadBlockedReason(
        FocusStore.get(context).current(),
        PomodoroStore.get(context).current().active,
    )

    fun copyCode(code: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("LockDistra settings code", ShareCode.display(code)))
        Toast.makeText(context, "Code copied", Toast.LENGTH_SHORT).show()
    }

    fun shareCode(code: String) {
        val text = "My LockDistra settings code: ${ShareCode.display(code)}\n" +
            "In LockDistra open Settings > Backup > Paste your friend's code, enter it and press Apply."
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        try {
            context.startActivity(Intent.createChooser(send, "Share your code").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: ActivityNotFoundException) {
            copyCode(code)
        }
    }

    FocusCard {
        Column(Modifier.fillMaxWidth()) {
            Text("Backup your settings", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Upload saves your blocked apps, limits, websites, keywords, Focus Profiles and other settings on the server. " +
                    "On a new phone, or after reinstalling, log in and press Download to get them back.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Your App lock PIN, trusted phone keys and Android permissions are not included.",
                style = MaterialTheme.typography.bodySmall,
                color = c.muted
            )
            Spacer(Modifier.height(12.dp))
            if (user == null) {
                Text("Log in (Account above) to use backup.", style = MaterialTheme.typography.bodySmall, color = c.warning)
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PrimaryButton(
                        if (busy) "Please wait..." else "Upload",
                        enabled = !busy,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            message = null
                            busy = true
                            scope.launch {
                                try {
                                    remote.upload(user.uid, SettingsBackupRules.snapshot(context))
                                    message = "Settings uploaded."
                                } catch (e: kotlinx.coroutines.CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    message = friendly(e)
                                } finally {
                                    busy = false
                                }
                            }
                        }
                    )
                    SecondaryButton(
                        "Download",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            if (busy) return@SecondaryButton
                            message = null
                            val blocked = blockedReason()
                            if (blocked != null) {
                                message = blocked
                                return@SecondaryButton
                            }
                            busy = true
                            scope.launch {
                                try {
                                    val backup = remote.fetch(user.uid)
                                    if (backup == null) message = "No backup found for this account. Upload one first."
                                    else pending = backup
                                } catch (e: kotlinx.coroutines.CancellationException) {
                                    throw e
                                } catch (e: Exception) {
                                    message = friendly(e)
                                } finally {
                                    busy = false
                                }
                            }
                        }
                    )
                }

                Spacer(Modifier.height(16.dp))
                Text(
                    "Share a copy of your settings with a friend. Your friend needs the code and a LockDistra account.",
                    style = MaterialTheme.typography.bodySmall,
                    color = c.muted
                )
                Spacer(Modifier.height(8.dp))
                SecondaryButton(
                    "Share your settings with a friend",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (busy) return@SecondaryButton
                        message = null
                        busy = true
                        scope.launch {
                            try {
                                myCode = shared.publish(user.uid, SettingsBackupRules.snapshot(context, forSharing = true))
                            } catch (e: kotlinx.coroutines.CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                message = friendly(e)
                            } finally {
                                busy = false
                            }
                        }
                    }
                )
                Spacer(Modifier.height(10.dp))
                SecondaryButton(
                    "Paste your friend's code",
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        if (busy) return@SecondaryButton
                        message = null
                        codeText = ""
                        codeError = null
                        enterCode = true
                    }
                )
            }
            message?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
            }
        }
    }

    pending?.let { backup ->
        val whenText = if (backup.updatedAt > 0L)
            DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(backup.updatedAt)) else null
        AlertDialog(
            onDismissRequest = { pending = null },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Download settings?") },
            text = {
                Text(
                    (whenText?.let { "Backup from $it. " } ?: "") +
                        "This replaces the settings on this phone with the saved ones, and LockDistra restarts. " +
                        "If it does not open again, open it yourself."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pending = null
                    // Checked again: a session may have started while the dialog was open.
                    val blocked = blockedReason()
                    if (blocked != null) {
                        message = blocked
                    } else if (SettingsBackupRules.apply(context, backup.data)) {
                        RestartActivity.restart(context)
                    } else {
                        message = "This backup could not be applied. Nothing was changed."
                    }
                }) { Text("Download and restart", color = c.accent) }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel", color = c.muted) } },
        )
    }

    myCode?.let { code ->
        AlertDialog(
            onDismissRequest = { myCode = null },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Your settings code") },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        ShareCode.display(code),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 3.sp,
                            color = c.accent,
                        ),
                    )
                    TextButton(onClick = { copyCode(code) }) { Text("Copy code", color = c.accent) }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Send this code to your friend. In LockDistra they open Settings > Backup > Paste your friend's code. " +
                            "It carries your blocked apps, limits, websites, keywords, Focus Profiles and other settings. " +
                            "It does not carry your name, App lock PIN or Android permissions."
                    )
                }
            },
            confirmButton = { TextButton(onClick = { shareCode(code) }) { Text("Share", color = c.accent) } },
            dismissButton = { TextButton(onClick = { myCode = null }) { Text("Close", color = c.muted) } },
        )
    }

    if (enterCode && user != null) {
        AlertDialog(
            onDismissRequest = { if (!busy) enterCode = false },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Your friend's code") },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    Text("Paste or type the code your friend sent you. You can also paste the whole message.")
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = codeText,
                        onValueChange = { codeText = it.take(300); codeError = null },
                        label = { Text("Code") },
                        placeholder = { Text("K7P2-9QXM") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                        colors = fieldColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    codeError?.let {
                        Spacer(Modifier.height(6.dp))
                        Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busy,
                    onClick = {
                        val clean = ShareCode.normalize(codeText)
                        if (clean == null) {
                            codeError = "That code does not look right. It has 8 letters and numbers, like K7P2-9QXM."
                            return@TextButton
                        }
                        val blocked = blockedReason()
                        if (blocked != null) {
                            codeError = blocked
                            return@TextButton
                        }
                        busy = true
                        scope.launch {
                            try {
                                val found = shared.fetch(user.uid, clean)
                                if (found == null) {
                                    codeError = "No settings found for this code. Check it and try again."
                                } else {
                                    enterCode = false
                                    pendingShared = found
                                }
                            } catch (e: kotlinx.coroutines.CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                codeError = friendly(e)
                            } finally {
                                busy = false
                            }
                        }
                    }
                ) { Text(if (busy) "Please wait..." else "Apply", color = if (busy) c.muted else c.accent) }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { enterCode = false }) { Text("Cancel", color = c.muted) } },
        )
    }

    pendingShared?.let { backup ->
        AlertDialog(
            onDismissRequest = { pendingShared = null },
            containerColor = c.card,
            titleContentColor = c.text,
            textContentColor = c.muted,
            title = { Text("Apply your friend's settings?") },
            text = {
                Text(
                    "This replaces the blocked apps, limits, websites, keywords, Focus Profiles and other settings on this phone " +
                        "with your friend's. Your name, App lock and Android permissions stay as they are. " +
                        "LockDistra closes and opens again. If it does not open, open it yourself."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    pendingShared = null
                    // Checked again: a session may have started while the dialog was open.
                    val blocked = blockedReason()
                    if (blocked != null) {
                        message = blocked
                    } else if (SettingsBackupRules.apply(context, backup.data, shared = true)) {
                        RestartActivity.restart(context)
                    } else {
                        message = "These settings could not be applied. Nothing was changed."
                    }
                }) { Text("Apply and restart", color = c.accent) }
            },
            dismissButton = { TextButton(onClick = { pendingShared = null }) { Text("Cancel", color = c.muted) } },
        )
    }
}
