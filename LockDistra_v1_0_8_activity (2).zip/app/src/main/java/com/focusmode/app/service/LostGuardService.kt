package com.focusmode.app.service

import android.app.Service
import android.app.admin.DevicePolicyManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.focusmode.app.BlockActivity
import com.focusmode.app.R
import com.focusmode.app.data.FocusStore
import com.focusmode.app.data.GuardRules
import com.focusmode.app.data.SafetyConfig

/**
 * "Accessibility lost" fallback guard.
 *
 * The main guard lives inside the accessibility service. If that service is OFF (phone restarted and the maker's
 * software did not restart it, "Stop running in background" was used, ...), nothing guards the uninstall / device-admin
 * / App-info screens any more. This small foreground service closes exactly that gap: while the accessibility service
 * is not connected it watches the foreground activity (Usage access) and, when an uninstall / deactivate-admin /
 * App-info screen opens, locks the screen (device admin "force-lock") and opens the block screen.
 *
 * It can't read page texts (only the activity class), so it is stricter than the normal guard, but only while
 * accessibility is down. Accessibility settings itself are never touched, so the person can always switch it back on.
 * It stops by itself once accessibility has been connected for a while.
 */
class LostGuardService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var connectedTicks = 0
    private var lastActAt = 0L
    private var lastActedEventTime = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    private val tick = object : Runnable {
        override fun run() {
            try {
                if (AppBlockerService.connected) {
                    connectedTicks++
                    if (connectedTicks >= STOP_AFTER_CONNECTED_TICKS) {
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                        return
                    }
                } else {
                    connectedTicks = 0
                    check()
                }
            } catch (_: Exception) {
            }
            handler.postDelayed(this, TICK_MS)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Notifications.ensureChannels(this)
        val n = NotificationCompat.Builder(this, Notifications.CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat_leaf)
            .setContentTitle("LockDistra")
            .setContentText("Protection is waiting for Accessibility to start.")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                ServiceCompat.startForeground(this, ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(ID, n)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun check() {
        if (!Permissions.hasUsageAccess(this)) return
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(end - LOOKBACK_MS, end)
        val e = UsageEvents.Event()
        val resumed = if (Build.VERSION.SDK_INT >= 29) UsageEvents.Event.ACTIVITY_RESUMED else UsageEvents.Event.MOVE_TO_FOREGROUND
        val paused = if (Build.VERSION.SDK_INT >= 29) UsageEvents.Event.ACTIVITY_PAUSED else UsageEvents.Event.MOVE_TO_BACKGROUND
        var pkg: String? = null
        var cls: String? = null
        var time = 0L
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == resumed) {
                pkg = e.packageName; cls = e.className; time = e.timeStamp
            } else if (e.eventType == paused && e.packageName == pkg) {
                pkg = null; cls = null
            }
        }
        val p = pkg ?: return
        if (p == packageName) return
        if (time <= lastActedEventTime) return
        if (!GuardRules.isDangerousWhileBlind(p, cls)) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastActAt < 1_500L) return
        lastActAt = now
        lastActedEventTime = time
        act(p)
    }

    private fun act(pkg: String) {
        BootCoverService.trace(this, "lost-guard closed $pkg")
        // Lock first (needs the device admin, which is exactly what protects against uninstalling), then open the block screen.
        try {
            if (Permissions.isAdminActive(this)) {
                (getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).lockNow()
            }
        } catch (_: Exception) {
        }
        try {
            startActivity(
                Intent(this, BlockActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                    putExtra(BlockActivity.EXTRA_PACKAGE, pkg)
                    putExtra(BlockActivity.EXTRA_REASON, BlockActivity.REASON_PROTECTION)
                    putExtra(BlockActivity.EXTRA_DETAIL, "")
                }
            )
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val ID = 1013
        private const val TICK_MS = 600L
        private const val LOOKBACK_MS = 6_000L
        private const val STOP_AFTER_CONNECTED_TICKS = 25

        /** True when the fallback guard is wanted: protection on, accessibility not running. Never throws. */
        fun wanted(context: Context): Boolean = try {
            SafetyConfig.UNINSTALL_PROTECTION &&
                !AppBlockerService.connected &&
                (Permissions.isAdminActive(context) || BootCoverService.rememberedAdmin(context) ||
                    runCatching { FocusStore.get(context).current().advancedProtection }.getOrDefault(false))
        } catch (_: Exception) {
            false
        }

        /** Starts the guard when it is wanted. Safe to call often and from any place. */
        fun startIfNeeded(context: Context) {
            val app = context.applicationContext
            if (!wanted(app)) return
            try {
                ContextCompat.startForegroundService(app, Intent(app, LostGuardService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
