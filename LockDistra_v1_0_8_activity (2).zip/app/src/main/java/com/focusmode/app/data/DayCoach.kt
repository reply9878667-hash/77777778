package com.focusmode.app.data

import java.time.LocalDate
import java.time.ZoneId

/**
 * Day Coach: only two times are set, the day start and the sleep time. Nothing else is planned or blocked.
 *  - at the day start: "Good morning", with 5 minutes to get fresh;
 *  - 5 minutes later: the FIRST task of the Daily Tasks list (Today) is told as a message;
 *  - 15 minutes before the sleep time: a reminder to set (or check) tomorrow's tasks;
 *  - at the sleep time: "Good night".
 * The messages come as notifications, so they show when the app is closed and also as a banner while the app is open.
 *
 * Everything in this file is plain Kotlin (no Android classes) so it can be unit tested on a JVM.
 * Times are minutes after local midnight (0..1439); days are yyyymmdd keys like [DailyTaskRules.dayKey].
 */
data class CoachSettings(
    val enabled: Boolean = false,
    /** When the coach says good morning. */
    val dayStartMin: Int = DayCoachRules.DEFAULT_DAY_START,
    /** The person's sleep time; the night messages are counted back from it. */
    val sleepMin: Int = DayCoachRules.DEFAULT_SLEEP,
)

enum class CoachEventType { DAY_START, FIRST_TASK, PLAN_REMINDER, GOOD_NIGHT }

/**
 * Something the coach does at [at]. It is still done if the phone was asleep and wakes up late, but only until
 * [validUntil]; after that it is skipped. [key] is unique per event and its second part is always the day.
 */
data class CoachEvent(
    val key: String,
    val type: CoachEventType,
    val at: Long,
    val validUntil: Long,
    val dayKey: Int,
)

object DayCoachRules {

    const val DEFAULT_DAY_START = 6 * 60
    const val DEFAULT_SLEEP = 23 * 60
    const val DAY_MIN = 24 * 60

    /** Minutes between "Good morning" and the first-task message. */
    const val FRESH_UP_MIN = 5
    const val PLAN_REMIND_BEFORE = 15

    private const val MIN_MS = 60_000L

    fun clampMin(m: Int) = m.coerceIn(0, DAY_MIN - 1)

    // ---- Days ---------------------------------------------------------------------------------------------------

    fun dayKey(ms: Long, zone: ZoneId = ZoneId.systemDefault()): Int = DailyTaskRules.dayKey(ms, zone)

    fun toDate(day: Int): LocalDate = LocalDate.of(day / 10_000, day / 100 % 100, day % 100)

    fun addDays(day: Int, n: Int): Int {
        val d = toDate(day).plusDays(n.toLong())
        return d.year * 10_000 + d.monthValue * 100 + d.dayOfMonth
    }

    /** Local wall-clock [minute] of [day] as epoch milliseconds. */
    fun atMs(day: Int, minute: Int, zone: ZoneId = ZoneId.systemDefault()): Long =
        toDate(day).atStartOfDay().plusMinutes(minute.toLong()).atZone(zone).toInstant().toEpochMilli()

    // ---- Events -------------------------------------------------------------------------------------------------

    /** Every event of yesterday, today and tomorrow (yesterday because a night can run past midnight). */
    fun events(s: CoachSettings, today: Int, zone: ZoneId = ZoneId.systemDefault()): List<CoachEvent> {
        if (!s.enabled) return emptyList()
        val out = ArrayList<CoachEvent>()
        for (d in listOf(addDays(today, -1), today, addDays(today, 1))) {
            val dayStart = atMs(d, s.dayStartMin, zone)
            out += CoachEvent("ds:$d", CoachEventType.DAY_START, dayStart, dayStart + FRESH_UP_MIN * MIN_MS, d)
            val first = dayStart + FRESH_UP_MIN * MIN_MS
            out += CoachEvent("ft:$d", CoachEventType.FIRST_TASK, first, first + 120 * MIN_MS, d)
            // The night whose sleep time is on day d.
            val sleepAt = atMs(d, s.sleepMin, zone)
            out += CoachEvent("pr:$d", CoachEventType.PLAN_REMINDER, sleepAt - PLAN_REMIND_BEFORE * MIN_MS, sleepAt, d)
            out += CoachEvent("gn:$d", CoachEventType.GOOD_NIGHT, sleepAt, sleepAt + 60 * MIN_MS, d)
        }
        return out
    }

    /** Events whose time has come, are still worth doing and have not been done yet, oldest first. */
    fun due(events: List<CoachEvent>, handled: Set<String>, now: Long): List<CoachEvent> =
        events.filter { it.key !in handled && it.at <= now && now <= it.validUntil }.sortedBy { it.at }

    /** When the next event after [now] happens, or null when there is none. */
    fun nextAt(events: List<CoachEvent>, handled: Set<String>, now: Long): Long? =
        events.filter { it.key !in handled && it.at > now }.minOfOrNull { it.at }

    /** Forgets the keys of days that are over (the second part of a key is its day). */
    fun pruneHandled(handled: Set<String>, today: Int): Set<String> {
        val keep = addDays(today, -2)
        return handled.filterTo(HashSet()) { k ->
            val day = k.split(":").getOrNull(1)?.toIntOrNull() ?: return@filterTo false
            day >= keep
        }
    }

    // ---- The tasks the messages talk about -----------------------------------------------------------------------

    /** The first task of the Today list (list order) that is not done yet, or null. */
    fun firstTask(board: TaskBoard): DailyTask? =
        board.tasks.firstOrNull { it.tag == TaskTag.TODAY && !it.done }

    /** How many unfinished Tomorrow tasks are set. */
    fun tomorrowCount(board: TaskBoard): Int = board.tasks.count { it.tag == TaskTag.TOMORROW && !it.done }
}

data class CoachMessage(val title: String, val text: String)

/** The coach's words: friendly Hinglish. */
object CoachMessages {

    private const val SUN = "\u2600\uFE0F"
    private const val MUSCLE = "\uD83D\uDCAA"
    private const val MOON = "\uD83C\uDF19"
    private const val SLEEP = "\uD83D\uDE34"
    private const val MEMO = "\uD83D\uDCDD"
    private const val ROCKET = "\uD83D\uDE80"

    private fun t(min: Int) = BedtimeRules.format(min)

    /** At the day start. */
    fun goodMorning(): CoachMessage = CoachMessage(
        "Good morning $SUN",
        "Fresh ho jao, tumhare paas ${DayCoachRules.FRESH_UP_MIN} minute hain. Uske baad main tumhara pehla task bataunga $MUSCLE",
    )

    /** [DayCoachRules.FRESH_UP_MIN] minutes later: the first task of the list. */
    fun firstTask(task: DailyTask?): CoachMessage =
        if (task == null) CoachMessage(
            "Aaj ka task list khali hai $MEMO",
            "Abhi koi task nahi mila. Home par apne tasks daal do, phir shuru karo $ROCKET",
        ) else CoachMessage(
            "Pehla task $ROCKET",
            task.text + "\nChalo, abhi shuru karo $MUSCLE",
        )

    /** 15 minutes before the sleep time: set (or check) tomorrow's tasks. */
    fun planReminder(tomorrowTasks: Int): CoachMessage =
        if (tomorrowTasks == 0) CoachMessage(
            "Kal ke tasks set karo $MEMO",
            "Sone mein ${DayCoachRules.PLAN_REMIND_BEFORE} minute bache hain. Abhi Home mein Tomorrow Tasks daal do, phir aaram se so jao $SLEEP",
        ) else CoachMessage(
            "Kal ke tasks check karo $MEMO",
            "Kal ke $tomorrowTasks task ready hain. Sone se pehle ek baar dekh lo, kuch jodna ho to abhi jod do $SLEEP",
        )

    /** At the sleep time. */
    fun goodNight(dayStartMin: Int): CoachMessage = CoachMessage(
        "Good night $MOON",
        "Ab phone side mein rakho aur so jao. Kal subah ${t(dayStartMin)} baje milte hain $SLEEP",
    )
}
