package com.focusmode.app.ui.tips

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.delay

/** Where the marked elements are on screen. Filled by [tipTarget], read by the spotlight. */
object TipTargets {
    val bounds = mutableStateMapOf<String, Rect>()
}

/** Marks an element so a hint can spotlight it: `Modifier.tipTarget("auto_chip")`. */
fun Modifier.tipTarget(key: String): Modifier = composed {
    DisposableEffect(key) { onDispose { TipTargets.bounds.remove(key) } }
    onGloballyPositioned { TipTargets.bounds[key] = it.boundsInRoot() }
}

/**
 * Shows the next fitting hint on [screen]. Place it LAST inside the full-screen root Box so it draws over everything.
 *
 * [enabled] must be false while any dialog, sheet or full-screen prompt is open (and while a session runs): the hint is
 * then removed, and it comes back the next time the person is on a quiet screen.
 * [onAction] gets the tip id when the person taps the "Try it" button.
 */
@Composable
fun FeatureTipsHost(
    store: FeatureTipsStore,
    screen: String,
    enabled: Boolean,
    onAction: (String) -> Unit,
) {
    val tips by store.state.collectAsStateWithLifecycle()
    var current by remember { mutableStateOf<Tip?>(null) }

    LaunchedEffect(screen, enabled, tips.enabled) {
        current = null
        if (!enabled || !tips.enabled) return@LaunchedEffect
        // Let the screen settle (its slide-in animation) before pointing at anything.
        delay(1600)
        val tip = FeatureTips.pick(store.state.value, screen, System.currentTimeMillis())
        if (tip != null) {
            store.markShown()
            current = tip
        }
    }

    current?.let { tip ->
        BackHandler { store.markSeen(tip.id); current = null }
        val rect = tip.target?.let { TipTargets.bounds[it] }
        TipOverlay(
            tip = tip,
            target = rect,
            onGotIt = { store.markSeen(tip.id); current = null },
            onAction = { store.markSeen(tip.id); current = null; onAction(tip.id) },
            onSkipAll = { store.setEnabled(false); current = null },
        )
    }
}

@Composable
private fun TipOverlay(
    tip: Tip,
    target: Rect?,
    onGotIt: () -> Unit,
    onAction: () -> Unit,
    onSkipAll: () -> Unit,
) {
    val c = FocusTheme.colors
    val density = LocalDensity.current

    val pulse = rememberInfiniteTransition(label = "tipPulse")
    val ring by pulse.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Restart),
        label = "tipRing"
    )
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val fade by animateFloatAsState(if (shown) 1f else 0f, tween(260), label = "tipFade")

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = fade }
            // Taps on the dimmed screen are swallowed: the hint is answered with its buttons.
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        val screenH = constraints.maxHeight.toFloat()
        // Ignore a target that scrolled out of view or has no size yet.
        val usable = target?.takeIf { it.width > 0f && it.height > 0f && it.bottom > 0f && it.top < screenH }
        val hole = usable?.inflate(with(density) { 8.dp.toPx() })

        Canvas(Modifier.fillMaxSize().graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }) {
            drawRect(Color.Black.copy(alpha = 0.66f))
            if (hole != null) {
                val radius = minOf(hole.height / 2f, 28.dp.toPx())
                // Cut the spotlight out of the dimmed layer.
                drawRoundRect(
                    color = Color.Black, topLeft = hole.topLeft, size = hole.size,
                    cornerRadius = CornerRadius(radius), blendMode = BlendMode.Clear
                )
                drawRoundRect(
                    color = c.accent, topLeft = hole.topLeft, size = hole.size,
                    cornerRadius = CornerRadius(radius), style = Stroke(2.dp.toPx())
                )
                // Pulse: a second ring grows outward and fades.
                val grow = ring * 18.dp.toPx()
                drawRoundRect(
                    color = c.accent.copy(alpha = (1f - ring) * 0.75f),
                    topLeft = Offset(hole.left - grow, hole.top - grow),
                    size = Size(hole.width + 2 * grow, hole.height + 2 * grow),
                    cornerRadius = CornerRadius(radius + grow),
                    style = Stroke(2.dp.toPx())
                )
            }
        }

        // The card sits next to the spotlight: below it when the element is in the upper half, above it otherwise.
        val below = hole != null && hole.center.y <= screenH / 2f
        val above = hole != null && !below
        val cardModifier = when {
            below -> Modifier.align(Alignment.TopCenter).padding(top = with(density) { hole!!.bottom.toDp() } + 18.dp)
            above -> Modifier.align(Alignment.BottomCenter).padding(bottom = with(density) { (screenH - hole!!.top).toDp() } + 18.dp)
            else -> Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 32.dp)
        }

        Column(
            cardModifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(c.card)
                .padding(horizontal = 18.dp, vertical = 16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(30.dp).clip(CircleShape).background(c.accentSoft), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Lightbulb, null, tint = c.accent, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.size(10.dp))
                Text("Tip", style = MaterialTheme.typography.labelMedium, color = c.accent)
            }
            Spacer(Modifier.height(10.dp))
            Text(tip.title, style = MaterialTheme.typography.titleMedium, color = c.text)
            Spacer(Modifier.height(6.dp))
            Text(tip.body, style = MaterialTheme.typography.bodyMedium, color = c.muted)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onSkipAll) { Text("Turn off tips", color = c.muted) }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onGotIt) { Text("Got it", color = if (tip.actionLabel == null) c.accent else c.muted) }
                tip.actionLabel?.let { TextButton(onClick = onAction) { Text(it, color = c.accent) } }
            }
        }
    }
}
