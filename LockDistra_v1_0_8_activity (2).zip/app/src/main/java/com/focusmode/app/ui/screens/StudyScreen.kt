package com.focusmode.app.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.focusmode.app.LectureActivity
import com.focusmode.app.data.ChannelAlerts
import com.focusmode.app.data.LectureLockStore
import com.focusmode.app.data.LockSession
import com.focusmode.app.data.StudyBlocklist
import com.focusmode.app.data.StudyChannel
import com.focusmode.app.data.StudyChannelInfo
import com.focusmode.app.data.StudyErrorKind
import com.focusmode.app.data.StudyException
import com.focusmode.app.data.StudyFeed
import com.focusmode.app.data.StudyMode
import com.focusmode.app.data.StudyMonitor
import com.focusmode.app.data.StudySwitch
import com.focusmode.app.data.WebHandoff
import com.focusmode.app.data.StudyRepository
import com.focusmode.app.data.StudyRules
import com.focusmode.app.data.StudyStore
import com.focusmode.app.data.StudyVideo
import com.focusmode.app.data.StudyWeb
import com.focusmode.app.ui.components.ChannelSubscribeControl
import com.focusmode.app.ui.components.CircleIconButton
import com.focusmode.app.ui.components.FocusCard
import com.focusmode.app.ui.components.NearEndEffect
import com.focusmode.app.ui.components.PrimaryButton
import com.focusmode.app.ui.components.SectionLabel
import com.focusmode.app.ui.components.SearchLoading
import com.focusmode.app.ui.components.ShimmerFill
import com.focusmode.app.ui.components.ShortSkeletonGrid
import com.focusmode.app.ui.components.SkeletonLine
import com.focusmode.app.ui.components.SoftChip
import com.focusmode.app.ui.components.VideoSkeletonList
import com.focusmode.app.ui.theme.FocusTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

// Sized by memory, not by count: sharp (1280 px) pictures are large, so the cache holds as many as fit in a safe budget.
private val thumbCache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtMost(48 * 1024 * 1024)) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
}

/** Old saved feeds hold the small 320 px picture; ask for the sharp one instead (hqdefault always exists). */
private fun sharpThumb(url: String): String =
    if (url.endsWith("/mqdefault.jpg") || url.endsWith("/default.jpg")) url.substringBeforeLast('/') + "/hqdefault.jpg" else url

private fun thumbFile(dir: java.io.File, url: String) = java.io.File(dir, "t" + Integer.toHexString(url.hashCode()) + ".jpg")

// A picture that could not be loaded (address -> time) is not asked for again for a few minutes: a broken address must not
// cause a new request every time its card scrolls back into view.
private val failedThumbs: MutableMap<String, Long> = java.util.Collections.synchronizedMap(HashMap<String, Long>())
private const val FAILED_RETRY_MS = 5L * 60 * 1000

// One lock per address being loaded: the same picture on two cards (or a logo under ten videos) is downloaded only once.
private val thumbLocks = java.util.concurrent.ConcurrentHashMap<String, Any>()

private const val THUMB_DISK_MAX = 80L * 1024 * 1024
private const val THUMB_DISK_KEEP = 50L * 1024 * 1024
@Volatile private var thumbDiskChecked = false

/** Keeps the saved pictures from growing for ever: once per app start, the oldest are deleted when they pass 80 MB. */
private fun trimThumbDisk(dir: java.io.File) {
    if (thumbDiskChecked) return
    thumbDiskChecked = true
    val files = dir.listFiles() ?: return
    var total = 0L
    for (f in files) total += f.length()
    if (total <= THUMB_DISK_MAX) return
    for (f in files.sortedBy { it.lastModified() }) {
        if (total <= THUMB_DISK_KEEP) break
        total -= f.length()
        f.delete()
    }
}

/** A picture from the phone's disk if it was loaded before (no network at all), otherwise downloaded once and saved. */
private fun fetchBitmap(url: String, dir: java.io.File?): Bitmap? {
    val file = dir?.let { thumbFile(it, url) }
    if (file != null && file.length() > 0L) {
        val saved = BitmapFactory.decodeFile(file.path)
        if (saved != null) { runCatching { file.setLastModified(System.currentTimeMillis()) }; return saved }
        file.delete() // a damaged file: it is downloaded again below
    }
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 6000
    c.readTimeout = 8000
    // The stream is closed (not disconnect()), so the connection to YouTube's picture server is reused for the next picture.
    if (c.responseCode != 200) { c.errorStream?.close(); return null }
    val bytes = c.inputStream.use { it.readBytes() }
    // Bytes that are not a picture (an error page that came with code 200) are never saved.
    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
    if (file != null) runCatching { file.writeBytes(bytes) }
    return bmp
}

/** Memory first, then disk / network; two cards asking for the same picture at the same time share one download. */
private fun loadThumb(url: String, dir: java.io.File?): Bitmap? {
    thumbCache.get(url)?.let { return it }
    val lock = thumbLocks.getOrPut(url) { Any() }
    val loaded: Bitmap? = try {
        synchronized(lock) {
            // Another card may have finished the same picture while this one waited for the lock.
            thumbCache.get(url) ?: runCatching { fetchBitmap(url, dir) }.getOrNull()?.also { thumbCache.put(url, it) }
        }
    } finally {
        thumbLocks.remove(url)
    }
    return loaded
}

/**
 * A picture from YouTube, loaded once and kept in memory. A broken or missing address shows a quiet placeholder (not an empty
 * hole); [placeholder] = false is for round channel logos, which draw their own first letter instead ([onFailed] tells them).
 */
@Composable
internal fun Thumb(url: String, modifier: Modifier = Modifier, placeholder: Boolean = true, onFailed: (() -> Unit)? = null) {
    val c = FocusTheme.colors
    val ctx = LocalContext.current
    val diskDir = remember(ctx) { java.io.File(ctx.cacheDir, "study_thumbs").apply { mkdirs() } }
    val address = remember(url) { sharpThumb(StudyRules.imageUrl(url)) }
    val skip = address.isEmpty() || (failedThumbs[address]?.let { System.currentTimeMillis() - it < FAILED_RETRY_MS } ?: false)
    var failed by remember(address) { mutableStateOf(skip) }
    val bmp by produceState<ImageBitmap?>(initialValue = thumbCache.get(address)?.asImageBitmap(), key1 = address) {
        if (value == null && !failed) {
            val loaded = withContext(Dispatchers.IO) {
                trimThumbDisk(diskDir)
                loadThumb(address, diskDir)
                    ?: if (address.endsWith("/maxresdefault.jpg")) loadThumb(address.replace("maxresdefault", "hqdefault"), diskDir) else null
            }
            if (loaded != null) {
                thumbCache.put(address, loaded)
                value = loaded.asImageBitmap()
            } else {
                failedThumbs[address] = System.currentTimeMillis()
                failed = true
            }
        }
    }
    LaunchedEffect(failed) { if (failed) onFailed?.invoke() }
    // A picture already in memory shows at once; a new one fades in over the shimmering placeholder (no pop-in).
    val fade by animateFloatAsState(if (bmp != null) 1f else 0f, tween(260), label = "thumbFade")
    Box(modifier.background(c.cardHigh), contentAlignment = Alignment.Center) {
        if (!failed && (bmp == null || fade < 1f)) ShimmerFill(Modifier.fillMaxSize())
        if (failed && bmp == null && placeholder) Icon(Icons.Rounded.School, null, tint = c.muted, modifier = Modifier.size(32.dp))
        bmp?.let { Image(it, null, Modifier.fillMaxSize().graphicsLayer { alpha = fade }, contentScale = ContentScale.Crop) }
    }
}

@Composable
private fun LengthBadge(seconds: Int, modifier: Modifier = Modifier) {
    Text(
        StudyRules.formatLength(seconds),
        style = MaterialTheme.typography.labelSmall,
        color = Color.White,
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.72f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    )
}

@Composable
private fun ShortCard(v: StudyVideo, onClick: () -> Unit) {
    val c = FocusTheme.colors
    Column(Modifier.clickable(onClick = onClick)) {
        Box {
            // A Short's picture is a 16:9 frame with the vertical video in the middle: a centre crop shows just the video.
            Thumb(v.thumbUrl, Modifier.fillMaxWidth().aspectRatio(9f / 16f).clip(RoundedCornerShape(18.dp)))
            LengthBadge(v.seconds, Modifier.align(Alignment.BottomEnd).padding(8.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(v.title, style = MaterialTheme.typography.bodySmall, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
        StudyRules.timeAgo(v.publishedAt).takeIf { it.isNotEmpty() }?.let {
            Text(it, style = MaterialTheme.typography.labelSmall, color = c.muted, maxLines = 1)
        }
    }
}

/** The short notice after a blocked search: one line of what happened, one of what is shown instead, and a close button. */
@Composable
internal fun BlockedNotice(onClose: () -> Unit) {
    val c = FocusTheme.colors
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp).clip(RoundedCornerShape(14.dp)).background(c.accentSoft).padding(start = 14.dp, top = 10.dp, bottom = 10.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.School, null, tint = c.accent, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(StudyBlocklist.NOTICE_TITLE, style = MaterialTheme.typography.titleSmall, color = c.text)
            Text(StudyBlocklist.NOTICE_BODY, style = MaterialTheme.typography.bodySmall, color = c.muted)
        }
        IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Close", tint = c.muted) }
    }
}

@Composable
internal fun MessageCard(title: String, body: String, action: String? = null, onAction: () -> Unit = {}) {
    val c = FocusTheme.colors
    FocusCard {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(c.accentSoft), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.School, null, tint = c.accent, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, color = c.text, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(body, style = MaterialTheme.typography.bodySmall, color = c.muted, textAlign = TextAlign.Center)
            if (action != null) {
                Spacer(Modifier.height(14.dp))
                PrimaryButton(action, onAction, Modifier.fillMaxWidth())
            }
        }
    }
}

/** A channel's round picture (its real logo once loaded, otherwise its first letter), like under a YouTube video. */
@Composable
private fun ChannelAvatar(name: String, url: String, modifier: Modifier = Modifier, size: Dp = 38.dp) {
    val c = FocusTheme.colors
    // A picture that cannot be loaded (broken address) leaves the first letter in its place, never an empty circle.
    var broken by remember(url) { mutableStateOf(false) }
    Box(modifier.size(size).clip(CircleShape).background(c.accentSoft), contentAlignment = Alignment.Center) {
        if (url.isNotEmpty() && !broken) Thumb(url, Modifier.fillMaxSize(), placeholder = false, onFailed = { broken = true })
        else Text(name.trim().take(1).uppercase().ifEmpty { "?" }, color = c.accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
    }
}

/**
 * A normal video as YouTube's home shows it: the picture edge to edge, then channel logo, title and channel name.
 * Tapping the logo or the name opens that channel ([onChannel]); null = already on that channel's page.
 */
@Composable
private fun VideoItem(v: StudyVideo, avatarUrl: String, onChannel: (() -> Unit)?, onClick: () -> Unit) {
    val c = FocusTheme.colors
    val channelTap = if (onChannel != null) Modifier.clickable(onClick = onChannel) else Modifier
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box {
            Thumb(v.thumbUrl, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
            LengthBadge(v.seconds, Modifier.align(Alignment.BottomEnd).padding(8.dp))
        }
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 8.dp), verticalAlignment = Alignment.Top) {
            ChannelAvatar(v.channelTitle, avatarUrl, channelTap)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(v.title, style = MaterialTheme.typography.titleSmall, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    listOf(v.channelTitle, StudyRules.timeAgo(v.publishedAt)).filter { it.isNotEmpty() }.joinToString("  ·  "),
                    style = MaterialTheme.typography.bodySmall, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    // The whole line, and taller than the text, is the channel's tap target (a thin line was easy to miss).
                    modifier = channelTap.fillMaxWidth().padding(vertical = 8.dp)
                )
            }
        }
    }
}

private var webEngineWarm = false

private enum class StudyView { MAIN, SETTINGS, NOTIFICATIONS, SUBSCRIPTIONS }

private enum class StudyBody { SKELETON, SEARCHING, CONTENT }

/**
 * The Study tab: a YouTube that only shows learning videos, laid out like YouTube (no title, a search icon on top, subject
 * chips, big pictures). Tapping a video plays it at once in LockDistra's player ([LectureActivity] in preview mode) with
 * "Start Focus Mode" under it. While a Focus session runs, tapping a video swaps the lecture ([onSwitchLecture]).
 * Videos played here shape the suggestions: the channels played most fill the feed.
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun StudyScreen(
    sessionActive: Boolean = false,
    /** True only when the running session already has a lecture (a link was set): then a tapped video replaces it. Otherwise it only previews. */
    lectureBound: Boolean = false,
    onSwitchLecture: (StudyVideo) -> Unit = {},
) {
    val c = FocusTheme.colors
    val context = LocalContext.current
    val store = remember { StudyStore.get(context) }
    val repo = remember { StudyRepository(store) }
    val scope = rememberCoroutineScope()
    // The scroll positions live here (not inside the list), so coming back from a channel / Shorts viewer / settings shows the
    // list exactly where it was left instead of at the top.
    val listState = rememberLazyListState()
    val gridState = rememberLazyGridState()

    // First time the Study section is opened: the benefits popup, once.
    var showBenefits by remember { mutableStateOf(!store.benefitsSeen) }
    if (showBenefits) StudyBenefitsDialog(onDone = { store.benefitsSeen = true; showBenefits = false })

    var view by remember { mutableStateOf(StudyView.MAIN) }
    var channel by remember { mutableStateOf<StudyChannel?>(null) }
    // The Short that was tapped (id): the full-screen Shorts viewer is open while this is set.
    var viewerStart by remember { mutableStateOf<String?>(null) }
    // True from a pull-down until that refresh ends (drives the pull-to-refresh indicator).
    var pulling by remember { mutableStateOf(false) }
    var avatars by remember { mutableStateOf(store.avatars()) }
    var unread by remember { mutableStateOf(store.unreadCount()) }
    // Source indicator: the title keeps its normal colour on the API, turns yellow on the page-data search and red on the WebView.
    // Nothing else is shown: the switching itself is all automatic (StudyRepository / StudyMonitor).
    val sourceMode by StudyMonitor.mode.collectAsState()
    val titleColor = when (sourceMode) {
        StudyMode.API -> c.text
        StudyMode.PAGE -> Color(0xFFFFC107)
        StudyMode.WEB -> Color(0xFFFF4D4D)
    }
    // Part 3/4: while a request runs on a fallback source a thin loading line shows (after a short delay, so a quick switch does not
    // flicker). The list on screen stays untouched.
    val switching by StudySwitch.switching.collectAsState()
    var showSwitching by remember { mutableStateOf(false) }
    LaunchedEffect(switching) {
        if (switching) { delay(250); showSwitching = true } else showSwitching = false
    }
    var searchOpen by remember { mutableStateOf(false) }
    var shortsTab by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var activeQuery by remember { mutableStateOf<String?>(null) }
    // Web search (backup when the daily YouTube limit is used up): set = the search is read from YouTube's own page and
    // shown by [StudyWebSearch], which looks like the normal list (no note, nothing tells the person the limit is out).
    var webQuery by remember { mutableStateOf<String?>(null) }
    // True after a search with a blocked word (comedy, adult, games...): that search was not made, a short notice shows
    // and the normal study videos are shown instead. Goes away with the next search.
    var blockedNotice by remember { mutableStateOf(false) }

    var feed by remember { mutableStateOf<StudyFeed?>(null) }
    var results by remember { mutableStateOf<List<StudyVideo>>(emptyList()) }
    // Channels whose name matches the search (shown above the videos), so a creator is found by the channel's name.
    var channelHits by remember { mutableStateOf<List<com.focusmode.app.data.NativeChannel>>(emptyList()) }
    var nextToken by remember { mutableStateOf<String?>(null) }
    // Three separate loading states: the home feed (skeleton), a search (spinner) and "Load more" (small spinner).
    // The feed starts as "loading" so the very first frame is the skeleton, never a flash of "Nothing here yet".
    var feedLoading by remember { mutableStateOf(true) }
    var searching by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    // Endless Home scroll: "more" is loading / there may be more / (when a load failed it stays off until the next pull-down).
    var feedMoreLoading by remember { mutableStateOf(false) }
    var feedHasMore by remember { mutableStateOf(true) }
    val loading = feedLoading || searching || loadingMore || feedMoreLoading
    // Newest request numbers [feed, search]: an answer that arrives after a newer request was made is ignored.
    val seq = remember { intArrayOf(0, 0) }
    var error by remember { mutableStateOf<StudyException?>(null) }
    val searchFocus = remember { FocusRequester() }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }
    var recents by remember { mutableStateOf(store.recents) }

    fun fail(e: Exception) {
        error = if (e is StudyException) e else StudyException(StudyErrorKind.OTHER, "Something went wrong. Try again.")
    }

    /** Shows [text] as a web search (no API quota). */
    fun startWeb(text: String) {
        // Already showing this web search (two failures of the same request): never start a second one.
        if (webQuery == text && activeQuery == text) return
        seq[1]++ // an API search still running is dropped
        searching = false; loadingMore = false; error = null
        results = emptyList(); nextToken = null
        activeQuery = text
        webQuery = text
        StudyMonitor.report(StudyMode.WEB)
    }

    fun loadFeed(force: Boolean, manual: Boolean = false) {
        val my = ++seq[0]
        feedHasMore = true
        scope.launch {
            feedLoading = true
            if (activeQuery == null) error = null
            try {
                val loaded = withContext(Dispatchers.IO) {
                    val base = repo.feed(force, manual = manual)
                    com.focusmode.app.data.PromoVideo.inFeed(base, runCatching { com.focusmode.app.data.PromoVideo.next(context, "home") }.getOrNull())
                }
                if (my == seq[0]) feed = loaded
            } catch (e: Exception) {
                if (my == seq[0] && activeQuery == null) {
                    // What is already on screen stays: a failed refresh never replaces the list by an error card or a popup.
                    val hasContent = !feed?.videos.isNullOrEmpty() || !feed?.shorts.isNullOrEmpty()
                    if (!hasContent) {
                        // API and Direct YouTube could not serve it and nothing is saved: the first subject opens as a web search.
                        if (e is WebHandoff && !shortsTab) startWeb(store.selected.ifEmpty { store.subjects }.firstOrNull() ?: "Maths")
                        else fail(e)
                    }
                }
            } finally {
                if (my == seq[0]) feedLoading = false
            }
        }
    }

    /** A search with a blocked word is never sent: the notice shows and the study videos (home) show instead. */
    fun blockSearch() {
        seq[1]++ // a search still running is dropped
        searching = false; loadingMore = false; error = null
        results = emptyList(); nextToken = null
        query = ""; activeQuery = null; webQuery = null
        blockedNotice = true
        // The home loads through the source switcher (API, Direct YouTube, then Web as the last backup).
        if (feed == null) loadFeed(false)
    }

    /** Home scroll reached the end of what is shown: the next older videos are added (never replaces what is on screen). */
    fun loadMoreFeed() {
        val current = feed ?: return
        if (activeQuery != null || webQuery != null || error != null) return
        if (feedMoreLoading || feedLoading || !feedHasMore) return
        feedMoreLoading = true
        val my = seq[0]
        scope.launch {
            try {
                val seen = (current.videos + current.shorts).map { it.id }.toSet()
                val more = withContext(Dispatchers.IO) { repo.feedMore(seen) }
                // A pull-to-refresh / new feed started meanwhile: this answer belongs to the old list, drop it.
                if (my != seq[0]) return@launch
                val now = feed ?: return@launch
                feed = StudyFeed(
                    (now.videos + more.feed.videos).distinctBy { it.id },
                    (now.shorts + more.feed.shorts).distinctBy { it.id }
                )
                feedHasMore = more.hasMore
            } catch (e: Exception) {
                // Nothing more could be loaded now (no internet / limit): the list stays as it is, no error screen; the next pull-down tries again.
                if (my == seq[0]) feedHasMore = false
            } finally {
                feedMoreLoading = false
            }
        }
    }

    fun runSearch(q: String, more: Boolean = false, manual: Boolean = false) {
        val text = q.trim()
        if (text.isEmpty()) return
        // A blocked word (comedy, adult, games, songs...): the search is not made at all.
        if (!more && StudyBlocklist.blockedSearch(text) != null) { blockSearch(); return }
        if (!more) blockedNotice = false
        // Which source answers (YouTube API, Direct YouTube page data, then the WebView below) is decided by the source switcher.
        // Automatic next page: never while a request is running, and never once the last page was reached.
        if (more && (loadingMore || searching || nextToken == null)) return
        val my = ++seq[1]
        if (!more) {
            // A new search: the old results go away at once, so the spinner (not stale videos) shows while it runs.
            activeQuery = text
            results = emptyList()
            nextToken = null
            loadingMore = false
            channelHits = emptyList()
            // Channels come on their own, so slow channel data never holds the videos back.
            scope.launch {
                val hits = withContext(Dispatchers.IO) { runCatching { repo.searchChannels(text) }.getOrDefault(emptyList()) }
                if (my == seq[1]) channelHits = hits
            }
        }
        // Set at once (not inside the coroutine), so a second call in the same frame sees the request already running.
        if (more) loadingMore = true else searching = true
        scope.launch {
            error = null
            try {
                val shorts = shortsTab
                val token = if (more) nextToken else null
                val page = withContext(Dispatchers.IO) {
                    val p = repo.search(text, shorts, token, manual)
                    val promo = if (more) null else runCatching { com.focusmode.app.data.PromoVideo.next(context, "search") }.getOrNull()
                    if (promo != null && promo.isShort == shorts) p.copy(videos = listOf(promo) + p.videos.filter { it.id != promo.id }) else p
                }
                if (my != seq[1]) return@launch
                results = if (more) (results + page.videos).distinctBy { it.id } else page.videos
                nextToken = page.next
            } catch (e: Exception) {
                if (my == seq[1]) {
                    if (more) {
                        // The next page could not be loaded: the results already shown stay, paging simply stops (no error card, no reset).
                        nextToken = null
                    } else if (e is WebHandoff && !shortsTab) {
                        // The API and the page-data search could not serve it: the same search continues in the WebView, no error screen.
                        startWeb(text)
                    } else fail(e)
                }
            } finally {
                if (my == seq[1]) { searching = false; loadingMore = false }
            }
        }
    }

    fun clearSearch() {
        seq[1]++ // a search still running is dropped
        searching = false; loadingMore = false
        query = ""; activeQuery = null; results = emptyList(); nextToken = null; error = null
        channelHits = emptyList()
        webQuery = null
        blockedNotice = false
        StudyMonitor.sync(store.apiAvailable)
    }

    /** A video was tapped: it plays at once (or, during a Focus session, becomes the lecture). */
    fun play(v: StudyVideo) {
        store.noteWatched(v.channelId, v.channelTitle)
        if (v.isShort) LectureLockStore.get(context).saveRatio(v.id, 9f / 16f)
        if (sessionActive && lectureBound) onSwitchLecture(v) else {
            LockSession.markOwnLaunch()
            runCatching { context.startActivity(LectureActivity.previewIntent(context, v)) }
        }
    }

    /** A Short was tapped: the swipe viewer opens (during a Focus session it becomes the lecture instead, as any video). */
    fun openShort(v: StudyVideo) {
        if (sessionActive) play(v) else viewerStart = v.id
    }

    LaunchedEffect(Unit) {
        // Coming from a "new video" notification: play that video first.
        store.takePendingOpen()?.let { play(it) }
        // A new random mix from the saved pool on every app launch (same mix when coming back inside the app).
        val launch = withContext(Dispatchers.IO) {
            repo.launchFeed()?.let { base ->
                com.focusmode.app.data.PromoVideo.inFeed(base, runCatching { com.focusmode.app.data.PromoVideo.next(context, "home") }.getOrNull())
            }
        }
        if (launch != null) {
            feed = launch
            feedLoading = false
            // Fresh videos for the NEXT launch are fetched quietly (at most every 30 minutes); the list on screen does not jump.
            withContext(Dispatchers.IO) { if (repo.needsQuietRefresh()) runCatching { repo.feed(force = true, quiet = true) } }
        } else {
            withContext(Dispatchers.IO) { repo.cachedFeed() }?.let { feed = it }
            loadFeed(false)
        }
    }

    // The browser engine inside the app (WebView) takes a moment to start the first time: it is started now, quietly, while the
    // list is being read, so the first tapped video does not have to wait for it.
    LaunchedEffect(Unit) {
        delay(600)
        if (!webEngineWarm) {
            webEngineWarm = true
            // The same start-up is the proof that the WebView can be created: a failure is recorded for the Web source.
            runCatching { android.webkit.WebView(context.applicationContext).destroy() }
                .onSuccess { com.focusmode.app.data.StudySources.tracker.clearReason(StudyMode.WEB, com.focusmode.app.data.SourceReason.WEBVIEW_INIT_FAILED) }
                .onFailure { com.focusmode.app.data.StudySources.tracker.failure(StudyMode.WEB, com.focusmode.app.data.SourceClassifier.webInitFailed()) }
        }
    }

    // Source detection (Part 2/4): local facts (free) and, only for a source that failed and whose cool-down is over, one small
    // re-check. No timer: it runs once per opening of the Study section, after the list had its head start.
    LaunchedEffect(Unit) {
        delay(1500)
        withContext(Dispatchers.IO) {
            runCatching {
                val checker = com.focusmode.app.data.StudySourceChecker(context.applicationContext, store)
                checker.refreshLocal()
                checker.verifyDue()
            }
        }
    }

    // Part 4/4: automatic recovery when the connection comes back. The callback exists ONLY while the Study section is on screen (no
    // service, no timer). It makes the failed sources due and re-checks them once, in the background; the list on screen is not
    // touched. Only a screen that is showing an error card retries by itself (a list that is already there is never reloaded).
    var networkTick by remember { mutableStateOf(0) }
    androidx.compose.runtime.DisposableEffect(Unit) {
        val app = context.applicationContext
        val cm = app.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        // When the phone is online right now, the first callback only repeats what is already true: it is not a recovery.
        var echo = runCatching { cm?.activeNetwork != null }.getOrDefault(false)
        val callback = object : android.net.ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: android.net.Network) {
                if (echo) { echo = false; return }
                Thread {
                    runCatching { com.focusmode.app.data.StudySourceChecker(app, store).onNetworkRestored() }
                    main.post { networkTick += 1 }
                }.apply { isDaemon = true }.start()
            }
        }
        val registered = runCatching { cm?.registerDefaultNetworkCallback(callback) }.isSuccess && cm != null
        onDispose { if (registered) runCatching { cm?.unregisterNetworkCallback(callback) } }
    }
    LaunchedEffect(networkTick) {
        if (networkTick > 0 && webQuery == null && error != null && !loading) {
            if (activeQuery != null) runSearch(activeQuery!!) else loadFeed(true)
        }
    }

    // Popups the admin set to "inside Study".
    LaunchedEffect(Unit) {
        val act = generateSequence(context) { (it as? android.content.ContextWrapper)?.baseContext }
            .firstOrNull { it is android.app.Activity } as? android.app.Activity
        val cfg = com.focusmode.app.data.RemoteConfig.get(context.applicationContext)
        if (act != null && cfg != null) com.focusmode.app.ui.CustomPopups.maybeShow(act, cfg.optJSONArray("popups"), "study")
    }

    LaunchedEffect(loading) { if (!loading) pulling = false }

    // A different search or tab starts at the top (the lists keep their position only while the same list stays on screen).
    LaunchedEffect(activeQuery, shortsTab) {
        runCatching { listState.scrollToItem(0) }
        runCatching { gridState.scrollToItem(0) }
    }

    LaunchedEffect(searchOpen) {
        if (searchOpen) {
            recents = store.recents
            runCatching { searchFocus.requestFocus() }
        }
    }

    // Suggestions while typing (a short wait after the last letter, so one word is one request).
    LaunchedEffect(query, searchOpen) {
        if (!searchOpen || query.isBlank()) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        // Instant first: the same text typed before comes straight from memory; otherwise the earlier suggestions that still
        // fit the longer text stay on screen while the new ones are fetched (no empty list between two letters).
        val saved = repo.cachedSuggest(query)
        if (saved != null) { suggestions = saved; return@LaunchedEffect }
        val typedNow = query.trim()
        suggestions = suggestions.filter { it.startsWith(typedNow, ignoreCase = true) }
        delay(60)
        suggestions = withContext(Dispatchers.IO) { repo.suggest(query) }
    }

    // Opening the search box: the connection to the suggestion service is made now, so the first letter is already fast.
    LaunchedEffect(searchOpen) {
        if (searchOpen) withContext(Dispatchers.IO) { runCatching { repo.suggest("a") } }
    }

    /** A search from the search box or a suggestion: remembered in the history, the box closes and the results show. */
    fun doSearch(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        // A blocked search is not remembered in the history.
        if (StudyBlocklist.blockedSearch(t) != null) { searchOpen = false; blockSearch(); return }
        store.addRecent(t)
        query = t
        searchOpen = false
        runSearch(t)
    }

    // Channel logos of everything on screen (one cheap request for up to 50 channels).
    val listed = if (activeQuery != null) results else feed?.videos.orEmpty() + feed?.shorts.orEmpty()
    LaunchedEffect(listed.map { it.channelId }.toSet()) {
        if (listed.none { it.channelId.isNotEmpty() }) return@LaunchedEffect
        // Pictures saved meanwhile (for example by the page-data search) show at once, then only the missing ones are asked for.
        val saved = withContext(Dispatchers.IO) { store.avatars() }
        if (saved != avatars) avatars = saved
        val wanted = listed.map { it.channelId }.filter { it.isNotEmpty() && it !in saved }.distinct()
        if (wanted.isEmpty()) return@LaunchedEffect
        withContext(Dispatchers.IO) { runCatching { repo.loadAvatars(wanted) } }
        avatars = store.avatars()
    }
    LaunchedEffect(view, channel) { unread = store.unreadCount() }

    BackHandler(enabled = view != StudyView.MAIN || channel != null || searchOpen) {
        if (channel != null) {
            channel = null
        } else if (view != StudyView.MAIN) {
            if (view == StudyView.SETTINGS) loadFeed(false)
            view = StudyView.MAIN
        } else {
            searchOpen = false
            clearSearch()
        }
    }

    if (view == StudyView.SETTINGS) {
        StudySettings(store, repo, onBack = { view = StudyView.MAIN; loadFeed(false) })
        return
    }

    if (view == StudyView.NOTIFICATIONS) {
        NotificationsScreen(store, avatars, onBack = { view = StudyView.MAIN }, onPlay = { play(it) })
        return
    }
    channel?.let { ch ->
        ChannelScreen(ch, avatars[ch.id].orEmpty(), avatars, store, repo, swipeShorts = !sessionActive, onBack = { channel = null }, onPlay = { play(it) })
        return
    }

    if (view == StudyView.SUBSCRIPTIONS) {
        LaunchedEffect(Unit) {
            val wanted = store.channels.map { it.id }.filter { it !in avatars }
            if (wanted.isNotEmpty()) {
                withContext(Dispatchers.IO) { runCatching { repo.loadAvatars(wanted) } }
                avatars = store.avatars()
            }
        }
        SubscriptionsScreen(store, avatars, onBack = { view = StudyView.MAIN }, onOpen = { channel = it })
        return
    }

    val shownVideos: List<StudyVideo> = if (activeQuery != null) results.filter { it.isShort == shortsTab }
    else (if (shortsTab) feed?.shorts else feed?.videos).orEmpty()
    val subjects = remember(view) { store.subjects }

    viewerStart?.let { sid ->
        ShortsViewer(
            videos = shownVideos.filter { it.isShort },
            startId = sid,
            onNearEnd = { if (activeQuery != null && nextToken != null && !loading && error == null) runSearch(activeQuery!!, more = true) },
            onOpenChannel = { v -> if (v.channelId.isNotEmpty()) { viewerStart = null; channel = StudyChannel(v.channelId, v.channelTitle) } },
            onBack = { viewerStart = null },
        )
        return
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        if (searchOpen) {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { searchOpen = false; clearSearch() }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = c.text)
                }
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    placeholder = { Text("Search") },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { clearSearch() }) { Icon(Icons.Rounded.Close, "Clear search", tint = c.muted) }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { doSearch(query) }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = c.text,
                        unfocusedTextColor = c.text,
                        cursorColor = c.accent,
                        focusedBorderColor = c.accent,
                        unfocusedBorderColor = c.muted.copy(alpha = 0.5f),
                    ),
                    modifier = Modifier.weight(1f).focusRequester(searchFocus)
                )
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { view = StudyView.SUBSCRIPTIONS }) { Icon(Icons.Rounded.Menu, "Menu: Subscriptions", tint = c.text) }
                if (activeQuery != null) {
                    Column(Modifier.weight(1f).clickable { searchOpen = true }.padding(start = 4.dp)) {
                        // While the search runs, a small "Searching" sits above the keyword (no spinner).
                        if (searching) {
                            Text("Searching", style = MaterialTheme.typography.labelSmall, color = c.muted, maxLines = 1)
                        }
                        Text(
                            activeQuery.orEmpty(), style = MaterialTheme.typography.titleMedium, color = titleColor, maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(onClick = { clearSearch() }) { Icon(Icons.Rounded.Close, "Clear search", tint = c.muted) }
                } else {
                    Text(
                        "LockDistra", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = titleColor,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f).padding(start = 4.dp)
                    )
                }
                IconButton(onClick = { view = StudyView.NOTIFICATIONS }) {
                    BadgedBox(badge = { if (unread > 0) Badge() }) { Icon(Icons.Rounded.Notifications, "Notifications", tint = c.text) }
                }
                IconButton(onClick = { searchOpen = true }) { Icon(Icons.Rounded.Search, "Search", tint = c.text) }
                IconButton(onClick = { view = StudyView.SETTINGS }) { Icon(Icons.Rounded.Settings, "Study settings", tint = c.text) }
            }
        }

        if (searchOpen) {
            // YouTube's search page: the history when the box is empty, suggestions while typing.
            val typed = query.trim()
            val rows = if (typed.isEmpty()) recents else (listOf(typed) + suggestions).distinctBy { it.lowercase() }
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(rows, key = { it }) { s ->
                    Row(
                        Modifier.fillMaxWidth().clickable { doSearch(s) }.padding(start = 16.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Search, null, tint = c.muted, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.size(16.dp))
                        Text(s, style = MaterialTheme.typography.bodyLarge, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(vertical = 12.dp))
                        if (typed.isEmpty()) {
                            IconButton(onClick = { store.removeRecent(s); recents = store.recents }) {
                                Icon(Icons.Rounded.Close, "Remove from history", tint = c.muted)
                            }
                        }
                    }
                }
            }
        } else {
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Videos / Shorts show as selected only while no subject is chosen; choosing a subject un-selects them,
            // and tapping Videos / Shorts again leaves the subject and shows that feed.
            item { SoftChip("Videos", activeQuery == null && !shortsTab, { shortsTab = false; if (activeQuery != null) clearSearch() }) }
            item { SoftChip("Shorts", activeQuery == null && shortsTab, { shortsTab = true; if (activeQuery != null) clearSearch() }) }
            items(subjects) { s ->
                SoftChip(s, activeQuery.equals(s, ignoreCase = true), {
                    if (activeQuery.equals(s, ignoreCase = true)) clearSearch() else {
                        // In the Shorts tab a subject searches Shorts (it used to jump back to Videos).
                        query = s
                        searchOpen = false
                        runSearch(s)
                    }
                })
            }
            // Shorts only: knowledge topics (GK, current affairs, science facts...), slid through like the subjects.
            if (shortsTab) {
                items(StudyRules.KNOWLEDGE_QUERIES) { s ->
                    SoftChip(s, activeQuery.equals(s, ignoreCase = true), {
                        if (activeQuery.equals(s, ignoreCase = true)) clearSearch() else {
                            query = s
                            searchOpen = false
                            runSearch(s)
                        }
                    })
                }
            }
        }
        // Switching to another source: a thin line (its space is always reserved, so the list does not jump).
        Box(Modifier.fillMaxWidth().height(2.dp)) {
            androidx.compose.animation.AnimatedVisibility(visible = showSwitching, enter = androidx.compose.animation.fadeIn(tween(200)), exit = androidx.compose.animation.fadeOut(tween(300))) {
                androidx.compose.material3.LinearProgressIndicator(color = c.accent, trackColor = Color.Transparent, modifier = Modifier.fillMaxWidth())
            }
        }
        Spacer(Modifier.height(8.dp))

        if (blockedNotice) {
            BlockedNotice(onClose = { blockedNotice = false })
            Spacer(Modifier.height(10.dp))
        }

        if (webQuery != null) {
            StudyWebSearch(
                query = webQuery.orEmpty(),
                queryIsStudy = StudyWeb.isStudyQuery(webQuery.orEmpty(), store.subjects),
                repo = repo,
                onPlay = { play(it) },
                modifier = Modifier.weight(1f),
                retryTick = networkTick,
            )
        } else {
        val message: @Composable () -> Unit = {
            Box(Modifier.padding(horizontal = 12.dp)) {
                when {
                    error != null -> MessageCard(
                        StudyRules.errorTitle(error!!, activeQuery != null), error!!.message.orEmpty(), "Try again",
                        { if (activeQuery != null) runSearch(activeQuery!!, manual = true) else loadFeed(true, manual = true) }
                    )
                    !loading && shownVideos.isEmpty() -> MessageCard(
                        if (activeQuery != null) "No study videos found" else "Nothing here yet",
                        if (activeQuery != null) "Only learning videos are shown, so a search for entertainment finds nothing. Try a subject or a chapter name."
                        else "Pull fresh videos with the refresh button, or add trusted channels and subjects in Study settings."
                    )
                }
            }
        }

        // What the area under the chips shows: the skeleton while the feed loads for the first time, the spinner while a
        // search runs, otherwise the videos / message. The three fade into each other, so there is no blank screen or jump.
        val body = when {
            searching -> StudyBody.SEARCHING
            error == null && activeQuery == null && feedLoading && shownVideos.isEmpty() -> StudyBody.SKELETON
            else -> StudyBody.CONTENT
        }
        // Pull down to refresh, like YouTube (this replaces the old refresh button). Not while the first skeleton shows.
        PullToRefreshBox(
            isRefreshing = pulling && loading,
            onRefresh = {
                pulling = true
                if (activeQuery != null) runSearch(activeQuery!!, manual = true) else loadFeed(true, manual = true)
            },
            modifier = Modifier.weight(1f)
        ) {
        Crossfade(targetState = body, modifier = Modifier.fillMaxSize(), animationSpec = tween(240), label = "studyBody") { state ->
            when (state) {
                StudyBody.SKELETON -> if (shortsTab) ShortSkeletonGrid() else VideoSkeletonList()
                StudyBody.SEARCHING -> if (shortsTab) ShortSkeletonGrid() else VideoSkeletonList()
                StudyBody.CONTENT -> if (shortsTab && shownVideos.isNotEmpty() && error == null) {
                    NearEndEffect(gridState, listOf(nextToken, loading, results.size, shownVideos.size, feedHasMore)) {
                        if (activeQuery != null && nextToken != null && !loading && error == null) runSearch(activeQuery!!, more = true)
                        else if (activeQuery == null) loadMoreFeed()
                    }
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        state = gridState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        if (activeQuery != null && channelHits.isNotEmpty()) {
                            item(span = { GridItemSpan(2) }) {
                                Column {
                                    channelHits.forEach { h -> ChannelHitRow(h) { channel = StudyChannel(h.id, h.name) } }
                                }
                            }
                        }
                        gridItems(shownVideos, key = { it.id }) { v -> ShortCard(v) { openShort(v) } }
                        if (loadingMore || feedMoreLoading) {
                            item(span = { GridItemSpan(2) }) { Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = c.accent) } }
                        }
                    }
                } else {
                    NearEndEffect(listState, listOf(nextToken, loading, results.size, shownVideos.size, feedHasMore)) {
                        if (activeQuery != null && nextToken != null && !loading && error == null) runSearch(activeQuery!!, more = true)
                        else if (activeQuery == null) loadMoreFeed()
                    }
                    LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                        if (activeQuery != null && channelHits.isNotEmpty()) {
                            items(channelHits, key = { "ch_" + it.id }) { h -> ChannelHitRow(h) { channel = StudyChannel(h.id, h.name) } }
                        }
                        if (error == null) {
                            items(shownVideos, key = { it.id }) { v ->
                                VideoItem(
                                    v, avatars[v.channelId].orEmpty(),
                                    // A video that came without its channel (a web result) has no channel page to open.
                                    onChannel = if (v.channelId.isNotEmpty()) ({ channel = StudyChannel(v.channelId, v.channelTitle) }) else null,
                                ) { play(v) }
                            }
                        }
                        item { message() }
                        if (loadingMore || feedMoreLoading || (feedLoading && shownVideos.isNotEmpty())) {
                            item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = c.accent) } }
                        }
                    }
                }
            }
        }
        } // PullToRefreshBox
        } // web search / API list
        }
    }
}

/** One channel found by name in the search: picture, name, handle and subscribers; a tap opens the channel page. */
@Composable
private fun ChannelHitRow(h: com.focusmode.app.data.NativeChannel, onClick: () -> Unit) {
    val c = FocusTheme.colors
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ChannelAvatar(h.name, h.avatarUrl, size = 48.dp)
        Spacer(Modifier.size(12.dp))
        Column(Modifier.weight(1f)) {
            Text(h.name, style = MaterialTheme.typography.bodyLarge, color = c.text, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = listOf(h.handle, h.subsLabel).filter { it.isNotBlank() }.joinToString("  ·  ")
            if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** The menu: every channel the person subscribed to, how each one notifies, and when the phone last looked for new videos. */
@Composable
private fun SubscriptionsScreen(store: StudyStore, avatars: Map<String, String>, onBack: () -> Unit, onOpen: (StudyChannel) -> Unit) {
    val c = FocusTheme.colors
    val context = androidx.compose.ui.platform.LocalContext.current
    var channels by remember { mutableStateOf(store.channels) }
    var modes by remember { mutableStateOf(channels.associate { it.id to store.alertMode(it.id) }) }
    var lastAt by remember { mutableStateOf(store.lastCheckAt) }
    var lastNote by remember { mutableStateOf(store.lastCheckNote) }
    var asked by remember { mutableStateOf(false) }
    // While a "Check now" runs the result is read again every few seconds.
    LaunchedEffect(asked) {
        if (!asked) return@LaunchedEffect
        val before = lastAt
        repeat(20) {
            kotlinx.coroutines.delay(2000)
            if (store.lastCheckAt != before) { lastAt = store.lastCheckAt; lastNote = store.lastCheckNote; asked = false; return@LaunchedEffect }
        }
        asked = false
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = c.text) }
            Text("Subscriptions", style = MaterialTheme.typography.titleLarge, color = c.text, modifier = Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (lastAt <= 0L) "New videos: not checked yet"
                else "Last checked " + StudyRules.timeAgo(lastAt) + if (lastNote.isNotEmpty()) "  ·  $lastNote" else "",
                style = MaterialTheme.typography.bodySmall, color = c.muted, modifier = Modifier.weight(1f)
            )
            TextButton(enabled = !asked && channels.isNotEmpty(), onClick = {
                asked = true
                com.focusmode.app.service.StudyUpdatesWorker.checkNow(context)
            }) { Text(if (asked) "Checking..." else "Check now", color = c.accent) }
        }
        if (channels.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "You have not subscribed to any channel yet. Open a video and tap Subscribe, and the channel will be listed here.",
                    style = MaterialTheme.typography.bodyMedium, color = c.muted, textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(channels, key = { it.id }) { ch ->
                    val mode = modes[ch.id] ?: ChannelAlerts.ALL
                    Row(
                        Modifier.fillMaxWidth().clickable { onOpen(ch) }.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ChannelAvatar(ch.name, avatars[ch.id].orEmpty(), size = 40.dp)
                        Spacer(Modifier.size(12.dp))
                        Text(
                            ch.name.ifEmpty { ch.id }, style = MaterialTheme.typography.bodyLarge, color = c.text,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        // Tap to change what this channel notifies about: All, Personalized (your subjects) or None.
                        TextButton(onClick = {
                            val next = when (mode) { ChannelAlerts.ALL -> ChannelAlerts.PERSONALIZED; ChannelAlerts.PERSONALIZED -> ChannelAlerts.NONE; ChannelAlerts.NONE -> ChannelAlerts.ALL }
                            store.setAlertMode(ch.id, next)
                            modes = modes + (ch.id to next)
                        }) {
                            Icon(
                                if (mode == ChannelAlerts.NONE) Icons.Rounded.NotificationsOff else Icons.Rounded.Notifications, null,
                                tint = if (mode == ChannelAlerts.NONE) c.muted else c.accent, modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.size(4.dp))
                            Text(
                                when (mode) { ChannelAlerts.ALL -> "All"; ChannelAlerts.PERSONALIZED -> "Personalized"; ChannelAlerts.NONE -> "None" },
                                color = if (mode == ChannelAlerts.NONE) c.muted else c.accent
                            )
                        }
                    }
                }
            }
        }
    }
}

/** The bell: new videos of followed channels, newest first. Tap one to play it. */
@Composable
private fun NotificationsScreen(store: StudyStore, avatars: Map<String, String>, onBack: () -> Unit, onPlay: (StudyVideo) -> Unit) {
    val c = FocusTheme.colors
    var items by remember { mutableStateOf(store.inbox()) }
    LaunchedEffect(Unit) { store.markInboxRead() }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = c.text) }
            Text("Notifications", style = MaterialTheme.typography.titleLarge, color = c.text, modifier = Modifier.weight(1f))
            if (items.isNotEmpty()) {
                TextButton(onClick = { store.clearInbox(); items = emptyList() }) { Text("Clear", color = c.accent) }
            }
        }
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    "No new videos yet. Subscribe to a channel on a video's page and its new videos will show up here.",
                    style = MaterialTheme.typography.bodyMedium, color = c.muted, textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(items, key = { it.id }) { v ->
                    Row(Modifier.fillMaxWidth().clickable { onPlay(v) }.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
                        ChannelAvatar(v.channelTitle, avatars[v.channelId].orEmpty(), size = 32.dp)
                        Spacer(Modifier.size(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(v.title, style = MaterialTheme.typography.bodyMedium, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(2.dp))
                            Text(
                                listOf(v.channelTitle, StudyRules.timeAgo(v.publishedAt)).filter { it.isNotEmpty() }.joinToString("  ·  "),
                                style = MaterialTheme.typography.bodySmall, color = c.muted, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(Modifier.size(10.dp))
                        Box {
                            Thumb(v.thumbUrl, Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp)))
                            LengthBadge(v.seconds, Modifier.align(Alignment.BottomEnd).padding(4.dp))
                        }
                    }
                }
            }
        }
    }
}

/** A channel's page, like YouTube's: logo, name, handle, subscribers, Subscribe, and its Videos and Shorts. */
@Composable
private fun ChannelScreen(
    ch: StudyChannel,
    avatarUrl: String,
    avatars: Map<String, String>,
    store: StudyStore,
    repo: StudyRepository,
    swipeShorts: Boolean,
    onBack: () -> Unit,
    onPlay: (StudyVideo) -> Unit,
) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    var viewerStart by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<StudyChannelInfo?>(null) }
    var videos by remember { mutableStateOf<List<StudyVideo>>(emptyList()) }
    var next by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var errorTitle by remember { mutableStateOf("Could not load videos") }
    var shortsTab by remember { mutableStateOf(false) }
    var autoTries by remember { mutableStateOf(0) }
    var aboutOpen by remember { mutableStateOf(false) }

    fun load(first: Boolean, manual: Boolean = false) {
        // Next page only when none is running and there is one left (scrolling can ask several times in a row).
        if (!first && (loading || next == null)) return
        loading = true
        scope.launch {
            error = null
            try {
                if (first) {
                    // The channel's details and its first videos are asked at the same time, not one after the other.
                    val infoJob = async(Dispatchers.IO) { runCatching { repo.channelInfo(ch.id) }.getOrNull() }
                    val firstPage = runCatching { withContext(Dispatchers.IO) { repo.channelPage(ch.id, null, manual) } }
                    info = infoJob.await() ?: info
                    val page = firstPage.getOrThrow()
                    videos = (videos + page.videos).distinctBy { it.id }
                    next = page.next
                } else {
                    val page = withContext(Dispatchers.IO) { repo.channelPage(ch.id, next, manual) }
                    videos = (videos + page.videos).distinctBy { it.id }
                    next = page.next
                }
            } catch (e: Exception) {
                error = (e as? StudyException)?.message ?: "Could not load this channel."
                errorTitle = (e as? StudyException)?.let { StudyRules.errorTitle(it, false) } ?: "Could not load this channel"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(ch.id) { load(true) }

    val shown = videos.filter { it.isShort == shortsTab }
    // A tab with nothing yet (a channel with few Shorts): look at a few more pages by itself.
    LaunchedEffect(shortsTab, videos.size, next, loading) {
        if (!loading && error == null && shown.isEmpty() && next != null && autoTries < 4) {
            autoTries++
            load(false)
        }
    }
    LaunchedEffect(shortsTab) { autoTries = 0 }

    viewerStart?.let { sid ->
        ShortsViewer(
            videos = shown.filter { it.isShort },
            startId = sid,
            onNearEnd = { if (next != null && !loading && error == null) load(false) },
            onOpenChannel = { viewerStart = null },
            onBack = { viewerStart = null },
        )
        return
    }

    val name = info?.name ?: ch.name
    val shownName = name.ifBlank { "Channel" }
    val about = info?.description.orEmpty()
    val pic = info?.avatarUrl?.takeIf { it.isNotEmpty() } ?: avatarUrl
    val stats = listOfNotNull(
        info?.handle?.takeIf { it.isNotEmpty() },
        info?.subscribers?.let { StudyRules.formatCount(it) + " subscribers" },
        info?.videoCount?.let { StudyRules.formatCount(it) + " videos" },
    )

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = c.text) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            ChannelAvatar(shownName, pic, size = 72.dp)
            Spacer(Modifier.size(16.dp))
            Column(Modifier.weight(1f)) {
                Text(shownName, style = MaterialTheme.typography.titleLarge, color = c.text, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (stats.isNotEmpty()) {
                    Spacer(Modifier.height(2.dp))
                    Text(stats.joinToString("  ·  "), style = MaterialTheme.typography.bodySmall, color = c.muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                } else if (loading && info == null) {
                    Spacer(Modifier.height(8.dp))
                    SkeletonLine(0.7f)
                }
            }
        }
        if (about.isNotEmpty()) {
            // The channel's own description: two lines, a tap opens all of it (and closes it again).
            Text(
                about, style = MaterialTheme.typography.bodySmall, color = c.muted,
                maxLines = if (aboutOpen) 12 else 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().clickable { aboutOpen = !aboutOpen }.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            ChannelSubscribeControl(store, ch.id, name, Modifier.fillMaxWidth(), wide = true)
        }
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SoftChip("Videos", !shortsTab, { shortsTab = false })
            SoftChip("Shorts", shortsTab, { shortsTab = true })
        }
        Spacer(Modifier.height(10.dp))

        val footer: @Composable () -> Unit = {
            Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), contentAlignment = Alignment.Center) {
                when {
                    loading && shown.isNotEmpty() -> CircularProgressIndicator(color = c.accent)
                    loading -> Unit // nothing loaded yet: the skeleton above shows
                    error != null -> MessageCard(errorTitle, error.orEmpty(), "Try again", { load(videos.isEmpty(), manual = true) })
                    shown.isEmpty() && next == null -> Text(
                        if (shortsTab) "No Shorts from this channel." else "No videos from this channel.",
                        style = MaterialTheme.typography.bodyMedium, color = c.muted
                    )
                }
            }
        }

        // First load of the channel's videos: skeleton cards (like YouTube), then they fade into the real list.
        val skeleton = loading && shown.isEmpty()
        Crossfade(targetState = skeleton, modifier = Modifier.weight(1f), animationSpec = tween(240), label = "channelBody") { showSkeleton ->
            if (showSkeleton) {
                if (shortsTab) ShortSkeletonGrid() else VideoSkeletonList()
            } else if (shortsTab) {
                val gridState = rememberLazyGridState()
                NearEndEffect(gridState, listOf(next, loading, videos.size)) {
                    if (next != null && !loading && error == null) load(false)
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    gridItems(shown, key = { it.id }) { v -> ShortCard(v) { if (swipeShorts) viewerStart = v.id else onPlay(v) } }
                    item(span = { GridItemSpan(2) }) { footer() }
                }
            } else {
                val listState = rememberLazyListState()
                NearEndEffect(listState, listOf(next, loading, videos.size)) {
                    if (next != null && !loading && error == null) load(false)
                }
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                    items(shown, key = { it.id }) { v -> VideoItem(v, avatars[v.channelId].orEmpty().ifEmpty { pic }, onChannel = null) { onPlay(v) } }
                    item { footer() }
                }
            }
        }
    }
}

/** Followed subjects and trusted channels (no API key and no notification switch: both are built in). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StudySettings(store: StudyStore, repo: StudyRepository, onBack: () -> Unit) {
    val c = FocusTheme.colors
    val scope = rememberCoroutineScope()
    var subjects by remember { mutableStateOf(store.subjects) }
    var selected by remember { mutableStateOf(store.selected) }
    var newSubject by remember { mutableStateOf("") }
    var channels by remember { mutableStateOf(store.channels) }
    var channelText by remember { mutableStateOf("") }
    var channelBusy by remember { mutableStateOf(false) }
    var channelError by remember { mutableStateOf<String?>(null) }
    var removeCandidate by remember { mutableStateOf<StudyChannel?>(null) }

    removeCandidate?.let { ch ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { removeCandidate = null },
            containerColor = c.card, titleContentColor = c.text, textContentColor = c.muted,
            title = { Text("Unsubscribe from ${ch.name.ifEmpty { "this channel" }}?", style = MaterialTheme.typography.titleLarge) },
            text = { Text("You will stop getting its new-video notifications and it will leave your trusted channels.") },
            confirmButton = {
                TextButton(onClick = {
                    store.unfollow(ch.id)
                    channels = store.channels
                    removeCandidate = null
                }) { Text("Unsubscribe", color = c.warning) }
            },
            dismissButton = { TextButton(onClick = { removeCandidate = null }) { Text("Cancel", color = c.accent) } }
        )
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = c.text, unfocusedTextColor = c.text, cursorColor = c.accent,
        focusedBorderColor = c.accent, unfocusedBorderColor = c.muted.copy(alpha = 0.5f),
    )

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleIconButton(Icons.AutoMirrored.Rounded.ArrowBack, "Back", onBack)
            Spacer(Modifier.size(14.dp))
            Text("Study settings", style = MaterialTheme.typography.titleLarge)
        }
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Column {
                SectionLabel("Subjects I follow")
                FocusCard {
                    Column {
                        Text(
                            "Your suggestions come from these. If none is switched on, all of them are used.",
                            style = MaterialTheme.typography.bodySmall, color = c.muted
                        )
                        Spacer(Modifier.height(10.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            subjects.forEach { s ->
                                SoftChip(s, s in selected, {
                                    selected = if (s in selected) selected - s else selected + s
                                    store.selected = selected
                                })
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = newSubject,
                            onValueChange = { newSubject = it },
                            singleLine = true,
                            placeholder = { Text("Add a subject, e.g. Sanskrit") },
                            trailingIcon = {
                                TextButton(onClick = {
                                    val t = newSubject.trim()
                                    if (t.isNotEmpty() && subjects.none { it.equals(t, true) }) {
                                        subjects = subjects + t
                                        store.subjects = subjects
                                    }
                                    newSubject = ""
                                }) { Text("Add", color = c.accent) }
                            },
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                }
            }
            item {
                Column {
                SectionLabel("Trusted channels")
                FocusCard {
                    Column {
                        Text(
                            "Videos from these channels are always allowed, their newest uploads appear in your suggestions, and a new upload sends you a notification. Use Subscribe on the video player to add a channel here.",
                            style = MaterialTheme.typography.bodySmall, color = c.muted
                        )
                        Spacer(Modifier.height(10.dp))
                        channels.forEach { ch ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(ch.name, style = MaterialTheme.typography.bodyMedium, color = c.text, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                IconButton(onClick = { removeCandidate = ch }) { Icon(Icons.Rounded.Close, "Remove ${ch.name}", tint = c.muted) }
                            }
                        }
                        OutlinedTextField(
                            value = channelText,
                            onValueChange = { channelText = it; channelError = null },
                            singleLine = true,
                            isError = channelError != null,
                            placeholder = { Text("@channelname or channel link") },
                            trailingIcon = {
                                TextButton(enabled = !channelBusy && channelText.isNotBlank(), onClick = {
                                    scope.launch {
                                        channelBusy = true
                                        try {
                                            withContext(Dispatchers.IO) { repo.addChannel(channelText) }
                                            channels = store.channels
                                            channelText = ""
                                        } catch (e: StudyException) {
                                            channelError = e.message
                                        } catch (e: Exception) {
                                            channelError = "Could not add this channel."
                                        } finally {
                                            channelBusy = false
                                        }
                                    }
                                }) { Text(if (channelBusy) "..." else "Add", color = c.accent) }
                            },
                            colors = fieldColors,
                            modifier = Modifier.fillMaxWidth()
                        )
                        channelError?.let {
                            Spacer(Modifier.height(6.dp))
                            Text(it, style = MaterialTheme.typography.bodySmall, color = c.warning)
                        }
                    }
                }
                }
            }
        }
    }
}
