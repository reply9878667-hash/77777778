# Keep service / receiver entry points referenced from the manifest.
-keep class com.focusmode.app.service.** { *; }
