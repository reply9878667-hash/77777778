import java.util.Properties
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.focusmode.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.focusmode.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 36
        versionName = "1.0.3"

        // ./gradlew assembleDebug -PplayBuild=true  -> variant for the Play Store (no uninstall protection).
        // Default (no flag) -> the full app with every feature.
        val playBuild = (project.findProperty("playBuild") ?: "false").toString()
        buildConfigField("boolean", "PLAY_STORE_BUILD", playBuild)

        // Online Approval (Firebase). None of these values live in the source code. They are read from
        // firebase.properties (git-ignored, next to settings.gradle.kts) or from FOCUSMODE_FB_*
        // environment variables (for example GitHub Actions secrets). With nothing set the build still
        // works and the feature simply says "not set up". See ONLINE_APPROVAL.md.
        val fbProps = Properties().apply {
            val f = rootProject.file("firebase.properties")
            if (f.exists()) f.inputStream().use { load(it) }
        }
        fun fb(prop: String, env: String): String =
            ((fbProps.getProperty(prop) ?: System.getenv(env)) ?: "").trim()
        fun quoted(v: String): String = "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\""
        buildConfigField("String", "FB_API_KEY", quoted(fb("apiKey", "FOCUSMODE_FB_API_KEY")))
        buildConfigField("String", "FB_APP_ID", quoted(fb("appId", "FOCUSMODE_FB_APP_ID")))
        buildConfigField("String", "FB_DATABASE_URL", quoted(fb("databaseUrl", "FOCUSMODE_FB_DATABASE_URL")))
        buildConfigField("String", "FB_PROJECT_ID", quoted(fb("projectId", "FOCUSMODE_FB_PROJECT_ID")))
        buildConfigField("String", "FB_SENDER_ID", quoted(fb("senderId", "FOCUSMODE_FB_SENDER_ID")))
        buildConfigField("String", "APPROVAL_WORKER_URL", quoted(fb("workerUrl", "FOCUSMODE_APPROVAL_WORKER_URL")))
        // Optional adult-list updates: HTTPS address of manifest.json produced by tools/build_adult_blocklist.py
        // (for example a raw.githubusercontent.com link). Empty = the app only uses its bundled list.
        buildConfigField("String", "ADULT_LIST_MANIFEST_URL", quoted(fb("adultListUrl", "FOCUSMODE_ADULT_LIST_URL")))

        // Study section: YouTube Data API v3 key (free, from Google Cloud). Optional: it can also be pasted inside the
        // app (Study > Settings). Read from firebase.properties ("youtubeApiKey") or FOCUSMODE_YT_API_KEY.
        buildConfigField("String", "YOUTUBE_API_KEY", quoted(fb("youtubeApiKey", "FOCUSMODE_YT_API_KEY")))

        // Accounts (see AUTH_TASK1.md). The OAuth *web* client id for "Continue with Google". Not a secret.
        // Blank = Google sign-in says "isn't set up in this build"; email sign-up and login still work.
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", quoted(fb("googleWebClientId", "FOCUSMODE_GOOGLE_WEB_CLIENT_ID").ifEmpty { "406553564367-6nlrf8sustanut06np60fu8d7hfmb8ai.apps.googleusercontent.com" }))

        // Push needs an ANDROID app id and the Worker URL. Say so at build time instead of failing silently.
        val fbAppId = fb("appId", "FOCUSMODE_FB_APP_ID")
        if (fbAppId.isNotEmpty() && !fbAppId.contains(":android:") && fb("workerUrl", "FOCUSMODE_APPROVAL_WORKER_URL").isNotEmpty()) {
            logger.warn("LockDistra: appId in firebase.properties is not an Android app id (needs 1:...:android:...). Push notifications will NOT work.")
        }
        if (fbAppId.isNotEmpty() && fb("workerUrl", "FOCUSMODE_APPROVAL_WORKER_URL").isEmpty()) {
            logger.warn("LockDistra: workerUrl is empty. No FCM push; the trusted phone uses its background listener instead (needs the app opened once after install).")
        }
    }

    // One fixed key for every release build, so a new APK installs as an update over the old one
    // (a fresh random key each build makes Android say "App not installed").
    // The key's passwords are NOT in this file. They come from keystore.properties (git-ignored,
    // next to settings.gradle.kts) or from the FOCUSMODE_* environment variables. A release build
    // is never signed with the public debug key: with no key available it stays unsigned and says so.
    val keystoreFile = rootProject.file("signing/focusmode-release.jks")
    val keyProps = Properties().apply {
        val f = rootProject.file("keystore.properties")
        if (f.exists()) f.inputStream().use { load(it) }
    }
    fun keyValue(prop: String, env: String): String? =
        (keyProps.getProperty(prop) ?: System.getenv(env))?.takeIf { it.isNotBlank() }
    val storePass = keyValue("storePassword", "FOCUSMODE_STORE_PASSWORD")
    val keyAliasName = keyValue("keyAlias", "FOCUSMODE_KEY_ALIAS")
    val keyPass = keyValue("keyPassword", "FOCUSMODE_KEY_PASSWORD") ?: storePass
    val canSignRelease = keystoreFile.exists() && storePass != null && keyAliasName != null && keyPass != null
    if (canSignRelease) {
        signingConfigs {
            create("fixed") {
                storeFile = keystoreFile
                storePassword = storePass
                keyAlias = keyAliasName
                keyPassword = keyPass
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
            }
        }
    } else {
        logger.warn("LockDistra: no release key found (signing/focusmode-release.jks + keystore.properties). The release APK will be UNSIGNED and cannot be installed.")
    }

    // One fixed DEBUG key (public, passwords "android"), so the debug build has the same SHA-1 on every machine and every
    // build. Without it each build machine makes its own random debug key, the SHA-1 changes, and "Continue with Google"
    // stops working ("Account reauth failed") until the new SHA-1 is added in Firebase again.
    val debugKeystore = rootProject.file("signing/rewire-debug.jks")
    if (debugKeystore.exists()) {
        signingConfigs {
            getByName("debug") {
                storeFile = debugKeystore
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            if (canSignRelease) signingConfig = signingConfigs.getByName("fixed")
            isDebuggable = false
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        // A lint warning must never stop the APK from being built.
        abortOnError = false
        checkReleaseBuilds = false
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.6")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Study: checks followed channels for new videos in the background (new-video notifications).
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Online Approval unlock. Set up by hand (no google-services plugin): see data/online/FirebaseGateway.
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-database")
    implementation("com.google.firebase:firebase-messaging")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // Accounts: "Continue with Google" through Android's Credential Manager (the successor of the old
    // Google Sign-In SDK). The Google ID token is exchanged for a Firebase login by firebase-auth above.
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Plain-JVM tests for the Focus controls / Emergency access rules (./gradlew test).
    testImplementation("junit:junit:4.13.2")
    // Real org.json for the plain-JVM backup tests (the Android one is only a stub there).
    testImplementation("org.json:json:20240303")
}
