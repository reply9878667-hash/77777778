# Study: Subscriptions menu + new-video notification fixes

## Menu (three lines, top left of Study)
* Lists every subscribed channel (logo, name). Tap a channel = its page. Each row has a notification choice (All / Personalized / None), tap to change.
* Top line: when the phone last looked for new videos and what it found ("No new videos", "2 new videos", "YouTube's daily limit is used up"...). "Check now" runs one check at once.

## Why no notification came (found in the code)
1. The first look at a channel was fully silent and only ran when the background job ran. Anything uploaded between the Subscribe tap and that first run was swallowed for good. Now the first look announces videos uploaded after the Subscribe tap (channels subscribed by an older version: the last 24 hours).
2. The background job is a normal WorkManager job. Android may hold it back for hours (battery saver, app standby, Xiaomi / Realme / Vivo / Oppo autostart limits). Now: every 3 hours, one check when the app opens after an hour without one, and "Check now".
3. Failures were swallowed without a trace (daily YouTube limit, key refused, no internet). Now the result is kept and shown in the menu.
4. Only the first 8 subscribed channels were ever looked at; now 12.
Not compiled here. Tests added: FirstLookTest.
