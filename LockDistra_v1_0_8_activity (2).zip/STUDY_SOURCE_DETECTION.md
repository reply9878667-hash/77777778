# Study Section – Part 2/4: Intelligent Source Detection

Scope: detection and status management only. No automatic fallback or source switching was added or changed; the existing
switching (StudyRepository / StudyMonitor, title colour) runs exactly as before. Nothing new is shown on screen.

**NOT compiled and NOT run here** (the build sandbox has no Gradle / Kotlin / Android SDK, and no network). Run
`./gradlew testDebugUnitTest` and a debug build before release. The checks below were desk-checked, not executed.

## The three sources (one status each, `StudyMode` is the key)
| Source | In code | Detected from |
|---|---|---|
| YouTube Data API | `StudyMode.API` | every real API answer (`StudyApi.get`), persisted key rests, key present, network |
| Direct YouTube | `StudyMode.PAGE` | YouTube app installed / enabled (PackageManager), INTERNET + network-state permissions, every real page-data search (`StudyRepository.nativeSearch`) |
| Web | `StudyMode.WEB` | Web enabled flag, WebView provider, WebView start-up, network, real WebView page results / errors |

Statuses: Available, Unavailable, Temporarily Failed, Disabled, Authentication Error, Quota Exhausted, Network Error, plus
**Unknown** (not verified yet; never a failure). Each has a reason (`SourceReason`): daily limit, rate limit, invalid key, key
refused, no key, timeout, server error (500/502/504), service unavailable (503), unreadable answer, unreachable, no internet,
switched off, app not installed / disabled, permission missing, page unreadable, blocked by YouTube (403/429), WebView
missing / init failed / renderer stopped.

## False-detection rules (where they live)
- A status changes only on evidence: a real result of that source, a key rest saved after a real answer, or a local fact read
  for sure. Facts that cannot be read are `null` and never count against a source (`SourceClassifier.*Local`).
- One API key failing while the next key answers is not an API failure (`StudyApi.get` records only when no key answered).
- Per-minute API limit = Temporarily Failed (60 s), only the daily limit = Quota Exhausted. `StudyApi.restingError` used to call
  every rest "used up today"; a short rest is now the per-minute message.
- Timeouts, 5xx, 403/429 from YouTube pages, unreadable pages: always Temporarily Failed / Network Error, with a growing cool-down
  (30 s, 1, 2, 4, 8, max 10 min). They never become Unavailable or Disabled.
- No internet = Network Error on that source, never Disabled, and it never hides a verified quota / key problem.
- A success does not erase a switch-off or a missing / disabled YouTube app.
- Manifest: `<package android:name="com.google.android.youtube"/>` added to `<queries>`; without it a DISABLED YouTube app is
  invisible to the launcher query and would wrongly look "not installed".

## Lightweight monitoring
No timer, no service, no network callback. `StudyScreen` runs one quiet check ~1.5 s after the Study section opens:
`refreshLocal()` (phone facts only, skipped if it ran in the last 15 s, shared by all instances) and `verifyDue()` (a network
request only for a source that FAILED, whose cool-down is over, not in the last 10 s, and not blocked by a local fact). Working,
switched-off and never-used sources are never asked. Re-checks: API = 1-unit `i18nLanguages` call; Direct = one page-data
search; Web = one HEAD request (4 s timeout).

## Decisions to confirm
1. Direct YouTube = the existing page-data reading, which needs only internet. You asked for it to depend on the YouTube **app**
   being installed and enabled, so that is what decides (`SourceClassifier.DIRECT_REQUIRES_APP = true`). Set it to `false` if a
   phone without the YouTube app should still show Direct YouTube as available.
2. There is no screen to switch a source off yet; `StudyStore.setSourceEnabled(mode, false)` is the only way, so Disabled today comes
   from that flag or a disabled YouTube app.
3. A generic 403 on a request for one private playlist still counts as "key refused" (pre-existing rule in `parseError`, unchanged).

## Modified files
data: StudySources (new), StudySourceChecker (new), StudyRules (`StudyException.reason`, causes in `parseError`), StudyApi, StudyNative
(`HttpStatusException`), StudyRepository, StudyStore · ui: StudyScreen, StudyWebSearch · AndroidManifest.xml · tests: StudySourcesTest (new).

## Test matrix (StudySourcesTest, 38 JVM tests; desk-checked, not executed)
API failure: daily limit, per-minute limit, invalid key, refused key, 503 vs 500, timeout vs network, missing item, no key, resting keys.
YouTube disabled / not installed / permission / unknown facts / API quota does not touch it. Web disabled, no WebView, network failure
(not Disabled), request errors. Network failure on all sources and recovery. Cool-down growth and cap, never permanent, due rules.
Successful recovery (web after network error, API after reset, WebView init).

## Not verified
Compile and test run; real Android behaviour of PackageManager / ConnectivityManager / `WebView.getCurrentWebViewPackage()` on
devices; WebView error callbacks on a real network loss; the live YouTube pages and API.
