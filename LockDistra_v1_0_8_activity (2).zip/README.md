# LockDistra

*Powered by Re Arena*

A single-purpose Android app (Kotlin, Jetpack Compose) that blocks distracting apps for a set time,
with a plant that grows as you stay focused.

## Build and run

1. Open this folder in Android Studio (Koala or newer). It uses Gradle 8.9, AGP 8.7.2, Kotlin 2.0.20.
2. Let Gradle sync, then run on a phone or emulator (Android 8.0 / API 26 or newer).
   Command line: run `gradle wrapper` once, then `./gradlew assembleDebug`.

> This project was written without access to an Android SDK, so it has not been compiled or run
> yet. Expect to fix a small compile error or two on first sync.

## First run

Tap the big ring. LockDistra asks for permissions and explains each one:

| Permission | Why | Required |
|---|---|---|
| Accessibility service | Sees which app is in front so it can cover blocked apps. In YouTube it also detects the Shorts player. | Yes |
| Notifications | Permanent status notification and the plant chime. | Recommended |
| Usage access | Fallback way to find the foreground app. | Recommended |
| Battery optimization (Settings screen) | Asked after an explanation. Stops the phone from putting blocking and limits to sleep. | Recommended |
| Device admin (Settings screen) | Blocks normal uninstalling while on. | Optional |
| Fingerprint (Settings > App lock, optional) | Lets the app lock open with a fingerprint. Uses Android's own prompt; LockDistra never sees the fingerprint. | Optional |
| Advanced protection (Settings screen, separate toggle) | Needs the accessibility service and device admin above. Also guards the uninstall / App info / device admin screens between sessions. | Optional |

The app only uses the internet for the optional **Online approval** unlock (see `ONLINE_APPROVAL.md`).
Nothing is sent unless you connect a trusted phone; blocking, limits and the PIN lock never use the network.

## How it works

- `data/FocusStore` keeps all state in SharedPreferences (selected apps, session, emergency window,
  plant growth, theme, name). Every change saves immediately.
- `service/FocusService` is a foreground service (type `specialUse`) with a permanent notification
  showing a live countdown. It drives the timer end, emergency end and plant reminders each second.
  `FocusAlarmReceiver` is a doze-safe backup via `AlarmManager.setAndAllowWhileIdle`.
- `service/AppBlockerService` is the accessibility service. When a blocked app comes to the front it
  opens `BlockActivity` over it. A 1.2 s poll also catches the moment emergency access ends.
- `service/BootReceiver` restarts an unfinished session after reboot or app update (see "Stability and security (v1.5)"). Android restores
  an enabled accessibility service by itself.
- Plant: has its own page and grows only after a check-in (see "Plant page and check-ins (v1.6)").
- Emergency access: opens ONE chosen app for 2, 3 or 4 minutes from the dashboard, the block screen or the
  notification (see "Emergency apps and Focus controls" below).

## Look and feel (v1.1)

- **Splash** (`ui/screens/SplashScreen.kt`): logo springs in over a moving glow, a ring draws around it, the name fades up,
  a progress bar fills and "Powered by Re Arena" sits centred at the bottom. Plays once per launch (about 2.3 s).
  Android 12+ shows the system splash first in the same colour, older versions use the dark `Theme.FocusMode.Launch`
  window background, so there is no light flash.
- **Blocked screen** (`BlockActivity`): drifting aurora background with rising particles, pulsing rings around a progress ring,
  the plant (or a shield / hourglass icon), the blocked app's icon with a lock, a status chip, staggered entry, and a
  countdown card (session remaining, time since start when there is no limit, or time until midnight for a daily limit).
- **Shared components** (`ui/components/Effects.kt`): `FocusSwitch` (spring thumb), `staggeredEntrance`, `FocusProgressBar`,
  `AppListSkeleton` (shimmer loading rows) and `AuroraBackground`. Buttons, chips and cards have press feedback.
- **App icons** sit on a tile tinted per app, with a coloured letter placeholder that cross-fades to the real icon.
  Blocked apps get a highlighted card and a "Blocked / Allowed" status line.

## Things to know

- YouTube Shorts detection looks for known view ids and the selected Shorts tab. YouTube changes
  these, so treat Shorts-only blocking as best effort. Blocking the whole YouTube app is reliable.
  Educational channels and in-app sections are described under "Educational Shorts and Inside apps (v1.3)".
- Advanced protection (`FocusState.advancedProtection`): `AppBlockerService` shows a "Protected" `BlockActivity`
  (`REASON_PROTECTION`) when the installer's uninstall dialog, or a Settings / Play Store screen showing
  "LockDistra" plus an uninstall, force-stop or device-admin action, is opened. It works outside sessions too,
  needs device admin, switches itself off if the admin is removed, asks for confirmation to turn off and is
  locked during a session. Screen matching uses English UI texts (`dangerousActions`), so on other languages
  only the installer dialog and in-session guarding are guaranteed. Turning accessibility off in system
  Settings still stops the guard (the device admin keeps normal uninstalling blocked).
- Usage limits (`data/UsageLimitStore`, `ui/screens/LimitsScreen`): per-app daily limit (hours + minutes) and a
  reminder N minutes before it ends. `AppBlockerService` counts time only while a limited app is in front and
  the screen is on (one coroutine, started on window change, cancelled when the user leaves). Usage is saved
  every 5 s and resets at midnight. At the limit `BlockActivity` (`REASON_LIMIT`) covers the app until tomorrow
  or until the limit is changed. A small floating pill (accessibility overlay, no extra permission) shows the
  remaining time; it can be turned off on the Usage limits screen.
- Settings blocking: Android Settings appears in Blocked apps (own section) and is covered by
  `BlockActivity` (`REASON_SETTINGS`) during a session. Emergency / panel screens inside Settings stay open,
  the block screen offers "Open LockDistra" so the session can be ended, and Emergency access still pauses
  all blocking. Settings can't be given a daily limit.
- Restarts: state lives in device-protected storage (`data/Storage`), `BootReceiver` is direct-boot aware and
  handles LOCKED_BOOT_COMPLETED, BOOT_COMPLETED and QUICKBOOT. `FocusController.restoreAfterBoot` restarts the
  session/service/alarms and posts a notification; "Restore session after restart" (Settings) is user-controlled
  and locked during a session. If Accessibility was switched off by the restart, a notification says so.
  Usage is saved every 5 s, on screen-off and on shutdown, and is reconciled with Android's usage stats when
  Usage Access is granted. Counting stops while the screen is off.
- Uninstall protection stops normal uninstalling and cannot be switched off during a session. Outside
  a session the user can switch it off, by design.
- Some manufacturers (Xiaomi, Oppo, Vivo, Samsung and others) kill background apps aggressively. If
  blocking stops, exclude LockDistra from battery optimisation for that phone.
- Publishing on Google Play needs an accessibility declaration and a foreground-service
  (`specialUse`) justification in Play Console.

## Emergency apps and Focus controls (v1.2)

### Emergency apps (`data/EmergencyStore`, `ui/screens/EmergencyScreen`)
- Home > Blocking > **Emergency apps**: a switch for every installed app (all start OFF) and, once on, a number of
  allowed uses (1 to 10, default 3). The row shows "2 of 3 attempts left".
- Emergency access no longer pauses everything. It opens only the chosen app (`FocusState.emergencyPkg`); every
  other blocked app stays blocked (`FocusState.emergencyCovers`, used by `AppBlockerService`).
- One attempt is used when the window opens (`EmergencyStore.consume`, atomic) and is not refunded if the window
  is closed early. At 0 attempts the block screen and the picker say so and the app cannot be opened that way.
- Attempts come back: every focus session (default), every day, or only by a manual reset between sessions.
- While a session runs these settings can only be tightened (switch an app off, lower a limit). No new apps, no
  higher limits, no reset, and no change at all if "app restriction changes" or "settings" are locked.

### Focus controls (`FocusControlsCard`, `FocusStore.setControl`, rules in `data/Policy.kt`)
Shown directly under the LockDistra ring while a session runs. Every switch means "this is allowed":

| Switch | When OFF |
|---|---|
| Allow turning LockDistra OFF | The ring, and any other stop path, is refused until the timer ends. A restart cannot end the session either (it is restored even if "Restore after restart" is off). |
| Allow changing LockDistra settings | Reminder timing, the protection switches, restore-after-restart, the floating timer and the Focus controls themselves are frozen. |
| Allow Emergency access | The dashboard card, the block-screen button and the notification shortcut are all off. |
| Allow app restriction changes | Blocked apps, YouTube Shorts, usage limits and emergency apps are frozen. |
| Allow other bypass methods | OFF (the default) keeps the existing guard on App info / uninstall / device admin / Accessibility pages for LockDistra during a session. Switch it ON in Settings to turn that guard off. |

- During a session a switch can only go from allowed to off, never back, and a confirmation is shown first.
- The same five switches are free defaults in **Settings > Focus controls** between sessions.
- A session with no time limit can always be ended, so "turning OFF" cannot be locked for it (and the "No time
  limit" option is disabled while that default is locked). This stops a locked session from becoming a trap.
- Defaults match the earlier behaviour, so nothing changes until you switch something.

### Honest limits
- Android does not let an app block the power menu, restarting, Quick Settings, safe mode or `adb`. The locks cover
  LockDistra itself and the system screens the accessibility service can see. Revoking the accessibility
  permission in system Settings is only guarded while device admin is on, and a determined user can still get
  there from safe mode or a factory reset.
- Guarding of Settings pages matches English UI text (see `dangerousActions`).

### Tests
`./gradlew test` runs `app/src/test/.../PolicyTest.kt` (rules for controls, emergency windows, attempts and
tighten-only editing). These tests need no device. The whole update was written without an Android SDK, so it has
not been compiled or run on a phone yet.

## Educational Shorts and Inside apps (v1.3)

### Educational Shorts (`ui/screens/ContentScreens.kt` > `EducationScreen`, matching in `data/ContentPolicy.kt`)
Home > Blocking > **Educational Shorts**. It only does something while LockDistra is on and the **Shorts** restriction is on
(Blocked apps > YouTube Shorts, or Inside apps). The YouTube app is never whitelisted as a whole.

- **Channel whitelist**: type a channel name or `@handle` (or paste a `youtube.com/@handle` link). A Short whose channel matches plays;
  every other Short is blocked with the usual block screen. "Recently blocked" lists the handles of blocked Shorts so one tap allows them later.
- **Automatic detection** (switch, default OFF): scores the Short's caption, hashtags and channel name against education keywords
  (physics, jee, tutorial, explained...) minus entertainment keywords (prank, meme, dance...). Ads ("Learn more") are ignored.
  It is a **keyword heuristic that runs on the phone, not an AI model**. It can be wrong in both directions. The channel list is the reliable part.
- With no channels and detection off, behaviour is exactly as before: every Short is blocked at once.
- Editing rules during a session: channels can be removed but not added, detection can be switched off but not on, and everything is
  frozen when "Allow app restriction changes" is off (`ContentPolicy`).

### Inside apps (`FeaturesScreen`, `data/ContentStore.kt`)
Home > Blocking > **Inside apps**. Each switch closes one section while LockDistra is on, and the rest of the app stays usable.

| App | Sections |
|---|---|
| YouTube | Shorts (same switch as in Blocked apps), Search, Recommended videos (Home feed) |
| Instagram | Reels, Explore (the Search and explore tab), Search box |
| Facebook, Snapchat (only if installed, experimental) | Reels / Video / Marketplace, Spotlight / Discover |
| Any installed app | **Your own sections**: pick an app and type the name of a tab that highlights when open (Spotlight, Marketplace, Trending...) |

Closing a section escalates in three steps (`AppBlockerService.handleSectionHit`): tap a safe tab (for example Instagram Home), then Back,
then the block screen (`REASON_FEATURE`). Each step waits 0.9 s so a screen transition can't trigger the next one. During a session a switch can
only be turned ON, never off, and not at all when app restrictions are locked. Emergency access still opens one app completely for a few minutes.

### How detection works, and what can break
- Android has no API that lets one app filter inside another, and YouTube exposes no channel or Shorts API. Both features read the screen through the
  existing **Accessibility service**: one bounded snapshot (max 400 nodes) of resource ids, tab labels, selected state and visible text, compared in
  memory and discarded. Nothing is recorded or sent. The only thing saved is the `@handle` of a blocked Short (max 12), so it can be allowed later.
- This is **best effort**. The resource ids and tab names in `FeatureCatalog` come from the apps' current screens and any app update may change them.
  The user's own sections and the channel names the user typed do not depend on ids.
- Tab and button matching uses English labels. In another language add your own section with the local tab name.
- A Short's channel can take a moment to appear, so a non-educational Short can show for 1 to 2 seconds before it is closed. A Short that never shows a
  channel is treated as non-educational.
- Instagram shows Explore and Search on one tab, so blocking Explore also closes that tab.
- YouTube search is detected by its search box, and the Home feed by the selected Home tab. "Up next" suggestions under a playing video are not covered.
- Only the section on screen is checked, so a video opened from a link or notification plays until the user navigates into a blocked section.

### Tests
`ContentPolicyTest` covers channel parsing, whitelist matching (handle, display name, false matches from captions), the wait/grace logic,
automatic detection, section matching and the session edit rules. The logic in `ContentPolicy.kt` is Android-free, so these run with `./gradlew test`.
They were also run here on a plain JVM together with the existing `PolicyTest`. The Android parts (service, screens, stores) have **not been compiled or
run on a device**, because no Android SDK was available when this was written. Expect to fix a small compile error or two on first sync, and test the
section matching on your own phone's YouTube and Instagram versions.

## App lock (v1.4)

Settings > **App lock**. Off by default. It locks **LockDistra's own screens only** (dashboard, all settings, Emergency apps and
limits, Blocked apps, Usage limits...). It does not lock any other app. Blocking, usage limits, the timer and the notifications keep
working while the app is locked, so a locked LockDistra never weakens a running session.

### What the person gets
- **PIN (4 to 8 digits) or password (6 to 32 characters).** Obvious PINs (1111, 1234, 8765...) are refused. A number pad is used for a PIN.
- **Lock screen on open.** `FocusApp` composes nothing of the real UI while locked, so the dashboard, settings and emergency limits can't be
  reached by any route: launcher icon, recents, a notification tap, the "Open LockDistra" button on the block screen, or the
  "Emergency access" notification action. The lock screen replaces the splash that launch.
- **Stays after a restart.** The unlocked state lives only in memory (`data/LockSession`). A reboot or Android closing the app always brings the
  lock back. The PIN itself is saved and survives reboots.
- **Lock again after leaving the app**: At once (default), 30 s, 1 min or 5 min. Rotating the phone does not count as leaving.
  A trip to a system page the app opened itself (Accessibility, Usage access, Device admin, battery) is forgiven for up to 5 minutes so
  granting permissions doesn't lock the person out halfway.
- **Fingerprint / biometric** (switch, needs Android 10 or newer and a strong biometric saved in the phone). Turning it on asks for one real
  fingerprint first. The PIN / password always stays available as the other way in.
- **Wrong tries are throttled.** 5 free tries, then 30 s, 1 min, 5 min, 15 min and 1 hour. The count and the pause are saved, so closing the
  app or restarting the phone doesn't reset them. Within one boot the pause uses the monotonic clock, so changing the phone's date doesn't skip it.
- **Changing the lock** asks for the current PIN / password first, and so does turning the lock off or making a new recovery code.
  Turning the lock off or changing auto-lock / fingerprint follows "Allow changing LockDistra settings", so a locked session can't be
  loosened from here. Changing the PIN itself is still allowed.

### Forgot the PIN (recovery and reset)
Offline, and it only lets the person choose a **new** PIN or password. The old one is never shown or recoverable.
- **Recovery code only.** When the lock is turned on, a random 16-character code (80 bits, `XXXX-XXXX-XXXX-XXXX`, no look-alike characters) is shown once.
  It is not copied to the clipboard. Using it issues a fresh code. Wrong codes are throttled like PIN tries.
- **The phone's own screen lock does NOT open this lock (v2.4).** Earlier versions offered "Use my phone's screen lock" under Forgot. That was removed,
  including its code in `LockStore`, so anyone who knows the phone's PIN can no longer reset LockDistra's lock. Only the PIN / password set inside LockDistra,
  or its recovery code, works.
If the recovery code is lost, the only way left is clearing LockDistra's data in Android's App info.

### How credentials are stored (`data/LockStore.kt`, `data/AppLockPolicy.kt`)
- The PIN / password is **never stored**. A salted PBKDF2-HMAC-SHA256 hash is (120,000 rounds, 16-byte random salt, 256-bit result).
- That hash is then encrypted with an AES-256-GCM key kept in the **Android Keystore** (not exportable), so copying the preferences file
  off the phone is not enough to guess PINs offline. If the Keystore can't be used on some phone, it falls back to the salted hash alone.
- The recovery code is stored as a salted hash only (it has 80 random bits, so it needs no extra wrapping).
- Everything is in normal credential-protected storage (`app_lock` preferences), unreadable until the phone is unlocked after a restart,
  not in the device-protected storage the session uses. `allowBackup` is already off, so nothing is copied to a cloud backup.
- Typed PINs are kept out of saved instance state. Nothing here uses the network (the INTERNET permission is used only by the optional Online approval, v2.5).
- While app lock is on, `FLAG_SECURE` is set on the main window: screenshots are blocked and the recents card is blank. Turning the lock off
  clears it.

### Limits to know about
- This is an **app** lock, not a device lock. Someone who can uninstall LockDistra (when uninstall protection is off) or clear its data from
  App info can still remove it. Device admin / Advanced protection from earlier versions are what guard that.
- The **Emergency access** button on the block screen still works while the app is locked, because it exists to open ONE chosen app for a few
  minutes within the attempt limits already set. What it can't do while locked is change those limits, the chosen apps or any setting.
- A fingerprint is checked by Android and not tied to a Keystore key (Android 9 or older phones have no fingerprint option here).
- Written without an Android SDK: not compiled or run on a device yet (see the note at the top). Expect to fix a small compile error or two on first sync.

### Tests
`AppLockPolicyTest` (JUnit, no device needed) covers the PIN / password rules, pause schedule, when the lock comes back, hashing, and recovery
codes. Android parts (`LockStore`, lock screen UI, biometric prompt, Keystore) need testing on a real phone: set a PIN, close and reopen the app,
reboot, try wrong PINs, try the recovery code, and check that Forgot offers no phone-screen-lock option.


## Stability and security (v1.5)

### Staying alive in the background
- **Watchdog alarm.** While a session runs, `FocusEngine.scheduleNextWakeup` always sets an alarm at most 5 minutes ahead (besides the
  session end, emergency end and plant reminder). If the phone's battery saver stopped `FocusService`, `FocusAlarmReceiver` starts it again.
- **Quick revival.** Swiping LockDistra out of recents (`onTaskRemoved`) or the system killing the service (`onDestroy` while the session
  is still on) sets a 3 second alarm. A normal stop ends the session first, so nothing is scheduled then.
- **Second safety net.** The accessibility service's poll loop re-starts the foreground service about once a minute if a session is on.
- **Battery optimisation.** Settings > Permissions > Battery optimization explains and asks (unchanged). The dialog now also shows
  steps for Xiaomi / Redmi / POCO, OPPO / realme / OnePlus, vivo / iQOO, Samsung and Huawei / Honor (`Permissions.oemBatteryHint`),
  because those makers stop apps even after the normal exemption. Android gives no way to switch those extra options on for the user.
- **Status notification.** If it is swiped away (Android 14 and newer allow that for foreground services) the delete action puts it back at once.

### Restart and clock handling
- **Only real boot signals can end a session.** `LOCKED_BOOT_COMPLETED` and `BOOT_COMPLETED` can only come from Android. The vendor
  `QUICKBOOT_POWERON` actions can be sent by any app, so they can bring a session back but never end one (`RestartPolicy`). Before this, an
  app could have sent a fake quick-boot broadcast to end a session when "Restore after restart" was off.
- **Changing the phone's date or time does not shorten or stretch a session** (`data/ClockGuard.kt`, `FocusStore.syncClock`). While a
  session runs, the wall clock is compared with the monotonic clock (which a user can't change). A jump of a minute or more moves the session's
  start, end, emergency window and next reminder by the same amount, so the time left stays the same. This also helps when the phone's
  time is corrected by the network after a restart. A jump that happens while the phone is off or restarting can't be seen.

### Notification and intent bypass
- `MainActivity` has to be exported (launcher), so other apps could send it the notification intents. Those intents now carry a random
  key made on the phone (`data/IntentGuard.kt`). Without it the intent is a plain launch: no "grow plant", no jump to the Emergency picker,
  no jump to Usage limits. The key is in device-protected storage, not in backups.
- **Plant growth can't be forged.** Only the tap of the reminder that was really posted can grow the plant, once (`GrowPolicy`).
- Emergency access from the notification still follows the same rules as the dashboard (checked again when tapped), and every notification
  tap lands on the app lock first when the lock is on.

### Final review and cleanup in this version
- Version 1.5 (code 6). Added `.apk` / `.aab` to `.gitignore`.
- Static checks run here: brackets balanced in every Kotlin file, every `R.string` used exists, every project import resolves, no TODO / debug
  logging left. New tests: `StabilityPolicyTest` (clock jumps, restart rules, plant-growth rule).
- **Not done here:** compiling and running. No Android SDK or Kotlin compiler was available, so nothing has been built or run, including the
  new tests. First sync may show a small compile error.

### Honest limits (v1.5)
- Daily usage limits reset by calendar date, so moving the date forward can still reset a daily limit. Sessions are protected from clock
  changes, daily limits are not.
- A phone maker's own task killer can still stop LockDistra until the next watchdog alarm (up to about 5 minutes). Doze may delay that alarm further.
- Android still can't block the power menu, safe mode, Quick Settings or `adb`.

### Test on a real phone before relying on it
1. Start a 10 min session, swipe the app from recents: blocking and the notification must stay or return within seconds.
2. Swipe the status notification away: it must come back.
3. Move the phone's date forward 1 day: the session must not end and the time left must stay about the same.
4. Reboot with "Restore after restart" on and off, with and without "Allow turning OFF".
5. With adb, send `am start -n com.focusmode.app/.MainActivity --ez open_emergency true`: it must only open the app (or the lock screen), not the Emergency picker.
6. Lock screen on: tap each notification and check it asks for the PIN first.

## Plant page and check-ins (v1.6)

### Plant page (`ui/screens/PlantScreen.kt`)
The plant no longer sits on the dashboard. The dashboard shows a short "Your plant" card (stage, next check-in) that opens **Plant**, a page
of its own with the big animated plant, a progress bar, the check-in timing chips (Off / 15 / 30 / 45 min), "Plant a new seed" at full growth and
a short explanation. The plant only grows here. (The block screen still shows a small plant picture as decoration; it does not grow there.)

### Check-ins: "Are you studying?"
At every reminder interval a check-in is posted. It is answered in one of two ways, and each one grows the plant once:
1. **App open:** a full-screen "Are you studying?" cover appears (`CheckInOverlay`). **One tap anywhere** answers yes. A short message
   confirms it and the plant has grown on the Plant page.
2. **App closed:** the notification has a **"Yes, I'm studying"** button (`CheckInReceiver`). It answers without opening the app, so a
   lecture, video or notes stay on screen. Tapping the body of the notification opens the app on the Plant page, where the cover waits.

Rules: a check-in only counts for the reminder that was really posted and only once (`GrowPolicy`); the receiver is not exported, so other apps
can't send it; nothing can be answered when no session runs (`FocusState.checkInPending`). An unanswered check-in simply waits; the next
one replaces it. The button also works on the lock screen, by design. Nothing proves the person is truly studying: it is an honesty check.

### Tests
`StabilityPolicyTest` has a new test for `checkInPending`. Like everything else here it was written without an Android SDK and is **not compiled or run yet**.


## Safety and Google Play

- No analytics, no ads. The only account is an optional email login (v2.7) that sets the name shown on the trusted phone. INTERNET is used only by the optional Online approval unlock (v2.5, off by default). Backups are off. Without a connected trusted phone nothing leaves the device.
- Screen content is never recorded or stored. The accessibility service reads it only to compare it
  on the device, and only for the foreground app and for sections the person turned on.
- Games are left alone: no overlay over a game unless switched on in Usage limits, and nothing is
  read, tapped or sent Back inside a game (`service/GameApps.kt`).
- Two builds from one code base: the normal build keeps every feature (uninstall protection, device
  admin, one-tap battery request). `-PplayBuild=true` makes the Play-safe build, which leaves
  uninstall protection out because Google Play does not allow an app to prevent its own removal.
- Google Play Protect warning screens are never covered (`SafetyConfig.ALLOW_PLAY_PROTECT_SCREENS`).
- The code is not obfuscated on purpose; obfuscated accessibility apps draw more suspicion.
- To publish on Play: use the Play-safe build, sign a release build, fill in Play Console's
  Accessibility API and foreground-service (special use) declarations.


## Shorts, Reels & Status limits and popup fix (v1.7)

- **Content catalog** (`data/ContentPolicy.kt`, `ShortFormCatalog`): YouTube Shorts, Instagram Reels, Facebook Reels,
  WhatsApp Status (also WhatsApp Business) and Snapchat Spotlight. Only content whose app is installed is shown, in
  Blocked apps, Inside apps and Usage limits. WhatsApp Status is recognised by its full-screen viewer window
  (`StatusPlayback...`) or by the selected Updates / Status tab. Like every in-app detection it is best effort and an
  app update can break it.
- **Separate daily limits** (`UsageLimitStore`, Usage limits > "Shorts, Reels & Status"): each content kind has its own
  daily time (`cat_limits`, `cused_<id>`), counted only while that content is on screen, reset at midnight together with
  app limits. At the limit the service taps a safe tab, then presses Back, then shows `BlockActivity`
  (`REASON_CATEGORY`). The rest of the app stays usable. Normal app blocking, app limits and these limits are
  independent of each other.
- **Emergency**: unchanged. It still opens one blocked app for 2-4 minutes. Like app limits, a daily Shorts / Reels /
  Status limit is not lifted by an emergency window, and time used during one still counts.
- **Timer popup** (`service/TimerOverlay.kt`, `AppBlockerService.trackLoop`):
  - *Always*: re-attaches itself if Android drops the window, so it no longer vanishes for good.
  - *Every 1 / 2 / 5 / 10 min*: the service counts active use per app (`PopupSchedule`, saved in `UsageLimitStore`),
    and the popup slides in from the screen edge when the time is up, stays about 6 seconds and slides out. Switching
    apps, hiding the window or the screen turning off no longer resets the schedule.
  - A one-second watchdog re-checks which app is really in front, so a dialog from another app that closes without
    an event cannot leave the counter or timer stopped.

## Tests

`./gradlew testDebugUnitTest` runs the unit tests, including `ShortFormTest` (installed-only content, WhatsApp
Status detection, popup intervals, schedule across app switches).

## v2.3 – timer visibility, fixed icon position, security hardening

- **Timer in every limited app.** The floating timer now shows over every app that has a limit
  (Instagram, YouTube, WhatsApp, Facebook, games ...). "Also over games" (Usage limits) still exists but is
  **on by default**, and a one-time migration switches it on for people who still had the old default off.
- **Floating timer stays where you put it.** Drag it anywhere and let go: it stays at exactly that spot. It no
  longer docks to an edge, re-centres or drifts, a drag that is cut short (app switch, screen off) is still
  saved, and the position is written to disk immediately so it survives closing the app and restarting the
  phone. Tapping still shrinks it to a circle / expands it, and dragging a pill onto a screen edge still turns
  it into a circle. Both keep it on the same edge at the same distance. Only your own drag or tap changes anything.
- **Security.** See `SECURITY.md`. Signing passwords moved out of `build.gradle.kts` into
  `keystore.properties`; the release build is never signed with the debug key; `isAccessibilityTool="false"`
  declared. No feature or permission was removed.

## v2.7.4 – lock bypass fix, lock timer for every unlock method, Prevent changes

- **Bug fixed: Online approval opened the app without asking again.** After one approval the "Approved" state
  stayed in memory (the lock screen left the screen the instant the app opened, so it never cleared it). The
  next lock screen saw that old "Approved" and opened by itself. `OnlineManager` now clears it on its own
  (1.5 s after an approval, and again whenever the lock screen is about to show), and the lock screen no
  longer acts on a leftover approval. Applies to "Online" and "Both".
- **Lock again after leaving the app** (Settings, own card). Works for PIN / password, Online approval and Both:
  *At once, 5 s, 10 s, 30 s, 1 min, 5 min*. Coming back after that time shows the lock screen and needs the
  PIN / password or an approval from the trusted phone. It is stored apart from the PIN, so it also works with
  Online only and is kept when the PIN lock is turned off.
- **Prevent changes** (Settings). While on, no blocked app, limit, Shorts / content setting, Emergency app or
  LockDistra setting can be changed (`FocusState.changesLocked`, enforced in `FocusStore`, `ContentPolicy`,
  `EmergencyPolicy`, `AppViewModel`). Starting a session, Emergency access and Appearance still work.
  To change anything: type the app PIN / password or a recovery code, or ask the trusted phone to approve.
  That opens a 5 minute editing window (`ChangeGuard`, monotonic clock, memory only), then it locks again;
  "Lock now" closes it early. Turning it off needs the same check. It can only be switched on while a way to
  unlock it exists (App lock or a trusted phone), and it switches itself off if the last way is removed.
  The trusted phone sees a normal unlock request for this (same protocol, nothing changed on its side).
- Tests: `ChangeLockTest` (window times, what "locked" blocks, lock timer with Online-only).

## v2.0.1: Shorts / Reels / Status limit fix

- **Floating timer for Shorts / Reels / Status limits.** Before, the timer only existed for whole-app limits, so a limit set only on YouTube Shorts (or Reels, Status) showed nothing. It now shows (always, or every N min, following the Usage limits setting) while that content is open, with its own remaining time, and goes away when you leave it. If the app also has a limit, the one that runs out first is shown.
- **More reliable Shorts detection** (`ShortsDetector` in `data/ContentPolicy.kt`). YouTube renames its view ids often, so the old fixed list could miss the player, meaning nothing was counted and nothing was closed. The player is now also recognised by any visible `reel_*` / `shorts_*` view (the Home-feed Shorts shelf is excluded) and by the selected Shorts tab.
- `categoryTick` now returns what is open and how much time is left; the limit still closes the content with: safe tab, then Back, then the block screen.
- Tests: `ShortsLimitFixTest` in `ShortFormTest.kt`.

## v2.1.0: Timer designs and position lock

- **Timer design** (Usage limits > Floating timer > Timer design, with a live preview): Logo + name + time (the old look), Logo + time, Only time, Logo above time, and Plain text (no box). The small circle stays as it was. Code: `data/TimerStyle.kt`, `service/TimerOverlay.kt`.
- **Position lock**, in the circle and in the normal shape, and for sliding popups too. Leave the timer alone for 5 seconds and it locks where it is: dragging does nothing. To move it again, tap it 5 times in a row (each tap within 2 seconds of the last). A short buzz and a message say it is unlocked; drag it, and it locks again after 5 seconds without a touch. While locked, a tap never closes a popup or shrinks the timer. A timer that was never placed starts unlocked, so it can be put in its first spot. Logic: `TimerLock` in `data/TimerStyle.kt`.
- Adds the normal `VIBRATE` permission (for the unlock buzz).
- Tests: `TimerDesignTest`.

## v2.2.0: Emergency access on limit screens

- When an **app limit** or a **Shorts / Reels / Status limit** is used up, the block screen now has an **Emergency access** button (before, it only existed for focus-session blocks). It opens the app (or that content) for a few minutes; the app closes again by itself when the window ends. Time keeps counting, so the limit stays used up.
- It is part of the limit: the limit editor has an **Emergency access** section at the bottom (on/off, attempts per day 1 to 5, minutes each time 1 to 5). A limit that was never configured uses the default: on, 2 attempts of 2 minutes. Attempts come back every midnight; an attempt is used when started and is never given back.
- While the window runs, the floating timer shows an "Emergency" countdown.
- The focus-session Emergency access (Emergency apps screen) now also offers 1 to 5 minutes.
- Code: `data/LimitEmergency.kt`, `UsageLimitStore` (emergencyFor / startEmergency), `AppBlockerService`, `BlockActivity`, `LimitsScreen`. Tests: `LimitEmergencyTest`.


## Adult Content Blocking
Built-in adult-website blocklist with an offline database and optional safe updates: see `ADULT_BLOCKLIST.md`.
