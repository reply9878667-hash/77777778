# Study Section – Part 4/4: Source Recovery, Health Monitoring & Final Reliability

## Read first: what was and was not verified
This sandbox has **no Kotlin compiler, no Gradle, no Android SDK and no network**. So in this part **nothing was compiled and no test was run**
(Part 3's doc reports that it could compile/run its pure-Kotlin files; here that was not possible). What was done instead:
every edit was desk-checked line by line against the real signatures in the code, every new test was traced by hand against the code it
tests, and bracket balance of all changed files was checked by script (balanced). Please run `./gradlew testDebugUnitTest` and a debug
build before release; if the compiler complains about anything, it will be a small typo-level fix.

## What changed (and why)
| # | Requirement | What was wrong / missing | Fix |
|---|---|---|---|
| 1 | Automatic recovery | Recovery was only noticed when the Study screen **opened**. After a lost connection came back, nothing re-checked until the person left and re-entered. | `StudyScreen` registers a connectivity callback **only while Study is on screen** (no service, no timer). On "network back" a background thread runs `StudySourceChecker.onNetworkRestored()`: network-only cool-downs end, phone facts are re-read ("no internet" clears), failed sources are re-checked once. The list on screen is **never reloaded**. Only an *error card* retries itself once (`networkTick`); a failed web search does the same (`retryTick`). |
| 1 | Recovered source is used again | A request that failed in the last 3 s (or 60 s after 3 failures) was answered from memory **even if a source had recovered meanwhile**. | `SourceTracker.recoveryEpoch` goes up whenever something comes back (a source recovers, network restored, a phone fact clears). The switcher ignores a remembered failure from an older epoch. Priority is unchanged, so the recovered API is preferred again for the **next** request; a request/video already running is never interrupted. |
| 2 | Health monitoring | Only status / reason / failures / retryAt existed. | `SourceState` now also keeps last success, last failure time + reason, smoothed response time, recovery time. `SourceTracker.health(mode)` / `healthAll()` give a `SourceHealth` with a `RecoveryStatus` (HEALTHY, RECOVERED, WAITING, RETRY_DUE, BLOCKED_BY_PHONE) and the time left of the cool-down. Numbers are plain memory writes: no polling, no timers. Response time is measured for every real API answer and for each re-check probe. |
| 3 | Stability | A source that failed again right after recovering started over at a 30 s cool-down, so a flapping source could cause constant switching. | A failure within 2 min of a recovery keeps counting from the earlier failure count (30 s → 60 → 120 → 240 s … max 10 min). Outside that window it starts fresh. |
| 4 | False warnings | (a) The "all failed" message said the other sources "could not be reached" even when one was only switched off / its app was turned off. (b) All other cases said the same generic text. (c) The API no-key text said "YouTube is not connected". | Messages now name only **verified** reasons, per source (`SwitchMessages.reasonPhrase` / `detail`): daily limit, rate limit, invalid / refused key, no key, temporary server error, unreadable answer, YouTube app turned off / not installed, permission missing, web view missing / could not start / stopped. Unknown causes are never named. A test proves no reason can produce "Please enable…", "…is disabled", "…is unavailable". No-key text is now factual ("This needs a YouTube API key, and none is set…"). |
| 5 | Complete failure | Error card + Try again already existed (Part 3). | Added: auto-retry after reconnect (see 1), re-checks skipped while the phone is offline for sure (no wasted battery), specific message (see 4). The screen still never goes blank: an old list stays, otherwise the one error card shows. |
| 6 | Performance | Duplicate-request joining, 3 s/60 s memory, cool-downs, channel/video caches existed (Part 3). | `StudyApi.details` now falls back to the **older** answer for a video (any age) when the API cannot answer, so titles/lengths/thumbnails/channel ids do not disappear while another source takes over. Offline re-checks skipped. Nothing else was added, on purpose. |

## Modified files
`data/StudySources.kt` (health fields, recovery epoch, `networkRestored`, `health`, flap rule) · `data/StudySwitch.kt` (epoch-aware memory,
specific messages) · `data/StudySourceChecker.kt` (`onNetworkRestored`, offline skip, probe timing) · `data/StudyApi.kt` (response time,
factual no-key text, older-metadata fallback) · `ui/screens/StudyScreen.kt` (connectivity callback, auto retry of an error card) ·
`ui/screens/StudyWebSearch.kt` (`retryTick`) · **new** `test/.../StudyRecoveryTest.kt` (33 tests) · this file.
No UI was redesigned; no new service, no timer, no new permission (`ACCESS_NETWORK_STATE` was already required by Part 2).
Parts 1–3 behaviour is unchanged: priority API > Direct YouTube > Web, title colour, caches, endless scroll, Shorts, avatars.
This part touches only the phone-side Study code; `worker/` and `firebase/` (the external server side) were not changed and are not used by the Study sources.

## Scenario matrix (`StudyRecoveryTest`; desk-checked, **not executed**)
| # | Scenario | Test | Expected |
|---|---|---|---|
| 1 | All three working | `scenario1_…` | API serves, nobody else asked |
| 2 | API quota exhausted | `scenario2_…` | Direct YouTube serves; API used again after the reset |
| 3 | Direct YouTube unavailable | `scenario3_…` | Web search takes over (hand-off) |
| 4 | Web unavailable | `scenario4_…` | API / Direct still serve |
| 5 / 6 | YouTube app disabled / enabled | `scenario5and6_…` | Only Direct is blocked, reason "app disabled"; back in use once enabled |
| 7 | Internet disconnected | `scenario7_…` | One "No internet connection" message, no "disabled" wording |
| 8 | Internet returns | `scenario8_…`, `scenario8b_…` | Same request works at once; stale failure memory ignored |
| 9 | Failed API works again | `scenario9_…` | Asked again after its cool-down, marked available |
| 10 | Several sources fail together | `scenario10_…` | Message names the verified reasons (daily limit, app off, switched off) |
| 11 | Failure while switching | `scenario11_…` | Next source serves in the same call; only the failed one is blamed |
| 12 | Repeated failures + recovery | `scenario12_…`, `repeatedFailuresAndRecoveries_…`, flap tests | Each source asked once, no loop, recovery ends it |
| 13 | Channel profile / thumbnails across sources | `scenario13_…` | Same video id, channel id/name kept, thumbnail by video id |
Plus: health snapshot (6 tests), recovery detection per source, network-only cool-down rules, no-internet clearing, wording per failure (6 tests).

## Remaining limitations (honest list)
1. **Not compiled, not run** (see top). Real-device behaviour of the connectivity callback, `PackageManager`, `WebView` error callbacks and the live YouTube pages / API is untested.
2. The health numbers are **not shown on screen** (you asked for no UI redesign); they are available via `StudySources.tracker.health(mode)` for a report/debug screen later.
3. Response time is measured for API answers and re-check probes, not for every Direct-YouTube search or WebView page load.
4. The connectivity callback fires also when the phone changes from Wi-Fi to mobile data; that only causes one cheap re-check of sources that had *network* failures. A Wi-Fi with a login page counts as "online" until a real request fails.
5. Channel *details* (`channelInfos`) deliberately get **no** older-answer fallback: a half answer would make the phone remember "this channel has no picture" for good. The channel page still opens with the saved name/logo (Part 3).
6. Thumbnails themselves are plain image URLs loaded by the existing image loading; no image-cache change was made. Only the metadata (title, length, channel, thumbnail URL) fallback was added.
7. `SourceClassifier.DIRECT_REQUIRES_APP = true` (Part 2 decision) still means a phone **without** the YouTube app skips Direct YouTube; set it to `false` if that is not wanted.
