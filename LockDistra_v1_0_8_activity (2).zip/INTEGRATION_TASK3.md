# Task 3 – Complete application integration

Continues from `PROFILE_TASK2.md`. Onboarding screens, the seven questions, login / sign-up / Google, the profile system,
Home and all blocking / unlock code are **reused, not rebuilt**. This task only connects them.

> **Not compiled or run.** Written without an Android SDK / Gradle (same as Tasks 1 and 2). Open the project in Android
> Studio, sync, and expect to fix a small compile error or two. New pure logic has unit tests
> (`AppEntryRulesTest`): `./gradlew testDebugUnitTest`.

## What was found (and why a router was needed)
| Piece | Where | State before Task 3 |
|---|---|---|
| Onboarding | `ui/onboarding/OnboardingFlow`, answers in `data/OnboardingStore` | drawn as an **overlay on top of Home**; progress lived only in memory |
| Login / Sign-up / Google | `ui/auth/AuthFlow`, `data/auth/AuthRepository` | overlay on top of Home, **skippable**; Home reachable logged out |
| Profile + DB | `data/profile/ProfileRepository` (Realtime Database `users/{uid}`) | follows the login; claims onboarding answers when an account first appears |
| Home / navigation | `ui/FocusApp.kt` (`vm.screen`) | one big function that also hosted splash, onboarding and login |

## The integrated flow
One function decides the top-level screen: `data/AppEntryRules.route(...)`, shown by the new `ui/AppEntry.kt`.
```
New user         Splash -> Welcome -> Q1..Q7 -> Celebration -> Sign up -> "Welcome" -> Home
Existing user    Splash -> saved login found -> Home                      (no onboarding, no login screen)
Logged-out user  Splash -> Log in -> "Welcome back" -> Home
Returning user, new phone / reinstall:  Welcome -> "I already have an account" -> Log in -> Home
```
`Onboarding`, `Auth` and `Home` are **siblings**, not stacked overlays. Home is not composed while someone is logged
out, so no authenticated screen, dialog or request can show through, and Android Back has no earlier onboarding / account
screen to return to (Back on the first screen of a route leaves the app).

Facts used by the router are all saved on the phone, so the right screen appears on the **first frame after every restart**:
login (`AuthStore`), onboarding finished (`OnboardingStore.welcomeDone`), unfinished-onboarding draft, "new account owes
its own onboarding" marker.

## Requirements -> what was done
**Onboarding preserved / not duplicated**
* All answers are saved **after every change** (`OnboardingStore.saveDraft`); closing the app halfway resumes on the same
  question with the same answers.
* Celebration -> Continue: `saveAnswers` writes final answers + "done" flag + deletes the draft in **one commit**
  (previously two writes, so a kill in between could leave "done" without answers).
* Completed but not registered (app closed on the account screen): restart shows the **Sign up** screen, answers still
  waiting (unclaimed). They join the account created next, exactly once (Task 2 rule, unchanged: create-once on the server).
* Existing users are never asked again: a saved login always means Home; a login on a phone that never ran onboarding marks
  it done.
* Second person registering on a phone whose answers belong to another account: the **new account answers the questions
  itself** (`OnboardingStore.requiredFor`), then `ProfileRepository.claimPendingOnboarding()` files them under its uid.
  Never shared between accounts.

**Authentication**
* Login is now **mandatory** (`AuthConfig.REQUIRE_LOGIN = true`, Skip button gone, `ALLOW_SKIP = false`). Enforced only
  when Firebase is configured in this build (`AuthConfig.authRequired`); without Firebase an account cannot exist and the
  app stays open as before rather than locking you out of your own blocker.
* After sign-up / login a person sees the existing "Welcome" confirmation and presses Continue; Home does not jump in underneath.
* Logout (Settings -> Account, unchanged) ends the session and the router immediately shows the Log in screen;
  `vm.screen` is reset so the next login lands on Home, and a pending "Emergency access" shortcut is dropped.
* **Expired session:** at start *and every time the app returns to the foreground* (max once a minute) the server is asked
  whether the login still stands (`AuthRepository.revalidate`). Only a definite "no" (account deleted / disabled / token
  revoked) logs out, and the Log in screen says "Your session has expired. Please log in again." Offline never logs anyone out.

**Profile**
* Home's greeting name follows the account (`profile.displayName`, falling back to the login name) at login, after switching
  accounts and after profile edits. Profile screen (name, email, avatar, edits to `users/{uid}`) is unchanged.
* Missing name (some Google accounts): the profile gets the email's first part (or "Me") instead of a blank.
* Blocking, limits, timers and the trusted-phone listener are services and keep working while logged out; only the UI is closed.

**Errors** (all existing messages reused, nothing new crashes into a blank screen): no internet / timeout / wrong password /
Google failure / disabled account -> message on the account screen; database load or save failure -> banner on the Profile
screen with Retry (Home is never blocked by it); interrupted sign-up -> fields stay, nothing half-created (Task 1 guard);
expired session -> message above.

## Files
**New (3):** `ui/AppEntry.kt` (router + glue), `data/AppEntryRules.kt` (pure rules), `app/src/test/.../data/AppEntryRulesTest.kt`; this file.

**Modified (11):**
| File | Change |
|---|---|
| `ui/FocusApp.kt` | lock gate now opens `AppEntry`; `FocusAppContent` = Home only (takes `showSplash`); onboarding / first-run login / splash overlays removed from it. Home design and all its code untouched. |
| `data/OnboardingStore.kt` | + draft save/load/clear, `requiredFor`, `hasAnswersFor`; `saveAnswers` atomic with the done flag |
| `ui/onboarding/OnboardingFlow.kt` | + `initialDraft`, `onProgress`, `onHaveAccount` (all optional) |
| `ui/onboarding/WelcomeScreen.kt` | + small "I already have an account" text link under the button (only when `onHaveAccount` is passed) |
| `data/auth/AuthConfig.kt` | `ALLOW_SKIP=false`, + `REQUIRE_LOGIN`, `authRequired` |
| `data/auth/AuthRepository.kt` | + `notice` / `takeNotice`, `revalidate()`, expired flag in `forgetLogin` |
| `data/auth/AuthErrors.kt` | + `SESSION_EXPIRED` text |
| `ui/auth/AuthFlow.kt` | `onFinished(isNewAccount)`; shows the pending notice |
| `ui/auth/AuthViewModel.kt` | + `showPendingNotice()` |
| `data/profile/ProfileRepository.kt` | + `claimPendingOnboarding()`, claim after restart, blank-name fallback |

Left as is on purpose: `OnlineManager.skipLogin` / `OnlineStore.loginAsked` (now unused, harmless), the logged-out name dialog
on Home (only reachable when Firebase is not configured), `AUTH_TASK1.md` / `PROFILE_TASK2.md` (history; this file supersedes
their "Skip" and journey statements).

## Required configuration
Nothing new. Task 1 and 2 setup must work: Email/Password (and Google) enabled, `firebase.properties` filled, Anonymous
sign-in on, database rules from `firebase/database.rules.json` published. **If `firebase.properties` is empty the login is
not enforced** (see above), so fill it before testing the mandatory flow.

## Manual test (clear app data before each numbered test unless stated)
1. **New user:** Splash -> Welcome -> answer Q1-Q7 (Q6 "Set my own goal" 95 min, skip Q7) -> Celebration -> Continue -> **Sign up**
   (no Skip) -> create account -> "Welcome" -> Continue -> Home. Home greeting = the account name. Profile shows the 7 answers.
   Firebase console: `users/<uid>/profile` and `onboarding` exist.
2. **Back button:** on Sign up press Back -> app leaves (does not return to the questions). On Home press Back -> app leaves.
   From Q1 Back -> Welcome; from Celebration Back -> Q7 (unchanged).
3. **Interrupted onboarding:** answer Q1-Q3, swipe the app away, reopen -> same question with answers kept.
   Reach the Celebration, swipe away, reopen -> Celebration again, nothing lost.
4. **Interrupted registration:** finish onboarding, stop on the Sign up screen, swipe away, reopen -> Sign up screen
   (not the questions). Sign up -> the answers appear in Profile.
5. **Existing user:** (logged in) swipe away, reopen -> Splash -> Home directly. Also after a phone restart and in airplane mode.
6. **Logout:** Settings -> Account -> Log out -> confirm -> Log in screen at once. Back leaves the app. Log in -> Home on the
   Home tab with the right name / email / avatar in Profile. Log in as a *different* account -> its own name and answers only.
7. **Logged-out launch:** after logout, swipe away, reopen -> Log in screen, never Home or onboarding.
8. **Existing account on a fresh install:** Welcome -> "I already have an account" -> Log in -> Home, **no questions**; the
   profile shows the server's answers. (X on the login screen returns to Welcome.)
9. **Second account on the same phone:** log out, Sign up with a new email -> after the "Welcome" screen the **questions
   run once** for this account -> Home. Console: the new uid has its own `onboarding`; the first account's is untouched.
10. **Expired session:** logged in, delete the user in the Firebase console, return to the app with internet (or reopen) ->
    within seconds: Log in screen with "Your session has expired. Please log in again." Offline: nothing happens.
11. **Errors:** airplane mode on the Sign up screen -> "No internet connection"; wrong password -> "Wrong email or password";
    cancel the Google sheet -> nothing; Profile screen offline -> offline banner, Home still opens.
12. **Blocking while logged out:** start a session / block an app, log out -> the app is still blocked.
13. **Rotate** the phone on every route: typed text and position stay.

## Notes / limits (honest)
* Mandatory login also applies to people who had skipped it in earlier builds: after updating they see the Log in / Sign up screen once.
* Logging out is refused while a trusted phone is connected (Task 1 rule, unchanged), so that case shows the existing message.
* Focus settings (blocked apps, limits, emergency apps) are stored per phone, not per account, as before; a different
  account logging in on the same phone sees the same settings. Making them per-account is a separate feature.
* Final application-wide testing / optimisation (Task 4) was not started.
