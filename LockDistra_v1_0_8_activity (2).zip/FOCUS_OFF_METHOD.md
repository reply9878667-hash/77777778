# Focus OFF method + "Ready to Start Focus Mode?" popup

STATUS: written, NOT compiled, NOT run, NOT tested on a device (no Kotlin compiler / Gradle / Android SDK in the authoring
environment). Build in Android Studio, run `FocusOffMethodTest` and the existing unit tests, then do the manual checks below.

## What it does
- Settings > Focus > "Turn OFF method": Normal Button (default) / Password / Online Approval. Stored in `FocusStore` (`focus_off_method`).
  Changeable only between sessions and only while ReWire settings are unlocked.
- A method that is not set up is not selected; the note says what to set up (App lock under Security, or Trusted phone under Security).
  Nothing new is created: Password = the existing App lock PIN/password (`LockController.verify`, same lockout), Online Approval =
  the existing request to the trusted phone (`OnlineManager.requestUnlock`, new `forFocusOff` purpose that opens nothing by itself).
- Every "end Focus" path asks the chosen method: the ring's End button, and Pomodoro Pause / Stop while a Focus round runs.
  A finished timer, a Pomodoro Break and the locked-session message ("Allow turning ReWire OFF" off) are unchanged.
- Start popup (replaces the old "Start session?" dialog): heading, message, up to 4 apps / 3 games with icons and names, websites
  as a short list + count, "+ N more", "Focus Mode can be turned OFF using: <method>", Cancel / Enable Focus Mode. The preview uses
  the selected Focus Profile (or the phone-wide lists when no profile exists). If the chosen method is not set up any more,
  Enable is disabled and the text says what to set up.

## Safety rules
- If the chosen method lost its setup mid-session (App lock removed, phone disconnected) the plain button is used, so nobody gets trapped.
  Turning the App lock off already asks for the PIN; disconnecting the phone is blocked while a session runs with Online Approval chosen.
- Online Approval has no offline fallback inside this dialog (by design of the request). A session with a timer still ends by itself.

## Files
new: `data/FocusOffMethod.kt`, `ui/screens/FocusOffDialogs.kt`, `FocusOffMethodTest.kt`, this file
changed: `data/FocusStore.kt`, `data/online/OnlineManager.kt`, `ui/online/OnlineScreens.kt`, `ui/screens/FocusControlsCard.kt`,
`ui/screens/Sheets.kt`, `ui/screens/SettingsScreen.kt`, `ui/screens/LockScreens.kt` (VerifyDialog made `internal`),
`ui/AppViewModel.kt`, `ui/FocusApp.kt`

## Manual device checks
1. Method = Normal: End focus works as before. Settings shows the chip selected.
2. Password with no App lock: chip refuses, note says to turn on App lock. Turn it on, select Password, start Focus, press End: PIN
   dialog; wrong PIN stays ON; right PIN ends. Pomodoro Pause/Stop during a Focus round asks the same.
3. Online with no trusted phone: refuses with the setup note. Connect a phone, select Online, start Focus, press End: request is sent;
   Reject / expiry keeps Focus ON; Approve ends it. Disconnect phone during the session is refused.
4. Change the method during a session: refused. Between sessions: works.
5. Start popup: heading/message/method line correct for each method; 2-4 app icons, games, websites, "+ N more"; Cancel does not start;
   Enable Focus Mode starts. Remove the App lock after choosing Password: Enable is disabled with the setup text.
6. Pomodoro Break / finished timer / "Allow turning OFF" off behave as before.
