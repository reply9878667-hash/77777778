# Study Section – Part 3/4: Automatic Source Switching & Intelligent Fallback

**Compile / test status (read first).** The UI files (`StudyScreen`, `StudyWebSearch`) and `StudyStore` need the Android SDK and were
**not compiled** here. Everything else was: `StudySwitch`, `StudyRepository`, `StudyApi`, `StudyRules` and the new test compiled with
Kotlin 2.0.21; `StudySwitchTest` (39 tests) ran green 5 times in a row; the real `StudyRepository` was also run end-to-end against a
real network failure (see "What was run"). Run `./gradlew testDebugUnitTest` and a debug build before release.

## How it works now
One object decides everything: `SourceSwitcher` (`StudySwitch.kt`, pure Kotlin). Repository methods only say *how* each source does
the job; *which* source runs, what happens on failure, cool-downs and duplicate requests live in the switcher.

```
request ─► API ──fail──► Direct YouTube ──fail──► Web (WebHandoff → screen opens the WebView search) ──fail──► ONE clear error
            │ skipped at once if: switched off · no key · all keys resting · in cool-down · blocked by a local fact
```
- **Priority** API > Direct YouTube (`StudyMode.PAGE`) > Web, but a source is asked only if `check()` says it is really usable now
  (live phone facts first, then the Part 2 tracker). A failed source is skipped *instantly*; nobody waits for it to fail again.
- **Web** is a WebView on screen, so it cannot run in the repository: when API and Direct cannot serve, the chain ends in `WebHandoff`
  and the screen opens the web search (the only switch the screen performs).
- **Which source can serve what** (`StudyOp`): home feed API/Direct/Web · home "load more" API/Direct · first search page API/Direct/Web ·
  next page + Shorts API only · channel details API (else saved name/logo) · channel first page API/Direct · channel next page API only.

## Requirement by requirement
| # | Requirement | Where / how |
|---|---|---|
| 1 | Automatic switching with real availability | `SourceSwitcher.check` + `run`; priority list `SourceSwitcher.PRIORITY` |
| 2 | Intelligent fallback examples | quota → Direct; Direct unavailable (also: network/unreadable) → Web; auth error / no key → alternative; Web down → others still serve. A failure is recorded for **that** source only (test `oneSourceFailingDoesNotTouchTheOthers`) |
| 3 | Fast switching | next source starts in the same call the moment a failure is seen; cooling sources cost 0 ms (measured 0–1 ms); only the request's own list is touched, no screen reload; duplicate in-flight requests are joined; failed refresh/page never removes the list; thin loading line while on a fallback (`StudySwitch.switching`, shown after 250 ms so a quick switch does not flicker) |
| 4 | Content consistency | same video from two sources = one entry, richer details win, never a different id (`StudyMerge`); thumbnails always by video id; channel id/name/logo preserved (and never overwritten by empty); channel page via Direct keeps only videos whose `channelId` equals the channel; a source that cannot serve a request (`NotServed`) is skipped instead of showing something else; "load more" failure keeps the results and only stops paging; search results are not reset |
| 5 | Failure handling | reason identified (`SourceReason`), next source tried, first success used, no popup/error card while anything is on screen; all failed → `SourcesExhausted` with a written title/message (no internet / daily limit used up / switched off / busy) |
| 6 | Loop prevention | each source at most once per request · tracker cool-down 30 s, 1, 2, 4, 8, max 10 min (quota until reset, refused key 5 min) · a request that just failed is answered from memory for 3 s · 3 failed requests in a row → same automatic request rests 60 s · explicit "Try again" may skip a cool-down only if the failure is ≥ 10 s old · one in-flight chain per request key · screen guards: `startWeb` ignores the same query twice, stale answers dropped by `seq` |
| 7 | Existing behaviour | Part 1/2 logic kept: Part 2 tracker/classifier unchanged and used as the evidence store; title colour still follows the source that delivered; blocked-word search, caches, endless scroll, Shorts, avatars unchanged |

## Behaviour changes you should know about
1. **No API key no longer means "YouTube is not connected".** The home/search now go API → Direct → Web like everything else; the old
   card is gone. An error shows only when every source failed.
2. **Direct YouTube network errors now reach Web** (before they became an error card).
3. **Failed refresh / failed next page no longer replace the list by an error card** (before, any error hid the whole list).
4. **Extra requests respect cool-downs**: channel logos and the web-list details skip an API that is cooling down.
5. Tracker local states (`NO_INTERNET`, `SWITCHED_OFF`) are re-read only when Study opens, so they **never block routing**: live flags
   and a reconnected phone work immediately.

## Decisions to confirm
1. `SourceClassifier.DIRECT_REQUIRES_APP = true` (Part 2) is honoured by routing: a phone **without the YouTube app** skips Direct
   YouTube (goes API → Web) although the page-data search itself would work. Set it to `false` to keep Direct usable there.
2. Shorts search and next pages stay API-only (Direct/Web cannot continue a token or list Shorts). With the API down they show the
   existing list and stop paging; a Shorts-only screen with nothing saved shows the one error.
3. Request timeouts were left as they are (API connect 8 s / read 10 s). The first request after a hang waits for the timeout once;
   every later request skips that source instantly. Lower them if you want a faster first switch.

## Modified files
data: **StudySwitch.kt (new)**, StudyRepository (all multi-source calls via the switcher, `StoreFacts`), StudyRules (`StudyException`
is `open`; `errorTitle` uses the switcher's title) · ui: StudyScreen (soft failures, no-key path, `WebHandoff`, loading line, manual
retry), StudyWebSearch (combined "all three failed" message) · tests: **StudySwitchTest.kt (new, 39 tests)**.
`StudyApi`, `StudyNative`, `StudySources`, `StudySourceChecker`, `StudyMonitor`, `StudyStore` are unchanged.

## Test matrix (StudySwitchTest, 39 JVM tests — executed, green)
Priority & no needless switching · API quota → Direct (and API skipped next time) · Direct unavailable (app missing) → Web · Direct
network failure → Web · API auth error / no key → Direct · Web down → others serve · one failure does not touch other sources ·
`NotServed` not blamed · NOT_FOUND passes through · unexpected exceptions fall back · all three fail → one error (network / daily
limit / switched off / busy; also with Web switched off) · cool-down skip, growth (30/60/120/240 s) and recovery · each source once per
request · short memory + 3-failure long rest + manual retry rules · concurrent identical requests run once · stale offline / switch
flags never block · disabled YouTube app blocks only Direct · rate limit is a short pause · loading-flag on/off (also after failure) ·
merge: richer details, never a different video, no duplicates, channel info kept.

## What was run (besides the unit tests)
Real `StudyRepository` + real `StudyApi`/`StudyNative` against the sandbox's real network failure: API and Direct both failed →
`WebHandoff` in ~0.5 s; the same request again answered in 1 ms; another search skipped both cooling sources in 0 ms; quota-out keys →
API never called; saved home feed stayed on screen when all sources failed; next-page failure raised an error the screen swallows;
Web switched off + all failing → "No internet connection"; channel page fallback and `channelInfo` (never throws) behaved as designed.
The existing Part 2 test class gives the same 6 failures with and without these changes when run against my `org.json` stand-in
(they parse real JSON), so they show no regression; run them with the real library in Gradle.

## Not verified
Android compile of `StudyScreen` / `StudyWebSearch` / `StudyStore`; real Compose rendering of the loading line; the live YouTube API and
pages (a *successful* Direct YouTube / Web answer was tested with fake sources and the Part 2 parser tests, not live); WebView error
callbacks on a real network loss.
