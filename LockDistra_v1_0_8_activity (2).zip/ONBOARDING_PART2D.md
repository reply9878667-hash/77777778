# Onboarding – Part 2D: final celebration + dancing mascot

Journey: Welcome -> Q1..Q7 -> **Celebration** -> Continue -> app continues as before (login question, then Home).
Questions, validation, question navigation and the question-wise reactions are untouched.

## About "3D"
The Part 1 mascot is a shaded **2D** character (one Canvas: radial gradients, gloss, contact shadows, breathing
squash); it is not a 3D model, so there is no 3D to preserve and none was faked. The dance uses the very same
drawing (same character, palette, face), only with new body motion.

## Files
| File | Change |
|---|---|
| `ui/onboarding/CelebrationScreen.kt` | NEW. The screen: mascot (main attraction, ~46% of the height), glow, light confetti, speech bubble with the personalised message, one Continue button. Portrait + landscape. |
| `ui/onboarding/BuddyDance.kt` | NEW. The dance as plain maths: 5 moves (bounce + arm pumps, side sway with hands high, wiggle with arms wide, disco point, big jumps). |
| `ui/onboarding/FocusBuddy.kt` | EDITED. When `mood = Celebrating` it dances: moves picked at random (never the same twice in a row), blended over 0.5 s, sprout swings with a lag, mouth sings along. Face keeps blinking/glancing. Other moods unchanged. |
| `ui/onboarding/BuddyLook.kt` | +1 mood look (`Celebrating`: beaming face, sparkles). |
| `ui/onboarding/OnboardingFlow.kt` | EDITED. New step `Celebration`; Finish on Q7 now goes there instead of ending; Continue there calls `onQuestionsFinished(answers)` then `onFinished()`. Back from it returns to Q7, answers intact. |
| `data/OnboardingReactions.kt` | +`BuddyMood.Celebrating`, +`OnboardingCelebration` (headline/body text, name cleaning). |
| `data/OnboardingStore.kt` | +`saveAnswers()` / `savedAnswers()`: the 7 answers kept in the app's private storage on the phone. No account, no network. |
| `ui/FocusApp.kt` | 1 edit: `OnboardingFlow(..., onQuestionsFinished = onboarding::saveAnswers)`. |
| tests | `OnboardingCelebrationTest`, `BuddyDanceTest` (new). |

## The scene
Mascot pops in with a spring -> bubble appears -> "Awesome, <name>! 🎉" is typed while the mascot waves and
greets -> after ~1 s it starts dancing (while the rest of the message is typed) -> keeps dancing, glow breathing,
confetti drifting, until Continue. Tap the bubble to skip typing; tap the mascot and it reacts (nod / tilt / hop)
on top of the dance. The Continue button fades in as soon as the headline is typed.

## Testing
1. Clear app data, launch, go through Welcome and all 7 questions (type a name in Q1, e.g. "Rahul").
2. On Q7 press Finish: the celebration slides in. Check the headline shows the exact name ("Awesome, Rahul! 🎉"),
   and the second line is the thank-you message.
3. Watch the dance for ~20 s: it should change moves, never repeat the same one twice in a row, with smooth
   transitions; face keeps blinking and smiling; sprout swings.
4. Tap the mascot (extra reaction) and the bubble (skips typing). Rotate the phone (scene stays, no replay).
5. System back: returns to Q7 with all answers selected; Finish again returns to the celebration.
6. Continue: onboarding ends and the app continues exactly as before. Answers are saved
   (`OnboardingStore.get(context).savedAnswers()`).
7. Names: try a 30-letter name and one with spaces ("  Mary   Ann ").
8. `./gradlew testDebugUnitTest`.

## For Part 2E (integration testing)
`OnboardingFlow` is the single entry; `onQuestionsFinished` receives the answers, `onFinished` ends the flow.
