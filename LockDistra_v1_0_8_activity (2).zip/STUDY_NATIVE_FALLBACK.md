# Study – fast fallback when the API is resting

Order now, for a Study **search** (videos tab) and the Study **home feed**:

1. **YouTube API** (normal rules, Education category). Used whenever a key is not resting.
2. **Page-data search** (`StudyNative`, new). One HTTPS request to YouTube's search page, its `ytInitialData` JSON is read
   (classic `videoRenderer` and newer `lockupViewModel`). No WebView, no API units, fast. Results are judged by the same text
   rules as before (`StudyWeb.judge`: never adult words, no Shorts, no live streams, study word or study search, trusted channels).
3. **WebView search** (`StudyWebSearch`, unchanged). Only when step 2 cannot read YouTube's page at all (`NoDataException`).

## What changed
* `StudyRepository.search` / `feed` / `feedMore`: when the API rests or fails with a limit / key error, they carry on with step 2
  instead of an old saved list or an error. Home feed = a few subjects searched together and mixed channel by channel.
  Endless scroll = next subject + lesson type ("important questions", "one shot revision", ...).
* `StudyRules.parseError`: reads `errors[].reason`, `details[].reason` and `status`; 429 / rate-limit = 1 minute rest, daily quota =
  rest until reset, key problem (any other 401/403) = **5 minutes** (was 60), then the API is tried again by itself.
* `StudyScreen`: no longer jumps to the WebView just because the API is resting.

## Honest limits
* Step 2 reads YouTube's page, not an official API (same terms caveat as `STUDY_WEB_SEARCH.md`). If YouTube changes its page, step 3 takes over.
* Without the API there is no Education-category check: the text filter is looser. Shorts still need the API.
* Not run on a device (no Android / network in the build environment): please test Study search + Home with Wi-Fi on, and once with the API key removed.
* If the API was refused because the APK is signed with a different key than the Google Cloud key restriction, fix the SHA-1 in Google Cloud:
  that is what keeps the API itself from working.

## Source indicator (for the owner; the person only sees a colour)
The "Re Arena" title (and the search keyword while a search is open) is tinted by `StudyMonitor`:
* normal colour = YouTube API
* **yellow** = page-data search (`StudyNative`, API resting)
* **red** = WebView search (last backup)
Switching is fully automatic: any API failure (limit, refused key, timeout, 5xx) first tries the next source; no error message
shows while a backup still works. A resting API is asked again by itself (5 minutes for key problems, 1 minute when "busy",
until the daily reset when the quota is used up), and the colour returns to normal when the API answers again.

## Home feed: a different mix on every app launch
* Before: Study opened on the saved list, and the normal load returned the same saved list for 6 hours -> always the same videos.
* Now: every fetched video goes into one **pool** (newest first, max 150, `StudyRepository.savePool`). On the first Study open of an app launch
  `launchFeed()` shows a fresh random pick of 60 from that pool (instant, no network). The pick is kept for the rest of the launch, so
  switching tabs inside the app shows the same list; pull-down refresh makes a new one.
* A quiet background refresh (`feed(force = true, quiet = true)`, at most every 30 minutes) adds new videos to the pool for the next launch
  without changing the list on screen. Promo video insertion is unchanged (`PromoVideo.inFeed` is applied to the launch mix exactly as before).
