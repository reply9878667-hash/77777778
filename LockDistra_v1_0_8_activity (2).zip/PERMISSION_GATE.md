# Permission gate (opens Home when every required permission is allowed, or after Skip)

STATUS: written, NOT compiled, NOT run on a device (no Gradle / Android SDK / Kotlin compiler in the authoring environment).

## Flow
New user:      Splash -> Welcome -> 7 questions -> Celebration (character) -> Sign up -> "Welcome" -> **Permissions** -> Home
Login:         Splash -> Log in -> "Welcome back" -> **Permissions** (only if one is missing) -> Home
Saved login:   Splash -> Home, or Permissions first if a permission is missing / was switched off since last time.

The Permissions screen lists each required permission with an Allow button and an "X of N allowed" counter, and a
"Skip for now" button pinned at the bottom. When the last one is allowed Home opens by itself; Skip opens Home right away.
Skip is remembered on the phone (`PermissionGateStore`, prefs "permission_gate"), so the page is not shown again at every start.
It is not shown again after a skip even if a permission is switched off later; use Settings > permissions or the
"Finish setup" card on Home.

## After a skip: features ask instead of switching on without permission
Turning ON Bedtime, website blocking, Shorts blocking or a section/feature switch while Accessibility is off, or picking a
Study Check-In interval while notifications are off, does not turn it on: a "Permission needed" dialog offers Allow / Not now.
Turning OFF is always allowed. Starting a Focus session / Pomodoro already asked for Accessibility before this change.

## Required (all must be allowed)
Accessibility service, Usage access, Notifications, Unrestricted battery, Alarms & reminders (Android 12+ only).
NOT required: Device admin (uninstall protection) - optional, has its own switch in Settings, and that switch only turns
ON when Android really granted it.

## Files
new:     `ui/screens/PermissionGateScreen.kt`, `data/PermissionGateStore.kt`, `test/.../data/PermissionGateTest.kt`, this file
changed: `data/AppEntryRules.kt` (new Permissions route, `permissionsGranted` param, default true, `permissionStepDone`),
         `service/Permissions.kt` (`RequiredPermission`, `PermissionStatus.missingRequired()/allRequiredGranted`, exact-alarm check),
         `ui/AppEntry.kt` (reads permissions + skip, passes them to the route, shows the screen),
         `ui/FocusApp.kt` (4 feature toggles + Study Check-In ask for the permission; one dialog),
         `ui/screens/Sheets.kt` (`PermissionRow` private -> internal, so the gate reuses the same card)
Old "A few permissions first" sheet and the Settings permission lines are unchanged.
