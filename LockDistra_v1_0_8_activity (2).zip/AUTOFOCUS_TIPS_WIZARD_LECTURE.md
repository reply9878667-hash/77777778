# Auto Focus, Feature tips, Start wizard, Lecture Lock

Merged into the ReWire_PowerMenu_LinkSync project.

## What was added
- **Start wizard** (`ui/screens/StartWizard.kt`): replaces the old "Ready to Start?" confirmation. Shown every time Focus Mode or a
  Pomodoro starts: profile check, what is blocked, info, Study Check-In, "Allow ..." switches, Lecture Lock link, Turn OFF method.
- **Auto Focus** (`data/AutoFocusSchedule|Store|Notifier.kt`, `ui/autofocus/AutoFocusUi.kt`): start/end time + days; Focus Mode starts
  by itself for exactly the time left. "Auto" chip on Home, card in Settings > Focus.
- **Feature tips** (`ui/tips/*`): one-at-a-time spotlight hints, paced by app opens and sessions. Switch + "Show all tips again" in Settings.
- **Lecture Lock** (`data/LectureLink|LectureLockStore|LectureGuard.kt`, `service/AppBlockerService.kt`): paste a YouTube link in the wizard; it opens straight
  in YouTube when the session begins (the app opens it, and the Accessibility service opens it a few seconds in if YouTube is not in front). While the
  session runs, leaving the player (Home, Search, Subscriptions, Library, Shorts) or switching to a video of a different length sends the person back to the
  lecture. YouTube stays usable for the lecture even if it is in the blocked list. Fails open: if the YouTube screen is not recognised nothing is done.
  Limits: YouTube gives no video ID on screen, so a different video is only noticed by its length while the player bar is visible.

## Changed existing files
- `ui/FocusApp.kt`, `ui/screens/SettingsScreen.kt` (wizard/auto focus/tips wiring)
- `ui/components/FloatingFocusButton.kt` (new optional `hint` ring)

## Moved
- "Turn OFF method" and "Study Check-In" are chosen in the start wizard now, no longer cards in Settings.
  (`FocusOffMethodCard` / `StudyCheckInCard` still exist in `FocusControlsCard.kt`, just unused.)

## Not included
- Pomodoro "rounds" (the source files referenced it, the base app has no such feature): the wizard says "repeats until you stop it".
