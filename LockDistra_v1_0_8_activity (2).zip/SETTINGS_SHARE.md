# Settings backup, completeness fix and "Share with a friend"

## What was wrong
* **Auto Focus** kept its file in normal storage while the backup read it from device-protected storage (`Storage.prefs`),
  which also *moves* the file. After an Upload and a restart the phone's own Auto Focus schedule could be reset, and a
  Download wrote the schedule where nothing reads it. `AutoFocusStore` and `SmartSuggestStore` now use `Storage.prefs`
  (an existing file is moved over once, automatically).
* The five **Focus Mode advanced controls** (`ctl_allow_*`), the Focus Mode **name** and the **Smart suggest** switch were
  not part of the backup. They are now.

## In a backup (Upload / Download)
Focus Mode (blocked apps, Shorts, reminder, theme, last duration, restore-after-restart, study check-in, the five advanced
controls, name), App limits + category limits + floating timer + emergency limit settings, Emergency access apps and reset
mode, Pomodoro times, Auto Focus schedule, Website limits, Website blocking, Content filters, Keyword blocking, Adult
blocking switches + custom entries, Bedtime, every Focus Profile (apps, Shorts, features, websites, limits, emergency
limits, selected profile), Smart suggest switch.

## Not in a backup, on purpose
App lock PIN/password and its settings, trusted-phone keys, login, Prevent changes, Focus OFF method, Advanced protection
(needs the Device admin permission again), the running session / usage / emergency windows, the Daily Task Planner, the
lecture link of one session, Android permissions.

## Share your settings with a friend
Settings > Backup:
* **Share your settings with a friend** - saves a copy (without the name) at `sharedSettings/{CODE}` and shows a code like
  `K7P2-9QXM`, with *Copy code* and *Share*. Codes use 8 characters from `ABCDEFGHJKMNPQRSTUVWXYZ23456789` (no I, L, O, 0, 1).
* **Paste your friend's code** - accepts the code in any spelling (capitals, spaces, dashes) or the whole pasted message,
  looks it up, asks for confirmation, then writes the settings and restarts ReWire. The friend's own name, App lock and
  permissions are kept.
* Same locks as Download: not while Focus Mode or a Pomodoro is running, and not while Prevent changes is on.
* A downloaded text is checked first: only known settings, each with the type the app stores; anything else refuses the
  whole text and nothing is changed.

## Server rules - publish before using
`firebase/database.rules.json` has a new `sharedSettings/$code` node: any logged-in user who knows a code can read it,
nobody can list codes, a code can only be created once, and only its owner can delete it. **Publish the rules**
(`firebase deploy --only database`) or Share / Paste will answer "permission denied".

## Tests
`SettingsBackupTest` (plain JVM, `./gradlew test`): covered / not covered keys, type checks, shared copy, code format.
