# Player centre icon + Study video no longer binds to Focus by itself

## 1. Two play icons / tiny spinner in the lecture player
YouTube draws its own play / pause icon and its own loading circle in the middle of the video. For 720p and up the player is drawn big
and scaled down, so those icons became a tiny dot, shown next to LockDistra's own big button (two icons) and the slow-network circle was
that tiny dot too. Now a small black badge (#cv) covers the middle while the video buffers, starts, is paused or just changed state:
it holds LockDistra's own spinner (bigger), and a white play mark when paused with the controls hidden. During normal playing it is gone.

## 2. Focus Mode on + tapping a Study video
Cause: while a session ran, EVERY tapped Study video replaced the lecture (`switchLecture` -> `lectureStore.set(url)` -> locked player),
even when the session was started without a lecture link. That tied the timer to the player (it stands still when you leave).
Now it replaces the lecture only when the session already has one (`lectureBound`). Otherwise the video opens as a normal preview and the timer is not tied to it.
"Change video" inside a lecture session works as before. Shorts swipe stays off during a session.
Not compiled / not run on a device.
