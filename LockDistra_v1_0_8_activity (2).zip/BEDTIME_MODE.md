# Bedtime Mode (Task 3)

Nightly, repeating app blocking with its own schedule and its own app list.
Where: **Blocked apps** screen, compact card at the top (no new screen, tab or section).

## Files
New: `data/Bedtime.kt` (rules), `data/BedtimeStore.kt` (storage), `service/Bedtime.kt` (alarm, notifications, receiver),
`ui/screens/BedtimeCard.kt` (card + app picker), `test/.../BedtimeTest.kt`.
Edited (small hooks): `AppBlockerService.kt`, `BlockActivity.kt`, `AppsScreen.kt`, `AppViewModel.kt`, `FocusApp.kt`,
`FocusApplication.kt` (one `sync` call), `AndroidManifest.xml` (one receiver).

## How it works
* Settings live in their own prefs file `bedtime` (device-protected storage, like the other stores).
* **Blocking follows the clock, not an alarm.** `AppBlockerService` (the existing accessibility service) asks
  `BedtimeStore.blocks(pkg)`; if true it shows the existing block screen with a new reason `REASON_BEDTIME`.
  Works with no focus session, survives restarts / process kills / time changes by construction.
  A 1 s watchdog (already there) also checks while the window is open, so an app already on screen is closed when bedtime starts.
* Overnight windows: end < start means "crosses midnight" (22:00-07:00). Start included, end excluded. Start == end is rejected.
* **One alarm** (`AlarmManager`, fixed request code 31 + `FLAG_UPDATE_CURRENT`) is armed for the next start/end boundary;
  it only drives the notifications. Re-arming replaces it, so no duplicates. Exact when "Alarms & reminders" is allowed,
  otherwise `setAndAllowWhileIdle`.
* `BedtimeReceiver` re-syncs on: its alarm, boot (locked + normal), app update, `TIME_SET`, `TIMEZONE_CHANGED`; and `sync` also runs at app start and when the accessibility service connects.
* Notifications (own channel `bedtime_v1`, one id so OFF replaces ON): exactly the two texts from the task. A persisted
  "announced" flag stops repeats after reboots / repeated syncs.
* Not blocked: ReWire, the Settings app, dialer/phone/emergency/systemui (never offered in the list, and re-checked at enforcement).

## Isolation
No change to `FocusStore.blocked`, App Limits, Pomodoro, website rules or the focus-session logic. No new service,
no second AccessibilityService. Bedtime is checked right after the uninstall-protection check, before limits/focus.

## Permissions
No new manifest permissions. Uses ones already declared: `POST_NOTIFICATIONS` (optional; blocking works without it),
`SCHEDULE_EXACT_ALARM` (optional), `RECEIVE_BOOT_COMPLETED`, and the existing Accessibility service (required for blocking;
the card warns when it is off, and a notification is posted after a reboot that switched it off).

## Tests
Automated (`BedtimeTest`, 13 cases, pass on JUnit 4.13.2): defaults, same-day and overnight windows, start/end edges,
equal times rejected, only-selected-apps blocked, add/remove apps, off/no-apps, daily repetition, next-boundary math
(incl. across midnight), clock text, exact notification text.
Device checklist (needs a phone; not runnable without the Android SDK): toggle, pick times, select/deselect apps,
open a selected app at start (blocked) and at end (opens), reboot inside/outside the window, change clock/time zone,
deny notifications, run alongside App Limits and a Focus session.

## Known limitations
* Blocking needs ReWire's Accessibility service enabled (same as the rest of the app).
* It follows the phone's clock, so changing the date/time can lift it (the focus session has `ClockWatch` for this; Bedtime does not duplicate it).
* Can be switched off or edited at any time (no lock-in), including during bedtime.
* Without exact-alarm permission the start/end *notification* can be delayed a few minutes in deep sleep; blocking is not delayed.
* One schedule for every day (no per-weekday). Trusted-phone "extra time" does not open Bedtime-blocked apps.
