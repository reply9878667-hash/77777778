# Focus Profile, Part 3 (selected profile controls Focus Mode)

STATUS: written, NOT compiled, NOT run, NOT tested on a device (no Gradle / Android SDK / device in the authoring environment).
Build in Android Studio, run `FocusProfileRuntimeTest` and the existing unit tests, then do the manual checks below.

## How it works
No settings are copied and no new service/timer exists. While a focus session runs, the blockers ask
`FocusProfileRuntime` (pure, `data/FocusProfileRuntime.kt`) which settings to use:
- session running + a saved profile selected -> that profile's blocked apps/games, Shorts, Reels/Status sections,
  websites and app limits replace the phone-wide Focus lists (never combined with them or the other profile);
- anything else (no session, Pomodoro Break, no profile saved, selected profile missing) -> old behaviour, unchanged.
So Focus OFF / Break "remove" the profile just by there being no session; Break end starts the normal focus session
again (existing `PomodoroEngine`), which picks the selected profile up again. Durations are untouched.
Profile, selection and session are all persisted, so a restart/reboot brings back the same state (existing boot path).

## Limits
Profile limit + normal limit for the same app: the stricter one applies, both counted against the same daily usage.
Normal limits are never edited. Normal limits keep working during a profile session.

## Locks
While a session runs, selecting / deleting / editing a profile, or creating a first one, follows "Allow app changes" /
Prevent changes (same rule as editing the phone-wide lists). Outside a session and in a Break they are free.

## Known limits (not done on purpose / not wired)
- A profile limit's own Emergency setting (`limitEmergency`) is not read; the block screen uses the app's normal
  limit-emergency settings.
- Profile sessions do not use "Inside apps" custom sections or Adult/Bedtime (not part of a profile, as before).
- Status notification text is not refreshed on a mid-session profile switch until its next refresh.

## Files
new: `data/FocusProfileRuntime.kt`, `FocusProfileRuntimeTest.kt`, this file
changed: `service/AppBlockerService.kt`, `service/Notifications.kt`, `data/FocusProfileStore.kt`

## Manual device checks
1. Profile 1 blocks app A, Profile 2 blocks app B; select 1, Focus ON: A blocked, B open; OFF: both open.
2. Normal limit on app C still blocks C at its limit with Focus OFF and ON.
3. Profile limit on app D (e.g. 2 min): blocked after 2 min of use during Focus only.
4. Switch selected profile with Focus OFF, then ON: new profile's rules.
5. Pomodoro 1/1 min: Focus blocks, Break opens everything, next Focus blocks again.
6. Reboot mid-Focus and mid-Break; delete selected profile; Focus ON with no profiles (old behaviour).

## Logo change
New logo replaces the old one everywhere except the status-bar notification icon (`ic_stat_leaf`, untouched):
launcher icon (legacy + adaptive foreground/background + themed monochrome, all densities) and the in-app logo
`drawable-nodpi/ic_rewire_logo.png` (splash, dashboard, lock and online screens use it). Only image files changed.

## Focus Profile UI redesign (UI only)
STATUS: written, NOT compiled, NOT run (no Gradle / Android SDK here). Build in Android Studio and check on a device.
`FocusProfileScreen` now uses the main app's look: Home-style header (logo tile, back), night-scene hero card, FocusCards with
icon tiles, same buttons, and the same glass bottom bar with two tabs: Profile / Blocking (no Settings tab or section).
Title: "Create Focus Profile" (empty slot) / "Edit Focus Profile" (saved slot).
- `components/BottomBar.kt`: bar body extracted into reusable `FocusTabBar` + `TabBarItem`; `FocusBottomBar` (main screens) calls it, unchanged look.
- `FocusProfileScreen.kt`: the Blocking screen is now the Blocking tab (inline) instead of a slide-over; same `settingsScreen` callback.
- Unchanged: `FocusApp.kt` wiring, save / delete / select callbacks, openAfterSave logic, all data and runtime code.

## Website Blocking improvement (normal app only, Focus Profile untouched)
STATUS: written, NOT compiled, NOT run. Build in Android Studio, run `WebsiteBlockingTest`, then check on a device.
- New "Blocked websites" list inside the existing Website Blocking card (Blocking tab): type any link/domain, or several at once
  (comma / space / new line), each with edit, delete and its own ON/OFF switch. Duplicates are refused (www., http/https, paths and case ignored).
- Stored like an app's list under owner key `WebsiteCatalog.GENERAL` ("*") in the same `WebsiteStore` -> saved sites are kept, survive restart.
  Enforced by the existing engine (`AppBlockerService.enforceWebsite`) in the supported browsers during every focus session; subpages and subdomains match at a dot boundary.
- Existing per-app lists are unchanged and still listed in the card ("Inside specific apps").
- Changed: `data/WebsiteBlocking.kt`, `data/WebsiteStore.kt`, `ui/AppViewModel.kt`, `ui/FocusApp.kt`, `ui/screens/AppsScreen.kt`,
  `ui/screens/WebsiteBlockingCard.kt`, `ui/screens/WebsiteBlockingBlock.kt` (site list extracted, same behaviour for app panels), `WebsiteBlockingTest.kt`.
- Not done on purpose: Focus Profile, keyword blocking, website usage limits.

## Keyword Blocking (normal app only, Focus Profile untouched)
STATUS: written, NOT compiled, NOT run. Build in Android Studio, run `KeywordBlockingTest` + `WebsiteBlockingTest`, then check on a device.
- New "Keyword Blocking" card in the Blocking tab (below Website Blocking; not shown inside a Focus Profile): master switch, input + Add
  (comma / new-line separated for several), saved keywords with edit / delete / own switch, "new keywords also match inside words", and
  "Check page titles and headings". Saved in `KeywordStore` (own prefs file `keyword_blocking`), so it survives restart; nothing existing is migrated or changed.
- Matching (`data/KeywordBlocking.kt`): text and keyword are cut into lower-case words (any language); a keyword matches when its words appear
  next to each other. Case-insensitive; whole words by default ("sex" does not close "Essex"); per-keyword opt-in to match inside words (>= 3 characters).
- Enforcement: `AppBlockerService.enforceWebsite` (the existing browser path). Checks the address bar text (links and searches) and, rate-limited
  (1 per 1.5 s, <= 200 nodes, headings only), the window title and visible headings the browser exposes. Always on while the switch is on (no session needed).
  Block screen = existing `BlockActivity` with new reason `REASON_KEYWORD` (closes itself when the keyword is switched off / deleted).
- Locks: add / switch ON = tighten, edit / delete / switch OFF = loosen, same `ContentPolicy.canSetFeature` rule as Adult protection.
- Limits (Android): only the supported browsers' address bar and what they expose to accessibility; not other browsers, other apps,
  in-app web views or page body text. A page that exposes no title / headings is checked by its address bar only.
- Changed: new `KeywordBlocking.kt`, `KeywordStore.kt`, `ui/screens/KeywordBlockingCard.kt`, `KeywordBlockingTest.kt`;
  small edits in `AppBlockerService.kt`, `BlockActivity.kt`, `AppViewModel.kt`, `FocusApp.kt`, `AppsScreen.kt`.

## Study fixes (v42 follow-up)
STATUS: written, NOT compiled, NOT run (no Gradle / Android SDK here). Build in Android Studio and check on a device.
- Channel name line under a video: whole line + taller tap area opens the channel page (was a thin text-only target).
- Study chips: Videos / Shorts are selected only when no subject is chosen; choosing a subject un-selects them; tapping Videos/Shorts leaves the subject.
- Thumbnails: sharpest picture YouTube has (maxres > standard > high); old saved feeds upgraded from 320 px to hqdefault; cache is sized by memory.
Files: `ui/screens/StudyScreen.kt`, `data/StudyRules.kt`, `StudyRulesTest.kt`

## Study: pull to refresh, swipe Shorts, India-first (v44)
STATUS: written, NOT compiled, NOT run (no Gradle / Android SDK here). Build in Android Studio, run `StudyRulesTest`, then check on a device.
- Pull down on the Study list (videos, Shorts, search results) refreshes it, like YouTube. The refresh button on top is removed.
  A pull-refresh of the home feed picks other subjects each time. Uses Material3 `PullToRefreshBox` (BOM 2024.09.03).
- Tapping a Short opens `ShortsViewer` (new file): full screen, swipe up = next Short, swipe down = previous, tap = pause/play, loops.
  Only the visible Short has a WebView player. Works on Study home, search results and a channel's Shorts tab.
  During a Focus session a tapped Short still becomes the lecture (old behaviour).
- India first: search asks YouTube for `regionCode=IN`, `relevanceLanguage=hi`; each channel's country is looked up once and remembered.
  Home feed leaves out channels that set another country; search keeps them but puts them last. Followed/most-played channels are never treated as foreign.
Files: new `ui/screens/ShortsViewer.kt`; changed `StudyScreen.kt`, `data/StudyApi.kt`, `StudyRepository.kt`, `StudyRules.kt`, `StudyStore.kt`, `StudyRulesTest.kt`

## Day Coach simplified (v45)
STATUS: written, NOT compiled, NOT run (no Gradle / Android SDK here). Build in Android Studio, run `DayCoachTest`, then check on a device.
The Aaj / Kal / + Block planner is removed. Only two times are chosen: Day start and Sleep.
- Day start: "Good morning" (5 minutes to get fresh). 5 minutes later: the first unfinished task of the Today list (list order) as "Pehla task".
- 15 minutes before sleep: reminder to set tomorrow's tasks (text says "check" instead of "set" when Tomorrow tasks already exist).
- Sleep time: "Good night" (replaces the reminder notification).
- Notifications only (closed app: normal notification; open app: heads-up banner over the app). Nothing is blocked, no nagging, no Done button.
- Old saved block plans are dropped. Removed: `DayCoachActionReceiver` (+ manifest entry), the old "plan reminders" channel.
Files: `data/DayCoach.kt`, `data/DayCoachStore.kt`, `service/DayCoach.kt`, `ui/screens/DayCoachCard.kt`, `AndroidManifest.xml`, `DayCoachTest.kt`

## Study home: mixed channels, educational only (v46)
STATUS: written, NOT compiled, NOT run (no Gradle / Android SDK here). Build in Android Studio, run `StudyRulesTest`, then check on a device.
- Home feed (videos and Shorts, each on its own) is mixed by `StudyRules.diversify`: one video per channel per round, so channels alternate and
  the same channel never repeats back to back (unless it is the only one left). A channel has at most 3 videos in the feed (no cap when fewer than 6 channels).
- Channels the person plays a lot no longer count as fully trusted: they skip only the "Education" category check; entertainment/gaming-type
  videos are still left out. Followed channels stay fully trusted.
Files: `data/StudyRules.kt`, `data/StudyRepository.kt`, `StudyRulesTest.kt`
