# Study – Web Search (no API limit)

The Study search can now be read from YouTube's own mobile search page inside ReWire. It uses **none of the free daily
YouTube API limit** (a search costs 100 units there). Videos still have to pass the Study rules and still play in ReWire's
own player.

## When it is used
* **Automatically only**: the daily limit is used up (all keys resting), a search fails with a limit/key error, or the
  Study home has nothing saved to show. The search carries on as a web search, with no error screen.
* **Nothing tells the person.** There is no note, banner or switch: the list looks like a normal Study list.
* **Shorts** and the home feed still use the API (the home feed also shows the last saved copy when the limit is out).
* When the limit resets, the next search uses the API again by itself.

## What the person sees
A normal Study list under the subject chips: only approved videos, no Shorts, ads, channels, playlists, YouTube top bar,
bottom bar or "more" menus. Tapping a video opens **ReWire's player** (speed, resume, Start Focus Mode, background play),
never YouTube's watch page. Any other link is refused, so the person cannot wander off. The look follows the app theme.

## How it works
* `StudyWeb` (data, pure Kotlin, unit tested): search address, allowed-address check, card parsing, the rules.
* `StudyWebSearch` (ui): a WebView + a page script (`StudyWebScript`). The script finds result cards by their video link
  (not by YouTube's tag names), hides each card until the app has judged it, and reports taps.
* `StudyRepository.judgeWeb`: with the API available the **normal rules** decide (Education category, trusted channels,
  distraction words, not a Short) for 1 unit per 50 videos. With the limit used up only the card's own words are known:
  never an adult word, never a Short, a trusted channel's name is accepted, otherwise no distraction word **and** a study
  word (English or Hindi) on the card, or the search itself is a subject / study search.
* The page address is checked on every load and every in-page change; anything but the search page goes back to it.

## Limits (be honest about them)
* This reads YouTube's page, which is **not an official API**. YouTube's terms do not allow hiding parts of its pages or
  reading them this way, so keep it as a backup and think about it before a Play Store release.
* YouTube can change its page. The script is written not to depend on tag names, but it can still stop finding cards;
  then the list shows "No study videos found" and the API search is the fix once the limit resets.
* Without the API (limit used up) there is no Education-category check, so the filter is looser than a normal search.
* Needs a real-device test: it could not be run in the build environment (no network, no Android device).
