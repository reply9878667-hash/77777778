# Lecture player: skipped parts show in red on the seek bar

Problem: with "turn Focus Mode off when the lecture ends", skipped parts keep Focus Mode on (less than 90 % watched), but it was hard to
see WHICH part was skipped.

Now: every part that was jumped over (not watched, and before the furthest point reached) is drawn as a thin **red line** on the
seek bar, at the same place and with the same length as the skipped part. When that part is watched later, its red mark disappears.

* `LectureWatch.skippedRanges / skippedJson`: unwatched seconds BEFORE the furthest reached point (the not-yet-played rest of the
  video is never red). Runs shorter than 5 s are ignored. Output is fractions of the video, always with a dot as decimal sign.
* `LecturePlayerHtml`: `#gaps` layer above the purple progress bar, `setGaps([[from,to],...])` draws one `<i>` per range.
* `LectureActivity.pushSkipped()`: sends the ranges after every progress report and again after a page reload (saved parts show again).
* Own player only. In the normal YouTube page mode (fallback) the bar is YouTube's own and cannot be marked; the existing
  "Part of this lecture was skipped" message and the "Watch the skipped part" button still work there.
* Tests: `LectureWatchTest` (skippedRanges / skippedJson). Not compiled and not run on a device.
