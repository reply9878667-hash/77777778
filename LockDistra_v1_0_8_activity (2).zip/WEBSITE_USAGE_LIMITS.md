# Task 4 – Website Usage Limits

A daily time limit per website, like the App Usage Limit, for sites opened in a supported browser.

## Where it is
**Blocking screen -> "Blocking" section.** A new card, **Website Usage Limits**, sits directly under **Website Blocking**.
Same category, two separate cards, separate controls: Website Blocking closes sites during focus sessions; Website
Usage Limits limits the time spent on a site each day. No new page. Focus Profiles are untouched (the card is not shown
there and the profile code was not changed).

## What the person can do
* **Add**: type a link or a name (`youtube.com`, `https://www.instagram.com/reels/..`, `facebook`) or tap a suggestion
  (YouTube, Instagram, Facebook, X, Reddit, Netflix); choose hours (stepper), minutes (slider) or a preset.
* **Manage**: several sites, each with its own limit; edit the site and/or time; delete; ON/OFF per site. Each row shows
  the site, `used of limit` and a progress bar.
* **Duplicates are rejected** however the site is typed (`www.`, scheme, path, name only) and for other addresses of
  the same site (`youtu.be` for YouTube, `twitter.com` for `x.com`, `fb.com` for Facebook). A site that would overlap one
  that already has a limit (`mail.google.com` with `google.com`) is rejected too, so one page never counts twice.
* Same lock as app limits: while a session runs with "Allow app restriction changes" off, the card is read-only.
  Adding or switching ON asks for the Accessibility permission, like the other blocking features.

## How it works
* **Which site is open**: the existing browser monitoring (`AppBlockerService.enforceWebsite`) already reads the address
  bar of Chrome, Edge, Brave, Firefox, Samsung Internet, Opera, Vivaldi and DuckDuckGo. The host it reads is now also
  remembered (`noteSite`), so nothing new is read from the screen.
* **Counting**: `siteTrackLoop` runs only while a supported browser is in front, the screen is on and at least one
  website limit is ON. It adds one second at a time to the limit that covers the open host (the domain, every
  subpage and every subdomain). It saves every 5 s, and on screen off, shutdown, leaving the browser and service stop.
* **Midnight**: `WebsiteLimitStore` stores the day with the usage and clears yesterday's numbers on the first access of
  a new day. Limits and usage are in device-protected storage (like app limits), so they survive app restart, process
  death and reboot.
* **When the limit is used up**: the existing ReWire block screen opens over the browser (new reason
  `REASON_WEBSITE_LIMIT`: "LIMIT REACHED", "Time's up for today", countdown to midnight, "Go to home screen", "Continue to
  <browser>", "Change limit"). Opening the site again is blocked at once from the address bar. Changing the limit, switching
  it OFF or the new day lifts it; the block screen closes by itself then. "Change limit" opens the Blocking screen.
* **Battery**: nothing runs unless a limit is ON and a supported browser is in front. When only a website limit needs the
  address bar it is read at most every 1.5 s (events are rate limited, not polled harder); counting is a 1 s tick that does
  no screen reads.

## What is NOT claimed (Android limits)
* Only the browsers listed above are measured. Other browsers, in-app web views and sites in background tabs are **not**
  counted. A site playing audio/video in the background or picture-in-picture is not counted.
* Time comes from the address bar. A browser can hide it while a page scrolls, so the last site keeps counting for up to
  5 minutes and then counting pauses until the bar can be read again. A short undercount is possible; ReWire never guesses
  beyond that.
* A limit applies to the domain typed. Typing `youtube.com` covers `m.youtube.com`, `music.youtube.com` and every page.
  Different sites (`youtube.com` vs `youtube-nocookie.com`) are not linked.
* Emergency access and "Request to unlock" are for app limits; they are not offered on a website-limit block screen.

## Files
New: `data/WebsiteLimits.kt` (rules), `data/WebsiteLimitStore.kt` (storage), `ui/screens/WebsiteLimitsCard.kt` (card +
editor), `test/.../WebsiteLimitsTest.kt` (20 rule tests), this file.
Changed (small, additive): `service/AppBlockerService.kt`, `BlockActivity.kt`, `MainActivity.kt` (open Blocking from the
block screen), `ui/AppViewModel.kt`, `ui/FocusApp.kt`, `ui/screens/AppsScreen.kt` (card slot; `AppsScreen` is now `internal`
because it takes internal types), `ui/screens/LimitsScreen.kt` (`Stepper` is now `internal`, reused).
Not touched: Focus Profile code, App Limits logic, Website Blocking rules, Keyword Blocking, Adult protection.

## Not run
No Android SDK / Gradle / Kotlin compiler in the sandbox: **not compiled, not run on a device, unit tests not executed**.
Checked by script: brace balance of every edited file and that every `com.focusmode.app.*` import resolves.
Please run `./gradlew testDebugUnitTest assembleDebug` and try on a phone: add a 1-minute limit for a site in Chrome,
open it, wait for the block screen, then check it opens again after midnight (or by changing the phone date).
