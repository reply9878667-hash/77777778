# Player: video quality really applies, and always tells the truth

Only `ui/lecture/LecturePlayerHtml.kt` changed (the player page's script).

- **Higher quality actually applied:** YouTube gives 720p / 1080p only to a big player; a phone-sized player stays at 360-480p whatever
  is asked. When 720p or more is chosen, the player is drawn at that real width (1280 / 1920 / 2560 px) and scaled down to fit the
  video (`qBig()` + `layout()`). Auto is untouched. The choice is pushed again 0.7 s after the resize.
- **Menu never lies:** the highlighted line is the quality that REALLY plays (`getPlaybackQuality`), updated live while the menu is
  open. Auto shows what it currently plays: "Auto (480p)". The "Playing now" line says "you chose 1080p, but YouTube is not giving
  it for this video right now" instead of the old unclear text.
- **Small chip on the video** (top left, 3.5 s): "Playing at 720p", or "Playing at 480p  (you chose 1080p)" when they differ.
  Shown after a choice and whenever the real quality changes. Hidden in the floating window.
